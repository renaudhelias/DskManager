/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JCPC.ui;

import java.awt.event.KeyEvent;

/**
 *
 * @author Markus
 */
public class KeyTranslator {

    public KeyEvent translate(KeyEvent e, String localkeys) {

        // german keyboard mapping
        if (localkeys.equals("DE_DE")) {
            if (e.getKeyChar() == '\u00FC' || e.getKeyChar() == '\u00DC') {
                e.setKeyCode(KeyEvent.VK_OPEN_BRACKET);
                return e;
            }
            if (e.getKeyChar() == '\u00E4' || e.getKeyChar() == '\u00C4') {
                e.setKeyCode(KeyEvent.VK_QUOTE);
                return e;
            }
            if (e.getKeyChar() == '\u00F6' || e.getKeyChar() == '\u00D6') {
                e.setKeyCode(KeyEvent.VK_SEMICOLON);
                return e;
            }
            if (e.getKeyChar() == '\u00DF' || e.getKeyChar() == '\u003F') {
                e.setKeyCode(KeyEvent.VK_MINUS);
                return e;
            }
            if (e.getKeyCode() == 0x2d) // - key to /
            {
                e.setKeyCode(KeyEvent.VK_SLASH);
                return e;
            }

            if (e.getKeyCode() == 0x81) // ß key to ^
            {
                e.setKeyCode(KeyEvent.VK_EQUALS);
                return e;
            }
            if (e.getKeyCode() == 0x99) // <> key to [
            {
                e.setKeyCode(KeyEvent.VK_ALT_GRAPH);
                return e;
            }
            if (e.getKeyCode() == 0x82) // ^ key to TAB
            {
                e.setKeyCode(KeyEvent.VK_TAB);
                return e;
            }
            if (e.getKeyCode() == 0x208) // # key to \
            {
                e.setKeyCode(KeyEvent.VK_BACK_SLASH);
                return e;
            }
            if (e.getKeyCode() == 0x209) // + key to ]
            {
                e.setKeyCode(KeyEvent.VK_CLOSE_BRACKET);
                return e;
            }

            if (e.getKeyCode() == KeyEvent.VK_Z) // change Z to Y
            {
                e.setKeyCode(KeyEvent.VK_Y);
                return e;
            }
            if (e.getKeyCode() == KeyEvent.VK_Y) // and Y to Z
            {
                e.setKeyCode(KeyEvent.VK_Z);
                return e;
            }
        }
        // german mapping end

        // spanish keyboard mapping
        if (localkeys.equals("ES_ES")) {
            if (e.getKeyChar() == '\u00BA' || e.getKeyChar() == '\u00B2') {
                e.setKeyCode(KeyEvent.VK_TAB);
                return e;
            }
            if (e.getKeyChar() == '\u00E7' || e.getKeyChar() == '\u00C7') {
                e.setKeyCode(KeyEvent.VK_BACK_SLASH);
                return e;
            }

            if (e.getKeyChar() == '\u00D1' || e.getKeyChar() == '\u00F1') {
                e.setKeyCode(KeyEvent.VK_SEMICOLON);
                return e;
            }
            if (e.getKeyCode() == 0xde) {
                e.setKeyCode(KeyEvent.VK_MINUS);
                return e;
            }
            if (e.getKeyCode() == 0x2d) // - key to /
            {
                e.setKeyCode(KeyEvent.VK_SLASH);
                return e;
            }
            if (e.getKeyCode() == 0x81) {
                e.setKeyCode(KeyEvent.VK_QUOTE);
                return e;
            }
            if (e.getKeyCode() == 0x209) // + key to ]
            {
                e.setKeyCode(KeyEvent.VK_CLOSE_BRACKET);
                return e;
            }

            if (e.getKeyCode() == 0x206) {
                e.setKeyCode(KeyEvent.VK_EQUALS);
                return e;
            }
            if (e.getKeyCode() == 0x99) {
                e.setKeyCode(KeyEvent.VK_ALT_GRAPH);
                return e;
            }
            if (e.getKeyCode() == 0x80) {
                e.setKeyCode(KeyEvent.VK_OPEN_BRACKET);
                return e;
            }
        }
        // spanish mapping end

        // french keyboard mapping
        if (localkeys.equals("FR_FR")) {
            // ,;:=
            if (e.getKeyCode() == 515) {
                e.setKeyCode(KeyEvent.VK_CLOSE_BRACKET);
                return e;
            }
            if (e.getKeyCode() == 130) {
                e.setKeyCode(KeyEvent.VK_OPEN_BRACKET);
                return e;
            }
            if (e.getKeyCode() == 57) {
                e.setKeyCode(KeyEvent.VK_9);
                return e;
            }
            if (e.getKeyCode() == 522) {
                e.setKeyCode(KeyEvent.VK_MINUS);
                return e;
            }
            if (e.getKeyCode() == KeyEvent.VK_Q) {
                e.setKeyCode(KeyEvent.VK_A);
                return e;
            }
            if (e.getKeyCode() == KeyEvent.VK_A) {
                e.setKeyCode(KeyEvent.VK_Q);
                return e;
            }
            if (e.getKeyCode() == KeyEvent.VK_Z) {
                e.setKeyCode(KeyEvent.VK_W);
                return e;
            }
            if (e.getKeyCode() == KeyEvent.VK_W) {
                e.setKeyCode(KeyEvent.VK_Z);
                return e;
            }
            if (e.getKeyChar() == '\u00B2' || (e.getKeyCode() == 0 && (int)e.getKeyChar() == 65535)) {
                e.setKeyCode(KeyEvent.VK_BACK_SLASH);
                return e;
            }
            if (e.getKeyChar() == '\u0025' || e.getKeyChar() == '\u00F9') {
                e.setKeyCode(KeyEvent.VK_QUOTE);
                return e;
            }
            if (e.getKeyCode() == 151){
                e.setKeyCode(KeyEvent.VK_ALT_GRAPH);
                return e;
            }
            if (e.getKeyCode() == 77){
                e.setKeyCode(59);
                return e;
            }
            if (e.getKeyCode() == 44){
                e.setKeyCode(77);
                return e;
            }
            if (e.getKeyCode() == 59){
                e.setKeyCode(44);
                return e;
            }
            if (e.getKeyCode() == 517){
                e.setKeyCode(KeyEvent.VK_SLASH);
                return e;
            }
            if (e.getKeyCode() == 513){
                e.setKeyCode(KeyEvent.VK_PERIOD);
                return e;
            }
        }
        // french mapping end
        return e;
    }
}
