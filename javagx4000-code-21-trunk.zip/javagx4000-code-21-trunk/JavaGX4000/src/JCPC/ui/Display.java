package JCPC.ui;

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;

import JCPC.core.device.crtc.Basic6845;
import JCPC.system.cpc.CPC;
import JCPC.system.cpc.GateArray;
import java.net.URL;
import javax.imageio.ImageIO;

/**
 * Title: JCPC Description: The Java Emulation Platform Copyright: Copyright (c)
 * 2002 Company:
 *
 * @author
 * @version 1.5
 */
public class Display extends JPanel {

    public static boolean showdisks = false;
//    LCDDisplay dp;
    public static boolean drawmonitor = false;
    boolean DEBUG_FPS = false;
    boolean DEBUG_SCREEN = false;
    public boolean DEBUG_SPRITES = false;
    public static String vscroll = "0";

    public void doTouchFPS() {
        long time = System.currentTimeMillis();
        mNextFPS++;
        if (time - mLastFPSTime >= 1000) {
            mCurrFPS = mNextFPS;
            mNextFPS = 0;
            mLastFPSTime = time;
        }
    }
    long mLastFPSTime;
    int mNextFPS;
    public int mCurrFPS;
    public static boolean scanlines = true;
    public static final Color LED_ON = new Color(0x20, 0xff, 0x20);
    public static final Color LED_OFF = new Color(0x20, 0x60, 0x20, 0xc0);
    public static final Color LED_BORDER = new Color(0x60, 0x40, 0x40, 0xa0);
    public static final Color fLED_ON = new Color(0xff, 0x60, 0x20);
    public static final Color fLED_OFF = new Color(0x60, 0x20, 0x20, 0xc0);
    public static final Color fLED_BORDER = new Color(0x60, 0x40, 0x40, 0xa0);
    public static final Color SCAN = new Color(20, 20, 20, 0x90);
    public static final Color SCANL = new Color(20, 20, 20, 0x30);
    public int storesna, restoresna, crtc;
    final java.net.URL disc = getClass().getResource("3disc.gif");
    final Image Disc = getToolkit().getImage(disc);
    final java.net.URL iel = getClass().getResource("logo.png");
    final Image logo = getToolkit().getImage(iel);
    final java.net.URL imf = getClass().getResource("glossywindow.png");
    final Image masks = getToolkit().getImage(imf);
    final java.net.URL mimf = getClass().getResource("monitor.png");
    final java.net.URL dist = getClass().getResource("MonitorPieceBezel.png");
    final Image Dist = getToolkit().getImage(dist);
    final java.net.URL car = getClass().getResource("minis_cart.gif");
    final Image Cart = getToolkit().getImage(car);
    public boolean large;
    public static boolean ledOn;
    protected int divider = 1;
    public static final int CENTER = 0;
    public static final Dimension SCALE_1 = new Dimension(1, 1);
    public static final Dimension SCALE_2 = new Dimension(2, 2);
    public static final Dimension SCALE_1x2 = new Dimension(1, 2);
    protected String snapl = "Snapshot loaded... Press F5 to reload";
    protected String snaps = "Snapshot stored... Press F5 to load";
    protected String crtctype = "CRTC type ";
    protected String crtctype2 = "... Press F8 to change";
    protected BufferedImage image;
    protected WritableRaster raster, praster;
    protected WritableRaster leftraster, rightraster;
    protected int[] pixels;
    protected int imageWidth, imageHeight;
    protected int scaleWidth, scaleHeight;
    protected Rectangle imageRect = new Rectangle();
    protected Rectangle sourceRect = null;             // Source rectangle in image
    protected int imagePos = CENTER;
    protected boolean sameSize;
    protected boolean painted = true;
    BufferedImage moniter;

    public Display() {
//        dp = new LCDDisplay(768,lowlines);
//        JFrame fram = new JFrame();
//        fram.setLayout(new BorderLayout());
//        fram.add(dp, BorderLayout.CENTER);
//        fram.pack();
//        fram.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
//        fram.setVisible(true);
        try {
            BufferedImage moni = ImageIO.read(mimf);
            moniter = new BufferedImage(moni.getWidth(), moni.getHeight(), BufferedImage.TYPE_INT_ARGB);
            moniter.createGraphics().drawImage(moni, 0, 0, null);
            for (int x = 0; x < moniter.getWidth(); x++) {
                for (int y = 0; y < moniter.getHeight(); y++) {
                    Color grab = new Color(moniter.getRGB(x, y));
                    if (grab.getBlue() == 0 && grab.getGreen() == 0 && grab.getRed() == 0) {
                        moniter.setRGB(x, y, 0x0);
                    }
                }
            }
        } catch (Exception e) {
        }
        enableEvents(AWTEvent.FOCUS_EVENT_MASK);
        setFocusTraversalKeysEnabled(false);
        setRequestFocusEnabled(true);
    }

    public int[] getPixel(int x, int y) {
        return raster.getPixel(x, y, pixels);
    }

    public int putRGB(int red, int green, int blue) {
        return (red << 16) | (green << 8) | blue;
    }

    protected void getRGB(int value, int[] rgb) {
        rgb[0] = (value >> 16) & 0x0ff;
        rgb[1] = (value >> 8) & 0x0ff;
        rgb[2] = (value) & 0x0ff;
    }
    double div = 1.5;
    int off;
    int splitrgb;
    int[] rgb = {0, 0, 0};
    boolean frame;
    AnimatedGifEncoder enc;
    public boolean isgifrecording = false;

    public void startRec() {
        if (isgifrecording) {
            return;
        }
        isgifrecording = true;
    }
    BufferedImage gimage;
    int gifdelay = 0;
    Thread invoker;

    public void addFrame() {
        if (!isgifrecording) {
            return;
        }
        invoker = new Thread() {
            public void run() {
                enc = new AnimatedGifEncoder();
                enc.start("output.gif");
                enc.setRepeat(0);
                enc.setTransparent(null);
                enc.setDelay(125);
                while (isgifrecording) {
                    if (gimage == null) {
                        gimage = new BufferedImage(384, GateArray.lowlines, BufferedImage.TYPE_INT_RGB);
                    }
                    gifdelay++;
                    if (gifdelay == 3) {
                        gimage.createGraphics().drawImage(image, 0, 0, 384, 280, null);
                        enc.addFrame(gimage);
                        gifdelay = 0;
                    }
                    try {
                        Thread.sleep(25);
                    } catch (Exception e) {
                    }
                }
            }
        };
        invoker.start();
    }

    public void stopRec() {
        if (!isgifrecording) {
            return;
        }
        isgifrecording = false;
        giffing = false;
        while (invoker.isAlive()) {
            try {
                Thread.sleep(1);
            } catch (Exception e) {
            }
        }
        enc.finish();
    }
    public int lowlines = GateArray.lowlines;
    public int highlines = lowlines * 2;

    protected void CRTFilter() {
        try {
            Thread.yield();
        } catch (Exception e) {
        }
        splitrgb = 0;
        off = 0;
//        frame = !frame;
        for (int y = 0; y < lowlines; y++) {
            for (int x = 0; x < 768; x++) {
                if (y % 2 == (frame ? 1 : 0)) {
                    splitrgb = (splitrgb == 0 ? 1 : 0);
                } else {
                    splitrgb = (splitrgb == 2 ? 3 : 2);
                }
                getRGB(pixels[off], rgb);
                switch (splitrgb) {
                    case 0:
                        pixels[off] = putRGB(rgb[0], (int) (rgb[1] / div), (int) (rgb[2] / div));
                        break;
                    case 1:
                        pixels[off] = putRGB((int) (rgb[0] / div), rgb[1], (int) (rgb[2] / div));
                        break;
                    case 2:
                        pixels[off] = putRGB((int) (rgb[0] / div), (int) (rgb[1] / div), rgb[2]);
                        break;
                    case 3:
                        int r = (int) (rgb[0] * div);
                        int g = (int) (rgb[1] * div);
                        int b = (int) (rgb[2] * div);
                        if (r > 255) {
                            r = 255;
                        }
                        if (g > 255) {
                            g = 255;
                        }
                        if (b > 255) {
                            b = 255;
                        }
                        pixels[off] = putRGB(r, g, b);
                        break;
                }
                off++;
            }
        }
        if (leftside != null && fullscreen) {
            splitrgb = 0;
            for (off = 0; off < leftpixels.length; off++) {
                leftpixels[off] = (0);
            }
            for (off = 0; off < rightpixels.length; off++) {
                rightpixels[off] = (0);
            }
        }
    }

    public void setImageSize(Dimension size, Dimension scale) {
        imageWidth = size.width;
        imageHeight = size.height;
        image = new BufferedImage(imageWidth, imageHeight, BufferedImage.TYPE_INT_RGB);
        image.setAccelerationPriority(1);
        raster = image.getRaster();
        pixels = new int[768 * lowlines];
        for (int i = 0; i < pixels.length; i++) {
            pixels[i] = 0xff000000;
        }
        if (scale == null) {
            scale = SCALE_1;
        }
        scaleWidth = imageWidth * scale.width;
        scaleHeight = imageHeight * scale.height;
        checkSize();
        Graphics g = getGraphics();
        if (g != null) {
            size = getSize();
            g.setColor(getBackground());
            g.fillRect(0, 0, size.width, size.height);
            paint(g);
            g.dispose();
        }
    }

    public void setBounds(int x, int y, int width, int height) {
        super.setBounds(x, y, width, height);
        checkSize();
    }

    protected void checkSize() {
        Dimension size = getSize();
        Insets insets = getInsets();
        int clientWidth = size.width - insets.left - insets.right;
        int clientHeight = size.height - insets.top - insets.bottom;
        imageRect = new Rectangle(insets.left + (clientWidth - scaleWidth) / 2,
                insets.top + (clientHeight - scaleHeight) / 2, scaleWidth, scaleHeight);

    }
    public boolean turbo;

    public int[] getPixels() {
        return pixels;
    }
    BufferedImage output;
    int width;
    public BufferedImage leftside, rightside;
    public int[] leftpixels, rightpixels;
    public JPanel left;
    public JPanel right;
    public boolean drawborder = false;
    protected boolean borderinit = false;
    int fpstimer = 0;
    int errorhit = 0;
    int errortimer = 0;
    int lx, ly;

    public void updateLightpen(int x, int y) {
        lx = x;
        ly = y;
    }

    public void updateImage(boolean wait) {
//        dp.setPixels(pixels);
//        dp.updateDisplay();
        checkSize();
//        if (DEBUG_FPS) {
        doTouchFPS();
        if (mCurrFPS < 20 && !GateArray.cpc.doTurbo && !large) {
            fpstimer++;
            if (fpstimer > 30) {
                fpstimer = 0;
                errorhit++;
                if (errorhit < 10) {
                    GateArray.cpc.reSync();
                    System.out.println("Slow Performance: " + mCurrFPS + "fps - Adjusting");
                }
            }
        } else {
            errortimer++;
            if (errortimer > 150) {
                errorhit = 0;
            }
            fpstimer = 0;
        }

//        }
        int off = 0;
        int lastPix = 0;
        if (fullscreen && leftside != null && drawborder) {
            if (!borderinit) {
                leftraster = leftside.getRaster();
                rightraster = rightside.getRaster();
                borderinit = true;
            }
            int pipos = 0;
            int prpos = 0;
            int pval = GateArray.cpc.getGateArray().getBorder();
            for (int i = 0; i < lowlines; i++) {
                for (int k = 0; k < leftside.getWidth(); k++) {
                    leftpixels[pipos++] = pval;//pixels[(leftside.getWidth()-k)+(i*768)];
                }
                for (int k = 0; k < rightside.getWidth(); k++) {
                    rightpixels[prpos++] = pval;//pixels[(767-k)+(i*768)];
                }
            }
        }
        if (scanlines) {
            CRTFilter();
            for (int y = 0; y < imageHeight - 1; y++) {
                off = y * imageWidth;
                for (int x = 0; x < imageWidth; x++) {
                    off++;
                    try {
                        lastPix = pixels[off] = ((lastPix & 0xFEFEFE) + (pixels[off] & 0xFEFEFE)) >> 1;
                    } catch (Exception e) {
                    }
                }
            }
        }
        if (fullscreen && leftside != null && drawborder) {
            Graphics l = left.getGraphics();
            Graphics r = right.getGraphics();
            leftraster.setDataElements(0, 0, leftside.getWidth(), leftside.getHeight(), leftpixels);
            rightraster.setDataElements(0, 0, rightside.getWidth(), rightside.getHeight(), rightpixels);
            Graphics2D l2 = (Graphics2D) l;
            l2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            l = l2;
            Graphics2D r2 = (Graphics2D) r;
            r2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            r = r2;
            l.drawImage(leftside, 0, 0, left.getWidth(), left.getHeight(), null);
            r.drawImage(rightside, 0, 0, right.getWidth(), right.getHeight(), null);
        }
//            for (int x = 0; x < imageWidth; x++) {
//                off = x;
//                for (int y = 0; y < imageHeight; y +=2) {
//                    try{
//                    pixels[off + imageWidth] = (pixels[off] & 0xFEFEFE) >> 1;
//                    } catch (Exception e){}
//                    off += imageWidth * 2;
//                }
//            }
        if (imageRect.width != 0 && imageRect.height != 0 && isShowing()) {
            raster.setDataElements(0, 0, imageWidth, imageHeight, pixels);
            if (logopos < 300) {
                image.createGraphics().drawImage(logo, 0, logopos, image.getWidth(), image.getHeight(), this);
                logotimer++;
                if (logotimer > 100) {
                    logopos += 2;
                }
            }
            repaint(0, 0, this.getWidth(), this.getHeight());
        }
        if (wait || isgifrecording) {
            waitPainted();
        }
        if (isgifrecording && !giffing) {
            giffing = true;
            this.addFrame();
        }
    }
    boolean giffing = false;
    int logotimer = 0;
    int logopos = 0;
    public boolean penonscreen;

    public void waitPainted() {
        while (!painted) {
            Thread.yield();
        }
    }
    int a = 0;
    int b = 0;
    int c = 0;
    JFrame spriteframe;
    BufferedImage sprites;
    JLabel spritelabel;
    JFrame spriteframe2;
    BufferedImage sprites2;
    JLabel spritelabel2;
    BufferedImage trans;
    Font fontlarge = new Font("", 1, 11);
    Font fontsmall = new Font("", 1, 8);

    public void showSprites() {
        int[] result = GateArray.cpc.getGateArray().getField();
        if (spriteframe == null) {
            sprites = new BufferedImage(640, 400, BufferedImage.TYPE_INT_RGB);
            spriteframe = new JFrame("Sprites");
            spritelabel = new JLabel();
            spritelabel.setIcon(new ImageIcon(sprites));
            spriteframe.setResizable(false);
            spriteframe.setLayout(new BorderLayout());
            spriteframe.add(spritelabel, BorderLayout.CENTER);
            spriteframe.pack();
            spriteframe.setVisible(true);
        }
        Graphics g = sprites.getGraphics();
        g.setColor(new Color(20, 60, 128));
        g.fillRect(0, 0, 768, highlines);
        g.setFont(large ? fontlarge : fontsmall);
        String f = "";
        try {
            int xpos = 0;
            for (int i = 7; i >= 0; i--) {
                if (GateArray.cpc.getGateArray().ym[i] != 0 && GateArray.cpc.getGateArray().xm[i] != 0) {
                    GateArray.cpc.memory.putSpriteImg(i);
                    g.setColor(Color.white);
                    g.drawRect(4 + xpos, 19, (16 * GateArray.cpc.getGateArray().xm[i]) + 1, 1 + (32 * GateArray.cpc.getGateArray().ym[i]));
                    g.drawImage(GateArray.cpc.memory.spriteImg[i], 5 + (xpos), 20, this);
                    f = GateArray.cpc.memory.getSpriteX(i) + "," + GateArray.cpc.memory.getSpriteY(i);
                    g.drawString(f, 4 + xpos, 30 + (32 * GateArray.cpc.getGateArray().ym[i]));
                    xpos += 8 + 18 * GateArray.cpc.getGateArray().xm[i];
                }
            }
            xpos = 0;
            for (int i = 15; i > 7; i--) {
                if (GateArray.cpc.getGateArray().ym[i] != 0 && GateArray.cpc.getGateArray().xm[i] != 0) {
                    GateArray.cpc.memory.putSpriteImg(i);
                    g.setColor(Color.white);
                    f = GateArray.cpc.memory.getSpriteX(i) + "," + GateArray.cpc.memory.getSpriteY(i);
                    g.drawString(f, 4 + xpos, 210 + (32 * GateArray.cpc.getGateArray().ym[i]));
                    xpos += 8 + 18 * GateArray.cpc.getGateArray().xm[i];
                }
            }
            spritelabel.setIcon(new ImageIcon(sprites));
        } catch (Exception e) {
        }
        drawSprites();
    }
    Graphics g2;
    BufferedImage sprites3;

    public void drawSprites() {
        int[] result = GateArray.cpc.getGateArray().getField();
        if (spriteframe2 == null) {
            sprites2 = new BufferedImage(768, highlines, BufferedImage.TYPE_INT_RGB);
            sprites3 = new BufferedImage(768, lowlines, BufferedImage.TYPE_INT_ARGB);
            praster = sprites3.getRaster();
            trans = new BufferedImage(16, 16, BufferedImage.TYPE_INT_RGB);
            Graphics d = trans.createGraphics();
            d.setColor(Color.white);
            d.fillRect(0, 0, 8, 8);
            d.fillRect(8, 8, 8, 8);
            d.setColor(Color.lightGray);
            d.fillRect(8, 0, 8, 8);
            d.fillRect(0, 8, 8, 8);
            spriteframe2 = new JFrame("Sprites");
            spritelabel2 = new JLabel();
            spritelabel2.setIcon(new ImageIcon(sprites2));
            spriteframe2.setResizable(false);
            spriteframe2.setLayout(new BorderLayout());
            spriteframe2.add(spritelabel2, BorderLayout.CENTER);
            spriteframe2.pack();
            spriteframe2.setVisible(true);
            g2 = sprites2.getGraphics();
        }
        for (int x = 0; x < 800; x += 16) {
            for (int y = 0; y < 600; y += 16) {
                g2.drawImage(trans, x, y, this);
            }
        }
        Color b = new Color(pixels[0]);
        g2.setColor(new Color(b.getRed(), b.getGreen(), b.getBlue(), 128));
        g2.fillRect(result[0], result[2], GateArray.cpc.getGateArray().crtc.getRegisterValue(1) * 16, GateArray.cpc.getGateArray().crtc.getRegisterValue(6) * 16);

        try {

            praster.setDataElements(0, 0, imageWidth, imageHeight, ppixels);
            sprites2.getGraphics().drawImage(sprites3, 0, 0, 768, highlines, this);
            spritelabel2.getGraphics().drawImage(sprites2, 0, 0, 768, highlines, this);
        } catch (Exception e) {
        }
    }
    public static String[] carts = {
        "Barbarian II",
        "Batman",
        "Burnin' Rubber",
        "Copter 271",
        "Crazy Cars II",
        "Dick Tracy",
        "Epyx World Of Sports",
        "Fire And Forget II",
        "Klax",
        "Mystical",
        "Navy Seals",
        "No Exit",
        "Operation Thunderbolt",
        "Pang",
        "Panza Kickboxing",
        "Plotting",
        "Pro Tennis Tour",
        "Robocop II",
        "Skeet Shoot",
        "Super Pinball Magic",
        "Switchblade",
        "Tennis Cup II",
        "The Enforcer",
        "Tintin On The Moon",
        "Wildstreets",
        "CPC Plus System"
    };
    public int ppixels[] = new int[768 * lowlines];
    public boolean fullscreen = false;

    public void setFullscreen(boolean full) {
        fullscreen = full;
    }
    final URL cursorl = getClass().getResource("Pen-icon.png");
    final Image lightPen = getToolkit().getImage(cursorl);
    Font font2large = new Font("", 1, 16);
    Font font2small = new Font("", 1, 10);

    protected void paintImage(Graphics g) {
        //   if (started){
        if (scanlines || !large || fullscreen) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g = g2;
        }
        g.setFont(large ? font2large : font2small);
        if (fullscreen) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g = g2;
            if (scanlines) {
                image.createGraphics().drawImage(Dist, 0, 0, 768, lowlines, this);
            }
            g.drawImage(image, 0, 0, this.getWidth(), this.getHeight(), this);
            if (penonscreen) {
                g.drawImage(lightPen, lx + 8, ly + 8, 256, 256, null);
            }
            if (turbo) {
                g.setColor(LED_ON);
                g.fillRect(4 * divider, 3 * divider, 7 * divider, 3 * divider);
                g.setColor(LED_BORDER);
                g.drawString("x" + CPC.turbospeed, 4 * divider, 15 * divider);
                g.drawRect(3 * divider, 2 * divider, 8 * divider, 4 * divider);
                g.setColor(LED_ON);
                g.drawString("x" + CPC.turbospeed, 3 * divider, 14 * divider);
            }
            if (showdisks && showtime > 1) {
                g.drawImage(Disc, 24 * divider, 3 * divider, divider != 1 ? 26 : 13, divider != 1 ? 32 : 16, null);
                g.drawImage(Disc, 40 * divider, 3 * divider, divider != 1 ? 26 : 13, divider != 1 ? 32 : 16, null);
                showtime--;
            }
            return;
        }
        if (drawmonitor) {
            g.drawImage(image, large ? 60 : 30, large ? 80 : 40, large ? 768 : 384, large ? highlines : lowlines, null);
        } else {
            g.drawImage(image, 0, 0, large ? 768 : 384, large ? highlines : lowlines, null);
        }



        if (DEBUG_SCREEN) {
            int[] result = GateArray.cpc.getGateArray().getField();
            g.setColor(new Color(255, 255, 255, 0x60));
            g.fillRect(0, 0, large ? 768 : 384, large ? result[2] : result[2] / 2);
            g.fillRect(0, 0, large ? result[0] : result[0] / 2, large ? highlines : lowlines);
            g.fillRect(0, large ? result[3] : result[3] / 2, large ? 768 : 384, large ? highlines : lowlines);
            g.fillRect(large ? result[1] : result[1] / 2, 0, large ? result[1] : result[1] / 2, large ? highlines : lowlines);
//            g.drawImage(masks, result[0] / (large ? 1 : 2), result[2] / (large ? 1 : 2), GateArray.cpc.getGateArray().crtc.getRegisterValue(1) * (large ? 16 : 8), GateArray.cpc.getGateArray().crtc.getRegisterValue(6) * (large ? 16 : 8), this);
        }
        if (DEBUG_SPRITES) {
            showSprites();
        }

//        g.drawLine(result[0],result[2],result[1]-1,result[2]);
//        g.drawLine(result[0],result[3]-1,result[1]-1,result[3]-1);
//        g.drawLine(result[0],result[2],result[0],result[3]-1);
//        g.drawLine(result[1]-1,result[2],result[1]-1,result[3]-1);

//
        if (scanlines && drawmonitor) {
//            if (large)
            g.setColor(large ? SCAN : SCANL);
            for (int i = 0; i < imageRect.height; i += 2) {
                g.drawLine(large ? 60 : 30, (large ? 80 : 40) + i, large ? 828 : 414, (large ? 80 : 40) + i);
            }
            g.drawImage(Dist, large ? 60 : 30, large ? 80 : 40, large ? 768 : 384, large ? highlines : lowlines, this);
        }
        if (scanlines && !drawmonitor) {
//            if (large)
            g.setColor(large ? SCAN : SCANL);
            for (int i = 0; i < imageRect.height; i += 2) {
                g.drawLine(0, i, large ? 768 : 384, i);
            }
            g.drawImage(Dist, 0, 0, large ? 768 : 384, large ? highlines : lowlines, this);
        }
        if (storesna > 0) {
            g.setColor(LED_ON);
            restoresna = 0;
            crtc = 0;
            g.drawString(snaps, large ? 40 : 20, large ? 20 : 10);
            storesna--;
        }
        if (restoresna > 0) {
            crtc = 0;
            storesna = 0;
            g.setColor(Color.GREEN);
            g.drawString(snapl, large ? 40 : 20, large ? 20 : 10);
            restoresna--;
        }
        if (crtc > 0) {
            storesna = 0;
            restoresna = 0;
            g.setColor(Color.yellow);
            g.drawString(crtctype + Basic6845.CRTC + crtctype2, large ? 40 : 20, large ? 20 : 10);
            crtc--;
        }
        if (GateArray.cpc.saveallowed && GateArray.cpc.storing() != 0) {
            g.setColor(Color.red);
            g.drawRect(0, 0, large ? 767 : 383, large ? 543 : 271);
            g.drawRect(1, 1, large ? 765 : 381, large ? 541 : 269);
        }
        if (shootme) {
            java.io.File fil = new java.io.File("shots");
            if (!fil.exists()) {
                fil.mkdir();
            }
            try {
                javax.imageio.ImageIO.write(image, "PNG", new java.io.File("shots/" + impos++ + ".png"));
            } catch (Exception e) {
            }
        }
        if (menumode || menupos > -300) {
            if (large) {
                menumode = false;
                menupos = -300;
                int pos = 100 + menupos;
                for (int i = 0; i < carts.length - 11; i++) {
                    g.setColor(new Color(0, 0, 0x80, 0x60));
                    g.fillRect(190, pos, 230, 32);
                    g.drawImage(Cart, 200, pos, this);
                    g.setColor(Color.white);
                    g.drawString(carts[i], 238, pos + 20);
                    g.drawString(carts[i], 239, pos + 20);
                    pos += 32;
                }
                pos = 100 + menupos;
                for (int i = carts.length - 11; i < carts.length; i++) {
                    g.setColor(new Color(0, 0, 0x80, 0x60));
                    g.fillRect(490, pos, 230, 32);
                    g.drawImage(Cart, 500, pos, this);
                    g.setColor(Color.white);
                    g.drawString(carts[i], 538, pos + 20);
                    g.drawString(carts[i], 539, pos + 20);
                    pos += 32;
                }
            } else {
                int pos = 50 + menupos;
                int d = 20;
                for (int i = 0; i < carts.length - 11; i++) {
                    g.setColor(new Color(255 - d, 255 - d, 55, 255));
                    g.drawRect(95, pos, 135, 16);
                    g.setColor(new Color(d, d / 2, 200, 0x80));
                    g.fillRect(95, pos, 136, 16);
                    g.drawImage(Cart, 100, pos, 16, 16, this);
                    g.setColor(Color.white);
                    g.drawString(carts[i], 119, pos + 10);
                    g.drawString(carts[i], 120, pos + 10);
                    pos += 16;
                    d += 12;
                }
                pos = 50 + menupos;
                d = 20;
                for (int i = carts.length - 11; i < carts.length; i++) {
                    g.setColor(new Color(255 - d, 255 - d, 55, 255));
                    g.drawRect(245, pos, 135, 16);
                    g.setColor(new Color(d, d / 2, 200, 0x80));
                    g.fillRect(245, pos, 136, 16);
                    g.drawImage(Cart, 250, pos, 16, 16, this);
                    g.setColor(Color.white);
                    g.drawString(carts[i], 269, pos + 10);
                    g.drawString(carts[i], 268, pos + 10);
                    pos += 16;
                    d += 12;
                }
            }
            if (menumode) {
                if (menupos < 0) {
                    menupos += 4;
                }
            } else {
                menupos -= 4;
            }
        }
        if (penonscreen) {
            g.drawImage(lightPen, lx + (large ? 8 : 4), ly + (large ? 8 : 4), (large ? 128 : 64), (large ? 128 : 64), null);
        }
        if (drawmonitor) {
            g.drawImage(moniter, 0, 0, large ? 880 : 440, large ? 730 : 365, this);
        }
        if (DEBUG_FPS) {
            g.setColor(Color.red);
            g.drawString("FPS: " + mCurrFPS, 4, getHeight() - (large ? 5 : 10));
        }
        if (DEBUG_SPRITES) {
            for (int i = 0; i < 16; i++) {
                if (GateArray.cpc.getGateArray().xm[i] != 0 && GateArray.cpc.getGateArray().ym[i] != 0) {
                    g.setColor(Color.white);
                    g.drawRect(spx[i], spy[i], spw[i], sph[i]);
                    g.setColor(Color.white);
                    g.drawString("" + (i + 1), spx[i] + 2, spy[i] + 16);
                }

            }
        }
        if (!large) {
            if (ledOn) {
                g.setColor(fLED_ON);
            } else {
                g.setColor(fLED_OFF);
            }
            g.fillRect(40, 340, 8, 4);
            g.setColor(fLED_BORDER);
            g.drawRect(39, 339, 9, 5);
        } else {
            if (ledOn) {
                g.drawImage(Disc, 360 * divider, 3 * divider, this);
            }
        }
        if (turbo) {
            g.setColor(LED_ON);
            g.fillRect(4 * divider, 3 * divider, 7 * divider, 3 * divider);
            g.setColor(LED_BORDER);
            g.drawString("x" + CPC.turbospeed, 4 * divider, 15 * divider);
            g.drawRect(3 * divider, 2 * divider, 8 * divider, 4 * divider);
            g.setColor(LED_ON);
            g.drawString("x" + CPC.turbospeed, 3 * divider, 14 * divider);
        }
        if (showdisks && showtime > 1) {
            g.drawImage(Disc, 24 * divider, 3 * divider, divider != 1 ? 26 : 13, divider != 1 ? 32 : 16, null);
            g.drawImage(Disc, 40 * divider, 3 * divider, divider != 1 ? 26 : 13, divider != 1 ? 32 : 16, null);
            showtime--;
        }
//            g.setColor(Color.GREEN);
//            g.drawString(vscroll, 10, 24);
    }
    public static int showtime = 0;
    int menupos = -300;
    public boolean menumode;
    public boolean shootme = false;
    int impos = 0;
    int lpos = 550;
    int lw = 0;
    String info = "";
    int spx[] = new int[16], spy[] = new int[16], spw[] = new int[16], sph[] = new int[16];
    boolean oldfull;
    int timer;

    public void repaint() {
        //Display needs no repaint, it causes flickering, so lets remove it
    }

    public void setspri(int index, int x, int y, int w, int h) {
        spx[index] = x;
        spy[index] = y * 2;
        spw[index] = w;
        sph[index] = h * 2;
    }

    public void paintComponent(Graphics g) {
        painted = false;
        if (image != null) {
            started = true;
            paintImage(g);
        }
        painted = true;
    }
    private boolean started = false;

    public Dimension getPreferredSize() {
        if (drawmonitor) {
            if (large) {
                return new Dimension(880, 730);
            } else {
                return new Dimension(440, 365);
            }
        }
        if (large) {
            return new Dimension(768, highlines);
        } else {
            return new Dimension(384, lowlines);
        }
    }

    public Dimension getSize() {
        if (drawmonitor) {
            if (large) {
                return new Dimension(880, 730);
            } else {
                return new Dimension(440, 365);
            }
        }
        if (large) {
            return new Dimension(768, highlines);
        } else {
            return new Dimension(384, lowlines);
        }
    }
}
