package JCPC.ui;

import JCPC.core.*;
import JCPC.core.device.*;
import JCPC.core.device.floppy.*;
import JCPC.core.device.sound.JavaSound;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import JCPC.core.device.crtc.Basic6845;
import JCPC.system.cpc.CPC;
import JCPC.system.cpc.GateArray;
import JCPC.system.cpc.Samples;
import java.awt.image.BufferedImage;

/**
 * Title: GX4000 Description: Amstrad GX4000/CPC+ Emulator Copyright: Copyright
 * (c) 2013 Company: cpc-live.com
 *
 * @author Markus, Richard
 * @version 1.5
 */
public class GX4000 extends Applet implements ItemListener, ActionListener, KeyListener,
        FocusListener, Runnable, MouseListener, MouseMotionListener {

    GX4000Menu menu;

    public void showDebugger() {
        try {
            System.out.println("showDebugger");
            if (debug == null) {
                debug = (Debugger) Util.secureConstructor(Debugger.class,
                        new Class[]{}, new Object[]{});
                debug.setBounds(0, 0, 640, 450);
                debug.setComputer(computer);
            }
            System.out.println("Showing Debugger");
            debug.setVisible(true);
            debug.toFront();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    protected Debugger debug = null;

    public void actionPerformed(ActionEvent e) {
        if (menu != null) {
            if (e.getSource() == menu.jMenuItem1) {
                load();
            }
            if (e.getSource() == menu.jMenuItem2) {
                computer.openCPR();
            }
            if (e.getSource() == menu.jMenuItem3) {
                controller.setVisible(true);
            }
            if (e.getSource() == menu.jMenuItem5) {
                GateArray.cpc.checkCSD();
            }
            if (e.getSource() == menu.jMenuItem7) {
                resetComputer();
            }
            if (e.getSource() == menu.jMenuItem8) {
                showDebugger();
            }
        }
    }
    boolean gifrec = false;

    public void itemStateChanged(ItemEvent e) {
        if (menu != null) {
            if (menu.jCheckBoxMenuItem1 == e.getSource()) {
                display.DEBUG_FPS = menu.jCheckBoxMenuItem1.getState();
            }
            if (menu.jCheckBoxMenuItem4 == e.getSource()) {
                if (menu.jCheckBoxMenuItem4.isSelected()) {
                    if (!gifrec) {
                        display.startRec();
                        gifrec = true;
                    }
                } else {
                    if (gifrec) {
                        display.stopRec();
                        gifrec = false;
                    }
                }
            }
            if (menu.jCheckBoxMenuItem2 == e.getSource()) {
                this.setFullSize(menu.jCheckBoxMenuItem2.getState());
                System.out.println("Changing display to " + (large ? "large size" : "small size"));
                try {
                    Thread.sleep(100);
                } catch (Exception er) {
                }
                display.setPreferredSize(display.getPreferredSize());
                display.setSize(display.getPreferredSize());
                try {
                    Thread.sleep(100);
                } catch (Exception er) {
                }
                frame.pack();
                Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
                frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
            }
            if (menu.jCheckBoxMenuItem3 == e.getSource()) {
                keepmonitor = menu.jCheckBoxMenuItem3.getState();
                if (keepmonitor) {
                    menu.jCheckBoxMenuItem2.setSelected(false);
                }
                this.setFullSize(menu.jCheckBoxMenuItem2.getState());
                System.out.println("Changing display to " + (large ? "large size" : "small size"));
                try {
                    Thread.sleep(100);
                } catch (Exception er) {
                }
                display.setPreferredSize(display.getPreferredSize());
                display.setSize(display.getPreferredSize());
                try {
                    Thread.sleep(100);
                } catch (Exception er) {
                }
                frame.pack();
                Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
                frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
            }
        }
        if (e.getSource() == controller.trojan) {
            this.setLightgun(controller.trojan.isSelected());
        }
        if (e.getSource() == controller.cart) {
            GateArray.cpc.loadCart(controller.cart.getSelectedIndex());
        }
    }
//        g.setColor(Color.gray);
//        g.fillRect(720, 706, 60, 20);
    boolean menupossible = false;
    boolean penonscreen = false;

    public void mouseMoved(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        if (y < 50 && display.showdisks) {
            display.showtime = 50;
        }
        display.updateLightpen(x, y);
        if (lightpen) {
            if (display.fullscreen) {
                double xx = (double) (768) / (double) display.getWidth();
                double yy = (double) (544) / (double) display.getHeight();
                x = (int) ((double) x * xx);
                y = (int) ((double) y * yy);
            }
            GateArray.cpc.getCRTC().setLightpen(x, y, display.large, display.fullscreen, penonscreen);
        }
        if (large) {
            if ((e.getX() > 720 && e.getX() < 780 && e.getY() > 706 && e.getY() < 726)) {
                display.setCursor(new Cursor(Cursor.HAND_CURSOR));
                menupossible = true;
            } else if (display.menumode && e.getX() > basex && e.getX() < basexmax && e.getY() > 100 && e.getY() < 580) {
                display.setCursor(new Cursor(Cursor.HAND_CURSOR));
            } else if (display.menumode && e.getX() > basex + 300 && e.getX() < basexmax + 300 && e.getY() > 100 && e.getY() < 450) {
                display.setCursor(new Cursor(Cursor.HAND_CURSOR));
            } else {
                menupossible = false;
                if (!lightpen) {
                    display.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                } else {
                    display.setCursor(penonscreen ? pen : gun);
                }
            }
        } else {
            if ((e.getX() > 360 && e.getX() < 390 && e.getY() > 353 && e.getY() < 363)) {
                display.setCursor(new Cursor(Cursor.HAND_CURSOR));
                menupossible = true;
            } else if (display.menumode && e.getX() > 100 && e.getX() < 220 && e.getY() > 50 && e.getY() < 290) {
                display.setCursor(new Cursor(Cursor.HAND_CURSOR));
            } else if (display.menumode && e.getX() > 250 && e.getX() < 370 && e.getY() > 50 && e.getY() < 225) {
                display.setCursor(new Cursor(Cursor.HAND_CURSOR));
            } else {
                menupossible = false;
                if (!lightpen) {
                    display.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                } else {
                    display.setCursor(penonscreen ? pen : gun);
                }
            }
        }
    }

    public void mouseDragged(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        display.updateLightpen(x, y);
        if (lightpen) {
            if (display.fullscreen) {
                double xx = (double) (768) / (double) display.getWidth();
                double yy = (double) (544) / (double) display.getHeight();
                x = (int) ((double) x * xx);
                y = (int) ((double) y * yy);
            }
            GateArray.cpc.getCRTC().setLightpen(x, y, display.large, display.fullscreen, true);
        }
    }
    protected static boolean developer = false;
    protected boolean URL = false;
    String CRTC = "3";
    boolean alt = false;
    int multiload = 0;
    String cartridge = "none";
    String load = "none";
    String loadb = "none";
    String sna = "none";
    protected Computer computer = null;
    Locale loc;
    String localkeys = "";
    public static boolean isStandalone = false;
    protected Display display = new Display();
    protected boolean started = false;
    protected boolean large = false;

    public String getParameter(String key, String def) {
        return isStandalone ? System.getProperty(key, def) : (getParameter(key) != null ? getParameter(key) : def);
    }

    public GX4000() {
        enableEvents(AWTEvent.KEY_EVENT_MASK);
    }

    public void init() {
        localkeys = getLocale().toString().toUpperCase();
        display.requestFocus();
    }

    public void init(Locale loc) {
        localkeys = loc.toString().toUpperCase();
        display.requestFocus();
    }
    String disk1 = "";
    String disk2 = "";

    public void startEngine() {
        try {
            controller = new Controller();
            fram = 0;
            disk2 = "";
            setLayout(new BorderLayout());
            CPC.cartindex = Integer.parseInt(getParameter("GAME", "25"));
            if (CPC.cartindex > 25 || CPC.cartindex < 0) {
                CPC.cartindex = 2;
            }
            large = Util.getBoolean(getParameter("LARGE", "true"));
            Display.scanlines = Util.getBoolean(getParameter("FILTER", "false"));
            Display.drawmonitor = Util.getBoolean(getParameter("GUI", "false"));
            keepmonitor = Display.drawmonitor;

            controller.trojan.addItemListener(this);
            controller.cart.setModel(new javax.swing.DefaultComboBoxModel(Display.carts));
            controller.cart.setSelectedIndex(CPC.cartindex);
            controller.cart.addItemListener(this);
            String url = getParameter("URL", "false");
            url = url.toUpperCase();
            if (url.equals("TRUE")) {
                URL = true;
            }
            String csd = getParameter("CSD", "false");
            csd = csd.toUpperCase();
            CPC.CSD = false;
            if (csd.equals("TRUE")) {
                CPC.CSD = true;
            }
            String type = getParameter("AUTOTYPE", null);
            String boot = getParameter("BOOT", null);
            CRTC = "3";
            CRTC = getParameter("CRTC", CRTC);
//            System.out.println("CRTC choosen : " + CRTC);
            if (CRTC.startsWith(("1"))) {
                CRTC = "1";
            }
            if (CRTC.startsWith(("3"))) {
                CRTC = "3";
            }
            if (CRTC.startsWith(("0"))) {
                CRTC = "0";
            }
            Basic6845.CRTC = Integer.parseInt(CRTC);
            cartridge = getParameter("CPR", "internal");
            if (CPC.CSD) {
                cartridge = "none";
            }
            if (cartridge.equals("internal")) {
                cartridge = "none";
                CPC.internal = true;
            }
            load = getParameter("SNA", "none");
            sna = load;
            load = getParameter("DISK", load);
            if (load.startsWith("$")) {
                load = "none";
            }
            loadb = getParameter("DISKB", loadb);
            if (loadb.startsWith("$")) {
                loadb = "none";
            }
            disk2 = getParameter("DISK2", "");
            if (disk2.startsWith("$")) {
                disk2 = "";
            }
            Display.showdisks = false;
            if (disk2.length() > 1) {
                disk1 = load;
                Display.showdisks = true;
                Display.showtime = 150;
            }
            display.large = large;
            setComputer("CPCPLUS", true);
            if (large) {
                display.setSize(768, display.highlines);
                display.divider = 2;
            } else {
                display.setSize(384, display.lowlines);
            }
            add(display, BorderLayout.CENTER);
            display.setDoubleBuffered(true);
            display.setBackground(Color.black);
            display.addKeyListener(this);
            display.addMouseListener(this);
            display.addMouseMotionListener(this);
            display.addFocusListener(this);
            started = true;
            if (type != null) {
                computer.prepareAutotype(type);
            }
            if (boot != null) {
                if (boot.contains("/")) {
                    boot = boot.replace("/", "\"");
                    computer.prepareAutotype(boot);
                } else if (boot.equals("tape")) {
                    computer.prepareAutotype("|TAPE:RUN\"!\"");
                } else if (boot.startsWith("|")) {
                    computer.prepareAutotype(boot);
                } else {
                    computer.prepareAutotype("RUN\"" + boot + "\"");
                }
            }
            this.setLightgun(Util.getBoolean(getParameter("LIGHTGUN", "false")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (!cartridge.equals("none")) {
            loadFile(Computer.TYPE_DISC_IMAGE, cartridge, true);
        }
        if (!load.equals("none") && sna.equals("none")) {
            loadFile(Computer.TYPE_DISC_IMAGE, load, true);
        }
        if (load.equals("none") && !sna.equals("none")) {
            loadit = 1;
        }
        if (!load.equals("none") && !sna.equals("none")) {
            multiload = 1;
        }
        if (!loadb.equals("none")) {
            computer.setCurrentDrive(1);
            loadFile(Computer.TYPE_DISC_IMAGE, loadb, true);
        }
        computer.setCurrentDrive(0);
        if (frame != null) {
            frame.pack();
            Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
            frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
        }
        fireUpdate.start();
        display.requestFocus();
        display.DEBUG_SPRITES = Util.getBoolean(getParameter("SPRITES", display.DEBUG_SPRITES ? "true" : "false"));
        display.DEBUG_SCREEN = Util.getBoolean(getParameter("SCREEN", display.DEBUG_SCREEN ? "true" : "false"));
    }
    protected int loadit = 0;

    public void start() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
        }
        startEngine();
    }

    public boolean isStarted() {
        return started;
    }

    public void waitStart() {
        try {
            while (!started) {
                Thread.sleep(10);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void run() {
    }

    public void stop() {
        GateArray.cpc.reset();
        GateArray.cpc.getPSG().resetRegisters();
        computer.stop();
    }
    ActionListener update = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            update();
        }
    };
    javax.swing.Timer fireUpdate = new javax.swing.Timer(50, update);
    int fram = 0;
    int ktick;
    boolean pressed;
    int keypresser = 0;
    boolean kpress;
    boolean ispress;

    public void update() {
        if (keypresser != 0) {
            if (kpress) {
                computer.keyReleased(KeyEvent.VK_NUMPAD4);
                ispress = true;
            } else {
                computer.keyPressed(KeyEvent.VK_NUMPAD4);
                ispress = false;
            }
            kpress = !kpress;
        } else {
            kpress = false;
            if (ispress) {
                computer.keyReleased(KeyEvent.VK_NUMPAD4);
            }
            ispress = false;
        }
//        if (ktick != 0){
//                if (!pressed){
//                computer.keyPressed(KeyEvent.VK_NUMPAD4);
//                pressed = true;
//                } else {
//                computer.keyReleased(KeyEvent.VK_NUMPAD4);
//                pressed = false;
//                }
//        }
        if (fram < 1) {
            fram++;
            computer.reset();
            computer.reSync();
            if (frame != null) {
                frame.pack();
            }
        }
        if (loadit > 0) {
            loadit++;
            if (loadit > 5) {
                loadit = 0;
                loadFile(Computer.TYPE_SNAPSHOT, sna, true);
            }
        }
        if (multiload >= 1) {
            multiload++;
            if (multiload == 6) {
                loadFile(Computer.TYPE_SNAPSHOT, sna, true);
            }
            if (multiload == 8) {
                loadFile(Computer.TYPE_SNAPSHOT, load, true);
                multiload = 0;
            }
        }
    }

    public void keyTyped(KeyEvent e) {
    }
    private KeyTranslator translator = new KeyTranslator();

    public void setupController() {
        controller.setVisible(true);
    }
    JFrame fullframe;

    public void repaint() {
    }

    public void loadPlus() {
        GateArray.cpc.loadSystem();
    }
    BufferedImage testim = new BufferedImage(768, 544, BufferedImage.TYPE_INT_RGB);

    public void toggleFullscreen() {
        alt = false;
        if (fullframe == null) {
            fullframe = new JFrame();
            fullframe.setUndecorated(true);
            fullframe.setLayout(new BorderLayout());
            GraphicsConfiguration conf = this.getGraphicsConfiguration();
            int monitors = conf.getDevice().getConfigurations().length;
            int device = 0;
            int h = conf.getDevice().getConfigurations()[device].getBounds().height;
            int w = conf.getDevice().getConfigurations()[device].getBounds().width;
            Dimension d = new Dimension(w, h);
            fullframe.setPreferredSize(d);
            fullframe.setSize(d);
            Image testit = testim.getScaledInstance(d.width, -1, Image.SCALE_FAST);
            display.left = new JPanel();
            display.right = new JPanel();
            display.left.setBackground(Color.black);
            display.right.setBackground(Color.black);
            Dimension dd = new Dimension(0, (d.height - testit.getHeight(null)) >> 1);
            display.left.setPreferredSize(dd);
            display.right.setPreferredSize(dd);
            if (testit.getHeight(null) > this.getHeight()) {
                testit = testim.getScaledInstance(-1, d.height, Image.SCALE_FAST);
                dd = new Dimension((d.width - testit.getWidth(null)) >> 1, Toolkit.getDefaultToolkit().getScreenSize().height);
                display.left.setPreferredSize(dd);
                display.right.setPreferredSize(dd);
                display.leftside = new BufferedImage(20, 280, BufferedImage.TYPE_INT_RGB);
                display.rightside = new BufferedImage(20, 280, BufferedImage.TYPE_INT_RGB);
                display.leftpixels = new int[20 * 280];
                display.rightpixels = new int[20 * 280];
                fullframe.add(display.left, BorderLayout.WEST);
                fullframe.add(display.right, BorderLayout.EAST);
                display.drawborder = true;
            } else {
                display.drawborder = false;
                fullframe.add(display.left, BorderLayout.NORTH);
                fullframe.add(display.right, BorderLayout.SOUTH);
            }
        }
        display.fullscreen = !display.fullscreen;
        if (display.fullscreen) {
            if (frame != null) {
                frame.setVisible(false);
            }
            this.setVisible(false);
            this.remove(display);
            fullframe.add(display, BorderLayout.CENTER);
            fullframe.setVisible(true);
        } else {
            fullframe.remove(display);
            this.add(display, BorderLayout.CENTER);
            fullframe.setVisible(false);
            this.setVisible(true);
            if (frame != null) {
                frame.setVisible(true);
                frame.pack();
            }
        }
        display.requestFocus();
    }
    Controller controller;

    public void toggleFilter() {
        display.scanlines = !display.scanlines;
    }

    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD9) {
            keypresser = 1;
        }
        if (e.getKeyCode() == KeyEvent.VK_F12 && alt) {
            this.showDebugger();
            return;
        }
        if (e.getKeyCode() == KeyEvent.VK_SCROLL_LOCK) {
            this.setLightgun(!lightpen);
            controller.trojan.setSelected(lightpen);
        }
        if (e.getKeyCode() == KeyEvent.VK_ALT) {
            alt = true;
        }
        if (alt && e.getKeyCode() == KeyEvent.VK_ENTER) {
            if (!display.menumode) {
                toggleFullscreen();
            }
        }
        if (e.getKeyCode() == KeyEvent.VK_F10) {
            e.consume();
            return;
        }
        for (int i = 0; i < 6; i++) {
            if (e.getKeyCode() == controller.keyevents[i]) {
                switch (i) {
                    case 0:
                        e.setKeyCode(KeyEvent.VK_NUMPAD5);
                        break;
                    case 1:
                        e.setKeyCode(KeyEvent.VK_NUMPAD0);
                        break;
                    case 2:
                        e.setKeyCode(KeyEvent.VK_NUMPAD8);
                        break;
                    case 3:
                        e.setKeyCode(KeyEvent.VK_NUMPAD2);
                        break;
                    case 4:
                        e.setKeyCode(KeyEvent.VK_NUMPAD4);
                        break;
                    case 5:
                        e.setKeyCode(KeyEvent.VK_NUMPAD6);
                        break;
                }
            }
        }
//        if (e.getKeyCode() == 101)
//            display.shootme = true;
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD4) {
            ktick = ktick == 0 ? 1 : 0;
        }
//        if (e.getKeyCode() == KeyEvent.VK_F3) {
//            return;
//        }
//        if (e.getKeyCode() == KeyEvent.VK_F2) {
//            return;
//        }
//        if (e.getKeyCode() == KeyEvent.VK_F1) {
//            return;
//        }
//        if (e.getKeyCode() == KeyEvent.VK_F7) {
//            return;
//        }
        e = translator.translate(e, localkeys);
        if (e.getKeyCode() == KeyEvent.VK_F12) {
            resetComputer();
        }
        computer.processKeyEvent(e);
        e.consume();
    }

    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ALT) {
            alt = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD9) {
            keypresser = 0;
        }
        if (e.getKeyCode() == KeyEvent.VK_F10) {
            controller.setVisible(true);
            e.consume();
            return;
        }
        for (int i = 0; i < 6; i++) {
            if (e.getKeyCode() == controller.keyevents[i]) {
                switch (i) {
                    case 0:
                        e.setKeyCode(KeyEvent.VK_NUMPAD5);
                        break;
                    case 1:
                        e.setKeyCode(KeyEvent.VK_NUMPAD0);
                        break;
                    case 2:
                        e.setKeyCode(KeyEvent.VK_NUMPAD8);
                        break;
                    case 3:
                        e.setKeyCode(KeyEvent.VK_NUMPAD2);
                        break;
                    case 4:
                        e.setKeyCode(KeyEvent.VK_NUMPAD4);
                        break;
                    case 5:
                        e.setKeyCode(KeyEvent.VK_NUMPAD6);
                        break;
                }
            }
        }
        if (e.getKeyCode() == KeyEvent.VK_F3) {
            JCPC.system.cpc.GateArray.cpc.saveallowed = !JCPC.system.cpc.GateArray.cpc.saveallowed;
//            System.out.println("Storing DSK is " + (JCPC.system.cpc.GateArray.cpc.saveallowed ? "allowed... " : "not allowed... "));
//            return;
        }
        if (e.getKeyCode() == KeyEvent.VK_F1) {
            JOptionPane.showMessageDialog(new JFrame(), "JavaGX4000 by Markus Hohmann\r\n"
                    + "Contact: webmaster@cpc-live.com\r\n"
                    + "\r\n"
                    + "F1 - This info\r\n"
                    + "F2 - Load medium*\r\n"
                    + "F3 - Enable/disable DSK storing (Off by default)\r\n"
                    //+ "F4 - Store temporary Snapshot\r\n"
                    //+ "F5 - Load temporary Snapshot\r\n"
                    + "F6 - Load cartridge image (CPR)\r\n"
                    + "F7 - Toggle Scanlines (When large)\r\n"
                    + "F8 - Toggle CRTC type (0/1)\r\n"
                    + "F9 - Toggle Turbo\r\n"
                    + "F10 - Setup controller and lightgun / Select internal CPR\r\n"
                    + "F11 - Autotype console\r\n"
                    + "F12 - Reset CPC\r\n"
                    + "\r\n"
                    + "Alt+F12 - Debugger\r\n"
                    + "Alt+Enter - Toggle fullscreen\r\n"
                    + "Print Screen - Poke interface\r\n"
                    + "Scroll Lock - Toggle lightgun\r\n"
                    + "Pause - Amstrad Cartridge Software Demonstrator (CSD) emulation panel\r\n"
                    + "\r\n"
                    + "Joystick is mapped to:\r\n"
                    + "<Insert>/<NP 5> - Fire 0\r\n"
                    + "<Page up>/<NP 0> - Fire 1\r\n"
                    + "<Home>/<NP 8> - Up\r\n"
                    + "<Page down>/<NP 6> - Right\r\n"
                    + "<End>/<NP 2> - Down\r\n"
                    + "<Delete>/<NP 4> - Left\r\n"
                    + "\r\n"
                    + "*Supported media:\r\n"
                    + "DSK, SNA, CDT, CSW, BIN, CPR\r\n");
            return;
        }
        if (e.getKeyCode() == KeyEvent.VK_F7) {
            display.scanlines = !display.scanlines;
//            return;
        }
        e = translator.translate(e, localkeys);
        if (e.getKeyCode() == KeyEvent.VK_F2) {
            load();
//            return;
        }
        computer.processKeyEvent(e);
        e.consume();
    }
    FileDialog loader;

    protected void load() {
        if (developer) {
            if (loader == null) {
                loader = new FileDialog((Frame) frame,
                        "Load file", FileDialog.LOAD);
            }
//            loader.setFile("*.dsk;*.bin;*.cdt;*.cpr;*.sna;*.csw");
            loader.setVisible(true);
            String filename = loader.getFile();
            if (filename != null) {
                filename = loader.getDirectory() + loader.getFile();
                loadFile(Computer.TYPE_SNAPSHOT, filename, false);
//                System.out.println("File loaded: " + filename);
            }
        }
    }
    boolean lightpen = false;

    public void mouseClicked(MouseEvent e) {
        if (lightpen) {
            return;
        }
        display.requestFocus();
        if (e.getClickCount() == 2 && frame != null && !display.fullscreen) {
            Thread b = new Thread() {
                public void run() {
                    if (menu != null) {
                        menu.jCheckBoxMenuItem2.setSelected(!large);
                        return;
                    }
                    setFullSize(!large);
                    System.out.println("Changing display to " + (large ? "large size" : "small size"));
                    try {
                        Thread.sleep(100);
                    } catch (Exception e) {
                    }
                    display.setPreferredSize(display.getPreferredSize());
                    display.setSize(display.getPreferredSize());
                    try {
                        Thread.sleep(100);
                    } catch (Exception e) {
                    }
                    frame.pack();
                    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
                    frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
                }
            };
            b.start();
        }
    }

    public void mousePressed(MouseEvent e) {
        if (lightpen && !display.menumode) {
            if (e.getButton() != 1) {
                penonscreen = !penonscreen;
                display.penonscreen = penonscreen;
                display.setCursor(penonscreen ? pen : gun);
                return;
            }
            int x = e.getX();
            int y = e.getY();
            if (display.fullscreen) {
                double xx = (double) (768) / (double) display.getWidth();
                double yy = (double) (544) / (double) display.getHeight();
                x = (int) ((double) x * xx);
                y = (int) ((double) y * yy);
            }
            GateArray.cpc.getCRTC().setLightpen(x, y, display.large, display.fullscreen, true);
            computer.keyPressed(penonscreen ? KeyEvent.VK_ENTER : KeyEvent.VK_INSERT);
        }
    }
    final URL cursorim = getClass().getResource("lightgun.png");
    final Image lightGun = getToolkit().getImage(cursorim);
    final URL cursorim2 = getClass().getResource("lightpen.png");
    final Image lightPen = getToolkit().getImage(cursorim2);
    Cursor gun = Toolkit.getDefaultToolkit().createCustomCursor(lightGun, new Point(1, 1), "gunCursor");
    Cursor pen = Toolkit.getDefaultToolkit().createCustomCursor(lightPen, new Point(1, 1), "penCursor");
    int basex = 200;
    int basexmax = 230;

    public void setLightgun(boolean enable) {
        lightpen = enable;
        GateArray.cpc.getCRTC().lightgun = lightpen;
        if (lightpen) {
            display.setCursor(penonscreen ? pen : gun);
        } else {
            display.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        }

    }

    public void mouseReleased(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        if (y < 50) {
            display.showtime = 50;
        }
        if (Display.showtime > 0) {
            int d = display.divider;
            if (d == 2) {
                d = 1;
            } else {
                d = 2;
            }
            if (x > 46 / d && x < 76 / d) {
                if (y > 6 / d && y < 38 / d) {
                    System.out.println("Loading disk 1");
                    loadFile(Computer.TYPE_DISC_IMAGE, disk1, true);
                    Samples.INSERT.play();

                }
            }
            if (x > 80 / d && x < 106 / d) {
                if (y > 6 / d && y < 38 / d) {
                    System.out.println("Loading disk 2");
                    loadFile(Computer.TYPE_DISC_IMAGE, disk2, true);
                    Samples.INSERT.play();

                }
            }
        }
        if (menupossible) {
            display.menumode = !display.menumode;
        }
        if (!display.menumode && lightpen) {
            computer.keyReleased(penonscreen ? KeyEvent.VK_ENTER : KeyEvent.VK_INSERT);
            GateArray.cpc.getCRTC().releaseGun();
            return;
        }
        if (display.menumode && display.large) {
//            System.out.println(x + "," + y);
            y -= 100;

            if (x > basex && x < basexmax) {
                if (y < 480 && y > 0) {
                    int index = y / 32;
//                    System.out.println(index);
                    if (index < 0 || index > display.carts.length - 1) {
                        return;
                    }
                    controller.cart.setSelectedIndex(index);
//                    GateArray.cpc.loadCart(index);
                    display.menumode = false;
                }
            }

            if (x > basex + 300 && x < basexmax + 300) {
                if (y < 320 && y > 0) {
                    int index = 15 + y / 32;
//                    System.out.println(index);
                    if (index < 0 || index > display.carts.length - 1) {
                        return;
                    }
                    controller.cart.setSelectedIndex(index);
//                    GateArray.cpc.loadCart(index);
                    display.menumode = false;
                }
            }
        }
        if (display.menumode && !display.large) {
            y -= 50;

            if (x > 100 && x < 220) {
                if (y < 240 && y > 0) {
                    int index = y / 16;
//                    System.out.println(index);
                    if (index < 0 || index > display.carts.length - 1) {
                        return;
                    }
                    controller.cart.setSelectedIndex(index);
//                    GateArray.cpc.loadCart(index);
                    display.menumode = false;
                }
            }

            if (x > 250 && x < 370) {
                if (y < 210 && y > 0) {
                    int index = 15 + y / 16;
                    if (index < 0 || index > display.carts.length - 1) {
                        return;
                    }
                    controller.cart.setSelectedIndex(index);
//                    GateArray.cpc.loadCart(index);
                    display.menumode = false;
                }
            }
        }
        if (display.mCurrFPS < 45) {
            computer.reSync();
        }
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void loadFile(String name) {
        loadFile(Computer.TYPE_UNKNOWN, name, true);
    }

    public void loadFile(int type, String name, boolean usePath) {

        if (URL) {
            usePath = false;
        }
        try {
            computer.stop();
            computer.loadFile(type, (usePath ? computer.getFilePath() : "") + name);
        } catch (Exception e) {
        }
        computer.start();
        display.requestFocus();
//        computer.start();
    }

    public void resetComputer() {
        JCPC.system.cpc.GateArray.cpc.cprslot = 0;
        computer.reset();
    }

    public void loadGame(int slot) {
        GateArray.cpc.loadCart(slot);
    }

    public void setComputer(final String name) {

        try {
            setComputer(name, true);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(0);
        }
    }

    public void setComputer(String name, boolean start) throws Exception {
        if (computer == null || !name.equalsIgnoreCase(computer.getName())) {
            Computer newComputer = Computer.createComputer(this, name);
//            if (computer != null) {
//                Drive[] floppies = computer.getFloppyDrives();
//                if (floppies != null) {
//                    for (int i = 0; i < floppies.length; i++) {
//                        if (floppies[i] != null) {
//                            floppies[i].setActiveListener(null);
//                        }
//                    }
//                }
//                computer.dispose();
//                computer = null;
//                Runtime runtime = Runtime.getRuntime();
//                runtime.gc();
//                runtime.runFinalization();
//                runtime.gc();
//                System.out.println("Computer Disposed");
//            }
            computer = newComputer;
            setFullSize(large);
            computer.initialise();
            if (start) {
                computer.start();
            }
        }
    }
    boolean keepmonitor;

    public void setFullSize(boolean value) {
        large = value;
        Display.drawmonitor = value ? false : keepmonitor;
        computer.stop();
        display.divider = large ? 2 : 1;
        display.large = large;
        computer.setLarge(large);
        display.setImageSize(computer.getDisplaySize(large), computer.getDisplayScale(large));
        computer.setDisplay(display);
        computer.start();
    }

    public void focusLost(FocusEvent e) {
        computer.displayLostFocus();
        if (display.mCurrFPS < 45) {
            computer.reSync();
        }
    }

    public void focusGained(FocusEvent e) {
        if (display.mCurrFPS < 45) {
            computer.reSync();
        }
    }
    static JFrame frame;

    public static void main(String[] args) {
        developer = true;
        GX4000 applet = new GX4000();
        applet.isStandalone = true;
        applet.menu = new GX4000Menu();
        frame = new JFrame() {
            protected void processWindowEvent(WindowEvent e) {
                super.processWindowEvent(e);
                if (e.getID() == WindowEvent.WINDOW_CLOSING) {
                    System.exit(0);
                }
            }

            public synchronized void setTitle(String title) {
                super.setTitle(title);
                enableEvents(AWTEvent.WINDOW_EVENT_MASK);
            }
        };
        frame.setTitle("JavaGX4000");
        frame.getContentPane().add(applet, BorderLayout.CENTER);
        frame.add(applet.menu.Menu, BorderLayout.NORTH);
        applet.menu.jMenuItem1.addActionListener(applet);
        applet.menu.jMenuItem2.addActionListener(applet);
        applet.menu.jMenuItem3.addActionListener(applet);
        applet.menu.jMenuItem5.addActionListener(applet);
        applet.menu.jMenuItem7.addActionListener(applet);
        applet.menu.jMenuItem8.addActionListener(applet);
        applet.menu.jCheckBoxMenuItem1.addItemListener(applet);
        applet.menu.jCheckBoxMenuItem2.addItemListener(applet);
        applet.menu.jCheckBoxMenuItem3.addItemListener(applet);
        applet.menu.jCheckBoxMenuItem4.addItemListener(applet);
        //frame.setBackground(Color.black);
        applet.init();
        applet.start();
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
        frame.setVisible(true);
        frame.setResizable(false);
        frame.pack();
    }
}
