/*
 * Debugger.java
 *
 * Created on 18 January 2007, 15:07
 */

package JCPC.ui;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import JCPC.core.*;
import JCPC.core.device.*;
import JCPC.core.device.memory.*;
import JCPC.util.diss.*;

/**
 *
 * @author  Richard
 */
public class Debugger extends JFrame implements MouseListener, ActionListener {
  
  public static final Color navy = new Color(0,0,127);
  
  protected Computer computer;
  protected long startCycles = 0;
  
  protected JFileChooser fileDlg;
  public static void INK(int pen, Color color){
      if (panel1==null)return;
      switch (pen){
          case 0: panel1.setBackground(color);break;
          case 1: panel2.setBackground(color);break;
          case 2: panel3.setBackground(color);break;
          case 3: panel4.setBackground(color);break;
          case 4: panel5.setBackground(color);break;
          case 5: panel6.setBackground(color);break;
          case 6: panel7.setBackground(color);break;
          case 7: panel8.setBackground(color);break;
          case 8: panel9.setBackground(color);break;
          case 9: panel10.setBackground(color);break;
          case 10: panel11.setBackground(color);break;
          case 11: panel12.setBackground(color);break;
          case 12: panel13.setBackground(color);break;
          case 13: panel14.setBackground(color);break;
          case 14: panel15.setBackground(color);break;
          case 15: panel16.setBackground(color);break;
          case 16: panel17.setBackground(color);break;
      }
  }
  /** Creates new form Debugger */
  public Debugger() {
    initComponents();
    eDisassembler.setFont(new Font("Monospaced",0,11));
    eMemory.setFont(new Font("Monospaced",0,11));
    jButton1.addActionListener(this);
    bRun.addActionListener(this);
    bStop.addActionListener(this);
    bStep.addActionListener(this);
    bStepOver.addActionListener(this);
    mSave.addActionListener(this);
    mGoto.addActionListener(this);
    jScrollPane1.getVerticalScrollBar().setUnitIncrement(getFontMetrics(eMemory.getFont()).getHeight());
  }
  
  public void setComputer(Computer value) {
    if (computer != null)
      computer.removeActionListener(this);
    computer = value;
    eDisassembler.setComputer(computer);
    eMemory.setComputer(computer);
    if (computer != null) {
      computer.addActionListener(this);
      eRegisters.setDevice(computer.getProcessor());
      updateDisplay();
    }
    else
      eRegisters.setDevice(null);
  }
  
  protected void updateDisplay() {
    eDisassembler.setPC(computer.getProcessor().getProgramCounter());
    lCycleCount.setText(Long.toString(computer.getProcessor().getCycles() - startCycles));
    eRegisters.setValues();
    repaint();
  }
  
  protected long getGotoAddress() {
    String address = JOptionPane.showInputDialog("Address: ", "#");
    if (address == null)
      return -1;
    address = address.trim();
    if (address.length() == 0)
      return -1;
    
    switch(address.charAt(0)) {
      case '#':
      case '&':
      case '$': return Long.parseLong(address.substring(1), 16);

      default:  return Long.parseLong(address);
    }
  }
  
  public void actionPerformed(ActionEvent e) {
    computer.clearRunToAddress();
    if      (e.getSource() == bRun)      computer.start();
    else if (e.getSource() == bStop)     computer.stop();
    else if (e.getSource() == bStep)     computer.step();
    else if (e.getSource() == bStepOver) computer.stepOver();
    else if (e.getSource() == computer)  updateDisplay();
    else if (e.getSource() == jButton1)  {computer.getDisplay().DEBUG_SPRITES = true;jButton1.setEnabled(false);}
    else if (e.getSource() == mGoto) {
      long address = getGotoAddress();
      if (address != -1) {
        if (popupMenu.getInvoker() == eDisassembler) eDisassembler.setAddress((int)address);
        else                                         eMemory.setAddress((int)address);
      }
    }
    else if (e.getSource() == mSave) {
      if (popupMenu.getInvoker() == eDisassembler) saveDisassembly();
      else                                         saveMemory();
    }
    computer.setFrameSkip(0);
    computer.updateDisplay(false);
  }
  
  protected File showSaveDialog(String title) {
    if (fileDlg == null)
      fileDlg = new JFileChooser();
    fileDlg.setDialogTitle(title);
    return fileDlg.showSaveDialog(bRun) == JFileChooser.APPROVE_OPTION ? fileDlg.getSelectedFile() : null;
  }
  
  public void saveMemory() {
    saveMemory(eMemory.selStart, eMemory.selEnd);
  }
  
  public void saveMemory(int start, int end) {
    File file = showSaveDialog("Save Memory");
    if (file != null) {
      try {
        FileOutputStream io = new FileOutputStream(file);
        try {
          Memory mem = computer.getMemory();
          for (int addr = start; addr <= end; addr++)
            io.write(mem.readByte(addr));
        } finally {
          io.close();
        }
      } catch(Exception e) {
        e.printStackTrace();
      }
    }
  }
  
  public void saveDisassembly() {
    saveDisassembly(eDisassembler.selStart, eDisassembler.selEnd);
  }
  
  public void saveDisassembly(int start, int end) {
    File file = showSaveDialog("Save Disassembly");
    if (file != null) {
      int[] addr = new int[] { start };
      try {
        FileOutputStream io = new FileOutputStream(file);
        try {
          Disassembler diss = computer.getDisassembler();
          Memory mem = computer.getMemory();
          while (addr[0] <= end) {
            String s = Util.hex((short)addr[0]) + ": ";
            io.write((s + diss.disassemble(mem, addr) + "\r\n").getBytes());
          }
        } finally {
          io.close();
        }
      } catch(Exception e) {
        e.printStackTrace();
      }
    }
  }
  
  /** This method is called from within the constructor to
   * initialize the form.
   * WARNING: Do NOT modify this code. The content of this method is
   * always regenerated by the Form Editor.
   */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        popupMenu = new javax.swing.JPopupMenu();
        mGoto = new javax.swing.JMenuItem();
        mSave = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        bRun = new javax.swing.JButton();
        bStop = new javax.swing.JButton();
        bStep = new JCPC.ui.EButton();
        bStepOver = new JCPC.ui.EButton();
        jButton1 = new javax.swing.JButton();
        panel1 = new java.awt.Panel();
        panel2 = new java.awt.Panel();
        panel3 = new java.awt.Panel();
        panel4 = new java.awt.Panel();
        panel5 = new java.awt.Panel();
        panel6 = new java.awt.Panel();
        panel7 = new java.awt.Panel();
        panel8 = new java.awt.Panel();
        panel9 = new java.awt.Panel();
        panel10 = new java.awt.Panel();
        panel11 = new java.awt.Panel();
        panel12 = new java.awt.Panel();
        panel13 = new java.awt.Panel();
        panel14 = new java.awt.Panel();
        panel15 = new java.awt.Panel();
        panel16 = new java.awt.Panel();
        panel17 = new java.awt.Panel();
        jPanel3 = new javax.swing.JPanel();
        lCycles = new javax.swing.JLabel();
        lCycleCount = new javax.swing.JLabel();
        eRegisters = new JCPC.ui.ERegisters();
        jSplitPane1 = new javax.swing.JSplitPane();
        eDisassembler = new JCPC.ui.EDisassembler();
        jScrollPane1 = new javax.swing.JScrollPane();
        eMemory = new JCPC.ui.EMemory();

        mGoto.setText("Goto...");
        popupMenu.add(mGoto);

        mSave.setText("Save...");
        popupMenu.add(mSave);

        setTitle("JavaGX4000 Debugger");

        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        bRun.setText("Run");
        jPanel2.add(bRun);

        bStop.setText("Stop");
        jPanel2.add(bStop);

        bStep.setText("Step");
        jPanel2.add(bStep);

        bStepOver.setText("Step Over");
        jPanel2.add(bStepOver);

        jButton1.setText("Debug Sprites");
        jPanel2.add(jButton1);
        jPanel2.add(panel1);
        jPanel2.add(panel2);
        jPanel2.add(panel3);
        jPanel2.add(panel4);
        jPanel2.add(panel5);
        jPanel2.add(panel6);
        jPanel2.add(panel7);
        jPanel2.add(panel8);
        jPanel2.add(panel9);
        jPanel2.add(panel10);
        jPanel2.add(panel11);
        jPanel2.add(panel12);
        jPanel2.add(panel13);
        jPanel2.add(panel14);
        jPanel2.add(panel15);
        jPanel2.add(panel16);
        jPanel2.add(panel17);

        jPanel1.add(jPanel2, java.awt.BorderLayout.CENTER);

        lCycles.setForeground(new java.awt.Color(0, 0, 127));
        lCycles.setText("Cycles:");
        jPanel3.add(lCycles);

        lCycleCount.setText("0");
        lCycleCount.addMouseListener(this);
        jPanel3.add(lCycleCount);

        jPanel1.add(jPanel3, java.awt.BorderLayout.EAST);

        getContentPane().add(jPanel1, java.awt.BorderLayout.PAGE_END);

        eRegisters.setFocusable(false);
        eRegisters.setLayout(null);
        getContentPane().add(eRegisters, java.awt.BorderLayout.LINE_END);

        jSplitPane1.setDividerLocation(200);
        jSplitPane1.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
        jSplitPane1.setContinuousLayout(true);

        eDisassembler.setComponentPopupMenu(popupMenu);
        eDisassembler.addMouseListener(this);
        jSplitPane1.setTopComponent(eDisassembler);

        eMemory.setComponentPopupMenu(popupMenu);
        jScrollPane1.setViewportView(eMemory);

        jSplitPane1.setRightComponent(jScrollPane1);

        getContentPane().add(jSplitPane1, java.awt.BorderLayout.CENTER);

        pack();
    }

    // Code for dispatching events from components to event handlers.

    public void mouseClicked(java.awt.event.MouseEvent evt) {
        if (evt.getSource() == lCycleCount) {
            Debugger.this.lCycleCountMouseClicked(evt);
        }
        else if (evt.getSource() == eDisassembler) {
            Debugger.this.eDisassemblerMouseClicked(evt);
        }
    }

    public void mouseEntered(java.awt.event.MouseEvent evt) {
    }

    public void mouseExited(java.awt.event.MouseEvent evt) {
    }

    public void mousePressed(java.awt.event.MouseEvent evt) {
    }

    public void mouseReleased(java.awt.event.MouseEvent evt) {
    }// </editor-fold>//GEN-END:initComponents

  private void eDisassemblerMouseClicked(java.awt.event.MouseEvent e) {//GEN-FIRST:event_eDisassemblerMouseClicked
    if (e.getClickCount() == 2) {
      int addr = eDisassembler.getAddress(e.getY());
      if (addr != -1) {
        computer.setRunToAddress(addr);
        computer.start();
      }
    }
  }//GEN-LAST:event_eDisassemblerMouseClicked

  private void lCycleCountMouseClicked(java.awt.event.MouseEvent e) {//GEN-FIRST:event_lCycleCountMouseClicked
    if (e.getClickCount() == 2) {
      startCycles = computer.getProcessor().getCycles();
      lCycleCount.setText("0");
    }
  }//GEN-LAST:event_lCycleCountMouseClicked
  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    protected javax.swing.JButton bRun;
    protected JCPC.ui.EButton bStep;
    protected JCPC.ui.EButton bStepOver;
    protected javax.swing.JButton bStop;
    protected JCPC.ui.EDisassembler eDisassembler;
    protected JCPC.ui.EMemory eMemory;
    protected JCPC.ui.ERegisters eRegisters;
    protected javax.swing.JButton jButton1;
    protected javax.swing.JPanel jPanel1;
    protected javax.swing.JPanel jPanel2;
    protected javax.swing.JPanel jPanel3;
    protected javax.swing.JScrollPane jScrollPane1;
    protected javax.swing.JSplitPane jSplitPane1;
    protected javax.swing.JLabel lCycleCount;
    protected javax.swing.JLabel lCycles;
    protected javax.swing.JMenuItem mGoto;
    protected javax.swing.JMenuItem mSave;
    public static java.awt.Panel panel1;
    public static java.awt.Panel panel10;
    public static java.awt.Panel panel11;
    public static java.awt.Panel panel12;
    public static java.awt.Panel panel13;
    public static java.awt.Panel panel14;
    public static java.awt.Panel panel15;
    public static java.awt.Panel panel16;
    public static java.awt.Panel panel17;
    public static java.awt.Panel panel2;
    public static java.awt.Panel panel3;
    public static java.awt.Panel panel4;
    public static java.awt.Panel panel5;
    public static java.awt.Panel panel6;
    public static java.awt.Panel panel7;
    public static java.awt.Panel panel8;
    public static java.awt.Panel panel9;
    protected javax.swing.JPopupMenu popupMenu;
    // End of variables declaration//GEN-END:variables
  
}
