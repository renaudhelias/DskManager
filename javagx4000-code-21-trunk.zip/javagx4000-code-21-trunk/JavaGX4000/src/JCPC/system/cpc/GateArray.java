package JCPC.system.cpc;

import JCPC.core.Util;
import java.awt.Dimension;
import javax.swing.*;


import JCPC.core.device.crtc.*;
import JCPC.core.renderer.MonitorRenderer;
import JCPC.ui.Debugger;
import java.awt.BorderLayout;
import java.awt.Color;

/**
 * Title: JavaCPC Description: The Java Amstrad CPC Emulator Copyright:
 * Copyright (c) 2006-2010 Company:
 *
 * @author
 * @version 6.8
 */
public final class GateArray extends MonitorRenderer implements CRTCListener {

    public int getBorder() {
        return inks[16];
    }
    public static final int lowlines = 280;
    public static final int highlines = lowlines * 2;
    protected int borderHeight;
    protected static final GraphicsDecoder decoder = new GraphicsDecoder();
    protected final int HOFFSET = 0x0a8000 - 0x800;    // Offset of monitor (half pixel adjust) 0xa8000
    protected final int HOFFSEND = HOFFSET + 0x300000;  // End of offset
    protected Dimension HALF_DISPLAY_SIZE = new Dimension(384, lowlines);
    protected Dimension FULL_DISPLAY_SIZE = new Dimension(768, lowlines);
    static int returnmode = 0;
    static int rambank = 0;
    static int smode = 1;
    public static CPC cpc;
    public static Z80 z80;
    public Basic6845 crtc;
    public int InterruptLineCount;
    protected int InterruptSyncCount = 0;
//    public int interruptMask;
    protected int hSyncCount;
    protected int vSyncCount = 0;
    protected int screenMode = -1;
    public int newMode = 0;
    protected boolean[] isBorder;
    protected boolean[] rendered;
    protected boolean inHSync = false;
    protected boolean outHSync = false;
    public static int[] inks = new int[33];
    protected byte[] fullMap;
    protected byte[] halfMap;
    protected int offset = 0;
    protected int scanStart = 0;
    protected boolean scanStarted;
    protected Renderer borderRenderer;
    protected Renderer syncRenderer;
    protected Renderer defRenderer;
    protected Renderer startRenderer;
    protected Renderer endRenderer;
    protected Renderer renderer;
    protected int endPix;
    protected int selInk = 0;
    protected boolean render = true;
    protected boolean rendering = true;
    public static byte[] screenmemory;
    // protected int[] palTranslate	= new int[4096];
    protected int Luminance = 255;
    protected static final int[] maTranslate = new int[65536];
    protected static int[] CPCInks = new int[33];
    protected static int[] CPCInksb = new int[33];
    protected static int[] GAInks = {
        13, 27, 19, 25, 1, 7, 10,
        16, 28, 29, 24, 26, 6, 8,
        15, 17, 30, 31, 18, 20, 0,
        2, 9, 11, 4, 22, 21, 23, 3,
        5, 12, 14};
    protected int[] palette = {
        13, 13, 19, 25, 1, 7, 10, 16, 7, 25, 24, 26, 6, 8, 15, 17, 1, 19, 18, 20, 0, 2, 9, 11, 4, 22, 21, 23, 3, 5, 12, 14};
    protected static int[] Inks = {
        20, 4, 21, 28, 24, 29, 12, 5, 13, 22, 6, 23, 30, 0, 31, 14, 7, 15, 18, 2, 19, 26, 25, 27, 10, 3, 11};

    public void resetCPCColours() {
        System.arraycopy(original, 0, inkTranslateColor, 0, original.length);
    }

    public void setPlusPalette(int ink, int r, int g, int b) {
        setPlusPalette(ink, putRGB(LUM[r], LUM[g], LUM[b]));
    }

    public void setPlusPalette(int ink, int value) {
        inkTranslateColor[ink] = value;
        setInk(ink, ink);
//        System.out.println("INK "+Inks[ink]+ " set to "+Util.hex(value));
    }

    public void setPalette(int ink, int value) {
        inkTranslateColor[Inks[ink]] = value;
    }

    public int getVPOS() {
        return crtc.getVVPOS();
    }

    public int getHPOS() {
        return crtc.getHPOS();
    }
    protected static final byte[][] fullMaps = new byte[4][];
    protected static final byte[][] halfMaps = new byte[4][];

    static {
        for (int mode = 0; mode < 4; mode++) {
            byte[] full = new byte[65536 * 16];
            byte[] half = new byte[65536 * 8];
            fullMaps[mode] = full;
            halfMaps[mode] = half;
            for (int i = 0; i < 65536 * 8;) {
                int b1 = (i >> 3) & 0xff;
                int b2 = (i >> 11) & 0xff;
                decoder.decodeFull(full, i * 2, mode, b1);
                i += 4;
                decoder.decodeFull(full, i * 2, mode, b2);
                i += 4;
            }
        }
        for (int i = 0; i < maTranslate.length; i++) {
            int j = i << 1;
            maTranslate[i] = (j & 0x7fe) | ((j & 0x6000) << 1);
        }
//        for (int i=0;i<16;i++){
//            System.out.print("0x"+Integer.toHexString((i<<4)+0x0f)+",");
//        }
//        System.out.println();
//        System.exit(0);
    }
    public int LUM[] = {
        //        0xf,0x1f,0x2f,0x3f,0x4f,0x5f,0x6f,0x7f,0x8f,0x9f,0xaf,0xbf,0xcf,0xdf,0xef,0xff,
        0x00, 0x11, 0x22, 0x33,
        0x44, 0x55, 0x66, 0x77,
        0x88, 0x99, 0xAA, 0xBB,
        0xCC, 0xDD, 0xEE, 0xFF
    };
    public int[] inkTranslateColor = {
        /*
         * R G B
         */
        0x636363, /*
         * 13
         */
        0x636363, /*
         * 27
         */
        0x00FF63, /*
         * 19
         */
        0xFFFF63, /*
         * 25
         */
        0x000063, /*
         * 1
         */
        0xFF0063, /*
         * 7
         */
        0x006363, /*
         * 10
         */
        0xFF6363, /*
         * 16
         */
        0xFF0063, /*
         * 28
         */
        0xFFFF63, /*
         * 29
         */
        0xFFFF00, /*
         * 24
         */
        0xFEFEFE, /*
         * 26
         */
        0xFF0000, /*
         * 6
         */
        0xFF00FF, /*
         * 8
         */
        0xFF6300, /*
         * 15
         */
        0xFF63FF, /*
         * 17
         */
        0x000063, /*
         * 30
         */
        0x00FF63, /*
         * 31
         */
        0x00FF00, /*
         * 18
         */
        0x00FFFF, /*
         * 20
         */
        0x000000, /*
         * 0
         */
        0x0000FF, /*
         * 2
         */
        0x006300, /*
         * 9
         */
        0x0063FF, /*
         * 11
         */
        0x630063, /*
         * 4
         */
        0x63FF63, /*
         * 22
         */
        0x63FF00, /*
         * 21
         */
        0x63FFFF, /*
         * 23
         */
        0x630000, /*
         * 3
         */
        0x6300FF, /*
         * 5
         */
        0x636300, /*
         * 12
         */
        0x6363FF /*
     * 14
     */};
    protected static final int[] original = {
        /*
         * R G B
         */
        0x636363, /*
         * 13
         */
        0x636363, /*
         * 27
         */
        0x00FF63, /*
         * 19
         */
        0xFFFF63, /*
         * 25
         */
        0x000063, /*
         * 1
         */
        0xFF0063, /*
         * 7
         */
        0x006363, /*
         * 10
         */
        0xFF6363, /*
         * 16
         */
        0xFF0063, /*
         * 28
         */
        0xFFFF63, /*
         * 29
         */
        0xFFFF00, /*
         * 24
         */
        0xFEFEFE, /*
         * 26
         */
        0xFF0000, /*
         * 6
         */
        0xFF00FF, /*
         * 8
         */
        0xFF6300, /*
         * 15
         */
        0xFF63FF, /*
         * 17
         */
        0x000063, /*
         * 30
         */
        0x00FF63, /*
         * 31
         */
        0x00FF00, /*
         * 18
         */
        0x00FFFF, /*
         * 20
         */
        0x000000, /*
         * 0
         */
        0x0000FF, /*
         * 2
         */
        0x006300, /*
         * 9
         */
        0x0063FF, /*
         * 11
         */
        0x630063, /*
         * 4
         */
        0x63FF63, /*
         * 22
         */
        0x63FF00, /*
         * 21
         */
        0x63FFFF, /*
         * 23
         */
        0x630000, /*
         * 3
         */
        0x6300FF, /*
         * 5
         */
        0x636300, /*
         * 12
         */
        0x6363FF /*
     * 14
     */};

    public GateArray(CPC cpc) {
        super("Amstrad Gate Array");
        setCycleFrequency(1000000);  // 1MHz
        this.cpc = cpc;
        z80 = cpc.z80;
        crtc = cpc.crtc;
        reset();
        setHalfSize();
    }

    public void setHalfSize() {
        if (defRenderer == null) {
            defRenderer = new FullRenderer();
            startRenderer = new FullStartRenderer();
            endRenderer = new FullEndRenderer();
            borderRenderer = new BorderRenderer(16, 16);
            syncRenderer = new BorderRenderer(32, 16);
            renderer = borderRenderer;
        }
    }

    @Override
    public void reset() {
        oldline = -1;
        spritecheck = -1;
        System.out.println("GateArray reset!");

        crtc.reset();
        horizontalScroll = 0;
        verticalScroll = 0;
        InterruptLineCount = 0;
        setScreenMode(1);
        for (int i = 0; i < 33; i++) {
            inks[i] = 0xff000000;
        }
        inks[0x10] = 0xff808080;
        JCPC.ui.Display.vscroll = "" + verticalScroll + " - " + horizontalScroll;
        SoftScrollRegister = 0;
        horizontalScroll = 0;
        verticalScroll = 0;
        if (crtc != null) {
            crtc.setVerticalScroll(verticalScroll);
            crtc.init();
        }
        resetCPCColours();
    }

    public void memoryReset() {
        oldline = -1;
        spritecheck = -1;
//        System.err.println("memoryReset");
        InterruptLineCount = 0;
        SoftScrollRegister = 0;
        horizontalScroll = 0;
        verticalScroll = 0;
        crtc.setVerticalScroll(verticalScroll);
        crtc.init();
        resetCPCColours();
        JCPC.ui.Display.vscroll = "" + verticalScroll + " - " + horizontalScroll;
    }

    public void setSelectedInk(int value) {
        selInk = (value & 0x1f) < 0x10 ? value & 0x0f : 0x10;
    }

    public int getSelectedInk() {
        return selInk;
    }

    public void setInk(int index, int value) {
        CPCInks[index] = GAInks[value & 0x1f];
        CPCInksb[index] = value;
        inks[index] = inkTranslateColor[value & 0x1f];
        
//            Debugger.INK(index, new Color(inks[index]));
        
    }

    public void setBorder(int value) {
        CPCInks[16] = GAInks[value & 0x1f];
        CPCInksb[16] = value;
        inks[16] = inkTranslateColor[value & 0x1f];
    }

    public static int getInk(int index) {
        return CPCInks[index];
    }

    public static int getInks(int index) {
        return CPCInksb[index];
    }

    @Override
    public void writePort(int port, int value) {
        if (cpc.memory.plus) {
            return;
        }
//      if (port == 0xfbfe || port == 0xfbee)
//          return;
        if ((value & 0x80) == 0) {
            if ((value & 0x40) == 0) {
                value &= 0x1f;
                selInk = value < 0x10 ? value : 0x10;
            } else {
                CPCInks[selInk] = GAInks[value & 0x1f];
                CPCInksb[selInk] = value & 0x01f;
                inks[selInk] = inkTranslateColor[value & 0x1f];
            }

        } else {
            if ((value & 0x40) == 0) {
                cpc.asic.romconfig = value;
                cpc.asic.setModeAndROMEnable();
            } else {
                cpc.memory.setRAMBank(value);
                rambank = value;
            }
        }
    }

    public int getRAMBank() {
        return rambank;
    }

    public int getMode() {
        return returnmode;
    }

    public void setScreenMode(int mode) {
        screenMode = mode;
        fullMap = fullMaps[mode];
        halfMap = halfMaps[mode];
    }

    public int getScreenMode() {
        return screenMode;
    }

    public static int getSMode() {
        return smode;
    }

    public void GateArray_AcknowledgeInterrupt() {
        InterruptLineCount &= 0x1f;
        GateArray_RasterInterruptRequest = false;
    }
    /*
     * This is called when a OUT to Gate Array rom configuration/mode select
     * register, bit 4 is set
     */
    boolean GateArray_RasterInterruptRequest = false;

    public boolean GateArray_GetInterruptRequest() {
        return GateArray_RasterInterruptRequest;
    }

    public void GateArray_ClearInterrupt() {
        GateArray_RasterInterruptRequest = false;
        z80.Z80_ClearInterruptRequest();
        GateArray_ClearInterruptCount();
        cpc.getAsic().ASIC_ClearRasterInterrupt();
    }

    public void GateArray_ClearInterruptCount() {
        /*
         * reset interrupt line count
         */
        InterruptLineCount = 0;
    }
    boolean test = true;
    boolean testbars;
    public static int SoftScrollRegister;
    int oldscroll;
    boolean plusdone = true;
    int spritecheck;
    int oldline;
    int pline;

    public int cyclecount;
    @Override
    public void cycle() {
        cyclecount++;
        if (pixels == null) {
            try {
                pixels = display.getPixels();
            } catch (Exception e) {
                pixels = new int[768 * lowlines];
            }
            return;
        }
        if (rendered == null) {
            rendered = new boolean[pixels.length];
        }
        crtc.avoidCollision();
        smode = screenMode;
        // next 2 lines added
        if (hSyncCount == 3 || hSyncCount == 4) {
            if (crtc.CRTCType != 3) {
                modeCheck();
            }
        }
        if (scanStarted) {
            crtc.checkHDisp();
            if (hPos < HOFFSEND) {
                renderer.render();
            } else {
                checkSprites();
                endRenderer.render();
                render = scanStarted = false;
            }
        } else {
            cyclecount = 0;
            if (render && hPos >= HOFFSET) {
                startRenderer.render();
                scanStarted = true;
            }
        }
        crtc.cycle();
//        if (!inHSync){
//            System.out.println(inHSync);
//        }
        if (inHSync) {
            hSyncCount++;
            if (hSyncCount == 2) {
                outHSync = true;
                super.hSyncStart();
            }

            if (hSyncCount == 7) {
                endHSync();
            }
        }
        clock();
    }
    int pd;
    public boolean simplesprites = false;

    public void checkSprites() {
        if (simplesprites) {
            return;
        }
        if (spritecheck != getY()) {
            putSprites(true, offset);
            spritecheck = getY();
        }
    }

    void checkSlider() {
        if (slider == null) {
            slider = new Slider();
            slider.setVisible(true);
            slider.slider.setMaximum(768);
            slider.slider.setMinimum(0);
        }
    }
    Slider slider;
    int[] ff = {
        0xF3, 0xED, 0x56, 0x31, 0xFF, 0xBF, 0x01, 0x83, 0xF7, 0xED, 0x49, 0x01, 0x00, 0xF4, 0xED, 0x49
    };

    public void checkCart(byte[] data) {
//        System.out.println(Util.dumpBytes(data, 0, 16));
        boolean check = true;
        for (int i = 0; i < ff.length; i++) {
            if ((data[i] & 0x0ff) != ff[i]) {
                check = false;
            }
        }
        fireandforget = check;
        System.out.println("Fire and Forget loaded:" + fireandforget);
    }
    boolean fireandforget = false;
    // TODO: WinAPE does some weird stuff here to suit Overflow Preview 3

    protected void endHSync() {
        if ((fireandforget) && InterruptLineCount < 5 && InterruptSyncCount == 0) {
            crtc.doAsicHsync(true);
        }
        if (outHSync) {
            modeCheck();
            super.hSyncEnd();
        }
        outHSync = false;
    }

    public void modeCheck() {
        if (screenMode != newMode) {
            setScreenMode(newMode & 0x03);
        }
    }
    int skipsprites;
    int vscroll;
    public static int verticalScroll;

    public int getScroll() {
        return verticalScroll;
    }

    public void ASIC_SetSoftScrollRegister(int value) {
        SoftScrollRegister = value & 0x0ff;
        horizontalScroll = ((SoftScrollRegister) & 0x0f);       // horizontal scrolling
        verticalScroll = (SoftScrollRegister >> 4) & 0x07;      // vertical scrolling
        crtc.setVerticalScroll(verticalScroll);
        JCPC.ui.Display.vscroll = "" + verticalScroll + " - " + horizontalScroll;
    }
    int[] lines = {
        0x00, 0x70, 0xe0, 0x150, 0x1c0, 0x230, 0x2a0, 0x310
    };

    @Override
    public void hSyncStart() {
        hSyncCount = 0;
        inHSync = true;
        renderer = syncRenderer;
    }

    @Override
    public void hSync() {
        ymax = crtc.getR(6) * 8 + ymin;
        if (render = rendering && (monitorLine >= -4 && monitorLine < lowlines - 4)) {
            offset = scanStart;
            scanStart += 768;
            if (((SoftScrollRegister & 0x080) << 1) == 0) {
                borderpixel = pixels[1];
            }
        }
        if (vSyncCount > 0) {
            if (--vSyncCount == 0) {
                super.vSyncEnd();
            }
        }
        scanStarted = false;
    }
    int borderpixel = 0;
    int maxline;
    int ticker;
    boolean tt;
    public boolean nosprites = false;

    public void putSprites(boolean force, int offset) {
        if (spritemem == null) {
            spritemem = (CPCMemory) cpc.getMemory();
        }
        if (cpc.getAsic().isLocked()) {
            return;
        }

        if (cpc.doTurbo) {
            tt = !tt;
            if (tt) {
                return;
            }
        }
        for (int spriteindex = 0; spriteindex < 16; spriteindex++) {
            renderSprite(spriteindex, force, offset);
        }
    }
    protected int horizontalScroll;

    void GateArray_Interrupt() {
        if (cpc.memory.plus) {
            /*
             * CPC+ mode
             */

            /*
             * if ASIC raster interrupts are not enabled...
             */
            if (!cpc.getAsic().ASIC_RasterIntEnabled()) {
                /*
                 * CPC+ mode. Mark this interrupt as a Raster int
                 */
                cpc.getAsic().ASIC_SetRasterInterrupt();

                /*
                 * generate a interrupt
                 */
                z80.Z80_SetInterruptRequest();
//                setInterruptMask(interruptMask | 0x80);
            }
            return;
        }
        /*
         * CPC Mode. Generate a interrupt
         */
        z80.Z80_SetInterruptRequest();
//        setInterruptMask(interruptMask | 0x80);
    }

    @Override
    public void hSyncEnd() {
        debug = cpc.getMode() != CPC.RUN;
        endHSync();
        if (++InterruptLineCount == 52) {
            InterruptLineCount = 0;
            GateArray_Interrupt();
//            GateArray_RasterInterruptRequest = true;
        }
        if (InterruptSyncCount > 0 && --InterruptSyncCount == 0) {
            if (InterruptLineCount >= 32) {
                GateArray_Interrupt();
//                GateArray_RasterInterruptRequest = true;
            }
            InterruptLineCount = 0;
        }

        renderer = vSyncCount > 0 ? syncRenderer : (crtc.isVDisp() && crtc.isHDisp() ? defRenderer : borderRenderer);
    }

    public void hDispEnd() {
        renderer = vSyncCount > 0 || crtc.isHSync() ? syncRenderer : borderRenderer;
    }
    int p;

    public void hDispStart() {
        renderer = vSyncCount > 0 || crtc.isHSync() ? syncRenderer : (crtc.isVDisp() ? defRenderer : borderRenderer);
    }

    public void setMonitorLine(int value) {
        offset += (value * 768);
    }

    public int getLine() {
        return monitorLine;
    }

    @Override
    public void vSyncStart() {
        super.vSyncStart();
        vSyncCount = 32;
        renderer = syncRenderer;
        InterruptSyncCount = 2;
        if (isBorder == null) {
            return;
        }
        ymin = crtc.getR(4) - crtc.getR(7) - 3;
        ymin *= 8;
//        ymin = crtc.getR(7) * 8-25*8;
        if ((ymin & 0x0100) == 0x0100) {
            ymin |= 0x0ff00;
        }
        if ((ymin & 0x08000) != 0) {
            ymin = -((0 - ymin) & 0x03f);
        }
        int d = 0;
        for (int i = 0; i < isBorder.length; i += 4) {
            if (!isBorder[i]) {
                d = i / 768;
                break;
            }
        }
        if (ymin >= 0 && d > ymin) {
            ymin = d;
        }
    }

    @Override
    public void vSyncEnd() {
    }
//    int[][] sprite = new int[16][];
    int spriteoffset;
    int spos;
    CPCMemory spritemem;
    public int[] xm = new int[16];
    public int[] ym = new int[16];
    int[] xpos = new int[16];
    int[] ypos = new int[16];
    int ymin, ymax, xmin, xmax;
    int sproffset;
    int pix;
    int crtcX, crtcY;
    int[] result = new int[4];

    public int[] getField() {
        result[0] = xmin;
        result[1] = xmax;
        result[2] = ymin * 2;
        result[3] = ymax * 2;
        return result;
    }
    int split;

    public int getX(int blockID) {
        return blockID % 768;
    }

    public int getY(int blockID) {
        return (blockID / 768) % lowlines;
    }

    public int getY() {
        return aline;
    }

    public void setY(int pos) {
        aline = getY(pos);
    }
    int aline;
    boolean srendered;
    int pixelcheck;
    boolean[] spriteput = new boolean[16];
    Thread draw;
    boolean spritesput = false;
    int bink = 16;

    boolean isScroll() {
        return ((SoftScrollRegister & 0x080) << 1) != 0;
    }
    int rasterline;
    int stepper;
    int oldra;
    int tsync;

    protected void putPixel(int pos, int value) {
        if (!rendered[pos]) {
            if (display.DEBUG_SPRITES) {
                display.ppixels[pos] = 0;
            }
        }
        if (pos % 768 == 0) {
            setY(pos);
            putSprites(true, pos);
        }
//        if (crtc.getLine() != oldra) {
//            pixelpos = pos;
//            putSprites(false);
//            oldra = crtc.getLine();
//        }
        pos += horizontalScroll;
        if (!rendered[pos] && pixels[pos] != value) {
            pixels[pos] = value;
        }
        if ((pos) % 768 < xmin + 16 && isScroll()) {
            pixels[pos] = inks[bink];
            rendered[pos] = true;
        }
        if ((pos) % 768 > xmax && isScroll()) {
            pixels[pos] = inks[bink];
            rendered[pos] = true;
        }
        if (isBorder[pos] && DEBUG_BORDER) {
            if (pos == 0) {
                dev = getBorder();
            }
            if (pixels[pos] == dev) {
                pixels[pos] = (pos % 8) < 4 ? 0xff0000 : 0;
            }
        }
    }
    boolean DEBUG_BORDER = false;
    int dev;
    boolean skipper = false;
//[01:57:18] Richard Wilson: for each new scan line (rastln change)
//[01:57:18] Richard Wilson: I pre-render all sprites in a composite AND/OR buffer
//[01:58:01] Richard Wilson: that's because WinAPE does 8/16/32 bit rendering
//[01:58:54] Richard Wilson: If sprite data or position changes during a raster line, I completely re-render all sprites (only if the sprite moved or changed on the current line)
//[01:59:10] Richard Wilson: but only the single row of the sprites
    int line;
    int pixelpos;

    public void renderSprite(final int spriteindex, boolean force, int pos) {
        if (nosprites) {
            return;
        }
        if (spritemem == null) {
            return;
        }
        spritemem.setSpritePalette(spriteindex);
        if (xm[spriteindex] == 0 || ym[spriteindex] == 0) {
            return;
        }
        line = ((pos / 768) % lowlines) - (cpc.getAsic().ASIC_RasterIntEnabled() ? 0 : force ? 0 : 1);
//        line = getY() - (cpc.getAsic().ASIC_RasterIntEnabled() ? 0 : force ? 0 : 1);

        if (line < 0) {
            return;
        }

        // Horizontal sprite repeat seems weird, so lets do a weird trick
        if (crtc.getReg(9) != 7 && pixelpos % 768 != 0) {
            xpos[spriteindex] = (spritemem.getSpriteX(spriteindex) + ((pixelpos % 768) & 0xfffffff8)) % 768;
        } else {
            xpos[spriteindex] = spritemem.getSpriteX(spriteindex) + xmin;
        }
        // Vertical sprite repeat: Not sure if I'm using the correct IF statement
        if (crtc.getReg(9) != 7) {
            ypos[spriteindex] = spritemem.getSpriteY(spriteindex) + line;
        } else {
            ypos[spriteindex] = spritemem.getSpriteY(spriteindex) + ymin;
        }
        spritemem.setSpriteData(spriteindex);
        if (line < ypos[spriteindex] || line > (ypos[spriteindex] + 16 * ym[spriteindex])) {
            return;
        }
        if (xpos[spriteindex] + 16 * xm[spriteindex] < 0) {
            return;
        }
        if (xm[spriteindex] == 0 || ym[spriteindex] == 0) {
            return;
        }

        spriteline = (line - ypos[spriteindex]);
        startoff = ((spriteline) / ym[spriteindex]) * 16;
        spriteoffset = 768 * (ypos[spriteindex]);
        spriteoffset += xpos[spriteindex];
        spriteoffset += spriteline * 768;
        try {
            sxpos = 0;
            while (sxpos < 16) {
                spritepixel = spritemem.sprdata[spriteindex][startoff + sxpos];
                if (spritepixel != -1234567890) {
                    xx = 0;
                    while (xx < xm[spriteindex]) {
                        renderoffset = spriteoffset + sxpos * xm[spriteindex] + xx;
                        if (!rendered[renderoffset]) {
                            if (!isBorder[renderoffset]) {
                                pixelcheck = xpos[spriteindex] + (sxpos * xm[spriteindex] + xx);
                                if (pixelcheck < 768 && pixelcheck > -1) {
                                    if (renderoffset >= 0 && renderoffset < pixels.length) {
                                        pixels[renderoffset] = spritepixel;
                                        if (display.DEBUG_SPRITES) {
                                            display.ppixels[renderoffset] = 0xff000000 + spritepixel;
                                        }
                                        rendered[renderoffset] = true;
                                    }
                                }
                            }
                        }
                        xx++;
                    }
                }
                sxpos++;
            }
        } catch (Exception e) {
        }
    }
    int sxpos;
    int xx;
    int spritepixel;
    int spriteline;
    int startoff;
    int renderoffset = 0;
    int r3;
    int count = 0;
    boolean is = true;

    @Override
    public void vSync(boolean interlace) {
        for (int i = 0; i < rendered.length; i++) {
            rendered[i] = false;
        }
        int off = 0;
        int line = 0;
        for (int i = 0; i < pixels.length; i++) {
            off++;
            if (off == 768) {
                off = 0;
                line++;
            }
            if (!isBorder[i]) {
                break;
            }
        }
        off = 0;
        line = 0;
        xmin = ((0x032 - crtc.getR(2)) * 16);
        r3 = crtc.getR(3) & 0x0f;
        if (r3 < 0x06) {
            xmin += r3 * 8;
        }
        r3 = crtc.getR(0) - 0x03f;
        xmin += r3 * 16;
        xmax = xmin + crtc.getR(1) * 16;
        scanStart = offset = 0;
        cpc.vSync();
        maxline = 0;
    }

    @Override
    public void vSync() {
        for (int i = 0; i < rendered.length; i++) {
            rendered[i] = false;
        }
//        borderHeight *= 2;
        scanStart = 0;
        try {
            cpc.vSync();
        } catch (Exception e) {
        }
    }

    @Override
    public void vDispStart() {
    }

    public void setMemory(byte[] value) {
        screenmemory = value;
    }

    public void setRendering(boolean value) {
        rendering = value;
        if (!rendering) {
            render = scanStarted = false;
        }
    }

    public Dimension getDisplaySize(boolean large) {
        return large ? FULL_DISPLAY_SIZE : HALF_DISPLAY_SIZE;
    }

    public void cursor() {
    }  // Not used on CPC

    protected abstract class Renderer {

        public void render() {
        }
    }

    protected class BorderRenderer extends Renderer {

        protected int ink;
        protected int width;

        public BorderRenderer(int ink, int width) {
            this.ink = ink;
            this.width = width;
        }

        @Override
        public void render() {
            if (pixels == null) {
                return;
            }
            if (isBorder == null || isBorder.length < 1) {
                isBorder = new boolean[pixels.length];
            }

            int pix = inks[ink];
            try {
                for (int i = 0; i < width; i++) {
                    if (offset + horizontalScroll < pixels.length) {
                        putPixel(offset, pix);
                    }
                    isBorder[offset] = true;
                    offset++;
                }
            } catch (Exception e) {
            }
        }
    }
    boolean hasscroll;
    int scrolline;
    int ispos;
    int[] vscrolls = {
        0, 0x10, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70
    };

    protected class FullRenderer extends Renderer {

        @Override
        public void render() {
            int addr = maTranslate[crtc.getMA()] + ((crtc.getRA()) << 11);
            int val = ((screenmemory[addr] & 0xff) << 4) + ((screenmemory[addr + 1] & 0xff) << 12);  // Base always even
            for (int i = 0; i < 16; i++) {
                isBorder[offset] = false;
                if (offset + horizontalScroll < pixels.length) {
                    putPixel(offset++, inks[fullMap[val++]]);
                }
            }
        }
    }

    protected class FullStartRenderer extends Renderer {

        @Override
        public void render() {
            try {
                endPix = 16 - (((hPos - HOFFSET) >> 12) & 0x0f);
                if (renderer == borderRenderer) {
                    int pix = inks[16];
//                    borval = pix;
                    for (int i = endPix; i < 16; i++) {
                        isBorder[offset] = true;
                        if (offset + horizontalScroll < pixels.length) {
                            putPixel(offset++, pix);
                        }
                    }
                } else if (renderer == defRenderer) {
                    int addr = maTranslate[crtc.getMA()] + ((crtc.getRA()) << 11);

                    int val = ((screenmemory[addr] & 0xff) << 4) + ((screenmemory[addr + 1] & 0xff) << 12) + endPix;  // Base always even
                    for (int i = endPix; i < 16; i++) {
                        isBorder[offset] = false;
                        if (offset + horizontalScroll < pixels.length) {
                            putPixel(offset++, inks[fullMap[val++]]);
                        }
                    }
                } else {
                    int pix = inks[32];
//                    borval = pix;
                    for (int i = endPix; i < 16; i++) {
                        isBorder[offset] = false;
                        if (offset + horizontalScroll < pixels.length) {
                            putPixel(offset++, pix);
                        }
                    }
                }
            } catch (Exception e) {
            }
        }
    }
    boolean skip;

    protected class FullEndRenderer extends Renderer {

        @Override
        public void render() {
            try {
                if (renderer == borderRenderer) {
                    int pix = inks[16];
                    for (int i = 0; i < endPix; i++) {
                        isBorder[offset] = true;
                        if (offset + horizontalScroll < pixels.length) {
                            putPixel(offset++, pix);
                        }
                    }
                } else if (renderer == defRenderer) {
                    int addr = maTranslate[crtc.getMA()] + ((crtc.getRA()) << 11);
                    int val = ((screenmemory[addr] & 0xff) << 4) + ((screenmemory[addr + 1] & 0xff) << 12);  // Base always even

                    for (int i = 0; i < endPix; i++) {
                        isBorder[offset] = false;
                        if (offset + horizontalScroll < pixels.length) {
                            putPixel(offset++, inks[fullMap[val++]]);
                        }
                    }

                } else {
                    int pix = inks[32];
                    for (int i = 0; i < endPix; i++) {
                        isBorder[offset] = false;
                        if (offset + horizontalScroll < pixels.length) {
                            putPixel(offset++, pix);
                        }
                    }

                }
            } catch (Exception e) {
            }
        }
    }

    public void resetInks() {
        for (int i = 0; i < 17; i++) {
            setInk(i, getInks(i));
        }
    }

    public void resetInkss() {
        for (int i = 0; i < 17; i++) {
            setInk(i, i);
        }
    }

    public void init() {
        crtc.init();
    }

    public int PEEK(int address) {
        return cpc.PEEK(address);
    }

    public void POKE(int address, int value) {
        cpc.POKE(address, value);
    }

    public static int putRGB(int r, int g, int b) {
        return (r << 16) | (g << 8) | b;
    }

    public boolean getOut() {
        return (endPix != 0);
    }

    public int getLineNumber() {
        return crtc.getLineNumber();
    }

    public int getLineNum() {
        return getY();
    }
}
