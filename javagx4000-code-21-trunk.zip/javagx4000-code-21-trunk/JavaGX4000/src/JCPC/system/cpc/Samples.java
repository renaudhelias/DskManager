/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JCPC.system.cpc;

/**
 * Title:        JavaCPC
 * Description:  The Java Amstrad CPC Emulator
 * Copyright:    Copyright (c) 2006-2010
 * Company:
 * @author
 * @version 6.8
 */
import java.io.*;
import java.net.URL;
import javax.sound.sampled.*;

/**
 * This enum encapsulates all the sound effects
 */
public enum Samples {
    MOTOR("JCPC/system/cpc/motor.wav"),
    SEEK("JCPC/system/cpc/seek.wav"),
    SEEKBACK("JCPC/system/cpc/seekback.wav"),
    TRACK("JCPC/system/cpc/track.wav"),
    TRACKBACK("JCPC/system/cpc/trackback.wav"),
    RELAIS("JCPC/system/cpc/relon.wav"),
    RELAISOFF("JCPC/system/cpc/reloff.wav"),
    TAPEMOTOR("JCPC/system/cpc/tapmotor.wav"),
    INSERT("JCPC/system/cpc/insert.wav");
    // Nested class for specifying volume
    public static enum Volume {
        MUTE, LOW, MEDIUM, HIGH
    }
    public static Volume volume = Volume.HIGH;

    public boolean nosamples = false;
    public static boolean quiet = false;
    // Each sound effect has its own clip, loaded with its own sound file.
    private Clip clip;

    // Constructor to construct each element of the enum with its own sound file.
    Samples(String soundFileName) {
        if (nosamples)
            return;
        try {
            // Use URL (instead of File) to read from disk and JAR.
            URL url = this.getClass().getClassLoader().getResource(soundFileName);
            // Set up an audio input stream piped from the sound file.
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(url);
            // Get a clip resource.
//            clip = AudioSystem.getClip();
            AudioFormat format = audioInputStream.getFormat();
            DataLine.Info info = new DataLine.Info(Clip.class, format);

            clip = (Clip) AudioSystem.getLine(info);
            // Open audio clip and load samples from the audio input stream.
            clip.open(audioInputStream);
        } catch (Exception e) {
            nosamples = true;
        }
    }

    // Play or Re-play the sound effect from the beginning, by rewinding.
    public void play() {
        if (quiet)
            return;
        if (nosamples)
            return;
        if (volume != Volume.MUTE) {
            if (clip.isRunning()) {
                clip.stop();   // Stop the player if it is still running
            }
            clip.setFramePosition(0); // rewind to the beginning
            clip.start();     // Start playing
        }
    }
    public void click() {
        if (volume != Volume.MUTE) {
            if (clip.isRunning()) {
                clip.stop();   // Stop the player if it is still running
            }
            clip.setFramePosition(0); // rewind to the beginning
            clip.start();     // Start playing
        }
    }

    public void loop() {
        if (quiet){
            this.SEEK.stop();
            this.TRACK.stop();
            this.SEEKBACK.stop();
            this.TRACKBACK.stop();
            return;
        }
        if (nosamples)
            return;
        if (volume != Volume.MUTE) {
            if (clip.isRunning()) {
                clip.stop();   // Stop the player if it is still running
            }
            clip.setFramePosition(0); // rewind to the beginning
            clip.loop(clip.LOOP_CONTINUOUSLY);     // Start playing
        }
    }
    public void turn() {
        if (volume != Volume.MUTE) {
            if (clip.isRunning()) {
                clip.stop();   // Stop the player if it is still running
            }
            clip.setFramePosition(0); // rewind to the beginning
            clip.loop(clip.LOOP_CONTINUOUSLY);     // Start playing
        }
    }

    public void loop2() {
        if (quiet){
            this.SEEK.stop();
            this.TRACK.stop();
            this.SEEKBACK.stop();
            this.TRACKBACK.stop();
            return;
        }
        if (nosamples)
            return;
        if (volume != Volume.MUTE) {
            if (!clip.isRunning()) {
                clip.setFramePosition(0); // rewind to the beginning
                clip.loop(clip.LOOP_CONTINUOUSLY);     // Start playing
            }
        }
    }
    public void turn2() {
        if (nosamples)
            return;
        if (volume != Volume.MUTE) {
            if (!clip.isRunning()) {
                clip.setFramePosition(0); // rewind to the beginning
                clip.loop(clip.LOOP_CONTINUOUSLY);     // Start playing
            }
        }
    }

    public void stop() {
        if (nosamples)
            return;
        if (clip.isRunning()) {
            clip.stop();   // Stop the player if it is still running
        }
        clip.setFramePosition(0); // rewind to the beginning
        clip.stop();     // Start playing
    }

    // Optional static method to pre-load all the sound files.
    static void init() {
        values(); // calls the constructor for all the elements
    }
}

