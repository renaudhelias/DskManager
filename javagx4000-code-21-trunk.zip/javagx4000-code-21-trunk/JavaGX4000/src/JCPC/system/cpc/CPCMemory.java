package JCPC.system.cpc;

import java.util.Calendar;

import JCPC.core.*;
import JCPC.core.device.Device;
import JCPC.core.device.memory.*;
import java.awt.image.*;
import JCPC.core.device.crtc.Basic6845;

/**
 * Title: JavaCPC Description: The Java Amstrad CPC Emulator Copyright:
 * Copyright (c) 2006-2010 Company:
 *
 * @author Richard & Markus
 * @version 6.8
 */
/**
 * Actual memory mapping from OUT instructions performed by the Gate Array.
 *
 * Memory is allocated in 8K blocks.
 */
public class CPCMemory extends DynamicMemory {

    public void setCartridge(byte[] in) {
    }
    protected Calendar cal = Calendar.getInstance();
    // used for Patch
    protected int ramtype = 0;
    //
    public static final int TYPE_64K = 0;
    public static final int TYPE_128K = 0x01;
    public static final int TYPE_256K = 0x0f;
    public static final int TYPE_SILICON_DISC = 0xf0;
    public static final int TYPE_128_SILICON_DISC = 0xf1;
    public static final int TYPE_512K = 0xff;
    protected int[] baseRAM = new int[8];
    protected int[] readMap = new int[8];
    protected int[] writeMap = new int[8];
    protected int ramTYPE;
    protected boolean lower = true;
    protected boolean upper = true;
    public boolean plus = false;
    protected int upperROM = 0;
    protected int plusROM = 0;
    protected int bankRAM = -1;
    public static final int BASE_RAM = 0;                        // base 64k ram
    public static final int BASE_LOWROM = BASE_RAM + 9;          // 16k lower rom
    public static final int BASE_UPROM = BASE_LOWROM + 1;        // 16*16k upper rom
    public static final int BASE_CART = BASE_UPROM + 16;         // 32*16k cartridge rom
    public static final int BASE_ASIC = BASE_CART + 32;          // 16k asic ram
    public static final int BASE_MULTIFACE = BASE_ASIC + 1;
    CPC cpc;
    GateArray gateArray;

    public CPCMemory(int type, CPC cpc, GateArray gateArray) {
        super("CPC Memory", 0x10000, BASE_MULTIFACE + 1);
        this.cpc = cpc;
        this.gateArray = gateArray;
        ramtype = type;
        setRAMType(type);  // Always happens first, first 64K always gets mapped in first
        // allocate
        reset();
    }

    public int[] getBaseRam() {
        return baseRAM;
    }

    public int getBaseAsic() {
        return BASE_ASIC;
    }
    public boolean asiclocked = true;
    protected boolean asicRamActive = false;
    int lowRomLoc, lowRomPage;
    int red, green, blue;

    public int readASIC(int address) {
        return mem[baseAddr[BASE_ASIC] + (address & 0x03fff)] & 0x0ff;
    }

    public void writeASIC(int address, int value) {
        mem[baseAddr[BASE_ASIC] + (address & 0x03fff)] = (byte) value;
    }

    public void setSpritePalette(int i) {
        blue = gateArray.LUM[(readASIC(0x6422 + i * 2)) & 0x0f];
        red = gateArray.LUM[((readASIC(0x6422 + i * 2) >> 4)) & 0x0f];
        green = gateArray.LUM[(readASIC(0x6423 + i * 2)) & 0x0f];
        SpritePalette[i] = (red << 16) | (green << 8) | blue;
    }

//    public void setSpritePalette(int index, int value) {
//        if ((index & 1) == 0){
//        blue = (value << 4) & 0x0ff;
//        red = ((value >> 4) << 4) & 0x0ff;}
//        else
//        green = (value << 4) & 0x0ff;
//        SpritePalette[index>>1] = (red << 16) | (green << 8) | blue;
//        for (int i = 0; i < 16; i++) {
//            gateArray.spritechanged[i]=true;
////            setSprite(i);
////            gateArray.renderSprites(i);
//        }
//    }
    public void eraseSprite(int index) {
        spriteX[index] = -2000;
        spriteY[index] = -2000;
        xmag[index] = 0;
        ymag[index] = 0;
    }
    byte[] posbuf = new byte[2];
    int[] spriteX = new int[16];
    int[] spriteY = new int[16];
    int spritepos;
//    int sb, sc;
    int posx, posy;

    public void setSpritePos2(int index) {
        spritepos = 0x6000 + (index * 0x08);
        posbuf[0] = (byte) (readASIC(spritepos) & 0x0ff);
        posbuf[1] = (byte) (readASIC(spritepos + 1) & 0x0ff);
        if ((posbuf[1] & 0x03) == 3) {
            posbuf[1] = (byte) 0xff;
        } else {
//            posbuf[1] = (byte) (posbuf[1] & 0x03);
        }

        spriteX[index] = getWord(posbuf, 0);
//        spriteX[index] = (readASIC(spritepos)) + ((readASIC(spritepos+1)&0x03) << 8);
        if ((spriteX[index] & 0x0300) == 0x0300) {
            spriteX[index] |= 0x0ff00;
        }
        if ((spriteX[index] & 0x08000) != 0) {
            spriteX[index] = -((0 - spriteX[index]) & 0x0ffff);
        }
//
        posbuf[0] = (byte) readASIC(spritepos + 2);
        posbuf[1] = (byte) readASIC(spritepos + 3);
        if ((posbuf[1] & 0x01) == 1) {
            posbuf[1] = (byte) 0x0ff;
        } else {
//            posbuf[1] = (byte) (posbuf[1] & 0x01);
        }
        spriteY[index] = getWord(posbuf, 0) & 0x01ff;
//        spriteY[index] = (readASIC(spritepos+2)) + ((readASIC(spritepos+3)&0x01) << 8);
//        if (spriteY[index] > 0x01c0) {
//            spriteY[index] = -0x1ff + spriteY[index];
//        }
        if ((spriteY[index] & 0x0100) == 0x0100) {
            spriteY[index] |= 0x0ff00;
        }
        if ((spriteY[index] & 0x08000) != 0) {
            spriteY[index] = -((0 - spriteY[index]) & 0x0ffff);
        }
    }

    public void setSpritePos(int index) {
        spritepos = 0x6000 + (index * 0x08);
        spriteX[index] = ((readASIC(spritepos)) | ((readASIC(spritepos + 1)) << 8)) & 0x03ff;
        if ((spriteX[index] & 0x0300) == 0x0300) {
            spriteX[index] |= 0x0ff00;
        }
        if ((spriteX[index] & 0x08000) != 0) {
            spriteX[index] = -((0 - spriteX[index]) & 0x0ffff);
        }
        spriteY[index] = ((readASIC(spritepos + 2)) | ((readASIC(spritepos + 3)) << 8)) & 0x01ff;
        if ((spriteY[index] & 0x0100) == 0x0100) {
            spriteY[index] |= 0x0ff00;
        }
        if ((spriteY[index] & 0x08000) != 0) {
            spriteY[index] = -((0 - spriteY[index]) & 0x0ffff);
        }
    }

    public void setSpriteX(int index, int value) {
        spriteX[index] = value;
    }

    public void setSpriteY(int index, int value) {
        spriteY[index] = value;
    }

    public void setMag(int index, int value) {
        int mag = value & 0x0f;
        xmag[index] = magnify[((mag >> 2) & 0x03)];
        ymag[index] = magnify[(mag & 0x03)];
//        gateArray.spritechanged[index] = true;
        gateArray.xm[index] = xmag[index];
        gateArray.ym[index] = ymag[index];
    }
    int[] magnify = {
        0, 1, 2, 4
    };
    int[] xmag = new int[16];
    int[] ymag = new int[16];
//    int mag[] = new int[16];

    public int getSpriteX(int index) {
        return spriteX[index];
    }

    public int getSpriteY(int index) {
        return spriteY[index];
    }
    protected int[] SpritePalette = new int[16];
    int[][] sprdata = new int[16][0x100];

    public int[] getSprite(int index) {
        return sprdata[index];
    }

//    public void setAllSprites() {
//        for (int i = 0; i < 16; i++) {
//            setSprite(i);
////            setMag(i);
//        }
//    }
    public void setSpriteData(int index) {
        int val;
        for (int i = 0; i < sprdata[index].length; i++) {
            val = spriteram[(index * 0x0100) + i] & 0x0f;
            if (val != 0) {
                sprdata[index][i] = SpritePalette[val - 1];
            } else {
                sprdata[index][i] = -1234567890;
            }
        }
//        putSpriteImg(index);
    }

    public void writeSpriteData(int address, int value) {
        spriteram[address] = value;
//        writeByte(address+0x04000,value);
    }
    int[] spriteram = new int[0x01000];

    public void destroySprite(int index) {
        spritepos = 0x4000 + (index * 0x0100);
        for (int i = 0; i < 0x0100; i++) {
            spriteram[(index * 0x0100 + i)] = Util.random(0x0f);
        }
        for (int i = 0; i < sprdata[index].length; i++) {
            writeASIC(i + spritepos, Util.random(0x0f));
        }
    }

    public void putSpriteImg(int index) {
        BufferedImage spriteI = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);
        int xoff = 0;
        int yoff = 0;
        for (int y = 0; y < 16; y ++) {
            for (int x = 0; x < 16; x++) {
                int rgb = sprdata[index][yoff * 16 + xoff];
                if (rgb == -123456789) {
                    rgb = 0x00ffffff;
                } else {
                    rgb += 0xFF000000;
                }
                xoff++;
                spriteI.setRGB(x, y, rgb);
            }
            xoff = 0;
            yoff++;
        }
        try {
            spriteImg[index] = new BufferedImage(16 * (xmag[index] + 1), 16 * (ymag[index] + 1) * 2, BufferedImage.TYPE_INT_ARGB);
            spriteImg[index].getGraphics().drawImage(spriteI, 0, 0, 16 * xmag[index], 16 * ymag[index] * 2, null);
        } catch (Exception e) {
        }
    }
    public BufferedImage[] spriteImg = new BufferedImage[16];

    public void pluspalette(int ink) {
        blue = readASIC(0x6400 + ink * 2) & 0x0f;
        red = (readASIC(0x6400 + ink * 2) >> 4) & 0x0f;
        green = readASIC(0x6401 + ink * 2) & 0x0f;
        gateArray.setPlusPalette(ink, red, green, blue);
    }

    public void setPlus(boolean pl) {
        plus = pl;
    }
    // not used, just added.
    String[] CheckInfo = {
        "reset", "setROM", "setLowerEnabled", "setMultiEnabled",
        "setUpperEnabled", "setUpperROM", "setRamBank"
    };

    public void reset() {
        lowRomLoc = 0;
        lowRomPage = 0;
        for (int i = 0; i < 0x010000; i++) {
            mem[i] = (byte) 0;
            writeASIC(i, 0x0b0);
        }
        killSprites();
        for (int i = 0; i < 16; i++) {
            setMag(i, 0);
        }
        System.out.println("Memory reset!");
        setRAMBank(0xc0);
        asiclocked = true;
        asicRamActive = false;
        upper = false;
        lower = true;
        upperROM = 0;
        plusROM = 0;
        this.enableAsicRam(asicRamActive, lowRomLoc, lowRomPage);
        try {
            cpc.psg.resetRegisters();
        } catch (Exception e) {
        }
//        System.out.println(BASE_MULTIFACE);
        remap();
//        System.out.println(Util.dumpBytes(mem));
    }

    public void killSprites() {
        System.out.println("Destroying spritememory");
        for (int i = 0; i < 16; i++) {
            destroySprite(i);
//        mag[index] = 0;
        }
    }

    public void setRAMType(int value) {
        ramTYPE = value;
        getMem(BASE_RAM, 64 * 1024);
        for (int i = BASE_RAM + 1; i < BASE_RAM + 9; i++) {
            if ((ramTYPE & 0x01) != 0) {
                getMem(i, 64 * 1024);
            } else {
                freeMem(i, 64 * 1024);
            }
            ramTYPE >>= 1;
        }
        getMem(BASE_ASIC, 16 * 1024);
        getMem(BASE_MULTIFACE, 16 * 1024);
    }

    public int getRAMType() {
        return ramtype;
    }
    boolean lowerROMInserted = false;

    public void setLowerROM(byte[] data) {
        setROM(BASE_LOWROM, data);
    }

    public void setMultiROM(byte[] data) {
        setROM(BASE_MULTIFACE, data);
    }

    public void setUpperROM(int rom, byte[] data) {
        setROM(BASE_UPROM + (rom & 0x0f), data);
    }

    public void setPlusROM(int rom, byte[] data) {
        lowerROMInserted = setROM(BASE_CART + rom, data);
    }

    protected boolean setROM(int base, byte[] data) {
        if (data == null || data.length == 0) {
            freeMem(base, 16 * KB);
            return false;
        } else {
            base = getMem(base, 16 * KB);
            System.arraycopy(data, 0, mem, base, Math.min(16 * KB, data.length));
            return true;
        }
    }

    public void setLowerEnabled(boolean value) {
//        System.out.println("Lower is " + value);
        if (lower != value) {
            lower = value;
            remap();
        }
    }

    public void setUpperEnabled(boolean value) {
        if (upper != value) {
            upper = value;
            remap();
        }
    }

    public boolean getUpperEnabled() {
        return upper;
    }
    boolean DEBUG_UPPER = false;
    boolean useplus;

//    public void writePort(int port, int value){
//        setUpperROM(value);
//    }
    public void setUpperROM(int value) {
        useplus = false;
        value &= 0x0ff;
        if (isSecondaryRom) {
            value &= 0x0f;
            if (upperROM != value) {
                upperROM = value;
                remap();
            }
            return;
        }
        if (value > 0x7f) {
            useplus = true;
            value &= 0x1f;
            if (DEBUG_UPPER) {
                System.err.println("plusmap:" + Util.hex((byte) value));
            }
            plusROM = value;
        } else {
            if (plus) {
                useplus = true;
                value &= 0x0f;
                if (DEBUG_UPPER) {
                    System.err.println("normalmap:" + Util.hex((byte) value));
                }
                if (value == 7) {
                    value = 3;
                } else {
                    value = 1;
                }
                plusROM = value;
            } else {
                useplus = false;
                upperROM = value;
            }
        }
        remap();
    }

    public int getUpperROM() {
        return upperROM;
    }

    public int getPlusROM() {
        return plusROM;
    }

    public void setRAMBank(int value) {
        value &= 0x3f;
        if (bankRAM != value) {
            bankRAM = value;
            remapRAM();
        }
    }

    public int getRAMBank() {
        return bankRAM | 0xc0;
    }

    public void remapRAM() {
        int mask = 0;
        boolean enable128k = false;
        boolean enable256k = false;
        boolean silicondiskenabled = false;
        if (ramtype == TYPE_128K || ramtype == TYPE_128_SILICON_DISC) {
            enable128k = true;
        }
        if (ramtype == TYPE_256K) {
            enable256k = true;
        }
        if (ramtype == TYPE_128_SILICON_DISC || ramtype == TYPE_SILICON_DISC) {
            silicondiskenabled = true;
        }
        if (enable128k) {
            mask |= 0x07;
        }
        if (enable256k) {
            mask |= 0x01f;
        }
        if (silicondiskenabled) {
            mask |= 0x3f;
        }
        if (mask != 0) {
            bankRAM = bankRAM & mask;
        }
        int bankBase = ((bankRAM & 0x38) >> 3) + BASE_RAM + 1;
        bankBase = baseAddr[bankBase];
        if (bankBase == -1) {             // 64K block not available
            bankBase = baseAddr[BASE_RAM];
            bankRAM = 0;
        }

        int base = (bankRAM & 0x07) == 2 ? bankBase : baseAddr[BASE_RAM];   // 0xc2, 0xca etc.
        for (int i = 0; i < 8; i++) {
            baseRAM[i] = base + i * 0x2000;

        }
        if ((bankRAM & 0x05) == 0x01) {        // 0xc1, 0xc3, 0xc9, 0xcb etc.
            baseRAM[7] = (baseRAM[6] = bankBase + 0xc000) + 0x02000;
            if ((bankRAM & 0x02) == 0x02) {      // 0xc3, 0xcb etc. Maps normal 0xc000 to 0x4000
                baseRAM[3] = (baseRAM[2] = base + 0xc000) + 0x2000;
            }
        } else if ((bankRAM & 0x04) == 0x04) {   // 0xc4, 0xc5, 0xc6, 0xc7, 0xcc, 0xcd etc.
            baseRAM[3] = (baseRAM[2] = bankBase + (bankRAM & 0x03) * 0x4000) + 0x2000;
        }
        if (asicRamActive) {
            baseRAM[3] = (baseRAM[2] = baseAddr[BASE_ASIC]) + 0x02000;
        }
        remap();
    }

    public int readByte(int address) {
        try {
            return mem[readMap[address >> 13] + (address & 0x1fff)] & 0xff;
        } catch (Exception e) {
            return 0;
        }
    }

    public byte readLowByte(int address) {
        return mem[baseAddr[BASE_RAM] + address];
    }
    public int selInk;
    int oldInk;
    int spos;

    public boolean getASICActive() {
        return (baseRAM[2] == baseAddr[BASE_ASIC] && baseRAM[3] == (baseAddr[BASE_ASIC] + 0x02000));
    }
    int oldd = -5;
    int div = 0;

    public int writeByte(int address, int value) {
        value &= 0x0ff;
        if (asicRamActive) {
            if (address > 0x3fff && address < 0x8000) {
                if (address > 0x63ff && address < 0x06422 + 32) {
                    if ((address & 1) != 0) {
                        value &= 0x0f;
                    }
                }
                if (address > 0x03fff && address < 0x05000) {
                    int d = (address - 0x4000) / 0x0100;
//                    gateArray.spritechanged[d] = true;
                    spriteram[address - 0x04000] = value & 0x0f;
//                    int k = (address - 0x04000) % 256;
//                    if (k==255) {
//                        this.setSpriteData(d);
//                        gateArray.renderSprites(d, true);
//                    }
                }
                writeASIC(address, value);
                cpc.getAsic().ASIC_WriteRam(address, value);
                if (address > 0x63ff && address <= 0x6400 + 34) {
                    pluspalette((address - 0x06400) >> 1);
                }
//                if (address >= 0x6000 && address < 0x6080) {
//                    int d = (address - 0x6000) / 8;
//                        this.setSpriteData(d);
//                }
            }
        }
        mem[writeMap[address >> 13] + (address & 0x1fff)] = (byte) value;
        return value & 0xff;
    }

    public int writeByte(int address, int value, int forcedbank, boolean forced) {
        if (address > 0x3fff && address < 0x8000) {
            int g = getRAMBank();
            setRAMBank(forcedbank);
            try {
                mem[writeMap[address >> 13] + (address & 0x1fff)] = (byte) value;
            } catch (Exception e) {
            }
            int b = value & 0xff;
            setRAMBank(g);
            return b;
        } else {
            return writeByte(address, value);
        }
    }

    public void poke(int address, int value) {
        mem[address] = (byte) value;
    }
    int delay;

    public void remap() {
        mapRAM();
        mapROMs();
    }

    public int[] ReadMap() {
        return readMap;
    }

    protected void mapRAM() {
        for (int i = 0; i < baseRAM.length; i++) {
            readMap[i] = baseRAM[i];
            writeMap[i] = baseRAM[i];
        }
        if (asicRamActive) {
            writeMap[3] = readMap[3] = (writeMap[2] = readMap[2] = baseAddr[BASE_ASIC]) + 0x02000;
        }
    }
    boolean DEBUG_MF2 = false;
    int[] lowRom = {
        0, 0x4000, 0x8000
    };

    public void enableAsicRam(boolean asicRamActive, int lowRomLoc, int lowRomPage) {
        this.asicRamActive = asicRamActive;
        this.lowRomLoc = lowRomLoc;
        this.lowRomPage = lowRomPage;
        remapRAM();
        remap();
    }
    boolean DEBUG_LOWER = false;
    protected boolean isSecondaryRom = false;

    public void setSecondaryRomMapping(boolean rom) {
        isSecondaryRom = rom;
    }

    protected void mapROMs() {
        int addr;
        if (isSecondaryRom) {
            if (lower && (addr = baseAddr[BASE_LOWROM]) != -1) {
                readMap[0] = addr;
                readMap[1] = addr + 0x2000;
            }

            if (upper) {
                addr = baseAddr[BASE_UPROM + upperROM];
                if (addr == -1) {
                    addr = baseAddr[BASE_UPROM];
                }
                if (addr != -1) {
                    readMap[6] = addr;
                    readMap[7] = addr + 0x2000;
                }
            }
            return;
        }
        // TODO: This does not support CPC Plus Cartridge or ROM Mapping
        // or multiface
        if (!plus && lower && (addr = baseAddr[BASE_LOWROM]) != -1) {

            readMap[0] = addr;
            readMap[1] = addr + 0x2000;
        }
        if (plus && lower) {
            if (DEBUG_LOWER) {
                System.err.println("plusROM lower = " + plusROM);
            }
            addr = baseAddr[BASE_CART + (lowRomPage)];
            if (addr == -1) {
                addr = baseAddr[BASE_CART];
            }
            if (addr != -1) {
                readMap[lowRomLoc] = addr;
                readMap[lowRomLoc + 1] = addr + 0x2000;
            }
        }
        if (upper && !useplus) {
            addr = baseAddr[BASE_UPROM + upperROM];
            if (addr == -1) {
                addr = baseAddr[BASE_UPROM];
            }
            if (addr != -1) {
                readMap[6] = addr;
                readMap[7] = addr + 0x2000;
            }
        }
        if (upper && useplus) {
            addr = baseAddr[BASE_CART + plusROM];
            if (addr == -1) {
//                System.err.println(plusROM);
                addr = baseAddr[BASE_CART];
            }
            if (addr != -1) {
                readMap[6] = addr;
                readMap[7] = addr + 0x2000;
            }
        }
//        try{
//            GateArray.cpc.getAsic().setModeAndROMEnable2();
//        } catch (Exception e){}
    }
    int oldval;

    public int readPort(int port) {
        cal = Calendar.getInstance();
        int result = 0xFF;
        if (port == 0xFEFE) { /*
             * Emulator ID
             */
            result = 0xA0;
        }
        return result;
    }

    public int readByte(int address, Object config) {
        return readByte(address);
    }
}
