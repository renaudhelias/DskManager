/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JCPC.system.cpc;

/**
 *
 * @author Markus
 */
public class GraphicsDecoder {

    protected final void decodeFull(byte[] map, int offs, int mode, int b) {
        switch (mode) {
            case 0:
                map[offs] = map[offs + 1] = map[offs + 2] = map[offs + 3] =
                        (byte) (((b & 0x80) >> 7) | ((b & 0x08) >> 2) | ((b & 0x20) >> 3) | ((b & 0x02) << 2));
                map[offs + 4] = map[offs + 5] = map[offs + 6] = map[offs + 7] =
                        (byte) (((b & 0x40) >> 6) | ((b & 0x04) >> 1) | ((b & 0x10) >> 2) | ((b & 0x01) << 3));
                break;

            case 1:
                map[offs] = map[offs + 1] = (byte) (((b & 0x80) >> 7) | ((b & 0x08) >> 2));
                map[offs + 2] = map[offs + 3] = (byte) (((b & 0x40) >> 6) | ((b & 0x04) >> 1));
                map[offs + 4] = map[offs + 5] = (byte) (((b & 0x20) >> 5) | (b & 0x02));
                map[offs + 6] = map[offs + 7] = (byte) (((b & 0x10) >> 4) | ((b & 0x01) << 1));
                break;

            case 2:
                map[offs++] = (byte) ((b & 0x80) >> 7);
                map[offs++] = (byte) ((b & 0x40) >> 6);
                map[offs++] = (byte) ((b & 0x20) >> 5);
                map[offs++] = (byte) ((b & 0x10) >> 4);
                map[offs++] = (byte) ((b & 0x08) >> 3);
                map[offs++] = (byte) ((b & 0x04) >> 2);
                map[offs++] = (byte) ((b & 0x02) >> 1);
                map[offs] = (byte) (b & 0x01);
                break;

            case 3:
                map[offs] = map[offs + 1] = map[offs + 2] = map[offs + 3] = (byte) (((b & 0x80) >> 7) | ((b & 0x08) >> 2));
                map[offs + 4] = map[offs + 5] = map[offs + 6] = map[offs + 7] = (byte) (((b & 0x40) >> 6) | ((b & 0x04) >> 1));
                break;
        }
    }
//
//    protected final void decodeHalf(byte[] map, int offs, int mode, int b) {
//        switch (mode) {
//            case 0:
//                map[offs] = map[offs + 1] = (byte) (((b & 0x80) >> 7) | ((b & 0x08) >> 2) | ((b & 0x20) >> 3) | ((b & 0x02) << 2));
//                map[offs + 2] = map[offs + 3] = (byte) (((b & 0x40) >> 6) | ((b & 0x04) >> 1) | ((b & 0x10) >> 2) | ((b & 0x01) << 3));
//                break;
//
//            case 1:
//                map[offs++] = (byte) (((b & 0x80) >> 7) | ((b & 0x08) >> 2));
//                map[offs++] = (byte) (((b & 0x40) >> 6) | ((b & 0x04) >> 1));
//                map[offs++] = (byte) (((b & 0x20) >> 5) | (b & 0x02));
//                map[offs] = (byte) (((b & 0x10) >> 4) | ((b & 0x01) << 1));
//                break;
//
//            case 2:
//                map[offs++] = (byte) ((b & 0x80) >> 7);
//                map[offs++] = (byte) ((b & 0x20) >> 5);
//                map[offs++] = (byte) ((b & 0x08) >> 3);
//                map[offs] = (byte) ((b & 0x02) >> 1);
//                break;
//
//            case 3:
//                map[offs] = map[offs + 1] = (byte) (((b & 0x80) >> 7) | ((b & 0x08) >> 2));
//                map[offs + 2] = map[offs + 3] = (byte) (((b & 0x40) >> 6) | ((b & 0x04) >> 1));
//                break;
//        }
//    }
}
