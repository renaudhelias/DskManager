/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JCPC.system.cpc.plus;

/**
 *
 * @author Markus
 */
public class ASIC_DATA {
    /*
     * interrupt vector
     */

    int ASIC_InterruptVector = 0x0ff;
    /*
     * raster interrupt line
     */
    int ASIC_RasterInterruptLine;
    /*
     * soft scroll
     */
    int ASIC_SoftScroll;
    /*
     * raster split line
     */
    int ASIC_RasterSplitLine;
    int InternalDCSR;
    int ASIC_DCSR2;
    public ASIC_SPRITE_INFO Sprites[] = {
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),
        new ASIC_SPRITE_INFO(),};

    public class SPRITE_X {

        public int SpriteX_Bl;
        public int SpriteX_Bh;

        public void writeAddr_W(int word) {
            SpriteX_Bl = (word & 0xff);
            SpriteX_Bh = ((word >> 8) & 0x0ff);
        }

        public int getAddr_W() {
            return (SpriteX_Bl & 0xff) | ((SpriteX_Bh << 8) & 0xff00);
        }
    }

    public class SPRITE_Y {

        public int SpriteY_Bl;
        public int SpriteY_Bh;

        public void writeAddr_W(int word) {
            SpriteY_Bl = (word & 0xff);
            SpriteY_Bh = ((word >> 8) & 0x0ff);
        }

        public int getAddr_W() {
            return (SpriteY_Bl & 0xff) | ((SpriteY_Bh << 8) & 0xff00);
        }
    }

    public class ASIC_SPRITE_INFO {
        public SPRITE_X SpriteX = new SPRITE_X();
        public SPRITE_Y SpriteY = new SPRITE_Y();
        public int SpriteX_W;
        ASIC_ADDR SpriteX_B = new ASIC_ADDR();
        ASIC_ADDR SpriteY_W = new ASIC_ADDR();
        ASIC_ADDR SpriteY_B = new ASIC_ADDR();
        public int SpriteMag;
        public int[] pad = new int[3];
    }
}
