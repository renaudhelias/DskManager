/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JCPC.system.cpc.plus;

/**
 *
 * @author Markus
 */
public class ASIC_ADDR {

    public addrb Addr_B = new addrb();

    public void writeAddr_W(int word) {
        Addr_B.l = (word & 0xff);
        Addr_B.h = ((word >> 8) & 0x0ff);
    }
    class addrb {
        public int l;
        public int h;
    }

    public int getAddr_W() {
        return (Addr_B.l & 0xff) | ((Addr_B.h << 8) & 0xff00);
    }
}
