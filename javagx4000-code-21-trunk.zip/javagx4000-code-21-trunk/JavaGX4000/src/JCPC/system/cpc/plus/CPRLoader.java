/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JCPC.system.cpc.plus;

import JCPC.core.Util;
import JCPC.core.device.Device;
import java.net.*;
import java.awt.*;
import java.io.*;

/**
 *
 * @author Markus
 */
public class CPRLoader {

    protected byte[][] cprdata;
    public boolean DEBUG = false;

    public static void main(String[] args) {
        CPRLoader load = new CPRLoader();
        load.DEBUG = true;
        load.OpenCPR2();
    }

    public void OpenCPR() {
        String filename = null;
        try {
            FileDialog filedia = new FileDialog((Frame) new Frame(), "Open CPR cartridge", FileDialog.LOAD);
            filedia.setFile("*.CPR; *.BIN");
            filedia.setVisible(true);
            filename = filedia.getFile();
            if (filename != null) {
                filename = filedia.getDirectory() + filedia.getFile();
            }

        } catch (Exception e) {
            System.err.println("Load failed...");
            return;
        }
        if (filename == null) {
            filename = ("CPC_PLUS.CPR");
            return;
        }
        openCPR(filename);
    }

    public void OpenCPR2() {
        String filename = null;
        try {
            FileDialog filedia = new FileDialog((Frame) new Frame(), "Open CPR cartridge", FileDialog.LOAD);
            filedia.setFile("*.CPR; *.BIN");
            filedia.setVisible(true);
            filename = filedia.getFile();
            if (filename != null) {
                filename = filedia.getDirectory() + filedia.getFile();
                openCPR2(filename);
            } else {
                System.exit(0);
            }

        } catch (Exception e) {
            System.err.println("Load failed...");
            return;
        }
        if (filename == null) {
            filename = ("CPC_PLUS.CPR");
            return;
        }
    }

    public void openCPR(String filename) {
        File t = new File(filename);
        try {
            BufferedInputStream bin = new BufferedInputStream(new FileInputStream(t));
            byte[] data = new byte[bin.available()];
            bin.read(data);
            bin.close();
            readCPR(data, filename);
        } catch (Exception e) {
        }
    }

    public void openCPR2(String filename) {
        File t = new File(filename);
        try {
            BufferedInputStream bin = new BufferedInputStream(new FileInputStream(t));
            byte[] data = new byte[bin.available()];
            bin.read(data);
            bin.close();
            CPR2BIN(data, filename);
            OpenCPR2();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void openCPR(URL u) {
        try {
            URLConnection uc = u.openConnection();
            String contentType = uc.getContentType();
            int contentLength = uc.getContentLength();
            if (contentType.startsWith("text/") || contentLength == -1) {
                throw new IOException("This is not a binary file.");
            }

            InputStream raw = uc.getInputStream();
            InputStream in = new BufferedInputStream(raw);
            byte[] data = new byte[contentLength];
            int bytesRead = 0;
            int offset = 0;
            while (offset < contentLength) {
                bytesRead = in.read(data, offset, data.length - offset);
                if (bytesRead == -1) {
                    break;
                }
                offset += bytesRead;
            }
            in.close();

            if (offset != contentLength) {
                throw new IOException("Only read " + offset
                        + " bytes; Expected " + contentLength + " bytes");
            }
            readCPR(data, null);
        } catch (Exception e) {
            System.err.println("File not loadable / not found:" + u.getFile());
//            e.printStackTrace();
        }

    }
    protected boolean loaded[] = new boolean[32];
    protected String CPRHeader = "RIFF";
    protected String CPRIdentifier = "AMS!";
    protected int CPRBegin = 0x10;
    protected int CPRSize;

    public byte[] getCPR() {
        JCPC.system.cpc.GateArray.cpc.getGateArray().checkCart(cpr);
        return cpr;
    }

    public byte[] getData(int index) {
        try {
            return cprdata[index];
        } catch (Exception e) {
            return null;
        }
    }
    byte[] cpr = new byte[1024 * 512];

    public void readCPR(byte[] data, String filename) {
        boolean store = false;
        if (cprdata == null) {
            cprdata = new byte[32][];
        }
        if (CPRHeader.equals(new String(data, 0, CPRHeader.length()).toUpperCase())) {
            if (CPRIdentifier.equals(new String(data, 8, CPRIdentifier.length()).toUpperCase())) {
                for (int i = 0; i < 32; i++) {
                    loaded[i] = false;
                }
                CPRSize = Device.getDWord(data, 0x04);
                for (int i = 0; i < 32; i++) {
                    cprdata[i] = null;
                }
                int pos = 0x0c;
                while (pos < data.length) {
                    try {
                        byte check1 = data[pos++];
                        byte check2 = data[pos++];
                        byte index1 = data[pos++];
                        byte index2 = data[pos++];
                        int length = Device.getDWord(data, pos);
                        pos += 4;
                        if (check1 == (byte) 0x63 && check2 == (byte) 0x62) {
                            int index = 0;
                            String a = "" + (char) index1 + "" + (char) index2;
                            try {
                                index = Integer.parseInt(a);
                            } catch (Exception e) {
                                System.err.println("An error occured!");
                                return;
                            }
                            index &= 0x01f;
                            if (!loaded[index]) {
                                cprdata[index] = new byte[0x04000];
                                System.arraycopy(data, pos, cprdata[index], 0, length);
                                loaded[index] = true;
                                System.out.println("Storing to position: " + index);
//                            System.out.println(Util.dumpBytes(data));
                            } else {
//                            System.out.println("Tried to fill position " + index + " but it's already loaded.");
//                            System.out.println("Comparing data now...");
                                byte[] check = new byte[0x04000];
                                System.arraycopy(data, pos, check, 0, length);
                                for (int i = 0; i < length; i++) {
                                    if (check[i] != cprdata[index][i]) {
                                        System.err.println("Difference encountered! " + Util.hex((short) i));
                                        System.err.println(Util.dumpBytes(cprdata[index], i, 16));
                                        System.err.println(Util.dumpBytes(check, i, 16));
//                                    System.exit(0);
                                        cprdata[index] = new byte[0x04000];
                                        System.arraycopy(data, pos, cprdata[index], 0, length);
                                        break;
                                    }
                                }
                            }
                        }
                        pos += length;
                    } catch (Exception e) {
                        System.out.println("Error in Cartride file!!!");
                    }
                }

                int s = 0;
                for (int i = 0; i < 32; i++) {
                    if (cprdata[i] != null) {
                        s += cprdata[i].length;
                    }
                }
                cpr = new byte[s];
                for (int i = 0; i < 32; i++) {
                    if (cprdata[i] != null) {
                        System.arraycopy(cprdata[i], 0, cpr, i * 16384, cprdata[i].length);
                    }
                }
//                System.out.println(Util.dumpBytes(cpr));
                if (filename != null && store) {
                    String newname = filename + ".bin";
                    File out = new File(newname);
                    try {
                        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(out));
                        for (int i = 0; i < 32; i++) {
                            if (cprdata[i] != null) {
                                bos.write(cprdata[i]);
                            }
                        }
                        bos.close();
                    } catch (Exception e) {
                    }
                }
            }
        } else {
            int pos = 0;
            try {
                for (int i = 0; i < data.length; i += 0x04000) {
                    cprdata[pos] = new byte[0x04000];
                    System.arraycopy(data, i, cprdata[pos], 0, 0x04000);
//                    System.out.println(pos);
                    pos++;
                }
                cpr = new byte[data.length];
                System.arraycopy(data, 0, cpr, 0, cpr.length);
            } catch (Exception e) {
            }
        }
        JCPC.system.cpc.GateArray.cpc.reset();
        JCPC.system.cpc.GateArray.cpc.getAsic().reset();
//            JCPC.system.cpc.GateArray.cpc.getAsic().setModeAndROMEnable();

    }

    public void CPR2BIN(byte[] data, String filename) {
        boolean store = true;
        if (cprdata == null) {
            cprdata = new byte[32][];
        }
        if (CPRHeader.equals(new String(data, 0, CPRHeader.length()).toUpperCase())) {
            if (CPRIdentifier.equals(new String(data, 8, CPRIdentifier.length()).toUpperCase())) {
                for (int i = 0; i < 32; i++) {
                    loaded[i] = false;
                }
                CPRSize = Device.getDWord(data, 0x04);
                for (int i = 0; i < 32; i++) {
                    cprdata[i] = null;
                }
                int pos = 0x0c;
                while (pos < CPRSize) {
                    byte check1 = data[pos++];
                    byte check2 = data[pos++];
                    byte index1 = data[pos++];
                    byte index2 = data[pos++];
                    int length = Device.getDWord(data, pos);
                    pos += 4;
                    if (check1 == (byte) 0x63 && check2 == (byte) 0x62) {
                        int index = 0;
                        String a = "" + (char) index1 + "" + (char) index2;
                        try {
                            index = Integer.parseInt(a);
                        } catch (Exception e) {
                            System.err.println("An error occured!");
                            return;
                        }
                        index &= 0x01f;
                        if (!loaded[index]) {
                            cprdata[index] = new byte[0x04000];
                            System.arraycopy(data, pos, cprdata[index], 0, length);
                            loaded[index] = true;
                            System.out.println("Storing to position: " + index);
//                            System.out.println(Util.dumpBytes(data));
                        } else {
//                            System.out.println("Tried to fill position " + index + " but it's already loaded.");
//                            System.out.println("Comparing data now...");
                            byte[] check = new byte[0x04000];
                            System.arraycopy(data, pos, check, 0, length);
                            for (int i = 0; i < length; i++) {
                                if (check[i] != cprdata[index][i]) {
                                    System.err.println("Difference encountered! " + Util.hex((short) i));
                                    System.err.println(Util.dumpBytes(cprdata[index], i, 16));
                                    System.err.println(Util.dumpBytes(check, i, 16));
//                                    System.exit(0);
                                    cprdata[index] = new byte[0x04000];
                                    System.arraycopy(data, pos, cprdata[index], 0, length);
                                    break;
                                }
                            }
                        }
                    }
                    pos += length;
                }

                int s = 0;
                for (int i = 0; i < 32; i++) {
                    if (cprdata[i] != null) {
                        s += cprdata[i].length;
                    }
                }
                cpr = new byte[s];
                for (int i = 0; i < 32; i++) {
                    if (cprdata[i] != null) {
                        System.arraycopy(cprdata[i], 0, cpr, i * 16384, cprdata[i].length);
                    }
                }
//                System.out.println(Util.dumpBytes(cpr));
                if (filename != null && store) {
                    String newname = filename.replace(".cpr", "") + ".bin";
                    File out = new File(newname);
                    try {
                        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(out));
                        int limit = 0;
                        for (int i = 0; i < 32; i++) {
                            if (cprdata[i] != null && limit < 128) {
                                limit += 16;
                                bos.write(cprdata[i]);
                            }
                        }
                        bos.close();
                    } catch (Exception e) {
                    }
                }
            }
        } else {
            int pos = 0;
            try {
                for (int i = 0; i < data.length; i += 0x04000) {
                    cprdata[pos] = new byte[0x04000];
                    System.arraycopy(data, i, cprdata[pos], 0, 0x04000);
//                    System.out.println(pos);
                    pos++;
                }
            } catch (Exception e) {
            }
        }
//            JCPC.system.cpc.GateArray.cpc.getAsic().setModeAndROMEnable();

    }

    public void readCPR2(byte[] data, String filename) {
        boolean store = false;
        if (cprdata == null) {
            cprdata = new byte[32][];
        }
        if (CPRHeader.equals(new String(data, 0, CPRHeader.length()).toUpperCase())) {
            if (CPRIdentifier.equals(new String(data, 8, CPRIdentifier.length()).toUpperCase())) {
                for (int i = 0; i < 32; i++) {
                    loaded[i] = false;
                }
                CPRSize = Device.getDWord(data, 0x04);
                for (int i = 0; i < 32; i++) {
                    cprdata[i] = null;
                }
                int pos = 0x0c;
                while (pos < CPRSize) {
                    byte check1 = data[pos++];
                    byte check2 = data[pos++];
                    byte index1 = data[pos++];
                    byte index2 = data[pos++];
                    int length = Device.getDWord(data, pos);
                    pos += 4;
                    if (check1 == (byte) 0x63 && check2 == (byte) 0x62) {
                        int index = 0;
                        String a = "" + (char) index1 + "" + (char) index2;
                        try {
                            index = Integer.parseInt(a);
                        } catch (Exception e) {
                            System.err.println("An error occured!");
                            return;
                        }
                        index &= 0x01f;
                        if (!loaded[index]) {
                            cprdata[index] = new byte[0x04000];
                            System.arraycopy(data, pos, cprdata[index], 0, length);
                            loaded[index] = true;
                            System.out.println("Storing to position: " + index);
//                            System.out.println(Util.dumpBytes(data));
                        } else {
//                            System.out.println("Tried to fill position " + index + " but it's already loaded.");
//                            System.out.println("Comparing data now...");
                            byte[] check = new byte[0x04000];
                            System.arraycopy(data, pos, check, 0, length);
                            for (int i = 0; i < length; i++) {
                                if (check[i] != cprdata[index][i]) {
                                    System.err.println("Difference encountered! " + Util.hex((short) i));
                                    System.err.println(Util.dumpBytes(cprdata[index], i, 16));
                                    System.err.println(Util.dumpBytes(check, i, 16));
//                                    System.exit(0);
                                    cprdata[index] = new byte[0x04000];
                                    System.arraycopy(data, pos, cprdata[index], 0, length);
                                    break;
                                }
                            }
                        }
                    }
                    pos += length;
                }

                int s = 0;
                for (int i = 0; i < 32; i++) {
                    if (cprdata[i] != null) {
                        s += cprdata[i].length;
                    }
                }
                cpr = new byte[s];
                for (int i = 0; i < 32; i++) {
                    if (cprdata[i] != null) {
                        System.arraycopy(cprdata[i], 0, cpr, i * 16384, cprdata[i].length);
                    }
                }
//                System.out.println(Util.dumpBytes(cpr));
                if (filename != null && store) {
                    String newname = filename + ".bin";
                    File out = new File(newname);
                    try {
                        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(out));
                        for (int i = 0; i < 32; i++) {
                            if (cprdata[i] != null) {
                                bos.write(cprdata[i]);
                            }
                        }
                        bos.close();
                    } catch (Exception e) {
                    }
                }
            }
        } else {
            int pos = 0;
            try {
                for (int i = 0; i < data.length; i += 0x04000) {
                    cprdata[pos] = new byte[0x04000];
                    System.arraycopy(data, i, cprdata[pos], 0, 0x04000);
//                    System.out.println(pos);
                    pos++;
                }
            } catch (Exception e) {
            }
        }

    }
}
