/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JCPC.system.cpc.plus;

import JCPC.core.Util;
import JCPC.core.device.Device;
import JCPC.system.cpc.*;
import java.awt.event.*;

/**
 *
 * @author Markus
 */
public class JukeBox extends Device {

    boolean DEBUG = false;
    int choosenSlot;
    CPC cpc;
    int clock = 0;
    int games = 12;
    int[] times = {
        9, 17, 33, 67
    };
    int wait = 2;
    boolean timed = false;
    int gamepos;

    public JukeBox(CPC cpc) {
        super("Amstrad CSD Cartridge Demonstrator");
        this.cpc = cpc;
//        startTimer();
    }

    public void reset() {
        gamemode = false;
    }
    boolean gamemode = false;

    public void writePort(int port, int value) {
        if (DEBUG) {
            System.out.println("Someone is writing to my port: "
                    + Util.hex((short) port) + " - " + Util.hex((byte) value));
        }
//        if (port == 0x0fbe1 && value < 0x07f && value != 0) {
//            cpc.cprslot = value;
//            choosenSlot = value;
//        }
        if (port == 0x0fbe1 && value > 0x07f && value < 0xd0) {
            choosenSlot = (value % 12);
            if (choosenSlot == 0) {
                choosenSlot = 12;
            }
            cpc.cprslot = choosenSlot;
            if (DEBUG) {
                System.out.println("loading " + choosenSlot);
            }
            gamemode = true;
            cpc.remapCPR(!gamemode);
        }
    }

    public void stopTimer() {
        timed = false;
        cpc.reset();
        clock = 0;
        timer.stop();
    }

    public void setTimer(int value) {
        timed = value != 0;
        clock = 0;
        timer.stop();
        if (timed) {
            timer.start();
        }
        wait = value - 1;
        System.out.println("Timer set to " + value);
    }

    public void startTimer() {
        timed = true;
        cpc.reset();
        clock = 0;
        timer.start();
    }
    int internclock = 0;
    boolean oldmode;
    ActionListener time = new ActionListener() {

        public void actionPerformed(ActionEvent e) {
            if (!timed) {
                return;
            }
//            System.out.println(clock);
            if (gamemode != oldmode) {
                internclock = 0;
                oldmode = gamemode;
            }
            if (DEBUG) {
                System.out.println(gamemode + " - " + internclock++);
            }
            if (!gamemode) {
                clock = 0;
            }
            if (cpc.cprslot == 0) {
                gamemode = false;
            }
            if (gamemode) {
                clock++;
                if (clock >= times[wait]) {
                    clock = 0;
                    gamemode = false;
                    cpc.cprslot = 0;
                    cpc.remapCPR(!gamemode);
                }
            }

        }
    };
    javax.swing.Timer timer = new javax.swing.Timer(1000, time);

    public void resetJukeBox() {
        choosenSlot = 0;
        gamemode = false;
    }

    public static int random(int n) {
        double decimal = Math.random();
        int value = (int) Math.round(decimal * n);
        return value;
    }

    public int readPort(int port) {
        if (DEBUG) {
            System.out.println("Someone is reading my port " + Util.hex((short) port));
        }
        if (port == 0x0fbe2) {
            return ((choosenSlot) << 4) & 0x0ff;
        }
        return 0x1;
    }
}
