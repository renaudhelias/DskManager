/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JCPC.system.cpc.plus;

/**
 *
 * @author Markus
 */
public class ASIC_DMA_CHANNEL {
    
        public boolean PauseActive;
        public int PauseCount;                     /*
         * pause current count
         */

        public int PrescaleCount;                  /*
         * channel prescalar current count
         */

        public int LoopStart;                      /*
         * reload address for loop
         */

        public int RepeatCount;            /*
         * number of times to repeat the loop
         */
}
