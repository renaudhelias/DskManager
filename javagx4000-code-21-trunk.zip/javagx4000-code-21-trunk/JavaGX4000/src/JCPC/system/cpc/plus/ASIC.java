/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JCPC.system.cpc.plus;

import JCPC.core.Util;
import JCPC.core.device.Device;
import JCPC.core.device.sound.AY_3_8910;
import JCPC.system.cpc.*;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author Markus
 */
public class ASIC extends Device {

    public boolean DMA_Sound_Enabled = true;
    public ASIC_DATA ASIC_Data = new ASIC_DATA();
    ASIC_DMA_CHANNEL pChannel[] = {
        new ASIC_DMA_CHANNEL(),
        new ASIC_DMA_CHANNEL(),
        new ASIC_DMA_CHANNEL()
    };
    ASIC_DMA[] DMA = {
        new ASIC_DMA(),
        new ASIC_DMA(),
        new ASIC_DMA()
    };
    boolean nodma = false;
    int ASIC_DCSR2;
    protected boolean ASIC_InterruptRequest;
    protected final int SEQUENCE_SYNCHRONISE_FIRST_BYTE = 0;
    protected final int SEQUENCE_SYNCHRONISE_SECOND_BYTE = 1;
    protected final int SEQUENCE_RECOGNISE = 2;
    protected final int SEQUENCE_GET_LOCK_STATUS = 3;
    protected final int SEQUENCE_SYNCHRONISE_THIRD_BYTE = 4;
    protected int CurrentSequencePos;
    protected int RecogniseSequenceState;
    protected int selInk = 0;
    protected boolean DEBUG = false;
    CPC cpc;
    Z80 z80;
    AY_3_8910 psg;
    boolean asicLocked = true;
    boolean asicRamActive = false;
    int lowRomLoc;
    int lowRomPage;
    protected final int[] plusPalette = {
        0x666, 0x666, 0xF06, 0xFF6, 0x006, 0x0F6, 0x606, 0x6F6,
        0x0F6, 0xFF6, 0xFF0, 0xFFF, 0x0F0, 0x0FF, 0x6F0, 0x6FF,
        0x006, 0xF06, 0xF00, 0xF0F, 0x000, 0x00F, 0x600, 0x60F,
        0x066, 0xF66, 0xF60, 0xF6F, 0x060, 0x06F, 0x660, 0x66F
    };
    protected int[] RGB = new int[2];
    GateArray gateArray;

    public ASIC(CPC cpc, GateArray gateArray, AY_3_8910 psg, Z80 z80) {
        super("Amstrad 40489 ASIC");
        this.cpc = cpc;
        this.z80 = z80;
        this.gateArray = gateArray;
        this.psg = psg;
    }

    public void reset() {
        super.reset();
        trick = false;
        ASIC_InterruptRequest = false;
        romconfig = 0;
        System.out.println("ASIC reset");
        int i;
//        /* disable all SpritePalette */
        for (i = 0; i < 16; i++) {
            ASIC_Data.Sprites[i].SpriteMag = 0;
            cpc.memory.writeASIC(0x06000 + (i << 3) + 4, 0);
        }
//        /* no scan-line interrupt */
        ASIC_Data.ASIC_RasterInterruptLine = 0;
        /*
         * no split
         */
        ASIC_Data.ASIC_RasterSplitLine = 0;
//        /* no automatic clearing of DMA ints */
//        /* bits 7-1 are undefined at reset */
//        /* bit 0 set to 1 at reset */
        olddata = -1;
        ASIC_Data.ASIC_InterruptVector |= 1;
        System.out.println("Interruptvector = " + ASIC_Data.ASIC_InterruptVector);

        int vector = ASIC_CalculateInterruptVector();

        /*
         * set Z80 vector base for mode 2
         */
        z80.setInterruptVector(vector);
//        /* set soft scroll register */
        gateArray.ASIC_SetSoftScrollRegister(0);

//        /* DCSR */
        cpc.memory.writeASIC(0x06c0f, 0);

//        /* reset analogue input channels */
        for (i = 0; i < 8; i++) {
            cpc.memory.writeASIC(0x06808 + i, 0x0ff);
        }


        /*
         * reset unlock sequence state-machine
         */
        RecogniseSequenceState = SEQUENCE_SYNCHRONISE_FIRST_BYTE;
//        ASIC_Data.InternalDCSR = 0;
        ASIC_DCSR2 = 0;
        ASIC_Data.InternalDCSR = 0;
        this.ASIC_UpdateRAMWithInternalDCSR();
        asicLocked = true;
        asicRamActive = false;
        selInk = 0;
        lowRomLoc = 0;
        lowRomPage = 0;
        this.setModeAndROMEnable();
    }

    protected void setPal(int value) {
        RGB[0] = value & 0x0ff;
        RGB[1] = (value >> 8) & 0x0ff;
    }
    int rambank;

    public boolean isLocked() {
        return asicLocked;
    }
    protected int readport;

    public void writePort(int port, int value) {
        if (port > 0x0cfff && port < 0x0e000) {

        }
        if (!cpc.memory.plus) {
            return;
        }
        if ((port & 0x08000) == 0) {
            readport = value;
            //            if ((value & 0x020) != 0x0)
            if ((value & 0x0e0) == 0x0a0) {
                lowRomPage = value & 0x07;
                switch ((value >> 3) & 0x03) {
                    case 0: {
                        CurrentSequencePos = 0;
                        RecogniseSequenceState = SEQUENCE_SYNCHRONISE_FIRST_BYTE;
                        asicRamActive = false;
                        lowRomLoc = 0;		// &0000-&3fff
                        cpc.memory.enableAsicRam(asicRamActive, lowRomLoc, lowRomPage);
                        if (DEBUG) {
                            System.out.println("case 0: &0000-&3fff - asic RAM disabled");
                        }
                    }
                    break;
                    case 1: {
                        CurrentSequencePos = 0;
                        RecogniseSequenceState = SEQUENCE_SYNCHRONISE_FIRST_BYTE;
                        asicRamActive = false;
                        lowRomLoc = 2;		// &4000-&7fff
                        cpc.memory.enableAsicRam(asicRamActive, lowRomLoc, lowRomPage);
                        if (DEBUG) {
                            System.out.println("case 1: &4000-&7fff - asic RAM disabled");
                        }
                    }
                    break;
                    case 2: {
                        CurrentSequencePos = 0;
                        RecogniseSequenceState = SEQUENCE_SYNCHRONISE_FIRST_BYTE;
                        asicRamActive = false;
                        lowRomLoc = 4;		// &8000-&bfff
                        cpc.memory.enableAsicRam(asicRamActive, lowRomLoc, lowRomPage);
                        if (DEBUG) {
                            System.out.println("case 2: &8000-&bfff - asic RAM disabled");
                        }
                    }
                    break;
                    case 3: {
                        CurrentSequencePos = 0;
                        RecogniseSequenceState = SEQUENCE_SYNCHRONISE_FIRST_BYTE;
                        asicRamActive = true;
                        lowRomLoc = 0;		// &0000-&3fff
                        cpc.memory.enableAsicRam(asicRamActive, lowRomLoc, lowRomPage);
                        if (DEBUG) {
                            System.out.println("case 2: &0000-&3fff - asic RAM enabled");
                        }
                    }
                    break;
                }
            } else {
                if ((value & 0x80) == 0) {
                    if ((value & 0x40) == 0) {
                        value &= 0x1f;
                        selInk = value < 0x10 ? value : 0x10;
                    } else {
                        setPal(plusPalette[value & 0x01f]);
                        cpc.memory.writeASIC(0x6400 + selInk * 2, RGB[0]);
                        cpc.memory.writeASIC(0x6401 + selInk * 2, RGB[1]);
                        gateArray.setPlusPalette(selInk, (RGB[0] >> 4) & 0x0f, RGB[1] & 0x0f, RGB[0] & 0x0f);
//                        int r = ((RGB[0] >> 4) & 0x0f) * 17;
//                        int g = (RGB[1] & 0x0f) * 17;
//                        int b = (RGB[0] & 0x0f) * 17;
//                        System.out.println(selInk + ":" + r + " " + g + " " + b);
//                        JCPC.ui.Debugger.INK(selInk, new Color(r, g, b));
                    }
                } else {
                    if ((value & 0x40) == 0) {
                        romconfig = value;
                        setModeAndROMEnable();
                    } else {
                        cpc.memory.setRAMBank(value);
                        rambank = value;
                    }
                }
            }

        } else {
            cpc.memory.setUpperROM(value & 0x0ff);
        }
    }
    protected int ASIC_EnableSequence[] = {
        0x0ff, 0x077, 0x0b3, 0x051, 0x0a8, 0x0d4, 0x062, 0x039,
        0x09c, 0x046, 0x02b, 0x015, 0x08a, 0x0cd
    };

    public int readPort(int port) {
        if ((port & 0x08000) == 0) {
            return readport;
        } else {
            return 0;
        }
    }

    public boolean ASIC_RasterSplitLineMatch(int CRTC_LineCounter, int CRTC_RasterCounter) {
        if (asicLocked) {
            return false;
        }
        if (ASIC_LineMatch(ASIC_Data.ASIC_RasterSplitLine, CRTC_LineCounter, CRTC_RasterCounter, 0x01f)) {
            return true;
        }
        return false;
    }

    public void ASIC_HSync(int CRTC_LineCounter, int CRTC_RasterCounter) {
        if (asicLocked) {
            trick = false;
        }
        if (!asicLocked) /*
         * do a dma cycle and maybe set a dma interrupt
         */ {
            ASIC_DoDMA();
        }
        /*
         * if ASIC raster interrupts are not enabled...
         */
        if (!ASIC_RasterIntEnabled()) {
            if (gateArray.GateArray_GetInterruptRequest()) {
                /*
                 * CPC+ mode. Mark this interrupt as a Raster int
                 */
//                System.out.println("Asic Interruptrequest");
                z80.Z80_SetInterruptRequest();
                return;
            }
        }
        /*
         * if ASIC is not enabled, then functions not available
         */
        if (!asicLocked) {

            /*
             * is raster interrupt line active?
             */
            if (cpc.PEEK(0x08000) == 255 && cpc.PEEK(0x08001) == 18 && cpc.PEEK(0x08002) == 204 && cpc.PEEK(0x08003) == 105) {
                trick = true;
            }
            int mask = trick ? 0x01f : 0x03f;
            if (ASIC_LineMatch(ASIC_Data.ASIC_RasterInterruptLine, CRTC_LineCounter, CRTC_RasterCounter, mask)) {
                /*
                 * raster interrupt occured
                 */
//                System.out.println("Asic RasterInterruptrequest");
                ASIC_SetRasterInterrupt();
//                if (cpc.PEEK(0x02001) != 0) {
//                    System.out.println(cpc.PEEK(0x02000) + "," + cpc.PEEK(0x02001) + "," + cpc.PEEK(0x02002) + "," + cpc.PEEK(0x02003));
//                }
//                z80.Z80_SetInterruptRequest();
                return;
            }

        }

        /*
         * trigger int if any sources require an interrupt
         */
        ASIC_TriggerInterrupt();
    }
    boolean trick = false;

    public boolean ASIC_LineMatch(int inLine, int CRTC_LineCounter, int CRTC_RasterCounter, int mask) {
        if (inLine == 0) {
            return false;
        }
        return inLine == (((((CRTC_LineCounter) & mask) << 3) | (CRTC_RasterCounter & 0x07)));
    }

    private void ASIC_UpdateRAMWithInternalDCSR() {
        int i;
        int thisDCSR = ((ASIC_Data.InternalDCSR & 0x07f) | ASIC_DCSR2);

        for (i = 15; i >= 0; i--) {
            cpc.memory.writeASIC(0x2c00 + i, thisDCSR);
        }
    }
    /*
     * trigger a ASIC generated interrupt (raster or ASIC_DMA)
     */

    public void ASIC_TriggerInterrupt() {
        ASIC_InterruptRequest = false;

        /*
         * any interrupting sources?
         */
        if ((ASIC_Data.InternalDCSR & 0x0f0) != 0) {

            /*
             * calculate mode 2 interrupt vector based on interrupt that is
             * enabled
             */
            int vector = ASIC_CalculateInterruptVector();

            /*
             * set Z80 vector base for mode 2
             */
            z80.setInterruptVector(vector);
//            if (iv != vector) {
//                System.out.println("Interrupt set to " + vector);
//            }
            iv = vector;
            z80.Z80_SetInterruptRequest();
            ASIC_InterruptRequest = true;
        }
    }

    public boolean ASIC_GetInterruptRequest() {
        return ASIC_InterruptRequest;
    }
    int iv;
    /*
     * calculate a interrupt vector to supply in IM2 or ignore in IM1 based on
     * interrupts active.
     */

    int ASIC_CalculateInterruptVector() {
        int Vector = 0;

        /*
         * lowest priority to highest priority
         */

        /*
         * is DMA channel 0 interrupt triggered?
         */
        if ((ASIC_Data.InternalDCSR & 0x040) != 0) {
            Vector = 0x04;
        }
        /*
         * is DMA channel 1 interrupt triggered?
         */
        if ((ASIC_Data.InternalDCSR & 0x020) != 0) {
            Vector = 0x02;
        }
        /*
         * is DMA channel 2 interrupt triggered?
         */
        if ((ASIC_Data.InternalDCSR & 0x010) != 0) {
            Vector = 0x00;
        }
        /*
         * is raster interrupt triggered
         */
        if ((ASIC_Data.InternalDCSR & 0x080) != 0) {
            /*
             * raster int line specified
             */
            Vector = 0x06;
        }
        return ((ASIC_Data.ASIC_InterruptVector & 0x0f8) + Vector);
    }
    public int romconfig;

    public void setModeAndROMEnable() {
        cpc.memory.setLowerEnabled((romconfig & 0x04) == 0);
        cpc.memory.setUpperEnabled((romconfig & 0x08) == 0);
        if ((romconfig & 0x10) != 0) {
//            cpc.memory.setSecondaryRomMapping(this.ASIC_GateArray_CheckForSecondaryRomMapping(romconfig));
//            System.err.println("Secondary rom mapping is not implemented yet");
            if (this.asicLocked) {
                gateArray.GateArray_ClearInterrupt();
            }
        }
        cpc.memory.remap();
        gateArray.newMode = romconfig & 0x03;
    }

    boolean ASIC_GateArray_CheckForSecondaryRomMapping(int Function) {
        if (!this.asicLocked) {
            if ((Function & 0x0e0) == 0x0a0) {
                /*
                 * function 101xxxxx
                 */
//           ASIC_SetSecondaryRomMapping(Function);
                return true;
            }
        }
        return false;
    }

//    protected int getLineNumber() {
//        return gateArray.getLineNumber();
//    }
//2.4 Programmable raster interrupt
//        A new 8 bit memory mapped register (PRI) will be added within the ASIC at address 6800h,
//        which is cleared at power up. If zero, the normal raster interrupt mechanism will 
//        function as before. Otherwise, an interrupt will occur instead at the end of the 
//        scan line specified. In either case, this facility can provide a vectored interrupt 
//        (see section 2.7 below). The PRI can be reprogrammed as required to produce multiple 
//        interrupts per frame.
//    if asic is enabled and 6800 is not 0, then raster interrupt line is used, only if this is matched will the interrupt come.
//r52 continues to count, but doesn't do anything.
//
//if 6800 is 0, then InterruptLineCount is used to generate interrupt.
//
//value!=0 checking: winape does different to arnold, and I don't know what is correct. I check at end of hsync.
//
//z80 interrupt is set when interrupt is first generated.
//
//when interrupt is acknowledged by z80 then asic makes a decision: are other interrupt sources (ASIC_DMA etc) wanting to make interrupt? if they are interrupt request is not cleared.
//if nothing wants to interrupt, then it's cleared.
    /*
     * calculate a interrupt vector to supply in IM2 or ignore in IM1 based on
     * interrupts active.
     */
    /*
     * When reading &6c00-&6c0f will give result of reading DCSR register.
     *
     * The DMA channels data are located at &6c00, &6c04 and &6c08, for channels
     * 0, 1 and 2 in that order.
     */
    void ASIC_DMA_EnableChannel(int ChannelIndex) {
    }

    void ASIC_DMA_DisableChannel(int ChannelIndex) {
//        ASIC_DMA_CHANNEL pChannel[] = this.pChannel;

        /*
         * set pause and prescale to 0
         */
        /*
         * at the end of the next HSYNC, the first opcode in the list will be
         * executed for this channel, and the prescalar will be re-loaded
         */

        /*
         * set pause and prescale to 0
         */
        /*
         * at the end of the next HSYNC, the first opcode in the list will be
         * executed for this channel, and the prescalar will be re-loaded
         */
        pChannel[ChannelIndex].PrescaleCount = 0;
        pChannel[ChannelIndex].PauseCount = 0;
        pChannel[ChannelIndex].PauseActive = false;
        pChannel[ChannelIndex].RepeatCount = 0;
    }

    void ASIC_DMA_EnableChannels(int Data) {
        if ((Data & 0x01) != 0) {
            ASIC_DMA_EnableChannel(0);
        }

        if ((Data & 0x02) != 0) {
            ASIC_DMA_EnableChannel(1);
        }

        if ((Data & 0x04) != 0) {
            ASIC_DMA_EnableChannel(2);
        }
    }

    void ASIC_DMA_DisableChannels(int Data) {
        if ((Data & 0x01) == 0) {
            ASIC_DMA_DisableChannel(0);
        }

        if ((Data & 0x02) == 0) {
            ASIC_DMA_DisableChannel(1);
        }

        if ((Data & 0x04) == 0) {
            ASIC_DMA_DisableChannel(2);
        }
    }

    /*
     * clear ASIC_DMA ints by a manual write to DCSR
     */
    public void ASIC_ClearDMAInterruptsManual(int Data) {
        ASIC_Data.InternalDCSR = (ASIC_Data.InternalDCSR & ~(Data & (0x07 << 4)));
    }

    public void ASIC_ClearDMAInterruptsAutomatic() {
        /*
         * is DMA channel 2 interrupt triggered?
         */
        if ((ASIC_Data.InternalDCSR & 0x010) != 0) {
            /*
             * clear interrupt
             */
            ASIC_Data.InternalDCSR = (ASIC_Data.InternalDCSR & (~0x010));
            return;
        }

        /*
         * is DMA channel 1 interrupt triggered?
         */
        if ((ASIC_Data.InternalDCSR & 0x020) != 0) {
            /*
             * clear interrupt
             */
            ASIC_Data.InternalDCSR = (ASIC_Data.InternalDCSR & (~0x020));
            return;
        }


        /*
         * is DMA channel 0 interrupt triggered?
         */
        if ((ASIC_Data.InternalDCSR & 0x040) != 0) {
            /*
             * clear interrupt
             */
            ASIC_Data.InternalDCSR = (ASIC_Data.InternalDCSR & (~0x040));
        }
    }
    /*
     * clear ASIC_DMA interrupts automatically when ints are done, only clears
     */
    /*
     * highest priority DMA int active, so other ints may be done too
     */

    void ASIC_ClearDMAInterrupts() {
        /*
         * clear ASIC_DMA interrupts in order of priority
         */
        ASIC_ClearDMAInterruptsAutomatic();

        /*
         * update asic ram with DCSR value
         */
        ASIC_UpdateRAMWithInternalDCSR();
    }

    /*
     * return TRUE if raster ints are enabled, FALSE if not
     */
    public boolean ASIC_RasterIntEnabled() {
        return (ASIC_Data.ASIC_RasterInterruptLine != 0);
    }

    /*
     * set raster interrupt
     */
    public void ASIC_SetRasterInterrupt() {
        ASIC_DCSR2 = 0x080;
        ASIC_Data.InternalDCSR |= 0x080;
        ASIC_TriggerInterrupt();
    }
    /*
     * clear raster interrupt
     */

    public void ASIC_ClearRasterInterrupt() {
//        ASIC_DCSR2 = 0;
        ASIC_Data.InternalDCSR &= 0x07f;
        ASIC_TriggerInterrupt();
    }

    public int ASIC_GetDCSR() {
        return ((ASIC_Data.InternalDCSR & 0x07f) | ASIC_DCSR2);
    }
    ASICSecondaryScreenAddress ASIC_SecondaryScreenAddress = new ASICSecondaryScreenAddress();
    /*
     * this function is called whenever the Z80 acknowledges a interrupt
     */

    public int ASIC_ScreenMA() {
        return ASIC_SecondaryScreenAddress.Addr.getAddr_W();
    }
    /*
     * data will have already been poked into ram
     */

    public void ASIC_WriteRam(int Addr, int Data) {
        if ((Addr & 0x0c000) != 0x04000) {
            return;
        }

        Data &= 0x0ff;
        Addr = Addr & 0x03fff;

        if ((Addr & 0x0f000) == 0x00000) {
            /*
             * write to sprite ram
             */

            /*
             * remove upper nibble from sprite data
             */
            cpc.memory.writeASIC(Addr, Data & 0x0f);
//                ASIC_Ram[Addr/* & 0x0fff*/] = (unsigned char)(Data & 0x0f);
            return;
        }

        if ((Addr & 0x03f80) == 0x02000) {
            int SpriteIndex = (Addr & 0x078) >> 3;

            switch (Addr & 0x07) {
                case 0: {
                    if (ASIC_Data.Sprites[SpriteIndex].SpriteX.SpriteX_Bl == Data) {
                        return;
                    }

                    /*
                     * set X coordinate low byte
                     */
                    ASIC_Data.Sprites[SpriteIndex].SpriteX.SpriteX_Bl = Data;

//                    /*
//                     * mirror
//                     */
                    cpc.memory.writeASIC(Addr + 4, Data);
                }
                break;

                case 1: {
                    /*
                     * if bit 0 = 1 and bit 1 = 1, then reading this byte will
                     * return 0x0ff
                     */
                    /*
                     * otherwise bit 7-2 are forced to zero
                     */

                    int LocalData = Data & 0x03;
                    int PokeData;

                    PokeData = LocalData;
                    if (PokeData == 3) {
                        PokeData = 0x0ff;
                    }

                    /*
                     * change value in ram and mirror
                     */
                    cpc.memory.writeASIC(Addr, PokeData);
                    cpc.memory.writeASIC(Addr + 4, PokeData);

                    /*
                     * move this ahead if possible to speed things up a bit
                     */
                    if (ASIC_Data.Sprites[SpriteIndex].SpriteX.SpriteX_Bh == LocalData) {
                        return;
                    }

                    /*
                     * set X coordinate high byte
                     */
                    ASIC_Data.Sprites[SpriteIndex].SpriteX.SpriteX_Bh = LocalData;

                }
                break;

                case 2: {
                    if (ASIC_Data.Sprites[SpriteIndex].SpriteY.SpriteY_Bl == Data) {
                        return;
                    }

                    /*
                     * set Y coordinate low byte
                     */
                    ASIC_Data.Sprites[SpriteIndex].SpriteY.SpriteY_Bl = Data;

                    /*
                     * mirror
                     */
                    cpc.memory.writeASIC(Addr + 4, Data);
                }
                break;

                case 3: {

                    /*
                     * if bit 0 = 1 then reading this byte will return 0x0ff
                     */
                    /*
                     * otherwise bit 7-1 are forced to zero
                     */
                    int LocalData = Data & 0x01;
                    int PokeData;

                    PokeData = LocalData;
                    if (PokeData != 0) {
                        PokeData = 0x0ff;
                    }

                    cpc.memory.writeASIC(Addr, PokeData);
                    cpc.memory.writeASIC(Addr + 4, PokeData);


                    /*
                     * watch out if this is moved; if bit 0 is set, then 0x0ff
                     * must be poked into ASIC ram!
                     */
                    if (ASIC_Data.Sprites[SpriteIndex].SpriteY.SpriteY_Bh == LocalData) {
                        return;
                    }

                    /*
                     * set Y coordinate high byte
                     */
                    ASIC_Data.Sprites[SpriteIndex].SpriteY.SpriteY_Bh = LocalData;

                }
                break;

                default: {
                    if (ASIC_Data.Sprites[SpriteIndex].SpriteMag == (Data & 0x0f)) {
                        /*
                         * offset 4, mirrors offset 0, offset 3, mirrors offset
                         * 1..
                         */
                        cpc.memory.writeASIC(Addr, cpc.memory.readASIC(Addr & 0x3ffb));
                        return;
                    }

                    /*
                     * store sprite magnification
                     */
                    ASIC_Data.Sprites[SpriteIndex].SpriteMag = (Data & 0x0f);
                    cpc.memory.setMag(SpriteIndex, ASIC_Data.Sprites[SpriteIndex].SpriteMag);
//                    System.out.println("Storing mag for sprite "+ SpriteIndex+ " value: "+(Data & 0x0f));

                    /*
                     * offset 4, mirrors offset 0, offset 3, mirrors offset 1..
                     */
                    cpc.memory.writeASIC(Addr, cpc.memory.readASIC(Addr & 0x3ffb));
                }
                break;

            }

            /*
             * update sprite render information
             */
            ASIC_SetupSpriteRenderInfo(SpriteIndex);

            return;
        }

        if ((Addr & 0x0fff8) == 0x02800) {
            switch (Addr & 0x07) {
                case 0: {
//                    System.err.println(Util.hex(Addr));
                    ASIC_Data.ASIC_RasterInterruptLine = Data;
//                    System.out.println("raster interruptline = "+Data);

                    return;
                }
//
                case 1: {
                    ASIC_Data.ASIC_RasterSplitLine = Data;

                    /*
                     * split line
                     */
                    cpc.CRTC().ASICCRTC_ScreenSplit();
                    return;
                }
//
//		
                case 2: {
                    ASIC_SecondaryScreenAddress.Addr.Addr_B.h = Data;
                    return;
                }

                case 3: {
                    ASIC_SecondaryScreenAddress.Addr.Addr_B.l = Data;
                    return;
                }
//
                case 4: {
                    gateArray.ASIC_SetSoftScrollRegister(Data & 0xff);

//					Render_SetHorizontalPixelScroll(Data & 0x0f);
//                
//					ASICCRTC_SetSoftScroll(Data);
                    return;
                }
//
//				
                case 5: {
                    /*
                     * interrupt vector supplied by ASIC
                     */
                    if (olddata != Data) {
                        System.out.println("Write: Interruptvector = " + Data + " - " + this.ASIC_InterruptRequest);
                        olddata = Data;
                    }
                    ASIC_Data.ASIC_InterruptVector = Data;

                    int vector = ASIC_CalculateInterruptVector();

                    /*
                     * set Z80 vector base for mode 2
                     */
                    z80.setInterruptVector(vector);
                    // TODO: Check which routine is correct here... If used both, Robocop II doesnt startup.
//                    z80.Z80_SetInterruptRequest();
//                    ASIC_InterruptRequest = true;
                    return;
                }
//
                default:
                    return;

            }
        }

        /*
         * analogue input channels
         */
        if ((Addr & 0x03ff8) == 0x02808) {
//			ASIC_Data.ASIC_Ram[Addr] = ASIC_Data.AnalogueInputs[Addr & 0x07];
            return;
        }


        /*
         * write colour palette
         */
        if ((Addr & 0x0ffc0) == 0x02400) {
            int Index;

            Addr = Addr & 0x03ffe;
            Index = (Addr & 0x003f) >> 1;

            /*
             * Cliff's Test code checks for this
             */
            cpc.memory.writeASIC(Addr + 1, cpc.memory.readASIC(Addr + 1) & 0x00f);
//            int PackedRGBLookup = cpc.memory.readASIC(Addr) | (cpc.memory.readASIC(Addr + 1) << 8);
//            if ((Addr & 0x01) == 0) {
//                setPal(PackedRGBLookup);
//                gateArray.setPlusPalette(Index, (RGB[0] >> 4) & 0x0f, RGB[1] & 0x0f, RGB[0] & 0x0f);
//                gateArray.newMode = romconfig & 0x03;
//            }
//                ASIC_Data.ASIC_Ram[Addr+1] &= 0x00f;

//                {
//                        unsigned long PackedRGBLookup;
//
////#ifdef CPC_LSB_FIRST
////						PackedRGBLookup = ((unsigned long *)(ASIC_Data.ASIC_Ram + Addr))[0];
////#else
//						PackedRGBLookup = ASIC_Data.ASIC_Ram[Addr] | ((ASIC_Data.ASIC_Ram[Addr+1])<<8);
////#endif
////						PackedRGBLookup = PackedRGBLookup & 0x0fff;
//				
//						Render_SetColour(&ASIC_DisplayColours[PackedRGBLookup], Index);
//
//                }
            return;
        }

        if (nodma) {
            return;
        }
        if ((Addr & 0x0fff0) == 0x02c00) {
            if (Addr == 0x02c0f) {
                /*
                 * writing 1 to DMA int bits
                 */

                /*
                 * clear ASIC_DMA interrupts
                 */
                ASIC_ClearDMAInterruptsManual(Data);

                if ((Data & 0x07) != 0x07) {
                    /*
                     * writing 0's to DMA enable bits
                     */

                    /*
                     * disable channel(s)
                     */
                    ASIC_DMA_DisableChannels(Data);
                }

                /*
                 * keep info about channels enabled and the channels
                 * interrupting
                 */
                ASIC_Data.InternalDCSR = ((ASIC_Data.InternalDCSR & 0x07f) | (Data & 0x07));

                ASIC_UpdateRAMWithInternalDCSR();

                return;
            } else {
                int ChannelIndex = ((Addr & 0x0f) >> 2);
                if (ChannelIndex > 2) {
                    System.err.println("Channel?!?" + ChannelIndex + "," + Data);
                    return;
                }

                switch (Addr & 0x03) {
                    case 0: {
                        DMA[ChannelIndex].Addr.Addr_B.l = (Data & 0x0fe);
                    }
                    break;

                    case 1: {
                        DMA[ChannelIndex].Addr.Addr_B.h = Data;
                    }
                    break;

                    case 2: {
                        DMA[ChannelIndex].Prescale = Data;
                    }
                    break;
                }

                ASIC_UpdateRAMWithInternalDCSR();

                return;
            }
        }

        /*
         * write data for unused ram so that if a write and then a read is dopne
         * the unused ram data byte will be returned
         */
        cpc.memory.writeASIC(Addr, ASIC_UNUSED_RAM_DATA);
    }
    public final int ASIC_UNUSED_RAM_DATA = 0x0b0;

    private void ASIC_SetupSpriteRenderInfo(int SpriteIndex) {
        cpc.memory.setSpriteX(SpriteIndex, ASIC_Data.Sprites[SpriteIndex].SpriteX.getAddr_W());
        cpc.memory.setSpriteY(SpriteIndex, ASIC_Data.Sprites[SpriteIndex].SpriteY.getAddr_W());
        cpc.memory.setSpritePos(SpriteIndex);
    }

    public void ASIC_SetIVR(int IVR) {
        ASIC_Data.ASIC_InterruptVector = IVR;
    }
    int olddata = -1;

    public void ASIC_AcknowledgeInterrupt() {
        if ((ASIC_Data.InternalDCSR & 0x080) == 0) {
            /*
             * not a raster interrupt. Is it a DMA interrupt ?
             */

            ASIC_DCSR2 = 0x00;

            /*
             * if vector supplied had bit 0 not set, then we automatically clear
             * ASIC_DMA interrupts on a acknowledge
             */
            if ((ASIC_Data.ASIC_InterruptVector & 0x001) == 0) {
                /*
                 * clear the ASIC_DMA interrupt
                 */
                ASIC_ClearDMAInterrupts();
            }
        } else {
            /*
             * clear raster int
             */
            ASIC_ClearRasterInterrupt();
//                gateArray.GateArray_AcknowledgeInterrupt();
        }

        /*
         * write ASIC_Data.InternalDCSR to ram
         */
        ASIC_UpdateRAMWithInternalDCSR();

        ASIC_DCSR2 = 0x00;
    }

    void ASIC_DoDMA() {
        if ((ASIC_Data.InternalDCSR & (0x001 | 0x002 | 0x04)) == 0) {
            return;
        }

        if ((ASIC_Data.InternalDCSR & 0x001) != 0) {
            /*
             * channel 0 is enabled
             */
            ASIC_DMA_HandleChannel(0);
        }

        if ((ASIC_Data.InternalDCSR & 0x002) != 0) {
            /*
             * channel 1 is enabled
             */
            ASIC_DMA_HandleChannel(1);
        }

        if ((ASIC_Data.InternalDCSR & 0x004) != 0) {
            /*
             * channel 2 is enabled
             */
            ASIC_DMA_HandleChannel(2);
        }
    }

    int ASIC_DMA_GetOpcode(int Addr) {
        return Z80_RD_BASE_WORD(Addr);
    }
    /*
     * read a word from base memory without memory paging
     */

    int Z80_RD_BASE_WORD(int Addr) {
        int a = (Z80_RD_BASE_BYTE(Addr) | ((Z80_RD_BASE_BYTE(Addr + 1) << 8)));
//        System.out.println(Util.hex((short) Addr) + " - " + Util.hex((short) a));
        return a;
    }

    int Z80_RD_BASE_BYTE(int Addr) {
        return cpc.memory.readLowByte(Addr) & 0x0ff;
    }
///* read a byte from base memory without memory paging */
//Z80_BYTE Z80_RD_BASE_BYTE(Z80_WORD Addr)
//{
//        return Z80MemoryBase[Addr];
//}
//
///* read a word from base memory without memory paging */
//Z80_WORD Z80_RD_BASE_WORD(Z80_WORD Addr)
//{
//        return (unsigned short)((((Z80_WORD)Z80_RD_BASE_BYTE(Addr)) | (((Z80_WORD)Z80_RD_BASE_BYTE((Z80_WORD)(Addr+1)))<<8)));
//}

    int ASIC_DMA_GetChannelPrescale(int ChannelIndex) {
        /*
         * get pre-scalar
         */
        return (DMA[ChannelIndex].Prescale);
    }

    int ASIC_DMA_GetChannelAddr(int ChannelIndex) {
        return (DMA[ChannelIndex].Addr.getAddr_W());
    }

    void ASIC_DMA_WriteChannelAddr(int ChannelIndex, int Addr) {
        DMA[ChannelIndex].Addr.writeAddr_W(Addr & 0x0ffff);
    }

    void ASIC_DMA_ExecuteCommand(int ChannelIndex) {
        ASIC_DMA_CHANNEL pChannel[] = this.pChannel;
        int Command;
        int CommandOpcode;
        int Addr;

        Addr = DMA[ChannelIndex].Addr.getAddr_W();
        Command = ASIC_DMA_GetOpcode((Addr & 0x0fffe));

        CommandOpcode = (Command & 0x07000) >> 12;

        Addr = Addr + 2;

        if (CommandOpcode == 0) {
            /*
             * LOAD R,D
             */
            int Register;
            int Data;

            /*
             * PSG register
             */
            Register = (Command >> 8) & 0x0f;
            /*
             * data to write
             */
            Data = (Command & 0x0ff);
            /*
             * write data
             */

            if (DMA_Sound_Enabled) {
                psg.setRegister(Register, Data);
            }

        } else {
            if ((CommandOpcode & 0x01) != 0) {
                /*
                 * PAUSE n
                 */

                /*
                 * pause of 0 is equivalent to a NOP
                 */
                int PauseCount = Command & 0x0fff;

                if (PauseCount - 1 != 0) {
                    if (PauseCount - 1 >= 0) {
                        pChannel[ChannelIndex].PauseCount = PauseCount - 1;
                    }
                    pChannel[ChannelIndex].PrescaleCount = 0;//ASIC_Data.DMA[ChannelIndex].Prescale;
                    pChannel[ChannelIndex].PauseActive = true;
                }

            }

            if ((CommandOpcode & 0x02) != 0) {
                /*
                 * REPEAT n
                 */

                /*
                 * store repeat count
                 */
                pChannel[ChannelIndex].RepeatCount = Command & 0x0fff;

                /*
                 * set next instruction as loop start
                 */
                pChannel[ChannelIndex].LoopStart = Addr & 0x0ffff;
            }

            if ((CommandOpcode & 0x04) != 0) {
                /*
                 * NOP, LOOP, INT, STOP
                 */

                if ((Command & 0x0001) != 0) {
                    /*
                     * LOOP
                     */

                    /*
                     * if loop count is 0, this acts like a NOP
                     */

                    /*
                     * check repeat count
                     */
                    if (pChannel[ChannelIndex].RepeatCount != 0) {
                        /*
                         * decrement count
                         */
                        pChannel[ChannelIndex].RepeatCount--;

                        /*
                         * reload channel addr from stored loop start
                         */
                        Addr = pChannel[ChannelIndex].LoopStart;
                    }

                }

                if ((Command & 0x0010) != 0) {
                    /*
                     * INT
                     */

                    /*
                     * set channel interrupt
                     */
                    ASIC_Data.InternalDCSR |= 1 << (6 - ChannelIndex);
                }

                if ((Command & 0x0020) != 0) {
                    /*
                     * STOP
                     */

                    /*
                     * stop channel
                     */
                    ASIC_Data.InternalDCSR &= ~(1 << ChannelIndex);
                }
            }
        }

        ASIC_DMA_WriteChannelAddr(ChannelIndex, Addr);
        ASIC_UpdateRAMWithInternalDCSR();

    }

    void ASIC_DMA_HandleChannel(int ChannelIndex) {
//        ASIC_DMA_CHANNEL pChannel[] = this.pChannel;
        if (pChannel[ChannelIndex].PauseActive) {
            /*
             * is prescale count = 0? i.e. count has finished?
             */
            if (pChannel[ChannelIndex].PrescaleCount == 0) {
                /*
                 * channel prescale count finished
                 */

                /*
                 * get new prescale
                 */
                pChannel[ChannelIndex].PrescaleCount = DMA[ChannelIndex].Prescale;

                /*
                 * is there a pause active?
                 */
                if (pChannel[ChannelIndex].PauseCount == 0) {
                    pChannel[ChannelIndex].PauseActive = false;
                } else {
                    pChannel[ChannelIndex].PauseCount--;
                }
            } else {
                /*
                 * update pre-scale count
                 */
                pChannel[ChannelIndex].PrescaleCount--;
            }
        }

        if (!(pChannel[ChannelIndex].PauseActive)) {
            /*
             * execute DMA command
             */
            ASIC_DMA_ExecuteCommand(ChannelIndex);
        }
    }
    int lockvalue = 0xCD;

    public void ASIC_EnableDisable(int value) {
        value &= 0x0ff;
        switch (RecogniseSequenceState) {
            case SEQUENCE_SYNCHRONISE_FIRST_BYTE: {
                /*
                 * we are waiting for the first byte of synchronisation
                 */
                if (value != 0) {
                    RecogniseSequenceState = SEQUENCE_SYNCHRONISE_SECOND_BYTE;
                }
            }
            break;

            case SEQUENCE_SYNCHRONISE_SECOND_BYTE: {
                /*
                 * at this point we already have a non-zero byte to start the
                 * synchronisation.
                 *
                 * we are waiting for the second byte of synchronisation
                 *
                 * this byte must be zero for synchronisation. If it is
                 * non-zero, then it can still count as part of the
                 * synchronisation.
                 */

                if (value == 0x00) {
                    /*
                     * got zero. We are now waiting for the first byte of the
                     * sequence
                     */
                    RecogniseSequenceState = SEQUENCE_SYNCHRONISE_THIRD_BYTE;
                }
            }
            break;

            case SEQUENCE_SYNCHRONISE_THIRD_BYTE: {
                /*
                 * we are waiting for the first data byte of the sequence. To
                 * get here we must have had a non-zero byte followed by a zero
                 * byte
                 */

                /*
                 * have we got the first byte of the sequence?
                 */
                if (value == 0x0ff) {
                    /*
                     * first byte of sequence, get ready to recognise the
                     * sequence.
                     */
                    RecogniseSequenceState = SEQUENCE_RECOGNISE;
                    CurrentSequencePos = 1;
                } else {
                    if (value != 0) {
                        /*
                         * we got a non-zero byte, and it wasn't the first part
                         * of the sequence. / this could act as the first byte
                         * of synchronisation ready for a zero / to follow.
                         */
                        RecogniseSequenceState = SEQUENCE_SYNCHRONISE_SECOND_BYTE;
                    }

                    /*
                     * if we got a zero, we are still synchronised. We are still
                     * waiting for the first byte of sequence.
                     */
                }

            }
            break;

            case SEQUENCE_RECOGNISE: {
                /*
                 * we want to recognise the sequence. We already recognise the
                 * first byte.
                 */

                if (value == 0x000) {
                    RecogniseSequenceState = SEQUENCE_SYNCHRONISE_THIRD_BYTE;
                } else {
//                    if (value == ASIC_EnableSequence[CurrentSequencePos]) {
                        /*
                     * data byte the same as sequence
                     */

                    /*
                     * ready for next char in sequence
                     */
                    CurrentSequencePos++;

                    if (CurrentSequencePos == ASIC_EnableSequence.length) {
                        /*
                         * store value to lockvalue
                         */
                        lockvalue = value;
                        if (lockvalue != 0x0cd) {
                            checkLockStatus(value);
                        }

                        /*
                         * sequence is almost complete. If next byte is sent
                         * then the asic will be enabled / disabled depending on
                         * lockvalue.
                         */
                        RecogniseSequenceState = SEQUENCE_GET_LOCK_STATUS;
                        break;
                    }
//                    } else {
//                        CurrentSequencePos = 0;
//                        RecogniseSequenceState = SEQUENCE_SYNCHRONISE_SECOND_BYTE;
//                    }
                }
            }
            break;

            case SEQUENCE_GET_LOCK_STATUS: {
                /*
                 * the sequence has been correct up to this point, therefore we
                 * want to lock or un-lock the ASIC
                 */
                checkLockStatus(value);
            }
            break;
        }
    }

    public void checkLockStatus(int value) {
        if (asicLocked != (lockvalue != 0x0cd)) {
            asicLocked = lockvalue != 0x0cd;

            if (!asicLocked) {
                setModeAndROMEnable();
            }
            System.out.println("ASIC " + (asicLocked ? "L" : "Unl") + "ocked!!! " + Util.hex((byte) lockvalue));
            lockvalue = 0xcd;
            cpc.memory.asiclocked = asicLocked;
        }
        if (value != 0) {
            RecogniseSequenceState = SEQUENCE_SYNCHRONISE_SECOND_BYTE;
        } else {
            RecogniseSequenceState = SEQUENCE_SYNCHRONISE_FIRST_BYTE;
        }
    }
}
