package JCPC.system.cpc;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import JCPC.core.*;
import JCPC.core.cpu.*;
import JCPC.core.device.*;
import JCPC.core.device.crtc.*;
import JCPC.core.device.floppy.*;
import JCPC.core.device.io.*;
import JCPC.core.device.memory.*;
import JCPC.core.device.sound.*;
import JCPC.ui.*;
import JCPC.system.cpc.plus.*;
import javax.swing.Timer;
import JCPC.core.device.tape.CDT2WAV;
import JCPC.util.diss.Disassembler;
import JCPC.util.diss.DissZ80;
import java.util.Arrays;
import java.util.Collections;

/**
 * Title: JCPC Description: The Java Emulation Platform Copyright: Copyright (c)
 * 2002 Company:
 *
 * @author
 * @version 1.0
 */
public class CPC extends Computer implements ActionListener {

    boolean rubbercheat = false;
    protected Disassembler disassembler = new DissZ80();

    public void actionPerformed(ActionEvent e) {
        if (poker != null && e.getSource() == poker.poke) {
            int s = poker.preset.getSelectedIndex();
            switch (s) {
                case 0:
                    this.POKE(poker.getAddress(), poker.getValue());
                    break;
                case 1:
                    this.POKE(0x3f30, 9);
                    this.POKE(0x4707, 0);
                    display.requestFocus();
                    break;
                case 2:
                    this.POKE(0x7df, 153);
                    rubbercheat = true;
                    display.requestFocus();
                    break;
                case 3:
                    this.POKE(0x44a6, 0x03a);
                    display.requestFocus();
                    break;
                case 4:
                    this.POKE(0x2e3d, 0);
                    this.POKE(0x2678, 0);
                    this.POKE(0x938b, 0x39);
                    this.POKE(0x938c, 0x39);
                    this.POKE(0x938d, 0x39);
                    display.requestFocus();
                    break;
                case 5:
                    this.POKE(0x1dc0, 0);
                    this.POKE(0x27c9, 0xb7);
                    this.POKE(0x27d3, 0xb7);
                    display.requestFocus();
                    break;
                case 6:
                    this.POKE(0xbcc, 0x70);
                    this.POKE(0xbd0, 0x6c);
                    this.POKE(0xb12, 0xc9);
                    display.requestFocus();
                    break;
            }
            return;
        }
        if (csd == null) {
            return;
        }
        if (e.getSource() == csd.load1) {
            loadCSD(1);
        }
        if (e.getSource() == csd.load2) {
            loadCSD(2);
        }
        if (e.getSource() == csd.load3) {
            loadCSD(3);
        }
        if (e.getSource() == csd.load4) {
            loadCSD(4);
        }
        if (e.getSource() == csd.load5) {
            loadCSD(5);
        }
        if (e.getSource() == csd.load6) {
            loadCSD(6);
        }
        if (e.getSource() == csd.load7) {
            loadCSD(7);
        }
        if (e.getSource() == csd.load8) {
            loadCSD(8);
        }
        if (e.getSource() == csd.load9) {
            loadCSD(9);
        }
        if (e.getSource() == csd.load10) {
            loadCSD(10);
        }
        if (e.getSource() == csd.load11) {
            loadCSD(11);
        }
        if (e.getSource() == csd.load12) {
            loadCSD(12);
        }
        if (e.getSource() == csd.shuffle) {
            loadShuffledCSD();
        }
        if (e.getSource() == csd.jRadioButton1) {
            jukebox.setTimer(0);
        }
        if (e.getSource() == csd.jRadioButton2) {
            jukebox.setTimer(1);
        }
        if (e.getSource() == csd.jRadioButton3) {
            jukebox.setTimer(2);
        }
        if (e.getSource() == csd.jRadioButton4) {
            jukebox.setTimer(3);
        }
        if (e.getSource() == csd.jRadioButton5) {
            jukebox.setTimer(4);
        }
        if (e.getSource() == csd.csdmode) {
//            jukebox.setTimer(0);
            this.reset();
            CSD = !CSD;
            if (!CSD) {
                csd.csdmode.setText("Start CSD Mode");
//            byte[] cpr = getRom("plus/Plus.cpr", 131148);
                byte[] cpr = getRom("plus/CPC_PLUS.CPR", 131156);
                cprslot = 0;
                CPRLoad(cpr, "none");
            }
            if (CSD) {
                csd.csdmode.setText("Exit CSD Mode");
                byte[] cpr = getRom("plus/CSD.CPR", 32976);
                cprslot = 0;
                CPRLoad(cpr, "none");
            }
            this.reSync();
        }

    }
    String[] random = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24"};
    String[] random2 = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24"};

    public void loadShuffledCSD() {
        System.arraycopy(random2, 0, random, 0, random.length);
        Collections.shuffle(Arrays.asList(random));
        for (int i = 1; i < 13; i++) {
            loadInternalCSD(Integer.parseInt(random[i - 1]), i);
        }
    }

    protected void loadInternalCSD(int game, int slot) {
        byte[] data = getCart(game);
        cprload[slot].readCPR2(data, display.carts[game]);
        String name = display.carts[game];
        switch (slot) {
            case 1:
                csd.cpr01.setText(name);
                break;
            case 2:
                csd.cpr02.setText(name);
                break;
            case 3:
                csd.cpr03.setText(name);
                break;
            case 4:
                csd.cpr04.setText(name);
                break;
            case 5:
                csd.cpr05.setText(name);
                break;
            case 6:
                csd.cpr06.setText(name);
                break;
            case 7:
                csd.cpr07.setText(name);
                break;
            case 8:
                csd.cpr08.setText(name);
                break;
            case 9:
                csd.cpr09.setText(name);
                break;
            case 10:
                csd.cpr10.setText(name);
                break;
            case 11:
                csd.cpr11.setText(name);
                break;
            case 12:
                csd.cpr12.setText(name);
                break;
        }
    }

    protected void loadCSD(int slot) {
        int old = cprslot;
        cprslot = slot;
        FileDialog filedia = new FileDialog((Frame) new Frame(), "Open CPC+ Cartridge file", FileDialog.LOAD);
        filedia.setFile("*.cpr");
        filedia.setVisible(true);
        String filename = filedia.getFile();
        try {
            if (filedia.getFile() != null) {
                filename = filedia.getDirectory() + filedia.getFile();
                byte[] data = getFile(filename);
                System.out.println("Loading " + filename + " to CSD slot " + slot);
                cprload[cprslot].readCPR2(data, filename);
                String name = filedia.getFile();
                switch (slot) {
                    case 1:
                        csd.cpr01.setText(name);
                        break;
                    case 2:
                        csd.cpr02.setText(name);
                        break;
                    case 3:
                        csd.cpr03.setText(name);
                        break;
                    case 4:
                        csd.cpr04.setText(name);
                        break;
                    case 5:
                        csd.cpr05.setText(name);
                        break;
                    case 6:
                        csd.cpr06.setText(name);
                        break;
                    case 7:
                        csd.cpr07.setText(name);
                        break;
                    case 8:
                        csd.cpr08.setText(name);
                        break;
                    case 9:
                        csd.cpr09.setText(name);
                        break;
                    case 10:
                        csd.cpr10.setText(name);
                        break;
                    case 11:
                        csd.cpr11.setText(name);
                        break;
                    case 12:
                        csd.cpr12.setText(name);
                        break;
                }
            }
        } catch (Exception e) {
        }
        cprslot = old;
        this.reSync();
    }
    public static boolean CSD = false;
    private CSDGui csd;
    private int computername = 7;
    public CPRLoader cprload[] = new CPRLoader[13];
    // Conversion of CPC BDIR & BC1 values 0..3 to PSG values
    protected AY_3_8910 psg = (AY_3_8910) addDevice(new AY_3_8910());
    protected final int[] PSG_VALUES = new int[]{
        psg.BC2_MASK,
        psg.BC2_MASK | psg.BC1_MASK,
        psg.BC2_MASK | psg.BDIR_MASK,
        psg.BC2_MASK | psg.BDIR_MASK | psg.BC1_MASK
    };
    // Port mappings
    protected static final int PSG_PORT_A = -1;
    protected static final int PPI_PORT_B = -2;
    protected static final int PPI_PORT_C = -3;
    protected static final int CYCLES_PER_SECOND = 1000000;
    protected static final int AUDIO_TEST = 0x40000000;
    public Z80 z80 = new Z80(CYCLES_PER_SECOND);
    protected Basic6845 crtc = (Basic6845) addDevice(new Basic6845(this));
    protected GateArray gateArray = (GateArray) addDevice(new GateArray(this));
    public CPCMemory memory = new CPCMemory(CPCMemory.TYPE_512K, this, gateArray);
    protected ASIC asic = (ASIC) addDevice(new ASIC(this, gateArray, psg, z80));
    protected JukeBox jukebox = (JukeBox) addDevice(new JukeBox(this));
    protected PPI8255 ppi = (PPI8255) addDevice(new PPI8255());
    protected UPD765A fdc = (UPD765A) addDevice(new UPD765A(4));  // 4 cycles per call to cycle()
    protected Keyboard keyboard = new Keyboard();
    protected int audioAdd = psg.getSoundPlayer().getClockAdder(AUDIO_TEST, CYCLES_PER_SECOND);
    protected int audioCount = 0;
    protected Drive[] floppies = new Drive[2];
    protected AmDrum amdrum = (AmDrum) addDevice(new AmDrum());
    protected DigiBlaster digiblaster = (DigiBlaster) addDevice(new DigiBlaster());
    private int previousPortValue;
    private boolean relay;
    private boolean stoptape = false;
    private int tapestopper = 0;
    private int playcount = 0;
    private int pause = 0;
    public static int tapePosition = 0;
    private int tape_delay = 22;
    public static byte tapesample[] = new byte[0];
    private boolean play = false;
    private int portB;
    private int tapesound;
    public static boolean internal = false;

    public void Z80_AcknowledgeInterrupt() {
        /*
         * interrupt acknowledge func
         */

        /*
         * CRTC acknowledge int
         */
        gateArray.GateArray_AcknowledgeInterrupt();
        /*
         * ASIC acknowledge int
         */
        asic.ASIC_AcknowledgeInterrupt();

        z80.Z80_ClearInterruptRequest();
    }

    public AY_3_8910 getPSG() {
        return psg;
    }

    public CPC(Applet applet, String name) {
        super(applet, name);
        z80.setMemoryDevice(memory);
//        z80.addOutputDeviceMapping(new DeviceMapping(memory, 0x2000, 0x0000)); // ROM Select
        z80.setInterruptDevice(gateArray);
//        z80.addOutputDeviceMapping(new DeviceMapping(gateArray, 0xc000, 0x4000)); // All GA functions
        z80.addOutputDeviceMapping(new DeviceMapping(asic, 0xc000, 0x4000)); // CPC+ ASIC
        z80.addOutputDeviceMapping(new DeviceMapping(asic, 0x2000, 0x0000)); // CPC+ ASIC ROM Mapping
        z80.addInputDeviceMapping(new DeviceMapping(asic, 0xc000, 0x4000));
        z80.addOutputDeviceMapping(new DeviceMapping(jukebox, 0xffec, 0xfbe0)); // CPC+ JukeBox
        z80.addInputDeviceMapping(new DeviceMapping(jukebox, 0xffec, 0xfbe0));
        z80.setCycleDevice(this);
        crtc.setRegisterSelectMask(0x0300, 0x0000);
        crtc.setRegisterWriteMask(0x0300, 0x0100);
        crtc.setRegisterReadMask(0x0300, 0x0300);
        crtc.setRegisterStatusMask(0x0300, 0x0200);
        crtc.setCRTCListener(gateArray);
        z80.addOutputDeviceMapping(new DeviceMapping(crtc, 0x4000, 0x0000));
        z80.addInputDeviceMapping(new DeviceMapping(crtc, 0x4000, 0x0000));
        ppi.setPortMasks(0x0100, 0x0100, 0x0200, 0x0200);
        ppi.setReadDevice(PPI8255.PORT_B, this, PPI_PORT_B);
        ppi.setWriteDevice(PPI8255.PORT_C, this, PPI_PORT_C);
        ppi.setReadDevice(PPI8255.PORT_A, psg, 0);
        ppi.setWriteDevice(PPI8255.PORT_A, psg, 0);
        psg.setReadDevice(psg.PORT_A, this, PSG_PORT_A);
        psg.setClockSpeed(CYCLES_PER_SECOND);
        z80.addOutputDeviceMapping(new DeviceMapping(ppi, 0x0800, 0x0000));
        z80.addInputDeviceMapping(new DeviceMapping(ppi, 0x0800, 0x0000));
        z80.addOutputDeviceMapping(new DeviceMapping(fdc, 0x0580, 0x0100));
        z80.addInputDeviceMapping(new DeviceMapping(fdc, 0x0580, 0x0100));
        z80.addOutputDeviceMapping(new DeviceMapping(this, 0x581, 0x0000));
//        z80.addOutputDeviceMapping(new DeviceMapping(amdrum, 0xFF00, 0xFF00));
//        z80.addInputDeviceMapping(new DeviceMapping(amdrum, 0xFF00, 0xFF00));
//        z80.addOutputDeviceMapping(new DeviceMapping(digiblaster, 0x1000, 0x00));
        for (int i = 0; i < 2; i++) {
            fdc.setDrive(i, floppies[i] = new Drive(i == 0 ? 1 : 2));
            fdc.setDrive(i, null);
        }
        setBasePath("cpc");
        if (csd == null) {
            csd = new CSDGui();
            csd.setCSD(CSD);
            csd.load1.addActionListener(this);
            csd.load2.addActionListener(this);
            csd.load3.addActionListener(this);
            csd.load4.addActionListener(this);
            csd.load5.addActionListener(this);
            csd.load6.addActionListener(this);
            csd.load7.addActionListener(this);
            csd.load8.addActionListener(this);
            csd.load9.addActionListener(this);
            csd.load10.addActionListener(this);
            csd.load11.addActionListener(this);
            csd.load12.addActionListener(this);
            csd.shuffle.addActionListener(this);
            csd.jRadioButton1.addActionListener(this);
            csd.jRadioButton2.addActionListener(this);
            csd.jRadioButton3.addActionListener(this);
            csd.jRadioButton4.addActionListener(this);
            csd.jRadioButton5.addActionListener(this);
            csd.csdmode.addActionListener(this);
        }
        if (CSD) {
//            checkCSD();
        }
        for (int i = 0; i < 13; i++) {
            try {
                cprload[i] = new CPRLoader();
                cprslot = i;
                if (CSD) {
                    if (i == 0) {
//                        loadFile(0, "file/jukebox.zip");
                    } else {
                        if (!GX4000.isStandalone) {
                            String filename = "file/test" + i + ".zip";
                            System.err.println("Opening " + filename);
                            loadFile(0, filename);
                        }
                    }
                } else {
                    if (i != 0) {
                        this.loadInternalCSD(internalCSD[i], i);
                    }
                }
            } catch (Exception e) {
            }
        }
    }
    public int cprslot = 0;
    Poker poker;

    public void checkPoker() {
        if (poker == null) {
            poker = new Poker();
            poker.poke.addActionListener(this);
        }
        poker.setVisible(true);
    }

    public void checkCSD() {
        if (CSD) {
            csd.csdmode.setText("Exit CSD Mode");
//            byte[] cpr = getRom("plus/CSD.CPR", 32976);
//            cprslot = 0;
//            CPRLoad(cpr, "none");
        } else {
            csd.csdmode.setText("Start CSD Mode");
        }
        csd.setVisible(true);
    }

    public Basic6845 CRTC() {
        return crtc;
    }
    public static int cartindex = 2;

    @Override
    public void initialise() {
        windows = Util.isWindows();
        gateArray.setMemory(memory.getMemory());
        super.initialise();
        psg.getSoundPlayer().play();
        if (internal) {
            cprslot = 0;
            CPRLoad(getCart(cartindex), "none");
        }

        if (CSD) {
            byte[] cpr = getRom("plus/CSD.CPR", 32976);
            cprslot = 0;
            CPRLoad(cpr, "none");
        }
        internal = false;
//        memory.setLowerROM(getRom("roms/OS6128.ROM", 0x4000));
//        memory.setUpperROM(0, getRom("roms/BASIC1-1.ROM", 0x4000));
        memory.setUpperROM(7, getRom("roms/PARADOS.ROM", 0x4000));
//        System.out.println("GX4000 initialized");
    }

    public GateArray getGateArray() {
        return gateArray;
    }

    public ASIC getAsic() {
        return asic;
    }

    public int storing() {
        return fdc.saveTimer;
    }

    public void loadSystem() {
        byte[] cpr = getRom("plus/CPC_PLUS.CPR", 131156);
        cprslot = 0;
        CPRLoad(cpr, "none");
    }

    public void openCartridge() {
        FileDialog filedia = new FileDialog((Frame) new Frame(), "Open CPC+ Cartridge file", FileDialog.LOAD);
        filedia.setFile("*.cpr");
        filedia.setVisible(true);
        String filename = filedia.getFile();
        if (filedia.getFile() != null) {
            filename = filedia.getDirectory() + filedia.getFile();
            openCartridge(filename);
        }
    }

    public void putPlusRoms() {
        for (int i = 0; i < 32; i++) {
            byte[] rom = cprload[cprslot].getData(i);
            memory.setPlusROM(i, rom);
        }
    }

    public void openCartridge(String filename) {
        if (filename.contains("http")) {
            try {
                cprload[cprslot].openCPR(new java.net.URL(filename));
                loadedplus = true;
                putPlusRoms();
                memory.setCartridge(cprload[cprslot].getCPR());
                gateArray.setMemory(memory.getMemory());
                memory.remap();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }
        cprload[cprslot].openCPR(filename);
        loadedplus = true;
        putPlusRoms();
        memory.setCartridge(cprload[cprslot].getCPR());
        gateArray.setMemory(memory.getMemory());
        memory.remap();
    }
    public static boolean loadedplus = false;

    public void CPRLoad(byte[] data, String filename) {
        System.out.println("Loading data...");
        cprload[cprslot].readCPR(data, filename);
        loadedplus = true;
        putPlusRoms();
        memory.setCartridge(cprload[cprslot].getCPR());
        gateArray.setMemory(memory.getMemory());
        memory.remap();
        start();
    }

    public void remapCPR(boolean reset) {
        reset = true;
        try {
            if (reset) {
                super.reset();
            }
//            psg.resetRegisters();

            putPlusRoms();
            memory.setCartridge(cprload[cprslot].getCPR());
            gateArray.resetCPCColours();
            gateArray.setMemory(memory.getMemory());
            if (reset) {
                asic.reset();
                crtc.reset();
                gateArray.init();
                memory.reset();
                z80.reset();
                z80.setPC(0x0ffff);
                donewreset = 1;
            }
        } catch (Exception e) {
        }

    }
    int donewreset = 0;

    public void loadCPR() {
        try {

            putPlusRoms();
            memory.setCartridge(cprload[cprslot].getCPR());
            gateArray.setMemory(memory.getMemory());
            loadedplus = true;
//        cprslot = 0;
            gateArray.resetCPCColours();
            doscratch = 0;
            gateArray.init();
            memory.remap();
            z80.reset();
            tapePosition = 0;
            pause = 0;
            play = false;
            reSync();
            cprslot = 0;
        } catch (Exception e) {
        }
    }

    public void reset() {
        super.reset();
        jukebox.resetJukeBox();
        rubbercheat = false;
        donewreset = 1;
        gateArray.reset();
        memory.plus = true;
        cprslot = 0;
        if (memory.plus) {
            try {
                putPlusRoms();
                memory.setCartridge(cprload[cprslot].getCPR());
                gateArray.setMemory(memory.getMemory());
                loadedplus = true;
            } catch (Exception e) {
            }
        }
        gateArray.setMemory(memory.getMemory());
        gateArray.resetCPCColours();
        try {
            asic.reset();
        } catch (Exception e) {
        }
        doscratch = 0;
        gateArray.init();
        memory.reset();
        z80.reset();
        tapePosition = 0;
        pause = 0;
        play = false;
        reSync();
    }

    public void dispose() {
        super.dispose();
        psg.getSoundPlayer().dispose();
    }
    long doscratch = 0;
    boolean cycle;

    public Basic6845 getCRTC() {
        return crtc;
    }
    long sp1, sp2;
    int poop = 0;
    int old;
    int adder;

    public void cycle() {
        if (crtc.cyclecount %26 == 16) {
//            crtc.doAsicHsync(false);
//            adder = crtc.cyclecount;
//            System.out.println(adder);
        }
        if (divider < 3) {
            sp1 = System.currentTimeMillis();
        }
        fdc.cycle();
        psg.cycle();
        if ((audioCount += audioAdd / divider) >= AUDIO_TEST) {
            psg.writeAudio();
            audioCount -= AUDIO_TEST;
        }
        if (crtc.Scratchdemo) {
            if (cycle) {
                gateArray.cycle();
                gateArray.cycle();
                doscratch++;
            }
            if (doscratch > 17128089) {
                crtc.Scratchdemo = false;
                doscratch = 0;
            }
            cycle = !cycle;
        } else {
            if (!crtc.Scratchdemo) {
                doscratch = 0;
            }
            doscratch = 0;
            gateArray.cycle();
        }
        if (relay && play) {
//            AY_3_8910.tape = true;
            tapeCycle();
        } else {
//            AY_3_8910.tape = false;
        }
        if (divider < 3) {
            sp2 = System.currentTimeMillis() - sp1;
            if (sp2 > 200 * divider) {
//                System.out.println(sp2);
                this.reSync();
            }
        }
    }
    /* calculate checksum as AMSDOS would for the first 66 bytes of a datablock */
    /* this is used to determine if a file has a AMSDOS header */

    public static int ChecksumAMSDOS(byte pHeader[]) {
        int Checksum;
        int i;
        Checksum = 0;
        for (i = 0; i < 67; i++) {
            int CheckSumByte;
            CheckSumByte = pHeader[i] & 0x0ff;
            Checksum += CheckSumByte;
        }
        return Checksum;
    }

    public static boolean CheckAMSDOS(byte pHeader[]) {
        int CalculatedChecksum;
        int ChecksumFromHeader;
        try {
            CalculatedChecksum = ChecksumAMSDOS(pHeader);
        } catch (Exception e) {
            return false;
        }
        ChecksumFromHeader = (pHeader[67] & 0x0ff) | (pHeader[68] & 0x0ff) << 8;
        if (ChecksumFromHeader == CalculatedChecksum && ChecksumFromHeader != 0) {
            System.out.println("Has AMSDOS header");
            return true;
        }
        System.out.println("Without header");
        return false;
    }

    public void loadBinary(byte[] data) {
        int start = Device.getWord(data, 21);
        int exec = Device.getWord(data, 26);
        byte[] file = new byte[data.length - 0x080];
        System.arraycopy(data, 0x080, file, 0, file.length);
        System.out.println("loading to " + Util.hex((short) start));
        for (int i = 0; i < file.length; i++) {
            POKE(start + i, file[i] & 0x0ff);
        }
        if (exec != 0) {
            this.AutoType("'Start: &" + Util.hex((short) exec));
        }
    }

    public void setDisplay(Display value) {
        super.setDisplay(value);
        gateArray.setDisplay(value);
    }

    public void setFrameSkip(int value) {
        super.setFrameSkip(value);
        gateArray.setRendering(value == 0);
    }
    String[] basictypetext;
    int basictypelength = -1;
    int basicchecktype = 0;
    int basictypepos = 0;
    protected int BUFFER_START = 0xac8a;

    public void AutoType(String input) {
        input = input.replace("" + (char) 0x0d, "");
        basictypetext = input.split("" + (char) 10);
        basictypelength = basictypetext.length - 1;
        basictypepos = 0;
        doTurbo = true;
    }
    public boolean doTurbo = false;
    Autotype typ;

    public void autotype() {
        if (typ == null) {
            typ = new Autotype();
            typ.setVisible(false);
            typ.send.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    typ.setVisible(false);
                    AutoType(typ.text.getText());
                }
            });
        }
        typ.setVisible(true);
    }

    public void BasicAutoType() {
        if (basictypetext == null) {
            basictypelength = -1;
            doTurbo = false;
            return;
        }
        if (basictypepos >= basictypelength) {
            doTurbo = false;
        }
        if (basictypepos > basictypelength) {
            doTurbo = false;
            basictypepos = 0;
            basictypelength = -1;
            basictypetext = null;
            return;
        }
        BasicPutText(basictypetext[basictypepos++]);
    }

    public void BasicPutText(String input) {
        if (input.length() > 255) {
            return;
        }
        if (input.length() < 1) {
            basicchecktype = 1;
            return;
        }
        for (int i = 0; i < 255; i++) {
            memory.writeByte(BUFFER_START + i, 0);
        }
        for (int i = 0; i < input.length(); i++) {
            memory.writeByte(BUFFER_START + i, (int) input.charAt(i));
        }
        System.out.println(input);
        basicchecktype = 1;
    }
    int prepare = 0;
    String typetext = null;

    public void prepareAutotype(String input) {
        prepare = 1;
        typetext = input;
    }
    int divider = 1;
    int olddiv = 1;

    public void vSync() {
        if (rubbercheat) {
            this.POKE(0x7df, 153);
        }
        if (donewreset != 0) {
            donewreset++;
            if (donewreset == 2) {
                donewreset = 0;
                asic.reset();
                crtc.reset();
                gateArray.init();
                memory.reset();
                z80.reset();
                z80.setPC(0x0ffff);
            }
        }
        if (olddiv != divider) {
            olddiv = divider;
            reSync();
        }
        if (prepare != 0) {
            prepare++;
            if (prepare == 100) {
                this.keyPressed(KeyEvent.VK_NUMPAD1);
            }
            if (prepare == 110) {
                this.keyReleased(KeyEvent.VK_NUMPAD1);
            }
            if (prepare == 150) {
                prepare = 0;
                AutoType(typetext);
            }
        }
        if (doTurbo) {
            divider = turbospeed;
        } else {
            divider = 1;
        }
        try {
            display.turbo = doTurbo;
        } catch (Exception e) {
        }
        if (basictypelength > -1) {
            basicchecktype++;
            if (basicchecktype == 1) {
                BasicAutoType();
            }
            if (basicchecktype == 2) {
                keyboard.keyPressed(KeyEvent.VK_ENTER);
            }
            if (memory.readByte(BUFFER_START) == 0 && basicchecktype > 3) {
                basicchecktype = 0;
                keyboard.keyReleased(KeyEvent.VK_ENTER);
            }
        }
        if (stosna) {
            stosna = false;
            storeSNA();
            return;
        }
        if (resna) {
            resna = false;
            restoreSNA();
            return;
        }

        if (frameSkip == 0) {
            try {
                display.updateImage(true);
            } catch (Exception e) {
            }
        }
        if (windows) {
            syncProcessor(psg.getSoundPlayer());
        } else {
            syncProcessor();
        }
        if (stoptape && tapestopper >= 1) {
            tapestopper++;
            if (tapestopper == 2) {
                StopTape();
                tapestopper = 0;
            }
        }

    }
    boolean windows;

    public Memory getMemory() {
        return memory;
    }

    public Processor getProcessor() {
        return z80;
    }

    public Dimension getDisplaySize(boolean large) {
        return gateArray.getDisplaySize(true);
    }

    @Override
    public Disassembler getDisassembler() {
        return disassembler;
    }

    public Dimension getDisplayScale(boolean large) {
        return Display.SCALE_1x2;
    }

    public int readPort(int port) {
        int result = 0xff;
        switch (port) {
            case PPI_PORT_C:
                result = 1;
//                System.out.println("Port read..." + Util.hex(port) + " result:" + result);
                break;
            case PPI_PORT_B:
                result = (((0x040) | 0x010)
                        | (computername * 2) | (crtc.isVSync() ? 0x01 : 0) | portB);
                portb = result;
                break;

            case PSG_PORT_A: {
                result = keyboard.readSelectedRow();
                porta = result;
                break;
            }
        }
        return result;
    }

    public void writePort(int port, int value) {
        switch (port) {

            case PPI_PORT_C:
                psg.setBDIR_BC2_BC1(PSG_VALUES[value >> 6], ppi.readOutput(PPI8255.PORT_A));
                keyboard.setSelectedRow(value & 0x0f);
                if ((value & 0x020) == 0x20) {
                    psg.digicount = 1;
                }
                if ((((value ^ previousPortValue) & 0x010) != 0) || ((value & 0x10) == 0x10)) {
                    TapeRelayCheck(value);
                }
                break;

            default:
                // FDC Motor control
                if ((port & 0x0581) == 0) {
                    if (port >= 0xfa00) {
                        if ((value & 0x01) == 0) {
                            Display.ledOn = false;
                            Samples.MOTOR.play();
                        } else {
//                            fdc.seeker = 1;
                            Samples.MOTOR.loop2();
                            Display.ledOn = true;
                        }
                    }
                }
        }
    }
    protected int[] internalCSD = {
        -1,
        2, 3, 5, 6, 7, 10, 11, 13, 16, 17, 18, 22, 24
    };
    protected String[] carts = {
        "barbarian2",
        "batman",
        "burninrubber",
        "copter271",
        "crazycars2",
        "dicktracy",
        "epyxworldofsports",
        "fireandforget2",
        "klax",
        "mystical",
        "navyseals",
        "noexit",
        "operationthunderbolt",
        "pang",
        "panzakickboxing",
        "plotting",
        "protennistour",
        "robocop2",
        "skeetshot",
        "superpinballmagic",
        "switchblade",
        "tenniscup2",
        "theenforcer",
        "tintinonthemoon",
        "wildstreets",
        "cpc_plus"
    };

    public void loadCart(int index) {
        CPRLoad(getCart(index), "none");
        reset();
    }

    protected byte[] getCart(int index) {
        return getRom("plus/cpr/" + carts[index] + ".bin", 131072);
    }
    public static int turbospeed = 2;

    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_PAUSE) {
            checkCSD();
            e.consume();
        }
        if (e.getKeyCode() == KeyEvent.VK_PRINTSCREEN) {
            e.consume();
        }
        if (e.getKeyCode() == KeyEvent.VK_F6) {
//        call (0x006);
            return;
        }
        if (e.getKeyCode() == KeyEvent.VK_F11) {
            return;
        }
        if (e.getKeyCode() == KeyEvent.VK_F8) {
            return;
        }
        if (e.getKeyCode() == KeyEvent.VK_F9) {
            if (!doTurbo) {
                doTurbo = !doTurbo;
            } else {
                turbospeed = turbospeed + 1;
                if (turbospeed > 6) {
                    turbospeed = 2;
                    doTurbo = false;
                }
            }
        }
        keyboard.keyPressed(e.getKeyCode());
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD0) {
            keyboard.keyPressed(KeyEvent.VK_PAGE_UP);
        }
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD5) {
            keyboard.keyPressed(KeyEvent.VK_INSERT);
        }
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD4) {
            keyboard.keyPressed(KeyEvent.VK_DELETE);
        }
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD8) {
            keyboard.keyPressed(KeyEvent.VK_HOME);
        }
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD6) {
            keyboard.keyPressed(KeyEvent.VK_PAGE_DOWN);
        }
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD2) {
            keyboard.keyPressed(KeyEvent.VK_END);
        }
//            KeyEvent.VK_HOME, KeyEvent.VK_END, KeyEvent.VK_DELETE, KeyEvent.VK_PAGE_DOWN,
//    KeyEvent.VK_INSERT, KeyEvent.VK_PAGE_UP, -1, KeyEvent.VK_BACK_SPACE
    }
//    Poker pokefield;
//    int poker = 0;

    public void keyPressed(int e) {
        keyboard.keyPressed(e);
    }

    public void keyReleased(int e) {
        keyboard.keyReleased(e);
    }

    public void openCPR() {
        cprload[0].OpenCPR();
        memory.setCartridge(cprload[cprslot].getCPR());
    }

    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_PAUSE) {
//            checkCSD();
            e.consume();
        }
        if (e.getKeyCode() == KeyEvent.VK_PRINTSCREEN) {
            checkPoker();
            e.consume();
        }
//        if (e.getKeyCode() == KeyEvent.VK_PAUSE) {
//            POKE(0x01726, poker);
//            System.err.println(Util.hex((byte) poker));
//            poker = (poker + 0x010) & 0x070;
//        }
        if (e.getKeyCode() == KeyEvent.VK_F6) {
//            openCartridge();
            cprload[0].OpenCPR();
            memory.setCartridge(cprload[cprslot].getCPR());
            return;
        }
//        if (e.getKeyCode() == KeyEvent.VK_PRINTSCREEN) {
//            if (pokefield == null) {
//                pokefield = new Poker();
//            }
//            pokefield.setVisible(true);
//            z80.stop();
//            return;
//        }
        if (e.getKeyCode() == KeyEvent.VK_F11) {
            autotype();
            return;
        }
        if (e.getKeyCode() == KeyEvent.VK_F8) {
            display.crtc = 150;
            if (crtc.CRTC == 0) {
                crtc.CRTC = 1;
            } else if (crtc.CRTC == 1) {
                crtc.CRTC = 3;
            } else {
                crtc.CRTC = 0;
            }
            return;
        }
        keyboard.keyReleased(e.getKeyCode());
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD0) {
            keyboard.keyReleased(KeyEvent.VK_PAGE_UP);
        }
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD5) {
            keyboard.keyReleased(KeyEvent.VK_INSERT);
        }
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD4) {
            keyboard.keyReleased(KeyEvent.VK_DELETE);
        }
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD8) {
            keyboard.keyReleased(KeyEvent.VK_HOME);
        }
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD6) {
            keyboard.keyReleased(KeyEvent.VK_PAGE_DOWN);
        }
        if (e.getKeyCode() == KeyEvent.VK_NUMPAD2) {
            keyboard.keyReleased(KeyEvent.VK_END);
        }
        if (e.getKeyCode() == KeyEvent.VK_F4) {
//            stosna = true;
//            display.storesna = 150;
        }

        if (e.getKeyCode() == KeyEvent.VK_F5) {
//            resna = true;
//            display.restoresna = 150;
        }
    }
    protected boolean resna, stosna;
    protected static final String CDT_HEADER = "ZXTAPE";
    protected static final String SNA_HEADER = "MV - SNA";
    protected static final String CSW_HEADER = "Compressed Square Wave";
    protected static final String CPR_HEADER = "RIFF";
    protected static final int CRTC_FLAG_VSYNC_ACTIVE = 0x01;
    protected static final int CRTC_FLAG_HSYNC_ACTIVE = 0x02;
    protected static final int CRTC_FLAG_HDISP_ACTIVE = 0x04;
    protected static final int CRTC_FLAG_VDISP_ACTIVE = 0x08;
    protected static final int CRTC_FLAG_HTOT_REACHED = 0x10;
    protected static final int CRTC_FLAG_VTOT_REACHED = 0x20;
    protected static final int CRTC_FLAG_MAXIMUM_RASTER_COUNT_REACHED = 0x40;
    protected static final int SNAPSHOT_ID = 0x0000;
    protected static final int VERSION = 0x0010;
    /*
     * 11	1	Z80 register F 12	1	Z80 register A 13	1	Z80 register C 14	1	Z80
     * register B 15	1	Z80 register E 16	1	Z80 register D 17	1	Z80 register L 18
     * 1	Z80 register H 19	1	Z80 register R 1a	1	Z80 register I
     */
    protected static final int F = 0x0011;
    protected static final int A = 0x0012;
    protected static final int C = 0x0013;
    protected static final int B = 0x0014;
    protected static final int E = 0x0015;
    protected static final int D = 0x0016;
    protected static final int L = 0x0017;
    protected static final int H = 0x0018;
    protected static final int AF = 0x0011;
    protected static final int BC = 0x0013;
    protected static final int DE = 0x0015;
    protected static final int HL = 0x0017;
    protected static final int R = 0x0019;
    protected static final int I = 0x001a;
    protected static final int IFF1 = 0x001b;
    protected static final int IFF2 = 0x001c;
    protected static final int IX = 0x001d;
    protected static final int IY = 0x001f;
    protected static final int SP = 0x0021;
    protected static final int PC = 0x0023;
    protected static final int IM = 0x0025;
    protected static final int AF1 = 0x0026;
    protected static final int BC1 = 0x0028;
    protected static final int DE1 = 0x002a;
    protected static final int HL1 = 0x002c;
    protected static final int GA_PEN = 0x002e;
    protected static final int GA_INKS = 0x002f;
    protected static final int GA_ROM = 0x0040;
    protected static final int GA_RAM = 0x0041;
    protected static final int CRTC_REG = 0x0042;
    protected static final int CRTC_REGS = 0x0043;
    protected static final int UPPER_ROM = 0x0055;
    protected static final int PPI_A = 0x0056;
    protected static final int PPI_B = 0x0057;
    protected static final int PPI_C = 0x0058;
    protected static final int PPI_CONTROL = 0x0059;
    protected static final int PSG_REG = 0x005a;
    protected static final int PSG_REGS = 0x005b;
    protected static final int MEM_SIZE = 0x006b;
//    protected static final int CPC_TYPE = 0x006d;
//    protected static final int VER_INT_BLOCK = 0x006d;
//    protected static final int VER_MODES = 0x006e;
//    protected static final int HEADER_SIZE = 0x0100;

    public void loadFile(int type, String name) throws Exception {
        byte[] data = getFile(name);
        if (this.CheckAMSDOS(data)) {
            loadBinary(data);
            return;
        }
        if (SNA_HEADER.equals(new String(data, 0, SNA_HEADER.length()))) {
            storedSnapshot = data;
            resna = true;
            return;
        } else if (CDT_HEADER.equals(new String(data, 0, CDT_HEADER.length()).toUpperCase())) {
            System.out.println("Open CDT tape file");
            CDT_Load(name, data);
//            reSync();
            return;
        } else if (CSW_HEADER.equals(new String(data, 0, CSW_HEADER.length()))
                || name.toUpperCase().endsWith(".CSW")) {
            System.out.println("Open CSW tape file");
            CSWLoad(name, data);
//            reSync();
            return;
        } else if (CPR_HEADER.equals(new String(data, 0, CPR_HEADER.length()))) {
            System.out.println("Open CPR cartridge file");
            try {
                CPRLoad(data, name);
            } catch (Exception e) {
                e.printStackTrace();
            }
//            reSync();
            return;
        } else {
            DSK_Load(name, data);
//            reSync();
        }
        reSync();
    }

    public void reSync() {
        psg.getSoundPlayer().resync();
    }

    private void SNA_Load(byte[] data) {
        z80.stop();
        z80.setAF(getWord(data, AF));
        z80.setBC(getWord(data, BC));
        z80.setDE(getWord(data, DE));
        z80.setHL(getWord(data, HL));
        z80.setR(data[R]);
        z80.setI(data[I]);
        z80.setIFF1(data[IFF1] != 0);
        z80.setIFF2(data[IFF2] != 0);
        z80.setIX(getWord(data, IX));
        z80.setIY(getWord(data, IY));
        z80.setSP(getWord(data, SP));
        z80.setPC(getWord(data, PC));
        z80.setIM(data[IM]);
        z80.setAF1(getWord(data, AF1));
        z80.setBC1(getWord(data, BC1));
        z80.setDE1(getWord(data, DE1));
        z80.setHL1(getWord(data, HL1));

        gateArray.setSelectedInk(data[GA_PEN]);
        for (int i = 0; i < 0x11; i++) {
            gateArray.setInk(i, data[GA_INKS + i]);
        }
        asic.romconfig = data[GA_ROM];
        asic.setModeAndROMEnable();
        memory.setRAMBank(data[GA_RAM]);

        crtc.setSelectedRegister(data[CRTC_REG]);
        for (int i = 0; i < 18; i++) {
            crtc.setRegister(i, data[CRTC_REGS + i]);
        }

        ppi.setControl(data[PPI_CONTROL] & 0xff | 0x80);
        ppi.setOutputValue(PPI8255.PORT_A, data[PPI_A] & 0xff);
        ppi.setOutputValue(PPI8255.PORT_B, data[PPI_B] & 0xff);
        int portC = data[PPI_C] & 0xff;
        ppi.setOutputValue(PPI8255.PORT_C, portC);

        psg.setBDIR_BC2_BC1(PSG_VALUES[portC >> 6], ppi.readOutput(PPI8255.PORT_A));

        psg.setSelectedRegister(data[PSG_REG]);
        for (int i = 0; i < 14; i++) {
            psg.setRegister(i, data[PSG_REGS + i] & 0xff);
        }

        int memSize = getWord(data, MEM_SIZE) * 1024;

        byte[] mem = memory.getMemory();
        System.arraycopy(data, 0x100, mem, 0, memSize);
        System.arraycopy(data, 0x100, gateArray.screenmemory, 0, 0x10000);
        try {
            byte[] plussna = new byte[getWord(data, memSize + 0x0104)];
            System.arraycopy(data, 0x108 + memSize, plussna, 0, plussna.length);

            // TODO: Implement all other CPC+ features
            asic.checkLockStatus((plussna[plussna.length - 1] != 0) ? 0x07d : 0);
            memory.asicRamActive = true;
            int off = 0;
            for (int i = 0; i < 0x0800; i++) {
                memory.writeByte(0x04000 + off++, (plussna[i] >> 4) & 0x0f);
                memory.writeByte(0x04000 + off++, plussna[i] & 0x0f);
                memory.writeSpriteData(i * 2, (plussna[i] >> 4) & 0x0f);
                memory.writeSpriteData((i * 2) + 1, plussna[i] & 0x0f);
            }
            off = 0;
            for (int i = 0x880; i < 0x08bf; i++) {
                memory.writeASIC(0x6400 + off++, plussna[i] & 0x0ff);
            }
            byte i = plussna[0x8c5];
            z80.setInterruptVector(i & 0x0ff);
            memory.remapRAM();
        } catch (Exception e) {
            System.out.println("Unsupported or no uncompressed CPC plus snapshot");
        }
        start();
    }
    final int PLUS_SPRITE_DATA = 0;
    final int PLUS_SPRITE_ATTRIBUTES = 0x800;
    final int PLUS_PALETTE = 0x880;

    public void loadEntry(int index) {
        try {
            if (disknames[index].toLowerCase().endsWith("dsk")) {
                DSK_Load(disknames[index], disks[index]);
            }
            if (disknames[index].toLowerCase().endsWith("sna")) {
                SNA_Load(disks[index]);
            }
        } catch (Exception er) {
        }
    }

    public void DSK_Load(String name, byte[] data) {
        CPCDiscImage image = new CPCDiscImage(name, data);
        int drive = getCurrentDrive();
        //  fdc.setDrive(drive, floppies[drive] = new Drive(drive == 0 ? 1 : 2));
        floppies[drive].setSides(image.getNumberOfSides());
        int heads = image.getNumberOfSides() == 1 ? Drive.HEAD_0 : Drive.BOTH_HEADS;
        fdc.setDrive(drive, floppies[drive]);
        fdc.getDrive(drive).setDisc(heads, image);
        Samples.INSERT.click();
        fdc.poll();
        reSync();
    }

    public void displayLostFocus() {
        keyboard.reset();
    }

    public Drive[] getFloppyDrives() {
        return floppies;
    }

    public int PEEK(int address) {
        return memory.readByte(address);
    }

    public void POKE(int address, int value) {
        if (address < 0 || value < 0) {
            return;
        }
        memory.writeByte(address, value);
    }
    byte[] storedSnapshot;
    int porta, portb, portc;

    public void storeSNA() {
        z80.stop();
        int memSize = 0x20000;
        storedSnapshot = new byte[0x0100 + memSize];
        try {
            System.arraycopy(SNA_HEADER.getBytes("UTF-8"), 0, storedSnapshot, 0, SNA_HEADER.length());
        } catch (final IOException iox) {
        }
        storedSnapshot[VERSION] = (byte) 1;

        // z80 registers
        putWord(storedSnapshot, AF, z80.getRegisterValue(1));
        putWord(storedSnapshot, BC, z80.getRegisterValue(7));
        putWord(storedSnapshot, DE, z80.getRegisterValue(5));
        putWord(storedSnapshot, HL, z80.getRegisterValue(3));
        storedSnapshot[R] = (byte) z80.getRegisterValue(14);
        storedSnapshot[I] = (byte) z80.getRegisterValue(12);
        storedSnapshot[IFF1] = (byte) z80.getIFF1();
        storedSnapshot[IFF2] = (byte) z80.getIFF2();
        putWord(storedSnapshot, IX, z80.getRegisterValue(9));
        putWord(storedSnapshot, IY, z80.getRegisterValue(11));
        putWord(storedSnapshot, SP, z80.getRegisterValue(10));
        putWord(storedSnapshot, PC, z80.getRegisterValue(13));
        storedSnapshot[IM] = (byte) z80.getIM();
        putWord(storedSnapshot, AF1, z80.getRegisterValue(2));
        putWord(storedSnapshot, BC1, z80.getRegisterValue(8));
        putWord(storedSnapshot, DE1, z80.getRegisterValue(6));
        putWord(storedSnapshot, HL1, z80.getRegisterValue(4));

        // inks and pens
        storedSnapshot[GA_PEN] = (byte) gateArray.getSelectedInk();
        for (int i = 0; i < 0x11; i++) {
//              storedSnapshot[GA_INKS +i] = (byte)(gateArray.getInks(i)|0x040);
            storedSnapshot[GA_INKS + i] = (byte) (gateArray.getInks(i));
        }
        // CRTC registers
        storedSnapshot[CRTC_REG] = (byte) crtc.getSelectedRegister();
        for (int i = 0; i < 18; i++) {
            storedSnapshot[CRTC_REGS + i] = (byte) crtc.getReg(i);
        }
        storedSnapshot[PPI_CONTROL] = (byte) ppi.getControl();
        storedSnapshot[PPI_A] = (byte) ppi.getOutputValue(PPI8255.PORT_A);
        storedSnapshot[PPI_B] = (byte) ppi.getOutputValue(PPI8255.PORT_B);
        storedSnapshot[PPI_C] = (byte) ppi.getOutputValue(PPI8255.PORT_C);

        storedSnapshot[PSG_REG] = (byte) psg.getSelectedRegister();
        for (int i = 0; i < 16; i++) {
            storedSnapshot[PSG_REGS + i] = (byte) psg.getRegister(i);
        }

        storedSnapshot[GA_ROM] = (byte) gateArray.getMode();
        storedSnapshot[GA_RAM] = (byte) (gateArray.getRAMBank() & 0x3f);

//        storedSnapshot[UPPER_ROM] = (byte) memory.getUpperROM();
        storedSnapshot[MEM_SIZE] = (byte) 128;
//          storedSnapshot[CPC_TYPE] = (byte)2;
        byte[] mem = memory.getMemory();
        System.arraycopy(mem, 0, storedSnapshot, 0x0100, memSize);
        try {
            File out = new File("output.sna");
            int hold = 0;
            while (out.exists()) {
                out = new File("output_" + (hold++) + ".sna");
            }
            FileOutputStream os = new FileOutputStream(out);
            os.write(storedSnapshot);
            os.close();
        } catch (Exception er) {
        }
        start();
    }

    public void restoreSNA() {
        if (storedSnapshot != null) {
            z80.stop();
            SNA_Load(storedSnapshot);
            start();
        }
    }
    CDT2WAV cdt2wav = new CDT2WAV();

    public void CDT_Load(String name, byte[] data) throws Exception {
        pause = 0;
        int freq = 44100;
//        System.out.println("Converting CDT to WAV...");
//        System.out.println("CDT size:" + data.length);
        tapesample = null;
        System.gc();
        cdt2wav.set(data, freq);
        try {
            tapesample = cdt2wav.convert();
        } catch (Exception e) {
            tapesample = null;
        }
        if (tapesample == null) {
            tapesample = new byte[0]; // avoid tapesample being null
        }

        tape_delay = 1100000 / (freq);
        tapePosition = 0;
        play = true;
//        System.out.println(tapesample.length);

    }

    public void TapeRelayCheck(int value) {
        previousPortValue = value;
        if ((value) == 0x10 && !relay) {
            relay = true;
            System.out.println("Tape relay on... ");
        }
        if ((value & 0x10) == 0x00 && relay) {
            stoptape = true;
            tapestopper = 1;
        } else {
            stoptape = false;
            tapestopper = 0;
        }
    }

    public void StopTape() {
        relay = false;
        stoptape = false;
        System.out.println("Tape relay off... ");
    }
    public boolean saveallowed = false;

    public void tapeCycle() {
        pause++;
        if (pause > 2000000) {
            pause = 2000000;
            playcount++;
            if (playcount > tape_delay) {
                playcount = 0;
                if (tapePosition >= tapesample.length - 4) {
                    play = false;
//                    relay = false;
//                    System.out.println("Tape end eached!!!");
//                    pause = 0;
                    tapePosition = 0;
                    pause = 0;
                    return;
                }
                portB = tapesample[tapePosition];
                tapePosition++;
                portB = 0x80 - portB;
                tapesound = 16 * portB / 0x80;
                Display.ledOn = portB == 0;
                psg.digicount = 10;
                psg.digiblast = (psg.readRegister(7) == 0x3f && (psg.readRegister(8) == 0 || psg.readRegister(9) == 0 || psg.readRegister(10) == 0));//false;
                psg.blasterA = psg.blasterB = tapesound;
//                gateArray.setInk(16, portB & 0x1f);
            }
        }
    }

    public void CSWLoad(String name, byte[] data) {
        tapesample = null;
        System.gc();
        pause = 0;
        int length = data.length;
        int frequency = getWord(data, 25);
        if (data[27] != 1) {
            return;
        }
        int polarity = 0x7F + data[28] % 2;
        boolean odd = ((data[28] + 2) % 2 == 0);
        tape_delay = 1010000 / frequency;
//        System.out.println("frequency is: " + frequency);
        int size = 0;
        //loop1
        int i = 32;
        while (i < length) {
            int a = data[i++] & 0xff;
            if (a == 0) {
                a = data[i++] + (data[i++] << 8) + (data[i++] << 16) + (data[i++] << 24);
            }
            while (a-- > 0) {
                size++;
            }
        }
        tapesample = new byte[size + 1];
        //loop2
        int tapecount = 0;
        i = 32;
        while (i < length) {
            int a = data[i++] & 0xff;
            if (a == 0) {
                a = data[i++] + (data[i++] << 8) + (data[i++] << 16) + (data[i++] << 24);
            }
            if (!odd) {
                polarity = 0xff - polarity;
            }
            while (a-- > 0) {
                tapesample[tapecount] = (byte) (polarity ^ 0x80);
                if (tapesample[tapecount] == 0) {
                    tapesample[tapecount] = (byte) 0xda;
                } else {
                    tapesample[tapecount] = (byte) 0x26;
                }
                tapecount++;
            }
            if (odd) {
                polarity = 0xff - polarity;
            }
        }
        play = true;
    }
}
