package JCPC.core;

import java.lang.reflect.*;

/**
 * Title:        Bitwise Utilities
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:      Bindata Ltd
 * @author Richard Wilson
 * @version 1.0
 */

public class Util {

  /**
   * Undefined (not yet determined) Java Virtual Machine type.
   */
  public static final int JVM_UNDEFINED = 0;

  /**
   * Microsoft Java Virtual Machine type.
   */
  public static final int JVM_MS        = 1;

  /**
   * Netscape Java Virtual Machine type.
   */
  public static final int JVM_NETSCAPE  = 2;

  /**
   * Unknown Java Virtual Machine type.
   */
  public static final int JVM_UNKNOWN   = 3;

  /**
   * The currently determined Java Virtual Machine type.
   */
  public static int jvmType = JVM_UNDEFINED;

  /**
   * Data used to invoke secure methods or constructors on the Java Virtual
   * Machine.
   */
  private static Object[] jvmData;

  /**
   * assertPermission method of com.ms.secutiry.PolicyEngine for MS JVM.
   */
  private static Method assertPermission;
  /**
   * Inserts new elements into an int array.
   *
   * @param source The source array
   * @param start The start index of the elements to insert
   * @param count The number of elements to insert
   * @param value The value for the new elements
   * @return The new array with elements inserted
   */
  public static int[] arrayInsert(int[] source, int start, int count, int value)
  {
    int[] result;
    if (count <= 0) {
      result = new int[source.length];
      System.arraycopy(source,0,result,0,source.length);
    }
    else {
      result = new int[source.length + count];
      if (start > 0)
        System.arraycopy(source,0,result,0,start);

      int rem = source.length - start;
      if (rem > 0)
        System.arraycopy(source,start,result,start + count,rem);

      for (int i = start; i < start + count; i++)
        result[i] = value;
    }
    return result;
  }
  /**
   * Deletes elements from an int array.
   *
   * @param source The source array
   * @param start The start index of the first column removed
   * @param count The number of elements to remove
   * @return An int array with the given elements removed
   */
  public static int[] arrayDelete(int[] source, int start, int count) {
    int[] result;
    if (count <= 0) {
      result = new int[source.length];
      System.arraycopy(source,0,result,0,source.length);
    }
    else {
      result = new int[source.length - count];
      if (start > 0)
        System.arraycopy(source,0,result,0,start);

      if (start + count < source.length)
        System.arraycopy(source,start + count,result,start,source.length -
          (start + count));
    }
    return result;
  }
    public static int random(int n) {
        double decimal = Math.random();
        int value = (int) Math.round(decimal * n);
        return value;
    }
    
    // detect OS
    
    public static boolean isWindows() {
        String OS = System.getProperty("os.name");
        System.out.println("Your Operating System is:"+OS);
        return (OS.toLowerCase().indexOf("win") >= 0);

    }

  /**
   * Invokes a static method or a method on an instance after requesting
   * priviledges required for an Applet to invoke the method successfully.
   *
   * @param cl The Class containing the method
   * @param methodName The name of the method
   * @param paramTypes The Classes of the parameters for the method
   * @param instance The instance on which to invoke the method, or null for a
   *                 static method
   * @param params The values for the parameters for the method
   * @return The return result for the method
   */
  public static Object secureMethod(Class cl, String methodName,
    Class[] paramTypes, Object instance, Object[] params) throws Exception
  {
    return secureExecute(cl.getMethod(methodName,paramTypes),instance,params);
  }

  /**
   * Invokes a constructor after requesting priviledges required for an Applet
   * to invoke the constructor successfully.
   *
   * @param cl The Class of the instance to be constructed
   * @param paramTypes The Classes of the parameters for the constructor
   * @param params The values for the parameters for the constructor
   * @return The newly constructed instance
   */
  public static Object secureConstructor(Class cl, Class[] paramTypes,
    Object[] params) throws Exception
  {
    return secureExecute(cl.getConstructor(paramTypes),null,params);
  }

  /**
   * Invokes a static method, instance method or constructor after requesting
   * priviledges required for an Applet to invoke it successfully.
   *
   * @param routine The Method or Constructor instance
   * @param instance The instance on which to invoke the method, or null for a
   *                 static method or constructor
   * @param params The values for the parameters for the method or constructor
   * @return The return result of the method, or the newly created instance for
   *         a constructor
   */
  private static Object secureExecute(Object routine,
    Object instance, Object[] params) throws Exception
  {
    // Assert permissions
    switch(determineJVM()) {
      case JVM_MS:
        for (int i = 0; i < jvmData.length; i++)
          assertPermission.invoke(null,new Object[] { jvmData[i] });
        break;

      case JVM_NETSCAPE:
        break;
    }
    try {
      if (routine instanceof Method)
        return ((Method)routine).invoke(instance,params);
      else
        return ((Constructor)routine).newInstance(params);
    } catch (InvocationTargetException i) {
      System.out.println("InvocationTarget Exception in secureExecute");
      Throwable t = i.getTargetException();
      if (t instanceof Exception)
        throw (Exception)t;
      else
        throw i;
    }
  }

  /**
   * Determines the type of Java Virtual Machine on which the Application or
   * Applet is running.
   *
   * @param The type of Java Virtual Machine
   */
  public static int determineJVM() {
    if (jvmType == JVM_UNDEFINED) {
      try {
        if (Class.forName("com.ms.security.PermissionUtils") != null) {
          jvmData = new Object[4];
          Class pi = Class.forName("com.ms.security.PermissionID");
          jvmData[0] = pi.getField("SYSTEM").get(null);
          jvmData[1] = pi.getField("FILEIO").get(null);
          jvmData[2] = pi.getField("UI").get(null);
          jvmData[3] = pi.getField("PROPERTY").get(null);
          Class pe = Class.forName("com.ms.security.PolicyEngine");
          assertPermission = pe.getMethod("assertPermission",
            new Class[] { pi });
          jvmType = JVM_MS;
        }
      } catch (Throwable t) {
        if (!(t instanceof ClassNotFoundException))
          t.printStackTrace();
      }
      if (jvmType == JVM_UNDEFINED) {
        try {
          if (Class.forName("netscape.security.AppletSecurity") != null) {
            jvmType = JVM_NETSCAPE;
          }
        } catch(Throwable t) {
          if (!(t instanceof ClassNotFoundException))
            t.printStackTrace();
        }
      }
      if (jvmType == JVM_UNDEFINED)
        jvmType = JVM_UNKNOWN;
    }
    return jvmType;
  }

  /**
   * Ensures an array of ints is a specified size.
   *
   * @param source The source array to be shrunk or grown
   * @param size The required size of the array
   * @param value A value to be placed in any new additional elements
   * @return An array containing as many of the original values as possible, but
   *         of the required size
   */
  public static int[] ensureArraySize(int[] source, int size, int value) {
    int[] result = source;
    if (result.length < size)
      result = arrayInsert(result,result.length,size - result.length,value);
    else if (result.length > size)
      result = arrayDelete(result,size,result.length - size);
    return result;
  }

  /**
   * Inserts new elements into a double array.
   *
   * @param source The source array
   * @param start The start index of the elements to insert
   * @param count The number of elements to insert
   * @param value The value for the new elements
   * @return The new array with elements inserted
   */
  public static double[] arrayInsert(double[] source, int start, int count,
    double value)
  {
    double[] result;
    if (count <= 0) {
      result = new double[source.length];
      System.arraycopy(source,0,result,0,source.length);
    }
    else {
      result = new double[source.length + count];
      if (start > 0)
        System.arraycopy(source,0,result,0,start);

      int rem = source.length - start;
      if (rem > 0)
        System.arraycopy(source,start,result,start + count,rem);

      for (int i = start; i < start + count; i++)
        result[i] = value;
    }
    return result;
  }

  /**
   * Deletes elements from a double array.
   *
   * @param source The source array
   * @param start The start index of the first column removed
   * @param count The number of elements to remove
   * @return An int array with the given elements removed
   */
  public static double[] arrayDelete(double[] source, int start, int count) {
    double[] result;
    if (count <= 0) {
      result = new double[source.length];
      System.arraycopy(source,0,result,0,source.length);
    }
    else {
      result = new double[source.length - count];
      if (start > 0)
        System.arraycopy(source,0,result,0,start);

      if (start + count < source.length)
        System.arraycopy(source,start + count,result,start,source.length -
          (start + count));
    }
    return result;
  }

  /**
   * Ensures an array of doubles is a specified size.
   *
   * @param source The source array to be shrunk or grown
   * @param size The required size of the array
   * @param value A value to be placed in any new additional elements
   * @return An array containing as many of the original values as possible, but
   *         of the required size
   */
  public static double[] ensureArraySize(double[] source, int size,
    double value)
  {
    double[] result = source;
    if (result.length < size)
      result = arrayInsert(result,result.length,size - result.length,value);
    else if (result.length > size)
      result = arrayDelete(result,size,result.length - size);
    return result;
  }

  /**
   * Inserts new elements into an Object array.
   *
   * @param source The source array
   * @param start The start index of the elements to insert
   * @param count The number of elements to insert
   * @param value The value for the new elements
   * @return The new array with elements inserted
   */
  public static Object[] arrayInsert(Object[] source, int start, int count,
    Object value)
  {
    Object[] result = source;
    if (count > 0) {
      result = (Object[])Array.newInstance(source.getClass().getComponentType(),
        source.length + count);
      if (start > 0)
        System.arraycopy(source,0,result,0,start);

      int rem = source.length - start;
      if (rem > 0)
        System.arraycopy(source,start,result,start + count,rem);

      for (int i = start; i < start + count; i++)
        result[i] = value;
    }
    return result;
  }

  /**
   * Deletes elements from an Object array.
   *
   * @param source The source array
   * @param start The start index of the first column removed
   * @param count The number of elements to remove
   * @return An Object array with the given elements removed
   */
  public static Object[] arrayDelete(Object[] source, int start, int count) {
    Object[] result;
    if (count <= 0) {
      result = new Object[source.length];
      System.arraycopy(source,0,result,0,source.length);
    }
    else {
      result = new Object[source.length - count];
      if (start > 0)
        System.arraycopy(source,0,result,0,start);

      if (start + count < source.length)
        System.arraycopy(source,start + count,result,start,source.length -
          (start + count));
    }
    return result;
  }

  /**
   * Deletes an element from an Object array.
   *
   * @param source The source array
   * @param element The element to be deleted (matched using ==)
   * @return An Object array with the given element removed
   */
  public static Object[] arrayDeleteElement(Object[] source, Object element) {
    for (int i = 0; i < source.length; i++)
      if (source[i] == element)
        return arrayDelete(source, i, 1);
    return source;
  }
  /**
   * Gets a boolean from an Object. If the Object is a String and the Upper Case
   * value of the String is one of "TRUE", "T", "YES", "Y" or "1" then the
   * result will be true. If the Object is a Boolean, the result will be the
   * value of the Boolean, otherwise the default value is returned.
   *
   * @param source The source Object
   * @param defValue The default value
   * @return The boolean value
   */
  public static boolean getBoolean(Object source, boolean defValue) {
    if (source instanceof String) {
      source = ((String)source).toUpperCase();
      return "TRUE".equals(source) || "T".equals(source) || "YES".equals(source) || "Y".equals(source) ||
             "1".equals(source);
    }
    else if (source instanceof Boolean)
      return ((Boolean)source).booleanValue();
    return defValue;
  }
  public static boolean getBoolean(Object source) {
    if (source instanceof String) {
      source = ((String)source).toUpperCase();
      return "TRUE".equals(source) || "T".equals(source) || "YES".equals(source) || "Y".equals(source) ||
             "1".equals(source);
    }
    else if (source instanceof Boolean)
      return ((Boolean)source).booleanValue();
    return false;
  }

  /**
   * Converts an Object to a char.
   *
   * @param source The source Object
   * @return An char value, default char 0
   */
//  public static char getChar(Object source) {
//    return getChar(source,(char)0);
//  }

  /**
   * Converts an Object to a char.
   *
   * @param source The source Object
   * @param defValue The default value if it cannot be converted
   * @return An char value
   */
  public static char getChar(Object source, char defValue) {
    if (source instanceof String) {
      String str = (String)source;
      return str.length() == 0 ? defValue : str.charAt(0);
    }
    else if (source instanceof Character)
      return ((Character)source).charValue();

    return defValue;
  }


  /**
   * Converts an Object to a double.
   *
   * @param source The source Object
   * @return A double value
   */
  public static double getDouble(Object source) {
    return getDouble(source,0);
  }

  /**
   * Converts an Object to a double.
   *
   * @param source The source Object
   * @param defValue The default value if it cannot be converted
   * @return A double value
   */
  public static double getDouble(Object source, double defValue) {
    if (source instanceof String)
      try {
        return Double.valueOf((String)source).doubleValue();
      } catch (Exception e) {
        return defValue;
      }
    else if (source instanceof Number)
      return ((Number)source).doubleValue();
    else
      return defValue;
  }

  /**
   * Converts an Object to a long.
   *
   * @param source The source Object
   * @return A long value, default zero
   */
  public static long getLong(Object source) {
    return getLong(source,0);
  }

  /**
   * Converts an Object to a long.
   *
   * @param source The source Object
   * @param defValue The default value if it cannot be converted
   * @return A long value
   */
  public static long getLong(Object source, long defValue) {
    if (source instanceof String) {
      try {
        return Long.parseLong((String)source);
      } catch (Exception e) { }
    }
    else if (source instanceof Number)
      return ((Number)source).longValue();

    return defValue;
  }

  /**
   * Finds a Class given a default package and class name.
   *
   * @param packageName The default Package
   * @param className The class name
   * @return The Class, or null if not found
   */
  public static Class findClass(String packageName, String className) {
    if (className.indexOf('.') == -1)
      className = packageName + "." + className;
    Class result;
    try {
      result = Class.forName(className);
    } catch(Exception e) {
      result = null;
    }
    return result;
  }

  protected static final String HEX_CHARS = "0123456789ABCDEF";

  /**
   * Converts a byte to a Hexadecimal String.
   *
   * @param value The byte to convert
   * @return The Hexadecimal String
   */
  public static String hex(byte value) {
    return "" + HEX_CHARS.charAt((value & 0xF0) >> 4) + HEX_CHARS.charAt(value & 0x0F);
  }

  /**
   * Converts a short to a Hexadecimal String
   *
   * @param value The short to convert
   * @return The Hexadecimal String
   */
  public static String hex(short value) {
    return hex((byte)(value >> 8)) + hex((byte)value);
  }

  /**
   * Converts an int to a Hexadecimal String
   *
   * @param value The int to convert
   * @return The Hexadecimal String
   */
  public static String hex(int value) {
    return hex((short)(value >> 16)) + hex((short)value);
  }
    /**
     * Does a Hexadecimal/ASCII dump of a buffer.
     *
     * @param buffer The buffer to dump
     */
    public static String dumpBytes(byte[] buffer) {
        return dumpBytes(buffer, 0, buffer.length, true, true, true);
    }
    public static String dumpBytes(byte[] buffer, int start) {
        return dumpBytes(buffer, 0, buffer.length, true, true, true,start);
    }  
    public static String dumpBytes(int[] buffer) {
        return dumpBytes(buffer, 0, buffer.length, true, true, true);
    }

    /**
     * Does a Hexadecimal/ASCII dump of a buffer. The format will be
     * aaaaaaaa: bb bb bb bb bb bb bb bb bb bb bb bb bb bb bb bb cccccccccccccccc
     * where aaaaaaaa is the address offset of the data, bb represents a byte of
     * the data, and c is the ASCII character representing the data. ASCII values
     * below 0x20 and above 0x7e are displayed as the '.' character.
     *
     * @param buffer The buffer to dump
     * @param offset The start offset of the data in the buffer
     * @param length The length of the data to dump
     * @param showAddr true to include the address
     * @param showChars true to dump ASCII characters
     * @param lineFeed true to add a line feed
     * @return The dump String
     */
    public static String dumpBytes(byte[] buffer, int offset, int length,
            boolean showAddr, boolean showChars, boolean lineFeed) {
        length += offset;
        StringBuilder buff = new StringBuilder(80 * (length + 15) / 16);
        for (int i = offset; i < length; i += 16) {
            String end = "; ";
            if (showAddr) {
                buff.append(hex(i)).append(": ");
            }
            int j = 0;
            for (; j < 16 && i + j < length; j++) {
                byte data = buffer[i + j];
                buff.append(hex(data)).append(" ");
                end += data >= ' ' && data < 127 ? (char) data : '.';
            }
            for (; j < 16; j++) {
                buff.append("   ");
            }
            if (showChars) {
                buff.append(end);
            }
            if (lineFeed) {
                buff.append("\n");
            }
        }
        return buff.toString();
    }
    public static String dumpBytes(byte[] buffer, int offset, int length) {
        return dumpBytes(buffer,offset,length,true, true, true);
    }
    public static String dumpBytes(byte[] buffer, int offset, int length,
            boolean showAddr, boolean showChars, boolean lineFeed, int start) {
        length += offset;
        StringBuilder buff = new StringBuilder(80 * (length + 15) / 16);
        for (int i = offset; i < length; i += 16) {
            String end = "; ";
            if (showAddr) {
                buff.append(hex(i + start)).append(": ");
            }
            int j = 0;
            for (; j < 16 && i + j < length; j++) {
                byte data = buffer[i + j];
                buff.append(hex(data)).append(" ");
                end += data >= ' ' && data < 127 ? (char) data : '.';
            }
            for (; j < 16; j++) {
                buff.append("   ");
            }
            if (showChars) {
                buff.append(end);
            }
            if (lineFeed) {
                buff.append("\n");
            }
        }
        return buff.toString();
    }

    public static String dumpBytes(int[] buffer, int offset, int length,
            boolean showAddr, boolean showChars, boolean lineFeed) {
        length += offset;
        StringBuilder buff = new StringBuilder(80 * (length + 15) / 16);
        for (int i = offset; i < length; i += 16) {
            String end = "; ";
            if (showAddr) {
                buff.append(hex(i)).append(": ");
            }
            int j = 0;
            for (; j < 16 && i + j < length; j++) {
                byte data = (byte)buffer[i + j];
                buff.append(hex(data)).append(" ");
                end += data >= ' ' && data < 127 ? (char) data : '.';
            }
            for (; j < 16; j++) {
                buff.append("   ");
            }
            if (showChars) {
                buff.append(end);
            }
            if (lineFeed) {
                buff.append("\n");
            }
        }
        return buff.toString();
    }   /**
     * Converts a Hexadecimal character to a byte value.
     *
     * @param value The Hexadecimal character to convert
     * @return The byte value of the character
     */
    public static byte hexValue(char value) {
        if (value >= 'a') {
            return (byte) (value - 'a' + 10);
        } else if (value > '9') {
            return (byte) (value - 'A' + 10);
        } else {
            return (byte) (value - '0');
        }
    }

    /**
     * Converts a hexadecimal String to an int.
     *
     * @param source The source string
     * @return A hexadecimal integer
     */
    public static int hexValue(String source) throws Exception {
        int result = 0;
        source = source.trim();
        for (int i = 0; i < source.length(); i++) {
            byte val = hexValue(source.charAt(i));
            if (val < 0 || val > 15) {
                throw new Exception("Illegal hex character in " + source);
            }
            result = (result << 4) + val;
        }
        return result;
    }
}