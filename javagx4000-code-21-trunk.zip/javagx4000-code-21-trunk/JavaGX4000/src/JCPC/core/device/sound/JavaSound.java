/*
 * JavaSound.java
 *
 * Created on 12 June 2006, 20:24
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package JCPC.core.device.sound;

import javax.sound.sampled.*;

/**
 *
 * @author Richard
 */
public class JavaSound extends SunAudio {

    public static int SAMPLE_RATE = 22050;
    public static int[] rates = {
        6000,
        8000,
        11025,
        22050,
        32000,
        44100
    };
    public static boolean muted = false;
    protected static AudioFormat STEREO_FORMAT;
    protected SourceDataLine line;
    protected byte[] data;
    protected int offset = 0;
    protected int channels;
    protected long startCount;

    /**
     * Creates a new instance of JavaSound.
     *
     * @samples Number of samples written to DataLine at a time. Keep low ~32
     * @stereo true for Stereo, false for Mono
     */
    public JavaSound(int samples, boolean stereo) {
        super(samples, stereo);
        System.out.println("Samples:"+samples);
    }

    public int getSampleRate() {
        return SAMPLE_RATE;
    }

    protected void init() {
        format = SoundUtil.UPCM8;
        channels = 2;
        data = new byte[samples * channels];
        for (int i = 0; i < data.length; i++) {
            data[i] = (byte) 0x80;
        }
        boolean match = false;
        int i = rates.length - 1;
        boolean a=false; boolean b=false;
        while (!match) {
            try {
                SAMPLE_RATE = rates[i--];
                STEREO_FORMAT = new AudioFormat(SAMPLE_RATE, 8, 2, a, b);
                AudioFormat audioformat = STEREO_FORMAT;
                line = (SourceDataLine) AudioSystem.getLine(
                        new DataLine.Info(SourceDataLine.class, audioformat, SAMPLE_RATE * channels));
                line.open();
                match = true;
            } catch (Exception e) {
                if (i < 0) {
                    if (!a){
                        a=true;
                    } else if (!b){
                        b=true;
                    } else {
                        System.err.println("Critical Error!!!\r\nUnable to define sound!");
                        break;
                    }
                    i=rates.length-1;
                }
            }
        }
        System.out.println("Samplerate is:" + SAMPLE_RATE);
    }

    public void resync() {
        line.flush();
        for (int i = 0; i < data.length; i++) {
            data[i] = (byte) 0x80;
        }
        startCount = line.getLongFramePosition();
        int sample = SAMPLE_RATE / 10 * channels;   // 1/10 sec (100 ms) delay
        while (sample > 0) {
            int len = Math.min(data.length, sample);
            line.write(data, 0, len);
            sample -= len;
        }
        System.out.println("resync: start=" + startCount);
    }

    public long getCount() {
        return line.getLongFramePosition() - startCount - 100;
    }

    public long getDeviation() {
        return SAMPLE_RATE / 10;    // 100 ms
    }

    public void play() {
        resync();
        line.start();
    }

    public void stop() {
        line.stop();
    }

    public void dispose() {
        line.close();
    }

    public void writeStereo(int a, int b) {
        a ^= 0x80;
        b ^= 0x80;
        switch (format) {
            case SoundUtil.ULAW:
                data[offset] = SoundUtil.ulawToUPCM8((byte) a);
                data[offset + 1] = SoundUtil.ulawToUPCM8((byte) b);
                break;
            case SoundUtil.UPCM8:
                data[offset] = (byte) a;
                data[offset + 1] = (byte) b;
                break;
        }
        if (muted) {
            data[offset] = 0;
            data[offset + 1] = 0;
        }
        if ((offset += 2) == data.length) {
            line.write(data, 0, data.length);
            offset = 0;
        }
        updates++;
    }
}
