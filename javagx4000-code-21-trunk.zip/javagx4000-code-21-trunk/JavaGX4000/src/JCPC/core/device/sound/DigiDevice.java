/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JCPC.core.device.sound;

/**
 *
 * @author Markus
 */
import JCPC.core.device.*;

/**
 *
 * @author Markus
 */
public class DigiDevice extends Device {

    /** Creates a new instance of SoundDevice */
    public DigiDevice(String name) {
        super(name);
    }
}