/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JCPC.core.device.sound;


/**
 *
 * @author Markus
 */
public class AmDrum extends DigiDevice {

    int drum = 255;

    public AmDrum() {
        super("Cheetah AmDrum");
    }

    public int readPort(int port) {
        if (!AY_3_8910.digiblast) {
            return 0xff;
        }
        return drum;
    }

    public void writePort(int port, int value) {
        AY_3_8910.digicount = 1;
        AY_3_8910.digiblast = true;
        drum = value;
        AY_3_8910.blasterA = value ^ 0x080;
        AY_3_8910.blasterB = AY_3_8910.blasterA;
    }
}
