/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package JCPC.core.device.sound;

/**
 *
 * @author Markus
 */
public class DigiBlaster extends DigiDevice {

    public DigiBlaster() {
        super("Digiblaster");
    }

    public void writePort(int port, int value) {
        if (port == 0xef7f || port < 0xef00 || (port > 0xef9f && port < 0xeff0)) {
            return;
        }
        AY_3_8910.digicount = 1;
        AY_3_8910.digiblast = true;
        AY_3_8910.blasterA =  value;
        AY_3_8910.blasterB = AY_3_8910.blasterA;
    }
}
