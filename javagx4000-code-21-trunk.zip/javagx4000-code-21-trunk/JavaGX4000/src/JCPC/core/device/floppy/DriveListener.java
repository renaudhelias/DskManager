/*
 * DriveListener.java
 * 
 * Created on 3/09/2007, 11:24:32
 * 
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package JCPC.core.device.floppy;
/**
 * Title:        JavaCPC
 * Description:  The Java Amstrad CPC Emulator
 * Copyright:    Copyright (c) 2006-2010
 * Company:
 * @author
 * @version 6.8
 */
/**
 *
 * @author Richard
 */
public interface DriveListener {

    public void driveActiveChanged(Drive drive, boolean active);
}
