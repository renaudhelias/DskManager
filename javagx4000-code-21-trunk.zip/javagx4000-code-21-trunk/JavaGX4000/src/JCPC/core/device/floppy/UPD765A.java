/*
 * UPD765A.java
 *
 * Created on 09 March 2007, 11:17
 * CMD_PARAMS_SEEK has been removed for let demo 'Midline Process' work
 * Only CMD_PARAMS are used.
 */
package JCPC.core.device.floppy;

import JCPC.core.*;
import JCPC.core.device.*;
import JCPC.system.cpc.Samples;
import java.util.*;

/**
 * Title: JavaCPC Description: The Java Amstrad CPC Emulator Copyright:
 * Copyright (c) 2006-2010 Company:
 *
 * @author
 * @version 6.8
 */
public class UPD765A extends Device {

    public static boolean error = false;
    public static boolean fastdisk = false;
//    public static virtualDrive floppy = new virtualDrive();
    public boolean showSys = false;
    protected int counter;
    boolean parados = false;
    int[] enduser = null;
    boolean systemdisk = false;
    /**
     * DEBUG on/off.
     */
    private static final boolean DEBUG = false;
    /**
     * DEBUG command info
     */
    private static final boolean DEBUGINFO = false;
    /**
     * DEBUG sense drive on/off.
     */
    private static final boolean DEBUG_SENSE = false;
    /**
     * DEBUG GAP
     */
    private static final boolean DEBUG_GAP = false;
    /**
     * DEBUG show read buffer on/off.
     */
    private static final boolean DEBUG_BUFFER = false;
    /**
     * DEBUG data on/off.
     */
    private static final boolean DEBUG_DATA = false;
    /**
     * DEBUG read id on/off.
     */
    private static final boolean DEBUG_READ_ID = false;
    protected boolean readtrack = false;
    /**
     * Sector sizes.
     */
    private static final int[] SECTOR_SIZES = {0x80, 0x100, 0x200, 0x400, 0x800, 0x1000, 0x1800};
    protected static int sectSizes[] = new int[90];

    /**
     * @param commandSize command size
     * @return real size
     */
    public static int getSectorSize(int commandSize) {
        int ret = SECTOR_SIZES[Math.min(commandSize, 6)];
        sectSizes[params[1]] = ret;
        return ret;
    }

    /**
     * @param realSize sector size
     * @return NEC 765 command sector size (0-5)
     */
    public static int getCommandSize(int realSize) {
        for (int i = 0; i < SECTOR_SIZES.length; i++) {
            if (SECTOR_SIZES[i] == realSize) {
                return i;
            }
        }
        // default size
        return 2;
    }
    /**
     * For efficiency, the cycles can be 1, 2, 4 or 8 per cycle call, allowing
     * an 8MHz clock frequency to be emulated with only one call to cycle() at
     * 1MHz, or as used in the CPC, 4MHz with clocksPerCycle = 4, called at
     * 1MHz.
     */
    // The following values are from the documentation for 8MHz operation
    public int formatid[] = {0, 0, 0, 0};
    protected int actualDrive = 0;
    protected static int READ_TIME_FM;
    protected static int READ_TIME_MFM;
    protected static int POLL_TIME;
//    protected static final int READ_TIME_FM = 32 * 8;
//    protected static final int READ_TIME_MFM = 16 * 8;
//    protected static final int POLL_TIME = 1024 * 8;
    protected static final int POLL = 0;
    protected static final int SEEK = 1;
    protected static final int READ_ID = 2;
    protected static final int MATCH_SECTOR = 3;
    protected static final int READ = 4;
    protected static final int WRITE = 5;
    protected static final int FORMAT = 6;
    protected static final int SCAN = 8;
    protected static final int[] CMD_PARAMS = {
        0, 0, 8, 2, 1, 8, 8, 1, 0, 8, 1, 0, 8, 5, 0, 2,
        0, 8, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 8, 0, 0
    };
    // Valid commands during a seek???
    protected static final int[] CMD_PARAMS_SEEK = {
        0, 0, 0, 2, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 2,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    };
    // Main Status Register bits
    protected static final int D0_BUSY = 0x01;      // Drive 0 in Seek Mode
    protected static final int D1_BUSY = 0x02;
    protected static final int D2_BUSY = 0x04;
    protected static final int D3_BUSY = 0x08;
    protected static final int COMMAND_BUSY = 0x10;      // Command Busy
    protected static final int EXEC_MODE = 0x20;      // Execution Phase in non-DMA mode
    protected static final int DATA_IN_OUT = 0x40;      // Data Input/Output
    protected static final int REQ_MASTER = 0x80;      // Request for Master
    protected static final int SEEK_MASK = 0x0f;
    protected static final int ST0_NORMAL = 0x00;
    protected static final int ST0_ABNORMAL = 0x40;
    protected static final int ST0_INVALID = 0x80;
    protected static final int ST0_READY_CHANGE = 0xc0;
    protected static final int ST0_NOT_READY = 0x08;
    protected static final int ST0_HEAD_ADDR = 0x04;
    protected static final int ST0_EQUIP_CHECK = 0x10;
    protected static final int ST0_SEEK_END = 0x20;
    protected static final int ST1_MISSING_ADDR = 0x01;
    protected static final int ST1_NOT_WRITABLE = 0x02;
    protected static final int ST1_NO_DATA = 0x04;
    protected static final int ST1_OVERRUN = 0x10;
    protected static final int ST1_DATA_ERROR = 0x20;
    protected static final int ST1_END_CYL = 0x80;
    protected static final int ST2_MISSING_ADDR = 0x01;
    protected static final int ST2_BAD_CYLINDER = 0x02;
    protected static final int ST2_SCAN_NOT_SAT = 0x04;
    protected static final int ST2_SCAN_EQU_HIT = 0x08;
    protected static final int ST2_WRONG_CYL = 0x10;
    protected static final int ST2_DATA_ERROR = 0x20;
    protected static final int ST2_CONTROL_MARK = 0x40;      // Deleted data address mark
    protected static final int ST3_HEAD_ADDR = 0x04;
    protected static final int ST3_TWO_SIDE = 0x08;
    protected static final int ST3_TRACK_0 = 0x10;
    protected static final int ST3_READY = 0x20;
    protected static final int ST3_WRITE_PROT = 0x40;
    protected static final int ST3_FAULT = 0x80;
    protected int command;                      // Current command
    protected int action;                       // Current action
    protected static int[] params = new int[8]; // Command parameters
    protected int pcount = 0;
    protected int pindex = 0;
    protected int[] result = new int[7]; // Command Result
    protected int rindex = 0;
    protected int rcount = 0;
    protected Drive activeDrive;
    protected int c, h, r, n;                   // Sector ID
    protected int offset;                       // Offset in sector
    protected int size;                         // Size of sector
    protected byte[] buffer;                       // Sector Buffer
    protected int count;                        // Total cycle count
    protected int next;                         // Cycle count for next event
    protected int status;                       // Main Status Register
    protected int st1;                          // Status Register 1
    protected int st2;                          // Status Register 2
    protected int st3;                          // Status Register 3
    protected byte data;                         // Current data byte
    protected int sectorcount;				// sector count for format
    protected int cycleRate;                    // Number of cycles per cycle() call, should be 1, 2, 4 or
    // 8
    protected int countPoll, countStep, countFM, countMFM;
    protected Drive[] drives = new Drive[4];
    protected int[] pcn = new int[4];
    protected int[] ncn = new int[4];
    protected int[] dir = new int[4];
    protected int[] max = new int[4];
    protected int[] st0 = new int[4];          // Separate Status register 0 for each drive
    protected boolean[] ready = new boolean[4];
    protected Device interruptDevice;
    protected int interruptMask;
    private boolean driveChanged;

    /**
     * Creates a new instance of UPD765A
     *
     * @param clocksPerCycle clocks per cycle (1,2,4,8)
     */
    public UPD765A(int clocksPerCycle) {
        super("NEC uPD765AC-2 Floppy Controller");
        switch (clocksPerCycle) {
            case 1:
            case 2:
            case 4:
            case 8:
                cycleRate = clocksPerCycle;
                break;
            default:
                cycleRate = 4;
                break;
        }
        READ_TIME_FM     = 32;
        READ_TIME_MFM    = 16;
        POLL_TIME        = 1024;
//        READ_TIME_FM = 32 * 8;
//        READ_TIME_MFM = 14 * 8;
//        POLL_TIME = 1024 * 8;
        countPoll = POLL_TIME * cycleRate;
        countFM   = READ_TIME_FM * cycleRate;
        countMFM  = READ_TIME_MFM * cycleRate;
//        countPoll = POLL_TIME / cycleRate;
//        countFM = READ_TIME_FM / cycleRate;
//        countMFM = READ_TIME_MFM / cycleRate;
        reset();
    }
    public static int nooftracks;

    public void getNoOfTracks() {
        try {
            int drive = getDrive();
            nooftracks = drives[drive].getTracks();
        } catch (Exception e) {
            nooftracks = 40;
        }
    }

    public void setInterruptDevice(Device device, int mask) {
        interruptDevice = device;
        interruptMask = mask;
    }

    /**
     * Set or reset a drive.
     *
     * @param index drive index
     * @param drive the drive or <code>null</code> to reset
     */
    public void setDrive(int index, Drive drive) {
        drives[index] = drive;
        driveChanged = true;
    }

    /**
     * Return indexed drive.
     *
     * @param index drive index
     * @return drive or <code>null</code> when not set
     */
    public Drive getDrive(int index) {
        return drives[index];
    }
    public static String statusinfo;
    int oldstat;

    public void setStatusInfo() {
        if (status != oldstat) {
            oldstat = status;
            statusinfo = "???";
            if ((status & 0x040) != 0) {
                statusinfo = "FDC to CPU";
            } else {
                statusinfo = "CPU to FDC";
            }
            if ((status & 0x080) != 0) {
                statusinfo = "FDC ready for data";
            }
            if ((status & 0x020) != 0) {
                statusinfo = "Command execution";
            }
            if ((status & 0x010) != 0) {
                statusinfo = "FDC is busy";
            }
            if ((status & 0x08) != 0) {
                statusinfo = "DF3 is seeking";
            }
            if ((status & 0x04) != 0) {
                statusinfo = "DF2 is seeking";
            }
            if ((status & 0x02) != 0) {
                statusinfo = "DF1 is seeking";
            }
            if ((status & 0x01) != 0) {
                statusinfo = "DF0 is seeking";
            }
        }
    }

    @Override
    public final int readPort(int port) {   // Port 0 is main status, 1 is data
        if ((port & 0x01) == 0) {
            // if (DEBUG)
            //System.out.println("FDC Status Read: " + Util.hex((byte)status));
            return status;
        } else {
            if ((status & (EXEC_MODE | REQ_MASTER)) == REQ_MASTER && rcount > 0) {
                data = (byte) result[rindex++];
                if (DEBUG_DATA) {
                    System.out.println("DATA = " + Util.hex(data));
                }
                if (--rcount == 0) {
                    status &= ~(COMMAND_BUSY | DATA_IN_OUT);
                }
            } else if (action == READ && (status & REQ_MASTER) != 0) {
                status &= ~REQ_MASTER;
                //System.out.println("FDC Data read: " + Util.hex((byte)data));
                //System.out.print(" " + Util.hex((byte)data));
            }
            overrun = false;
            return data;
        }
    }
    boolean DEBUGPORT = false;
    public static String commands = "";

    @Override
    public final void writePort(int port, int value) {  // Port 0 is main status, 1 is data
        if (port < 0xfa00 || port > 0xfbff) {
            if (DEBUGPORT) {
                System.err.println("Possibly bad port write on port " + Util.hex((short) (port)) + " with data:" + Util.hex((byte) value));
            }
            return;
        }
        if ((port & 0x01) != 0) {
            data = (byte) value;
            overrun = false;
            //System.out.println("FDC write: " + Util.hex((short)port) + "," + Util.hex((byte)value));
            if ((status & (REQ_MASTER | DATA_IN_OUT)) == REQ_MASTER) {
                if ((status & EXEC_MODE) != 0) {
                    status &= ~REQ_MASTER;
                } else if ((status & COMMAND_BUSY) == 0) {
                    // Can start a command
                    command = value;
                    value &= 0x1f;
                    status |= COMMAND_BUSY;
                    pindex = 0;
//                     if ((pcount = (status & SEEK_MASK) == 0 ? CMD_PARAMS[value] : CMD_PARAMS_SEEK[value]) == 0) {
                    if ((pcount = CMD_PARAMS[value]) == 0) {
                        // Invalid command or Sense Interrupt status
                        status |= DATA_IN_OUT;
                        result[rindex = 0] = ST0_INVALID;
                        rcount = 1;
                        if (value == 0x08) {  // Sense Interrupt Status
                            for (int drive = 0; drive < 4; drive++) //                            int drive = getDrive();
                            {
                                if (st0[drive] != ST0_INVALID) {
                                    result[0] = st0[drive];
                                    st0[drive] = ST0_INVALID;
                                    result[1] = pcn[drive];
                                    status &= ~(1 << drive);
                                    rcount = 2;
                                    if (DEBUG_SENSE) {
                                        System.out.println("Sense Interrupt: " + Util.hex((byte) result[0]) + "," + Util.hex((byte) result[1]) + " on drive:" + actualDrive);
                                    }
                                    return;
//                                    break;
                                }
                            }
                        }
                    }
                } else {
                    params[pindex++] = value;
                    if (--pcount == 0) {
                        if (command == 0x66) {
                            command = 0x66;
                        }
                        String msg = "FDC Command " + Util.hex((byte) command) + ": " + Util.hex((byte) params[1]) + "/" + Util.hex((byte) params[2]) + "/" + Util.hex((byte) params[3]) + "/" + Util.hex((byte) params[4]) + " ";
                        switch (command & 0x1f) {
                            case 0x02:
                                commands = "Read Track";
                                if (DEBUGINFO) {
                                    System.out.println(msg + " (read track)");
                                }
                                readTrack();
                                break;
                            case 0x03:
                                // specify
                                commands = "Specify";
                                if (DEBUGINFO) {
                                    System.out.println(msg + " (specify)");
                                }
                                specify();
                                break;
                            case 0x04:
                                // sense actualDrive
                                commands = "Sense Drive";
                                if (DEBUGINFO) {
                                    System.out.println(msg + " (senseDrive)");
                                }
                                senseDrive();
                                break;
                            case 0x05:
                                // write sector
                                commands = "Write Sector";
                                if (DEBUGINFO) {
                                    System.out.println(msg + " (writeSector)");
                                }
                                writeSector();
                                break;
                            case 0x06:
                                // read sector
                                commands = "Read Sector";
                                if (DEBUGINFO) {
                                    System.out.println(msg + " (readSector)");
                                }
                                readSector();
                                break;
                            case 0x07:
                                // re-calibrate
                                commands = "Re-Calibrate";
                                if (DEBUGINFO) {
                                    System.out.println(msg + " (re-calibrate)");
                                }
                                seek(0, 77);
                                break;
                            case 0x08:
                                // get status register 0
                                if (DEBUG) {
                                    commands = "Get status register 0";
                                    System.out.println(msg + " (get status register 0)");
                                }
                                break;
                            case 0x09:
                                // write deleted data
                                commands = "Write Del.";
                                if (DEBUGINFO) {
                                    System.out.println(msg + " (write deleted data)");
                                }
                                writeSector();
                                break;
                            case 0x0a:
                                // read id
                                commands = "Read ID";
                                if (DEBUGINFO) {
                                    System.out.println(msg + " (read id)");
                                }
                                readID();
                                break;
                            case 0x0c:
                                // read deleted data
                                commands = "Read Del.";
                                if (DEBUGINFO) {
                                    System.out.println(msg + " (read deleted data)");
                                }
                                readSector();
                                break;
                            case 0x0d:
                                // format track
                                commands = "Format Track";
                                if (DEBUGINFO) {
                                    System.out.println(msg + " (format track)");
                                }
                                sectorcount = 0;
                                formatTrack();

                                break;
                            case 0x0f:
                                // seek track
                                commands = "Seek Track";
                                if (DEBUGINFO) {
                                    System.out.println(msg + " (seek track)");
                                }
                                seek(params[1], -1);
                                break;
                            case 0x11:
                                // scan equal
                                commands = "Scan Equal";
                                if (DEBUGINFO) {
                                    System.out.println(msg + " (scan equal)");
                                }
                                scan(EQUAL);
                                break;
                            case 0x19:
                                // scan low or equal
                                commands = "Scan L.o.E.";
                                if (DEBUGINFO) {
                                    System.out.println(msg + " (scan low or equal)");
                                }
                                scan(LOW_OR_EQUAL);
                                break;
                            case 0x1d:
                                // scan high or equal
                                commands = "Scan H.o.E.";
                                if (DEBUGINFO) {
                                    System.out.println(msg + " (scan high or equal)");
                                }
                                scan(HIGH_OR_EQUAL);
                                break;
                            default:
                                throw new RuntimeException("Invalid command: " + Util.hex((byte) command));
                        }
                    }
                }
            }
        }
    }

    @Override
    public final void reset() {
        Samples.SEEK.stop();
        Samples.SEEKBACK.stop();
        pindex = pcount = count = 0;
        status = REQ_MASTER;
        countStep = 16 * 8000 / cycleRate;
        action = POLL;
        next = countPoll;
        stop = false;
        command = 0;
    }

    public final void resetb() {
        pindex = pcount = count = 0;
        status = REQ_MASTER;
        action = POLL;
    }

    public final void initialise() {
        pindex = pcount = count = 0;
        action = POLL;
    }

    public final void specify() {
        countStep = (16 - (params[0] >> 4)) * 8000 / cycleRate;
        status &= ~(COMMAND_BUSY | DATA_IN_OUT);
    }

    public final void senseDrive() {
        int select = params[0] & 0x07;
        int drv = select & 0x03;
        if (DEBUG_SENSE) {
            System.out.println("senseDrive(" + Integer.toString(select, 2) + ") " + activeDrive.getName() + " / " + activeDrive.getType());
        }
        activeDrive = drives[drv];
        if (activeDrive != null) {
            if (ready[drv]) {
                select |= ST3_READY;
            }
            if (activeDrive.getCylinder() == 0) {
                select |= ST3_TRACK_0;
            }
            if (activeDrive.getSides() == 2) {
                select |= ST3_TWO_SIDE;
            }
            if (activeDrive.isWriteProtected()) {
                select |= ST3_WRITE_PROT;
            }
        }
        driveChanged = false;
        result[rindex = 0] = select;
        rcount = 1;
        status |= DATA_IN_OUT;
        if (DEBUG_SENSE) {
            System.out.println(" -> " + Integer.toString(result[0], 2));
        }
    }

    public int getDrive() {
        actualDrive = params[0] & 0x03;
        return actualDrive;
    }
    public int seeker = 0;

    public int getCylinder() {
        System.out.println("FDC is on Cylinder " + result[3]);
        return result[3];
    }

    public final void seek(int cyl, int steps) {
        if (DEBUG) {
            System.out.println("pcn[actualDrive] = " + pcn[actualDrive] + " | ncn[actualDrive] = " + ncn[actualDrive]);
        }
        Samples.MOTOR.turn2();
        seeker = 1;
        getDrive();
        max[actualDrive] = steps;
        ncn[actualDrive] = cyl;
        status &= ~COMMAND_BUSY;
        if (pcn[actualDrive] == cyl) {
            seekEnd(actualDrive, ST0_NORMAL);
        } else {
            status |= (1 << actualDrive);
            if (pcn[actualDrive] < cyl) {
                dir[actualDrive] = 1;
                Samples.TRACK.play();
            } else if (pcn[actualDrive] > cyl) {
                Samples.TRACKBACK.play();
                dir[actualDrive] = -1;
            }
            if (action != SEEK) {
                action = SEEK;
                next = count + countStep;   // TODO: Real FDC might use counters for each drive
            }
        }
    }

    public final void seekStep() {
    for (int drive = 0; drive < 4; drive++) {
//        int drive = getDrive();
        if (pcn[drive] != ncn[drive]) {
            int step = dir[drive];
            pcn[drive] += step;
            if (drives[drive] != null) {
                if (drives[drive].step(step)) {
                    pcn[drive] = 0;
                }
            }
            if (pcn[drive] == ncn[drive]) {
                seekEnd(drive, ST0_NORMAL);
            } else if (--max[drive] == 0) { // Recal 77 steps complete
                ncn[drive] = pcn[drive];
                seekEnd(drive, ST0_ABNORMAL | ST0_EQUIP_CHECK);
            } else {
                next = count + countStep;
                String track;// = Util.hex(params[1]).substring(6);
                if (pcn[drive] <= 9) {
                    track = "0";
                } else {
                    track = "";
                }
                getNoOfTracks();
                if (activeDrive != null) {
                    activeDrive.setActive(false);
                }
                if (step > 0) {
                    Samples.SEEK.loop2();
                } else {
                    Samples.SEEKBACK.loop2();
                }
            }
        }
    }
    }

    protected final void seekEnd(int drive, int status) {
        st0[drive] = status | ST0_SEEK_END | drive;
        dir[drive] = 0;
        Samples.SEEK.stop();
        Samples.SEEKBACK.stop();
        // Set interrupt. If no drives still seeking
        if ((dir[0] | dir[1] | dir[2] | dir[3]) == 0) {
            action = POLL;
            next = count + countPoll;
            if (activeDrive != null) {
                activeDrive.setActive(true);
            }
        }
    }

    public final void poll() {
//    for (int drive = 0; drive < 4; drive++) {
        int drive = getDrive();
        boolean rdy = true;//drives[drive] != null && drives[drive].isReady();
        if (rdy != ready[drive]) {
            ready[drive] = rdy;
            st0[drive] = ST0_READY_CHANGE | (rdy ? 0 : ST0_NOT_READY) | drive;
        }
//    }
    }

    public final boolean setupResult() {
        int select = params[0] & 0x07;
        driveChanged = false;
        activeDrive = drives[select & 0x03];
        result[rindex = 0] = select | ST0_ABNORMAL;
        result[1] = ST1_NO_DATA | ST1_MISSING_ADDR;
        rcount = 2;
        if (activeDrive != null && activeDrive.isReady()) {
            activeDrive.setHead(select >> 2);
            activeDrive.setActive(true);
            return true;
        }
        result[0] |= ST0_NOT_READY;
        status |= DATA_IN_OUT;
        return false;
    }

    public final void readID() {
        if (setupResult()) {
            action = READ_ID;
            status ^= REQ_MASTER | DATA_IN_OUT;
            if (!fastdisk) {
                next = count + (77100 / cycleRate); // TODO: Accurate timing!
            } else {
                next = count + (1200 / cycleRate); // TODO: Accurate timing!
            }
        }
    }
    int[] oldid;

    public final void getNextID() {
        if (DEBUG) {
            System.out.println("this is getNextID");
        }

        int[] id = activeDrive.getNextSectorID();
        oldid = id;
        if (id != null) {
            result[0] &= ~ST0_ABNORMAL; // status 0
            result[1] = result[2] = 0; // status 1 + 2
            result[3] = id[0]; // track
            result[4] = id[1]; // head
            result[5] = id[2]; // sector id
            result[6] = id[3]; // sector size
            next = count + countPoll;
        } else {
            result[0] = ST0_ABNORMAL;
            result[1] = ST1_MISSING_ADDR;
            result[3] = 0; // track
            result[4] = 0; // head
            result[5] = 1; // sector id
            result[6] = 2; // sector
            next = count + countPoll;
        }
        if (DEBUG) {
            for (int i = 0; i < id.length; i++) {
                System.out.println("ID[" + i + "]=" + Util.hex(id[i]));
            }
        }
        rcount = 7;
        status |= REQ_MASTER;
        action = POLL;
    }
    protected boolean overrun = false;

    protected final void readSectorByte() {
        if (offset == buffer.length || overrun) {
            endBuffer(READ);
        } else {
            overrun = true;
            data = buffer[offset++];
            next = count + countMFM;
            status |= REQ_MASTER;
        }
    }

    protected final void readSector() {
        if (setupResult()) {
            getNextSector(READ);
        }
    }

    protected final void readTrack() {
        if (setupResult()) {
            readtrack = true;
            activeDrive.resetSector();
            getNextSector(READ);
        }
    }

    protected final void formatTrack() {
        if (setupResult()) {
            if (activeDrive == null) {
                senseDrive();
            }
            activeDrive.removeAllSectorsFromTrack();
            activeDrive.resetSector();
            getNextFormatID();
        }
    }

    protected void addSector() {
    }

    protected final void getNextFormatID() {
        action = FORMAT;
        offset = 0;
        status = (status & ~DATA_IN_OUT) | REQ_MASTER | EXEC_MODE;  // ??? Is RQM high immediately?
        if (fastdisk) {
            next = count + (1200 / cycleRate); // TODO: Accurate timing!
        } else {
            next = count + (100000 / cycleRate); // TODO: Accurate timing!
        }
        data = -1;
    }
    protected final int LOW_OR_EQUAL = 0;
    protected final int HIGH_OR_EQUAL = 1;
    protected final int EQUAL = 2;
    protected int SCAN_COMMAND = 0;
    protected byte[] Dfdd, Dcpu;
    int offset2 = 0;

    protected void scan(int scancommand) {
        if (setupResult()) {
            try {
                SCAN_COMMAND = scancommand;
                action = SCAN;
                Dfdd = activeDrive.getSector(params[1], params[2], params[3], params[4]);
                Dcpu = new byte[Dfdd.length];
                if (!fastdisk) {
                    next = count + (77100 / cycleRate); // TODO: Accurate timing!
                } else {
                    next = count + (1200 / cycleRate); // TODO: Accurate timing!
                }

                offset2 = 0;
                status = (status & ~DATA_IN_OUT) | REQ_MASTER | EXEC_MODE;  // ??? Is RQM high immediately?
                data = -1;
            } catch (Exception e) {
            }
        }
    }

    protected final void writeScanByte() {
        if (data == -1); // TODO: Overrun error, no data supplied yet
        if (Dcpu != null) {
            Dcpu[offset2++] = (byte) data;
        }
        data = -1;
        if (Dcpu != null && offset2 == Dcpu.length) {
            endScanBuffer(SCAN_COMMAND);
        } else {
            next = count + countMFM;
            status |= REQ_MASTER;
        }
    }

    protected final void endScanBuffer(int direction) {
        int scanstatus = ST2_SCAN_NOT_SAT;
        switch (direction) {
            case HIGH_OR_EQUAL: {
                for (int i = 0; i < Dfdd.length; i++) {
                    if (Dfdd[i] == Dcpu[i]) {
                        scanstatus |= ST2_SCAN_EQU_HIT;
                    }
                    if (Dfdd[i] >= Dcpu[i]) {
                        scanstatus &= ~ST2_SCAN_NOT_SAT;
                    }
                }
                break;
            }
            case LOW_OR_EQUAL: {
                for (int i = 0; i < Dfdd.length; i++) {
                    if (Dfdd[i] == Dcpu[i]) {
                        scanstatus |= ST2_SCAN_EQU_HIT;
                        break;
                    }
                    if (Dfdd[i] <= Dcpu[i]) {
                        scanstatus &= ~ST2_SCAN_NOT_SAT;
                    }
                }
                break;
            }
            case EQUAL: {
                for (int i = 0; i < Dfdd.length; i++) {
                    if (Dfdd[i] == Dcpu[i]) {
                        scanstatus |= ST2_SCAN_EQU_HIT;
                        scanstatus &= ~ST2_SCAN_NOT_SAT;
                    }
                }
                break;
            }
        }
        if ((params[3] == params[5]) || ((scanstatus & ST2_SCAN_NOT_SAT) == 0)) {
            status &= ~EXEC_MODE;
            status |= REQ_MASTER | DATA_IN_OUT;
            result[0] &= ~ST0_ABNORMAL;
            result[1] = 0;
            result[2] = scanstatus;
            result[3] = params[1];
            result[4] = params[2];
            result[5] = 0x01;
            result[6] = params[4];
            rcount = 7;
            action = POLL;
            next = count + countPoll;
            activeDrive.setActive(false);

        } else {
            params[3] = (params[3] + 1) & 0xff;
            getNextSector(READ);
        }
    }

    protected final void endFormatID() {
        int drive = getDrive();
        activeDrive.addSectorToTrack(formatid[0], formatid[1], formatid[2], formatid[3], params[4]);
        sectorcount = (sectorcount + 1) & 0x0ff;
        if (sectorcount == params[2]) {
            status &= ~EXEC_MODE;
            status |= REQ_MASTER | DATA_IN_OUT;
            result[0] &= ~ST0_ABNORMAL;
            result[1] = result[2] = 0;
            result[3] = params[1];
            result[4] = params[2];
            result[5] = 0x01;
            result[6] = params[4];
            rcount = 7;
            action = POLL;
            next = count + countPoll;
            activeDrive.setActive(false);
        } else {
            getNextFormatID();
        }
        String track;
        if (activeDrive.getCylinder() <= 9) {
            track = "0";
        } else {
            track = "";
        }
        getNoOfTracks();
        try {
            int[] sectorID = activeDrive.getNextSectorID();
        } catch (Exception e) {
        }
    }

    protected final void getNextSector(int direction) {
        if (DEBUG) {
            System.out.println("This is getNextSector");
            //  System.out.println(params[1] + params[2]+ params[3]+ params[4]);
        }
        if (DEBUG_BUFFER) {
            System.out.println("getNextSector start");
        }
        buffer = activeDrive.getSector(params[1], params[2], params[3], params[4]);
        if (readtrack) {
            buffer = null;
            readtrack = false;
            if (DEBUG_BUFFER) {
                System.out.println("Buffer cleared...");
            }
        }

        if (direction == READ) {
            if ((command & 0x01f) == 0x06) { // read data
                // skip set?
                if ((command & (1 << 5)) != 0) { // skip if deleted data
                    // control mark set?
                    if (isDeletedData()) {
                        if (DEBUG_BUFFER) {
                            System.out.println("getNextSector endbuffer because deleted data");
                        }
                        // skip
                        endBuffer(direction);
                        return;
                    }

                }
            } else if ((command & 0x01f) == 0x0c) { // read deleted data
                // skip set?
                if ((command & (1 << 5)) != 0) { // skip if data
                    // control mark not set?
                    if (!isDeletedData()) {
                        if (DEBUG_BUFFER) {
                            System.out.println("getNextSector endbuffer because not deleted data");
                        }
                        // skip
                        endBuffer(direction);
                        return;
                    }
                }
            }
        }

        if (direction == WRITE) {
            if (DEBUG_BUFFER) {
                System.out.println("getNextSector write deleted data");
            }
            if ((command & 0x01f) == 0x05) {
                // not deleted data
                activeDrive.setST2ForSector(params[1], params[2], params[3], params[4], 0x000);
            } else if ((command & 0x01f) == 0x09) {
                // deleted data
                activeDrive.setST2ForSector(params[1], params[2], params[3], params[4], 0x040);
            }

        }

        if (DEBUG_BUFFER) {
            System.out.println("Buffer is:");
            if (buffer != null) {
                System.out.println(Util.dumpBytes(buffer));
            } else {
                System.err.println("Buffer is totally empty!");
                if (DEBUG_DATA) {
                    try {
                        Thread.sleep(5000);
                    } catch (Exception e) {
                    }
                }
            }
        }
        if (DEBUG_BUFFER) {
            System.out.println("getNextSector buffer checked");
        }
        if (DEBUG) {
            System.out.println("Got sector " + Util.hex((byte) params[3]) + " " + (buffer != null) + " "
                    + (buffer == null ? "" : Integer.toString(buffer.length)));
        }
        if (buffer != null) {
            if (DEBUG_BUFFER) {
                System.out.println("getNextSector buffer is not null");
            }
            String track;
            if (params[1] <= 9) {
                track = "0";
            } else {
                track = "";
            }
            int drive = getDrive();
            getNoOfTracks();
            offset = 0;
            action = direction;  // TODO: Accurate matching/timing
            if (direction == READ) {
                if (DEBUG) {
                    System.out.println("status:" + status + " REQ_MASTER:" + REQ_MASTER + " DATA_IN_OUT:" + DATA_IN_OUT + " EXEC_MODE:" + EXEC_MODE);
                }
                status = (status & ~REQ_MASTER) | DATA_IN_OUT | EXEC_MODE;
            } else {
                status = (status & ~DATA_IN_OUT) | REQ_MASTER | EXEC_MODE;  // ??? Is RQM high immediately?
            }

//            next = count + getTiming();
            next = count + getGAP2() + countPoll;
//            next = count + (800 / cycleRate);
            data = -1;
        } else {
            if (DEBUG_BUFFER) {
                System.out.println("getNextSector endbuffer is null");
            }
            endBuffer(direction);
        }
    }

    public int getGAP2() {
        // total=0: for n=1 to sectors_in_track: total=total+62+sector_size_in_bytes(n): next n
        int total = 146 + getSectorSize() * activeDrive.getSectorCount();
        int gap = (6250 - total) / (activeDrive.getSectorCount());
        int timer = (62 + gap) * 32;
//        System.out.println(timer);
        return timer / 3;
    }
    /*: real FDC values in a test :
    
     test 1 
     0173
     0a02
     0a14
     a162 
    
     test 2 
     000b
     0678
     0560
    
     test 3
     085b
     00 00 00 00 00 c2 02
    
     */
    int sectorsize = 1;

    public int getSectorSize() {
        try {
            sectorsize = buffer.length;
            if (DEBUG_GAP) {
                System.out.println("SectorSize = " + sectorsize);
            }
        } catch (Exception e) {
        }
        return sectorsize;
    }

    public int getTiming() {
        if (fastdisk) {
            return countPoll;
        }

        int numbytes = 0;
        // find this sector...
        for (int i = 0; i < activeDrive.getSectorCount(); i++) {
            try {
                int[] sectorID = activeDrive.getNextSectorID();
                if (sectorID[2] == params[3]) {
                    break;
                }
            } catch (Exception e) {
                break;
            }
        }
        // now loop to find next
        for (int i = 0; i < activeDrive.getSectorCount(); i++) {
            // add on gap
            numbytes += getGAP() + 2 + 60;
            // get id of next sector
            try {
                int[] sectorID = activeDrive.getNextSectorID();
                if (sectorID[2] == ((params[3] + 1) & 0x0ff)) {
                    break;
                }
                numbytes += SECTOR_SIZES[Math.min(sectorID[3], 6)];
            } catch (Exception e) {
                break;
            }
            // add on size of sector
        }
        int numCycles = (numbytes * countMFM) / 3;
        if (DEBUG_GAP) {
            System.out.println("numbytes = " + numCycles);
        }
        return numCycles;
    }

    public int getGAP() {
        try {
            int secs = activeDrive.getSectorCount();
            int GAPLength = (6100 - (getSectorSize() * secs)) / secs;
            GAPLength &= 0x07f;
            if (GAPLength < 1) {
                GAPLength = 1;
            }
            if (GAPLength > 90) {
                GAPLength = 90;
            }
            if (DEBUG_GAP) {
                System.out.println("GAP = " + GAPLength);
            }
            return GAPLength;
        } catch (Exception e) {
            return countPoll;
        }
    }

    protected boolean isDeletedData() {
        return ((activeDrive.getST2ForSector(params[1], params[2], params[3], params[4]) & 0x040) != 0);
    }
    boolean stop = false;
    int[] lastid;

    protected final void endBuffer(int direction) {
        int[] id;
        try {
            id = activeDrive.getReadID();
            lastid = id;
        } catch (Exception e) {
            id = lastid;
        }

        if (buffer == null) {
            // Cause a read error
            try {
                status &= ~EXEC_MODE;
                status |= REQ_MASTER | DATA_IN_OUT;
                result[0] |= ST0_ABNORMAL; // status 0
                result[1] = ST1_NO_DATA;
                result[2] = 0;
                result[3] = params[1] = id[0]; // track
                result[4] = params[2] = id[1]; // head
                result[5] = id[2]; // sector id
                result[6] = params[4] = id[3]; // sector size
                rcount = 7;
                action = POLL;
                next = count + getTiming();
//            next = count + countPoll;
                activeDrive.setActive(false);
                return;
            } catch (Exception e) {
            }
        }

        stop = false;
        if (direction == READ) {
            if ((command & 0x01f) == 0x06) { // read data
                // skip not set?
                // if ((command & (1 << 5)) == 0) { // skip if deleted data
                // control mark set?
                if (isDeletedData()) {
                    stop = true;
                }

                //  }
            } else if ((command & 0x01f) == 0x0c) { // read deleted data
                // skip set?
                // if ((command & (1 << 5)) == 0) { // skip if data
                // control mark not set?
                if (!isDeletedData()) {
                    stop = true;
                }
                // }
            }
        }
        if ((activeDrive.getST2ForSector(params[1], params[2], params[3], params[4]) & 0x20) != 0) {
            stop = true;
        }
        if ((activeDrive.getST1ForSector(params[1], params[2], params[3], params[4]) & 0x20) != 0) {
            stop = true;
        }

        if (params[3] == params[5] || stop || overrun) {
            status &= ~EXEC_MODE;
            status |= REQ_MASTER | DATA_IN_OUT;

            if (stop) {
                result[0] &= ~ST0_ABNORMAL; // status 0
                result[1] = result[2] = 0; // status 1 + 2
            } else {
                result[0] &= ST0_ABNORMAL;
                result[1] = ST1_END_CYL;
                result[2] = 0;
            }
            result[1] |= activeDrive.getST1ForSector(params[1], params[2], params[3], params[4]) & 0x20;
            result[2] |= activeDrive.getST2ForSector(params[1], params[2], params[3], params[4]) & 0x20;


            //  ST0_NORMAL = 0x00;
            //  ST0_ABNORMAL = 0x40;
            //  ST0_INVALID = 0x80;
            //  ST0_READY_CHANGE = 0xc0;
            //  ST0_NOT_READY = 0x08;
            //  ST0_HEAD_ADDR = 0x04;
            //  ST0_EQUIP_CHECK = 0x10;
            //  ST0_SEEK_END = 0x20;
            //  ST1_MISSING_ADDR = 0x01;
            //  ST1_NOT_WRITABLE = 0x02;
            //  ST1_NO_DATA = 0x04;
            //  ST1_OVERRUN = 0x10;
            //  ST1_DATA_ERROR = 0x20;
            //  ST1_END_CYL = 0x80;
            //  ST2_MISSING_ADDR = 0x01;
            //  ST2_BAD_CYLINDER = 0x02;
            //  ST2_SCAN_NOT_SAT = 0x04;
            //  ST2_SCAN_EQU_HIT = 0x08;
            //  ST2_WRONG_CYL = 0x10;
            //  ST2_DATA_ERROR = 0x20;
            //  ST2_CONTROL_MARK = 0x40;      // Deleted data address mark
            //  ST3_HEAD_ADDR = 0x04;
            //  ST3_TWO_SIDE = 0x08;
            //  ST3_TRACK_0 = 0x10;
            //  ST3_READY = 0x20;
            //  ST3_WRITE_PROT = 0x40;
            //  ST3_FAULT = 0x80;
            if (overrun) {
                System.out.println("FDC overrun");
                result[1] |= ST1_OVERRUN;
//                status &= ~REQ_MASTER;
            }
            if (direction == READ) {
                if ((command & 0x01f) == 0x06) { // read data
                    // skip not set?
                    if ((command & (1 << 5)) == 0) { // skip if deleted data
                        // control mark set?
                        if (isDeletedData()) {
                            result[2] |= 0x040;
                        }

                    }
                } else if ((command & 0x01f) == 0x0c) { // read deleted data..
                    // skip set?
                    if ((command & (1 << 5)) == 0) { // skip if data
                        // control mark not set?
                        if (!isDeletedData()) {
                            result[2] |= 0x040;
                        }
                    }
                }
            }
            try {
                result[3] = params[1] = id[0]; // track
                result[4] = params[2] = id[1]; // head
                result[5] = id[2]; // sector id
                result[6] = params[4] = id[3]; // sector size
            } catch (Exception e) {
            }
            rcount = 7;
            action = POLL;
            next = count + getTiming();
//            next = count + countPoll;
            activeDrive.setActive(false);
        } else {
            params[3] = (params[3] + 1) & 0xff;
            getNextSector(direction);
        }
    }

    protected final void writeSector() {
        if (setupResult()) {
            getNextSector(WRITE);
        }
    }

    protected final void writeDeletedData() {
        if (setupResult()) {
            getNextSector(WRITE);

        }
    }

    protected final void writeSectorByte() {
        if (data == -1) {
            overrun = true; // TODO: Overrun error, no data supplied yet
        }
        saveTimer = 1;
        buffer[offset++] = (byte) data;
        data = -1;
        if (offset == buffer.length) {
            endBuffer(WRITE);
            saveCheck();
        } else {
            next = count + countMFM;
            status |= REQ_MASTER;
        }

    }

    protected final void writeFormatByte() {
        formatid[offset++] = (byte) data & 0x0ff;
        data = -1;
        if (offset == 4) {
            endFormatID();
            saveCheck();
        } else {
            next = count + countMFM;
            status |= REQ_MASTER;
        }
    }

    public final void saveCheck() {
    }
    int stat = 0;
    public int saveTimer = 0;
    int cy = 0;

    @Override
    public final void cycle() {
//        if (cy != getCylinder()){
//            cy = getCylinder();
//            
//        System.out.println("Cyl:"+params[1]);
//        }
        if (seeker != 0) {
            seeker++;
            if (seeker > 4000000) {
                seeker = 0;
                Samples.MOTOR.stop();
            }
        }
        if (saveTimer != 0) {
            saveTimer++;
            if (saveTimer > 1000000) {
                activeDrive.saveImage();
                saveTimer = 0;
            }
        }
        if (++count == next) {
            setStatusInfo();
            // System.out.println("FDC Count ended");
            switch (action) {
                case SEEK:
                    seekStep();
                    break;
                case POLL:
                    poll();
                    break;
                case READ_ID:
                    getNextID();
                    break;
                case READ:
                    readSectorByte();
                    break;
                case SCAN:
                    writeScanByte();
                    break;
                case WRITE:
                    writeSectorByte();
                    break;
                case FORMAT:
                    writeFormatByte();
                    break;
                //default: setResult(action < 0 ? -action : 0,IRQ); break; // Ok
                default:
                    break;
            }
        }
    }

    /**
     * Set forced head to use for given drive.
     *
     * @param head head 0/1
     * @param drive set head for drive 0/1
     */
    public void setForcedHead(int head, int drive) {
        if (drives[drive] != null) {
            drives[drive].setForcedHead(head);
            driveChanged = true;
        }
    }

    /**
     * Return forced head.
     *
     * @param Drive set head for Drive 0/1
     * @return 0/1
     */
    public int getForcedHead(int drive) {
        if (drives[drive] != null) {
            return drives[drive].getForcedHead();
        }
        return 0;
    }

    public String[] getInfo(int drive) {
        try {
            drives[drive].setCylinder(0);
            poll();
            int cylinder = drives[drive].getCylinder();
            int disktype[] = null;
            byte[] info1 = null;
            byte[] info2 = null;
            byte[] info3 = null;
            byte[] info4 = null;
            byte[] info5 = null;
            byte[] info6 = null;
            byte[] info7 = null;
            byte[] info8 = null;
            byte[] info = null;
            int dumpsize = 64;
            int length = 0;
            int position = 0;
            parados = false;
            if (drives[drive] != null) {
                disktype = drives[drive].getNextSectorID();
                if (disktype != null) {
                    if (disktype[2] > 0x40 && disktype[2] <= 0x49) {
                        systemdisk = true;
                        drives[drive].setCylinder(2);
                        info1 = drives[drive].getSector(2, 0, 0x41, 2);// for system.
                        info2 = drives[drive].getSector(2, 0, 0x42, 2);// for system.
                        info3 = drives[drive].getSector(2, 0, 0x43, 2);// for system.
                        info4 = drives[drive].getSector(2, 0, 0x44, 2);// for system.
                        info5 = drives[drive].getSector(2, 0, 0x45, 2);// for system.
                        info6 = drives[drive].getSector(2, 0, 0x46, 2);// for system.
                        info7 = drives[drive].getSector(2, 0, 0x47, 2);// for system.
                        info8 = drives[drive].getSector(2, 0, 0x48, 2);// for system.
                    } else if (disktype[2] > 0xc0 && disktype[2] <= 0xc9) {
                        systemdisk = false;
                        drives[drive].setCylinder(0);
                        info1 = drives[drive].getSector(0, 0, 0xc1, 2);// for data
                        info2 = drives[drive].getSector(0, 0, 0xc2, 2);// for data
                        info3 = drives[drive].getSector(0, 0, 0xc3, 2);// for data
                        info4 = drives[drive].getSector(0, 0, 0xc4, 2);// for data
                        info5 = drives[drive].getSector(0, 0, 0xc5, 2);// for data
                        info6 = drives[drive].getSector(0, 0, 0xc6, 2);// for data
                        info7 = drives[drive].getSector(0, 0, 0xc7, 2);// for data
                        info8 = drives[drive].getSector(0, 0, 0xc8, 2);// for data
                    } else if (disktype[2] > 0x90 && disktype[2] <= 0x9F) {
                        systemdisk = false;
                        drives[drive].setCylinder(0);
                        info1 = drives[drive].getSector(0, 0, 0x91, 2);// for parados 80 tracks
                        info2 = drives[drive].getSector(0, 0, 0x92, 2);// for parados 80 tracks
                        info3 = drives[drive].getSector(0, 0, 0x93, 2);// for parados 80 tracks
                        info4 = drives[drive].getSector(0, 0, 0x94, 2);// for parados 80 tracks
                        info5 = drives[drive].getSector(0, 0, 0x95, 2);// for parados 80 tracks
                        info6 = drives[drive].getSector(0, 0, 0x96, 2);// for parados 80 tracks
                        info7 = drives[drive].getSector(0, 0, 0x97, 2);// for parados 80 tracks
                        info8 = drives[drive].getSector(0, 0, 0x98, 2);// for parados 80 tracks
                        parados = true;
                    } else if (disktype[2] > 0x10 && disktype[2] <= 0x1F) {
                        systemdisk = false;
                        drives[drive].setCylinder(0);
                        info1 = drives[drive].getSector(0, 0, 0x11, 2);// for romdos d10
                        info2 = drives[drive].getSector(0, 0, 0x12, 2);// for romdos d10
                        info3 = drives[drive].getSector(0, 0, 0x13, 2);// for romdos d10
                        info4 = drives[drive].getSector(0, 0, 0x14, 2);// for romdos d10
                        info5 = drives[drive].getSector(0, 0, 0x15, 2);// for romdos d10
                        info6 = drives[drive].getSector(0, 0, 0x16, 2);// for romdos d10
                        info7 = drives[drive].getSector(0, 0, 0x17, 2);// for romdos d10
                        info8 = drives[drive].getSector(0, 0, 0x18, 2);// for romdos d10
                        parados = true;
                    } else {
                        systemdisk = false;
                        System.err.println("Unknown disk format: " + Util.hex(disktype[2]));
                        drives[drive].setCylinder(0);
                        info1 = drives[drive].getSector(0, 0, 0xc1, 2);// for data
                        info2 = drives[drive].getSector(0, 0, 0xc2, 2);// for data
                        info3 = drives[drive].getSector(0, 0, 0xc3, 2);// for data
                        info4 = drives[drive].getSector(0, 0, 0xc4, 2);// for data
                        info5 = drives[drive].getSector(0, 0, 0xc5, 2);// for data
                        info6 = drives[drive].getSector(0, 0, 0xc6, 2);// for data
                        info7 = drives[drive].getSector(0, 0, 0xc7, 2);// for data
                        info8 = drives[drive].getSector(0, 0, 0xc8, 2);// for data
                    }
                    drives[drive].setCylinder(cylinder);
                    if (info1 != null && info2 != null && info3 != null && info4 != null) {
                        length += info1.length;
                        length += info2.length;
                        length += info3.length;
                        length += info4.length;
                        if (info5 != null) {
                            length += info5.length;
                        }
                        if (info6 != null) {
                            length += info6.length;
                        }
                        if (info7 != null) {
                            length += info7.length;
                        }
                        if (info8 != null) {
                            length += info8.length;
                        }
                        info = new byte[length];
                        for (int i = 0; i < info1.length; i++) {
                            info[position] = info1[i];
                            position++;
                        }
                        for (int i = 0; i < info2.length; i++) {
                            info[position] = info2[i];
                            position++;
                        }
                        for (int i = 0; i < info3.length; i++) {
                            info[position] = info3[i];
                            position++;
                        }
                        for (int i = 0; i < info4.length; i++) {
                            info[position] = info4[i];
                            position++;
                        }
                        if (info5 != null) {
                            dumpsize += 16;
                            for (int i = 0; i < info5.length; i++) {
                                info[position] = info5[i];
                                position++;
                            }
                        }
                        if (info6 != null) {
                            dumpsize += 16;
                            for (int i = 0; i < info6.length; i++) {
                                info[position] = info6[i];
                                position++;
                            }
                        }
                        if (info7 != null) {
                            dumpsize += 16;
                            for (int i = 0; i < info7.length; i++) {
                                info[position] = info7[i];
                                position++;
                            }
                        }
                        if (info8 != null) {
                            dumpsize += 16;
                            for (int i = 0; i < info8.length; i++) {
                                info[position] = info8[i];
                                position++;
                            }
                        }
                        // System.out.println(Util.dumpBytes(info));
                        return showDir(info, drive, dumpsize);
                    }
                }
            }

        } catch (Exception e) {
        }
        return null;
    }

    public String[] showDir(byte[] info, int drive, int size) {
        poll();
        String[] entry = new String[size];
        String[] output = null;
        String[] endentries = null;
        int[] user = new int[size];
        int[] checkuser = null;
        int position = 0;
        int[] check = new int[size];
        int recount = 0;
        int arrayLength = 0;
        boolean sys = false;
        boolean readonly = false;
        boolean corrupt = false;
        enduser = null;
        for (int counte = 0; counte < size; counte++) {
            if (!parados) {
                check[counte] = info[position + 12];
            } else {
                check[counte] = 0;
            }
            if (check[counte] == 0) {
                arrayLength++;
            }
            entry[counte] = "";
            user[counte] = info[position++];
            for (int i = 1; i < 9; i++) {
                int chk = (int) (info[position] & 0x7f);
                if (chk < 0x020 || chk > 0x07f) {
                    corrupt = true;
                }
                // if ((char)(info[position]&0x7f)!=' ')
                entry[counte] += (char) (info[position] & 0x7f);
                position++;

            }
            // if ((char)(info[position]&0x7f)!=' ')
            entry[counte] += ".";
            for (int i = 0; i < 3; i++) {
                // if ((char)(info[position]&0x7f)!=' ')
                entry[counte] += (char) (info[position] & 0x7f);
                if (i == 1 && (int) (info[position]) < 0) {
                    sys = true;
                }
                if (i == 0 && (int) (info[position]) < 0) {
                    readonly = true;
                }
                position++;
            }
            if (readonly) {
                entry[counte] += "<";
                readonly = false;
            }
            if (sys) {
                if (showSys) {
                    entry[counte] += ">";
                } else {
                    entry[counte] = null;
                }
                sys = false;
            }
            if (corrupt) {
                entry[counte] = null;
                corrupt = false;
            }
            position += 20;
        }

        output = new String[arrayLength];
        checkuser = new int[arrayLength];
        for (int counte = 0; counte < size; counte++) {
            if (entry[counte] != null && check[counte] == 0 && user[counte] >= 0 && user[counte] <= 0xff15) {
                output[recount] = entry[counte];
                checkuser[recount] = user[counte];
                recount++;
            }
        }

        for (int i = 0; i < output.length; i++) {
            if (output[i] != null) {
            } else {
                arrayLength--;
            }
        }
        endentries = new String[arrayLength];
        for (int i = 0; i < arrayLength; i++) {
            endentries[i] = output[i] + "|" + checkuser[i];
            System.out.println(endentries[i]);
        }
        Set<String> strings = new HashSet<String>();
        strings.addAll(Arrays.asList(endentries));
        endentries = strings.toArray(new String[0]);
        java.util.Arrays.sort(endentries);
        enduser = new int[endentries.length];
        for (int i = 0; i < endentries.length; i++) {
            String us = endentries[i];
            while (us.contains("|")) {
                us = us.substring(1);
            }
            enduser[i] = Integer.parseInt(us);
            while (endentries[i].contains("|")) {
                endentries[i] = endentries[i].substring(0, endentries[i].length() - 1);
            }
        }

        poll();
        return endentries;
    }

    public boolean getSystem() {
        return systemdisk;
    }

    public int[] getUser() {
        return enduser;
    }
}
