package JCPC.core.device.crtc;

import JCPC.core.*;
import JCPC.core.device.*;
import JCPC.system.cpc.CPC;
import JCPC.system.cpc.GateArray;
import JCPC.system.cpc.plus.ASIC;
import JCPC.ui.Display;

/**
 * Title: JavaCPC Description: The Java Amstrad CPC Emulator Copyright:
 * Copyright (c) 2006-2010 Company:
 *
 * @author
 * @version 6.8
 */
public class Basic6845 extends CRTC {

    protected boolean DEBUG = false;
    public static boolean patch = false;
    boolean ignore;
    boolean debug = false;
    boolean hitech, camemb4, skoh, tomate, special = false;
    public int CRTCType = 3;
    public static int CRTC = 3;
    public static int HCC;
    /*
     * -----------------------------------------------------------------------
     */
    /*
     * ASIC CRTC
     */
    /*
     * Programmable VSYNC. No CRTC 2 type problems.
     */
    /*
     * Port &bexx, &bfxx return contents of readable registers
     */
    /*
     * Writing to registers 18-31 has no effect
     */
    /*
     * Has Skew
     */
    int AsicCRTC_ReadMaskTable[] = {
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x000,
        0x000,
        0x000,
        0x000,
        0x000, /*
         * Light Pen (H)
         */
        0x000, /*
         * Light Pen (L)
         */
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,};
    int AsicCRTC_WriteMaskTable[] = {
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x07f,
        0x01f,
        0x07f,
        0x07f,
        0x0f3,
        0x01f,
        0x07f,
        0x01f,
        0x03f,
        0x0ff,
        0x03f,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,};
    /*
     * -----------------------------------------------------------------------
     */
    /*
     * HD6845S - CRTC 0
     */

    /*
     * these are or'ed on before returning result
     */
    protected int[] HD6845S_ReadMaskTable = {
        0x0ff, /*
         * Horizontal Total
         */
        0x0ff, /*
         * Horizontal Displayed
         */
        0x0ff, /*
         * Horizontal Sync Position
         */
        0x0ff, /*
         * Sync Widths
         */
        0x0ff, /*
         * Vertical Total
         */
        0x0ff, /*
         * Vertical Adjust
         */
        0x0ff, /*
         * Vertical Displayed
         */
        0x0ff, /*
         * Vertical Sync Position
         */
        0x0ff, /*
         * Interlace and Skew
         */
        0x0ff, /*
         * Maximum Raster Address
         */
        0x0ff, /*
         * Cursor Start
         */
        0x0ff, /*
         * Cursor End
         */
        0x000, /*
         * Screen Addr (H)
         */
        0x000, /*
         * Screen Addr (L)
         */
        0x000, /*
         * Cursor (H)
         */
        0x000, /*
         * Cursor (L)
         */
        0x000, /*
         * Light Pen (H)
         */
        0x000, /*
         * Light Pen (L)
         */
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,};

    /*
     * these are anded before data is written
     */
    protected int[] HD6845S_WriteMaskTable = {
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x07f,
        0x01f,
        0x07f,
        0x07f,
        0x0f3,
        0x01f,
        0x07f,
        0x01f,
        0x03f,
        0x0ff,
        0x03f,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,};

    /*
     * ---------------------------------------------------------------------------
     */

    /*
     * UM6845R - CRTC 1
     */
    protected int[] UM6845R_ReadMaskTable = {
        0x0ff, /*
         * Horizontal Total
         */
        0x0ff, /*
         * Horizontal Displayed
         */
        0x0ff, /*
         * Horizontal Sync Position
         */
        0x0ff, /*
         * Sync Width
         */
        0x0ff, /*
         * Vertical Total
         */
        0x0ff, /*
         * Vertical Total Adjust
         */
        0x0ff, /*
         * Vertical Displayed
         */
        0x0ff, /*
         * V. Sync Position
         */
        0x0ff, /*
         * Interlace Mode and Skew
         */
        0x0ff, /*
         * Max Scan Line Address
         */
        0x0ff, /*
         * Cursor Start
         */
        0x0ff, /*
         * Cursor End
         */
        0x0ff, /*
         * Start Address (H)
         */
        0x0ff, /*
         * Start Address (L)
         */
        0x000, /*
         * Cursor (H)
         */
        0x000, /*
         * Cursor (L)
         */
        0x000, /*
         * Light Pen (H)
         */
        0x000, /*
         * Light Pen (L)
         */
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x000,};
    protected int[] UM6845R_WriteMaskTable = {
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x07f,
        0x01f,
        0x07f,
        0x07f,
        0x003,
        0x01f,
        0x07f,
        0x01f,
        0x03f,
        0x0ff,
        0x03f,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,
        0x0ff,};
    protected final Register[] REGISTERS = {
        /*
         * REG 0
         */new Register("Horizontal Total"),
        /*
         * REG 1
         */ new Register("Horizontal Displayed"),
        /*
         * REG 2
         */ new Register("HSync Position"),
        /*
         * REG 3
         */ new Register("Sync Width"),
        /*
         * REG 4
         */ new Register("Vertical Total"),
        /*
         * REG 5
         */ new Register("Vertical Total Adjust"),
        /*
         * REG 6
         */ new Register("Vertical Displayed"),
        /*
         * REG 7
         */ new Register("VSync Position"),
        /*
         * REG 8
         */ new Register("Interlace and Delay"),
        /*
         * REG 9
         */ new Register("Max Scan Line"),
        /*
         * REG 10
         */ new Register("Cursor Start"),
        /*
         * REG 11
         */ new Register("Cursor End"),
        /*
         * REG 12
         */ new Register("Display Start Address (High)", 16),
        /*
         * REG 13
         */ new Register("Display Start Address (Low)", 16),
        // Light Pen register!
        /*
         * REG 14
         */ new Register("Cursor Address (High)", 16),
        /*
         * REG 15
         */ new Register("Cursor Address (Low)", 16),
        /*
         * REG 16
         */ new Register("Lightpen Address (High)", 16),
        /*
         * REG 17
         */ new Register("Lightpen Address (High)", 16)
    };
    protected CPC cpc;
    protected final int EVENT_HSYNC_START = 0x01;
    protected final int EVENT_HDISP_END = 0x02;
    protected final int EVENT_HDISP_START = 0x04;
    protected final int EVENT_VSYNC_START = 0x08;
    protected final int EVENT_VSYNC_END = 0x10;
    public static boolean CRTCCollision = false;
    protected int lastReg = 0;
    public boolean Scratch, Scratchdemo = false;
    protected static final int[] CURSOR_FLASH_MASKS = {0x40, 0x00, 0x10, 0x20};
//    public int ma;
    public int RasterCounter;
    public int hCC;
    public int LineCounter;
    protected int hCCMask = 0x7f;
    protected static int[] reg = new int[32];
    protected static int[] regs = new int[32];
    protected int[] orig = new int[32];
    protected int[] rdMask;
    protected int[] wrMask;
    protected int[] eventMask = new int[256];
    protected int registerSelectMask = 0x03;
    protected int registerSelectTest = 0x00;
    protected int registerWriteMask = 0x03;
    protected int registerWriteTest = 0x00;
    protected int registerReadMask = 0x03;
    protected int registerReadTest = 0x00;
    protected int registerStatusMask = 0x03;
    protected int registerStatusTest = 0x00;
    protected int selReg;
    protected int hChars = 1;
    protected int hSyncStart, hDispEnd, hSyncWidth, hSyncCount, vSyncCount;
    protected int vSyncWidth;
    protected boolean inHSync = false;
    protected boolean inVSync = false;
    public boolean hDisp = true;
    public boolean vDisp = true;
    protected boolean interlace = false;
    protected int interlaceVideo = 0;  // 0 for normal, 1 for interlace sync & video
    protected int scanAdd = 1;         // 2 for interlace sync & video
    protected int maxRaster = 0;       // Register 9 | interlaceVideo
    protected int frame = 0;           // Toggles between 0 and 1 for interlace mode
//    public int maBase = 0;          // Base address for current character line
//    public int maScreen = 0;        // Base address at start of screen
    public int maStore = 0;
    public int maCurrent = 0;
    public int maRegister = 0;
    public int vtAdj = 0;           // Vertical total adjust
    protected int halfR0 = 0;          // Used for VSync in interlace odd frames
    protected int hDispDelay = 0;      // HDISP delay
    protected int cursorMA = 0;        // Cursor position
    protected int cursorStart = 0;     // Cursor start
    protected int cursorEnd = 0;     // Cursor end
    protected boolean cursor = false;  // Is cursor on?
    protected int cursorCount = 0;     // Cursor flash counter
    protected int cursorFlash = 0;     // Cursor flash mask
    protected int cursorDelay = 0;     // Cursor delay programmed in register 8
    protected int cursorWait = 0;     // Delay counter

    public Basic6845(CPC cpc) {
        super("Basic 6845");
        this.cpc = cpc;
        rdMask = wrMask = new int[32];
        setMasks();
        reset();
    }

    public void init() {
        setMasks();
        Scratch = false;
        Scratchdemo = false;
        hitech = camemb4 = skoh = tomate = special = false;
        setReg3(142);
    }

    public void reset() {
        maScroll = 0;
        hitech = camemb4 = skoh = tomate = special = false;
        selReg = hCC = 0;
//        ma = maBase;
        maCurrent = maStore;
        hSyncWidth = hSyncCount = 0;
        inHSync = false;
        for (int i = 0; i < eventMask.length; i++) {
            eventMask[i] = 0;
        }
        reg[0] = 0x3f & wrMask[0];
        regs[0] = 0x3f & wrMask[0];
        setEvents();
    }

    public void setWriteMask(int reg, int mask) { // Why is this void here? Never called!!!
        wrMask[reg] = mask;
    }

    public void setMasks() {                       // set read and write masks for different CRTC mode
        for (int i = 0; i < 32; i++) {
            if (CRTCType == 0) {
                rdMask[i] = 0xff | HD6845S_ReadMaskTable[i];
                wrMask[i] = 0xff & HD6845S_WriteMaskTable[i];
            } else if (CRTCType == 1) {
                rdMask[i] = 0xff | UM6845R_ReadMaskTable[i];
                wrMask[i] = 0xff & UM6845R_WriteMaskTable[i];
            } else if (CRTCType == 3) {
                rdMask[i] = 0xff | AsicCRTC_ReadMaskTable[i];
                wrMask[i] = 0xff & AsicCRTC_WriteMaskTable[i];
            }
            setRegister(i, orig[i]);
        }
    }
    int keepMA;
    int oldline;
    int tick;
    int lc, rc;
    Slider slider;

    void checkSlider() {

        if (slider == null) {
            slider = new Slider();
            slider.slider.setMaximum(16);
            slider.slider.setMinimum(0);
            slider.setVisible(true);
        }
    }
//    public boolean asicsync;

    public int getHSyncWidth() {
        return hSyncWidth;
    }

    public int gethSyncCount() {
        return hSyncCount;
    }

    int maBase = 0;

    int oldlc;
    
    public int cyclecount;

    public void cycle() {
        cyclecount++;
        if (hCC == reg[0]) {
            hCC = 0;
            scanStart();
            if (maScroll == 0) {
                maCurrent = maStore & 0x03fff;
            }
        } else {
            hCC = (hCC + 1) & hCCMask;
            maCurrent = (maStore + hCC) & 0x3fff;
        }
        if (inHSync) {
            this.doAsicHsync(false);
            hSyncCount = (hSyncCount + 1) & 0x0f;
            if (hSyncCount == hSyncWidth) {
                inHSync = false;
                listener.hSyncEnd();
            }
        }
        int mask = eventMask[hCC];
        if (mask != 0) {
            if ((mask & EVENT_VSYNC_START) != 0) {
                eventMask[hCC] &= ~EVENT_VSYNC_START;
                inVSync = true;
                listener.vSyncStart();
            } else if ((mask & EVENT_VSYNC_END) != 0) {
                eventMask[hCC] &= ~EVENT_VSYNC_END;
                inVSync = false;
                listener.vSyncEnd();
            }
            if ((mask & EVENT_HSYNC_START) != 0) {
                hSyncCount = 0;
                if (hDisp && CRTCType == 1 && hSyncWidth == (reg[3] & 0x0f)) {
                    vDisp = reg[6] != 0;
                    hSyncCount = 1;
                }
                inHSync = true;
                listener.hSyncStart();

            }
            if (vDisp) {
                if ((mask & EVENT_HDISP_START) != 0) {

                    hDisp = true;
                    hDispStart();
                }

                if ((mask & EVENT_HDISP_END) != 0) {
                    hDisp = false;
                    listener.hDispEnd();
                    if ((getRA() | interlaceVideo) == maxRaster) {
                        maStore = (maStore + reg[1]) & 0x3fff;
                    }
                }
            }
        }
        checkHSync(false);
        if (cursor) {
            if (cursorWait > 0) {
                if (--cursorWait == 0) {
                    listener.cursor();
                }
            } else if (maCurrent == cursorMA && getRA() >= cursorStart && getRA() <= cursorEnd && hDisp) {
                if ((cursorWait = cursorDelay) == 0) {
                    listener.cursor();
                }
            }
        }
        HCC = hCC;
    }
    int maScroll;

    protected void hDispStart() {
        maCurrent = maStore & 0x03fff;
        if (CRTCType == 0 && LineCounter == 0 && RasterCounter == 0 && maScroll == 0) {
            updateScreen();
        }
        if (CRTCType == 1 && LineCounter == 0/*
                 * && RasterCounter <= reg[9]
                 */ && !camemb4) {
            updateScreen();
        }
        listener.hDispStart();
    }

    protected void newFrame() {
        cyclecount = 0;
        LineCounter = 0;
        frame = interlace ? frame ^ 0x01 : 0;
        CRTC_ClearFlag();
        RasterCounter = (frame & interlaceVideo) & 0x07;
        vDisp = reg[6] != 0;
        vDisp = true;
        updateScreen();
        listener.vDispStart();
        checkVSync(false);
        cursorCount = (cursorCount + 1) | 0x40;       // 0x40 is for always on
        cursor = (cursorCount & cursorFlash) != 0 && cursorDelay != 0x03;
    }

    public void updateScreen() {
        maRegister = (reg[13] + (reg[12] << 8)) & 0x3fff;
        maCurrent = maStore = maRegister;
        maBase = maRegister;
    }

    protected void checkVSync(boolean vcc) {
//            LineCounter = (LineCounter + 1) & 0x7f;
        if (special && CRTCType == 0) {
            vcc = true;
        } else if (vcc && ((reg[6] != RasterCounter && special) || !special)) {
            if (vtAdj == 0 || (CRTCType == 1)) {
                LineCounter = (LineCounter + 1) & 0x7f;
            }
            vcc = false;
        }
        if (LineCounter == reg[7] && !inVSync) {
            vSyncCount = 0;
            if (interlace && (frame == 0)) {
                eventMask[halfR0] |= EVENT_VSYNC_START;
            } else {
                inVSync = true;
                listener.vSyncStart();
            }
            //  System.out.println("vSync Start: reg7=" + reg[7]);
        }
        if (vcc && vtAdj == 0) {
            LineCounter = (LineCounter + 1) & 0x7f;
        }
    }

// Some scrollers use register 8 (CRTC 0)
// and register 6 (CRTC 1). This routine makes them visible
// JavaCPC is the only known emulator which emulates both correct!
    public void checkHDisp() {
        if (hDisp) {
            if (CRTCType == 0) {
                if ((reg[8] & 0x030) == 0x30) {
                    listener.hDispEnd();
                } else if ((reg[8] & 0x030) == 0x00) {
                    listener.hDispStart();
                }

            } else {
                if (reg[6] != 0) {
                    listener.hDispStart();
                } else {
                    listener.hDispEnd();
                }

            }
        }
    }
    protected boolean repaint = true;
    // We must check, if CPC cannot vSync to avoid emulation stops!!!
    // This routine maybe is completely bad, but I don't know better

    public void avoidCollision() {
        if (inVSync && reg[4] <= reg[7]) {
            if (LineCounter == reg[7]) {
                vSyncCount = 0;
            }
            repaint = true;
            CRTCCollision = true;
        } else {
            CRTCCollision = false;
            if (LineCounter == 0 && hCC == reg[1] && !inVSync && !inHSync && lastReg == 4) {
                CRTCCollision = true;
                if (repaint) {
                    repaint = false;
                }
            }
        }
        if (reg[9] == 0 && reg[4] == 0 && inVSync) {
            vtAdj = 1;
        }
        CRTCCollision = false;
    }

    protected void scanStart() {
        this.updateLightpen();
        if (CRTC != CRTCType) {       // Checks if CRTC type has changed
            CRTCType = CRTC;
            System.out.println("Changed CRTC type to " + CRTC);
            setMasks();

        }
        if (reg[9] == 0 && reg[4] == 0 && (CRTCType == 0 || CRTCType == 3)) {
            vtAdj = 1;
        }

        demoDetect();   // do some lousy crap here!!!!
        if (inVSync && (vSyncCount = (vSyncCount + 1) & 0x0f) == vSyncWidth) {
            if (interlace && (frame == 0)) {
                eventMask[halfR0] |= EVENT_VSYNC_END;
            } else {
                inVSync = false;
                listener.vSyncEnd();
            }

        } else if (vSyncCount == 0 && (CRTCType == 0 || CRTCType == 3) && LineCounter == 0 && RasterCounter == 0 && maScroll == 0) {
            updateScreen();
        }
        if (vtAdj > 0 && --vtAdj == 0) {
            newFrame();
        } else if ((RasterCounter | interlaceVideo) == maxRaster) {
            if (LineCounter == reg[4] && vtAdj == 0) {
                CRTC_SetFlag();
                vtAdj = reg[5] & 0x1f;
                if (interlace && frame == 0) {
                    vtAdj++;
                }

                if (vtAdj == 0) {
                    newFrame();
                    return;
                }
                if (CRTCType == 0) {
                    LineCounter = (LineCounter + 1) & 0x07f;
                }
            }

            if (reg[7] < reg[6] && LineCounter == reg[7] && vSyncCount == reg[7]) { // Sometimes emulation slows down and
                vtAdj = 1;                                                 // demos show too much things. Adjusting here.
                vSyncWidth = 0;                                            // and also setting vSyncWidth to 0 !?
            }

            checkVSync(true);

            if (LineCounter == reg[6]) {
                vDisp = false;
            }
            RasterCounter = (frame & interlaceVideo) & 0x07;
        } else {
            RasterCounter = (RasterCounter + scanAdd) & 0x07;
        }
        ASICCRTC_ScreenSplit();

    }
    boolean ASIC_DoScreenSplit = false;
    boolean ASIC_DoScreenSplitDelayed = false;
    boolean CRTC_VTOT_FLAG = true;

    public void ASICCRTC_ScreenSplit() {

        /*
         * this works if scroll is 0,1,2,3,4,5 or 6. When scroll is 7, then it
         * doesn't do the split fault. At a guess, it does do it, but the screen
         * address is also set by the scrolling hardware for the next char and
         * the error is not reproduced.
         *
         * The fault doesn't appear when there is a Vertical Adjust, because the
         * raster count will be different.
         */
        if (ASIC_DoScreenSplit) {
            ASIC_DoScreenSplit = false;
            maCurrent = maStore = cpc.getAsic().ASIC_ScreenMA();
        }

        if (ASIC_DoScreenSplitDelayed) {
            ASIC_DoScreenSplitDelayed = false;
            ASIC_DoScreenSplit = true;
        }
        if (cpc.getAsic().ASIC_RasterSplitLineMatch(LineCounter, RasterCounter)) {
            if (!CRTC_VTOT_FLAG) {
//                     if (!ASIC_RasterLineMatch)
                {
                    ASIC_DoScreenSplit = true;
                }
            } else {
//                     if (!ASIC_RasterLineMatch)
                {
                    ASIC_DoScreenSplitDelayed = true;
                }
            }
        }
    }
    boolean ASIC_RasterLineMatch;

    public void CRTC_SetFlag() {
        CRTC_VTOT_FLAG = true;
    }

    public void CRTC_ClearFlag() {
        CRTC_VTOT_FLAG = false;
    }

    public void writePort(int port, int value) {
        if ((port & registerSelectMask) == registerSelectTest) {
            selReg = value & 0x1f;
            cpc.getAsic().ASIC_EnableDisable(value);
        } else if ((port & registerWriteMask) == registerWriteTest) {
            setRegister(selReg, value);
        }
        lastReg = selReg;   // we remember the last changed register here.
    }
//10 FOR t=1 TO 17
//20 OUT &BC00,t
//30 CALL &BD19:PRINT INP(&BF00)
//40 NEXT
//        public int[] getField() {
//        result[0] = xmin;
//        result[1] = xmax;
//        result[2] = ymin * 2;
//        result[3] = ymax * 2;
//        return result;
//    }
    protected int maLightpen = 0;
    public boolean lightgun = false;
    int lpx = 0;
    int lpy = 0;
    boolean ll, lf;

    public void setLightpen(int x, int y, boolean large, boolean fullscreen, boolean trigger) {
        if (lightgun) {
            gunTriggered = trigger;
            if (!large && !fullscreen) {
                x *= 2;
                y *= 2;
            }
            if (!fullscreen && Display.drawmonitor) {
                x -= 60;
                y -= 80;
            }
            int[] field = listener.getField();
            x -= field[0];
            y -= field[2];
            lpx = x;
            lpy = y;
            ll = large;
            lf = fullscreen;
//            System.out.println("x:"+x+" y:"+y);
        }
    }

    /*
     * 10 out &1C00, 17 : L=inp(&1F00) : out &1C00, 16 : H=inp(&1F00) 20
     * L=H*256+L-12292 : Y=L/40 : X=L-Y*40
     *
     */
    boolean trigger;

    public void updateLightpen() {
        if (trigger != gunTriggered) {
            trigger = gunTriggered;
            System.out.println(trigger ? "Triggered" : "Not triggered");
        }
        if (!this.gunTriggered) {
            maLightpen = maBase;
        } else if (lpx > -8 && lpx < 623 && lpy > -8 && lpy < 408) {
            int pos = ((lpx >> 4) + (lpy >> 4) * reg[1]);
//            GateArray.cpc.POKE((0x0c000 + (pos % 16385)), 255);
            maLightpen = ((0x03000) + pos + 45) & 0x3fff;
        }
        nocomment = true;
        setRegister(16, (maLightpen >> 8) & 0x0ff);
        setRegister(17, (maLightpen) & 0x0ff);
        nocomment = false;
    }
    boolean nocomment = false;

    public void addLine() {
        addline++;
    }
    public int addline = 0;
    boolean gunTriggered = false;

    public void releaseGun() {
        gunTriggered = false;
    }
    byte[] lpenreg = new byte[2];

    public int readPort(int port) {
        if (cpc.memory.plus) {
            if (selReg == 16 || selReg == 17) {
                if (lightgun) {
                    switch (selReg) {
                        case 16:
                            return (reg[16] & 0x0ff);
                        case 17:
//                            System.out.println("Reading lightpen:" + Util.hex((short) maLightpen));
                            return (reg[17] & 0x0ff);
                    }
                }
            }
            if ((port & registerStatusMask) == registerStatusTest) {
                return reg[selReg];
            }
            return 0xff;
        }
        if ((port & registerStatusMask) == registerStatusTest && CRTCType == 1) {
            if (LineCounter == 0) {
                if (DEBUG) {
                    System.out.println("Status register read: " + (1 << 5));
                }
                return (1 << 5);
            } else {
                return 0;
            }

        }
        if ((port & registerReadMask) == registerReadTest) {
            if (DEBUG) {
                System.out.println("register read: " + selReg);
            }

            int value = reg[selReg];
            if (selReg < 10 || selReg > 17) {
                return 0x00;
            }
            if (CRTCType == 0) {
                switch (selReg) {
                    case 10:
                    case 11:
                        return value & 0x1f;
                    case 12:
                    case 14:
                    case 16:
                        return value & 0x3f;
                    default:
                        return value & 0xff;
                }
            } else if (CRTCType == 1) {
                switch (selReg) {
                    case 11:
                        return value & 0x1f;
                    case 12:
                    case 13:
                        return 0;
                    case 16:
                        return value & 0x3f;
                    default:
                        return value & 0xff;
                }
            }
        }
        return 0;
    }

    public void setRegister(int index, int value) {
//        if (index ==0)
//            System.out.println("****************************** REG 0:"+value);
        orig[index] = value & 0xff; //  We remember the original value here for a changed register
        value &= wrMask[index];
//        if (index == 4)
        //System.out.println("LineCounter = " + LineCounter + " reg 4 = " + value + " reg 5 = " + reg[5]);
        if (reg[index] != value) {
            reg[index] = value;
            regs[index] = value;
            switch (index) {
                case 0:
                    if (inHSync && value == 49) {
                        checkHSync(true);
                    }
                case 1:
                case 2:
                    setEvents();
                    break;

                case 3:
                    setReg3(value);
                    setEvents();

                    break;

                case 8:
                    setReg8(value);
                    break;

                case 9:
                    maxRaster = value | interlaceVideo;
                    break;

                case 10:
                    cursorStart = value & 0x1f;
                    cursorFlash = CURSOR_FLASH_MASKS[(value >> 5) & 0x03];
                    break;

                case 11:
                    cursorEnd = value & 0x1f;
                    break;

                case 12:
                case 13:
                    maRegister = ((reg[13] + ((reg[12] << 8)))) & 0x3fff;
                    break;

                case 14:
                case 15:
                    cursorMA = (reg[15] + (reg[14] << 8)) & 0x3fff;
                    System.out.println("Register 14 write " + Util.hex((short) cursorMA));
                    break;
                case 16:
                    reg[16] = value;
                    if (!nocomment) {
                        System.out.println("Register 16 write " + Util.hex((short) value));
                    }
                    break;
                case 17:
                    reg[17] = value;
                    if (!nocomment) {
                        System.out.println("Register 17 write " + Util.hex((short) value));
                    }
                    break;
            }

        }
    }

    protected void demoDetect() {              // the lousiest code ever!!! We need to detect some demos :-(
        if (!patch) {
            return;
        }

        if ((listener.PEEK(0x0de2) == 0x44 && listener.PEEK(0x0de3) == 0x55 && listener.PEEK(0x0de4) == 0x4f) || (listener.PEEK(0x0de2) == 0xe5 && listener.PEEK(0x0de3) == 0x3a && listener.PEEK(0x0de4) == 0xb8) || (listener.PEEK(0x82c2) == 0x37 && listener.PEEK(0x82c3) == 0x38 && listener.PEEK(0x82c4) == 0x37) || (listener.PEEK(0x2400) == 0x4b && listener.PEEK(0x2402) == 0x4d && listener.PEEK(0x2408) == 0x4e)) {
            special = true;
        } else {
            special = false;
        }

        if (listener.PEEK(0x8800) == 0x94 && listener.PEEK(0x8801) == 0x4c && listener.PEEK(0x8802) == 0x94) {
            camemb4 = true;
        } else {
            camemb4 = false;
        }

        if (listener.PEEK(0x34d7) == 0x48 && listener.PEEK(0x34d8) == 0x61 && listener.PEEK(0x34db) == 0x7a) {
            tomate = true;
            setReg3(142);
        } else {
            tomate = false;
        }

        if (listener.PEEK(0x1a74) == 0x40 && listener.PEEK(0x1a79) == 0x46 && listener.PEEK(0x0a60) == 0x78) {
            hitech = true;
        } else {
            hitech = false;
        }

        if (!Scratch && listener.PEEK(0x01ec) == 0x32 && listener.PEEK(0x01ed) == 0x030 && listener.PEEK(0x01ef) == 0x039) {
            Scratchdemo = true;
            setReg3(143);
            Scratch = true;

        }

        if (listener.PEEK(0xadf0) == 0x6c && listener.PEEK(0x3f90) == 0x4d && listener.PEEK(0x3f91) == 0x4f && listener.PEEK(0x3f92) == 0x4b) {
            skoh = true;
        } else {
            skoh = false;
        }
    }

    protected void demoPatch() {           // poor patches to make some demos work well!!!
        if (!patch) {
            return;
        }

        if (hitech) {
            if (reg[2] != 49 && reg[2] != 0) {
                reg[2] = 0x023;
            }

        }
        if (camemb4) {
            if (reg[1] == 24) {
                reg[1] = 23;
                reg[0] = 0xff;
            }

            if (reg[12] == 18) {
                vDisp = false;
            }

        }
        if (skoh) {
            hSyncCount = 0x0c;
        }

    }

    protected void setEvents() {
        try {
            eventMask[hSyncStart] &= ~EVENT_HSYNC_START;
            eventMask[hDispDelay] &= ~EVENT_HDISP_START;
            eventMask[hDispEnd] &= ~EVENT_HDISP_END;
            demoPatch();                                    // WTF?!? :-(
            hChars = reg[0] + 1;
            halfR0 = hChars >> 1;
            hSyncStart = reg[2];
            hDispDelay = ((reg[8] >> 4) & 0x04);          // We don't need hDispDelay! It should be 0 always.
            if (o != hDispDelay) {
                System.err.println(hDispDelay);
            }
            o = hDispDelay;
            if (this.CRTCType != 3) {
                hDispDelay = 0;                                 // Seems that only CRTC 2,3 or 4 use it.
            }
            hDispEnd = reg[1] + hDispDelay;
            eventMask[hSyncStart] |= EVENT_HSYNC_START;
            eventMask[hDispDelay] |= EVENT_HDISP_START;
            eventMask[hDispEnd] |= EVENT_HDISP_END;
        } catch (Exception e) {
        }
    }
    int o;

    public int getVSyncWidth() {
        return vSyncWidth;
    }
    int realreg3;

    protected void setReg3(int value) {
        realreg3 = value;
        if (value != 143 && Scratchdemo) {
            Scratchdemo = false;
        }
        if (CRTCType == 1) {
            vSyncWidth = 0;
        } else {
            vSyncWidth = (value >> 4) & 0x0f;
        }

        boolean debug3 = false;
        if (tomate && patch && CRTCType != 3) {
            if (value == 142) {
                value = 141;
            }

        }
        if (patch && CRTCType != 3) {
            if (value != 13 && value > 3) {
                value -= 1;
            }
        }

        hSyncWidth = value & 0x0f;
        if (debug3) {
            System.err.println("setReg3: value is:" + value
                    + " hSyncWidth is:" + hSyncWidth + " vSyncWidth is:" + vSyncWidth);
        }

    }

    public void doAsicHsync(boolean force) {
        if (oldline != this.RasterCounter || force) {
            cpc.getAsic().ASIC_HSync(LineCounter, RasterCounter);

            oldline = this.RasterCounter;
        }
    }

    public void AsicHSync() {
        cpc.getAsic().ASIC_HSync(LineCounter, RasterCounter);
    }

    protected void checkHSync(boolean force) {
        if (hSyncWidth == 0 || force) {
            inHSync = false;
            hSyncCount = 0;
            try {
                listener.hSyncEnd();
            } catch (Exception e) {
            }
        }

    }

    protected void setReg8(int value) {
        interlace = (value & 0x01) != 0;
        interlaceVideo = (value & 0x03) == 3 ? 1 : 0;
        scanAdd = interlaceVideo + 1;
        maxRaster = reg[9] | interlaceVideo;
        cursorDelay = (value >> 6) & 0x03;
        setEvents();

    }

    public void setRegisterSelectMask(int mask, int test) {
        registerSelectMask = mask;
        registerSelectTest = test;
    }

    public void setRegisterWriteMask(int mask, int test) {
        registerWriteMask = mask;
        registerWriteTest = test;
    }

    public void setRegisterReadMask(int mask, int test) {
        registerReadMask = mask;
        registerReadTest = test;
    }

    public void setRegisterStatusMask(int mask, int test) {
        registerStatusMask = mask;
        registerStatusTest = test;
    }

    public int getHCC() {
        return hCC;
    }

    public int getHPOS() {
        return hCC * 8;
    }

    public int getNum() {
        return (LineCounter + RasterCounter);
    }

    public int getVPOS() {
        return (LineCounter * reg[9]) + RasterCounter;
    }

    public int getVVPOS() {
        return (((LineCounter & 0x01f) << 3)) + RasterCounter;
    }

    public boolean isVDisp() {
        return vDisp;
    }

    public boolean isVSync() {
        return inVSync;
    }

    public boolean isHSync() {
        return inHSync;
    }

    public boolean isHDisp() {
        return hDisp;
    }

    public int getMA() {
        return (maCurrent) & 0x03fff;
    }
    int scrolls[] = {
        0, 7, 6, 5, 4, 3, 2, 1
    };

    public int getScreenMA() {
        return maStore;
    }
    boolean vbit;
    int maVCC;

    public void setVerticalScroll(int value) {
        maScroll = value;
    }

    public int getRA() {
        return (RasterCounter + maScroll) & 0x07;
    }

    public int getRa() {
        return (RasterCounter) & 0x07;
    }

    public int getVCC() {
        return LineCounter;
    }
    int oldc;
    int oldn;
    int oldl;
    int newl;

    public int getLineNumber() {
        return ((RasterCounter & 0x07) + ((LineCounter & 0x07f) << 3));
    }

    public int getLine() {
        return ((RasterCounter & 0x07) + ((LineCounter & 0x07f) << 3) & 0x01ff);
    }

    public int getVal() {
        return ((LineCounter & 0x01f) << 3) + (RasterCounter & 0x07);

    }

    public int getRasterLine() {
        return (LineCounter * 8 + RasterCounter) & 0xfff;
    }

    public int getVLC() {
        return RasterCounter;
    }

    public int getReg(int index) {
        return reg[index];
    }

    public int getRegs(int index) {
        return regs[index];
    }

    public static String getRegister(int index) {
        return Util.hex(reg[index]).substring(6);
    }

    public static int getR(int index) {
        return reg[index];
    }

    public int getSelectedRegister() {
        return selReg;
    }

    public void setSelectedRegister(int value) {
        selReg = value & 0x1f;
    }

    public boolean isInterlace() {
        return interlace;
    }

    public boolean isInterlaceVideo() {
        return interlaceVideo == 1;
    }

    public int getFrame() {
        return frame;
    }

    public int getCRTC() {
        return CRTCType;
    }

    public void setCRTC(int value) {
        CRTCType = value & 0x01;
        CRTC = value & 0x01;
        setMasks();

    }

    public int getRegisterValue(int index) {              // where is that int used???
        int result = reg[index];
        if (index == 12) {
            result = (reg[12] << 8) | reg[13];
        } else if (index == 13) {
            result = (reg[14] << 8) | reg[15];
        }

        return result;
    }
}
