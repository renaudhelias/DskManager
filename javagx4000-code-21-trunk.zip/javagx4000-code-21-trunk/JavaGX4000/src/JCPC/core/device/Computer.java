package JCPC.core.device;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.zip.*;
import java.lang.reflect.*;
import java.net.*;
import java.util.*;
import JCPC.core.*;
import JCPC.core.cpu.*;
import JCPC.core.device.floppy.*;
import JCPC.core.device.memory.*;
import JCPC.ui.*;
import JCPC.util.diss.Disassembler;

/**
 * Title: JCPC Description: The Java Emulation Platform Copyright: Copyright (c)
 * 2002 Company:
 *
 * @author
 * @version 1.0
 */
public abstract class Computer extends Device implements Runnable {

    protected int currentDrive = 0;
    public static final String DEFAULT_COMPUTER = "CPC6128";
    public static final int TYPE_UNKNOWN = 0;
    public static final int TYPE_SNAPSHOT = 1;
    public static final int TYPE_DISC_IMAGE = 2;
    public static final int TYPE_TAPE_IMAGE = 3;
    public static final int STOP = 0;
    public static final int STEP = 1;
    public static final int STEP_OVER = 2;
    public static final int RUN = 3;
    public static final int MAX_FRAME_SKIP = 20;
    public static final int MAX_FILE_SIZE = 1024 * 1024 * 13;  // 1024K maximum
    public byte[][] disks = new byte[30][];
    public String[] disknames = new String[30];
    int index = 0;
    protected Applet applet;
    protected Thread thread = new Thread(this);
    protected boolean stopped = false;
    protected int action = STOP;
    protected boolean running = false;
    protected boolean waiting = false;
    protected long startTime;
    protected long startCycles;
    protected String name;
    protected String romPath;
    protected String filePath;
    protected Vector files = null;
    protected Display display;
    protected int frameSkip = 0;
    protected int runTo = -1;
    protected int mode = STOP;
    protected long maxResync = 200;
    // Devices used in this computer
    protected Vector devices = new Vector();
    // Listeners for stopped emulation
    protected Vector listeners = new Vector(1);

    public static Computer createComputer(Applet applet, String name) throws Exception {
        Class cl = Util.findClass(null, "JCPC.system.cpc.CPC");
        Constructor con = cl.getConstructor(new Class[]{Applet.class, String.class});
        return (Computer) con.newInstance(new Object[]{applet, name});
    }

    public Computer(Applet applet, String name) {
        super("Computer: " + name);
        this.applet = applet;
        this.name = name;
//    thread.setPriority(Thread.MIN_PRIORITY);
        thread.start();
    }

    protected void setBasePath(String path) {
        romPath = "rom/";
        filePath = "file/";
    }

    public void initialise() {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                reset();
            }
        });
    }

    public Device addDevice(Device device) {
        return addDevice(device, null);
    }

    public Device addDevice(Device device, String name) {
        if (name != null) {
            device.setName(name);
        }
        devices.addElement(device);
        return device;
    }

    public Vector getDevices() {
        return devices;
    }

    public InputStream openFile(String name) throws Exception {
        System.out.println("File: " + name);
        InputStream result;
        try {
            if (name.startsWith("http:")) {
                result = new URL(name).openStream();
            } else {
                result = new URL(applet.getCodeBase(), name).openStream();
            }
        } catch (Exception e) {
//      e.printStackTrace();
            result = new FileInputStream(name);
        }

        if (name.toLowerCase().endsWith(".zip")) {
            ZipInputStream str = new ZipInputStream(result);
            str.getNextEntry();
            result = str;
            return result;
        }
        return result;
    }

    protected int readStream(InputStream stream, byte[] buffer, int offs, int size)
            throws Exception {
        return readStream(stream, buffer, offs, size, true);
    }

    protected int readStream(InputStream stream, byte[] buffer, int offs, int size, boolean error)
            throws Exception {
        while (size > 0) {
            int read = stream.read(buffer, offs, size);
            if (read == -1) {
                if (error) {
                    throw new Exception("Unexpected end of stream");
                } else {
                    break;
                }
            } else {
                offs += read;
                size -= read;
            }
        }
        return offs;
    }
    protected static byte[] SKIP_BUFFER = new byte[1024];

    protected void skipStream(InputStream stream, int size) throws Exception {
        while (size > 0) {
            int bytes = size > 1024 ? 1024 : size;
            stream.read(SKIP_BUFFER, 0, bytes);
            size -= bytes;
        }
    }
    // For now, only supporting a single Processor

    public Disassembler getDisassembler() {
        return null;
    }
//
//    public byte[] getEntry(InputStream in) {
//        return getEntry(in, MAX_FILE_SIZE);
//    }
//
//    public byte[] getEntry(InputStream in, int size) {
//        byte[] buffer = new byte[size];
//        int offs = 0;
//        try {
//            InputStream stream = null;
//            try {
//                while (in.available() > 0) {
//                    int read = in.read(buffer, offs, size);
//                    if (read == -1) {
//                        break;
//                    } else {
//                        offs += read;
//                        size -= read;
//                    }
//                }
//            } finally {
//                if (stream != null) {
//                    stream.close();
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        if (offs < buffer.length) {
//            byte[] result = new byte[offs];
//            System.arraycopy(buffer, 0, result, 0, offs);
//            buffer = result;
//        }
//        return buffer;
//    }

    public byte[] getFile(String name) {
        return getFile(name, MAX_FILE_SIZE, true);
    }

    public byte[] getFile(String name, int size) {
        return getFile(name, size, false);
    }

    public byte[] getFile(String name, int size, boolean crop) {
        byte[] buffer = new byte[size];
        int offs = 0;
        try {
            InputStream stream = null;
            try {
                stream = openFile(name);
                while (size > 0) {
                    int read = stream.read(buffer, offs, size);
                    if (read == -1) {
                        break;
                    } else {
                        offs += read;
                        size -= read;
                    }
                }
            } finally {
                if (stream != null) {
                    stream.close();
                }
            }
        } catch (Exception e) {
            System.err.println("File not found: " + name);
//            e.printStackTrace();
        }
        if (crop && offs < buffer.length) {
            byte[] result = new byte[offs];
            System.arraycopy(buffer, 0, result, 0, offs);
            buffer = result;
        }
        return buffer;
    }

    public abstract void AutoType(String input);

    public abstract void openCPR();

    public void setDisplay(Display value) {
        display = value;
        displaySet();
    }

    public Display getDisplay() {
        return display;
    }

    protected void displaySet() {
    }

    public abstract Processor getProcessor();

    public abstract void reSync();

//    public abstract int[] getBlocks();
//
//    public abstract String[] getIDs();
//
//    public abstract int getPosition();
//
//    public abstract void setPosition(int value);
    public abstract Memory getMemory();

    public byte[] getRom(String name, int size) {
        byte[] buffer = new byte[size];
        int offs = 0;
        try {
            InputStream stream = null;
            try {
                InputStream is = getClass().getResourceAsStream(name);
                stream = is;
                while (size > 0) {
                    int read = stream.read(buffer, offs, size);
                    if (read == -1) {
                        break;
                    } else {
                        offs += read;
                        size -= read;
                    }
                }
            } finally {
                if (stream != null) {
                    stream.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return buffer;
    }

    public abstract void prepareAutotype(String input);

    public void processKeyEvent(KeyEvent e) {
        if (mode == RUN) {
            if (e.getID() == KeyEvent.KEY_PRESSED) {
                keyPressed(e);
            } else if (e.getID() == KeyEvent.KEY_RELEASED) {
                keyReleased(e);
            }
        }
    }

    public abstract void keyPressed(KeyEvent e);

    public abstract void keyReleased(KeyEvent e);

    public abstract void keyPressed(int e);

    public abstract void keyReleased(int e);

    public abstract void loadEntry(int index);

    public void loadFile(int type, String name) throws Exception {
    }

    public abstract Dimension getDisplaySize(boolean large);

    public void setLarge(boolean value) {
    }

    public Dimension getDisplayScale(boolean large) {
        return Display.SCALE_1x2;
    }

    public void start() {
        setAction(RUN);
    }

    public void stop() {
        setAction(STOP);
    }

    public void step() {
        setAction(STEP);
    }

    public void stepOver() {
        setAction(STEP_OVER);
    }

    public synchronized void setAction(int value) {
        if (running && value != RUN) {
            action = STOP;
            //System.out.println(this + " Stopping " + getProcessor());
            getProcessor().stop();
            while (running) {
                try {
                    //System.out.println("stopping...");
                    Thread.sleep(200);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        //System.out.println("Entering synchronized");
        synchronized (thread) {
            action = value;
            thread.notify();
        }
    }

    public void dispose() {
        stopped = true;
        //System.out.println(this + " thread stopped: " + thread);
        stop();
        //System.out.println(this + " has stopped");
        try {
            thread.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
        thread = null;
        display = null;
        applet = null;
    }

    protected void emulate(int mode) {
        switch (mode) {
            case STEP:
                getProcessor().step();
                break;

            case STEP_OVER:
                getProcessor().stepOver();
                break;

            case RUN:
                if (runTo == -1) {
                    getProcessor().run();
                } else {
                    getProcessor().runTo(runTo);
                }
                break;
        }
    }

    public void addActionListener(ActionListener listener) {
        listeners.addElement(listener);
    }

    public void removeActionListener(ActionListener listener) {
        listeners.removeElement(listener);
    }

    protected void fireActionEvent() {
        ActionEvent e = new ActionEvent(this, 0, null);
        for (int i = 0; i < listeners.size(); i++) {
            ((ActionListener) listeners.elementAt(i)).actionPerformed(e);
        }
    }

    public String getROMPath() {
        return romPath;
    }

    public String getFilePath() {
        return filePath;
    }

    public void reset() {
    }

    public void run() {
        while (!stopped) {
            try {
                if (action == STOP) {
                    synchronized (thread) {
                        //System.out.println(this + " Waiting");
                        try {
                            thread.wait();
                        } catch (Exception e) {
                        }
                        //System.out.println(this + " Not Waiting");
                    }
                }
                if (action != STOP) {
                    try {
                        //System.out.println(this + " Running");
                        running = true;
                        synchronized (thread) {
                            mode = action;
                            action = STOP;
                        }
                        startCycles = getProcessor().getCycles();
                        startTime = System.currentTimeMillis();
                        emulate(mode);
                    } finally {
                        running = false;
                        //System.out.println(this + " Not running");
                        fireActionEvent();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public boolean isRunning() {
        return running;
    }

    protected void syncProcessor() {
        syncProcessor(null, (((getProcessor().getCycles() - startCycles) * 2000
                / getProcessor().getCyclesPerSecond()) + 1) / 2, 200);
    }

    protected void syncProcessor(ComputerTimer timer) {
        syncProcessor(timer, timer.getUpdates(), timer.getDeviation());
    }

    protected void syncProcessor(ComputerTimer timer, long count, long deviation) {
        startTime += count;
        startCycles = getProcessor().getCycles();
        long time = timer != null ? timer.getCount() : System.currentTimeMillis();
        //System.out.println(": " + startTime + ", " + time + "," + deviation);
        if (time < startTime - deviation) {
            setFrameSkip(0);
            startTime = time;
        } else if (time > startTime) {
            if (frameSkip == MAX_FRAME_SKIP) {
                setFrameSkip(0);
                if (timer != null) {
                    timer.resync();
                }
                //System.out.println(" R: " + (time - startTime));
                startTime = (timer != null ? timer.getCount() : System.currentTimeMillis());
            } else {
                //System.out.print(" S" + frameSkip);
                setFrameSkip(frameSkip + 1);
            }
        } else {
            try {
                setFrameSkip(0);
                long start = System.currentTimeMillis();
                while ((time = timer != null ? timer.getCount() : System.currentTimeMillis()) < startTime) {
                    if (timer != null && System.currentTimeMillis() - start > maxResync) {
                        timer.resync();
                        System.out.println("resync 2");
                        startTime = timer.getCount();
                        break;
                    }
                    Thread.sleep(1);
                }
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        }
    }

    public void setMaxResync(long value) {
        maxResync = value;
    }

    public void setFrameSkip(int value) {
        frameSkip = value;
    }

    public void displayLostFocus() {
    }

    public void updateDisplay(boolean wait) {
    }

    public String getName() {
        return name;
    }

    public void setRunToAddress(int value) {
        runTo = value;
    }

    public void clearRunToAddress() {
        runTo = -1;
    }

    public int getMode() {
        return mode;
    }

    public Drive[] getFloppyDrives() {
        return null;
    }

    public int getCurrentDrive() {
        return currentDrive;
    }

    public void setCurrentDrive(int drive) {
        currentDrive = drive;
    }

    public int getIndex() {
        return index;
    }
}
