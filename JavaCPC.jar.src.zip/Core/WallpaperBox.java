package Core;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.LayoutStyle;
import javax.swing.Timer;

public class WallpaperBox extends JFrame {
  Timer timer;
  
  int updater;
  
  ActionListener update;
  
  int maxno;
  
  String path;
  
  String area;
  
  int index;
  
  String zipurl;
  
  int random;
  
  String prefix;
  
  String babe;
  
  private JButton cat;
  
  private JButton jButton1;
  
  private JButton jButton2;
  
  private JButton jButton3;
  
  private JButton jButton4;
  
  private JLabel jLabel1;
  
  private JLabel label;
  
  private JLabel no;
  
  public static JProgressBar progress;
  
  public static JCheckBox unzip;
  
  public WallpaperBox() {
    this.update = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          WallpaperBox.this.updater++;
          if (WallpaperBox.this.updater == 20) {
            WallpaperBox.this.jButton1.setEnabled(true);
            WallpaperBox.this.jButton2.setEnabled(true);
            WallpaperBox.this.updater = 0;
          } 
        }
      };
    this.path = "newbox3";
    this.area = "fantasy_";
    this.index = 0;
    initComponents();
    this.timer = new Timer(150, this.update);
    this.cat.setText("Fantasy");
    setTitle("FantasyBox 1.0 by Devilmarkus");
    this.maxno = 626;
    updateBox(false, false);
    this.timer.start();
  }
  
  public void download() {
    if (this.zipurl == null)
      return; 
    this.updater = 0;
    this.jButton1.setEnabled(false);
    this.jButton2.setEnabled(false);
    String down = "fantasy_" + this.prefix + this.babe + ".zip";
    final String[] args = new String[2];
    args[0] = this.zipurl;
    args[1] = down;
    Thread tr = new Thread() {
        public void run() {
          copyURL.download(args);
        }
      };
    tr.start();
  }
  
  public void setBox() {
    this.index++;
    if (this.index > 3)
      this.index = 0; 
    switch (this.index) {
      case 1:
        this.maxno = 500;
        this.path = "newbox";
        this.area = "babe_";
        updateBox(false, false);
        this.cat.setText("Babes");
        setTitle("BabeBox 1.0 by Devilmarkus");
        break;
      case 0:
        this.maxno = 626;
        this.path = "newbox3";
        this.area = "fantasy_";
        updateBox(false, false);
        this.cat.setText("Fantasy");
        setTitle("FantasyBox 1.0 by Devilmarkus");
        break;
      case 2:
        this.maxno = 296;
        this.path = "newbox2";
        this.area = "3d_";
        updateBox(false, false);
        this.cat.setText("3D-Art");
        setTitle("3D-Box 1.0 by Devilmarkus");
        break;
      case 3:
        this.maxno = 500;
        this.path = "newbox4";
        this.area = "cars_";
        updateBox(false, false);
        this.cat.setText("Cars");
        setTitle("CarBox 1.0 by Devilmarkus");
        break;
    } 
  }
  
  public void updateBox(boolean back, boolean forward) {
    try {
      this.zipurl = "";
      this.updater = 0;
      this.prefix = "";
      this.babe = "";
      if (!back && !forward)
        this.random = random(this.maxno - 1) + 1; 
      if (back) {
        this.random--;
        if (this.random < 1)
          this.random = this.maxno; 
      } 
      if (forward) {
        this.random++;
        if (this.random > this.maxno)
          this.random = 1; 
      } 
      if (this.random < 100)
        this.prefix = "0"; 
      if (this.random < 10)
        this.prefix = "00"; 
      this.no.setText("" + this.random);
      this.babe = "" + this.random;
      URL imag = new URL("http://cpc-live.com/" + this.path + "/img_" + this.prefix + this.babe + ".jpg");
      this.zipurl = "http://cpc-live.com/" + this.path + "/img_" + this.prefix + this.babe + ".zip";
      this.label.setIcon(new ImageIcon(imag));
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public static int random(int n) {
    double decimal = Math.random();
    int value = (int)Math.round(decimal * n);
    return value;
  }
  
  private void initComponents() {
    unzip = new JCheckBox();
    this.jButton1 = new JButton();
    this.jLabel1 = new JLabel();
    this.no = new JLabel();
    this.jButton2 = new JButton();
    this.jButton3 = new JButton();
    this.jButton4 = new JButton();
    this.label = new JLabel();
    this.cat = new JButton();
    progress = new JProgressBar();
    unzip.setSelected(true);
    unzip.setText("Unzip");
    unzip.setFocusPainted(false);
    unzip.setFocusable(false);
    setTitle("FantasyBox 1.0 by Devilmarkus");
    setBackground(new Color(0, 0, 0));
    setCursor(new Cursor(0));
    setResizable(false);
    this.jButton1.setText("RND");
    this.jButton1.setToolTipText("Select random image");
    this.jButton1.setFocusPainted(false);
    this.jButton1.setFocusable(false);
    this.jButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            WallpaperBox.this.jButton1ActionPerformed(evt);
          }
        });
    this.jLabel1.setText("No.");
    this.no.setText("000");
    this.jButton2.setText("Set");
    this.jButton2.setToolTipText("Download this image");
    this.jButton2.setFocusPainted(false);
    this.jButton2.setFocusable(false);
    this.jButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            WallpaperBox.this.jButton2ActionPerformed(evt);
          }
        });
    this.jButton3.setText("<");
    this.jButton3.setToolTipText("Previous image");
    this.jButton3.setFocusPainted(false);
    this.jButton3.setFocusable(false);
    this.jButton3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            WallpaperBox.this.jButton3ActionPerformed(evt);
          }
        });
    this.jButton4.setText(">");
    this.jButton4.setToolTipText("Next image");
    this.jButton4.setFocusPainted(false);
    this.jButton4.setFocusable(false);
    this.jButton4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            WallpaperBox.this.jButton4ActionPerformed(evt);
          }
        });
    this.label.setToolTipText("The actual image");
    this.label.setBorder(BorderFactory.createEtchedBorder());
    this.cat.setText("Category");
    this.cat.setToolTipText("Select category");
    this.cat.setFocusPainted(false);
    this.cat.setFocusable(false);
    this.cat.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            WallpaperBox.this.catActionPerformed(evt);
          }
        });
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(progress, -1, 388, 32767)
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
              .addComponent(this.label, -2, 388, -2)
              .addGroup(layout.createSequentialGroup()
                .addComponent(this.jButton1)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(this.jLabel1)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(this.no)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(this.jButton3)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(this.jButton4)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(this.jButton2)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(this.cat, -1, -1, 32767))))
          .addContainerGap()));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addComponent(this.label, -2, 244, -2)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jButton1)
            .addComponent(this.jLabel1)
            .addComponent(this.no)
            .addComponent(this.jButton3)
            .addComponent(this.jButton4)
            .addComponent(this.jButton2)
            .addComponent(this.cat))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(progress, -2, -1, -2)
          .addContainerGap(-1, 32767)));
    getAccessibleContext().setAccessibleName("BabeBox 2.0 by Devilmarkus");
    pack();
  }
  
  private void jButton1ActionPerformed(ActionEvent evt) {
    updateBox(false, false);
  }
  
  private void jButton2ActionPerformed(ActionEvent evt) {
    download();
  }
  
  private void jButton3ActionPerformed(ActionEvent evt) {
    updateBox(true, false);
  }
  
  private void jButton4ActionPerformed(ActionEvent evt) {
    updateBox(false, true);
  }
  
  private void catActionPerformed(ActionEvent evt) {
    setBox();
  }
  
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new WallpaperBox()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\Core\WallpaperBox.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */