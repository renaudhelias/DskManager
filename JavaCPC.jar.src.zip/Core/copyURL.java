package Core;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import jemu.settings.DSettings;
import jemu.ui.Desktop;

public class copyURL {
  public static boolean abort = false;
  
  public static boolean downloading = false;
  
  public static void download(String[] args) {
    if (args.length < 1) {
      System.err.println("usage: java copyURL URL [LocalFile]");
      System.exit(1);
    } 
    try {
      String check = args[1];
      File chk = new File(check);
      String ext = check.substring(check.length() - 4);
      String name = check.substring(0, check.length() - 4);
      System.out.println("Name is:" + name);
      System.out.println("Ext. is:" + ext);
      while (chk.canRead()) {
        name = name + "-";
        chk = new File(name + ext);
      } 
      args[1] = name + ext;
      String dlurl = args[0];
      if (dlurl.contains("download.php")) {
        String newurl = "http://retropower.eu/cpc/";
        while (!dlurl.startsWith("type="))
          dlurl = dlurl.substring(1); 
        dlurl = dlurl.replace("type=", "");
        while (!dlurl.startsWith("&")) {
          newurl = newurl + dlurl.charAt(0);
          dlurl = dlurl.substring(1);
        } 
        while (!dlurl.startsWith("fichier="))
          dlurl = dlurl.substring(1); 
        dlurl = dlurl.replace("fichier=", "");
        newurl = newurl + "/" + dlurl;
        dlurl = newurl;
      } 
      dlurl = dlurl.replace(" ", "%20");
      dlurl = dlurl.replace("(", "%28");
      dlurl = dlurl.replace(")", "%29");
      dlurl = dlurl.replace("[", "%5B");
      dlurl = dlurl.replace("]", "%5D");
      URL url = new URL(dlurl);
      System.out.println("Opening connection to " + dlurl + "...");
      HttpURLConnection urlC = (HttpURLConnection)url.openConnection();
      urlC.setRequestMethod("GET");
      InputStream is = url.openStream();
      BufferedInputStream bis = new BufferedInputStream(is);
      System.out.print("Copying resource (type: " + urlC
          .getContentType());
      Date date = new Date(urlC.getLastModified());
      int size = urlC.getContentLength();
      WallpaperBox.progress.setMaximum(size);
      System.out.println(", modified on: " + date
          .toString() + ")...");
      System.out.flush();
      FileOutputStream fos = null;
      if (args.length < 2) {
        String localFile = null;
        StringTokenizer st = new StringTokenizer(url.getFile(), "/");
        while (st.hasMoreTokens())
          localFile = st.nextToken(); 
        fos = new FileOutputStream(localFile);
      } else {
        fos = new FileOutputStream(args[1] + ".tmp");
      } 
      BufferedOutputStream bos = new BufferedOutputStream(fos);
      int count = 0;
      abort = false;
      while (count < size) {
        bos.write(bis.read());
        count++;
        WallpaperBox.progress.setValue(count);
      } 
      bis.close();
      bos.close();
      is.close();
      fos.close();
      File temp = new File(args[1] + ".tmp");
      if (abort) {
        temp.delete();
        downloading = false;
        return;
      } 
      File temp2 = new File(args[1]);
      temp.renameTo(temp2);
      try {
        if (WallpaperBox.unzip.isSelected())
          getZipFiles(args[1]); 
      } catch (Exception exception) {}
      System.out.println("\n" + count + " byte(s) copied");
      WallpaperBox.progress.setValue(0);
      downloading = false;
    } catch (MalformedURLException malformedURLException) {
    
    } catch (IOException iOException) {}
  }
  
  public static boolean deleteDirectory(File path) {
    if (path.exists()) {
      File[] files = path.listFiles();
      for (int i = 0; i < files.length; i++) {
        if (files[i].isDirectory()) {
          deleteDirectory(files[i]);
        } else {
          files[i].delete();
        } 
      } 
    } 
    return path.delete();
  }
  
  public static void getZipFiles(String filename) {
    try {
      String destinationname = "wallpaper/";
      File check = new File(destinationname);
      if (!check.exists())
        check.mkdir(); 
      String wallname = "";
      byte[] buf = new byte[1024];
      ZipInputStream zipinputstream = null;
      zipinputstream = new ZipInputStream(new FileInputStream(filename));
      ZipEntry zipentry = zipinputstream.getNextEntry();
      while (zipentry != null) {
        String entryName = zipentry.getName();
        System.out.println("entryname " + entryName);
        File newFile = new File(entryName);
        String directory = newFile.getParent();
        if (directory == null && 
          newFile.isDirectory())
          break; 
        FileOutputStream fileoutputstream = new FileOutputStream(destinationname + entryName);
        wallname = destinationname + entryName;
        int n;
        while ((n = zipinputstream.read(buf, 0, 1024)) > -1)
          fileoutputstream.write(buf, 0, n); 
        fileoutputstream.close();
        zipinputstream.closeEntry();
        zipentry = zipinputstream.getNextEntry();
      } 
      zipinputstream.close();
      File zip = new File(filename);
      zip.delete();
      SetWallpaper(wallname);
    } catch (Exception exception) {}
  }
  
  public static void SetWallpaper(String path) {
    DSettings.set("wallpaper", path);
    Desktop.changewallpaper = true;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\Core\copyURL.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */