package jemu.system.cpc;

import java.awt.EventQueue;
import javax.swing.GroupLayout;
import javax.swing.JFrame;
import javax.swing.JSlider;

public class Intak extends JFrame {
  public JSlider intak;
  
  public Intak() {
    initComponents();
  }
  
  private void initComponents() {
    this.intak = new JSlider();
    setDefaultCloseOperation(3);
    this.intak.setMaximum(1000);
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addComponent(this.intak, -1, 380, 32767)
          .addContainerGap()));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addComponent(this.intak, -2, -1, -2)
          .addContainerGap(-1, 32767)));
    pack();
  }
  
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new Intak()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\Intak.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */