package jemu.system.cpc;

import jemu.core.cpu.Z80;

public class Z80 extends Z80 {
  protected static final byte[] CPC_TIME_PRE = new byte[] { 
      1, 3, 2, 2, 1, 1, 2, 1, 1, 3, 
      2, 2, 1, 1, 2, 1, 3, 3, 2, 2, 
      1, 1, 2, 1, 3, 3, 2, 2, 1, 1, 
      2, 1, 2, 3, 5, 2, 1, 1, 2, 1, 
      2, 3, 5, 2, 1, 1, 2, 1, 2, 3, 
      4, 2, 3, 3, 3, 1, 2, 3, 4, 2, 
      1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 
      2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 
      1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 
      1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 
      1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 
      2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 
      1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 
      1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 
      1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 
      2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 
      1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 
      1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 
      1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 
      2, 1, 2, 3, 3, 3, 3, 4, 2, 4, 
      2, 3, 3, 1, 3, 5, 2, 4, 2, 3, 
      3, 3, 3, 4, 2, 4, 2, 1, 3, 3, 
      3, 1, 2, 4, 2, 3, 3, 6, 3, 4, 
      2, 4, 2, 1, 3, 1, 3, 1, 2, 4, 
      2, 3, 3, 1, 3, 4, 2, 4, 2, 2, 
      3, 1, 3, 1, 2, 4 };
  
  protected static final byte[] CPC_TIME_POST = new byte[] { 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0 };
  
  protected static final byte[] CPC_TIME_PRE_CB = new byte[] { 
      1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 
      1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 
      1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 
      3, 1, 1, 1, 1, 1, 1, 1, 3, 1, 
      1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 
      1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 
      1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 
      2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 
      1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 
      1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 
      1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 
      2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 
      1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 
      1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 
      1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 
      3, 1, 1, 1, 1, 1, 1, 1, 3, 1, 
      1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 
      1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 
      1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 
      3, 1, 1, 1, 1, 1, 1, 1, 3, 1, 
      1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 
      1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 
      1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 
      3, 1, 1, 1, 1, 1, 1, 1, 3, 1, 
      1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 
      1, 1, 1, 1, 3, 1 };
  
  protected static final byte[] CPC_TIME_POST_CB = new byte[] { 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0 };
  
  protected static final byte[] CPC_TIME_PRE_ED = new byte[] { 
      3, 3, 3, 5, 1, 3, 1, 2, 3, 3, 
      3, 5, 1, 3, 1, 2, 3, 3, 3, 5, 
      1, 3, 1, 2, 3, 3, 3, 5, 1, 3, 
      1, 2, 3, 3, 3, 5, 1, 3, 1, 4, 
      3, 3, 3, 5, 1, 3, 1, 4, 3, 3, 
      3, 5, 1, 3, 1, 1, 3, 3, 3, 5, 
      1, 3, 1, 1, 4, 3, 4, 4, 4, 3, 
      4, 4, 4, 3, 4, 4, 4, 3, 4, 4 };
  
  protected static final byte[] CPC_TIME_POST_ED = new byte[] { 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
  
  protected static final byte[] CPC_TIME_EXTRA = new byte[] { 
      1, 1, 2, 2, 1, 2, 1, 1, 2, 2, 
      2, 0, 0, 5, 1 };
  
  protected byte[] TURBO_TIME_PRE;
  
  protected byte[] TURBO_TIME_PRE_CB;
  
  protected byte[] TURBO_TIME_PRE_ED;
  
  protected byte[] TURBO_TIME_EXTRA;
  
  final byte turbonops = 1;
  
  public Z80(long cyclesPerSecond) {
    super(cyclesPerSecond);
    this.turbonops = 1;
  }
  
  public void setTimes(boolean turbo) {
    if (this.TURBO_TIME_PRE == null) {
      this.TURBO_TIME_PRE = new byte[CPC_TIME_PRE.length];
      this.TURBO_TIME_PRE_CB = new byte[CPC_TIME_PRE_CB.length];
      this.TURBO_TIME_PRE_ED = new byte[CPC_TIME_PRE_ED.length];
      this.TURBO_TIME_EXTRA = new byte[CPC_TIME_EXTRA.length];
      int i;
      for (i = 0; i < this.TURBO_TIME_PRE.length; i++)
        this.TURBO_TIME_PRE[i] = 1; 
      for (i = 0; i < this.TURBO_TIME_PRE_CB.length; i++)
        this.TURBO_TIME_PRE_CB[i] = 1; 
      for (i = 0; i < this.TURBO_TIME_PRE_ED.length; i++)
        this.TURBO_TIME_PRE_ED[i] = 1; 
      for (i = 0; i < this.TURBO_TIME_EXTRA.length; i++)
        this.TURBO_TIME_EXTRA[i] = 1; 
    } 
    setTimes(turbo ? this.TURBO_TIME_PRE : CPC_TIME_PRE, CPC_TIME_POST, turbo ? this.TURBO_TIME_PRE_CB : CPC_TIME_PRE_CB, CPC_TIME_POST_CB, turbo ? this.TURBO_TIME_PRE_ED : CPC_TIME_PRE_ED, CPC_TIME_POST_ED, turbo ? this.TURBO_TIME_EXTRA : CPC_TIME_EXTRA);
  }
  
  public void setTimes() {
    setTimes(CPC_TIME_PRE, CPC_TIME_POST, CPC_TIME_PRE_CB, CPC_TIME_POST_CB, CPC_TIME_PRE_ED, CPC_TIME_POST_ED, CPC_TIME_EXTRA);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\Z80.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */