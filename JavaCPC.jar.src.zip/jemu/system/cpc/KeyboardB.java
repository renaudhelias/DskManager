package jemu.system.cpc;

import java.util.Vector;

public class KeyboardB extends Keyboard {
  protected static final int[] KEY_MAP = new int[] { 
      38, 39, 40, 120, 117, 114, 35, 110, 37, 12, 
      118, 119, 116, 112, 113, 123, 127, 65406, 10, 93, 
      115, 16, 92, 17, 61, 45, 91, 80, 222, 59, 
      47, 46, 48, 57, 79, 73, 76, 75, 77, 44, 
      56, 55, 85, 89, 72, 74, 78, 32, 54, 53, 
      82, 84, 71, 70, 66, 86, 52, 51, 69, 87, 
      83, 68, 67, 88, 49, 50, 27, 81, 9, 65, 
      20, 90, -1, -1, -1, -1, -1, -1, -1, 8 };
  
  public void setKeyMappings() {
    addKeyMappings(KEY_MAP);
    addKeyMapping(186, 5, 3);
    addKeyMapping(188, 7, 4);
    addKeyMapping(189, 1, 3);
    addKeyMapping(190, 7, 3);
    addKeyMapping(219, 2, 3);
    addKeyMapping(221, 3, 2);
  }
  
  protected void processKey(byte keynum) {
    if ((this.keyBytes[keynum / 8] & 1 << (keynum & 0x7)) == 0) {
      this.keyBytes[keynum / 8] = this.keyBytes[keynum / 8] | 1 << (keynum & 0x7);
    } else {
      this.keyBytes[keynum / 8] = this.keyBytes[keynum / 8] & (1 << (keynum & 0x7) ^ 0xFFFFFFFF);
    } 
  }
  
  protected void ReleaseKey(byte keynum) {
    this.keyBytes[keynum / 8] = this.keyBytes[keynum / 8] | 1 << (keynum & 0x7);
  }
  
  protected void PressKey(byte keynum) {
    this.keyBytes[keynum / 8] = this.keyBytes[keynum / 8] & (1 << (keynum & 0x7) ^ 0xFFFFFFFF);
  }
  
  protected boolean IsPressed(byte keynum) {
    return ((this.keyBytes[keynum / 8] & 1 << (keynum & 0x7)) == 0);
  }
  
  protected int[] previousbytes = new int[10];
  
  protected void initBytes() {
    for (int i = 0; i < 10; i++)
      this.previousbytes[i] = this.keyBytes[i]; 
  }
  
  protected byte[] getKeyNum() {
    Vector<Integer> keynums = new Vector();
    for (int i = 0; i < 10; i++) {
      if (this.previousbytes[i] != this.keyBytes[i]) {
        for (int b = 0; b < 8; b++) {
          if (((this.previousbytes[i] ^ this.keyBytes[i]) & 1 << b) != 0)
            keynums.add(Integer.valueOf(i * 8 + b)); 
        } 
        this.previousbytes[i] = this.keyBytes[i];
      } 
    } 
    Object[] array = keynums.toArray();
    byte[] keys = new byte[array.length];
    for (int j = 0; j < keys.length; j++)
      keys[j] = (byte)Integer.parseInt(array[j].toString()); 
    return keys;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\KeyboardB.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */