package jemu.system.cpc;

public class CheckDOS {
  public int ChecksumAMSDOS(byte[] pHeader) {
    int Checksum = 0;
    for (int i = 0; i < 67; i++) {
      int CheckSumByte = pHeader[i] & 0xFF;
      Checksum += CheckSumByte;
    } 
    return Checksum;
  }
  
  public boolean CheckAMSDOS(byte[] pHeader) {
    int CalculatedChecksum = ChecksumAMSDOS(pHeader);
    int ChecksumFromHeader = pHeader[67] & 0xFF | (pHeader[68] & 0xFF) << 8;
    if (ChecksumFromHeader == CalculatedChecksum && ChecksumFromHeader != 0)
      return true; 
    return false;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\CheckDOS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */