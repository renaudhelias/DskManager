package jemu.system.cpc;

public class Cruncher {
  private int SEEKBACK = 4096;
  
  private int MAXSTRING = 256;
  
  private int[] matches = new int[this.MAXSTRING];
  
  private int[][] matchtable = new int[this.MAXSTRING][this.SEEKBACK];
  
  private byte[] bufOut = new byte[1048575];
  
  public byte[] Depack(byte[] bufIn) {
    int startIn = 0;
    int DepackBits = 0;
    int inBytes = startIn, outBytes = 0;
    while (true) {
      int longueur, delta, bit = DepackBits & 0x1;
      DepackBits >>= 1;
      if (DepackBits == 0) {
        DepackBits = bufIn[inBytes++] & 0xFF;
        bit = DepackBits & 0x1;
        DepackBits >>= 1;
        DepackBits |= 0x80;
      } 
      if (bit == 0) {
        this.bufOut[outBytes++] = bufIn[inBytes++];
        continue;
      } 
      if (bufIn[inBytes] == 0)
        break; 
      int a = bufIn[inBytes];
      if ((a & 0x80) != 0) {
        longueur = 3 + (bufIn[inBytes] >> 4 & 0x7);
        delta = (bufIn[inBytes++] & 0xF) << 8;
        delta |= bufIn[inBytes++] & 0xFF;
        delta++;
      } else if ((a & 0x40) != 0) {
        longueur = 2;
        delta = bufIn[inBytes++] & 0x3F;
        delta++;
      } else if ((a & 0x20) != 0) {
        longueur = 2 + (bufIn[inBytes++] & 0x1F);
        delta = bufIn[inBytes++] & 0xFF;
        delta++;
      } else if ((a & 0x10) != 0) {
        delta = (bufIn[inBytes++] & 0xF) << 8;
        delta |= bufIn[inBytes++] & 0xFF;
        longueur = (bufIn[inBytes++] & 0xFF) + 1;
        delta++;
      } else if (bufIn[inBytes] == 15) {
        longueur = delta = (bufIn[inBytes + 1] & 0xFF) + 1;
        inBytes += 2;
      } else {
        if (bufIn[inBytes] > 1) {
          longueur = delta = bufIn[inBytes] & 0xFF;
        } else {
          longueur = delta = 256;
        } 
        inBytes++;
      } 
      while (longueur-- > 0) {
        this.bufOut[outBytes] = this.bufOut[outBytes - delta];
        outBytes++;
      } 
    } 
    byte[] buffer = new byte[outBytes];
    System.arraycopy(this.bufOut, 0, buffer, 0, buffer.length);
    return buffer;
  }
  
  public byte[] Pack(byte[] bufIn) {
    int lengthIn = bufIn.length;
    int lengthOut = 0;
    byte[] codebuffer = new byte[24];
    byte bits = 0;
    int count = 0, bitcount = 0, codecount = 0;
    int matchtablestart = 0, matchtableend = 0;
    for (int i = 0; i < this.matches.length; i++)
      this.matches[i] = 0; 
    while (true) {
      int c;
      for (c = matchtableend; c < count; c++) {
        int b = bufIn[c] & 0xFF;
        this.matchtable[b][this.matches[b]] = c;
        this.matches[b] = this.matches[b] + 1;
      } 
      matchtableend = count;
      if (count >= 2) {
        int stlen = 0;
        int stpos = 0;
        int stlen2 = 0;
        int bb = bufIn[count] & 0xFF;
        for (c = this.matches[bb] - 1; c >= 0; c--) {
          int start = this.matchtable[bb][c];
          int end = start + this.MAXSTRING;
          if (end > count)
            end = count; 
          int max = end - start;
          if (max >= stlen) {
            int d;
            for (d = 1; d < max && 
              start + d < lengthIn && count + d < lengthIn && bufIn[start + d] == bufIn[count + d]; d++);
            if (d >= 2 && d > stlen) {
              stlen = d;
              stpos = count - start;
            } 
            if (d == stlen && count - start < stpos)
              stpos = count - start; 
          } 
          if (stlen == this.MAXSTRING && stpos == stlen)
            break; 
        } 
        if (count + 1 < lengthIn) {
          bb = bufIn[count + 1] & 0xFF;
          for (c = this.matches[bb] - 1; c >= 0; c--) {
            int start = this.matchtable[bb][c];
            int end = start + this.MAXSTRING;
            if (end > count + 1)
              end = count + 1; 
            int max = end - start;
            if (max >= stlen2) {
              int d;
              for (d = 1; d < max && 
                start + d < lengthIn && count + d + 1 < lengthIn && bufIn[start + d] == bufIn[count + d + 1]; d++);
              if (d >= 2 && d >= stlen2)
                stlen2 = d; 
            } 
            if (stlen2 == this.MAXSTRING)
              break; 
          } 
          if (stlen2 - 1 > stlen)
            stlen = 0; 
        } 
        if (stlen > 1) {
          if (stlen == 2 && stpos >= this.MAXSTRING) {
            codebuffer[codecount++] = bufIn[count++];
            bitcount++;
          } else {
            if (stpos == stlen) {
              if (stlen == this.MAXSTRING) {
                codebuffer[codecount++] = 1;
              } else if (stlen <= 14) {
                codebuffer[codecount++] = (byte)stlen;
              } else {
                codebuffer[codecount++] = 15;
                codebuffer[codecount++] = (byte)(stlen - 1);
              } 
            } else if (stlen == 2 && stpos < 65) {
              codebuffer[codecount++] = (byte)(64 + stpos - 1);
            } else if (stlen <= 33 && stpos < 257) {
              codebuffer[codecount++] = (byte)(32 + stlen - 2);
              codebuffer[codecount++] = (byte)(stpos - 1);
            } else if (stlen >= 3 && stlen <= 10) {
              codebuffer[codecount++] = (byte)(128 + (stlen - 3 << 4) + (stpos - 1 >> 8));
              codebuffer[codecount++] = (byte)(stpos - 1);
            } else {
              codebuffer[codecount++] = (byte)(16 + (stpos - 1 >> 8));
              codebuffer[codecount++] = (byte)(stpos - 1);
              codebuffer[codecount++] = (byte)(stlen - 1);
            } 
            bits = (byte)(bits | 1 << bitcount);
            bitcount++;
            count += stlen;
          } 
        } else {
          codebuffer[codecount++] = bufIn[count++];
          bitcount++;
        } 
      } else {
        codebuffer[codecount++] = bufIn[count++];
        bitcount++;
      } 
      if (bitcount == 8) {
        this.bufOut[lengthOut++] = bits;
        System.arraycopy(codebuffer, 0, this.bufOut, lengthOut, codecount);
        lengthOut += codecount;
        bitcount = codecount = 0;
        bits = 0;
      } 
      if (count >= lengthIn)
        break; 
      int oldmatchtablestart = matchtablestart;
      matchtablestart = count - this.SEEKBACK;
      if (matchtablestart < 0)
        matchtablestart = 0; 
      for (c = oldmatchtablestart; c < matchtablestart; c++) {
        int b = bufIn[c] & 0xFF;
        int d;
        for (d = 0; d < this.matches[b]; d++) {
          if (this.matchtable[b][d] >= matchtablestart) {
            System.arraycopy(this.matchtable[b], d, this.matchtable[b], 0, this.matches[b] - d);
            break;
          } 
        } 
        this.matches[b] = this.matches[b] - d;
      } 
    } 
    codebuffer[codecount++] = 0;
    this.bufOut[lengthOut++] = (byte)(bits | 1 << bitcount);
    System.arraycopy(codebuffer, 0, this.bufOut, lengthOut, codecount);
    byte[] buffer = new byte[lengthOut + codecount];
    System.arraycopy(this.bufOut, 0, buffer, 0, buffer.length);
    return buffer;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\Cruncher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */