package jemu.system.cpc;

import jemu.core.device.keyboard.MatrixKeyboard;
import jemu.settings.Settings;

public abstract class Keyboard extends MatrixKeyboard {
  protected boolean DEBUG = false;
  
  protected int[] keyBytes = new int[16];
  
  protected int row = 0;
  
  protected int[] KeyboardData = new int[16];
  
  protected boolean keyClash;
  
  public Keyboard() {
    super("CPC Keyboard", 8, 10);
    this.keyClash = false;
    this.keyClash = Settings.getBoolean("keyboard_clash", true);
    for (int i = 0; i < this.keyBytes.length; i++) {
      this.KeyboardData[i] = 255;
      this.keyBytes[i] = 255;
    } 
    setKeyMappings();
    reset();
  }
  
  public void setKeyClash(boolean clash) {
    this.keyClash = clash;
  }
  
  protected abstract void setKeyMappings();
  
  protected abstract void processKey(byte paramByte);
  
  protected abstract void ReleaseKey(byte paramByte);
  
  protected abstract void PressKey(byte paramByte);
  
  protected abstract boolean IsPressed(byte paramByte);
  
  protected abstract void initBytes();
  
  protected abstract byte[] getKeyNum();
  
  protected void keyChanged(int col, int row, int oldValue, int newValue) {
    if (oldValue == 0) {
      if (newValue != 0)
        this.KeyboardData[row] = this.KeyboardData[row] & (1 << col ^ 0xFF); 
    } else if (newValue == 0) {
      this.KeyboardData[row] = this.KeyboardData[row] | 1 << col;
    } 
    System.arraycopy(this.KeyboardData, 0, this.keyBytes, 0, 16);
    if (this.keyClash)
      GenerateKeyboardClash(); 
  }
  
  protected void GenerateKeyboardClash() {
    for (int i = 0; i < 9; i++) {
      int Line1 = this.KeyboardData[i];
      if (Line1 != 255) {
        for (int j = 0; j < 9; j++) {
          if (i != j) {
            int Line2 = this.KeyboardData[j];
            if (Line2 != 255 && (
              Line1 | Line2) != 255)
              Line1 &= Line1 ^ Line2 ^ 0xFF; 
          } 
        } 
        this.keyBytes[i] = Line1;
      } 
    } 
  }
  
  public void setSelectedRow(int value) {
    this.row = value;
  }
  
  public int readSelectedRow() {
    if (this.DEBUG && 
      this.keyBytes[this.row] != 255)
      System.out.println("Row: " + this.row + " Data: " + this.keyBytes[this.row]); 
    return this.keyBytes[this.row];
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\Keyboard.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */