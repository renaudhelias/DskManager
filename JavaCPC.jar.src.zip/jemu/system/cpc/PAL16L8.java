package jemu.system.cpc;

import jemu.core.device.Device;

public class PAL16L8 extends Device {
  CPCMemory cpcmemory;
  
  CPC cpc;
  
  int rambank;
  
  public PAL16L8(CPC cpc) {
    super("PAL16L8 Circuit");
    this.cpc = cpc;
  }
  
  public void writePort(int port, int value) {
    if (this.cpcmemory == null)
      this.cpcmemory = (CPCMemory)this.cpc.getMemory(); 
    if ((value & 0x80) != 0 && (value & 0x40) != 0) {
      this.cpcmemory.set4MBSlot(port);
      this.cpcmemory.setMemoryRAMBank(value);
      this.rambank = value;
    } 
  }
  
  public int getRAMBank() {
    return this.rambank;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\PAL16L8.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */