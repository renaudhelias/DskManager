package jemu.system.cpc;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Panel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.JPanel;

public class Palette extends JPanel {
  ColorSelector select;
  
  GifMaker maker;
  
  public JPanel jPanel1;
  
  public JPanel jPanel10;
  
  public JPanel jPanel11;
  
  public JPanel jPanel12;
  
  public JPanel jPanel13;
  
  public JPanel jPanel14;
  
  public JPanel jPanel15;
  
  public JPanel jPanel16;
  
  public JPanel jPanel2;
  
  public JPanel jPanel3;
  
  public JPanel jPanel4;
  
  public JPanel jPanel5;
  
  public JPanel jPanel6;
  
  public JPanel jPanel7;
  
  public JPanel jPanel8;
  
  public JPanel jPanel9;
  
  public Panel panel1;
  
  public Panel panel10;
  
  public Panel panel11;
  
  public Panel panel12;
  
  public Panel panel13;
  
  public Panel panel14;
  
  public Panel panel15;
  
  public Panel panel16;
  
  public Panel panel2;
  
  public Panel panel3;
  
  public Panel panel4;
  
  public Panel panel5;
  
  public Panel panel6;
  
  public Panel panel7;
  
  public Panel panel8;
  
  public Panel panel9;
  
  public Palette(GifMaker maker) {
    initComponents();
    this.maker = maker;
    this.select = new ColorSelector();
  }
  
  private void initComponents() {
    this.jPanel1 = new JPanel();
    this.panel1 = new Panel();
    this.jPanel2 = new JPanel();
    this.panel2 = new Panel();
    this.jPanel3 = new JPanel();
    this.panel3 = new Panel();
    this.jPanel4 = new JPanel();
    this.panel4 = new Panel();
    this.jPanel5 = new JPanel();
    this.panel5 = new Panel();
    this.jPanel6 = new JPanel();
    this.panel6 = new Panel();
    this.jPanel7 = new JPanel();
    this.panel7 = new Panel();
    this.jPanel8 = new JPanel();
    this.panel8 = new Panel();
    this.jPanel9 = new JPanel();
    this.panel9 = new Panel();
    this.jPanel10 = new JPanel();
    this.panel10 = new Panel();
    this.jPanel11 = new JPanel();
    this.panel11 = new Panel();
    this.jPanel12 = new JPanel();
    this.panel12 = new Panel();
    this.jPanel13 = new JPanel();
    this.panel13 = new Panel();
    this.jPanel14 = new JPanel();
    this.panel14 = new Panel();
    this.jPanel15 = new JPanel();
    this.panel15 = new Panel();
    this.jPanel16 = new JPanel();
    this.panel16 = new Panel();
    setMaximumSize(new Dimension(92, 24));
    setMinimumSize(new Dimension(92, 24));
    setPreferredSize(new Dimension(92, 24));
    setLayout(new FlowLayout(0, 0, 0));
    this.jPanel1.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 0, new Color(0, 0, 0)));
    this.jPanel1.setLayout(new BorderLayout());
    this.panel1.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel1MouseClicked(evt);
          }
        });
    GroupLayout panel1Layout = new GroupLayout(this.panel1);
    this.panel1.setLayout(panel1Layout);
    panel1Layout.setHorizontalGroup(panel1Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel1Layout.setVerticalGroup(panel1Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel1.add(this.panel1, "Center");
    add(this.jPanel1);
    this.jPanel2.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
    this.jPanel2.setLayout(new BorderLayout());
    this.panel2.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel2MouseClicked(evt);
          }
        });
    GroupLayout panel2Layout = new GroupLayout(this.panel2);
    this.panel2.setLayout(panel2Layout);
    panel2Layout.setHorizontalGroup(panel2Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel2Layout.setVerticalGroup(panel2Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel2.add(this.panel2, "Center");
    add(this.jPanel2);
    this.jPanel3.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, new Color(0, 0, 0)));
    this.jPanel3.setLayout(new BorderLayout());
    this.panel3.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel3MouseClicked(evt);
          }
        });
    GroupLayout panel3Layout = new GroupLayout(this.panel3);
    this.panel3.setLayout(panel3Layout);
    panel3Layout.setHorizontalGroup(panel3Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel3Layout.setVerticalGroup(panel3Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel3.add(this.panel3, "Center");
    add(this.jPanel3);
    this.jPanel4.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
    this.jPanel4.setLayout(new BorderLayout());
    this.panel4.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel4MouseClicked(evt);
          }
        });
    GroupLayout panel4Layout = new GroupLayout(this.panel4);
    this.panel4.setLayout(panel4Layout);
    panel4Layout.setHorizontalGroup(panel4Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel4Layout.setVerticalGroup(panel4Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel4.add(this.panel4, "Center");
    add(this.jPanel4);
    this.jPanel5.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, new Color(0, 0, 0)));
    this.jPanel5.setLayout(new BorderLayout());
    this.panel5.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel5MouseClicked(evt);
          }
        });
    GroupLayout panel5Layout = new GroupLayout(this.panel5);
    this.panel5.setLayout(panel5Layout);
    panel5Layout.setHorizontalGroup(panel5Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel5Layout.setVerticalGroup(panel5Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel5.add(this.panel5, "Center");
    add(this.jPanel5);
    this.jPanel6.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 0, new Color(0, 0, 0)));
    this.jPanel6.setLayout(new BorderLayout());
    this.panel6.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel6MouseClicked(evt);
          }
        });
    GroupLayout panel6Layout = new GroupLayout(this.panel6);
    this.panel6.setLayout(panel6Layout);
    panel6Layout.setHorizontalGroup(panel6Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel6Layout.setVerticalGroup(panel6Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel6.add(this.panel6, "Center");
    add(this.jPanel6);
    this.jPanel7.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 0, new Color(0, 0, 0)));
    this.jPanel7.setLayout(new BorderLayout());
    this.panel7.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel7MouseClicked(evt);
          }
        });
    GroupLayout panel7Layout = new GroupLayout(this.panel7);
    this.panel7.setLayout(panel7Layout);
    panel7Layout.setHorizontalGroup(panel7Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel7Layout.setVerticalGroup(panel7Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel7.add(this.panel7, "Center");
    add(this.jPanel7);
    this.jPanel8.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
    this.jPanel8.setLayout(new BorderLayout());
    this.panel8.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel8MouseClicked(evt);
          }
        });
    GroupLayout panel8Layout = new GroupLayout(this.panel8);
    this.panel8.setLayout(panel8Layout);
    panel8Layout.setHorizontalGroup(panel8Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel8Layout.setVerticalGroup(panel8Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel8.add(this.panel8, "Center");
    add(this.jPanel8);
    this.jPanel9.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 0, new Color(0, 0, 0)));
    this.jPanel9.setLayout(new BorderLayout());
    this.panel9.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel9MouseClicked(evt);
          }
        });
    GroupLayout panel9Layout = new GroupLayout(this.panel9);
    this.panel9.setLayout(panel9Layout);
    panel9Layout.setHorizontalGroup(panel9Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel9Layout.setVerticalGroup(panel9Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel9.add(this.panel9, "Center");
    add(this.jPanel9);
    this.jPanel10.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 0, new Color(0, 0, 0)));
    this.jPanel10.setLayout(new BorderLayout());
    this.panel10.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel10MouseClicked(evt);
          }
        });
    GroupLayout panel10Layout = new GroupLayout(this.panel10);
    this.panel10.setLayout(panel10Layout);
    panel10Layout.setHorizontalGroup(panel10Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel10Layout.setVerticalGroup(panel10Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel10.add(this.panel10, "Center");
    add(this.jPanel10);
    this.jPanel11.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 0, new Color(0, 0, 0)));
    this.jPanel11.setLayout(new BorderLayout());
    this.panel11.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel11MouseClicked(evt);
          }
        });
    GroupLayout panel11Layout = new GroupLayout(this.panel11);
    this.panel11.setLayout(panel11Layout);
    panel11Layout.setHorizontalGroup(panel11Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel11Layout.setVerticalGroup(panel11Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel11.add(this.panel11, "Center");
    add(this.jPanel11);
    this.jPanel12.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 0, new Color(0, 0, 0)));
    this.jPanel12.setLayout(new BorderLayout());
    this.panel12.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel12MouseClicked(evt);
          }
        });
    GroupLayout panel12Layout = new GroupLayout(this.panel12);
    this.panel12.setLayout(panel12Layout);
    panel12Layout.setHorizontalGroup(panel12Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel12Layout.setVerticalGroup(panel12Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel12.add(this.panel12, "Center");
    add(this.jPanel12);
    this.jPanel13.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 0, new Color(0, 0, 0)));
    this.jPanel13.setLayout(new BorderLayout());
    this.panel13.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel13MouseClicked(evt);
          }
        });
    GroupLayout panel13Layout = new GroupLayout(this.panel13);
    this.panel13.setLayout(panel13Layout);
    panel13Layout.setHorizontalGroup(panel13Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel13Layout.setVerticalGroup(panel13Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel13.add(this.panel13, "Center");
    add(this.jPanel13);
    this.jPanel14.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 0, new Color(0, 0, 0)));
    this.jPanel14.setLayout(new BorderLayout());
    this.panel14.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel14MouseClicked(evt);
          }
        });
    GroupLayout panel14Layout = new GroupLayout(this.panel14);
    this.panel14.setLayout(panel14Layout);
    panel14Layout.setHorizontalGroup(panel14Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel14Layout.setVerticalGroup(panel14Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel14.add(this.panel14, "Center");
    add(this.jPanel14);
    this.jPanel15.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 0, new Color(0, 0, 0)));
    this.jPanel15.setLayout(new BorderLayout());
    this.panel15.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel15MouseClicked(evt);
          }
        });
    GroupLayout panel15Layout = new GroupLayout(this.panel15);
    this.panel15.setLayout(panel15Layout);
    panel15Layout.setHorizontalGroup(panel15Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel15Layout.setVerticalGroup(panel15Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel15.add(this.panel15, "Center");
    add(this.jPanel15);
    this.jPanel16.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 1, new Color(0, 0, 0)));
    this.jPanel16.setLayout(new BorderLayout());
    this.panel16.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Palette.this.panel16MouseClicked(evt);
          }
        });
    GroupLayout panel16Layout = new GroupLayout(this.panel16);
    this.panel16.setLayout(panel16Layout);
    panel16Layout.setHorizontalGroup(panel16Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    panel16Layout.setVerticalGroup(panel16Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 10, 32767));
    this.jPanel16.add(this.panel16, "Center");
    add(this.jPanel16);
  }
  
  public void setInk(int pen) {
    this.select.setVisible(true);
    this.select.PEN(pen, GateArray.getInk(pen));
  }
  
  private void panel1MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(0); 
    this.maker.tpen = 0;
    this.maker.toggleTrans();
  }
  
  private void panel2MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(1); 
    this.maker.tpen = 1;
    this.maker.toggleTrans();
  }
  
  private void panel3MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(2); 
    this.maker.tpen = 2;
    this.maker.toggleTrans();
  }
  
  private void panel4MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(3); 
    this.maker.tpen = 3;
    this.maker.toggleTrans();
  }
  
  private void panel5MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(4); 
    this.maker.tpen = 4;
    this.maker.toggleTrans();
  }
  
  private void panel6MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(5); 
    this.maker.tpen = 5;
    this.maker.toggleTrans();
  }
  
  private void panel7MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(6); 
    this.maker.tpen = 6;
    this.maker.toggleTrans();
  }
  
  private void panel8MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(7); 
    this.maker.tpen = 7;
    this.maker.toggleTrans();
  }
  
  private void panel9MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(8); 
    this.maker.tpen = 8;
    this.maker.toggleTrans();
  }
  
  private void panel10MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(9); 
    this.maker.tpen = 9;
    this.maker.toggleTrans();
  }
  
  private void panel11MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(10); 
    this.maker.tpen = 10;
    this.maker.toggleTrans();
  }
  
  private void panel12MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(11); 
    this.maker.tpen = 11;
    this.maker.toggleTrans();
  }
  
  private void panel13MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(12); 
    this.maker.tpen = 12;
    this.maker.toggleTrans();
  }
  
  private void panel14MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(13); 
    this.maker.tpen = 13;
    this.maker.toggleTrans();
  }
  
  private void panel15MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(14); 
    this.maker.tpen = 14;
    this.maker.toggleTrans();
  }
  
  private void panel16MouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setInk(15); 
    this.maker.tpen = 15;
    this.maker.toggleTrans();
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\Palette.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */