package jemu.system.cpc;

import JCPC.core.device.Device;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import jemu.core.device.Computer;
import jemu.core.device.floppy.DiscImage;
import jemu.ui.cpcgamescd.CPCFileSystem;

public class MagicCPCDiscImage extends DiscImage {
  CPCFileSystem system;
  
  String path;
  
  int[][][][] ids;
  
  byte[][][][] sectors;
  
  int lastCylinder = 79;
  
  int headMask = 1;
  
  public static final int SECTS = 9;
  
  public static final int CYLS = 40;
  
  public static final int HEADS = 1;
  
  HashMap<String, File> dirContent;
  
  List<String> dirContentKeys;
  
  boolean isData;
  
  boolean isBank;
  
  List<String> scanNames;
  
  List<Byte> buffer;
  
  int cursorWrite;
  
  Integer cylinderBank;
  
  Integer headBank;
  
  Integer indexBank;
  
  public byte[] getImage() {
    return null;
  }
  
  public void saveImage(File file) {}
  
  public void writeSector(int a, int b, int c, int d, int e, int f, byte[] g) {}
  
  public void addSectorToTrack(int a, int b, int c, int d, int e, int f, int g) {}
  
  public int getGap(int track) {
    return 0;
  }
  
  public int getNoOfTracks() {
    return this.lastCylinder;
  }
  
  public void removeAllSectorsFromTrack(int a, int b) {}
  
  public void setST1ForSector(int a, int b, int c, int d, int e, int f, int g) {}
  
  public void setST2ForSector(int a, int b, int c, int d, int e, int f, int g) {}
  
  public int getST1ForSector(int a, int b, int c, int d, int e, int f) {
    return 0;
  }
  
  public int getST2ForSector(int a, int b, int c, int d, int e, int f) {
    return 0;
  }
  
  public class BadScanNameMomentException extends Exception {}
  
  public class MagicCPCDiscImageException extends Exception {
    public static final String FILE_STRUCTDIR_TOO_BIG = "FILE_STRUCTDIR_TOO_BIG";
    
    public MagicCPCDiscImageException(String message) {
      super(message);
    }
  }
  
  public MagicCPCDiscImage(String dir) {
    super("MagicCPCDiscImage");
    this.dirContent = new HashMap<>();
    this.dirContentKeys = new ArrayList<>();
    this.isData = false;
    this.isBank = true;
    this.scanNames = new ArrayList<>();
    this.buffer = new ArrayList<>();
    this.cursorWrite = 0;
    this.cylinderBank = null;
    this.headBank = null;
    this.indexBank = null;
    this.system = new CPCFileSystem();
    init(dir);
  }
  
  public void init(String path) {
    this.path = path;
    createSectorStructure();
    listDir();
  }
  
  private void createSectorStructure() {
    this.ids = new int[2][80][0][];
    this.sectors = new byte[2][80][][];
    for (int cyl = 0; cyl < 40; cyl++) {
      for (int head = 0; head < 1; head++) {
        this.ids[head][cyl] = new int[9][4];
        this.sectors[head][cyl] = new byte[9][];
        for (int sect = 0; sect < 9; sect++) {
          int[] sectId = this.ids[head][cyl][sect];
          sectId[0] = cyl;
          sectId[1] = 0;
          sectId[2] = 193 + sect;
          sectId[3] = 2;
          int size = sectorSize(sectId[3]);
          byte[] sectData = this.sectors[head][cyl][sect] = new byte[size];
          for (int i = 0; i < size; i++)
            sectData[i] = -27; 
        } 
      } 
    } 
  }
  
  private void resetSectorContent() {
    byte[] empty = new byte[512];
    for (int j = 0; j < 512; j++)
      empty[j] = -27; 
    System.arraycopy(empty, 0, this.sectors[0][0][0], 0, 512);
    System.arraycopy(empty, 0, this.sectors[0][0][1], 0, 512);
    System.arraycopy(empty, 0, this.sectors[0][0][2], 0, 512);
    System.arraycopy(empty, 0, this.sectors[0][0][3], 0, 512);
  }
  
  public void copyAsDSK() {
    this.system.get(this.path + "/MAGIC_OUTPUT.DSK");
    try {
      File folder = new File(this.path);
      if (folder.isDirectory())
        for (File sf : folder.listFiles()) {
          if (!sf.isDirectory() && sf.length() <= 65535L && sf.length() >= 1L) {
            String cpcname = sf.getName().toUpperCase();
            String realname = sf.getName().toUpperCase();
            if (cpcname.contains(".")) {
              int point = cpcname.indexOf(".");
              String filename = cpcname.substring(0, point);
              filename = filename + "        ";
              filename = filename.substring(0, 8);
              String extension = cpcname.substring(point + 1, cpcname.length());
              extension = extension + "   ";
              extension = extension.substring(0, 3);
              cpcname = filename + extension;
            } else {
              cpcname = cpcname + "           ";
              cpcname = cpcname.substring(0, 11);
            } 
            this.system.DIR();
            this.system.copyToDSK(this.path + "/", realname, this.path + "/MAGIC_OUTPUT.DSK");
          } 
        }  
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  private void listDir() {
    this.dirContent.clear();
    this.dirContentKeys.clear();
    int ii = 0;
    int noSect = 0;
    try {
      File folder = new File(this.path);
      if (folder.isDirectory())
        for (File sf : folder.listFiles()) {
          if (!sf.isDirectory() && sf.length() <= 131199L && sf.length() >= 1L) {
            String cpcname = sf.getName().toUpperCase();
            String realname = sf.getName().toUpperCase();
            if (cpcname.contains(".")) {
              int point = cpcname.indexOf(".");
              String filename = cpcname.substring(0, point);
              filename = filename + "        ";
              filename = filename.substring(0, 8);
              String extension = cpcname.substring(point + 1, cpcname.length());
              extension = extension + "   ";
              extension = extension.substring(0, 3);
              cpcname = filename + extension;
            } else {
              cpcname = cpcname + "           ";
              cpcname = cpcname.substring(0, 11);
            } 
            File fSuperAmstradName = new File(this.path + "/" + realname);
            this.dirContent.put(cpcname, fSuperAmstradName);
            this.dirContentKeys.add(cpcname);
          } 
        }  
      resetSectorContent();
      byte[] line = new byte[32];
      for (int j = 0; j < 32; j++)
        line[j] = 0; 
      byte[] empty = new byte[512];
      for (int k = 0; k < 512; k++)
        empty[k] = -27; 
      int i = 0;
      byte writeNoSect = 2;
      int writeH = 0;
      int writeC = 0;
      int writeR = 4;
      boolean teaForTwo = false;
      for (String name : this.dirContentKeys) {
        noSect = i / 16;
        if (noSect >= 4) {
          System.out.println("FILE_STRUCTDIR_TOO_BIG");
          break;
        } 
        ii = i % 16;
        byte[] sectData = this.sectors[0][0][noSect];
        File f = this.dirContent.get(name);
        long fileLength = f.length();
        System.out.println("DIR : " + name);
        try {
          byte[] selectedFileContent = new byte[512];
          FileInputStream fis = new FileInputStream(f);
          while (fis.read(selectedFileContent) > 0) {
            System.arraycopy(selectedFileContent, 0, this.sectors[writeH][writeC][writeR], 0, 512);
            teaForTwo = !teaForTwo;
            writeR++;
            if (writeR >= 9) {
              writeR = 0;
              writeC++;
              if (writeC >= 40)
                break; 
            } 
            System.arraycopy(empty, 0, selectedFileContent, 0, 512);
          } 
          if (teaForTwo) {
            teaForTwo = !teaForTwo;
            writeR++;
            if (writeR >= 9) {
              writeR = 0;
              writeC++;
              if (writeC >= 40)
                break; 
            } 
          } 
          fis.close();
        } catch (Exception e) {
          break;
        } 
        long m = fileLength / 16384L;
        long mm = fileLength % 16384L;
        if (mm > 0L)
          m++; 
        for (int n = 0; n < m; n++) {
          noSect = (i + n) / 16;
          if (noSect >= 4) {
            System.out.println("FILE_STRUCTDIR_TOO_BIG");
            break;
          } 
          ii = (i + n) % 16;
          sectData = this.sectors[0][0][noSect];
          System.arraycopy(line, 0, sectData, ii * 32, 32);
          System.arraycopy(name.getBytes(), 0, sectData, ii * 32 + 1, 11);
          if (n == m - 1L && mm > 0L) {
            long mmm = mm / 128L;
            long mmmm = mm % 128L;
            if (mmmm > 0L)
              mmm++; 
            sectData[ii * 32 + 1 + 8 + 3 + 3] = (byte)(int)mmm;
            long nnn = mm / 1024L;
            long nnnn = mm % 1024L;
            if (nnnn > 0L)
              nnn++; 
            for (int i1 = 0; i1 < nnn; i1++) {
              sectData[ii * 32 + 16 + i1] = writeNoSect;
              writeNoSect = (byte)(writeNoSect + 1);
            } 
          } else {
            sectData[ii * 32 + 1 + 8 + 3 + 3] = Byte.MIN_VALUE;
            for (int i1 = 16; i1 < 32; i1++) {
              sectData[ii * 32 + i1] = writeNoSect;
              writeNoSect = (byte)(writeNoSect + 1);
            } 
          } 
          sectData[ii * 32 + 1 + 8 + 3] = (byte)n;
        } 
        i = (int)(i + m);
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
    this.scanNames = doScanAllNamesFromSectors();
  }
  
  protected static int sectorSize(int n) {
    return (n > 5) ? 6144 : (128 << n);
  }
  
  protected int getSectorIndex(int[][] ids, int c, int h, int r, int n) {
    for (int i = 0; i < ids.length; i++) {
      int[] id = ids[i];
      if (id[0] == c && id[1] == h && id[2] == r && id[3] == n)
        return i; 
    } 
    return -1;
  }
  
  public byte[] readSector(int cylinder, int head, int c, int h, int r, int n) {
    head &= this.headMask;
    byte[] result = null;
    if (cylinder <= this.lastCylinder) {
      int index = getSectorIndex(this.ids[head][cylinder], c, h, r, n);
      if (index != -1)
        result = this.sectors[head][cylinder][index]; 
    } 
    return result;
  }
  
  public int[] getSectorID(int cylinder, int head, int index) {
    return this.ids[head & this.headMask][cylinder][index];
  }
  
  public int getSectorCount(int cylinder, int head) {
    return (cylinder > this.lastCylinder) ? 0 : (this.ids[head & this.headMask][cylinder]).length;
  }
  
  public void notifyWriteSector(byte data, int cylinder, int head, int c, int h, int r, int n) {
    head &= this.headMask;
    if (cylinder <= this.lastCylinder) {
      int index = getSectorIndex(this.ids[head][cylinder], c, h, r, n);
      if (index != -1)
        if (head == 0 && cylinder == 0 && index < 4) {
          if (this.isData) {
            this.cursorWrite = 0;
            this.isData = false;
          } 
          if (this.cursorWrite == 511)
            doScanNames(true, head, cylinder, index); 
        } else {
          if (!this.isData) {
            this.cursorWrite = 0;
            this.isData = true;
          } 
          if (this.cursorWrite == 0)
            if (this.cylinderBank == null) {
              this.cylinderBank = Integer.valueOf(cylinder);
              this.headBank = Integer.valueOf(head);
              this.indexBank = Integer.valueOf(index);
              this.isBank = true;
            } else if (this.cylinderBank.intValue() == cylinder && this.headBank.intValue() == head && this.indexBank.intValue() == index) {
              this.isBank = false;
            }  
          if (this.isBank) {
            this.buffer.add(Byte.valueOf(data));
          } else if (this.buffer.size() > 0) {
            this.buffer.add(this.cursorWrite, Byte.valueOf(data));
            if (this.cursorWrite == 511)
              for (int i = 0; i < 512; i++)
                this.buffer.remove(512);  
            this.cylinderBank = null;
          } else {
            this.cylinderBank = null;
          } 
        }  
    } 
    this.cursorWrite++;
    if (this.cursorWrite == 512)
      this.cursorWrite = 0; 
  }
  
  private List<String> doScanAllNamesFromSectors() {
    List<String> flatScanNames = new ArrayList<>();
    for (int index = 0; index < 4; index++) {
      byte[] result = this.sectors[0][0][index];
      for (int i = 0; i < result.length / 32; i++) {
        byte[] filename = new byte[11];
        System.arraycopy(result, i * 32 + 1, filename, 0, 11);
        if (result[i * 32] != -27 && filename[10] != -27 && filename[10] != 36) {
          String s = "";
          for (int j = 0; j < 11; j++)
            s = s + (char)filename[j]; 
          flatScanNames.add(s);
        } 
      } 
    } 
    return flatScanNames;
  }
  
  private void doScanNames(boolean isWrite, int head, int cylinder, int index) {
    List<String> newScanNames = doScanAllNamesFromSectors();
    try {
      String filename = checkNewFile(this.scanNames, newScanNames);
      if (filename != null) {
        String first = filename;
        String ext = filename;
        while (first.length() > 8)
          first = first.substring(0, first.length() - 1); 
        while (ext.length() > 3)
          ext = ext.substring(1); 
        first = first.replace(" ", "");
        ext = ext.replace(" ", "");
        filename = first + "." + ext;
        System.out.println("FILE ADDED (isWrite=" + isWrite + ") : " + filename);
        File f = new File(this.path + "/" + filename);
        try {
          byte[] buff = new byte[512];
          FileOutputStream fos = new FileOutputStream(f, true);
          for (int b = 0; b < this.buffer.size(); b++) {
            buff[b % 512] = ((Byte)this.buffer.get(b)).byteValue();
            if (b % 512 == 511) {
              fos.write(buff);
              CPC.protect = true;
            } else if (b == this.buffer.size() - 1) {
              fos.write(buff, 0, b % 512 + 1);
              CPC.protect = true;
            } 
          } 
          fos.flush();
          fos.close();
          this.buffer.clear();
          checkFile(f);
        } catch (Exception e) {
          e.printStackTrace();
        } 
      } 
      this.scanNames = newScanNames;
      return;
    } catch (BadScanNameMomentException e) {
      System.out.println("Something but a new file by here");
      try {
        List<String> filenames = checkRenameFile(this.scanNames, newScanNames);
        if (filenames != null) {
          System.out.println("Renaming file " + (String)filenames.get(0) + " into " + (String)filenames.get(1));
          File f = new File(this.path + "/" + (String)filenames.get(0));
          File f2 = new File(this.path + "/" + (String)filenames.get(1));
          f.renameTo(f2);
          CPC.protect = true;
        } 
        this.scanNames = newScanNames;
        return;
      } catch (BadScanNameMomentException badScanNameMomentException) {
        System.out.println("Something but a new file/a rename file by here");
        try {
          String filename = checkEraseFile(this.scanNames, newScanNames);
          if (filename != null) {
            System.out.println("Erasing file " + filename);
            File f = new File(this.path + "/" + filename);
            f.delete();
            String first = filename;
            String ext = filename;
            while (first.length() > 8)
              first = first.substring(0, first.length() - 1); 
            while (ext.length() > 3)
              ext = ext.substring(1); 
            first = first.replace(" ", "");
            ext = ext.replace(" ", "");
            filename = first + "." + ext;
            f = new File(this.path + "/" + filename);
            if (f.exists())
              f.delete(); 
            CPC.protect = true;
          } 
          this.scanNames = newScanNames;
          return;
        } catch (BadScanNameMomentException badScanNameMomentException1) {
          System.out.println("Something but a new file/a rename file/an erase file by here : DIRStruct is not yet aligned, do just continue.");
          return;
        } 
      } 
    } 
  }
  
  protected void checkFile(File f) {
    try {
      int k = (int)f.length();
      byte[] buffer = new byte[k];
      BufferedInputStream bin = new BufferedInputStream(new FileInputStream(f));
      bin.read(buffer);
      bin.close();
      if (Computer.CheckAMSDOS(buffer)) {
        int size = Device.getWord(buffer, 24) + 128;
        byte[] result = new byte[size];
        System.arraycopy(buffer, 0, result, 0, size);
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(f));
        bos.write(result);
        bos.close();
      } 
    } catch (Exception exception) {}
  }
  
  private String checkEraseFile(List<String> scanNames, List<String> newScanNames) throws BadScanNameMomentException {
    HashMap<String, Integer> fileEntryCounts = new HashMap<>();
    for (String name : scanNames) {
      if (fileEntryCounts.containsKey(name)) {
        int n = ((Integer)fileEntryCounts.get(name)).intValue() - 1;
        fileEntryCounts.put(name, Integer.valueOf(n));
        continue;
      } 
      fileEntryCounts.put(name, Integer.valueOf(-1));
    } 
    for (String name : newScanNames) {
      if (fileEntryCounts.containsKey(name)) {
        int n = ((Integer)fileEntryCounts.get(name)).intValue() + 1;
        fileEntryCounts.put(name, Integer.valueOf(n));
        continue;
      } 
      fileEntryCounts.put(name, Integer.valueOf(1));
    } 
    String candidate = null;
    boolean candidateHasProblem = false;
    for (String name : fileEntryCounts.keySet()) {
      if (((Integer)fileEntryCounts.get(name)).intValue() < 0) {
        if (!candidateHasProblem) {
          candidate = name;
          candidateHasProblem = true;
          continue;
        } 
        throw new BadScanNameMomentException();
      } 
      if (((Integer)fileEntryCounts.get(name)).intValue() > 0)
        throw new BadScanNameMomentException(); 
    } 
    return candidate;
  }
  
  private List<String> checkRenameFile(List<String> scanNames, List<String> newScanNames) throws BadScanNameMomentException {
    HashMap<String, Integer> fileEntryCounts = new HashMap<>();
    for (String name : scanNames) {
      if (fileEntryCounts.containsKey(name)) {
        int n = ((Integer)fileEntryCounts.get(name)).intValue() - 1;
        fileEntryCounts.put(name, Integer.valueOf(n));
        continue;
      } 
      fileEntryCounts.put(name, Integer.valueOf(-1));
    } 
    for (String name : newScanNames) {
      if (fileEntryCounts.containsKey(name)) {
        int n = ((Integer)fileEntryCounts.get(name)).intValue() + 1;
        fileEntryCounts.put(name, Integer.valueOf(n));
        continue;
      } 
      fileEntryCounts.put(name, Integer.valueOf(1));
    } 
    String candidateFrom = null;
    String candidateTo = null;
    boolean candidateFromHasProblem = false;
    boolean candidateToHasProblem = false;
    for (String name : fileEntryCounts.keySet()) {
      if (((Integer)fileEntryCounts.get(name)).intValue() > 0) {
        if (!candidateToHasProblem) {
          candidateTo = name;
          candidateToHasProblem = true;
          continue;
        } 
        throw new BadScanNameMomentException();
      } 
      if (((Integer)fileEntryCounts.get(name)).intValue() < 0) {
        if (!candidateFromHasProblem) {
          candidateFrom = name;
          candidateFromHasProblem = true;
          continue;
        } 
        throw new BadScanNameMomentException();
      } 
    } 
    if (candidateFromHasProblem != candidateToHasProblem)
      throw new BadScanNameMomentException(); 
    if (candidateFrom == null && candidateTo == null)
      return null; 
    List<String> candidates = new ArrayList<>();
    candidates.add(candidateFrom);
    candidates.add(candidateTo);
    return candidates;
  }
  
  private String checkNewFile(List<String> scanNames, List<String> newScanNames) throws BadScanNameMomentException {
    HashMap<String, Integer> fileEntryCounts = new HashMap<>();
    for (String name : scanNames) {
      if (fileEntryCounts.containsKey(name)) {
        int n = ((Integer)fileEntryCounts.get(name)).intValue() - 1;
        fileEntryCounts.put(name, Integer.valueOf(n));
        continue;
      } 
      fileEntryCounts.put(name, Integer.valueOf(-1));
    } 
    for (String name : newScanNames) {
      if (fileEntryCounts.containsKey(name)) {
        int n = ((Integer)fileEntryCounts.get(name)).intValue() + 1;
        fileEntryCounts.put(name, Integer.valueOf(n));
        continue;
      } 
      fileEntryCounts.put(name, Integer.valueOf(1));
    } 
    String candidate = null;
    boolean candidateHasProblem = false;
    for (String name : fileEntryCounts.keySet()) {
      if (((Integer)fileEntryCounts.get(name)).intValue() > 0) {
        if (!candidateHasProblem) {
          candidate = name;
          candidateHasProblem = true;
          continue;
        } 
        throw new BadScanNameMomentException();
      } 
      if (((Integer)fileEntryCounts.get(name)).intValue() < 0)
        throw new BadScanNameMomentException(); 
    } 
    return candidate;
  }
  
  public void notifyReadSector(boolean beginOfSector, int cylinder, int head, int c, int h, int r, int n) {
    head &= this.headMask;
    if (cylinder <= this.lastCylinder) {
      int index = getSectorIndex(this.ids[head][cylinder], c, h, r, n);
      if (index != -1 && 
        head == 0 && cylinder == 0 && beginOfSector && index < 4)
        doScanNames(true, head, cylinder, index); 
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\MagicCPCDiscImage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */