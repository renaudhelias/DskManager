package jemu.system.cpc;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import org.netbeans.lib.awtextra.AbsoluteConstraints;
import org.netbeans.lib.awtextra.AbsoluteLayout;

public class FormatPanel extends JPanel {
  protected boolean DEBUG = false;
  
  protected String[] DSKImages;
  
  protected String selected;
  
  protected int index;
  
  public int seldrive;
  
  private ButtonGroup buttonGroup1;
  
  public JComboBox drivesel;
  
  private JLabel dsk;
  
  private JButton jButton1;
  
  private JButton jButton2;
  
  private JLabel jLabel1;
  
  private JPanel jPanel1;
  
  private JPanel jPanel2;
  
  private JPanel jPanel3;
  
  private JPanel jPanel4;
  
  private JRadioButton jRadioButton1;
  
  private JRadioButton jRadioButton10;
  
  private JRadioButton jRadioButton11;
  
  private JRadioButton jRadioButton12;
  
  private JRadioButton jRadioButton13;
  
  private JRadioButton jRadioButton14;
  
  private JRadioButton jRadioButton15;
  
  private JRadioButton jRadioButton16;
  
  private JRadioButton jRadioButton17;
  
  private JRadioButton jRadioButton18;
  
  private JRadioButton jRadioButton19;
  
  private JRadioButton jRadioButton2;
  
  private JRadioButton jRadioButton20;
  
  private JRadioButton jRadioButton21;
  
  private JRadioButton jRadioButton22;
  
  private JRadioButton jRadioButton23;
  
  private JRadioButton jRadioButton3;
  
  private JRadioButton jRadioButton4;
  
  private JRadioButton jRadioButton5;
  
  private JRadioButton jRadioButton6;
  
  private JRadioButton jRadioButton7;
  
  private JRadioButton jRadioButton8;
  
  private JRadioButton jRadioButton9;
  
  private JLabel selform;
  
  public FormatPanel() {
    this.index = 9;
    this.seldrive = 0;
    this.DSKImages = new String[] { 
        "parados80.dsk", "parados41.dsk", "parados40D.dsk", "romdosD1.dsk", "romdosD2.dsk", "romdosD10.dsk", "romdosD20.dsk", "romdosD40.dsk", "s-dos(romdosD80).dsk", "dataSS40.dsk", 
        "dataDS40.dsk", "dataSS80.dsk", "dataDS80.dsk", "systemSS40.dsk", "systemDS40.dsk", "systemSS80.dsk", "systemDS80.dsk", "ibmSS40.dsk", "ibmDS40.dsk", "ibmSS80.dsk", 
        "ibmDS80.dsk", "ultraform.dsk", "vortex704k.dsk" };
    this.selected = "Selected Format: ";
    initComponents();
    this.dsk.setVisible(this.DEBUG);
    this.drivesel.setSelectedIndex(this.seldrive);
  }
  
  private void initComponents() {
    this.buttonGroup1 = new ButtonGroup();
    this.jPanel1 = new JPanel();
    this.jPanel2 = new JPanel();
    this.jRadioButton2 = new JRadioButton();
    this.jRadioButton8 = new JRadioButton();
    this.jRadioButton9 = new JRadioButton();
    this.jPanel3 = new JPanel();
    this.jRadioButton1 = new JRadioButton();
    this.jRadioButton12 = new JRadioButton();
    this.jRadioButton11 = new JRadioButton();
    this.jRadioButton6 = new JRadioButton();
    this.jRadioButton7 = new JRadioButton();
    this.jRadioButton3 = new JRadioButton();
    this.jPanel4 = new JPanel();
    this.jRadioButton4 = new JRadioButton();
    this.jRadioButton5 = new JRadioButton();
    this.jRadioButton20 = new JRadioButton();
    this.jRadioButton21 = new JRadioButton();
    this.jRadioButton22 = new JRadioButton();
    this.jRadioButton10 = new JRadioButton();
    this.jRadioButton13 = new JRadioButton();
    this.jRadioButton14 = new JRadioButton();
    this.jRadioButton15 = new JRadioButton();
    this.jRadioButton16 = new JRadioButton();
    this.jRadioButton17 = new JRadioButton();
    this.jRadioButton18 = new JRadioButton();
    this.jRadioButton19 = new JRadioButton();
    this.jRadioButton23 = new JRadioButton();
    this.jButton1 = new JButton();
    this.jButton2 = new JButton();
    this.selform = new JLabel();
    this.dsk = new JLabel();
    this.drivesel = new JComboBox();
    this.jLabel1 = new JLabel();
    this.jPanel1.setBorder(BorderFactory.createTitledBorder("Select Format"));
    this.jPanel1.setPreferredSize(new Dimension(440, 300));
    this.jPanel1.setLayout((LayoutManager)new AbsoluteLayout());
    this.jPanel2.setBorder(BorderFactory.createTitledBorder("PARADOS"));
    this.jPanel2.setLayout((LayoutManager)new AbsoluteLayout());
    this.buttonGroup1.add(this.jRadioButton2);
    this.jRadioButton2.setText("PARADOS 80");
    this.jRadioButton2.setFocusPainted(false);
    this.jRadioButton2.setFocusable(false);
    this.jRadioButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton2ActionPerformed(evt);
          }
        });
    this.jPanel2.add(this.jRadioButton2, new AbsoluteConstraints(20, 30, -1, -1));
    this.buttonGroup1.add(this.jRadioButton8);
    this.jRadioButton8.setText("PARADOS 41");
    this.jRadioButton8.setFocusPainted(false);
    this.jRadioButton8.setFocusable(false);
    this.jRadioButton8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton8ActionPerformed(evt);
          }
        });
    this.jPanel2.add(this.jRadioButton8, new AbsoluteConstraints(160, 30, -1, -1));
    this.buttonGroup1.add(this.jRadioButton9);
    this.jRadioButton9.setText("PARADOS D40");
    this.jRadioButton9.setFocusPainted(false);
    this.jRadioButton9.setFocusable(false);
    this.jRadioButton9.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton9ActionPerformed(evt);
          }
        });
    this.jPanel2.add(this.jRadioButton9, new AbsoluteConstraints(300, 30, -1, -1));
    this.jPanel1.add(this.jPanel2, new AbsoluteConstraints(20, 30, 430, 60));
    this.jPanel3.setBorder(BorderFactory.createTitledBorder("ROMDOS"));
    this.jPanel3.setLayout((LayoutManager)new AbsoluteLayout());
    this.buttonGroup1.add(this.jRadioButton1);
    this.jRadioButton1.setText("ROMDOS D1");
    this.jRadioButton1.setFocusPainted(false);
    this.jRadioButton1.setFocusable(false);
    this.jRadioButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton1ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.jRadioButton1, new AbsoluteConstraints(20, 30, -1, -1));
    this.buttonGroup1.add(this.jRadioButton12);
    this.jRadioButton12.setText("ROMDOS D10");
    this.jRadioButton12.setFocusPainted(false);
    this.jRadioButton12.setFocusable(false);
    this.jRadioButton12.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton12ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.jRadioButton12, new AbsoluteConstraints(20, 60, -1, -1));
    this.buttonGroup1.add(this.jRadioButton11);
    this.jRadioButton11.setText("S-DOS (RDOS D80)");
    this.jRadioButton11.setFocusPainted(false);
    this.jRadioButton11.setFocusable(false);
    this.jRadioButton11.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton11ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.jRadioButton11, new AbsoluteConstraints(270, 30, -1, -1));
    this.buttonGroup1.add(this.jRadioButton6);
    this.jRadioButton6.setText("ROMDOS D40");
    this.jRadioButton6.setFocusPainted(false);
    this.jRadioButton6.setFocusable(false);
    this.jRadioButton6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton6ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.jRadioButton6, new AbsoluteConstraints(270, 60, -1, -1));
    this.buttonGroup1.add(this.jRadioButton7);
    this.jRadioButton7.setText("ROMDOS D2");
    this.jRadioButton7.setFocusPainted(false);
    this.jRadioButton7.setFocusable(false);
    this.jRadioButton7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton7ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.jRadioButton7, new AbsoluteConstraints(150, 30, -1, -1));
    this.buttonGroup1.add(this.jRadioButton3);
    this.jRadioButton3.setText("ROMDOS D20");
    this.jRadioButton3.setFocusPainted(false);
    this.jRadioButton3.setFocusable(false);
    this.jRadioButton3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton3ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.jRadioButton3, new AbsoluteConstraints(150, 60, -1, -1));
    this.jPanel1.add(this.jPanel3, new AbsoluteConstraints(20, 90, 430, 90));
    this.jPanel4.setBorder(BorderFactory.createTitledBorder("OTHER"));
    this.jPanel4.setLayout((LayoutManager)new AbsoluteLayout());
    this.buttonGroup1.add(this.jRadioButton4);
    this.jRadioButton4.setSelected(true);
    this.jRadioButton4.setText("DATA (SS 40)");
    this.jRadioButton4.setFocusPainted(false);
    this.jRadioButton4.setFocusable(false);
    this.jRadioButton4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton4ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jRadioButton4, new AbsoluteConstraints(20, 30, -1, -1));
    this.buttonGroup1.add(this.jRadioButton5);
    this.jRadioButton5.setText("DATA (DS 40)");
    this.jRadioButton5.setFocusPainted(false);
    this.jRadioButton5.setFocusable(false);
    this.jRadioButton5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton5ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jRadioButton5, new AbsoluteConstraints(150, 30, -1, -1));
    this.buttonGroup1.add(this.jRadioButton20);
    this.jRadioButton20.setText("ULTRAFORM");
    this.jRadioButton20.setFocusPainted(false);
    this.jRadioButton20.setFocusable(false);
    this.jRadioButton20.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton20ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jRadioButton20, new AbsoluteConstraints(300, 180, -1, -1));
    this.buttonGroup1.add(this.jRadioButton21);
    this.jRadioButton21.setText("IBM (SS 80)");
    this.jRadioButton21.setFocusPainted(false);
    this.jRadioButton21.setFocusable(false);
    this.jRadioButton21.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton21ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jRadioButton21, new AbsoluteConstraints(20, 180, -1, -1));
    this.buttonGroup1.add(this.jRadioButton22);
    this.jRadioButton22.setText("IBM (DS 40)");
    this.jRadioButton22.setFocusPainted(false);
    this.jRadioButton22.setFocusable(false);
    this.jRadioButton22.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton22ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jRadioButton22, new AbsoluteConstraints(150, 150, -1, -1));
    this.buttonGroup1.add(this.jRadioButton10);
    this.jRadioButton10.setText("DATA (SS 80)");
    this.jRadioButton10.setFocusPainted(false);
    this.jRadioButton10.setFocusable(false);
    this.jRadioButton10.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton10ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jRadioButton10, new AbsoluteConstraints(20, 60, -1, -1));
    this.buttonGroup1.add(this.jRadioButton13);
    this.jRadioButton13.setText("DATA (DS 80)");
    this.jRadioButton13.setFocusPainted(false);
    this.jRadioButton13.setFocusable(false);
    this.jRadioButton13.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton13ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jRadioButton13, new AbsoluteConstraints(150, 60, -1, -1));
    this.buttonGroup1.add(this.jRadioButton14);
    this.jRadioButton14.setText("SYSTEM (SS 40)");
    this.jRadioButton14.setFocusPainted(false);
    this.jRadioButton14.setFocusable(false);
    this.jRadioButton14.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton14ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jRadioButton14, new AbsoluteConstraints(20, 90, -1, -1));
    this.buttonGroup1.add(this.jRadioButton15);
    this.jRadioButton15.setText("SYSTEM (DS 40)");
    this.jRadioButton15.setFocusPainted(false);
    this.jRadioButton15.setFocusable(false);
    this.jRadioButton15.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton15ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jRadioButton15, new AbsoluteConstraints(150, 90, -1, -1));
    this.buttonGroup1.add(this.jRadioButton16);
    this.jRadioButton16.setText("SYSTEM (SS 80)");
    this.jRadioButton16.setFocusPainted(false);
    this.jRadioButton16.setFocusable(false);
    this.jRadioButton16.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton16ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jRadioButton16, new AbsoluteConstraints(20, 120, -1, -1));
    this.buttonGroup1.add(this.jRadioButton17);
    this.jRadioButton17.setText("IBM (SS 40)");
    this.jRadioButton17.setFocusPainted(false);
    this.jRadioButton17.setFocusable(false);
    this.jRadioButton17.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton17ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jRadioButton17, new AbsoluteConstraints(20, 150, -1, -1));
    this.buttonGroup1.add(this.jRadioButton18);
    this.jRadioButton18.setText("SYSTEM (DS 80)");
    this.jRadioButton18.setFocusPainted(false);
    this.jRadioButton18.setFocusable(false);
    this.jRadioButton18.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton18ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jRadioButton18, new AbsoluteConstraints(150, 120, -1, -1));
    this.buttonGroup1.add(this.jRadioButton19);
    this.jRadioButton19.setText("IBM (DS 80)");
    this.jRadioButton19.setFocusPainted(false);
    this.jRadioButton19.setFocusable(false);
    this.jRadioButton19.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton19ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jRadioButton19, new AbsoluteConstraints(150, 180, -1, -1));
    this.buttonGroup1.add(this.jRadioButton23);
    this.jRadioButton23.setText("VORTEX (DS 80)");
    this.jRadioButton23.setFocusPainted(false);
    this.jRadioButton23.setFocusable(false);
    this.jRadioButton23.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jRadioButton23ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jRadioButton23, new AbsoluteConstraints(300, 150, -1, -1));
    this.jPanel1.add(this.jPanel4, new AbsoluteConstraints(20, 180, 430, 210));
    this.jButton1.setText("Format");
    this.jButton1.setFocusPainted(false);
    this.jButton1.setFocusable(false);
    this.jButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jButton1ActionPerformed(evt);
          }
        });
    this.jPanel1.add(this.jButton1, new AbsoluteConstraints(300, 400, -1, -1));
    this.jButton2.setText("Cancel");
    this.jButton2.setFocusPainted(false);
    this.jButton2.setFocusable(false);
    this.jButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.jButton2ActionPerformed(evt);
          }
        });
    this.jPanel1.add(this.jButton2, new AbsoluteConstraints(380, 400, -1, -1));
    this.selform.setFont(new Font("Tahoma", 1, 11));
    this.selform.setForeground(new Color(255, 0, 0));
    this.selform.setText("Selected Format: DATA (SS 40)");
    this.jPanel1.add(this.selform, new AbsoluteConstraints(30, 420, -1, -1));
    this.jPanel1.add(this.dsk, new AbsoluteConstraints(290, 420, 170, 20));
    this.drivesel.setFont(new Font("Tahoma", 0, 10));
    this.drivesel.setModel(new DefaultComboBoxModel<>(new String[] { "DF0", "DF1", "DF2", "DF3" }));
    this.drivesel.setFocusable(false);
    this.drivesel.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FormatPanel.this.driveselActionPerformed(evt);
          }
        });
    this.jPanel1.add(this.drivesel, new AbsoluteConstraints(120, 390, -1, 20));
    this.jLabel1.setFont(new Font("Tahoma", 1, 11));
    this.jLabel1.setText("Selected Drive:");
    this.jPanel1.add(this.jLabel1, new AbsoluteConstraints(30, 390, -1, 20));
    GroupLayout layout = new GroupLayout(this);
    setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addComponent(this.jPanel1, -2, 470, -2)
          .addContainerGap(-1, 32767)));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addComponent(this.jPanel1, -2, 452, -2)
          .addContainerGap(22, 32767)));
  }
  
  private void jRadioButton6ActionPerformed(ActionEvent evt) {
    this.index = 7;
    this.selform.setText(this.selected + "ROMDOS D40");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton2ActionPerformed(ActionEvent evt) {
    this.index = 0;
    this.selform.setText(this.selected + "PARADOS 80");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton8ActionPerformed(ActionEvent evt) {
    this.index = 1;
    this.selform.setText(this.selected + "PARADOS 41");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton9ActionPerformed(ActionEvent evt) {
    this.index = 2;
    this.selform.setText(this.selected + "PARADOS 40D");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton1ActionPerformed(ActionEvent evt) {
    this.index = 3;
    this.selform.setText(this.selected + "ROMDOS D1");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton7ActionPerformed(ActionEvent evt) {
    this.index = 4;
    this.selform.setText(this.selected + "ROMDOS D2");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton11ActionPerformed(ActionEvent evt) {
    this.index = 8;
    this.selform.setText(this.selected + "S-DOS (ROMDOS D80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton12ActionPerformed(ActionEvent evt) {
    this.index = 5;
    this.selform.setText(this.selected + "ROMDOS D10");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton3ActionPerformed(ActionEvent evt) {
    this.index = 6;
    this.selform.setText(this.selected + "ROMDOS D20");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton4ActionPerformed(ActionEvent evt) {
    this.index = 9;
    this.selform.setText(this.selected + "DATA (SS 40)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton5ActionPerformed(ActionEvent evt) {
    this.index = 10;
    this.selform.setText(this.selected + "DATA (DS 40)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton10ActionPerformed(ActionEvent evt) {
    this.index = 11;
    this.selform.setText(this.selected + "DATA (SS 80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton13ActionPerformed(ActionEvent evt) {
    this.index = 12;
    this.selform.setText(this.selected + "DATA (DS 80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton14ActionPerformed(ActionEvent evt) {
    this.index = 13;
    this.selform.setText(this.selected + "SYSTEM (SS 40)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton15ActionPerformed(ActionEvent evt) {
    this.index = 14;
    this.selform.setText(this.selected + "SYSTEM (DS 40)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton16ActionPerformed(ActionEvent evt) {
    this.index = 15;
    this.selform.setText(this.selected + "SYSTEM (SS 80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton18ActionPerformed(ActionEvent evt) {
    this.index = 16;
    this.selform.setText(this.selected + "SYSTEM (DS 80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton17ActionPerformed(ActionEvent evt) {
    this.index = 17;
    this.selform.setText(this.selected + "IBM (SS 40)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton22ActionPerformed(ActionEvent evt) {
    this.index = 18;
    this.selform.setText(this.selected + "IBM (DS 40)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton21ActionPerformed(ActionEvent evt) {
    this.index = 19;
    this.selform.setText(this.selected + "IBM (SS 80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton19ActionPerformed(ActionEvent evt) {
    this.index = 20;
    this.selform.setText(this.selected + "IBM (DS 80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton20ActionPerformed(ActionEvent evt) {
    this.index = 21;
    this.selform.setText(this.selected + "ULTRAFORM");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jButton1ActionPerformed(ActionEvent evt) {
    CPC.formNo = this.index;
    CPC.seldrive = this.seldrive;
  }
  
  private void driveselActionPerformed(ActionEvent evt) {
    this.seldrive = this.drivesel.getSelectedIndex();
  }
  
  private void jButton2ActionPerformed(ActionEvent evt) {
    CPC.formNo = 200;
  }
  
  private void jRadioButton23ActionPerformed(ActionEvent evt) {
    this.index = 22;
    this.selform.setText(this.selected + "VORTEX (DS 80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\FormatPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */