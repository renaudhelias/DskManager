package jemu.system.cpc;

import JCPC.core.device.Device;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowStateListener;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.LayoutStyle;
import javax.swing.Timer;
import javax.swing.border.Border;
import javax.swing.border.SoftBevelBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import jemu.core.Util;

public final class GraphicsViewer extends JFrame implements MouseListener, MouseMotionListener {
  ActionListener update = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        GraphicsViewer.this.Show();
      }
    };
  
  Timer fire = new Timer(150, this.update);
  
  protected boolean editable = true;
  
  BufferedImage[] screen;
  
  GraphicsDecoder decoder;
  
  public static int[] pixels;
  
  protected JPanel[] pan;
  
  protected JLabel[] img;
  
  protected int[] addresses;
  
  int width = 4;
  
  int height = 4;
  
  int mode = 1;
  
  int zoom = 4;
  
  int forcedzoom = 1;
  
  int panels = 0;
  
  protected int expaddress = 0;
  
  protected int expindex = 0;
  
  protected int expx = 0;
  
  protected int expad = 0;
  
  protected int gpen = 1;
  
  protected Color trans = new Color(0, 0, 255, 160);
  
  public void moveBack() {
    if (this.expindex > 0) {
      for (int i = 0; i < this.panels; i++)
        this.img[i].setEnabled(true); 
      this.expindex--;
      this.expaddress = this.addresses[this.expindex];
      this.aaddress.setText(Util.hex((short)this.addresses[this.expindex]));
      this.baddress.setText(Util.hex((short)this.addresses[this.expindex]));
      updateCell();
      updateScreen(this.screen[this.expindex]);
      if (this.rangeset) {
        checkRange();
      } else {
        this.img[this.expindex].setEnabled(false);
      } 
    } 
  }
  
  public void moveForward() {
    if (this.expindex < this.panels - 1) {
      for (int i = 0; i < this.panels; i++)
        this.img[i].setEnabled(true); 
      this.expindex++;
      this.expaddress = this.addresses[this.expindex];
      this.aaddress.setText(Util.hex((short)this.addresses[this.expindex]));
      this.baddress.setText(Util.hex((short)this.addresses[this.expindex]));
      updateCell();
      updateScreen(this.screen[this.expindex]);
      if (this.rangeset) {
        checkRange();
      } else {
        this.img[this.expindex].setEnabled(false);
      } 
    } 
  }
  
  int range = 0;
  
  int to = 0;
  
  boolean rangeset = false;
  
  protected boolean[] isenabled;
  
  public void mouseClicked(MouseEvent e) {
    if (e.getSource() == this.preview) {
      if (this.paint.isSelected() && 
        this.editable)
        PLOT(); 
      return;
    } 
    for (int i = 0; i < this.panels; i++) {
      this.img[i].setEnabled(true);
      if (e.getSource() == this.img[i])
        if (e.getClickCount() == 2) {
          this.rangeset = false;
          if ((e.getModifiers() & 0x10) != 0) {
            this.rangeset = false;
            this.address.setText(Util.hex((short)this.addresses[i]));
            this.expaddress = this.addresses[i];
            this.expindex = 0;
            this.scrollindex = this.expindex;
            Show();
          } else {
            this.rangeset = false;
            this.expaddress = this.addresses[i];
            this.expindex = i;
            this.scrollindex = this.expindex;
            savescreen(this.screen[i]);
          } 
        } else if ((e.getModifiers() & 0x10) != 0) {
          this.range = i;
          this.rangeset = false;
          this.img[i].setEnabled(false);
          this.expaddress = this.addresses[i];
          this.expindex = i;
          this.scrollindex = this.expindex;
          updateScreen(this.screen[this.expindex]);
          this.aaddress.setText(Util.hex((short)this.addresses[i]));
          this.baddress.setText(Util.hex((short)this.addresses[i]));
        } else {
          this.rangeset = true;
          this.to = i;
          checkRange();
          break;
        }  
    } 
  }
  
  public void checkRange() {
    if (!this.rangeset)
      return; 
    int f;
    for (f = 0; f < this.panels; f++)
      this.img[f].setEnabled(true); 
    if (this.range > this.to) {
      for (f = this.to; f <= this.range; f++)
        this.img[f].setEnabled(false); 
    } else if (this.range < this.to) {
      for (f = this.to; f >= this.range; f--)
        this.img[f].setEnabled(false); 
    } else {
      this.rangeset = false;
    } 
  }
  
  public void mouseEntered(MouseEvent e) {
    if (e.getSource() == this.preview)
      this.editable = true; 
  }
  
  public void mouseExited(MouseEvent e) {
    if (e.getSource() == this.preview)
      this.editable = false; 
  }
  
  public void mouseReleased(MouseEvent e) {
    if (e.getSource() == this.preview)
      if (this.rangeset) {
        checkRange();
      } else {
        this.img[this.expindex].setEnabled(false);
      }  
  }
  
  public void mousePressed(MouseEvent e) {}
  
  BufferedImage paletteImage = new BufferedImage(64, 64, 1);
  
  Palette pal;
  
  GifMaker gmaker;
  
  JFrame prev;
  
  FileDialog imp;
  
  Thread r;
  
  int pzoom;
  
  DOSHandler handler;
  
  protected byte[] hasdata;
  
  protected byte[] asmdata;
  
  boolean write;
  
  boolean autoupdate;
  
  boolean notPainted;
  
  int[] lines;
  
  int[] banks;
  
  BufferedImage buffer;
  
  boolean vertical;
  
  Mapper mapper;
  
  FileDialog importer;
  
  String[] mapinfo;
  
  boolean bit16;
  
  boolean skip;
  
  int scrollindex;
  
  int cellcount;
  
  private JCheckBox Screen;
  
  private JTextField aaddress;
  
  private JTextField address;
  
  private JTextField baddress;
  
  private JComboBox bank;
  
  private JCheckBox bin;
  
  private JCheckBox bin1;
  
  private Button button1;
  
  private Button button10;
  
  private Button button11;
  
  private Button button12;
  
  private Button button13;
  
  private Button button14;
  
  private Button button15;
  
  private Button button16;
  
  private Button button2;
  
  private Button button3;
  
  private Button button4;
  
  private Button button5;
  
  private Button button6;
  
  private Button button7;
  
  private Button button8;
  
  private Button button9;
  
  private ButtonGroup buttonGroup1;
  
  private ButtonGroup buttonGroup2;
  
  private JCheckBox format;
  
  private JCheckBox grid;
  
  private JCheckBox header;
  
  private JCheckBox header1;
  
  private JTextField heightfield;
  
  private JButton jButton1;
  
  private JButton jButton10;
  
  private JButton jButton11;
  
  private JButton jButton12;
  
  private JButton jButton13;
  
  private JButton jButton14;
  
  private JButton jButton15;
  
  private JButton jButton16;
  
  private JButton jButton17;
  
  private JButton jButton18;
  
  private JButton jButton19;
  
  private JButton jButton2;
  
  private JButton jButton20;
  
  private JButton jButton21;
  
  private JButton jButton22;
  
  private JButton jButton23;
  
  private JButton jButton24;
  
  private JButton jButton25;
  
  private JButton jButton26;
  
  private JButton jButton3;
  
  private JButton jButton4;
  
  private JButton jButton5;
  
  private JButton jButton6;
  
  private JButton jButton7;
  
  private JButton jButton8;
  
  private JButton jButton9;
  
  private JCheckBox jCheckBox2;
  
  private JLabel jLabel1;
  
  private JLabel jLabel10;
  
  private JLabel jLabel11;
  
  private JLabel jLabel12;
  
  private JLabel jLabel13;
  
  private JLabel jLabel2;
  
  private JLabel jLabel5;
  
  private JLabel jLabel6;
  
  private JLabel jLabel7;
  
  private JLabel jLabel8;
  
  private JLabel jLabel9;
  
  private JPanel jPanel1;
  
  private JPanel jPanel2;
  
  private JPanel jPanel3;
  
  private JPanel jPanel4;
  
  private JPanel jPanel5;
  
  private JPanel jPanel6;
  
  private JPanel jPanel7;
  
  private JPanel jPanel8;
  
  private JPanel jPanel9;
  
  private JScrollPane jScrollPane1;
  
  private JScrollPane jScrollPane2;
  
  private JSeparator jSeparator1;
  
  private JSpinner jSpinner1;
  
  private JToggleButton jToggleButton1;
  
  private JCheckBox line;
  
  private JCheckBox linear;
  
  private JSlider maxtiles;
  
  private JCheckBox nozoom;
  
  private JToggleButton paint;
  
  private JLabel preview;
  
  private JCheckBox reverse;
  
  private JCheckBox rom;
  
  private JCheckBox skipscreen;
  
  private JCheckBox step;
  
  private JLabel tiles;
  
  private JPanel viewPort;
  
  private JTextField widthfield;
  
  private JTextField zm;
  
  public void setPalette() {
    if (this.isenabled == null)
      this.isenabled = new boolean[16]; 
    for (int i = 0; i < 16; i++) {
      this.isenabled[i] = true;
      if ((this.mode == 1 || this.mode == 3) && i > 3)
        this.isenabled[i] = false; 
      if (this.mode == 2 && i > 1)
        this.isenabled[i] = false; 
    } 
    this.button1.setVisible(this.isenabled[0]);
    this.button2.setVisible(this.isenabled[1]);
    this.button3.setVisible(this.isenabled[2]);
    this.button4.setVisible(this.isenabled[3]);
    this.button5.setVisible(this.isenabled[4]);
    this.button6.setVisible(this.isenabled[5]);
    this.button7.setVisible(this.isenabled[6]);
    this.button8.setVisible(this.isenabled[7]);
    this.button9.setVisible(this.isenabled[8]);
    this.button10.setVisible(this.isenabled[9]);
    this.button11.setVisible(this.isenabled[10]);
    this.button12.setVisible(this.isenabled[11]);
    this.button13.setVisible(this.isenabled[12]);
    this.button14.setVisible(this.isenabled[13]);
    this.button15.setVisible(this.isenabled[14]);
    this.button16.setVisible(this.isenabled[15]);
    this.pal.jPanel1.setVisible(this.isenabled[0]);
    this.pal.jPanel2.setVisible(this.isenabled[1]);
    this.pal.jPanel3.setVisible(this.isenabled[2]);
    this.pal.jPanel4.setVisible(this.isenabled[3]);
    this.pal.jPanel5.setVisible(this.isenabled[4]);
    this.pal.jPanel6.setVisible(this.isenabled[5]);
    this.pal.jPanel7.setVisible(this.isenabled[6]);
    this.pal.jPanel8.setVisible(this.isenabled[7]);
    this.pal.jPanel9.setVisible(this.isenabled[8]);
    this.pal.jPanel10.setVisible(this.isenabled[9]);
    this.pal.jPanel11.setVisible(this.isenabled[10]);
    this.pal.jPanel12.setVisible(this.isenabled[11]);
    this.pal.jPanel13.setVisible(this.isenabled[12]);
    this.pal.jPanel14.setVisible(this.isenabled[13]);
    this.pal.jPanel15.setVisible(this.isenabled[14]);
    this.pal.jPanel16.setVisible(this.isenabled[15]);
    Graphics d = this.paletteImage.createGraphics();
    Color[] p = new Color[16];
    for (int j = 0; j < 16; j++)
      p[j] = CPC.getCol(j); 
    int off = 0;
    for (int x = 0; x < 4; x++) {
      for (int y = 0; y < 4; y++) {
        d.setColor(p[off++]);
        d.fillRect(x * 16, y * 16, 16, 16);
      } 
    } 
    for (int k = 0; k < 16; k++) {
      Color col = CPC.getCol(k);
      switch (k) {
        case 0:
          this.button1.setBackground(col);
          this.pal.panel1.setBackground(col);
          break;
        case 1:
          this.button2.setBackground(col);
          this.pal.panel2.setBackground(col);
          break;
        case 2:
          this.button3.setBackground(col);
          this.pal.panel3.setBackground(col);
          break;
        case 3:
          this.button4.setBackground(col);
          this.pal.panel4.setBackground(col);
          break;
        case 4:
          this.button5.setBackground(col);
          this.pal.panel5.setBackground(col);
          break;
        case 5:
          this.button6.setBackground(col);
          this.pal.panel6.setBackground(col);
          break;
        case 6:
          this.button7.setBackground(col);
          this.pal.panel7.setBackground(col);
          break;
        case 7:
          this.button8.setBackground(col);
          this.pal.panel8.setBackground(col);
          break;
        case 8:
          this.button9.setBackground(col);
          this.pal.panel9.setBackground(col);
          break;
        case 9:
          this.button10.setBackground(col);
          this.pal.panel10.setBackground(col);
          break;
        case 10:
          this.button11.setBackground(col);
          this.pal.panel11.setBackground(col);
          break;
        case 11:
          this.button12.setBackground(col);
          this.pal.panel12.setBackground(col);
          break;
        case 12:
          this.button13.setBackground(col);
          this.pal.panel13.setBackground(col);
          break;
        case 13:
          this.button14.setBackground(col);
          this.pal.panel14.setBackground(col);
          break;
        case 14:
          this.button15.setBackground(col);
          this.pal.panel15.setBackground(col);
          break;
        case 15:
          this.button16.setBackground(col);
          this.pal.panel16.setBackground(col);
          break;
      } 
    } 
  }
  
  public void mouseMoved(MouseEvent e) {
    if (e.getSource() == this.preview) {
      try {
        int x = e.getX() / this.pzoom / 8;
        int cx = e.getX() / this.pzoom;
        int y = e.getY() / this.pzoom * 2;
        y++;
        x++;
        if (this.mode == 1)
          cx /= 2; 
        if (this.mode == 0)
          cx /= 4; 
        int a = this.addresses[this.expindex] + x * y - 1;
        this.aaddress.setText(Util.hex((short)a));
        this.baddress.setText(Util.hex((short)a));
        this.expad = this.addresses[this.expindex] + x - 1 + this.preview.getWidth() / this.pzoom * 8 * (y - 1);
        this.expx = cx;
      } catch (Exception exception) {}
      return;
    } 
    for (int i = 0; i < this.panels; i++) {
      if (e.getSource() == this.img[i]) {
        int x = e.getX() / 8;
        int y = e.getY() / 2;
        y++;
        x++;
        int a = this.addresses[i] + x * y - 1;
        this.aaddress.setText(Util.hex((short)a));
        this.baddress.setText(Util.hex((short)a));
        break;
      } 
    } 
  }
  
  public byte[] exportBin() {
    int x = this.screen[this.expindex].getWidth() / 8 / this.zoom / this.forcedzoom;
    int y = this.screen[this.expindex].getHeight() / 2 / this.zoom / this.forcedzoom;
    int size = x * y;
    byte[] data = new byte[size];
    if (this.write) {
      System.arraycopy(GateArray.screenmemory, this.expaddress, data, 0, size);
    } else {
      for (int i = 0; i < size; i++)
        data[i] = (byte)CPC.memory.readByte(this.expaddress + i); 
    } 
    System.arraycopy(GateArray.screenmemory, this.expaddress, data, 0, size);
    return data;
  }
  
  public byte[] exportRange() {
    int x = 0;
    int y = 0;
    int size = 0;
    int off = 0;
    int divider = 0;
    if (this.range > this.to) {
      this.expaddress = this.addresses[this.to];
      for (int f = this.to; f <= this.range; f++) {
        x += this.screen[f].getWidth() / 8 / this.zoom / this.forcedzoom;
        y += this.screen[f].getHeight() / 2 / this.zoom / this.forcedzoom;
        divider++;
      } 
    } else {
      this.expaddress = this.addresses[this.range];
      for (int f = this.to; f >= this.range; f--) {
        x += this.screen[f].getWidth() / 8 / this.zoom / this.forcedzoom;
        y += this.screen[f].getHeight() / 2 / this.zoom / this.forcedzoom;
        divider++;
      } 
    } 
    size = x * y / divider;
    byte[] data = new byte[size];
    if (this.write) {
      System.arraycopy(GateArray.screenmemory, this.expaddress, data, 0, size);
    } else {
      for (int i = 0; i < size; i++)
        data[i] = (byte)CPC.memory.readByte(this.expaddress + i); 
    } 
    return data;
  }
  
  public void PLOT() {
    PLOT(this.expx, this.mode, this.expad);
  }
  
  public void PLOT(int pen) {
    PLOT(this.expx, this.mode, this.expad, pen);
  }
  
  public void PLOT(int x, int mode, int scraddr) {
    CPC.PLOT(this.linear.isSelected(), x, this.gpen, mode, scraddr);
    updateCell();
    updateScreen(this.screen[this.expindex]);
  }
  
  public void PLOT(int x, int mode, int scraddr, int pen) {
    CPC.PLOT(this.linear.isSelected(), x, pen, mode, scraddr);
  }
  
  public void mouseDragged(MouseEvent e) {
    if (e.getSource() == this.preview) {
      if (this.paint.isSelected() && 
        this.editable)
        try {
          int x = e.getX() / this.pzoom / 8;
          int cx = e.getX() / this.pzoom;
          int y = e.getY() / this.pzoom * 2;
          y++;
          x++;
          if (this.mode == 1)
            cx /= 2; 
          if (this.mode == 0)
            cx /= 4; 
          int a = this.addresses[this.expindex] + x * y - 1;
          this.aaddress.setText(Util.hex((short)a));
          this.baddress.setText(Util.hex((short)a));
          this.expad = this.addresses[this.expindex] + x - 1 + this.preview.getWidth() / this.pzoom * 8 * (y - 1);
          this.expx = cx;
          PLOT();
        } catch (Exception exception) {} 
      return;
    } 
  }
  
  public JComponent getPanel() {
    return this.jPanel9;
  }
  
  private void formMouseWheelMoved(MouseWheelEvent evt) {
    if (this.pan == null || this.pan[0] == null || this.pan[0].getWidth() < 1)
      return; 
    try {
      int capture = Util.hexValue(this.address.getText());
      if (evt.getUnitsToScroll() > 0) {
        int endcapture = capture + this.screen[0].getWidth() / 8 / this.zoom / this.forcedzoom * this.cellcount * this.screen[0].getHeight() / 2 / this.zoom / this.forcedzoom;
        endcapture &= 0xFFFF;
        this.address.setText(Util.hex((short)endcapture));
        Show();
      } else if (evt.getUnitsToScroll() < 0) {
        int endcapture = capture - this.screen[0].getWidth() / 8 / this.zoom / this.forcedzoom * this.cellcount * this.screen[0].getHeight() / 2 / this.zoom / this.forcedzoom;
        endcapture &= 0xFFFF;
        this.address.setText(Util.hex((short)endcapture));
        Show();
      } 
    } catch (Exception exception) {}
  }
  
  public GraphicsViewer() {
    this.imp = new FileDialog(this, "Import PNG Tile", 0);
    this.pzoom = 1;
    this.notPainted = false;
    this.lines = new int[] { 0, 1, 3, 2, 7, 4, 5, 6 };
    this.banks = new int[] { 192, 196, 197, 198, 199 };
    this.vertical = false;
    this.scrollindex = 0;
    this.cellcount = 0;
    this.decoder = new GraphicsDecoder();
    initComponents();
    this.Screen.setVisible(false);
    this.gmaker = new GifMaker();
    this.pal = new Palette(this.gmaker);
    this.jPanel2.add(this.pal);
    this.jPanel2.add(this.jButton19);
    this.jPanel2.add(this.jButton18);
    this.viewPort.addMouseWheelListener(new MouseWheelListener() {
          public void mouseWheelMoved(MouseWheelEvent evt) {
            GraphicsViewer.this.formMouseWheelMoved(evt);
          }
        });
    Show();
  }
  
  public void importPNG() {
    this.prev.setAlwaysOnTop(false);
    this.pzoom = 1;
    updateScreen(this.screen[this.expindex]);
    this.imp.setFile("*.png");
    this.imp.setVisible(true);
    this.prev.setAlwaysOnTop(true);
    if (this.imp.getFile() != null && this.imp.getDirectory() != null) {
      String f = this.imp.getDirectory() + this.imp.getFile();
      String path = this.imp.getDirectory();
      String pic = this.imp.getFile();
      try {
        File a = new File(f);
        BufferedImage pre = ImageIO.read(a);
        if (!this.imp.getFile().contains("cell_") || this.imp.getFile().contains("cell_palette") || pre.getWidth() != this.buffer.getWidth() || pre.getHeight() != this.buffer.getHeight()) {
          System.out.println("Bad File!");
          return;
        } 
        pic = pic.replace("cell_", "cell_palette_");
        System.out.println("Opening " + path + pic);
        BufferedImage palImage = ImageIO.read(new File(path + pic));
        System.out.println("Image imported... Checking Palette....");
        int[] pall = new int[16];
        int off = 0;
        for (int x = 0; x < 4; x++) {
          for (int y = 0; y < 4; y++) {
            int RGB = this.paletteImage.getRGB(x * 16, y * 16);
            Color cpc = new Color(RGB);
            int red = cpc.getRed();
            int green = cpc.getGreen();
            int blue = cpc.getBlue();
            int RGB2 = palImage.getRGB(x * 16, y * 16);
            Color png = new Color(RGB2);
            int pred = png.getRed();
            int pgreen = png.getGreen();
            int pblue = png.getBlue();
            if (RGB2 != RGB) {
              System.out.println("Bad Palette");
              pall[off++] = RGB2;
              break;
            } 
            pall[off++] = RGB2;
          } 
        } 
        System.out.println("Palette Checked... Building now....");
        int xs = 1;
        switch (this.mode) {
          case 0:
            xs = 4;
            break;
          case 1:
            xs = 2;
            break;
        } 
        int ys = 2;
        int xx;
        for (xx = 0; xx < pre.getWidth(); xx += xs) {
          int yy;
          for (yy = 0; yy < pre.getHeight(); yy += ys) {
            int j = xx / 8;
            int cx = xx;
            int y = yy / 2;
            y++;
            j++;
            if (this.mode == 1)
              cx /= 2; 
            if (this.mode == 0)
              cx /= 4; 
            this.expad = this.addresses[this.expindex] + j - 1 + pre.getWidth() / 8 * (y - 1);
            this.expx = cx;
            int pen = -1;
            int i = 0;
            while (true) {
              if (i < ((this.mode == 2) ? 2 : ((this.mode == 1) ? 4 : 16))) {
                Color colbuffer = new Color(pre.getRGB(xx, yy));
                int R = colbuffer.getRed();
                int G = colbuffer.getGreen();
                int B = colbuffer.getBlue();
                colbuffer = new Color(pall[i]);
                int r = colbuffer.getRed();
                int g = colbuffer.getGreen();
                int b = colbuffer.getBlue();
                if (((R >= 0 && R <= 40 && r >= 0 && r <= 40) || (R >= 88 && R <= 168 && r >= 88 && r <= 168) || (R >= 216 && R <= 255 && r >= 216 && r <= 255)) && ((G >= 0 && G <= 40 && g >= 0 && g <= 40) || (G >= 88 && G <= 168 && g >= 88 && g <= 168) || (G >= 216 && G <= 255 && g >= 216 && g <= 255)) && ((B >= 0 && B <= 40 && b >= 0 && b <= 40) || (B >= 88 && B <= 168 && b >= 88 && b <= 168) || (B >= 216 && B <= 255 && b >= 216 && b <= 255))) {
                  pen = i;
                  break;
                } 
                i++;
                continue;
              } 
              break;
            } 
            if (pen > -1)
              PLOT(pen); 
          } 
        } 
        updateCell();
        updateScreen(this.screen[this.expindex]);
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
  }
  
  public void updateScreen(BufferedImage ima) {
    int z = this.pzoom;
    int w = ima.getWidth() * z;
    int h = ima.getHeight() * z;
    w /= this.zoom;
    h /= this.zoom;
    w /= this.forcedzoom;
    h /= this.forcedzoom;
    if (this.buffer == null || this.buffer.getWidth() != w || this.buffer.getHeight() != h)
      this.buffer = new BufferedImage(w, h, 1); 
    this.buffer.getGraphics().drawImage(ima, 0, 0, w, h, null);
    this.preview.setIcon(new ImageIcon(this.buffer));
    if (this.preview.getWidth() != this.buffer.getWidth() || this.preview.getHeight() != this.buffer.getHeight()) {
      this.preview.setPreferredSize(new Dimension(this.buffer.getWidth(), this.buffer.getHeight()));
      this.preview.setSize(new Dimension(this.buffer.getWidth(), this.buffer.getHeight()));
      this.preview.setMinimumSize(new Dimension(this.buffer.getWidth(), this.buffer.getHeight()));
      this.preview.setMaximumSize(new Dimension(this.buffer.getWidth(), this.buffer.getHeight()));
    } 
  }
  
  public void savescreen(BufferedImage ima) {
    if (this.prev == null) {
      this.prev = new JFrame("Edit cell");
      this.prev.setLayout(new BorderLayout());
      this.prev.add(this.jPanel1, "Center");
      this.prev.setResizable(true);
      this.prev.setDefaultCloseOperation(1);
      this.preview.addMouseListener(this);
      this.preview.addMouseMotionListener(this);
      this.prev.pack();
      this.prev.setAlwaysOnTop(true);
    } 
    int w = ima.getWidth();
    int h = ima.getHeight();
    w /= this.forcedzoom;
    h /= this.forcedzoom;
    w /= this.zoom;
    h /= this.zoom;
    w *= this.pzoom;
    h *= this.pzoom;
    this.buffer = new BufferedImage(w, h, 1);
    this.buffer.getGraphics().drawImage(ima, 0, 0, w, h, null);
    this.preview.setIcon(new ImageIcon(this.buffer));
    this.preview.setPreferredSize(new Dimension(this.buffer.getWidth(), this.buffer.getHeight()));
    this.preview.setSize(new Dimension(this.buffer.getWidth(), this.buffer.getHeight()));
    this.preview.setMinimumSize(new Dimension(this.buffer.getWidth(), this.buffer.getHeight()));
    this.preview.setMaximumSize(new Dimension(this.buffer.getWidth(), this.buffer.getHeight()));
    this.prev.setVisible(true);
  }
  
  public void copy() {
    if (this.rangeset) {
      this.hasdata = exportRange();
    } else {
      this.hasdata = exportBin();
    } 
  }
  
  public void paste() {
    if (this.hasdata == null)
      return; 
    try {
      System.arraycopy(this.hasdata, 0, GateArray.screenmemory, this.expaddress, this.hasdata.length);
    } catch (Exception exception) {}
    Show();
  }
  
  public void exportASM() {
    boolean useformat = this.format.isSelected();
    String islinear = "";
    if (this.linear.isSelected())
      islinear = "_linear"; 
    StringBuilder output = new StringBuilder();
    output.append("        ;;'");
    int g = this.expaddress;
    if (this.rangeset) {
      if (this.range > this.to) {
        output.append("range_" + Util.hex((short)this.addresses[this.to]) + "-" + Util.hex((short)this.addresses[this.range]) + islinear);
        g = this.addresses[this.to];
      } else {
        output.append("range_" + Util.hex((short)this.addresses[this.range]) + "-" + Util.hex((short)this.addresses[this.to]) + islinear);
        g = this.addresses[this.range];
      } 
    } else {
      output.append("cell_" + Util.hex((short)this.expaddress) + islinear);
    } 
    output.append("\r\n        ;; width:" + this.width + " - height:" + this.height);
    int sizesprite = this.width * this.height + (useformat ? 2 : 0);
    output.append("\r\n        ;;  size:" + sizesprite);
    output.append("\r\n\r\n        ORG     &");
    if (this.rangeset) {
      if (this.range > this.to) {
        output.append(Util.hex((short)this.addresses[this.to]));
      } else {
        output.append(Util.hex((short)this.addresses[this.range]));
      } 
      this.asmdata = exportRange();
    } else {
      output.append((short)this.expaddress);
      this.asmdata = exportBin();
    } 
    output.append("\r\n\r\n.sprite" + islinear + "_" + Util.hex((short)g) + "\r\n");
    int h = 0;
    int realheight = this.height;
    int useheight = realheight;
    if (useformat)
      output.append("        DB      &" + Util.hex((byte)useheight) + " ,&" + Util.hex((byte)this.width) + "\r\n"); 
    int i;
    for (i = 0; i < this.asmdata.length; i += this.width) {
      output.append("        DB      ");
      for (int j = 0; j < this.width; j++) {
        try {
          output.append("&" + Util.hex(this.asmdata[i + j]));
          g++;
          if (j < this.width - 1)
            output.append(","); 
        } catch (Exception exception) {}
      } 
      output.append("\r\n");
      h++;
      if (h >= this.height && i < this.asmdata.length - this.width) {
        output.append("\r\n.sprite" + islinear + "_" + Util.hex((short)g) + "\r\n");
        if (useformat)
          output.append("        DB      &" + Util.hex((byte)useheight) + ", &" + Util.hex((byte)this.width) + "\r\n"); 
        h = 0;
      } 
    } 
    try {
      File file;
      if (this.rangeset) {
        if (this.range > this.to) {
          file = new File("range_" + Util.hex((short)this.addresses[this.to]) + "-" + Util.hex((short)this.addresses[this.range]) + islinear + ".asm");
        } else {
          file = new File("range_" + Util.hex((short)this.addresses[this.range]) + "-" + Util.hex((short)this.addresses[this.to]) + islinear + ".asm");
        } 
      } else {
        file = new File("cell_" + Util.hex((short)this.expaddress) + islinear + ".asm");
      } 
      byte[] content1 = output.toString().getBytes("UTF-8");
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
      bos.write(content1);
      bos.close();
    } catch (Exception exception) {}
  }
  
  public void export() {
    if (this.handler == null)
      this.handler = new DOSHandler(); 
    try {
      String islinear = "";
      if (this.linear.isSelected())
        islinear = "_linear"; 
      if (this.bin.isSelected()) {
        File file;
        if (this.rangeset) {
          if (this.range > this.to) {
            file = new File("range_" + Util.hex((short)this.addresses[this.to]) + "-" + Util.hex((short)this.addresses[this.range]) + islinear + ".bin");
          } else {
            file = new File("range_" + Util.hex((short)this.addresses[this.range]) + "-" + Util.hex((short)this.addresses[this.to]) + islinear + ".bin");
          } 
        } else {
          file = new File("cell_" + Util.hex((short)this.expaddress) + islinear + ".bin");
        } 
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
        byte[] data = null;
        if (this.rangeset) {
          data = exportRange();
        } else {
          data = exportBin();
        } 
        if (this.header.isSelected())
          if (this.rangeset) {
            data = this.handler.makeHeader(data, this.expaddress, data.length, "RANGEDUMP");
          } else {
            data = this.handler.makeHeader(data, this.expaddress, data.length, "CELLDUMP");
          }  
        bos.write(data);
        bos.close();
      } else if (this.rangeset) {
        BufferedImage out = null;
        if (this.range > this.to) {
          int frames = this.range - this.to + 1;
          File file = new File("range_" + Util.hex((short)this.addresses[this.to]) + "-" + Util.hex((short)this.addresses[this.range]) + islinear + ".png");
          System.out.println("Case 1:Frames found: " + frames);
          out = new BufferedImage(this.screen[0].getWidth() * frames, this.screen[0].getHeight(), 4);
          int len = this.screen[0].getWidth();
          int pos = 0;
          for (int f = this.to; f < this.to + frames; f++) {
            out.getGraphics().drawImage(this.screen[f], pos, 0, null);
            pos += len;
          } 
          ImageIO.write(out, "png", file);
        } else if (this.range < this.to) {
          int frames = this.to - this.range + 1;
          File file = new File("range_" + Util.hex((short)this.addresses[this.range]) + "-" + Util.hex((short)this.addresses[this.to]) + islinear + ".png");
          System.out.println("Case 2:Frames found: " + frames);
          out = new BufferedImage(this.screen[0].getWidth() * frames, this.screen[0].getHeight(), 4);
          int len = this.screen[0].getWidth();
          int pos = 0;
          for (int f = this.range; f < this.range + frames; f++) {
            out.getGraphics().drawImage(this.screen[f], pos, 0, null);
            pos += len;
          } 
          ImageIO.write(out, "png", file);
        } 
      } else {
        File file = new File("cell_" + Util.hex((short)this.expaddress) + islinear + ".png");
        ImageIO.write(this.screen[this.expindex], "png", file);
        file = new File("cell_palette_" + Util.hex((short)this.expaddress) + islinear + ".png");
        ImageIO.write(this.paletteImage, "png", file);
      } 
    } catch (Exception exception) {}
  }
  
  public void Show() {
    if (this.notPainted)
      return; 
    this.notPainted = true;
    String d = this.jSpinner1.getValue().toString();
    int skip = Integer.parseInt(d);
    this.write = !this.rom.isSelected();
    int rw = this.width * 8;
    int rh = this.height * 2;
    int insets = 1;
    if (!this.grid.isSelected())
      insets = 0; 
    int x = this.viewPort.getWidth();
    int y = this.viewPort.getHeight();
    int xPanels = x / (rw + insets);
    int yPanels = y / (rh + insets);
    this.panels = yPanels / this.zoom * xPanels / this.zoom;
    if (this.panels < 1)
      this.panels = 1; 
    if (this.panels < 256 && (this.width < 10 || this.height < 40))
      this.panels = 256; 
    int max = this.maxtiles.getValue() / 256 * 256;
    if (max != 0 && this.panels > max)
      this.panels = max; 
    this.forcedzoom = this.panels / 600;
    if (this.forcedzoom < 1)
      this.forcedzoom = 1; 
    if (this.nozoom.isSelected())
      this.forcedzoom = 1; 
    this.panels /= this.forcedzoom;
    if (this.pan == null || this.pan.length != this.panels) {
      this.pan = new JPanel[this.panels];
      this.img = new JLabel[this.panels];
      this.addresses = new int[this.panels];
      this.screen = new BufferedImage[this.panels];
    } 
    for (int i = 0; i < this.panels; i++) {
      this.pan[i] = new JPanel();
      this.pan[i].setLayout(new BorderLayout());
      this.img[i] = new JLabel();
      this.pan[i].add(this.img[i], "Center");
      this.img[i].addMouseListener(this);
      this.img[i].addMouseMotionListener(this);
    } 
    int adr = 0;
    try {
      adr = Util.hexValue(this.address.getText());
    } catch (Exception e) {
      return;
    } 
    int bnk = this.bank.getSelectedIndex();
    this.viewPort.removeAll();
    for (int cells = 0; cells < this.panels; cells++) {
      this.addresses[cells] = adr;
      if (this.grid.isSelected()) {
        this.pan[cells].setBorder(BorderFactory.createLineBorder(Color.white, 1));
      } else {
        this.pan[cells].setBorder((Border)null);
      } 
      this.pan[cells].setPreferredSize(new Dimension(rw * this.zoom * this.forcedzoom + insets, rh * this.zoom * this.forcedzoom + insets));
      this.screen[cells] = new BufferedImage(rw, rh / 2, 1);
      int size = this.screen[cells].getWidth() * this.screen[cells].getHeight();
      pixels = new int[size];
      for (int g = 0; g < pixels.length; g++)
        pixels[g] = -16777216; 
      int isbnk = CPC.memory.getRAMBank();
      CPC.memory.setForcedRAMBank(this.banks[bnk]);
      try {
        WritableRaster raster = this.screen[cells].getRaster();
        if (!this.linear.isSelected() && !this.Screen.isSelected()) {
          for (int k = 0; k < size; k += 8) {
            int[] arrayOfInt;
            if (this.reverse.isSelected()) {
              arrayOfInt = this.decoder.pixelreversecolor(adr, this.mode, !this.rom.isSelected());
            } else {
              arrayOfInt = this.decoder.pixelcolor(adr, this.mode, !this.rom.isSelected());
            } 
            for (int h = 0; h < 8; h++) {
              if (this.skipscreen.isSelected() && adr > 49151) {
                pixels[k + h] = Color.darkGray.getRGB();
              } else if (adr < 65536) {
                pixels[k + h] = GateArray.inks[arrayOfInt[h]];
              } else {
                pixels[k + h] = Color.lightGray.getRGB();
              } 
            } 
            adr++;
          } 
          adr += skip;
        } else if (this.linear.isSelected()) {
          for (int k = 0; k < size; k += 8) {
            int[] arrayOfInt = this.decoder.pixellinear(adr, this.mode, !this.rom.isSelected());
            for (int h = 0; h < 8; h++) {
              if (this.skipscreen.isSelected() && adr > 49151) {
                pixels[k + h] = Color.darkGray.getRGB();
              } else if (adr < 65536) {
                pixels[k + h] = GateArray.inks[arrayOfInt[h]];
              } else {
                pixels[k + h] = Color.lightGray.getRGB();
              } 
            } 
            adr++;
          } 
          adr += skip;
        } else if (this.Screen.isSelected()) {
          for (int k = 0; k < size; k += 8) {
            int[] arrayOfInt;
            if (cells == 0)
              System.out.println(k); 
            if (this.reverse.isSelected()) {
              arrayOfInt = this.decoder.pixelreversecolor(adr, this.mode, !this.rom.isSelected());
            } else {
              arrayOfInt = this.decoder.pixelcolor(adr, this.mode, !this.rom.isSelected());
            } 
            for (int h = 0; h < 8; h++) {
              if (this.skipscreen.isSelected() && adr > 49151) {
                pixels[k + h] = Color.darkGray.getRGB();
              } else if (adr < 65536) {
                pixels[k + h] = GateArray.inks[arrayOfInt[h]];
              } else {
                pixels[k + h] = Color.lightGray.getRGB();
              } 
            } 
            adr++;
          } 
          adr += skip;
        } 
        raster.setDataElements(0, 0, this.screen[cells].getWidth(), this.screen[cells].getHeight(), pixels);
        try {
          this.buffer = new BufferedImage(rw * this.zoom * this.forcedzoom, rh * this.zoom * this.forcedzoom, 1);
          this.buffer.getGraphics().drawImage(this.screen[cells], 0, 0, rw * this.zoom * this.forcedzoom, rh * this.zoom * this.forcedzoom, null);
          this.screen[cells] = new BufferedImage(this.buffer.getWidth(), this.buffer.getHeight(), 1);
          this.screen[cells].getGraphics().drawImage(this.buffer, 0, 0, null);
          this.img[cells].setIcon(new ImageIcon(this.buffer));
        } catch (Exception exception) {}
      } catch (Exception e) {
        System.gc();
        System.err.println(e.getMessage());
      } 
      CPC.memory.setForcedRAMBank(isbnk);
      if (adr > 65535)
        adr = 0; 
    } 
    int v = (this.pan[0].getPreferredSize()).width + (this.pan[0].getInsets()).right;
    this.cellcount = this.viewPort.getWidth() / v;
    for (int j = 0; j < this.panels; j++)
      this.viewPort.add(this.pan[j]); 
    this.viewPort.repaint();
    this.viewPort.updateUI();
    this.jPanel9.repaint();
    try {
      updateScreen(this.screen[this.expindex]);
    } catch (Exception exception) {}
    setPalette();
    if (this.viewPort.getHeight() < this.jScrollPane1.getHeight())
      this.viewPort.setPreferredSize(new Dimension(800, this.jScrollPane1.getHeight())); 
    if (this.viewPort.getHeight() < this.screen[0].getHeight() + 10)
      this.viewPort.setPreferredSize(new Dimension(800, this.screen[0].getHeight() + 10)); 
    this.notPainted = false;
  }
  
  public void updateCell() {
    int skip = Integer.parseInt(this.jSpinner1.getValue().toString());
    int adr = this.expaddress;
    int rw = this.width * 8;
    int rh = this.height * 2;
    this.screen[this.expindex] = new BufferedImage(rw, rh / 2, 1);
    int size = this.screen[this.expindex].getWidth() * this.screen[this.expindex].getHeight();
    pixels = new int[size];
    for (int g = 0; g < pixels.length; g++)
      pixels[g] = -16777110; 
    try {
      WritableRaster raster = this.screen[this.expindex].getRaster();
      if (!this.linear.isSelected()) {
        for (int i = 0; i < size; i += 8) {
          int[] v = this.decoder.pixelcolor(adr, this.mode, !this.rom.isSelected());
          for (int h = 0; h < 8; h++) {
            if (this.skipscreen.isSelected() && adr > 49151) {
              pixels[i + h] = Color.darkGray.getRGB();
            } else if (adr < 65536) {
              pixels[i + h] = GateArray.inks[v[h]];
            } else {
              pixels[i + h] = Color.lightGray.getRGB();
            } 
          } 
          adr++;
        } 
        adr += skip;
      } else {
        for (int i = 0; i < size; i += 8) {
          int[] v = this.decoder.pixellinear(adr, this.mode, !this.rom.isSelected());
          for (int h = 0; h < 8; h++) {
            if (this.skipscreen.isSelected() && adr > 49151) {
              pixels[i + h] = Color.darkGray.getRGB();
            } else if (adr < 65536) {
              pixels[i + h] = GateArray.inks[v[h]];
            } else {
              pixels[i + h] = Color.lightGray.getRGB();
            } 
          } 
          adr++;
        } 
        adr += skip;
      } 
      adr &= 0xFFFF;
      raster.setDataElements(0, 0, this.screen[this.expindex].getWidth(), this.screen[this.expindex].getHeight(), pixels);
      this.buffer = new BufferedImage(rw * this.zoom, rh * this.zoom, 1);
      this.buffer.getGraphics().drawImage(this.screen[this.expindex], 0, 0, rw * this.zoom, rh * this.zoom, null);
      this.screen[this.expindex] = new BufferedImage(this.buffer.getWidth(), this.buffer.getHeight(), 1);
      this.screen[this.expindex].getGraphics().drawImage(this.buffer, 0, 0, null);
      this.img[this.expindex].setIcon(new ImageIcon(this.buffer));
    } catch (Exception e) {
      e.printStackTrace();
    } 
    this.img[this.expindex].setEnabled(true);
    setPalette();
  }
  
  private void initComponents() {
    this.jButton18 = new JButton();
    this.jPanel1 = new JPanel();
    this.jScrollPane2 = new JScrollPane();
    this.jPanel8 = new JPanel();
    this.preview = new JLabel();
    this.jPanel6 = new JPanel();
    this.jLabel10 = new JLabel();
    this.baddress = new JTextField();
    this.jButton16 = new JButton();
    this.jButton15 = new JButton();
    this.jLabel11 = new JLabel();
    this.jButton14 = new JButton();
    this.jButton13 = new JButton();
    this.jLabel9 = new JLabel();
    this.jPanel7 = new JPanel();
    this.jButton20 = new JButton();
    this.header = new JCheckBox();
    this.bin = new JCheckBox();
    this.jButton12 = new JButton();
    this.jToggleButton1 = new JToggleButton();
    this.paint = new JToggleButton();
    this.jButton1 = new JButton();
    this.jButton17 = new JButton();
    this.jButton25 = new JButton();
    this.jPanel3 = new JPanel();
    this.button1 = new Button();
    this.button2 = new Button();
    this.button3 = new Button();
    this.button4 = new Button();
    this.button5 = new Button();
    this.button6 = new Button();
    this.button7 = new Button();
    this.button8 = new Button();
    this.button9 = new Button();
    this.button10 = new Button();
    this.button11 = new Button();
    this.button12 = new Button();
    this.button13 = new Button();
    this.button14 = new Button();
    this.button15 = new Button();
    this.button16 = new Button();
    this.buttonGroup1 = new ButtonGroup();
    this.jButton19 = new JButton();
    this.buttonGroup2 = new ButtonGroup();
    this.jPanel9 = new JPanel();
    this.jPanel2 = new JPanel();
    this.jLabel8 = new JLabel();
    this.aaddress = new JTextField();
    this.jButton23 = new JButton();
    this.jButton26 = new JButton();
    this.nozoom = new JCheckBox();
    this.jButton24 = new JButton();
    this.jLabel13 = new JLabel();
    this.maxtiles = new JSlider();
    this.tiles = new JLabel();
    this.jPanel4 = new JPanel();
    this.jLabel1 = new JLabel();
    this.jButton2 = new JButton();
    this.widthfield = new JTextField();
    this.jButton3 = new JButton();
    this.jLabel5 = new JLabel();
    this.jButton5 = new JButton();
    this.heightfield = new JTextField();
    this.jButton4 = new JButton();
    this.jLabel7 = new JLabel();
    this.jButton10 = new JButton();
    this.zm = new JTextField();
    this.jButton11 = new JButton();
    this.jSeparator1 = new JSeparator();
    this.jButton21 = new JButton();
    this.bin1 = new JCheckBox();
    this.header1 = new JCheckBox();
    this.jButton22 = new JButton();
    this.format = new JCheckBox();
    this.grid = new JCheckBox();
    this.jLabel12 = new JLabel();
    this.jSpinner1 = new JSpinner();
    this.jPanel5 = new JPanel();
    this.jLabel2 = new JLabel();
    this.jButton8 = new JButton();
    this.address = new JTextField();
    this.jButton9 = new JButton();
    this.step = new JCheckBox();
    this.line = new JCheckBox();
    this.jButton6 = new JButton();
    this.jLabel6 = new JLabel();
    this.jButton7 = new JButton();
    this.linear = new JCheckBox();
    this.reverse = new JCheckBox();
    this.Screen = new JCheckBox();
    this.rom = new JCheckBox();
    this.skipscreen = new JCheckBox();
    this.bank = new JComboBox();
    this.jCheckBox2 = new JCheckBox();
    this.jScrollPane1 = new JScrollPane();
    this.viewPort = new JPanel();
    this.jButton18.setText("Paste");
    this.jButton18.setFocusPainted(false);
    this.jButton18.setFocusable(false);
    this.jButton18.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton18ActionPerformed(evt);
          }
        });
    this.jPanel1.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel1.setLayout(new BorderLayout());
    this.jScrollPane2.setPreferredSize(new Dimension(300, 300));
    this.jPanel8.setLayout(new BorderLayout());
    this.preview.setPreferredSize(new Dimension(300, 300));
    this.jPanel8.add(this.preview, "First");
    this.jScrollPane2.setViewportView(this.jPanel8);
    this.jPanel1.add(this.jScrollPane2, "Center");
    this.jPanel6.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel6.setPreferredSize(new Dimension(0, 26));
    this.jLabel10.setText("Address:");
    this.baddress.setEditable(false);
    this.baddress.setText("0000");
    this.baddress.setBorder(BorderFactory.createEtchedBorder());
    this.jButton16.setText(">");
    this.jButton16.setBorder(BorderFactory.createBevelBorder(0));
    this.jButton16.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton16ActionPerformed(evt);
          }
        });
    this.jButton15.setText("<");
    this.jButton15.setBorder(BorderFactory.createBevelBorder(0));
    this.jButton15.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton15ActionPerformed(evt);
          }
        });
    this.jLabel11.setText("Cell:");
    this.jButton14.setText("+");
    this.jButton14.setBorder(BorderFactory.createBevelBorder(0));
    this.jButton14.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton14ActionPerformed(evt);
          }
        });
    this.jButton13.setText("-");
    this.jButton13.setBorder(BorderFactory.createBevelBorder(0));
    this.jButton13.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton13ActionPerformed(evt);
          }
        });
    this.jLabel9.setText("Zoom");
    GroupLayout jPanel6Layout = new GroupLayout(this.jPanel6);
    this.jPanel6.setLayout(jPanel6Layout);
    jPanel6Layout.setHorizontalGroup(jPanel6Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel6Layout.createSequentialGroup().addContainerGap().addComponent(this.jLabel9).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton13, -2, 20, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton14, -2, 20, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel11).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton15).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton16).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jLabel10).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.baddress, -2, 43, -2).addContainerGap(49, 32767)));
    jPanel6Layout.setVerticalGroup(jPanel6Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel6Layout.createSequentialGroup().addGroup(jPanel6Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton13).addComponent(this.jButton14).addComponent(this.jLabel9).addComponent(this.baddress, -2, -1, -2).addComponent(this.jLabel10).addComponent(this.jButton15).addComponent(this.jButton16).addComponent(this.jLabel11)).addGap(0, 3, 32767)));
    this.jPanel1.add(this.jPanel6, "North");
    this.jPanel7.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel7.setPreferredSize(new Dimension(300, 130));
    this.jButton20.setText("Export ASM");
    this.jButton20.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton20ActionPerformed(evt);
          }
        });
    this.header.setText("Header");
    this.header.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.headerActionPerformed(evt);
          }
        });
    this.bin.setText("BIN");
    this.bin.setFocusPainted(false);
    this.bin.setFocusable(false);
    this.bin.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.binActionPerformed(evt);
          }
        });
    this.jButton12.setText("Export");
    this.jButton12.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton12ActionPerformed(evt);
          }
        });
    this.buttonGroup1.add(this.jToggleButton1);
    this.jToggleButton1.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/ico/mouse.gif")));
    this.jToggleButton1.setSelected(true);
    this.buttonGroup1.add(this.paint);
    this.paint.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/ico/pixel.gif")));
    this.jButton1.setText("Copy");
    this.jButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton1ActionPerformed(evt);
          }
        });
    this.jButton17.setText("Paste");
    this.jButton17.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton17ActionPerformed(evt);
          }
        });
    this.jButton25.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/pngimage.png")));
    this.jButton25.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton25ActionPerformed(evt);
          }
        });
    this.jPanel3.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel3.setLayout(new FlowLayout(1, 1, 0));
    this.button1.setFont(new Font("Monospaced", 1, 11));
    this.button1.setLabel("00");
    this.button1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button1ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button1);
    this.button2.setFont(new Font("Monospaced", 1, 11));
    this.button2.setLabel("01");
    this.button2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button2ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button2);
    this.button3.setFont(new Font("Monospaced", 1, 11));
    this.button3.setLabel("02");
    this.button3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button3ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button3);
    this.button4.setFont(new Font("Monospaced", 1, 11));
    this.button4.setLabel("03");
    this.button4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button4ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button4);
    this.button5.setFont(new Font("Monospaced", 1, 11));
    this.button5.setLabel("04");
    this.button5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button5ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button5);
    this.button6.setFont(new Font("Monospaced", 1, 11));
    this.button6.setLabel("05");
    this.button6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button6ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button6);
    this.button7.setFont(new Font("Monospaced", 1, 11));
    this.button7.setLabel("06");
    this.button7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button7ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button7);
    this.button8.setFont(new Font("Monospaced", 1, 11));
    this.button8.setLabel("07");
    this.button8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button8ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button8);
    this.button9.setFont(new Font("Monospaced", 1, 11));
    this.button9.setLabel("08");
    this.button9.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button9ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button9);
    this.button10.setFont(new Font("Monospaced", 1, 11));
    this.button10.setLabel("09");
    this.button10.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button10ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button10);
    this.button11.setFont(new Font("Monospaced", 1, 11));
    this.button11.setLabel("10");
    this.button11.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button11ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button11);
    this.button12.setFont(new Font("Monospaced", 1, 11));
    this.button12.setLabel("11");
    this.button12.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button12ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button12);
    this.button13.setFont(new Font("Monospaced", 1, 11));
    this.button13.setLabel("12");
    this.button13.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button13ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button13);
    this.button14.setFont(new Font("Monospaced", 1, 11));
    this.button14.setLabel("13");
    this.button14.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button14ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button14);
    this.button15.setFont(new Font("Monospaced", 1, 11));
    this.button15.setLabel("14");
    this.button15.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button15ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button15);
    this.button16.setFont(new Font("Monospaced", 1, 11));
    this.button16.setLabel("15");
    this.button16.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.button16ActionPerformed(evt);
          }
        });
    this.jPanel3.add(this.button16);
    GroupLayout jPanel7Layout = new GroupLayout(this.jPanel7);
    this.jPanel7.setLayout(jPanel7Layout);
    jPanel7Layout.setHorizontalGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel7Layout.createSequentialGroup().addContainerGap().addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel3, -2, 252, -2).addGroup(jPanel7Layout.createSequentialGroup().addComponent(this.jToggleButton1, -2, 26, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.paint, -2, 26, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton17).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton25, -2, 26, -2)).addGroup(jPanel7Layout.createSequentialGroup().addComponent(this.jButton12).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.bin).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.header).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton20))).addContainerGap(25, 32767)));
    jPanel7Layout.setVerticalGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel7Layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel3, -2, 50, -2).addGap(6, 6, 6).addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton1, -2, 25, -2).addComponent(this.jButton17, -2, 25, -2).addComponent(this.jButton25, -2, 25, -2)).addComponent(this.jToggleButton1, -2, 25, -2).addComponent(this.paint, -2, 25, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton12).addComponent(this.bin).addComponent(this.header).addComponent(this.jButton20)).addContainerGap(-1, 32767)));
    this.jPanel1.add(this.jPanel7, "South");
    this.jButton19.setText("Copy");
    this.jButton19.setFocusPainted(false);
    this.jButton19.setFocusable(false);
    this.jButton19.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton19ActionPerformed(evt);
          }
        });
    setTitle("JavaCPC GFXViewer");
    setMinimumSize(new Dimension(853, 524));
    addWindowStateListener(new WindowStateListener() {
          public void windowStateChanged(WindowEvent evt) {
            GraphicsViewer.this.formWindowStateChanged(evt);
          }
        });
    this.jPanel2.setBorder(new SoftBevelBorder(0));
    this.jPanel2.setLayout(new FlowLayout(0));
    this.jLabel8.setText("Address:");
    this.jPanel2.add(this.jLabel8);
    this.aaddress.setEditable(false);
    this.aaddress.setColumns(4);
    this.aaddress.setHorizontalAlignment(2);
    this.aaddress.setText("429C");
    this.aaddress.setBorder((Border)null);
    this.jPanel2.add(this.aaddress);
    this.jButton23.setText("Mapper");
    this.jButton23.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton23ActionPerformed(evt);
          }
        });
    this.jPanel2.add(this.jButton23);
    this.jButton26.setText("Make GIF");
    this.jButton26.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton26ActionPerformed(evt);
          }
        });
    this.jPanel2.add(this.jButton26);
    this.nozoom.setText("No AutoZoom");
    this.jPanel2.add(this.nozoom);
    this.jButton24.setText("Import Mapinfo");
    this.jButton24.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton24ActionPerformed(evt);
          }
        });
    this.jPanel2.add(this.jButton24);
    this.jLabel13.setText("Max. Tiles:");
    this.jPanel2.add(this.jLabel13);
    this.maxtiles.setMajorTickSpacing(1024);
    this.maxtiles.setMaximum(4096);
    this.maxtiles.setMinorTickSpacing(256);
    this.maxtiles.setPaintTicks(true);
    this.maxtiles.setSnapToTicks(true);
    this.maxtiles.setValue(768);
    this.maxtiles.setPreferredSize(new Dimension(100, 31));
    this.maxtiles.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent evt) {
            GraphicsViewer.this.maxtilesStateChanged(evt);
          }
        });
    this.jPanel2.add(this.maxtiles);
    this.tiles.setHorizontalAlignment(4);
    this.tiles.setText("768");
    this.tiles.setPreferredSize(new Dimension(32, 14));
    this.jPanel2.add(this.tiles);
    this.jPanel4.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel4.setLayout(new FlowLayout(0));
    this.jLabel1.setText("Width:");
    this.jPanel4.add(this.jLabel1);
    this.jButton2.setFont(new Font("Monospaced", 1, 11));
    this.jButton2.setText("-");
    this.jButton2.setBorder(BorderFactory.createBevelBorder(0));
    this.jButton2.setFocusPainted(false);
    this.jButton2.setFocusable(false);
    this.jButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton2ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jButton2);
    this.widthfield.setColumns(3);
    this.widthfield.setHorizontalAlignment(4);
    this.widthfield.setText("4");
    this.widthfield.addKeyListener(new KeyAdapter() {
          public void keyReleased(KeyEvent evt) {
            GraphicsViewer.this.widthfieldKeyReleased(evt);
          }
        });
    this.jPanel4.add(this.widthfield);
    this.jButton3.setFont(new Font("Monospaced", 1, 11));
    this.jButton3.setText("+");
    this.jButton3.setBorder(BorderFactory.createBevelBorder(0));
    this.jButton3.setFocusPainted(false);
    this.jButton3.setFocusable(false);
    this.jButton3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton3ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jButton3);
    this.jLabel5.setText("Height:");
    this.jPanel4.add(this.jLabel5);
    this.jButton5.setFont(new Font("Monospaced", 1, 11));
    this.jButton5.setText("-");
    this.jButton5.setBorder(BorderFactory.createBevelBorder(0));
    this.jButton5.setFocusPainted(false);
    this.jButton5.setFocusable(false);
    this.jButton5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton5ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jButton5);
    this.heightfield.setColumns(3);
    this.heightfield.setHorizontalAlignment(4);
    this.heightfield.setText("4");
    this.heightfield.addKeyListener(new KeyAdapter() {
          public void keyReleased(KeyEvent evt) {
            GraphicsViewer.this.heightfieldKeyReleased(evt);
          }
        });
    this.jPanel4.add(this.heightfield);
    this.jButton4.setFont(new Font("Monospaced", 1, 11));
    this.jButton4.setText("+");
    this.jButton4.setBorder(BorderFactory.createBevelBorder(0));
    this.jButton4.setFocusPainted(false);
    this.jButton4.setFocusable(false);
    this.jButton4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton4ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jButton4);
    this.jLabel7.setText("Zoom:");
    this.jPanel4.add(this.jLabel7);
    this.jButton10.setFont(new Font("Monospaced", 1, 11));
    this.jButton10.setText("-");
    this.jButton10.setBorder(BorderFactory.createBevelBorder(0));
    this.jButton10.setFocusPainted(false);
    this.jButton10.setFocusable(false);
    this.jButton10.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton10ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jButton10);
    this.zm.setColumns(2);
    this.zm.setHorizontalAlignment(4);
    this.zm.setText("4");
    this.zm.addKeyListener(new KeyAdapter() {
          public void keyReleased(KeyEvent evt) {
            GraphicsViewer.this.zmKeyReleased(evt);
          }
        });
    this.jPanel4.add(this.zm);
    this.jButton11.setFont(new Font("Monospaced", 1, 11));
    this.jButton11.setText("+");
    this.jButton11.setBorder(BorderFactory.createBevelBorder(0));
    this.jButton11.setFocusPainted(false);
    this.jButton11.setFocusable(false);
    this.jButton11.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton11ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jButton11);
    this.jSeparator1.setOrientation(1);
    this.jSeparator1.setPreferredSize(new Dimension(4, 22));
    this.jPanel4.add(this.jSeparator1);
    this.jButton21.setText("Export");
    this.jButton21.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton21ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jButton21);
    this.bin1.setText("BIN");
    this.bin1.setFocusPainted(false);
    this.bin1.setFocusable(false);
    this.bin1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.bin1ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.bin1);
    this.header1.setText("Header");
    this.header1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.header1ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.header1);
    this.jButton22.setText("Export ASM");
    this.jButton22.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton22ActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.jButton22);
    this.format.setSelected(true);
    this.format.setText("Store Format");
    this.format.setFocusable(false);
    this.format.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.formatActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.format);
    this.grid.setSelected(true);
    this.grid.setText("Grid");
    this.grid.setFocusPainted(false);
    this.grid.setFocusable(false);
    this.grid.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.gridActionPerformed(evt);
          }
        });
    this.jPanel4.add(this.grid);
    this.jLabel12.setText("Skip bytes:");
    this.jPanel4.add(this.jLabel12);
    this.jSpinner1.setMinimumSize(new Dimension(50, 20));
    this.jSpinner1.setPreferredSize(new Dimension(50, 20));
    this.jSpinner1.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent evt) {
            GraphicsViewer.this.jSpinner1StateChanged(evt);
          }
        });
    this.jPanel4.add(this.jSpinner1);
    this.jPanel5.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel5.setLayout(new FlowLayout(0));
    this.jLabel2.setText("Address: (&)");
    this.jPanel5.add(this.jLabel2);
    this.jButton8.setFont(new Font("Monospaced", 1, 11));
    this.jButton8.setText("-");
    this.jButton8.setBorder(BorderFactory.createBevelBorder(0));
    this.jButton8.setFocusPainted(false);
    this.jButton8.setFocusable(false);
    this.jButton8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton8ActionPerformed(evt);
          }
        });
    this.jPanel5.add(this.jButton8);
    this.address.setColumns(4);
    this.address.setHorizontalAlignment(4);
    this.address.setText("0000");
    this.address.addKeyListener(new KeyAdapter() {
          public void keyReleased(KeyEvent evt) {
            GraphicsViewer.this.addressKeyReleased(evt);
          }
        });
    this.jPanel5.add(this.address);
    this.jButton9.setFont(new Font("Monospaced", 1, 11));
    this.jButton9.setText("+");
    this.jButton9.setBorder(BorderFactory.createBevelBorder(0));
    this.jButton9.setFocusPainted(false);
    this.jButton9.setFocusable(false);
    this.jButton9.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton9ActionPerformed(evt);
          }
        });
    this.jPanel5.add(this.jButton9);
    this.step.setText("Step field");
    this.step.setFocusPainted(false);
    this.step.setFocusable(false);
    this.step.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.stepActionPerformed(evt);
          }
        });
    this.jPanel5.add(this.step);
    this.line.setText("Step line");
    this.line.setFocusPainted(false);
    this.line.setFocusable(false);
    this.line.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.lineActionPerformed(evt);
          }
        });
    this.jPanel5.add(this.line);
    this.jButton6.setText("Mode");
    this.jButton6.setFocusPainted(false);
    this.jButton6.setFocusable(false);
    this.jButton6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton6ActionPerformed(evt);
          }
        });
    this.jPanel5.add(this.jButton6);
    this.jLabel6.setFont(new Font("Monospaced", 1, 11));
    this.jLabel6.setText("1");
    this.jPanel5.add(this.jLabel6);
    this.jButton7.setText("Get");
    this.jButton7.setFocusPainted(false);
    this.jButton7.setFocusable(false);
    this.jButton7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jButton7ActionPerformed(evt);
          }
        });
    this.jPanel5.add(this.jButton7);
    this.linear.setText("Linear");
    this.linear.setFocusPainted(false);
    this.linear.setFocusable(false);
    this.linear.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.linearActionPerformed(evt);
          }
        });
    this.jPanel5.add(this.linear);
    this.reverse.setText("Reverse");
    this.reverse.setFocusPainted(false);
    this.reverse.setFocusable(false);
    this.reverse.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.reverseActionPerformed(evt);
          }
        });
    this.jPanel5.add(this.reverse);
    this.Screen.setText("Screen");
    this.Screen.setFocusPainted(false);
    this.Screen.setFocusable(false);
    this.Screen.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.ScreenActionPerformed(evt);
          }
        });
    this.jPanel5.add(this.Screen);
    this.rom.setText("ROM");
    this.rom.setFocusPainted(false);
    this.rom.setFocusable(false);
    this.rom.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.romActionPerformed(evt);
          }
        });
    this.jPanel5.add(this.rom);
    this.skipscreen.setText("Skip screen");
    this.skipscreen.setFocusPainted(false);
    this.skipscreen.setFocusable(false);
    this.skipscreen.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.skipscreenActionPerformed(evt);
          }
        });
    this.jPanel5.add(this.skipscreen);
    this.bank.setModel(new DefaultComboBoxModel<>(new String[] { "C0", "C4", "C5", "C6", "C7" }));
    this.bank.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent evt) {
            GraphicsViewer.this.bankItemStateChanged(evt);
          }
        });
    this.jPanel5.add(this.bank);
    this.jCheckBox2.setText("Auto Update");
    this.jCheckBox2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GraphicsViewer.this.jCheckBox2ActionPerformed(evt);
          }
        });
    this.jPanel5.add(this.jCheckBox2);
    this.viewPort.setBorder(new SoftBevelBorder(1));
    this.viewPort.setMaximumSize(new Dimension(800, 32767));
    this.viewPort.setMinimumSize(new Dimension(100, 100));
    this.viewPort.setPreferredSize(new Dimension(800, 500));
    this.viewPort.setLayout(new FlowLayout(1, 0, 0));
    this.jScrollPane1.setViewportView(this.viewPort);
    GroupLayout jPanel9Layout = new GroupLayout(this.jPanel9);
    this.jPanel9.setLayout(jPanel9Layout);
    jPanel9Layout.setHorizontalGroup(jPanel9Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel9Layout.createSequentialGroup().addContainerGap().addGroup(jPanel9Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel2, -1, 991, 32767).addComponent(this.jPanel5, -1, 991, 32767).addComponent(this.jPanel4, -1, 991, 32767).addComponent(this.jScrollPane1)).addContainerGap()));
    jPanel9Layout.setVerticalGroup(jPanel9Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel9Layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel5, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel4, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane1, -1, 444, 32767).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel2, -2, -1, -2).addContainerGap()));
    getContentPane().add(this.jPanel9, "Center");
    pack();
  }
  
  private void jButton2ActionPerformed(ActionEvent evt) {
    if (this.width > 1) {
      this.width--;
      Show();
    } 
    this.widthfield.setText("" + this.width);
  }
  
  private void jButton3ActionPerformed(ActionEvent evt) {
    if (this.width < 300) {
      this.width++;
      Show();
    } 
    this.widthfield.setText("" + this.width);
  }
  
  private void jButton5ActionPerformed(ActionEvent evt) {
    if (this.height > 1) {
      this.height--;
      Show();
    } 
    this.heightfield.setText("" + this.height);
  }
  
  private void jButton4ActionPerformed(ActionEvent evt) {
    if (this.height < 2048) {
      this.height++;
      Show();
    } 
    this.heightfield.setText("" + this.height);
  }
  
  private void jButton6ActionPerformed(ActionEvent evt) {
    this.mode++;
    if (this.mode == 4)
      this.mode = 0; 
    Show();
    this.jLabel6.setText("" + this.mode);
  }
  
  private void jButton7ActionPerformed(ActionEvent evt) {
    this.mode = GateArray.getSMode();
    this.jLabel6.setText("" + this.mode);
    Show();
  }
  
  public void keyPress(int code) {
    if (this.mapper != null)
      this.mapper.keyPress(code); 
  }
  
  public void keyRelease(int code) {
    if (this.mapper != null)
      this.mapper.keyRelease(code); 
  }
  
  private void importMap() {
    if (this.importer == null)
      this.importer = new FileDialog(this, "Import map info", 0); 
    this.importer.setFile("*.txt");
    this.importer.setVisible(true);
    if (this.importer.getFile() != null) {
      String g = this.importer.getDirectory() + this.importer.getFile();
      try {
        File f = new File(g);
        byte[] data = new byte[(int)f.length()];
        BufferedInputStream bin = new BufferedInputStream(new FileInputStream(f));
        bin.read(data);
        bin.close();
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < data.length; i++)
          s.append((char)(data[i] & 0xFF)); 
        String result = s.toString();
        if (!result.startsWith("TileAddress"))
          return; 
        result = result.replace("\r", "");
        this.mapinfo = result.split("\n");
        for (int j = 0; j < this.mapinfo.length; j++) {
          this.mapinfo[j] = this.mapinfo[j].substring(13);
          this.mapinfo[j] = this.mapinfo[j].replace("&", "");
          System.out.println(this.mapinfo[j]);
        } 
        if (this.mapper == null)
          this.mapper = new Mapper(); 
        this.mapper.setInfo(this.mapinfo[4], this.mapinfo[5], this.mapinfo[6]);
        this.address.setText(this.mapinfo[0]);
        this.widthfield.setText(this.mapinfo[2]);
        this.heightfield.setText(this.mapinfo[3]);
        this.width = Integer.parseInt(this.mapinfo[2]);
        this.height = Integer.parseInt(this.mapinfo[3]);
        if (this.mapinfo.length > 7) {
          this.mode = Integer.parseInt(this.mapinfo[7]);
          this.jLabel6.setText("" + this.mode);
        } 
        if (this.mapinfo.length > 8)
          this.linear.setSelected((Integer.parseInt(this.mapinfo[8]) != 0)); 
        this.bit16 = this.skip = false;
        if (this.mapinfo.length > 9) {
          this.bit16 = (Integer.parseInt(this.mapinfo[9]) != 0);
          this.skip = (Integer.parseInt(this.mapinfo[10]) != 0);
        } 
        this.zoom = 1;
        this.zm.setText("1");
        this.range = Integer.parseInt(this.mapinfo[1]) - 1;
        this.to = 0;
        Show();
      } catch (Exception exception) {}
    } 
  }
  
  private void generateMap() {
    try {
      int adr = Util.hexValue(this.address.getText());
      int wi = Integer.parseInt(this.widthfield.getText());
      int he = Integer.parseInt(this.heightfield.getText());
      int selected = 0;
      if (this.range > this.to) {
        selected = this.range - this.to;
      } else {
        selected = this.to - this.range;
      } 
      selected++;
      if (this.mapper == null)
        this.mapper = new Mapper(); 
      this.mapper.initMapper(selected, adr, wi, he, this.screen, this.mode, this.linear.isSelected(), this.bit16, this.skip);
      this.mapper.setVisible(true);
    } catch (Exception exception) {}
  }
  
  private void generateGif() {
    try {
      int adr = Util.hexValue(this.address.getText());
      int wi = Integer.parseInt(this.widthfield.getText());
      int he = Integer.parseInt(this.heightfield.getText());
      int selected = 0;
      if (this.range > this.to) {
        selected = this.range - this.to;
      } else {
        selected = this.to - this.range;
      } 
      selected++;
      this.gmaker.initMapper(selected, adr, wi, he, this.screen, this.mode, this.linear.isSelected(), this.bit16, this.skip);
      this.gmaker.prev.setIcon(new ImageIcon(this.gmaker.screen[0]));
      this.gmaker.setVisible(true);
      this.gmaker.play();
    } catch (Exception exception) {}
  }
  
  private void jButton8ActionPerformed(ActionEvent evt) {
    try {
      int skip = Integer.parseInt(this.jSpinner1.getValue().toString());
      int adr = Util.hexValue(this.address.getText());
      if (this.step.isSelected()) {
        adr -= this.width * this.height;
        adr -= skip;
      } else if (this.line.isSelected()) {
        adr -= this.width;
      } else {
        adr--;
      } 
      if (adr < 0)
        adr = 65535; 
      this.address.setText(Util.hex((short)adr));
      Show();
    } catch (Exception exception) {}
  }
  
  private void jButton9ActionPerformed(ActionEvent evt) {
    try {
      int skip = Integer.parseInt(this.jSpinner1.getValue().toString());
      int adr = Util.hexValue(this.address.getText());
      if (this.step.isSelected()) {
        adr += this.width * this.height;
        adr += skip;
      } else if (this.line.isSelected()) {
        adr += this.width;
      } else {
        adr++;
      } 
      if (adr > 65535)
        adr = 0; 
      this.address.setText(Util.hex((short)adr));
      Show();
    } catch (Exception exception) {}
  }
  
  private void gridActionPerformed(ActionEvent evt) {
    Show();
  }
  
  private void jButton10ActionPerformed(ActionEvent evt) {
    if (this.zoom > 1)
      this.zoom--; 
    this.zm.setText("" + this.zoom);
    Show();
  }
  
  private void jButton11ActionPerformed(ActionEvent evt) {
    if (this.zoom < 10)
      this.zoom++; 
    this.zm.setText("" + this.zoom);
    Show();
  }
  
  private void jButton12ActionPerformed(ActionEvent evt) {
    export();
  }
  
  private void addressKeyReleased(KeyEvent evt) {
    try {
      String ad = this.address.getText();
      int add = 0;
      try {
        add = Util.hexValue(ad);
      } catch (Exception e) {
        add = 0;
      } 
      if (add > 65535)
        add = 0; 
      this.address.setText(Util.hex((short)add));
      Show();
    } catch (Exception exception) {}
  }
  
  private void button1ActionPerformed(ActionEvent evt) {
    this.gpen = 0;
  }
  
  private void button2ActionPerformed(ActionEvent evt) {
    this.gpen = 1;
  }
  
  private void button3ActionPerformed(ActionEvent evt) {
    this.gpen = 2;
  }
  
  private void button4ActionPerformed(ActionEvent evt) {
    this.gpen = 3;
  }
  
  private void button5ActionPerformed(ActionEvent evt) {
    this.gpen = 4;
  }
  
  private void button6ActionPerformed(ActionEvent evt) {
    this.gpen = 5;
  }
  
  private void button7ActionPerformed(ActionEvent evt) {
    this.gpen = 6;
  }
  
  private void button8ActionPerformed(ActionEvent evt) {
    this.gpen = 7;
  }
  
  private void button9ActionPerformed(ActionEvent evt) {
    this.gpen = 8;
  }
  
  private void button10ActionPerformed(ActionEvent evt) {
    this.gpen = 9;
  }
  
  private void button11ActionPerformed(ActionEvent evt) {
    this.gpen = 10;
  }
  
  private void button12ActionPerformed(ActionEvent evt) {
    this.gpen = 11;
  }
  
  private void button13ActionPerformed(ActionEvent evt) {
    this.gpen = 12;
  }
  
  private void button14ActionPerformed(ActionEvent evt) {
    this.gpen = 13;
  }
  
  private void button15ActionPerformed(ActionEvent evt) {
    this.gpen = 14;
  }
  
  private void button16ActionPerformed(ActionEvent evt) {
    this.gpen = 15;
  }
  
  private void binActionPerformed(ActionEvent evt) {
    this.bin1.setSelected(this.bin.isSelected());
    this.header.setEnabled(this.bin.isSelected());
    this.header1.setEnabled(this.bin.isSelected());
  }
  
  private void stepActionPerformed(ActionEvent evt) {
    if (this.step.isSelected())
      this.line.setSelected(false); 
  }
  
  private void lineActionPerformed(ActionEvent evt) {
    if (this.line.isSelected())
      this.step.setSelected(false); 
  }
  
  private void jButton13ActionPerformed(ActionEvent evt) {
    if (this.pzoom > 1)
      this.pzoom--; 
    updateScreen(this.screen[this.expindex]);
  }
  
  private void jButton14ActionPerformed(ActionEvent evt) {
    if (this.pzoom < 5) {
      this.pzoom++;
      updateScreen(this.screen[this.expindex]);
    } 
  }
  
  private void jButton15ActionPerformed(ActionEvent evt) {
    moveBack();
  }
  
  private void jButton16ActionPerformed(ActionEvent evt) {
    moveForward();
  }
  
  private void formWindowStateChanged(WindowEvent evt) {
    Show();
  }
  
  private void linearActionPerformed(ActionEvent evt) {
    if (this.linear.isSelected() && this.reverse.isSelected())
      this.reverse.setSelected(false); 
    if (this.linear.isSelected() && this.Screen.isSelected())
      this.Screen.setSelected(false); 
    Show();
  }
  
  private void skipscreenActionPerformed(ActionEvent evt) {
    Show();
  }
  
  private void jButton1ActionPerformed(ActionEvent evt) {
    copy();
  }
  
  private void jButton17ActionPerformed(ActionEvent evt) {
    paste();
  }
  
  private void jButton18ActionPerformed(ActionEvent evt) {
    paste();
  }
  
  private void jButton19ActionPerformed(ActionEvent evt) {
    copy();
  }
  
  private void widthfieldKeyReleased(KeyEvent evt) {
    try {
      int z = Integer.parseInt(this.widthfield.getText());
      if (z < 1) {
        this.widthfield.setText("" + z);
        z = 1;
      } 
      if (z > 500) {
        this.widthfield.setText("" + z);
        z = 500;
      } 
      this.width = z;
      Show();
    } catch (Exception exception) {}
  }
  
  private void heightfieldKeyReleased(KeyEvent evt) {
    try {
      int z = Integer.parseInt(this.heightfield.getText());
      if (z < 1) {
        this.heightfield.setText("" + z);
        z = 1;
      } 
      if (z > 500) {
        this.heightfield.setText("" + z);
        z = 500;
      } 
      this.height = z;
      Show();
    } catch (Exception exception) {}
  }
  
  private void zmKeyReleased(KeyEvent evt) {
    try {
      int z = Integer.parseInt(this.zm.getText());
      if (z < 1) {
        this.zm.setText("" + z);
        z = 1;
      } 
      if (z > 20) {
        this.zm.setText("" + z);
        z = 20;
      } 
      this.zoom = z;
      Show();
    } catch (Exception exception) {}
  }
  
  private void romActionPerformed(ActionEvent evt) {
    Show();
  }
  
  private void jButton20ActionPerformed(ActionEvent evt) {
    exportASM();
  }
  
  private void jButton21ActionPerformed(ActionEvent evt) {
    export();
  }
  
  private void bin1ActionPerformed(ActionEvent evt) {
    this.bin.setSelected(this.bin1.isSelected());
    this.header1.setEnabled(this.bin.isSelected());
    this.header.setEnabled(this.bin.isSelected());
  }
  
  private void jButton22ActionPerformed(ActionEvent evt) {
    exportASM();
  }
  
  private void headerActionPerformed(ActionEvent evt) {
    this.header1.setSelected(this.header.isSelected());
  }
  
  private void header1ActionPerformed(ActionEvent evt) {
    this.header.setSelected(this.header1.isSelected());
  }
  
  private void jCheckBox2ActionPerformed(ActionEvent evt) {
    this.autoupdate = this.jCheckBox2.isSelected();
    if (this.autoupdate) {
      this.fire.start();
    } else {
      this.fire.stop();
    } 
  }
  
  private void jSpinner1StateChanged(ChangeEvent evt) {
    String d = this.jSpinner1.getValue().toString();
    int k = Integer.parseInt(d);
    if (k < 0)
      this.jSpinner1.setValue(Integer.valueOf(999)); 
    if (k > 999)
      this.jSpinner1.setValue(Integer.valueOf(0)); 
    Show();
  }
  
  private void jButton23ActionPerformed(ActionEvent evt) {
    generateMap();
  }
  
  private void jButton24ActionPerformed(ActionEvent evt) {
    importMap();
  }
  
  private void maxtilesStateChanged(ChangeEvent evt) {
    int v = this.maxtiles.getValue() / 256 * 256;
    if (v != 0) {
      this.tiles.setText("" + v);
    } else {
      this.tiles.setText("∞");
    } 
  }
  
  private void reverseActionPerformed(ActionEvent evt) {
    if (this.linear.isSelected() && this.reverse.isSelected())
      this.linear.setSelected(false); 
    if (this.reverse.isSelected() && this.Screen.isSelected())
      this.Screen.setSelected(false); 
    Show();
  }
  
  private void ScreenActionPerformed(ActionEvent evt) {
    if (this.linear.isSelected() && this.Screen.isSelected())
      this.linear.setSelected(false); 
    if (this.reverse.isSelected() && this.Screen.isSelected())
      this.reverse.setSelected(false); 
    if (this.Screen.isSelected()) {
      this.heightfield.setText("8");
      this.height = 8;
      int[] val = { (GateArray.cpc.getGateArray()).crtc.getReg(13), (GateArray.cpc.getGateArray()).crtc.getReg(12) };
      int CRTC = Device.getWord(val, 0);
      CRTC = (CRTC & 0x3FF) * 2 + (CRTC & 0x3000) * 4;
      this.address.setText(Util.hex((short)CRTC));
    } 
    Show();
  }
  
  private void jButton25ActionPerformed(ActionEvent evt) {
    importPNG();
  }
  
  private void jButton26ActionPerformed(ActionEvent evt) {
    generateGif();
  }
  
  private void bankItemStateChanged(ItemEvent evt) {
    Show();
  }
  
  private void formatActionPerformed(ActionEvent evt) {}
  
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new GraphicsViewer()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\GraphicsViewer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */