package jemu.system.cpc;

import jemu.core.device.floppy.UPD765A;

public class CPCDiscImageTrack {
  private final int track;
  
  private int side;
  
  private final int length;
  
  private CPCDiscImageSector[] sectors;
  
  public CPCDiscImageTrack(int track, int side, int length, int numberOfSectors) {
    this.track = track;
    this.side = side;
    this.length = length;
    this.sectors = new CPCDiscImageSector[numberOfSectors];
  }
  
  public void removeAllSectorsFromTrack() {
    this.sectors = new CPCDiscImageSector[0];
  }
  
  public void addSectorToTrack(int sectorTrack, int sectorSide, int sectorId, int sectorSize, int fillerByte) {
    CPCDiscImageSector[] newsectors = new CPCDiscImageSector[this.sectors.length + 1];
    for (int i = 0; i < this.sectors.length; i++) {
      CPCDiscImageSector sect = this.sectors[i];
      newsectors[i] = new CPCDiscImageSector(sect.getTrack(), sect.getSide(), sect
          .getId(), sect.getSize(), sect.getData(), sect.getST1(), sect.getST2());
    } 
    this.sectors = newsectors;
    int bytes = UPD765A.getSectorSize(sectorSize);
    byte[] sectData = new byte[bytes];
    for (int j = 0; j < bytes; j++)
      sectData[j] = (byte)fillerByte; 
    setSector(new CPCDiscImageSector(sectorTrack, sectorSide, sectorId, sectorSize, sectData, 0, 0), newsectors.length - 1);
  }
  
  public void setSector(CPCDiscImageSector sector, int index) {
    this.sectors[index] = sector;
  }
  
  public CPCDiscImageSector getSector(int index) {
    return this.sectors[index];
  }
  
  public int getSectorCount() {
    return this.sectors.length;
  }
  
  public int[] getSectorIDs(int index) {
    int[] result = new int[4];
    result[0] = this.sectors[index].getTrack();
    result[1] = this.sectors[index].getSide();
    result[2] = this.sectors[index].getId();
    result[3] = this.sectors[index].getSize();
    return result;
  }
  
  public int getTrack() {
    return this.track;
  }
  
  public int getSide() {
    return this.side;
  }
  
  public int getLength() {
    return this.length;
  }
  
  public void setSectorData(int sectorTrack, int sectorSide, int sectorId, int sectorSize, byte[] data) {
    for (int i = 0; i < this.sectors.length; i++) {
      CPCDiscImageSector sect = this.sectors[i];
      if (sect.getTrack() == sectorTrack && sect.getSide() == sectorSide && sect.getId() == sectorId && sect.getSize() == sectorSize) {
        sect.setData(data);
        break;
      } 
    } 
  }
  
  public byte[] getSectorData(int sectorTrack, int sectorSide, int sectorId, int sectorSize) {
    for (int i = 0; i < this.sectors.length; i++) {
      CPCDiscImageSector sect = this.sectors[i];
      if (sect.getTrack() == sectorTrack && sect.getId() == sectorId && sect.getSize() == sectorSize)
        return sect.getData(); 
      if (sect.getTrack() == sectorTrack && sect.getId() == sectorId && sect.getSize() != 0)
        try {
          return sect.getData();
        } catch (Exception exception) {} 
    } 
    return null;
  }
  
  public int getST1(int sectorTrack, int sectorSide, int sectorId, int sectorSize) {
    for (int i = 0; i < this.sectors.length; i++) {
      CPCDiscImageSector sect = this.sectors[i];
      if (sect.getTrack() == sectorTrack && sect.getId() == sectorId && sect.getSize() == sectorSize)
        return sect.getST1(); 
    } 
    return 0;
  }
  
  public int getST2(int sectorTrack, int sectorSide, int sectorId, int sectorSize) {
    for (int i = 0; i < this.sectors.length; i++) {
      CPCDiscImageSector sect = this.sectors[i];
      if (sect.getTrack() == sectorTrack && sect.getId() == sectorId && sect.getSize() == sectorSize)
        return sect.getST2(); 
    } 
    return 0;
  }
  
  public void setST1(int sectorTrack, int sectorSide, int sectorId, int sectorSize, int st1) {
    for (int i = 0; i < this.sectors.length; i++) {
      CPCDiscImageSector sect = this.sectors[i];
      if (sect.getTrack() == sectorTrack && sect.getId() == sectorId && sect.getSize() == sectorSize)
        sect.setST1(st1); 
    } 
  }
  
  public void setST2(int sectorTrack, int sectorSide, int sectorId, int sectorSize, int st2) {
    for (int i = 0; i < this.sectors.length; i++) {
      CPCDiscImageSector sect = this.sectors[i];
      if (sect.getTrack() == sectorTrack && sect.getId() == sectorId && sect.getSize() == sectorSize)
        sect.setST2(st2); 
    } 
  }
  
  public void setSide(int side) {
    this.side = side;
    for (int i = 0; i < this.sectors.length; i++)
      this.sectors[i].setSide(side); 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\CPCDiscImageTrack.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */