package jemu.system.cpc;

import java.awt.FileDialog;
import java.awt.Frame;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import javax.swing.JOptionPane;

public class CPCDiscImageMerger {
  public static void merge() {
    Frame frame = new Frame();
    FileDialog filedia1 = new FileDialog(frame, "Select first dsk file...", 0);
    filedia1.setFile("*.dsk");
    filedia1.setVisible(true);
    String filename1 = filedia1.getFile();
    if (filename1 != null) {
      filename1 = filedia1.getDirectory() + filedia1.getFile();
      String firstFileName = filename1;
      FileDialog filedia2 = new FileDialog(frame, "Select second dsk file...", 0);
      filedia2.setFile("*.dsk");
      filedia2.setVisible(true);
      String filename2 = filedia2.getFile();
      if (filename2 != null) {
        filename2 = filedia2.getDirectory() + filedia2.getFile();
        String secondFileName = filename2;
        FileDialog filedia3 = new FileDialog(frame, "Select destination dsk file...", 1);
        filedia3.setFile("*.dsk");
        filedia3.setVisible(true);
        String filename3 = filedia3.getFile();
        if (filename3 != null) {
          filename3 = filedia3.getDirectory() + filedia3.getFile();
          String newFileName = filename3;
          if (!newFileName.toLowerCase().endsWith(".dsk"))
            newFileName = newFileName + ".dsk"; 
          try {
            CPCDiscImageForMerge firstImage = openImage(firstFileName);
            CPCDiscImageForMerge secondImage = openImage(secondFileName);
            CPCDiscImageForMerge newImage = new CPCDiscImageForMerge(newFileName, firstImage, secondImage);
            newImage.saveImage();
          } catch (IOException iox) {
            JOptionPane.showMessageDialog(null, iox.getMessage(), "Guru meditation!", 0);
          } 
        } 
      } 
    } 
  }
  
  private static CPCDiscImageForMerge openImage(String fileName) throws IOException {
    BufferedInputStream bis = new BufferedInputStream(new FileInputStream(fileName));
    return CPCDiscImageForMerge.create(fileName, bis);
  }
  
  public static void main(String[] args) {
    Frame frame = new Frame();
    FileDialog filedia1 = new FileDialog(frame, "Select first dsk file...", 0);
    filedia1.setFile("*.dsk");
    filedia1.setVisible(true);
    String filename1 = filedia1.getFile();
    if (filename1 == null)
      System.exit(0); 
    if (filename1 != null) {
      filename1 = filedia1.getDirectory() + filedia1.getFile();
      String firstFileName = filename1;
      FileDialog filedia2 = new FileDialog(frame, "Select second dsk file...", 0);
      filedia2.setFile("*.dsk");
      filedia2.setVisible(true);
      String filename2 = filedia2.getFile();
      if (filename2 == null)
        System.exit(0); 
      if (filename2 != null) {
        filename2 = filedia2.getDirectory() + filedia2.getFile();
        String secondFileName = filename2;
        FileDialog filedia3 = new FileDialog(frame, "Select destination dsk file...", 1);
        filedia3.setFile("*.dsk");
        filedia3.setVisible(true);
        String filename3 = filedia3.getFile();
        if (filename3 == null)
          System.exit(0); 
        if (filename3 != null) {
          filename3 = filedia3.getDirectory() + filedia3.getFile();
          String newFileName = filename3;
          if (!newFileName.toLowerCase().endsWith(".dsk"))
            newFileName = newFileName + ".dsk"; 
          try {
            CPCDiscImageForMerge firstImage = openImage(firstFileName);
            CPCDiscImageForMerge secondImage = openImage(secondFileName);
            CPCDiscImageForMerge newImage = new CPCDiscImageForMerge(newFileName, firstImage, secondImage);
            newImage.saveImage();
          } catch (IOException iox) {
            JOptionPane.showMessageDialog(null, iox.getMessage(), "Guru meditation!", 0);
          } 
        } 
      } 
      System.exit(0);
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\CPCDiscImageMerger.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */