package jemu.system.cpc;

import java.awt.Dimension;
import jemu.core.Util;
import jemu.core.device.crtc.Basic6845;
import jemu.core.device.crtc.CRTCListener;
import jemu.core.renderer.MonitorRenderer;
import jemu.settings.Palette;
import jemu.ui.Display;
import jemu.ui.JEMU;
import jemu.ui.Switches;

public final class GateArray extends MonitorRenderer implements CRTCListener {
  protected int borderHeight;
  
  protected static final GraphicsDecoder decoder = new GraphicsDecoder();
  
  protected final int HOFFSET = 718848;
  
  protected final int HOFFSEND = 3864576;
  
  protected Dimension HALF_DISPLAY_SIZE = new Dimension(384, 272);
  
  protected Dimension FULL_DISPLAY_SIZE = new Dimension(768, 272);
  
  static int returnmode = 0;
  
  static int smode = 1;
  
  public static CPC cpc;
  
  public static Z80 z80;
  
  public Basic6845 crtc;
  
  protected int r52;
  
  protected int vSyncInt = 0;
  
  protected int interruptMask;
  
  protected int hSyncCount;
  
  protected int vSyncCount = 0;
  
  protected int screenMode = -1;
  
  protected boolean[] isBorder;
  
  protected boolean outHSync = false;
  
  public static int[] inks = new int[33];
  
  protected byte[] fullMap;
  
  protected byte[] halfMap;
  
  protected int offset = 0;
  
  protected int scanStart = 0;
  
  protected boolean scanStarted;
  
  protected Renderer borderRenderer;
  
  protected Renderer syncRenderer;
  
  protected Renderer defRenderer;
  
  protected Renderer startRenderer;
  
  protected Renderer endRenderer;
  
  protected Renderer renderer;
  
  protected int endPix;
  
  protected int selInk = 0;
  
  protected boolean render = true;
  
  protected boolean rendering = true;
  
  public static byte[] screenmemory;
  
  protected boolean halfSize = false;
  
  protected int Luminance = 255;
  
  protected static final int[] maTranslate = new int[65536];
  
  protected static int[] CPCInks = new int[33];
  
  public static int[] CPCInksb = new int[33];
  
  public static int[] GAInks = new int[] { 
      13, 27, 19, 25, 1, 7, 10, 16, 28, 29, 
      24, 26, 6, 8, 15, 17, 30, 31, 18, 20, 
      0, 2, 9, 11, 4, 22, 21, 23, 3, 5, 
      12, 14 };
  
  public static int[] palette = new int[] { 
      13, 13, 19, 25, 1, 7, 10, 16, 7, 25, 
      24, 26, 6, 8, 15, 17, 1, 19, 18, 20, 
      0, 2, 9, 11, 4, 22, 21, 23, 3, 5, 
      12, 14 };
  
  public static int[] Inks = new int[] { 
      20, 4, 21, 28, 24, 29, 12, 5, 13, 22, 
      6, 23, 30, 0, 31, 14, 7, 15, 18, 2, 
      19, 26, 25, 27, 10, 3, 11, 1, 8, 9, 
      16, 17 };
  
  public static void resetCPCColours() {
    System.arraycopy(original, 0, inkTranslateColor, 0, original.length);
  }
  
  public static void writePalette() {
    for (int i = 0; i < 32; i++) {
      String ink = "" + i;
      if (i < 10)
        ink = "0" + ink; 
      Palette.set("ink_" + ink, "" + Util.hex(inkTranslateColor[Inks[i]]).substring(2));
    } 
  }
  
  public static void setPalette(int ink, int r, int g, int b) {
    inkTranslateColor[Inks[ink]] = putRGB(LUM(r), LUM(g), LUM(b));
    resetInks();
  }
  
  public static void setInk(int ink, int r, int g, int b) {
    inkTranslateColor[Inks[ink]] = putRGB(r, g, b);
    resetInks();
  }
  
  public static void setPlusPalette(int ink, int r, int g, int b) {
    inkTranslateColor[ink] = putRGB(LUM(r), LUM(g), LUM(b));
    resetInkss();
  }
  
  public static void setPlusPalette(int ink, int value) {
    inkTranslateColor[ink] = value;
  }
  
  public static void setPalette(int ink, int value) {
    inkTranslateColor[Inks[ink]] = value;
  }
  
  public static void setUserPalette(int ink, int r, int g, int b) {
    inkTranslateColor[Inks[ink]] = putRGB(r, g, b);
  }
  
  public static int LUM(int in) {
    return luminancePLUS[in];
  }
  
  public int getVPOS() {
    return this.crtc.getVVPOS() * (this.halfSize ? 1 : 2);
  }
  
  public int getHPOS() {
    return this.crtc.getHPOS() / (this.halfSize ? 2 : 1);
  }
  
  public static int[] luminancePLUS = new int[] { 
      0, 17, 34, 51, 68, 85, 102, 119, 136, 153, 
      170, 187, 204, 221, 238, 255 };
  
  public static int[] inkTranslateC64 = new int[] { 
      9605802, 6324384, 9482352, 14729376, 1057073, 10243120, 4219008, 14712928, 10374449, 15987563, 
      14725264, 14737632, 10502176, 8997457, 12607552, 14731464, 1057073, 193387, 6329133, 12632288, 
      513, 2113632, 4227072, 7372960, 7620721, 9482352, 6332416, 13684960, 5904640, 3166320, 
      12607552, 10526912 };
  
  public static int[] inkTranslateColor = new int[] { 
      6513507, 6513507, 65379, 16777059, 99, 16711779, 25443, 16737123, 16711779, 16777059, 
      16776960, 16711422, 16711680, 16711935, 16737024, 16737279, 99, 65379, 65280, 65535, 
      0, 255, 25344, 25599, 6488163, 6553443, 6553344, 6553599, 6488064, 6488319, 
      6513408, 6513663 };
  
  protected static final int[] original = new int[] { 
      6513507, 6513507, 65379, 16777059, 99, 16711779, 25443, 16737123, 16711779, 16777059, 
      16776960, 16711422, 16711680, 16711935, 16737024, 16737279, 99, 65379, 65280, 65535, 
      0, 255, 25344, 25599, 6488163, 6553443, 6553344, 6553599, 6488064, 6488319, 
      6513408, 6513663 };
  
  protected static final int[] inkTranslateMeasured = new int[] { 
      6781031, 6781031, 1046648, 16316517, 133200, 15669359, 553063, 16288111, 15669359, 16316517, 
      16316449, 16251128, 15212307, 16259320, 16289543, 16288248, 133200, 1046648, 1177614, 2685176, 
      1798, 659672, 552712, 1015544, 5705561, 7927920, 8452108, 7993592, 5312264, 6296040, 
      6780935, 7307256 };
  
  protected static final int[] inkTranslateGrim = new int[] { 
      7241067, 7241067, 62315, 15987565, 619, 15729256, 30824, 15957355, 15729256, 15987565, 
      15987469, 16774137, 15926534, 15926004, 15957261, 16417017, 619, 62315, 192513, 1045490, 
      513, 787188, 161793, 818164, 6881896, 7467883, 7468292, 7468020, 7078401, 7078642, 
      7240449, 7240694 };
  
  protected static final int[] inkTranslateCPCe = new int[] { 
      7171413, 7171413, 65365, 16777045, 85, 16711765, 27989, 16739669, 16711765, 16777045, 
      16776960, 16711422, 16711680, 16711935, 16739584, 16739839, 85, 65365, 65280, 65535, 
      0, 255, 27904, 28159, 7143509, 7208789, 7208704, 7208959, 7143424, 7143679, 
      7171328, 7171583 };
  
  protected static final int[] inkTranslate3d = new int[] { 
      9803925, 9803925, 2162569, 16777097, 2105481, 16720009, 2136213, 16750741, 16720009, 16777097, 
      16776992, 16711422, 16719904, 16720127, 16749856, 16750079, 2105481, 2162569, 2162464, 2162687, 
      2105376, 2105599, 2135328, 2135551, 9773193, 9830281, 9830176, 9830399, 9773088, 9773311, 
      9803040, 9803263 };
  
  protected static final int[] inkTranslateLinear = new int[] { 
      8224125, 8224125, 65405, 16777085, 125, 16711805, 32125, 16743805, 16711805, 16777085, 
      16776960, 16711422, 16711680, 16711935, 16743680, 16743935, 125, 65405, 65280, 65535, 
      0, 255, 32000, 32255, 8192125, 8257405, 8257280, 8257535, 8192000, 8192255, 
      8224000, 8224255 };
  
  protected static final int[] green = new int[] { 
      1333263, 1465361, 1728789, 1860631, 1992729, 2256157, 2585633, 2717475, 2980903, 3376428, 
      3574063, 3837747, 3969845, 4233016, 4430907, 4760640, 4958018, 5155909, 5551179, 5749070, 
      6012497, 6144339, 6342230, 6605657, 6869341, 6935134, 7001183, 4167223, 2717475, 7133025, 
      1465362, 5814862 };
  
  protected static final int[] inkTranslateGreen = new int[] { 
      32000, 32000, 46336, 61184, 2560, 17152, 24576, 39168, 17152, 61184, 
      58624, 63488, 14592, 19456, 36864, 41728, 40960, 46336, 44032, 48896, 
      0, 4864, 22272, 27136, 9728, 53760, 51456, 56320, 7424, 12288, 
      29440, 34304 };
  
  protected static final int[] inkTranslateGrey = new int[] { 
      8228221, 8228221, 11912629, 15728623, 662026, 4412227, 6320224, 10070425, 4412227, 15728623, 
      15070693, 16318456, 3754297, 5004364, 9478288, 10728355, 10530976, 11912629, 11320492, 12570559, 
      4096, 1254163, 5728087, 6978154, 2504230, 13820626, 13228489, 14478556, 1912093, 3162160, 
      7570291, 8820358 };
  
  protected static final int[] inkTranslateBW = new int[] { 
      8224125, 8224125, 11908533, 15724527, 657930, 4408131, 6316128, 10066329, 4408131, 15724527, 
      15066597, 16316664, 3750201, 5000268, 9474192, 10724259, 10526880, 11908533, 11316396, 12566463, 
      0, 1250067, 5723991, 6974058, 2500134, 13816530, 13224393, 14474460, 1907997, 3158064, 
      7566195, 8816262 };
  
  protected static final byte[][] fullMaps = new byte[4][];
  
  protected static final byte[][] halfMaps = new byte[4][];
  
  public static int[] requestink = new int[17];
  
  CPCMemory cpcmemory;
  
  boolean test;
  
  boolean testbars;
  
  boolean wasHSync;
  
  int lastMode;
  
  int skipsprites;
  
  int voffset;
  
  int[][] sprite;
  
  int spriteoffset;
  
  int spos;
  
  CPCMemory spritemem;
  
  boolean skipsprite;
  
  int[] xm;
  
  int[] ym;
  
  int[] xpos;
  
  int[] ypos;
  
  int ymin;
  
  int ymax;
  
  int xmin;
  
  int xmax;
  
  int[] oldline;
  
  int sproffset;
  
  int r3;
  
  boolean even;
  
  int shiftoffset;
  
  int modeline;
  
  int reg2line;
  
  static {
    for (int mode = 0; mode < 4; mode++) {
      byte[] full = new byte[1048576];
      byte[] half = new byte[524288];
      fullMaps[mode] = full;
      halfMaps[mode] = half;
      for (int j = 0; j < 524288; ) {
        int b1 = j >> 3 & 0xFF;
        int b2 = j >> 11 & 0xFF;
        decoder.decodeHalf(half, j, mode, b1);
        decoder.decodeFull(full, j * 2, mode, b1);
        j += 4;
        decoder.decodeHalf(half, j, mode, b2);
        decoder.decodeFull(full, j * 2, mode, b2);
        j += 4;
      } 
    } 
    for (int i = 0; i < maTranslate.length; i++) {
      int j = i << 1;
      maTranslate[i] = j & 0x7FE | (j & 0x6000) << 1;
    } 
  }
  
  public GraphicsDecoder getDecoder() {
    return decoder;
  }
  
  public GateArray(CPC cpc) {
    super("Amstrad Gate Array");
    this.test = false;
    this.lastMode = 1;
    this.voffset = -4;
    this.sprite = new int[16][];
    this.xm = new int[16];
    this.ym = new int[16];
    this.xpos = new int[16];
    this.ypos = new int[16];
    this.oldline = new int[16];
    this.shiftoffset = 0;
    this.rasterDelay = 8;
    this.result = new int[4];
    setCycleFrequency(1000000L);
    this;
    GateArray.cpc = cpc;
    z80 = cpc.z80;
    this.crtc = cpc.crtc;
    reset();
    setHalfSize(false);
    for (int i = 0; i < 32; i++)
      inkTranslateGreen[i] = green[GAInks[i]]; 
  }
  
  public void setHalfSize(boolean value) {
    if (this.halfSize != value || this.defRenderer == null) {
      this.halfSize = value;
      this.defRenderer = this.halfSize ? new HalfRenderer() : new FullRenderer();
      this.startRenderer = this.halfSize ? new HalfStartRenderer() : new FullStartRenderer();
      this.endRenderer = this.halfSize ? new HalfEndRenderer() : new FullEndRenderer();
      this.borderRenderer = new BorderRenderer(16, this.halfSize ? 8 : 16);
      this.syncRenderer = new BorderRenderer(32, this.halfSize ? 8 : 16);
      this.renderer = this.borderRenderer;
    } 
  }
  
  public void reset() {
    resetCPCColours();
    this.r52 = 0;
    setScreenMode(1);
    for (int i = 0; i < 33; i++)
      inks[i] = -16777216; 
    inks[16] = -16777216;
  }
  
  public void setSelectedInk(int value) {
    this.selInk = ((value & 0x1F) < 16) ? (value & 0xF) : 16;
  }
  
  public int getSelectedInk() {
    return this.selInk;
  }
  
  public static void forceInk(int index, int value) {
    CPCInks[index] = GAInks[value & 0x1F];
    CPCInksb[index] = value;
    requestink[index] = value & 0x1F;
    cpc.getGateArray().updateInks();
  }
  
  public static void setInk(int index, int value) {
    CPCInks[index] = GAInks[value & 0x1F];
    CPCInksb[index] = value;
    requestink[index] = value & 0x1F;
  }
  
  public static int getInk(int index) {
    return CPCInks[index];
  }
  
  public static int getInkRGB(int index) {
    return inks[index];
  }
  
  public static int getInks(int index) {
    return CPCInksb[index];
  }
  
  public void writePort(int port, int value) {
    if ((value & 0x80) == 0) {
      if ((value & 0x40) == 0) {
        value &= 0x1F;
        this.selInk = (value < 16) ? value : 16;
      } else {
        CPCInks[this.selInk] = GAInks[value & 0x1F];
        CPCInksb[this.selInk] = value & 0x1F;
        requestink[this.selInk] = value & 0x1F;
        if (this.renderer == this.borderRenderer || this.crtc.Scratchdemo)
          updateInks(); 
      } 
    } else {
      if (this.cpcmemory == null)
        this.cpcmemory = (CPCMemory)cpc.getMemory(); 
      if ((value & 0x40) == 0)
        setModeAndROMEnable(this.cpcmemory, value); 
    } 
  }
  
  public void updateInks() {
    if (use3d != Display.use3d)
      resetInks(); 
    use3d = Display.use3d;
    int monitormode = Switches.monitormode;
    for (int i = 0; i < requestink.length; i++) {
      if (requestink[i] != -1) {
        switch (monitormode) {
          case 1:
            inks[i] = inkTranslateLinear[requestink[i]];
            break;
          case 2:
            inks[i] = inkTranslateGreen[requestink[i]];
            break;
          case 3:
            inks[i] = inkTranslateBW[requestink[i]];
            break;
          case 4:
            inks[i] = inkTranslateGrey[requestink[i]];
            break;
          case 5:
            inks[i] = inkTranslateCPCe[requestink[i]];
            break;
          case 6:
            inks[i] = inkTranslateMeasured[requestink[i]];
            break;
          case 7:
            inks[i] = inkTranslateGrim[requestink[i]];
            break;
          case 8:
            inks[i] = inkTranslateC64[requestink[i]];
            break;
          default:
            inks[i] = inkTranslateColor[requestink[i]];
            break;
        } 
        requestink[i] = -1;
      } 
    } 
  }
  
  public void setNewMode(int value) {
    this.screenMode = value & 0x3;
  }
  
  public void setModeAndROMEnable(CPCMemory memory, int value) {
    returnmode = value;
    memory.setLowerEnabled(((value & 0x4) == 0));
    memory.setUpperEnabled(((value & 0x8) == 0));
    if ((value & 0x10) != 0) {
      this.r52 = 0;
      setInterruptMask(this.interruptMask & 0x70);
    } 
    this.screenMode = value & 0x3;
  }
  
  public int getMode() {
    return returnmode;
  }
  
  public void setScreenMode(int mode) {
    if (mode < 0)
      return; 
    this.fullMap = fullMaps[mode];
    this.halfMap = halfMaps[mode];
  }
  
  public int getScreenMode() {
    return this.screenMode;
  }
  
  public static int getSMode() {
    return smode;
  }
  
  public void setInterruptMask(int value) {
    this.interruptMask = value;
    if (this.interruptMask != 0) {
      z80.setInterrupt(1);
    } else {
      z80.clearInterrupt(1);
    } 
  }
  
  public void setInterrupt(int mask) {
    this.r52 &= 0x1F;
    setInterruptMask(this.interruptMask & 0x70);
  }
  
  public void cycle() {
    if (this.test) {
      this.testbars = !this.testbars;
      if (this.testbars) {
        setInk(16, 13);
      } else {
        setInk(16, 20);
      } 
      updateInks();
    } 
    if (!this.inHSync && !this.inVSync && (this.hSyncCount == 3 || this.hSyncCount == 4) && this.crtc.camemb4)
      modeCheck(); 
    this.crtc.avoidCollision();
    smode = this.screenMode;
    if (this.scanStarted) {
      this.crtc.checkHDisp();
      if (this.hPos < 3864576) {
        this.renderer.render();
      } else {
        this.endRenderer.render();
        this.render = this.scanStarted = false;
      } 
    } else if (this.render && this.hPos >= 718848) {
      this.crtc.checkHDisp();
      this.startRenderer.render();
      this.scanStarted = true;
    } 
    this.crtc.cycle();
    if (this.inHSync) {
      modeCheck();
      this.hSyncCount++;
      if (this.hSyncCount == 1) {
        this.outHSync = true;
        super.hSyncStart();
      } 
      if (this.hSyncCount == 7)
        endHSync(); 
    } 
    clock();
  }
  
  protected void endHSync() {
    if (this.outHSync) {
      super.hSyncEnd();
      if (cpc.getAsic() != null)
        cpc.getAsic().splitScreen(); 
      modeCheck();
    } 
    this.outHSync = false;
  }
  
  public void modeCheck() {
    setScreenMode(this.screenMode & 0x3);
  }
  
  public void hSyncStart() {
    modeCheck();
    this.hSyncCount = 0;
    this.inHSync = true;
    this.renderer = this.syncRenderer;
  }
  
  public void hSync() {
    modeCheck();
    if (this.render = (this.rendering && this.monitorLine >= this.voffset && this.monitorLine < 272 + this.voffset)) {
      this.offset = this.scanStart;
      if (Display.doublesize) {
        this.scanStart += this.halfSize ? 768 : 1536;
      } else {
        this.scanStart += this.halfSize ? 384 : 768;
      } 
    } 
    if (this.vSyncCount > 0 && --this.vSyncCount == 0)
      super.vSyncEnd(); 
    this.scanStarted = false;
  }
  
  public void hSyncEnd() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield crtc : Ljemu/core/device/crtc/Basic6845;
    //   5: iconst_2
    //   6: invokevirtual getReg : (I)I
    //   9: bipush #46
    //   11: if_icmple -> 35
    //   14: aload_0
    //   15: getfield crtc : Ljemu/core/device/crtc/Basic6845;
    //   18: iconst_2
    //   19: invokevirtual getReg : (I)I
    //   22: iconst_2
    //   23: irem
    //   24: ifeq -> 31
    //   27: iconst_2
    //   28: goto -> 36
    //   31: iconst_0
    //   32: goto -> 36
    //   35: iconst_0
    //   36: putfield reg2shift : I
    //   39: getstatic jemu/system/cpc/GateArray.GAType : I
    //   42: ldc 40010
    //   44: if_icmpne -> 90
    //   47: aload_0
    //   48: getfield modeline : I
    //   51: aload_0
    //   52: getfield monitorLine : I
    //   55: if_icmpeq -> 95
    //   58: aload_0
    //   59: aload_0
    //   60: getfield monitorLine : I
    //   63: putfield modeline : I
    //   66: aload_0
    //   67: invokevirtual getScreenMode : ()I
    //   70: iconst_2
    //   71: if_icmpne -> 82
    //   74: aload_0
    //   75: iconst_m1
    //   76: putfield modeshift : I
    //   79: goto -> 95
    //   82: aload_0
    //   83: iconst_0
    //   84: putfield modeshift : I
    //   87: goto -> 95
    //   90: aload_0
    //   91: iconst_0
    //   92: putfield modeshift : I
    //   95: getstatic jemu/system/cpc/GateArray.cpc : Ljemu/system/cpc/CPC;
    //   98: pop
    //   99: getstatic jemu/system/cpc/CPC.memory : Ljemu/system/cpc/CPCMemory;
    //   102: getfield plus : Z
    //   105: ifeq -> 118
    //   108: aload_0
    //   109: dup
    //   110: getfield skipsprites : I
    //   113: iconst_1
    //   114: iadd
    //   115: putfield skipsprites : I
    //   118: aload_0
    //   119: getfield skipsprites : I
    //   122: bipush #8
    //   124: if_icmpne -> 140
    //   127: aload_0
    //   128: iconst_0
    //   129: putfield skipsprites : I
    //   132: aload_0
    //   133: aload_0
    //   134: invokevirtual getVPOS : ()I
    //   137: invokevirtual renderSprites : (I)V
    //   140: aload_0
    //   141: getstatic jemu/system/cpc/GateArray.cpc : Ljemu/system/cpc/CPC;
    //   144: invokevirtual getMode : ()I
    //   147: iconst_3
    //   148: if_icmpeq -> 155
    //   151: iconst_1
    //   152: goto -> 156
    //   155: iconst_0
    //   156: putfield debug : Z
    //   159: aload_0
    //   160: invokevirtual endHSync : ()V
    //   163: getstatic jemu/system/cpc/GateArray.cpc : Ljemu/system/cpc/CPC;
    //   166: pop
    //   167: getstatic jemu/system/cpc/CPC.memory : Ljemu/system/cpc/CPCMemory;
    //   170: getfield plus : Z
    //   173: ifeq -> 205
    //   176: getstatic jemu/system/cpc/GateArray.cpc : Ljemu/system/cpc/CPC;
    //   179: invokevirtual getAsic : ()Ljemu/system/cpc/plus/ASIC;
    //   182: invokevirtual doInterrupt : ()Z
    //   185: ifeq -> 205
    //   188: aload_0
    //   189: iconst_0
    //   190: putfield r52 : I
    //   193: aload_0
    //   194: aload_0
    //   195: getfield interruptMask : I
    //   198: sipush #128
    //   201: ior
    //   202: invokevirtual setInterruptMask : (I)V
    //   205: goto -> 209
    //   208: astore_1
    //   209: aload_0
    //   210: dup
    //   211: getfield r52 : I
    //   214: iconst_1
    //   215: iadd
    //   216: dup_x1
    //   217: putfield r52 : I
    //   220: bipush #52
    //   222: if_icmpne -> 267
    //   225: aload_0
    //   226: iconst_0
    //   227: putfield r52 : I
    //   230: getstatic jemu/system/cpc/GateArray.cpc : Ljemu/system/cpc/CPC;
    //   233: invokevirtual getAsic : ()Ljemu/system/cpc/plus/ASIC;
    //   236: invokevirtual getRaster : ()Z
    //   239: ifeq -> 255
    //   242: getstatic jemu/system/cpc/GateArray.cpc : Ljemu/system/cpc/CPC;
    //   245: pop
    //   246: getstatic jemu/system/cpc/CPC.memory : Ljemu/system/cpc/CPCMemory;
    //   249: getfield plus : Z
    //   252: ifne -> 267
    //   255: aload_0
    //   256: aload_0
    //   257: getfield interruptMask : I
    //   260: sipush #128
    //   263: ior
    //   264: invokevirtual setInterruptMask : (I)V
    //   267: aload_0
    //   268: getfield vSyncInt : I
    //   271: ifle -> 339
    //   274: aload_0
    //   275: dup
    //   276: getfield vSyncInt : I
    //   279: iconst_1
    //   280: isub
    //   281: dup_x1
    //   282: putfield vSyncInt : I
    //   285: ifne -> 339
    //   288: aload_0
    //   289: getfield r52 : I
    //   292: bipush #32
    //   294: if_icmplt -> 334
    //   297: getstatic jemu/system/cpc/GateArray.cpc : Ljemu/system/cpc/CPC;
    //   300: invokevirtual getAsic : ()Ljemu/system/cpc/plus/ASIC;
    //   303: invokevirtual getRaster : ()Z
    //   306: ifeq -> 322
    //   309: getstatic jemu/system/cpc/GateArray.cpc : Ljemu/system/cpc/CPC;
    //   312: pop
    //   313: getstatic jemu/system/cpc/CPC.memory : Ljemu/system/cpc/CPCMemory;
    //   316: getfield plus : Z
    //   319: ifne -> 334
    //   322: aload_0
    //   323: aload_0
    //   324: getfield interruptMask : I
    //   327: sipush #128
    //   330: ior
    //   331: invokevirtual setInterruptMask : (I)V
    //   334: aload_0
    //   335: iconst_0
    //   336: putfield r52 : I
    //   339: aload_0
    //   340: aload_0
    //   341: getfield vSyncCount : I
    //   344: ifle -> 354
    //   347: aload_0
    //   348: getfield syncRenderer : Ljemu/system/cpc/GateArray$Renderer;
    //   351: goto -> 385
    //   354: aload_0
    //   355: getfield crtc : Ljemu/core/device/crtc/Basic6845;
    //   358: invokevirtual isVDisp : ()Z
    //   361: ifeq -> 381
    //   364: aload_0
    //   365: getfield crtc : Ljemu/core/device/crtc/Basic6845;
    //   368: invokevirtual isHDisp : ()Z
    //   371: ifeq -> 381
    //   374: aload_0
    //   375: getfield defRenderer : Ljemu/system/cpc/GateArray$Renderer;
    //   378: goto -> 385
    //   381: aload_0
    //   382: getfield borderRenderer : Ljemu/system/cpc/GateArray$Renderer;
    //   385: putfield renderer : Ljemu/system/cpc/GateArray$Renderer;
    //   388: return
    // Line number table:
    //   Java source line number -> byte code offset
    //   #910	-> 0
    //   #911	-> 39
    //   #912	-> 47
    //   #913	-> 58
    //   #914	-> 66
    //   #915	-> 74
    //   #917	-> 82
    //   #921	-> 90
    //   #923	-> 95
    //   #924	-> 108
    //   #926	-> 118
    //   #927	-> 127
    //   #928	-> 132
    //   #930	-> 140
    //   #931	-> 159
    //   #933	-> 163
    //   #934	-> 176
    //   #935	-> 188
    //   #936	-> 193
    //   #940	-> 205
    //   #939	-> 208
    //   #941	-> 209
    //   #942	-> 225
    //   #943	-> 230
    //   #944	-> 255
    //   #947	-> 267
    //   #948	-> 288
    //   #949	-> 297
    //   #950	-> 322
    //   #953	-> 334
    //   #955	-> 339
    //   #956	-> 388
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	389	0	this	Ljemu/system/cpc/GateArray;
    // Exception table:
    //   from	to	target	type
    //   163	205	208	java/lang/Exception
  }
  
  public void hDispEnd() {
    this.renderer = (this.vSyncCount > 0 || this.crtc.isHSync()) ? this.syncRenderer : this.borderRenderer;
  }
  
  public void hDispStart() {
    this.renderer = (this.vSyncCount > 0 || this.crtc.isHSync()) ? this.syncRenderer : (this.crtc.isVDisp() ? this.defRenderer : this.borderRenderer);
  }
  
  public void vSyncStart() {
    super.vSyncStart();
    this.vSyncCount = 25;
    this.renderer = this.syncRenderer;
    this.vSyncInt = 2;
  }
  
  public void vSyncEnd() {}
  
  public void renderSprites(int monitorline) {
    if (this.spritemem == null)
      this.spritemem = (CPCMemory)cpc.getMemory(); 
    for (int i = 15; i > -1; i--) {
      this.spritemem.setMag(i);
      this.oldline[i] = monitorline;
      this.xm[i] = this.spritemem.getXM(i);
      this.ym[i] = this.spritemem.getYM(i);
      this.skipsprite = false;
      if (this.sprite[i] == null)
        this.skipsprite = true; 
      if (this.xm[i] == 0 || this.ym[i] == 0)
        this.skipsprite = true; 
      if (!this.skipsprite) {
        this.xpos[i] = this.spritemem.getSpriteX(i) + this.xmin;
        this.ypos[i] = this.spritemem.getSpriteY(i) + this.ymin;
        if (!this.skipsprite) {
          this.spriteoffset = this.xpos[i];
          this.spriteoffset += 768 * this.ypos[i];
          this.spos = 0;
          for (int y = 0; y < 16; y++) {
            for (int x = 0; x < 16; x++) {
              if (this.sprite[i][this.spos] != -123456789)
                for (int cubex = 0; cubex < this.xm[i]; cubex++) {
                  for (int cubey = 0; cubey < this.ym[i]; cubey++) {
                    this.sproffset = this.spriteoffset + cubex + 768 * cubey * 2;
                    if (this.sproffset < this.pixels.length && this.sproffset >= 0 && !this.isBorder[this.sproffset])
                      this.pixels[this.sproffset] = this.sprite[i][this.spos]; 
                  } 
                }  
              this.spos++;
              this.spriteoffset += this.xm[i];
            } 
            this.spriteoffset -= 16 * this.xm[i];
            this.spriteoffset += 1536 * this.ym[i];
          } 
        } 
      } 
    } 
  }
  
  public void vSync(boolean interlace) {
    this.borderHeight = 35 - Basic6845.getR(7) << 3;
    this.borderHeight *= 2;
    if (this.borderHeight > 400)
      this.borderHeight = 0; 
    this.ymin = Basic6845.getR(4) * 8 - Basic6845.getR(7) * 8 - 24;
    if ((this.ymin & 0x100) == 256)
      this.ymin |= 0xFF00; 
    if ((this.ymin & 0x8000) != 0)
      this.ymin = -(0 - this.ymin & 0x3F); 
    this.ymax = Basic6845.getR(6) * 8 + this.ymin;
    this.xmin = (50 - Basic6845.getR(2)) * 16;
    this.r3 = Basic6845.getR(3) & 0xF;
    if (this.r3 < 6)
      this.xmin += this.r3 * 8; 
    this.r3 = Basic6845.getR(0) - 63;
    this.xmin += this.r3 * 16;
    this.xmax = this.xmin + Basic6845.getR(1) * 16;
    try {
      if (this.spritemem == null)
        this.spritemem = (CPCMemory)cpc.getMemory(); 
      for (int i = 0; i < 16; i++)
        this.sprite[i] = this.spritemem.getSprite(i); 
    } catch (Exception exception) {}
    this.scanStart = this.offset = 0;
    cpc.vSync();
  }
  
  public void vSync() {
    this.scanStart = 0;
    try {
      cpc.vSync();
    } catch (Exception exception) {}
  }
  
  public void vDispStart() {}
  
  public void setMemory(byte[] value) {
    screenmemory = value;
  }
  
  public void setRendering(boolean value) {
    this.rendering = value;
    if (!this.rendering)
      this.render = this.scanStarted = false; 
  }
  
  public Dimension getDisplaySize(boolean large) {
    return large ? this.FULL_DISPLAY_SIZE : this.HALF_DISPLAY_SIZE;
  }
  
  public void cursor() {}
  
  protected abstract class Renderer {
    public void render() {}
  }
  
  protected class BorderRenderer extends Renderer {
    protected int ink;
    
    protected int width;
    
    public BorderRenderer(int ink, int width) {
      this.ink = ink;
      this.width = width;
    }
    
    public void render() {
      if (GateArray.this.pixels == null)
        return; 
      if (GateArray.this.isBorder == null || GateArray.this.isBorder.length < 1)
        GateArray.this.isBorder = new boolean[417792]; 
      int pix = GateArray.inks[this.ink];
      try {
        for (int i = 0; i < this.width; i++) {
          if (GateArray.this.halfSize) {
            GateArray.this.pixels[GateArray.this.offset] = pix;
          } else {
            GateArray.this.checkOffset();
            GateArray.this.pixels[GateArray.this.offset + GateArray.this.shiftoffset] = pix;
          } 
          GateArray.this.isBorder[GateArray.this.offset] = true;
          GateArray.this.offset++;
        } 
      } catch (Exception exception) {}
    }
  }
  
  protected class HalfRenderer extends Renderer {
    public void render() {
      if (GateArray.screenmemory == null)
        return; 
      if (GateArray.this.pixels.length > 208896)
        GateArray.this.pixels = new int[208896]; 
      try {
        int addr = GateArray.maTranslate[GateArray.this.crtc.getMA()] + ((GateArray.this.crtc.getRA() & 0x7) << 11);
        int val = ((GateArray.screenmemory[addr] & 0xFF) << 3) + ((GateArray.screenmemory[addr + 1] & 0xFF) << 11);
        int i;
        for (i = 0; i < 4; i++)
          GateArray.this.pixels[GateArray.this.offset++] = GateArray.inks[GateArray.this.halfMap[val++]]; 
        for (i = 0; i < 4; i++)
          GateArray.this.pixels[GateArray.this.offset++] = GateArray.inks[GateArray.this.halfMap[val++]]; 
        GateArray.this.updateInks();
      } catch (Exception e) {
        JEMU.togglesize = true;
      } 
    }
  }
  
  public static int GAType = 40008;
  
  static int[] types = new int[] { 40008, 40010 };
  
  int shiftreg2;
  
  int oldshiftreg2;
  
  int reg2shift;
  
  int modeshift;
  
  int rasterDelay;
  
  static boolean use3d;
  
  int[] result;
  
  public static void setGAType(int value) {
    GAType = types[value];
  }
  
  public int getShift() {
    return this.shiftreg2;
  }
  
  protected void checkOffset() {
    this.shiftoffset = this.modeshift + this.reg2shift;
    if (this.offset + this.shiftoffset < 0)
      this.shiftoffset = 0; 
    if (this.offset + this.shiftoffset >= this.pixels.length)
      this.shiftoffset = 0; 
  }
  
  protected class HalfStartRenderer extends Renderer {
    public void render() {
      if (GateArray.this.pixels == null)
        return; 
      if (GateArray.screenmemory == null)
        return; 
      try {
        GateArray.this.endPix = 8 - (GateArray.this.hPos - 718848 >> 13 & 0x7);
        if (GateArray.this.renderer == GateArray.this.borderRenderer) {
          int pix = GateArray.inks[16];
          for (int i = GateArray.this.endPix; i < 8; i++)
            GateArray.this.pixels[GateArray.this.offset++] = pix; 
        } else if (GateArray.this.renderer == GateArray.this.defRenderer) {
          int addr = GateArray.maTranslate[GateArray.this.crtc.getMA()] + ((GateArray.this.crtc.getRA() & 0x7) << 11);
          int val = ((GateArray.screenmemory[addr] & 0xFF) << 3) + ((GateArray.screenmemory[addr + 1] & 0xFF) << 11) + GateArray.this.endPix;
          for (int i = GateArray.this.endPix; i < 8; i++)
            GateArray.this.pixels[GateArray.this.offset++] = GateArray.inks[GateArray.this.halfMap[val++]]; 
        } else {
          int pix = GateArray.inks[32];
          for (int i = GateArray.this.endPix; i < 8; i++)
            GateArray.this.pixels[GateArray.this.offset++] = pix; 
        } 
        GateArray.this.updateInks();
      } catch (Exception exception) {}
    }
  }
  
  protected class HalfEndRenderer extends Renderer {
    public void render() {
      if (GateArray.screenmemory == null)
        return; 
      try {
        if (GateArray.this.renderer == GateArray.this.borderRenderer) {
          int pix = GateArray.inks[16];
          for (int i = 0; i < GateArray.this.endPix; i++) {
            try {
              GateArray.this.pixels[GateArray.this.offset++] = pix;
            } catch (Exception exception) {}
          } 
        } else if (GateArray.this.renderer == GateArray.this.defRenderer) {
          int addr = GateArray.maTranslate[GateArray.this.crtc.getMA()] + ((GateArray.this.crtc.getRA() & 0x7) << 11);
          int val = ((GateArray.screenmemory[addr] & 0xFF) << 3) + ((GateArray.screenmemory[addr + 1] & 0xFF) << 11);
          for (int i = 0; i < GateArray.this.endPix; i++)
            GateArray.this.pixels[GateArray.this.offset++] = GateArray.inks[GateArray.this.halfMap[val++]]; 
        } else {
          int pix = GateArray.inks[32];
          for (int i = 0; i < GateArray.this.endPix; i++)
            GateArray.this.pixels[GateArray.this.offset++] = pix; 
        } 
        GateArray.this.updateInks();
      } catch (Exception exception) {}
    }
  }
  
  protected class FullRenderer extends Renderer {
    public void render() {
      if (GateArray.screenmemory == null)
        return; 
      if (GateArray.this.pixels.length < 417792)
        GateArray.this.pixels = new int[417792]; 
      try {
        int delay = 0;
        int addr = GateArray.maTranslate[GateArray.this.crtc.getMA()] + ((GateArray.this.crtc.getRA() & 0x7) << 11);
        int val = ((GateArray.screenmemory[addr] & 0xFF) << 4) + ((GateArray.screenmemory[addr + 1] & 0xFF) << 12);
        for (int i = 0; i < 16; i++) {
          if (delay++ == GateArray.this.rasterDelay)
            GateArray.this.updateInks(); 
          GateArray.this.isBorder[GateArray.this.offset] = false;
          GateArray.this.checkOffset();
          GateArray.this.pixels[GateArray.this.offset++ + GateArray.this.shiftoffset] = GateArray.inks[GateArray.this.fullMap[val++]];
          if (GateArray.this.shiftoffset < 0)
            GateArray.this.pixels[GateArray.this.offset] = GateArray.this.pixels[GateArray.this.offset - 1]; 
        } 
      } catch (Exception e) {
        JEMU.togglesize = true;
      } 
    }
  }
  
  protected class FullStartRenderer extends Renderer {
    public void render() {
      if (GateArray.screenmemory == null)
        return; 
      if (GateArray.this.isBorder == null || GateArray.this.isBorder.length < 1)
        GateArray.this.isBorder = new boolean[417792]; 
      try {
        GateArray.this.updateInks();
        int delay = 0;
        GateArray.this.endPix = 16 - (GateArray.this.hPos - 718848 >> 12 & 0xF);
        if (GateArray.this.renderer == GateArray.this.borderRenderer) {
          int pix = GateArray.inks[16];
          delay = 0;
          for (int i = GateArray.this.endPix; i < 16; i++) {
            if (delay++ == GateArray.this.rasterDelay)
              GateArray.this.updateInks(); 
            GateArray.this.isBorder[GateArray.this.offset] = true;
            GateArray.this.checkOffset();
            GateArray.this.pixels[GateArray.this.offset++ + GateArray.this.shiftoffset] = pix;
            if (GateArray.this.shiftoffset < 0)
              GateArray.this.pixels[GateArray.this.offset] = GateArray.this.pixels[GateArray.this.offset - 1]; 
          } 
        } else if (GateArray.this.renderer == GateArray.this.defRenderer) {
          int addr = GateArray.maTranslate[GateArray.this.crtc.getMA()] + ((GateArray.this.crtc.getRA() & 0x7) << 11);
          int val = ((GateArray.screenmemory[addr] & 0xFF) << 4) + ((GateArray.screenmemory[addr + 1] & 0xFF) << 12) + GateArray.this.endPix;
          delay = 0;
          for (int i = GateArray.this.endPix; i < 16; i++) {
            if (delay++ == GateArray.this.rasterDelay)
              GateArray.this.updateInks(); 
            GateArray.this.isBorder[GateArray.this.offset] = true;
            GateArray.this.checkOffset();
            GateArray.this.pixels[GateArray.this.offset++ + GateArray.this.shiftoffset] = GateArray.inks[GateArray.this.fullMap[val++]];
            if (GateArray.this.shiftoffset < 0)
              GateArray.this.pixels[GateArray.this.offset] = GateArray.this.pixels[GateArray.this.offset - 1]; 
          } 
        } else {
          int pix = GateArray.inks[32];
          delay = 0;
          for (int i = GateArray.this.endPix; i < 16; i++) {
            if (delay++ == GateArray.this.rasterDelay)
              GateArray.this.updateInks(); 
            GateArray.this.isBorder[GateArray.this.offset] = true;
            GateArray.this.checkOffset();
            GateArray.this.pixels[GateArray.this.offset++ + GateArray.this.shiftoffset] = pix;
            if (GateArray.this.shiftoffset < 0)
              GateArray.this.pixels[GateArray.this.offset] = GateArray.this.pixels[GateArray.this.offset - 1]; 
          } 
        } 
      } catch (Exception exception) {}
    }
  }
  
  protected class FullEndRenderer extends Renderer {
    public void render() {
      if (GateArray.screenmemory == null)
        return; 
      try {
        int delay = 0;
        if (GateArray.this.renderer == GateArray.this.borderRenderer) {
          int pix = GateArray.inks[16];
          for (int i = 0; i < GateArray.this.endPix; i++) {
            if (delay++ == GateArray.this.rasterDelay)
              GateArray.this.updateInks(); 
            GateArray.this.isBorder[GateArray.this.offset] = true;
            GateArray.this.checkOffset();
            GateArray.this.pixels[GateArray.this.offset++ + GateArray.this.shiftoffset] = pix;
            if (GateArray.this.shiftoffset < 0)
              GateArray.this.pixels[GateArray.this.offset] = GateArray.this.pixels[GateArray.this.offset - 1]; 
          } 
        } else if (GateArray.this.renderer == GateArray.this.defRenderer) {
          int addr = GateArray.maTranslate[GateArray.this.crtc.getMA()] + ((GateArray.this.crtc.getRA() & 0x7) << 11);
          int val = ((GateArray.screenmemory[addr] & 0xFF) << 4) + ((GateArray.screenmemory[addr + 1] & 0xFF) << 12);
          delay = 0;
          for (int i = 0; i < GateArray.this.endPix; i++) {
            if (delay++ == GateArray.this.rasterDelay)
              GateArray.this.updateInks(); 
            GateArray.this.isBorder[GateArray.this.offset] = true;
            GateArray.this.checkOffset();
            GateArray.this.pixels[GateArray.this.offset++ + GateArray.this.shiftoffset] = GateArray.inks[GateArray.this.fullMap[val++]];
            if (GateArray.this.shiftoffset < 0)
              GateArray.this.pixels[GateArray.this.offset] = GateArray.this.pixels[GateArray.this.offset - 1]; 
          } 
        } else {
          int pix = GateArray.inks[32];
          delay = 0;
          for (int i = 0; i < GateArray.this.endPix; i++) {
            if (delay++ == GateArray.this.rasterDelay)
              GateArray.this.updateInks(); 
            GateArray.this.isBorder[GateArray.this.offset] = true;
            GateArray.this.checkOffset();
            GateArray.this.pixels[GateArray.this.offset++ + GateArray.this.shiftoffset] = pix;
            if (GateArray.this.shiftoffset < 0)
              GateArray.this.pixels[GateArray.this.offset] = GateArray.this.pixels[GateArray.this.offset - 1]; 
          } 
        } 
      } catch (Exception exception) {}
    }
  }
  
  public static void resetInks() {
    int i;
    for (i = 0; i < 33; i++)
      inks[i] = !use3d ? -14671840 : -16777216; 
    for (i = 0; i < 17; i++)
      setInk(i, getInks(i)); 
  }
  
  public static void resetInkss() {
    for (int i = 0; i < 17; i++)
      setInk(i, i); 
  }
  
  public void init() {
    this.crtc.init();
  }
  
  public int PEEK(int address) {
    return CPC.PEEK(address);
  }
  
  public void POKE(int address, int value) {
    CPC.POKE(address, value);
  }
  
  public static int putRGB(int r, int g, int b) {
    return r << 16 | g << 8 | b;
  }
  
  public boolean getOut() {
    return (this.endPix != 0);
  }
  
  public int getLineNumber() {
    return this.crtc.getLineNumber();
  }
  
  public int[] getField() {
    this.result[0] = this.xmin;
    this.result[1] = this.xmax;
    this.result[2] = this.ymin * 2;
    this.result[3] = this.ymax * 2;
    return this.result;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\GateArray.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */