package jemu.system.cpc;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.Calendar;
import javax.swing.ImageIcon;
import jemu.core.Util;
import jemu.core.device.MultiFace.MultiFace;
import jemu.core.device.memory.DynamicMemory;
import jemu.settings.Settings;
import jemu.ui.Desktop;
import jemu.ui.Switches;

public class CPCMemory extends DynamicMemory {
  protected boolean DEBUG_BANK = false;
  
  protected Calendar cal = Calendar.getInstance();
  
  public static int upperRom;
  
  public static int plusRom;
  
  protected int ramtype = 0;
  
  public static final int CPCUNKNOWN = 0;
  
  public static final int CPC464 = 1;
  
  public static final int CPC664 = 2;
  
  public static final int CPC6128 = 3;
  
  public static final int TYPE_64K = 0;
  
  public static final int TYPE_128K = 1;
  
  public static final int TYPE_256K = 15;
  
  public static final int TYPE_SILICON_DISC = 240;
  
  public static final int TYPE_128_SILICON_DISC = 241;
  
  public static final int TYPE_512K = 255;
  
  protected int[] baseRAM = new int[8];
  
  protected int[] readMap = new int[8];
  
  protected int[] writeMap = new int[8];
  
  protected int ramTYPE;
  
  protected boolean lower = true;
  
  protected boolean upper = true;
  
  public boolean plus = false;
  
  public boolean multi = false;
  
  protected int upperROM = 0;
  
  protected int plusROM = 0;
  
  protected int bankRAM = -1;
  
  protected static final int BASE_RAM = 0;
  
  protected static final int BASE_4MB_slot0 = 9;
  
  protected static final int BASE_4MB_slot1 = 17;
  
  protected static final int BASE_4MB_slot2 = 25;
  
  protected static final int BASE_4MB_slot3 = 33;
  
  protected static final int BASE_4MB_slot4 = 41;
  
  protected static final int BASE_4MB_slot5 = 49;
  
  protected static final int BASE_4MB_slot6 = 57;
  
  protected static final int BASE_4MB_slot7 = 65;
  
  protected static final int BASE_LOWROM = 73;
  
  protected static final int BASE_UPROM = 74;
  
  protected static final int BASE_ASIC = 106;
  
  protected static final int BASE_PLUS = 107;
  
  protected static final int BASE_MULTIFACE = 108;
  
  protected boolean asiclocked;
  
  protected boolean asicRamActive;
  
  int lowRomLoc;
  
  int lowRomPage;
  
  int red;
  
  int green;
  
  int blue;
  
  byte[] posbuf;
  
  int[] spriteX;
  
  int[] spriteY;
  
  int spritepos;
  
  int[] oldmag;
  
  int[] magnify;
  
  int[] xmag;
  
  int[] ymag;
  
  int[] mag;
  
  protected Color[] sprites;
  
  int[][] sprdata;
  
  public BufferedImage[] spriteImg;
  
  String[] CheckInfo;
  
  public boolean has4MB;
  
  int slot4mb;
  
  int oldport;
  
  int actualport;
  
  boolean firstinit;
  
  public CPCMemory(int type) {
    super("CPC Memory", 65536, 109);
    this.asiclocked = true;
    this.asicRamActive = false;
    this.posbuf = new byte[2];
    this.spriteX = new int[16];
    this.spriteY = new int[16];
    this.oldmag = new int[16];
    this.magnify = new int[] { 0, 1, 2, 4 };
    this.xmag = new int[16];
    this.ymag = new int[16];
    this.mag = new int[16];
    this.sprites = new Color[16];
    this.sprdata = new int[16][256];
    this.spriteImg = new BufferedImage[16];
    this.CheckInfo = new String[] { "reset", "setROM", "setLowerEnabled", "setMultiEnabled", "setUpperEnabled", "setUpperROM", "setRamBank" };
    this.has4MB = false;
    this.firstinit = false;
    this.cpc464 = new int[] { 1, 137, 127, 237, 73, 195, 128, 5, 195, 130 };
    this.cpc664 = new int[] { 1, 137, 127, 237, 73, 195, 123, 5, 195, 138 };
    this.cpc6128 = new int[] { 1, 137, 127, 237, 73, 195, 145, 5, 195, 138 };
    this.DEBUG = false;
    this.roms32 = false;
    this.DEBUG_MF2 = false;
    enable32Roms(Settings.getBoolean("32_roms_enabled", false));
    setRAMType(type);
    reset();
  }
  
  public int getRamType() {
    return this.ramtype;
  }
  
  public int readFromAsic(int address) {
    return this.mem[this.baseAddr[106] + (address & 0x3FFF)] & 0xFF;
  }
  
  public void writeToAsic(int address, int value) {
    this.mem[this.baseAddr[106] + (address & 0x3FFF)] = (byte)value;
  }
  
  public void spritepalette() {
    int i;
    for (i = 0; i < 16; i++)
      setSprite(i); 
    for (i = 0; i < 16; i++) {
      this.blue = readFromAsic(25634 + i * 2) & 0xF;
      this.red = readFromAsic(25634 + i * 2) >> 4 & 0xF;
      this.green = readFromAsic(25635 + i * 2) & 0xF;
      setSpritePalette(i, this.red, this.green, this.blue);
    } 
  }
  
  public void spritepalette(int i) {
    setSprite(i);
    this.blue = readFromAsic(25634 + i * 2) & 0xF;
    this.red = readFromAsic(25634 + i * 2) >> 4 & 0xF;
    this.green = readFromAsic(25635 + i * 2) & 0xF;
    setSpritePalette(i, this.red, this.green, this.blue);
  }
  
  public void eraseSprite(int index) {
    this.mag[index] = 0;
    this.oldmag[index] = -1;
    this.spriteX[index] = -2000;
    this.spriteY[index] = -2000;
    this.xmag[index] = 0;
    this.ymag[index] = 0;
  }
  
  public void setSpritePos(int index) {
    this.spritepos = 24576 + index * 8;
    this.posbuf[0] = (byte)readFromAsic(this.spritepos);
    this.posbuf[1] = (byte)readFromAsic(this.spritepos + 1);
    this.spriteX[index] = getWord(this.posbuf, 0);
    if ((this.spriteX[index] & 0x300) == 768)
      this.spriteX[index] = this.spriteX[index] | 0xFF00; 
    if ((this.spriteX[index] & 0x8000) != 0)
      this.spriteX[index] = -(0 - this.spriteX[index] & 0xFFFF); 
    this.posbuf[0] = (byte)readFromAsic(this.spritepos + 2);
    this.posbuf[1] = (byte)readFromAsic(this.spritepos + 3);
    this.spriteY[index] = getWord(this.posbuf, 0);
    if ((this.spriteY[index] & 0x100) == 256)
      this.spriteY[index] = this.spriteY[index] | 0xFF00; 
    if ((this.spriteY[index] & 0x8000) != 0)
      this.spriteY[index] = -(0 - this.spriteY[index] & 0xFFFF); 
  }
  
  public void setMag(int index) {
    this.spritepos = 24576 + index * 8;
    for (int i = 0; i < 4; i++) {
      this.mag[index] = readFromAsic(this.spritepos + 4 + i) & 0xF;
      if (this.mag[index] != 0)
        break; 
    } 
    if (this.mag[index] != this.oldmag[index]) {
      this.xmag[index] = this.magnify[this.mag[index] >> 2 & 0x3];
      this.ymag[index] = this.magnify[this.mag[index] & 0x3];
    } 
    this.oldmag[index] = this.mag[index];
  }
  
  public int getXM(int index) {
    return this.xmag[index];
  }
  
  public int getYM(int index) {
    return this.ymag[index];
  }
  
  public int getSpriteX(int index) {
    setSpritePos(index);
    return this.spriteX[index];
  }
  
  public int getSpriteY(int index) {
    return this.spriteY[index] * 2;
  }
  
  public void setSpritePalette(int pen, int r, int g, int b) {
    r &= 0xF;
    g &= 0xF;
    b &= 0xF;
    this.sprites[pen] = new Color(r * 17, g * 17, b * 17);
  }
  
  public int[] getSprite(int index) {
    spritepalette(index);
    return this.sprdata[index];
  }
  
  public void setSprite(int index) {
    try {
      this.spritepos = 16384 + index * 256;
      for (int i = 0; i < (this.sprdata[index]).length; i++) {
        int val = 0;
        val = readFromAsic(i + this.spritepos) & 0xF;
        if (val > 0) {
          this.sprdata[index][i] = this.sprites[val - 1].getRGB();
        } else {
          this.sprdata[index][i] = -123456789;
        } 
      } 
      putSpriteImg(index);
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void putSpriteImg(int index) {
    if (this.sprites[index] == null)
      return; 
    BufferedImage spriteI = new BufferedImage(32, 32, 2);
    int xoff = 0;
    int yoff = 0;
    for (int y = 0; y < 32; y += 2) {
      for (int x = 0; x < 32; x += 2) {
        int rgb = this.sprdata[index][yoff * 16 + xoff];
        if (rgb == -123456789)
          rgb = 0; 
        xoff++;
        spriteI.setRGB(x, y, rgb);
        spriteI.setRGB(x + 1, y, rgb);
        spriteI.setRGB(x + 1, y + 1, rgb);
        spriteI.setRGB(x, y + 1, rgb);
      } 
      xoff = 0;
      yoff++;
    } 
    switch (index) {
      case 0:
        Desktop.sprite1.setIcon(new ImageIcon(spriteI));
        break;
      case 1:
        Desktop.sprite2.setIcon(new ImageIcon(spriteI));
        break;
      case 2:
        Desktop.sprite3.setIcon(new ImageIcon(spriteI));
        break;
      case 3:
        Desktop.sprite4.setIcon(new ImageIcon(spriteI));
        break;
      case 4:
        Desktop.sprite5.setIcon(new ImageIcon(spriteI));
        break;
      case 5:
        Desktop.sprite6.setIcon(new ImageIcon(spriteI));
        break;
      case 6:
        Desktop.sprite7.setIcon(new ImageIcon(spriteI));
        break;
      case 7:
        Desktop.sprite8.setIcon(new ImageIcon(spriteI));
        break;
      case 8:
        Desktop.sprite9.setIcon(new ImageIcon(spriteI));
        break;
      case 9:
        Desktop.sprite10.setIcon(new ImageIcon(spriteI));
        break;
      case 10:
        Desktop.sprite11.setIcon(new ImageIcon(spriteI));
        break;
      case 11:
        Desktop.sprite12.setIcon(new ImageIcon(spriteI));
        break;
      case 12:
        Desktop.sprite13.setIcon(new ImageIcon(spriteI));
        break;
      case 13:
        Desktop.sprite14.setIcon(new ImageIcon(spriteI));
        break;
      case 14:
        Desktop.sprite15.setIcon(new ImageIcon(spriteI));
        break;
      case 15:
        Desktop.sprite16.setIcon(new ImageIcon(spriteI));
        break;
    } 
  }
  
  public void pluspalette(int ink) {
    this.blue = readFromAsic(25600 + ink * 2) & 0xF;
    this.red = readFromAsic(25600 + ink * 2) >> 4 & 0xF;
    this.green = readFromAsic(25601 + ink * 2) & 0xF;
    GateArray.setPlusPalette(ink, this.red, this.green, this.blue);
  }
  
  public void setPlus(boolean pl) {
    this.plus = pl;
  }
  
  public void reset() {
    this.lowRomLoc = 0;
    this.lowRomPage = 0;
    System.out.println("Memory reset!");
    setMemoryRAMBank(192);
    this.asiclocked = true;
    this.asicRamActive = false;
    this.upper = false;
    this.lower = true;
    this.multi = false;
    this.useplus = false;
    this.upperROM = 0;
    this.plusROM = 0;
    remap();
    GateArray.cpc.psg.resetRegisters();
  }
  
  public void set4MBRamBank(int value) {
    this.actualport = value;
    this.slot4mb = 127 - (value >> 8 & 0xFF);
    setMemoryRAMBank(value & 0xFF);
  }
  
  public void set4MBSlot(int port) {
    this.actualport = port;
    this.slot4mb = 127 - (port >> 8 & 0xFF);
  }
  
  public void setRAMType(int value) {
    this.has4MB = Settings.getBoolean("memory_4mb", false);
    this.ramtype = value;
    this.ramTYPE = value;
    getMem(0, 65536);
    int i;
    for (i = 1; i < 9; i++) {
      if ((this.ramTYPE & 0x1) != 0) {
        getMem(i, 65536);
      } else {
        freeMem(i, 65536);
      } 
      this.ramTYPE >>= 1;
    } 
    for (i = 9; i < 17; i++)
      getMem(i, 65536); 
    for (i = 17; i < 25; i++)
      getMem(i, 65536); 
    for (i = 25; i < 33; i++)
      getMem(i, 65536); 
    for (i = 33; i < 41; i++)
      getMem(i, 65536); 
    for (i = 41; i < 49; i++)
      getMem(i, 65536); 
    for (i = 49; i < 57; i++)
      getMem(i, 65536); 
    for (i = 57; i < 65; i++)
      getMem(i, 65536); 
    for (i = 65; i < 73; i++)
      getMem(i, 65536); 
    getMem(106, 16384);
    getMem(108, 16384);
  }
  
  public int getRAMType() {
    return this.ramtype;
  }
  
  public static boolean showram = false;
  
  int[] cpc464;
  
  int[] cpc664;
  
  int[] cpc6128;
  
  protected boolean DEBUG;
  
  protected boolean roms32;
  
  boolean useplus;
  
  int oldvalue;
  
  int ia;
  
  int ib;
  
  public int selInk;
  
  int oldInk;
  
  public static int byteNoise;
  
  boolean DEBUG_MF2;
  
  int region;
  
  public byte AsmRom;
  
  public void setLowerROM(byte[] data) {
    if (data == null || data.length < 1)
      return; 
    String language = CPC.language;
    String version = "v";
    if (language.toLowerCase().equals("fr"))
      version = "f"; 
    if (language.toLowerCase().equals("es"))
      version = "s"; 
    byte[] buffer = new byte[data.length];
    System.arraycopy(data, 0, buffer, 0, buffer.length);
    int CPCType = 1;
    Switches.ROM = "CPC464";
    int i;
    for (i = 0; i < this.cpc464.length; i++) {
      if (this.cpc464[i] != (buffer[i] & 0xFF)) {
        CPCType = 2;
        Switches.ROM = "CPC664";
        break;
      } 
    } 
    if (CPCType == 2)
      for (i = 0; i < this.cpc664.length; i++) {
        if (this.cpc664[i] != (buffer[i] & 0xFF)) {
          CPCType = 3;
          Switches.ROM = "CPC6128";
          break;
        } 
      }  
    if (CPCType == 3)
      for (i = 0; i < this.cpc6128.length; i++) {
        if (this.cpc6128[i] != (buffer[i] & 0xFF)) {
          CPCType = 0;
          Switches.ROM = "UNKNOWN";
          break;
        } 
      }  
    String RAM = "128K";
    switch (this.ramtype) {
      case 0:
        RAM = "64K";
        break;
      case 1:
        RAM = "128K";
        break;
      case 15:
      case 240:
        RAM = "320K";
        break;
      case 255:
        RAM = "576K";
        break;
    } 
    if (this.has4MB)
      RAM = "4MB"; 
    int pos = 1646;
    switch (CPCType) {
      case 1:
        RAM = RAM + " Microcomputer";
        if (this.ramtype == 1 || this.ramtype == 15 || this.ramtype == 240 || this.ramtype == 255) {
          if (!this.has4MB) {
            RAM = RAM + " (" + version + "1)";
          } else {
            RAM = RAM + "  (" + version + "1)";
          } 
        } else {
          RAM = RAM + "  (" + version + "1)";
        } 
        if (showram)
          System.arraycopy(RAM.getBytes(), 0, buffer, pos, RAM.length()); 
        break;
      case 2:
        pos = 1647;
        RAM = RAM + " Microcomputer";
        if (this.ramtype == 1 || this.ramtype == 15 || this.ramtype == 240 || this.ramtype == 255) {
          if (!this.has4MB) {
            RAM = RAM + " (v2)";
          } else {
            RAM = RAM + "  (v2)";
          } 
        } else {
          RAM = RAM + "  (v2)";
        } 
        if (showram)
          System.arraycopy(RAM.getBytes(), 0, buffer, pos, RAM.length()); 
        break;
      case 3:
        pos = 1673;
        if ((buffer[1667] & 0xFF) == 75)
          break; 
        RAM = RAM + " Microcomputer";
        if (this.ramtype == 1 || this.ramtype == 15 || this.ramtype == 240 || this.ramtype == 255) {
          if (!this.has4MB) {
            RAM = RAM + " (" + version + "3) ";
          } else {
            RAM = RAM + "  (" + version + "3) ";
          } 
        } else {
          RAM = RAM + "  (" + version + "3) ";
        } 
        if (showram)
          System.arraycopy(RAM.getBytes(), 0, buffer, pos, RAM.length()); 
        break;
    } 
    GateArray.cpc.setOS();
    System.out.println("Your selected System ROM is for " + Switches.ROM);
    setROM(73, buffer);
  }
  
  public byte[] getLowerROM() {
    byte[] data = new byte[16384];
    int base = getMem(73, 16384);
    System.arraycopy(this.mem, base, data, 0, 16384);
    return data;
  }
  
  public byte[] getLowerFONT() {
    byte[] data = new byte[2048];
    int base = getMem(73, 16384);
    System.arraycopy(this.mem, base + 14336, data, 0, 2048);
    return data;
  }
  
  public void writeLowerFONT(byte[] data) {
    int base = getMem(73, 16384);
    System.arraycopy(data, 0, this.mem, base + 14336, 2048);
  }
  
  public void setMultiROM(byte[] data) {
    setROM(108, data);
  }
  
  public void setUpperROM(int rom, byte[] data) {
    if (data != null && this.DEBUG)
      System.out.println("Putting upper rom to slot " + rom); 
    setROM(74 + (rom & (this.roms32 ? 31 : 15)), data);
  }
  
  public void enable32Roms(boolean enable) {
    this.roms32 = enable;
    Settings.setBoolean("32_roms_enabled", this.roms32);
  }
  
  public void setPlusROM(int rom, byte[] data) {
    setROM(107 + rom, data);
  }
  
  protected void setROM(int base, byte[] data) {
    try {
      if (data == null || data.length == 0) {
        freeMem(base, 16384);
      } else {
        base = getMem(base, 16384);
        System.arraycopy(data, 0, this.mem, base, Math.min(16384, data.length));
      } 
      remap();
    } catch (Exception e) {
      e.printStackTrace();
      System.exit(0);
    } 
  }
  
  public void setLowerEnabled(boolean value) {
    if (this.lower != value) {
      this.lower = value;
      remap();
    } 
  }
  
  public void setMultiEnabled(boolean value) {
    if (this.multi != value) {
      this.multi = value;
      remap();
    } 
  }
  
  public void setUpperEnabled(boolean value) {
    if (this.upper != value) {
      this.upper = value;
      remap();
    } 
  }
  
  public void setUpperROM(int value) {
    if (this.plus && value > 127) {
      value &= 0x1F;
      this.useplus = true;
      if (this.plusROM != value) {
        this.plusROM = value;
        remap();
      } 
      plusRom = value;
    } else {
      upperRom = value;
      if (this.plus) {
        value &= 0xF;
        if (value == 7) {
          this.useplus = true;
          value = 3;
          if (this.plusROM != value) {
            this.plusROM = value;
            remap();
          } 
        } else {
          this.useplus = true;
          value = 1;
          if (this.plusROM != value) {
            this.plusROM = value;
            remap();
          } 
        } 
      } else {
        value &= this.roms32 ? 31 : 15;
        this.useplus = false;
        if (this.upperROM != value) {
          this.upperROM = value;
          remap();
        } 
      } 
    } 
  }
  
  public int getUpperROM() {
    return upperRom;
  }
  
  public int getPlusROM() {
    return plusRom;
  }
  
  public void setMemoryRAMBank(int value) {
    if (this.oldport != this.actualport || this.oldvalue != value) {
      this.oldport = this.actualport;
      this.oldvalue = value & 0xFF;
      if (this.DEBUG_BANK)
        System.out.println("Bankswitch to: " + Util.hex((byte)value) + " at port " + Util.hex((short)this.oldport)); 
    } 
    value &= 0x3F;
    this.bankRAM = value;
    remapRAM();
    remap();
  }
  
  public void setForcedRAMBank(int value) {
    if (this.oldport != this.actualport || this.oldvalue != value) {
      this.oldport = this.actualport;
      this.oldvalue = value & 0xFF;
      System.out.println("Bankswitch to: " + Util.hex((byte)value) + " at port " + Util.hex((short)this.oldport));
    } 
    value &= 0x3F;
    this.bankRAM = value;
    remapRAM();
    for (int i = 0; i < 8; i++)
      this.writeMap[i] = this.baseRAM[i]; 
  }
  
  public int getRAMBank() {
    return this.bankRAM | 0xC0;
  }
  
  protected void remapRAM() {
    int mask = 0;
    boolean enable128k = false;
    boolean enable256k = false;
    boolean silicondiskenabled = false;
    if (this.ramtype == 1 || this.ramtype == 241)
      enable128k = true; 
    if (this.ramtype == 15)
      enable256k = true; 
    if (this.ramtype == 241 || this.ramtype == 240)
      silicondiskenabled = true; 
    if (enable128k)
      mask |= 0x7; 
    if (enable256k)
      mask |= 0x1F; 
    if (silicondiskenabled)
      mask |= 0x3F; 
    if (mask != 0)
      this.bankRAM &= mask; 
    int bankBase = ((this.bankRAM & 0x38) >> 3) + 0 + 1;
    bankBase = this.baseAddr[bankBase];
    if (bankBase == -1) {
      bankBase = this.baseAddr[0];
      this.bankRAM = 0;
    } 
    if (this.has4MB) {
      int BASE_4MB = ((this.bankRAM & 0x38) >> 3) + 0 + 1;
      switch (this.slot4mb) {
        case 1:
          BASE_4MB = ((this.bankRAM & 0x38) >> 3) + 9;
          break;
        case 2:
          BASE_4MB = ((this.bankRAM & 0x38) >> 3) + 17;
          break;
        case 3:
          BASE_4MB = ((this.bankRAM & 0x38) >> 3) + 25;
          break;
        case 4:
          BASE_4MB = ((this.bankRAM & 0x38) >> 3) + 33;
          break;
        case 5:
          BASE_4MB = ((this.bankRAM & 0x38) >> 3) + 41;
          break;
        case 6:
          BASE_4MB = ((this.bankRAM & 0x38) >> 3) + 49;
          break;
        case 7:
          BASE_4MB = ((this.bankRAM & 0x38) >> 3) + 57;
          break;
        case 8:
          BASE_4MB = ((this.bankRAM & 0x38) >> 3) + 65;
          break;
        default:
          BASE_4MB = ((this.bankRAM & 0x38) >> 3) + 0 + 1;
          break;
      } 
      bankBase = BASE_4MB;
      bankBase = this.baseAddr[bankBase];
      if (bankBase == -1) {
        System.out.println("BANK " + Util.hex((byte)this.bankRAM) + " at slot4mb " + this.slot4mb + " is not available!");
        bankBase = this.baseAddr[0];
        this.bankRAM = 0;
      } 
    } 
    int base = ((this.bankRAM & 0x7) == 2) ? bankBase : this.baseAddr[0];
    for (int i = 0; i < 8; i++)
      this.baseRAM[i] = base + i * 8192; 
    if ((this.bankRAM & 0x5) == 1) {
      this.baseRAM[6] = bankBase + 49152;
      this.baseRAM[7] = bankBase + 57344;
      if ((this.bankRAM & 0x2) == 2) {
        this.baseRAM[2] = base + 49152;
        this.baseRAM[3] = base + 57344;
      } 
    } else if ((this.bankRAM & 0x4) == 4) {
      this.baseRAM[2] = bankBase + (this.bankRAM & 0x3) * 16384;
      this.baseRAM[3] = this.baseRAM[2] + 8192;
    } 
  }
  
  public int readByte(int address) {
    try {
      if (this.multi && address > 8191 && address < 16384)
        return MultiFace.MultifaceRam[address - 8192] & 0xFF; 
      if (getRAMBank() == 192) {
        if (address > 16383 && address < 32768 && this.asicRamActive)
          return readFromAsic(address); 
        if (address > 16383 && address < 32768 && this.baseRAM[3] == this.baseAddr[106] + 8192)
          return readFromAsic(address); 
      } 
      byteNoise = this.mem[this.readMap[address >> 13] + (address & 0x1FFF)] & 0xFF;
      return byteNoise;
    } catch (Exception e) {
      return 0;
    } 
  }
  
  public int readWriteByte(int address) {
    try {
      return this.mem[this.writeMap[address >> 13] + (address & 0x1FFF)] & 0xFF;
    } catch (Exception e) {
      return 0;
    } 
  }
  
  public int readWriteByte(int address, int forcedbank, boolean forced) {
    try {
      if (address > 16383 && address < 32768) {
        int g = getRAMBank();
        setForcedRAMBank(forcedbank);
        int b = this.mem[this.writeMap[address >> 13] + (address & 0x1FFF)] & 0xFF;
        setForcedRAMBank(g);
        return b;
      } 
      return readWriteByte(address);
    } catch (Exception e) {
      e.printStackTrace();
      return 0;
    } 
  }
  
  public int writeByte(int address, int value) {
    byteNoise = value & 0xFF;
    try {
      if (!this.plus && address > 8191 && address < 16384 && this.multi) {
        MultiFace.MultifaceRam[address - 8192] = (byte)(value & 0xFF);
      } else {
        this.mem[this.writeMap[address >> 13] + (address & 0x1FFF)] = (byte)value;
        if (address > 16383 && address < 32768 && this.asicRamActive) {
          writeToAsic(address, value);
          if (address > 25599 && address < 25634 && this.asicRamActive)
            pluspalette((address - 25600) / 2); 
        } 
      } 
    } catch (Exception exception) {}
    return value & 0xFF;
  }
  
  public int writeBytde(int address, int value) {
    try {
      if (!this.plus && address > 8191 && address < 16384 && this.multi) {
        MultiFace.MultifaceRam[address - 8192] = (byte)(value & 0xFF);
      } else {
        if (address > 24575 && address < 32768 && this.asicRamActive) {
          writeToAsic(address, value);
          if (address > 25599 && address < 25634)
            pluspalette((address - 25600) / 2); 
          return value & 0xFF;
        } 
        if (address > 16383 && address < 20480 && this.asicRamActive)
          writeToAsic(address, value); 
        if (getRAMBank() == 192 && address > 16383 && address < 32768 && this.baseRAM[2] == this.baseAddr[106]) {
          writeToAsic(address, value);
          if (address > 25599 && address < 25634 && this.baseRAM[2] == this.baseAddr[106])
            pluspalette((address - 25600) / 2); 
          return value & 0xFF;
        } 
        if (getRAMBank() == 192 && address > 16383 && address < 32768 && this.asicRamActive) {
          writeToAsic(address, value);
          return value & 0xFF;
        } 
        this.mem[this.writeMap[address >> 13] + (address & 0x1FFF)] = (byte)value;
        if (address > 25599 && address < 25634 && this.asicRamActive)
          pluspalette((address - 25600) / 2); 
      } 
    } catch (Exception exception) {}
    return value & 0xFF;
  }
  
  public int writeBytes(int address, int value) {
    try {
      if (!this.plus && address > 8191 && address < 16384 && this.multi) {
        MultiFace.MultifaceRam[address - 8192] = (byte)(value & 0xFF);
      } else {
        if (this.plus && address > 16383 && address < 32768 && this.asicRamActive && this.baseRAM[2] == this.baseAddr[106]) {
          writeToAsic(address, value);
          if (address > 25599 && address < 25634)
            pluspalette((address - 25600) / 2); 
          return value & 0xFF;
        } 
        this.mem[this.writeMap[address >> 13] + (address & 0x1FFF)] = (byte)value;
      } 
    } catch (Exception exception) {}
    return value & 0xFF;
  }
  
  public int writeByte(int address, int value, int forcedbank, boolean forced) {
    if (address > 16383 && address < 32768) {
      int g = getRAMBank();
      setForcedRAMBank(forcedbank);
      try {
        this.mem[this.writeMap[address >> 13] + (address & 0x1FFF)] = (byte)value;
      } catch (Exception exception) {}
      int b = value & 0xFF;
      setForcedRAMBank(g);
      return b;
    } 
    return writeByte(address, value);
  }
  
  public void poke(int address, int value) {
    this.mem[address] = (byte)value;
  }
  
  public void remap() {
    mapRAM();
    mapROMs();
  }
  
  protected void mapRAM() {
    for (int i = 0; i < 8; i++) {
      this.writeMap[i] = this.baseRAM[i];
      this.readMap[i] = this.baseRAM[i];
    } 
  }
  
  public void enableAsicRam(boolean asicRamActive, int lowRomLoc, int lowRomPage, boolean asicLocked, int region) {
    this.region = region;
    this.asiclocked = asicLocked;
    this.asicRamActive = asicRamActive;
    this.lowRomLoc = lowRomLoc;
    this.lowRomPage = lowRomPage;
    remapRAM();
    remap();
  }
  
  public boolean getAsicActive() {
    return this.asicRamActive;
  }
  
  protected void mapROMs() {
    if (!this.plus)
      this.useplus = false; 
    int addr;
    if (!this.plus && this.lower && (addr = this.baseAddr[73]) != -1)
      if (!this.plus && this.multi && (addr = this.baseAddr[108]) != -1) {
        if (this.DEBUG_MF2)
          System.out.println("Mapping multiface ROM"); 
        this.readMap[0] = this.baseAddr[108];
        this.writeMap[1] = this.baseAddr[108] + 8192;
        this.readMap[1] = this.baseAddr[108] + 8192;
      } else {
        this.readMap[0] = addr;
        this.readMap[1] = addr + 8192;
      }  
    if (this.plus && this.lower && (addr = this.baseAddr[107 + this.lowRomPage]) != -1) {
      this.readMap[this.lowRomLoc] = addr;
      this.readMap[this.lowRomLoc + 1] = addr + 8192;
    } 
    if (this.upper && !this.useplus) {
      addr = this.baseAddr[74 + this.upperROM];
      if (addr == -1)
        addr = this.baseAddr[74]; 
      if (addr != -1) {
        this.readMap[6] = addr;
        this.readMap[7] = addr + 8192;
      } 
    } 
    if (this.upper && this.plus && this.useplus) {
      addr = this.baseAddr[107 + this.plusROM];
      if (addr == -1)
        addr = this.baseAddr[107]; 
      if (addr != -1) {
        this.readMap[6] = addr;
        this.readMap[7] = addr + 8192;
      } 
    } 
  }
  
  public void writePort(int port, int value) {
    setUpperROM(value);
  }
  
  public int readPort(int port) {
    this.cal = Calendar.getInstance();
    int result = 255;
    if (port == 65278)
      result = 160; 
    if (Settings.getBoolean("realtime_clock", false)) {
      if (port == 65266)
        result = this.cal.get(2); 
      if (port == 65268)
        result = this.cal.get(5); 
      if (port == 65270)
        result = this.cal.get(11); 
      if (port == 65272)
        result = this.cal.get(12); 
      if (port == 65274)
        result = this.cal.get(13); 
      if (port == 65276)
        result = this.cal.get(7); 
    } 
    return result;
  }
  
  public int readByte(int address, Object config) {
    return readByte(address);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\CPCMemory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */