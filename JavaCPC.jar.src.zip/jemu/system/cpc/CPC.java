package jemu.system.cpc;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.zip.GZIPOutputStream;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.table.AbstractTableModel;
import javazoom.jl.converter.Converter;
import jemu.core.ArrayFind;
import jemu.core.Compressor;
import jemu.core.Util;
import jemu.core.cpu.Processor;
import jemu.core.device.Computer;
import jemu.core.device.Device;
import jemu.core.device.DeviceMapping;
import jemu.core.device.MultiFace.MultiFace;
import jemu.core.device.crtc.Basic6845;
import jemu.core.device.floppy.Drive;
import jemu.core.device.floppy.UPD765A;
import jemu.core.device.internalfilesystem.ImageExporter;
import jemu.core.device.internalfilesystem.InternalFileSystem;
import jemu.core.device.io.PPI8255;
import jemu.core.device.keyboard.VirtualKeyBoard;
import jemu.core.device.memory.Memory;
import jemu.core.device.printer.Printer;
import jemu.core.device.realtimeclock.SF2Mouse;
import jemu.core.device.realtimeclock.SFIIClock;
import jemu.core.device.sound.AY_3_8910;
import jemu.core.device.sound.AY_3_8910_A;
import jemu.core.device.sound.AY_3_8910_B;
import jemu.core.device.sound.AmDrum;
import jemu.core.device.sound.DigiBlaster;
import jemu.core.device.sound.YMControl;
import jemu.core.device.speech.DKTronics;
import jemu.core.device.speech.SSA1;
import jemu.core.device.tape.CDT2WAV;
import jemu.core.device.tape.TapeDeck;
import jemu.core.samples.Samples;
import jemu.settings.Palette;
import jemu.settings.RSettings;
import jemu.settings.Settings;
import jemu.system.cpc.plus.ASIC;
import jemu.system.cpc.plus.CPRLoader;
import jemu.ui.Autotype;
import jemu.ui.Basic;
import jemu.ui.Console;
import jemu.ui.Debugger;
import jemu.ui.Desktop;
import jemu.ui.Display;
import jemu.ui.JEMU;
import jemu.ui.Main;
import jemu.ui.Switches;
import jemu.ui.VideoRecorder;
import jemu.ui.copyURL;
import jemu.ui.paint.MovieMaker;
import jemu.ui.paint.normalPaint;
import jemu.ui.paint.overscanPaint;
import jemu.ui.samp2cdt;
import jemu.util.ass.EditorPanel;
import jemu.util.diss.Disassembler;
import jemu.util.diss.DissZ80;
import net.sourceforge.lhadecompressor.LhaEntry;
import net.sourceforge.lhadecompressor.LhaFile;

public final class CPC extends Computer implements ActionListener {
  boolean z80turbo = false;
  
  boolean recordvideo;
  
  public static boolean playvideo;
  
  BufferedOutputStream videostream;
  
  BufferedInputStream videoinput;
  
  int videosize;
  
  int videoframe;
  
  public void recordVideo() {
    if (!this.recordvideo) {
      try {
        this.videostream = new BufferedOutputStream(new FileOutputStream(new File("output.cpc")));
      } catch (Exception exception) {}
      this.recordvideo = true;
      this.videoframe = 0;
    } 
  }
  
  public AY_3_8910 getPSG() {
    return this.psg;
  }
  
  public void playFrame() {
    try {
      if (this.videoinput == null) {
        this.videoinput = new BufferedInputStream(new FileInputStream(new File("output.cpc")));
        this.videosize = (int)(new File("output.cpc")).length() / 16384;
        this.videoframe = 0;
      } 
      byte[] vdata = new byte[16384];
      this.videoinput.read(vdata);
      byte[] regs = new byte[14];
      System.arraycopy(vdata, 10192, regs, 0, 14);
      this.psg.writePSGRegisters(regs);
      this.gateArray.setNewMode(vdata[6096] & 0xFF);
      int i;
      for (i = 0; i < 16384; i++)
        POKE(49152 + i, vdata[i]); 
      for (i = 0; i < 17; i++)
        INK(i, vdata[6097 + i] & 0xFF); 
      if (this.videoframe >= this.videosize) {
        this.videoframe = 0;
        this.videoinput.close();
        this.videoinput = new BufferedInputStream(new FileInputStream(new File("output.cpc")));
      } 
      this.recorder.feedDisplay();
      this.recorder.frame.setText("" + this.videoframe++);
    } catch (Exception e) {
      try {
        this.videoinput.close();
        this.videoinput = new BufferedInputStream(new FileInputStream(new File("output.cpc")));
      } catch (Exception er) {
        playvideo = false;
      } 
    } 
  }
  
  public void recordFrame() {
    if (this.videostream == null)
      return; 
    int i;
    for (i = 0; i < 17; i++)
      POKE(55249 + i, (byte)GateArray.getInk(i)); 
    for (i = 0; i < this.SCR_CODE.length; i++)
      POKE(51152 + i, (byte)this.SCR_CODE[i]); 
    POKE(55248, (byte)this.gateArray.getScreenMode());
    byte[] vdata = new byte[16384];
    for (int j = 0; j < 16384; j++)
      vdata[j] = (byte)PEEK(49152 + j); 
    System.arraycopy(this.psg.getPSGRegisters(), 0, vdata, 10192, 14);
    this.recorder.feedDisplay();
    this.recorder.frame.setText("" + this.videoframe++);
    try {
      this.videostream.write(vdata);
    } catch (Exception e) {
      this.recordvideo = false;
    } 
  }
  
  public void stopVideo() {
    if (this.recordvideo) {
      this.recordvideo = false;
      try {
        this.videostream.close();
      } catch (Exception e) {
        this.recordvideo = false;
      } 
    } else {
      playvideo = false;
      if (this.videoinput != null)
        try {
          this.videoinput.close();
          this.videoframe = 0;
        } catch (Exception exception) {} 
    } 
  }
  
  public void playVideo() {
    playvideo = true;
  }
  
  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == this.recorder.rec)
      recordVideo(); 
    if (e.getSource() == this.recorder.stop)
      stopVideo(); 
    if (e.getSource() == this.recorder.play)
      playVideo(); 
  }
  
  VideoRecorder recorder = new VideoRecorder();
  
  String ramdisk = "null";
  
  public static String language = "en";
  
  public static boolean disableresync = false;
  
  protected boolean started = false;
  
  public static String cpctype = null;
  
  public static String snapshot = null;
  
  public static String drivea = null;
  
  public static String driveb = null;
  
  public static String assemblercode = null;
  
  public static String crtctype = null;
  
  public static String bootdrive = null;
  
  public static String tape = null;
  
  public static String amsdos = null;
  
  public static String autotypetext = null;
  
  public static String usemem = null;
  
  protected boolean loadsnapshot = false;
  
  protected boolean loaddrivea = false;
  
  protected boolean loaddriveb = false;
  
  protected boolean loadtapedrive = false;
  
  protected boolean assemblecode = false;
  
  public static int formNo = 100;
  
  public boolean overscan;
  
  int phonemelength;
  
  int speechlength;
  
  public static int speechCount = 0;
  
  public static int xms = 0;
  
  public static boolean loadalarm = false;
  
  public static boolean setPaintOnTop = false;
  
  public static boolean PaintOnTop = false;
  
  public static boolean resetcpc = false;
  
  public static int[] blocks = null;
  
  public static String[] ids = null;
  
  public static int importoverscanscr = 0;
  
  public static int importnormalscr = 0;
  
  public static boolean updatebox = false;
  
  public static boolean normalupdatebox = false;
  
  boolean saveOCP = true;
  
  public static boolean restorePaint = false;
  
  public static boolean insertOverscanPaintDisk = false;
  
  public static boolean insertNormalPaintDisk = false;
  
  static int writePal = 0;
  
  static boolean reset = false;
  
  public static overscanPaint overscanPaintBox;
  
  public static normalPaint normalPaintBox;
  
  static JFrame overscanPaintFrame = null;
  
  static JFrame normalPaintFrame = null;
  
  public static boolean savescreen = false;
  
  public static boolean saveoverscanscreen = false;
  
  public int coscreen = 0;
  
  public static boolean initreset = false;
  
  int posi;
  
  int phase;
  
  static int[] cheat = new int[] { 
      0, 20, 11, 28, 7, 3, 30, 6, 24, 4, 
      15, 22, 31, 27, 25, 14 };
  
  protected final String YM_Header = "YM";
  
  static byte[] cheatc = null;
  
  static boolean havescreen = false;
  
  static byte[] screencontent = new byte[16384];
  
  static boolean restorescreen = false;
  
  protected int inspect = 0;
  
  protected int boot = 0;
  
  protected int inspectdrive = 0;
  
  public static boolean bootthis = false;
  
  public static boolean resync = false;
  
  protected int countFPS;
  
  protected int checkFPS = 44;
  
  protected int recountFPS;
  
  protected int errCount;
  
  public static boolean inspectA = false;
  
  public static boolean inspectB = false;
  
  JDialog loadFile = new JDialog();
  
  public String[] entries = null;
  
  String[][] enter = (String[][])null;
  
  JTable fileTable = new JTable();
  
  public int[] users = null;
  
  protected int track;
  
  public static boolean showAudioCapture;
  
  public static boolean fromCapture = false;
  
  public static int resetInk = 0;
  
  public static boolean changeBorder = false;
  
  int mp3count = 0;
  
  String mp3name = "";
  
  Frame mp3 = new Frame();
  
  JButton conv = new JButton("Reading MP3...");
  
  public static int bitrate = 8;
  
  public Converter mp3c = new Converter();
  
  protected long checkmem = 2147483647L;
  
  public static boolean doOptimize = false;
  
  public static boolean doRecord = false;
  
  protected int tapestop = 0;
  
  public static boolean Bypass = false;
  
  public static boolean shouldquit = false;
  
  public static boolean trueaudio = false;
  
  public static boolean tape_stereo = false;
  
  public static boolean isCDT = false;
  
  public static String downloadname = "";
  
  public static boolean download = false;
  
  public static String downstring = "";
  
  public static int DoDownload = 0;
  
  public static String Oldpage = "";
  
  public static boolean shouldBoot = false;
  
  protected int turbocount = 0;
  
  protected int tapedistort = 0;
  
  public static int recordcount = 0;
  
  protected byte TapeRecbyte = 0;
  
  public static boolean savetape;
  
  public static boolean tapeload = false;
  
  public static int tape_delay = 22;
  
  public static int tapestarttimer = 0;
  
  public static int playcount;
  
  public static int tapeBandPosition;
  
  protected int doLoad;
  
  public static boolean inserttape;
  
  public static boolean tapeloaded = false;
  
  public static String loadtape;
  
  protected int portB = 0;
  
  public static byte[] tapesample;
  
  protected boolean tapeEnabled = true;
  
  public static int tapesound;
  
  public static int tapesoundb = 0;
  
  public static boolean playing;
  
  public static boolean savecheck;
  
  public static boolean stoptape;
  
  public static boolean tapeRelay;
  
  public static boolean tapeRec;
  
  public static boolean tapeRewind;
  
  public static boolean tapePlay;
  
  public static boolean tapeFastForward;
  
  public static boolean tapedeck = false;
  
  public TapeDeck TapeDrive = new TapeDeck();
  
  public static boolean st_mode;
  
  public static boolean zx_mode = false;
  
  public boolean YM_Interleaved = false;
  
  public static int YM_registers = 16;
  
  public static boolean oldYM = false;
  
  public int[] YM_Data = new int[1000000];
  
  public int[] YM_DataInterleaved = new int[1000000];
  
  public static int ymcount = 0;
  
  public static int YM_RecCount = 0;
  
  public static int YM_vbl = 0;
  
  public static boolean YM_Rec = false;
  
  public static boolean YM_Play = false;
  
  public static boolean YM_Stop = false;
  
  public static boolean YM_Save = false;
  
  public static boolean YM_Load = false;
  
  public static boolean atari_st_mode;
  
  public static boolean spectrum_mode = false;
  
  public boolean shouldcount = false;
  
  public int begincount = 0;
  
  public static int vcount;
  
  public static int YM_Minutes;
  
  public static int YM_Seconds;
  
  public static int msecs = 0;
  
  public String YMtitle = "";
  
  public String YMauthor = "";
  
  public String YMcreator = "";
  
  JCheckBox YMInterleaved = new JCheckBox("Interleaved");
  
  public static int timefire = 2;
  
  public int previousPortValue = 0;
  
  public int launchcount;
  
  public int blastercount;
  
  public int launchcode;
  
  public int launchcaul = 0;
  
  public static int savetimer;
  
  public static int saveOnExit;
  
  public static int saveOn = 0;
  
  public static boolean df0mod;
  
  public static boolean df1mod;
  
  public static boolean df2mod;
  
  public static boolean df3mod = false;
  
  public boolean fired = false;
  
  public int firetimer;
  
  JCheckBox AmHeader = new JCheckBox("Write AMSDOS header");
  
  public boolean soverscan = false;
  
  JCheckBox Overscan = new JCheckBox("Save overscan screen?");
  
  JTextField AddressA = new JTextField();
  
  JTextField AddressB = new JTextField();
  
  JTextField SetByte = new JTextField();
  
  private int startimageA = 16384;
  
  private int startimageB = 49152;
  
  boolean amheader = false;
  
  public String MP3_HEADER_A = "ÿû";
  
  public String MP3_HEADER_B = "ID3";
  
  public String CNG_HEADER = "CNGSOFT's LZ";
  
  public boolean CNG = false;
  
  public boolean CNGBIN = false;
  
  protected String CSW_HEADER = "Compressed Square Wave";
  
  protected String WAV_HEADER = "RIFF";
  
  protected int[] WAV_HEADER_11KHz = new int[] { 
      82, 73, 70, 70, 217, 252, 164, 0, 87, 65, 
      86, 69, 102, 109, 116, 32, 16, 0, 0, 0, 
      1, 0, 1, 0, 17, 43, 0, 0, 17, 43, 
      0, 0, 1, 0, 8, 0, 100, 97, 116, 97, 
      181, 252, 164, 0 };
  
  protected int[] WAV_HEADER_22KHz = new int[] { 
      82, 73, 70, 70, 217, 252, 164, 0, 87, 65, 
      86, 69, 102, 109, 116, 32, 16, 0, 0, 0, 
      1, 0, 1, 0, 34, 86, 0, 0, 34, 86, 
      0, 0, 1, 0, 8, 0, 100, 97, 116, 97, 
      181, 252, 164, 0 };
  
  protected int[] WAV_HEADER_44KHz = new int[] { 
      82, 73, 70, 70, 217, 252, 164, 0, 87, 65, 
      86, 69, 102, 109, 116, 32, 16, 0, 0, 0, 
      1, 0, 1, 0, 68, 172, 0, 0, 68, 172, 
      0, 0, 1, 0, 8, 0, 100, 97, 116, 97, 
      181, 252, 164, 0 };
  
  public int[] SCR_HEADER = new int[] { 
      0, 74, 65, 86, 65, 67, 80, 67, 32, 83, 
      67, 82, 0, 0, 0, 0, 0, 0, 2, 0, 
      0, 0, 192, 0, 0, 64, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 64, 0, 66, 4, 0, 
      0, 74, 65, 86, 65, 67, 80, 67, 32, 36, 
      36, 36, 255, 0, 255, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0 };
  
  public int[] PAL_HEADER = new int[] { 
      0, 17, 22, 13, 18, 22, 32, 32, 32, 80, 
      65, 76, 0, 0, 0, 0, 0, 0, 2, 239, 
      0, 9, 136, 0, 239, 0, 9, 136, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 239, 0, 0, 138, 5, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0 };
  
  public int[] PAL_INK = new int[] { 
      84, 68, 85, 92, 88, 93, 76, 69, 77, 86, 
      70, 87, 94, 64, 95, 78, 71, 79, 82, 66, 
      83, 90, 89, 91, 74, 67, 75, 84, 84, 84, 
      84 };
  
  public int[] SCR_CODE = new int[] { 
      58, 208, 215, 205, 28, 189, 33, 209, 215, 70, 
      72, 205, 56, 188, 175, 33, 209, 215, 70, 72, 
      245, 229, 205, 50, 188, 225, 241, 35, 60, 254, 
      16, 32, 241, 201, 0, 0 };
  
  public int[] FLIP_CODE = new int[] { 
      1, 12, 188, 237, 73, 1, 48, 189, 237, 73, 
      205, 25, 189, 118, 118, 205, 9, 187, 254, 32, 
      202, 249, 231, 1, 12, 188, 237, 73, 1, 16, 
      189, 237, 73, 205, 25, 189, 118, 118, 195, 208, 
      231, 201 };
  
  static int[] CodeP0 = new int[] { 
      243, 1, 17, 188, 33, 208, 223, 126, 237, 121, 
      35, 13, 32, 249, 1, 160, 127, 58, 208, 215, 
      237, 121, 237, 73, 1, 184, 127, 237, 73, 33, 
      209, 215, 17, 0, 100, 1, 34, 0, 237, 176, 
      205, 208, 207, 56, 251, 251, 201 };
  
  static int[] CodeP1 = new int[] { 
      1, 14, 244, 237, 73, 1, 192, 246, 237, 73, 
      175, 237, 121, 1, 146, 247, 237, 73, 1, 69, 
      246, 237, 73, 6, 244, 237, 120, 1, 130, 247, 
      237, 73, 1, 0, 246, 237, 73, 23, 201 };
  
  static int[] CodeP3 = new int[] { 
      255, 0, 255, 119, 179, 81, 168, 212, 98, 57, 
      156, 70, 43, 21, 138, 205, 238 };
  
  public static boolean FDCReset = false;
  
  public CPCDiscImage dskImage;
  
  public CPCDiscImage dskImageA;
  
  public CPCDiscImage dskImageB;
  
  public CPCDiscImage dskImageC;
  
  public CPCDiscImage dskImageD;
  
  protected static GridBagConstraints gbcConstraints = null;
  
  static String[] Palette = new String[33];
  
  public static Color[] Greencols = new Color[] { 
      new Color(0), new Color(657930), new Color(1250067), new Color(1907997), new Color(2500134), new Color(3158064), new Color(3750201), new Color(4408131), new Color(5000268), new Color(5723991), 
      new Color(6316128), new Color(6974058), new Color(7566195), new Color(8224125), new Color(8816262), new Color(9474192), new Color(10066329), new Color(10724259), new Color(11316396), new Color(11908533), 
      new Color(12566463), new Color(13224393), new Color(13816530), new Color(14474460), new Color(15066597), new Color(15724527), new Color(16316664), new Color(8224125), new Color(4408131), new Color(15724527), 
      new Color(657930), new Color(11908533) };
  
  public static Color[] Palcols = new Color[] { 
      new Color(0), new Color(125), new Color(255), new Color(8192000), new Color(8192125), new Color(8192255), new Color(16711680), new Color(16711805), new Color(16711935), new Color(32000), 
      new Color(32125), new Color(32255), new Color(8224000), new Color(8224125), new Color(8224255), new Color(16743680), new Color(16743805), new Color(16743935), new Color(65280), new Color(65405), 
      new Color(65535), new Color(8257280), new Color(8257405), new Color(8257535), new Color(16776960), new Color(16777085), new Color(16777215), new Color(8224125), new Color(16711805), new Color(16777085), 
      new Color(125), new Color(65405) };
  
  public static final Color[] pale = new Color[] { 
      new Color(0), new Color(125), new Color(255), new Color(8192000), new Color(8192125), new Color(8192255), new Color(16711680), new Color(16711805), new Color(16711935), new Color(32000), 
      new Color(32125), new Color(32255), new Color(8224000), new Color(8224125), new Color(8224255), new Color(16743680), new Color(16743805), new Color(16743935), new Color(65280), new Color(65405), 
      new Color(65535), new Color(8257280), new Color(8257405), new Color(8257535), new Color(16776960), new Color(16777085), new Color(16777215), new Color(8224125), new Color(16711805), new Color(16777085), 
      new Color(125), new Color(65405) };
  
  protected boolean turbo = false;
  
  protected int turbotimer;
  
  public int autotyper = 0;
  
  public int readkey = 0;
  
  int[] eventArray;
  
  boolean[] shifter;
  
  public static boolean shift;
  
  protected static final int PSG_PORT_A = -1;
  
  protected static final int PPI_PORT_B = -2;
  
  protected static final int PPI_PORT_C = -3;
  
  public static int autotype = 4;
  
  protected static final int CYCLES_PER_SECOND_CPC = 1000000;
  
  protected static final int CYCLES_PER_SECOND_ST = 2000000;
  
  protected static final int CYCLES_PER_SECOND_ZX = 1773400;
  
  protected static final int AUDIO_TEST = 1073741824;
  
  protected String lowerROM = null;
  
  public HashMap upperROMs = new HashMap<>();
  
  public Z80 z80 = new Z80(1000000L);
  
  public static CPCMemory memory = null;
  
  public static CPCMemory memory2 = null;
  
  protected SSA1 ssa1 = (SSA1)addDevice((Device)new SSA1());
  
  protected DKTronics dktronics = (DKTronics)addDevice((Device)new DKTronics());
  
  protected AmDrum amdrum = (AmDrum)addDevice((Device)new AmDrum());
  
  protected InternalFileSystem internalfilesystem = (InternalFileSystem)addDevice((Device)new InternalFileSystem());
  
  protected DigiBlaster digiblaster = (DigiBlaster)addDevice((Device)new DigiBlaster());
  
  protected SFIIClock sfclock = (SFIIClock)addDevice((Device)new SFIIClock());
  
  protected SF2Mouse sfmouse = (SF2Mouse)addDevice((Device)new SF2Mouse());
  
  protected MultiFace multiface = (MultiFace)addDevice((Device)new MultiFace());
  
  protected Printer printer = (Printer)addDevice((Device)new Printer());
  
  protected Basic6845 crtc = (Basic6845)addDevice((Device)new Basic6845());
  
  protected GateArray gateArray = (GateArray)addDevice((Device)new GateArray(this));
  
  protected PAL16L8 Pal16L8 = (PAL16L8)addDevice(new PAL16L8(this));
  
  protected ASIC asic = (ASIC)addDevice((Device)new ASIC(this));
  
  protected PPI8255 ppi = (PPI8255)addDevice((Device)new PPI8255());
  
  public UPD765A fdc = (UPD765A)addDevice((Device)new UPD765A(4));
  
  protected AY_3_8910 psg = (AY_3_8910)addDevice((Device)new AY_3_8910());
  
  protected Disassembler disassembler = (Disassembler)new DissZ80();
  
  protected int audioAdd = this.psg.getSoundPlayer().getClockAdder(1073741824, 1000000);
  
  protected int audioCount = 0;
  
  protected Drive[] floppies = new Drive[4];
  
  protected KeyboardB keyboardb = new KeyboardB();
  
  protected KeyboardA keyboarda = new KeyboardA();
  
  protected KeyboardN keyboardn = new KeyboardN();
  
  DeviceMapping amstradSpeech = new DeviceMapping((Device)this.ssa1, 1041, 0);
  
  DeviceMapping dktronicsSpeech = new DeviceMapping((Device)this.dktronics, 65535, 64510);
  
  DeviceMapping multiface2 = new DeviceMapping((Device)this.multiface, 0, 0);
  
  boolean amsspeech = false;
  
  public boolean dkspeech = false;
  
  protected final int[] PSG_VALUES;
  
  protected AY_3_8910_A psg1;
  
  protected final int[] PSG_VALUES1;
  
  protected AY_3_8910_B psg2;
  
  protected final int[] PSG_VALUES2;
  
  protected Z84C30 z84c30;
  
  protected String CPCname;
  
  protected String[] DSKImages;
  
  protected int[] DSKSizes;
  
  protected FormatPanel format;
  
  public static int seldrive;
  
  JFrame fram;
  
  DeviceMapping psg1a;
  
  DeviceMapping psg1b;
  
  DeviceMapping psg1c;
  
  DeviceMapping psg1d;
  
  DeviceMapping psg1e;
  
  DeviceMapping psg1f;
  
  DeviceMapping psg1al;
  
  DeviceMapping psg1bl;
  
  DeviceMapping psg1cl;
  
  DeviceMapping psg1dl;
  
  DeviceMapping psg1el;
  
  DeviceMapping psg1fl;
  
  DeviceMapping psg2a;
  
  DeviceMapping psg2b;
  
  DeviceMapping psg2c;
  
  DeviceMapping psg2d;
  
  DeviceMapping psg2e;
  
  DeviceMapping psg2f;
  
  DeviceMapping psg2al;
  
  DeviceMapping psg2bl;
  
  DeviceMapping psg2cl;
  
  DeviceMapping psg2dl;
  
  DeviceMapping psg2el;
  
  DeviceMapping psg2fl;
  
  DeviceMapping z84c30a;
  
  JFrame forma;
  
  public static boolean up0;
  
  public static boolean up1;
  
  CPRLoader CPRloader;
  
  VirtualKeyBoard key;
  
  JFrame keyFram;
  
  int diff;
  
  JFileChooser fileDlg;
  
  String[] magics;
  
  MagicCPCDiscImage[] magicimage;
  
  File magiccheck;
  
  String[][] lastMagicDir;
  
  String[][] actualMagicDir;
  
  long[][] lastMagicSizes;
  
  long[][] actualMagicSizes;
  
  public static boolean protect;
  
  public Basic6845 getCRTC() {
    return this.crtc;
  }
  
  public Printer getPrinter() {
    return this.printer;
  }
  
  public void setMode(int mo) {
    this.gateArray.screenMode = mo;
  }
  
  public void setR52(int r) {
    this.gateArray.r52 = r;
  }
  
  public int getR52() {
    return this.gateArray.r52;
  }
  
  public int getHPOS() {
    return this.gateArray.getHPOS();
  }
  
  public int getVPOS() {
    return this.gateArray.getVPOS();
  }
  
  public int getBorderL() {
    return this.gateArray.xmin;
  }
  
  public int getBorderR() {
    return this.gateArray.xmax;
  }
  
  public int getBorderH() {
    return this.gateArray.borderHeight;
  }
  
  public GateArray getGateArray() {
    return this.gateArray;
  }
  
  public ASIC getAsic() {
    return this.asic;
  }
  
  public void setDrive(int drive) {
    this.fdc.resetDrive();
    if (this.floppies[drive] == null)
      this.floppies[drive] = new Drive(2); 
    this.fdc.setDrive(drive, this.floppies[drive]);
  }
  
  public int getDrive() {
    return this.fdc.getDrive();
  }
  
  public void ASMDisk(String filename, int drive, String forma, int tracks) {
    int format = 9;
    forma = forma.toLowerCase();
    if (forma.contains("data") && 
      tracks == 80)
      format = 11; 
    if (forma.contains("sys")) {
      format = 13;
      if (tracks == 80)
        format = 15; 
    } 
    String discimage = this.DSKImages[format];
    int discsize = this.DSKSizes[format];
    this.dskImage = null;
    byte[] bufferdsk = getRom("file/" + discimage, discsize);
    try {
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File(filename)));
      bos.write(bufferdsk);
      bos.close();
      Settings.set("file.drive" + Integer.toString(drive), filename);
      boolean flop = Switches.FloppySound;
      int drv = getCurrentDrive();
      setCurrentDrive(drive);
      DSK_Load(filename, bufferdsk);
      Switches.FloppySound = flop;
      setCurrentDrive(drv);
      Desktop.checkdrives = true;
      this.fdc.poll();
      this.fdc.getInfo(drive);
    } catch (Exception exception) {}
  }
  
  public void updateDrive(int drive) {
    try {
      String nam = Settings.get("file.drive" + Integer.toString(drive), "empty");
      if (nam.equals("empty")) {
        Settings.setBoolean("loaddrive" + Integer.toString(drive), false);
        return;
      } 
      Settings.setBoolean("loaddrive" + Integer.toString(drive), true);
      int drv = getCurrentDrive();
      setCurrentDrive(drive);
      boolean flop = Switches.FloppySound;
      Switches.FloppySound = false;
      File dat = new File(nam);
      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(dat));
      byte[] bufferdsk = new byte[bis.available()];
      bis.read(bufferdsk);
      bis.close();
      DSK_Load(nam, bufferdsk);
      Switches.FloppySound = flop;
      setCurrentDrive(drv);
      Desktop.checkdrives = true;
    } catch (Exception exception) {}
  }
  
  public void setClock(int value) {
    this.psg1.setClock(value);
    this.psg2.setClock(value);
    reSync();
  }
  
  public void setStereo(boolean stereo) {
    this.psg1.setStereo(stereo);
    this.psg2.setStereo(stereo);
    reSync();
  }
  
  public void setInverted(boolean i) {
    this.psg1.setInverted(i);
    this.psg2.setInverted(i);
  }
  
  public CPC(Applet applet, String name) {
    super(applet, name);
    this.psg.getClass();
    (new int[4])[0] = 2;
    this.psg.getClass();
    this.psg.getClass();
    (new int[4])[1] = 0x2 | 0x1;
    this.psg.getClass();
    this.psg.getClass();
    (new int[4])[2] = 0x2 | 0x4;
    this.psg.getClass();
    this.psg.getClass();
    this.psg.getClass();
    this.PSG_VALUES = new int[] { 0, 0, 0, 0x2 | 0x4 | 0x1 };
    this.psg1 = (AY_3_8910_A)addDevice((Device)new AY_3_8910_A());
    this.psg1.getClass();
    (new int[4])[0] = 2;
    this.psg1.getClass();
    this.psg1.getClass();
    (new int[4])[1] = 0x2 | 0x1;
    this.psg1.getClass();
    this.psg1.getClass();
    (new int[4])[2] = 0x2 | 0x4;
    this.psg1.getClass();
    this.psg1.getClass();
    this.psg1.getClass();
    this.PSG_VALUES1 = new int[] { 0, 0, 0, 0x2 | 0x4 | 0x1 };
    this.psg2 = (AY_3_8910_B)addDevice((Device)new AY_3_8910_B());
    this.psg2.getClass();
    (new int[4])[0] = 2;
    this.psg2.getClass();
    this.psg2.getClass();
    (new int[4])[1] = 0x2 | 0x1;
    this.psg2.getClass();
    this.psg2.getClass();
    (new int[4])[2] = 0x2 | 0x4;
    this.psg2.getClass();
    this.psg2.getClass();
    this.psg2.getClass();
    this.PSG_VALUES2 = new int[] { 0, 0, 0, 0x2 | 0x4 | 0x1 };
    this.z84c30 = (Z84C30)addDevice(new Z84C30());
    this.CPCname = "";
    this.psg1a = new DeviceMapping((Device)this.psg1, 65535, 63616);
    this.psg1b = new DeviceMapping((Device)this.psg1, 65535, 63617);
    this.psg1c = new DeviceMapping((Device)this.psg1, 65535, 63618);
    this.psg1d = new DeviceMapping((Device)this.psg1, 65535, 63619);
    this.psg1e = new DeviceMapping((Device)this.psg1, 65535, 63620);
    this.psg1f = new DeviceMapping((Device)this.psg1, 65535, 63621);
    this.psg1al = new DeviceMapping((Device)this.psg1, 65535, 63872);
    this.psg1bl = new DeviceMapping((Device)this.psg1, 65535, 63873);
    this.psg1cl = new DeviceMapping((Device)this.psg1, 65535, 63874);
    this.psg1dl = new DeviceMapping((Device)this.psg1, 65535, 63875);
    this.psg1el = new DeviceMapping((Device)this.psg1, 65535, 63876);
    this.psg1fl = new DeviceMapping((Device)this.psg1, 65535, 63877);
    this.psg2a = new DeviceMapping((Device)this.psg2, 65535, 63624);
    this.psg2b = new DeviceMapping((Device)this.psg2, 65535, 63625);
    this.psg2c = new DeviceMapping((Device)this.psg2, 65535, 63626);
    this.psg2d = new DeviceMapping((Device)this.psg2, 65535, 63627);
    this.psg2e = new DeviceMapping((Device)this.psg2, 65535, 63628);
    this.psg2f = new DeviceMapping((Device)this.psg2, 65535, 63629);
    this.psg2al = new DeviceMapping((Device)this.psg2, 65535, 63880);
    this.psg2bl = new DeviceMapping((Device)this.psg2, 65535, 63881);
    this.psg2cl = new DeviceMapping((Device)this.psg2, 65535, 63882);
    this.psg2dl = new DeviceMapping((Device)this.psg2, 65535, 63883);
    this.psg2el = new DeviceMapping((Device)this.psg2, 65535, 63884);
    this.psg2fl = new DeviceMapping((Device)this.psg2, 65535, 63885);
    this.z84c30a = new DeviceMapping(this.z84c30, 65535, 63616);
    this.CPRloader = new CPRLoader();
    this.diff = 368;
    this.magics = new String[4];
    this.magicimage = new MagicCPCDiscImage[] { null, null, null, null };
    this.lastMagicDir = new String[4][];
    this.actualMagicDir = new String[4][];
    this.lastMagicSizes = new long[4][];
    this.actualMagicSizes = new long[4][];
    this.plotlogo = 0;
    this.loadedplus = false;
    this.black = 0;
    this.freq = 100;
    this.lcount = 0;
    this.keytime = 0;
    this.register = 0;
    this.waitlopos = 0;
    this.slomo = 1;
    this.speed = 0;
    this.baud = 0;
    this.readmorse = false;
    this.tapetime = 2000000;
    this.tapedelay = 22;
    this.updateled = false;
    this.evenimage = false;
    this.storeflipA = false;
    this.storeflipB = false;
    this.stopper = 0;
    this.checkgun = 0;
    this.guncolour = 0;
    this.releasegun = 0;
    this.bk = 0;
    this.lopos = 5000;
    this.skip = false;
    this.basictypelength = -1;
    this.basicchecktype = 1;
    this.basictypepos = 0;
    this.BUFFER_START = 44170;
    this.BUFFER_START_464 = 44196;
    this.rom464 = false;
    this.os_unpatch = new byte[2];
    this.os_patch = new byte[] { -19, -4 };
    this.mouseButton = 0;
    this.mbutton = new boolean[] { false, false, false };
    this.prepare = 0;
    this.typetext = null;
    this.plusui = true;
    this.baswait = 0;
    this.basauto = new Thread() {
        public void run() {
          CPC.this.bas.update();
        }
      };
    this.fromautoboot = false;
    this.enterpressed = false;
    this.counterInit = 100;
    this.errorcode = 0;
    this.snpCapture = false;
    this.mouseSensivity = 7;
    this.keyStroke = new byte[11000000];
    this.compatibility = false;
    this.wasWinCPC = false;
    this.doimageexport = false;
    this.isPlayCity = true;
    this.sectorsize = 512;
    this.doautotype = 0;
    this.doargs = 0;
    this.frequency = 44100;
    this.snacount = 0;
    this.snaocount = 0;
    this.rdiskbanks = new int[] { 
        204, 205, 206, 207, 212, 213, 214, 215, 220, 221, 
        222, 223, 228, 229, 230, 231, 236, 237, 238, 239, 
        244, 245, 246, 247, 252, 253, 254, 255 };
    this.banks = new int[] { 
        192, 196, 197, 198, 199, 204, 205, 206, 207, 212, 
        213, 214, 215, 220, 221, 222, 223, 228, 229, 230, 
        231, 236, 237, 238, 239, 244, 245, 246, 247, 252, 
        253, 254, 255 };
    this.banks4mb = new int[] { 
        32704, 32708, 32709, 32710, 32711, 32716, 32717, 32718, 32719, 32724, 
        32725, 32726, 32727, 32732, 32733, 32734, 32735, 32740, 32741, 32742, 
        32743, 32748, 32749, 32750, 32751, 32756, 32757, 32758, 32759, 32764, 
        32765, 32766, 32767, 32452, 32453, 32454, 32455, 32460, 32461, 32462, 
        32463, 32468, 32469, 32470, 32471, 32476, 32477, 32478, 32479, 32484, 
        32485, 32486, 32487, 32492, 32493, 32494, 32495, 32500, 32501, 32502, 
        32503, 32508, 32509, 32510, 32511, 32196, 32197, 32198, 32199, 32204, 
        32205, 32206, 32207, 32212, 32213, 32214, 32215, 32220, 32221, 32222, 
        32223, 32228, 32229, 32230, 32231, 32236, 32237, 32238, 32239, 32244, 
        32245, 32246, 32247, 32252, 32253, 32254, 32255, 31940, 31941, 31942, 
        31943, 31948, 31949, 31950, 31951, 31956, 31957, 31958, 31959, 31964, 
        31965, 31966, 31967, 31972, 31973, 31974, 31975, 31980, 31981, 31982, 
        31983, 31988, 31989, 31990, 31991, 31996, 31997, 31998, 31999, 31684, 
        31685, 31686, 31687, 31692, 31693, 31694, 31695, 31700, 31701, 31702, 
        31703, 31708, 31709, 31710, 31711, 31716, 31717, 31718, 31719, 31724, 
        31725, 31726, 31727, 31732, 31733, 31734, 31735, 31740, 31741, 31742, 
        31743, 31428, 31429, 31430, 31431, 31436, 31437, 31438, 31439, 31444, 
        31445, 31446, 31447, 31452, 31453, 31454, 31455, 31460, 31461, 31462, 
        31463, 31468, 31469, 31470, 31471, 31476, 31477, 31478, 31479, 31484, 
        31485, 31486, 31487, 31172, 31173, 31174, 31175, 31180, 31181, 31182, 
        31183, 31188, 31189, 31190, 31191, 31196, 31197, 31198, 31199, 31204, 
        31205, 31206, 31207, 31212, 31213, 31214, 31215, 31220, 31221, 31222, 
        31223, 31228, 31229, 31230, 31231, 30916, 30917, 30918, 30919, 30924, 
        30925, 30926, 30927, 30932, 30933, 30934, 30935, 30940, 30941, 30942, 
        30943, 30948, 30949, 30950, 30951, 30956, 30957, 30958, 30959, 30964, 
        30965, 30966, 30967, 30972, 30973, 30974, 30975 };
    this.keys = null;
    this.keyOffset = 0;
    this.FrameCount = 0;
    this.reloadsnp = false;
    this.keybytes = null;
    this.snpout = null;
    this.snpcounter = 0;
    this.buffSNA = null;
    this.snapfile = new File(System.getProperty("user.home"), "/JavaCPC/savestate.sna");
    this.restorebuf = false;
    this.storebuf = false;
    this.playcity = false;
    this.cruncher = new Cruncher();
    this.buff = new byte[1520];
    this.toPackfiles = new String[] { 
        "AR-1A.SCR", "AR-1B.SCR", "AR-2A.SCR", "AR-2B.SCR", "AR-BIGTA.SCR", "AR-BIGTB.SCR", "BE-1A.SCR", "BE-1B.SCR", "BE-2A.SCR", "BE-2B.SCR", 
        "BE-3A.SCR", "BE-3B.SCR", "BE-4A.SCR", "BE-4B.SCR", "BE-BIGTA.SCR", "BE-BIGTB.SCR", "BIGTA.SCR", "BIGTB.SCR", "CA-1A.SCR", "CA-1B.SCR", 
        "CA-2A.SCR", "CA-2B.SCR", "CA-3A.SCR", "CA-3B.SCR", "CA-BIGTA.SCR", "CA-BIGTB.SCR", "CHEATA.SCR", "CHEATB.SCR", "DI-1A.SCR", "DI-1B.SCR", 
        "DI-2A.SCR", "DI-2B.SCR", "DI-3A.SCR", "DI-3B.SCR", "DI-4A.SCR", "DI-4B.SCR", "DI-5A.SCR", "DI-5B.SCR", "DI-6A.SCR", "DI-6B.SCR", 
        "DI-BIGTA.SCR", "DI-BIGTB.SCR", "EA-1A.SCR", "EA-1B.SCR", "EA-2A.SCR", "EA-2B.SCR", "EA-3A.SCR", "EA-3B.SCR", "EA-BIGTA.SCR", "EA-BIGTB.SCR", 
        "EA-EJECA.SCR", "EA-EJECB.SCR", "EA-HOMEA.SCR", "EA-HOMEB.SCR", "EA-JAILA.SCR", "EA-JAILB.SCR", "EA-POLIA.SCR", "EA-POLIB.SCR", "HA-1A.SCR", "HA-1B.SCR", 
        "HA-2A.SCR", "HA-2B.SCR", "HA-3A.SCR", "HA-3B.SCR", "HA-3-2A.SCR", "HA-3-2B.SCR", "HA-4A.SCR", "HA-4B.SCR", "HA-5A.SCR", "HA-5B.SCR", 
        "HA-BIGTA.SCR", "HA-BIGTB.SCR", "IC-1A.SCR", "IC-1B.SCR", "IC-2A.SCR", "IC-2B.SCR", "IC-BIGTA.SCR", "IC-BIGTB.SCR", "IN-BIGTA.SCR", "IN-BIGTB.SCR", 
        "LI-1A.SCR", "LI-1B.SCR", "LI-2A.SCR", "LI-2B.SCR", "LI-3A.SCR", "LI-3B.SCR", "LI-BIGTA.SCR", "LI-BIGTB.SCR", "LIMPA.SCR", "LIMPB.SCR", 
        "ME-1A.SCR", "ME-1B.SCR", "ME-2A.SCR", "ME-2B.SCR", "ME-3A.SCR", "ME-3B.SCR", "ME-BIGTA.SCR", "ME-BIGTB.SCR", "PR-1A.SCR", "PR-1B.SCR", 
        "PR-2A.SCR", "PR-2B.SCR", "PR-3A.SCR", "PR-3B.SCR", "PR-4A.SCR", "PR-4B.SCR", "PR-BIGTA.SCR", "PR-BIGTB.SCR", "SH-1A.SCR", "SH-1B.SCR", 
        "SH-2A.SCR", "SH-2B.SCR", "SH-3A.SCR", "SH-3B.SCR", "SH-BIGTA.SCR", "SH-BIGTB.SCR", "WA-1A.SCR", "WA-1B.SCR", "WA-2A.SCR", "WA-2B.SCR", 
        "WA-3A.SCR", "WA-3B.SCR", "WA-4A.SCR", "WA-4B.SCR", "WA-BIGTA.SCR", "WA-BIGTB.SCR", "WINA.SCR", "WINB.SCR" };
    this.del = false;
    this.ym_loop = 0;
    this.mp3loaded = false;
    this.dskname = "empty";
    this.OCPListener = new ItemListener() {
        public void itemStateChanged(ItemEvent itemEvent) {
          int state = itemEvent.getStateChange();
          if (state == 1)
            CPC.this.saveOCP = true; 
          if (state == 2)
            CPC.this.saveOCP = false; 
        }
      };
    this.aR = 0.0D;
    this.iR = 0.0D;
    this.lR = 0.0D;
    this.dR = 0.0D;
    this.nR = 0.0D;
    this.bandThickness = new double[] { 0.0234D, 0.017D, 0.015D };
    this.timerDelay = 0;
    this.smode = 0;
    this.moviePalette = new byte[20];
    this.playMP3 = false;
    this.GateArrayINKs = new int[] { 
        20, 4, 21, 28, 24, 29, 12, 5, 13, 22, 
        6, 23, 30, 0, 31, 14, 7, 15, 18, 2, 
        19, 26, 25, 27, 10, 3, 11 };
    setBasePath("cpc");
    this.recorder.rec.addActionListener(this);
    this.recorder.stop.addActionListener(this);
    this.recorder.play.addActionListener(this);
    this.DSKImages = new String[] { 
        "parados80.dsk", "parados41.dsk", "parados40D.dsk", "romdosD1.dsk", "romdosD2.dsk", "romdosD10.dsk", "romdosD20.dsk", "romdosD40.dsk", "s-dos(romdosD80).dsk", "dataSS40.dsk", 
        "dataDS40.dsk", "dataSS80.dsk", "dataDS80.dsk", "systemSS40.dsk", "systemDS40.dsk", "systemSS80.dsk", "systemDS80.dsk", "ibmSS40.dsk", "ibmDS40.dsk", "ibmSS80.dsk", 
        "ibmDS80.dsk", "ultraform.dsk", "vortex704k.dsk" };
    this.DSKSizes = new int[] { 
        430336, 220672, 430336, 778496, 778496, 860416, 860416, 860416, 860416, 194816, 
        389376, 389376, 778496, 194816, 389376, 389376, 778496, 174336, 348416, 348416, 
        696576, 220672, 778496 };
    cheatc = getRom("file/cheat.bin", 16384);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    this.mp3.add(this.conv);
    this.conv.setFocusable(false);
    this.conv.setEnabled(false);
    this.mp3.setUndecorated(true);
    this.mp3.pack();
    this.mp3.setAlwaysOnTop(true);
    this.mp3.setLocation((d.width - (this.mp3.getSize()).width) / 2, (d.height - (this.mp3.getSize()).height) / 2);
    this.mp3.setVisible(false);
    initCPCType(name);
    this.z80.setMemoryDevice((Device)memory);
    this.z80.addInputDeviceMapping(new DeviceMapping((Device)memory, 257, 0));
    this.z80.addOutputDeviceMapping(new DeviceMapping((Device)memory, 8192, 0));
    this.z80.setInterruptDevice((Device)this.gateArray);
    this.z80.addOutputDeviceMapping(new DeviceMapping((Device)this.gateArray, 49152, 16384));
    this.z80.addOutputDeviceMapping(new DeviceMapping(this.Pal16L8, 32768, 0));
    this.z80.setCycleDevice((Device)this);
    this.crtc.setRegisterSelectMask(768, 0);
    this.crtc.setRegisterWriteMask(768, 256);
    this.crtc.setRegisterReadMask(768, 768);
    this.crtc.setRegisterStatusMask(768, 512);
    this.z80.addOutputDeviceMapping(new DeviceMapping((Device)this.amdrum, 65280, 65280));
    this.z80.addInputDeviceMapping(new DeviceMapping((Device)this.amdrum, 65280, 65280));
    this.z80.addOutputDeviceMapping(new DeviceMapping((Device)this.digiblaster, 4096, 0));
    this.z80.addOutputDeviceMapping(new DeviceMapping((Device)this.printer, 4096, 0));
    this.z80.addOutputDeviceMapping(new DeviceMapping((Device)this.multiface, 0, 0));
    this.z80.addOutputDeviceMapping(new DeviceMapping((Device)this.sfclock, 64788, 64788));
    this.z80.addOutputDeviceMapping(new DeviceMapping((Device)this.sfclock, 64789, 64789));
    this.z80.addInputDeviceMapping(new DeviceMapping((Device)this.sfclock, 64788, 64788));
    this.z80.addInputDeviceMapping(new DeviceMapping((Device)this.sfclock, 64789, 64789));
    this.z80.addInputDeviceMapping(new DeviceMapping((Device)this.sfclock, 64784, 64784));
    this.z80.addInputDeviceMapping(new DeviceMapping((Device)this.sfmouse, 64833, 64833));
    this.z80.addInputDeviceMapping(new DeviceMapping((Device)this.sfmouse, 64834, 64834));
    this.z80.addInputDeviceMapping(new DeviceMapping((Device)this.sfmouse, 64847, 64847));
    this.z80.addOutputDeviceMapping(new DeviceMapping((Device)this.sfmouse, 64847, 64847));
    this.z80.addInputDeviceMapping(new DeviceMapping((Device)this.internalfilesystem, 65520, 65520));
    this.z80.addOutputDeviceMapping(new DeviceMapping((Device)this.internalfilesystem, 65520, 65520));
    this.crtc.setCRTCListener(this.gateArray);
    this.z80.addOutputDeviceMapping(new DeviceMapping((Device)this.crtc, 16384, 0));
    this.z80.addInputDeviceMapping(new DeviceMapping((Device)this.crtc, 16384, 0));
    this.ppi.setPortMasks(256, 256, 512, 512);
    this.ppi.setReadDevice(1, (Device)this, -2);
    this.ppi.setWriteDevice(2, (Device)this, -3);
    this.ppi.setReadDevice(0, (Device)this.psg, 0);
    this.ppi.setWriteDevice(0, (Device)this.psg, 0);
    this.psg.getClass();
    this.psg.setReadDevice(0, (Device)this, -1);
    this.psg.setClockSpeed(1000000);
    this.psg2.setClockSpeed(1000000);
    this.psg1.setClockSpeed(1000000);
    mapDualYM(Settings.getBoolean("playcity", false));
    this.z80.addOutputDeviceMapping(new DeviceMapping((Device)this.ppi, 2048, 0));
    this.z80.addInputDeviceMapping(new DeviceMapping((Device)this.ppi, 2048, 0));
    this.z80.addOutputDeviceMapping(new DeviceMapping((Device)this.fdc, 1408, 256));
    this.z80.addInputDeviceMapping(new DeviceMapping((Device)this.fdc, 1408, 256));
    this.z80.addOutputDeviceMapping(new DeviceMapping((Device)this, 1409, 0));
    this.z80turbo = Settings.getBoolean("z80_turbo", false);
    this.z80.setTimes(this.z80turbo);
    for (int i = 0; i < 4; i++)
      this.floppies[i] = new Drive(2); 
  }
  
  public void setZ80Turbo(boolean turbo) {
    this.z80turbo = turbo;
    Settings.setBoolean("z80_turbo", this.z80turbo);
    this.z80.setTimes(this.z80turbo);
  }
  
  public boolean isZ80Turbo() {
    return this.z80turbo;
  }
  
  public void mapDualYM(boolean map) {
    if (map) {
      this.z80.addOutputDeviceMapping(this.psg1a);
      this.z80.addOutputDeviceMapping(this.psg1b);
      this.z80.addOutputDeviceMapping(this.psg1c);
      this.z80.addOutputDeviceMapping(this.psg1d);
      this.z80.addOutputDeviceMapping(this.psg1e);
      this.z80.addOutputDeviceMapping(this.psg1f);
      this.z80.addOutputDeviceMapping(this.psg1al);
      this.z80.addOutputDeviceMapping(this.psg1bl);
      this.z80.addOutputDeviceMapping(this.psg1cl);
      this.z80.addOutputDeviceMapping(this.psg1dl);
      this.z80.addOutputDeviceMapping(this.psg1el);
      this.z80.addOutputDeviceMapping(this.psg1fl);
      this.z80.addOutputDeviceMapping(this.psg2a);
      this.z80.addOutputDeviceMapping(this.psg2b);
      this.z80.addOutputDeviceMapping(this.psg2c);
      this.z80.addOutputDeviceMapping(this.psg2d);
      this.z80.addOutputDeviceMapping(this.psg2e);
      this.z80.addOutputDeviceMapping(this.psg2f);
      this.z80.addOutputDeviceMapping(this.psg2al);
      this.z80.addOutputDeviceMapping(this.psg2bl);
      this.z80.addOutputDeviceMapping(this.psg2cl);
      this.z80.addOutputDeviceMapping(this.psg2dl);
      this.z80.addOutputDeviceMapping(this.psg2el);
      this.z80.addOutputDeviceMapping(this.psg2fl);
      setStereo(true);
      setInverted(false);
      this.z80.addOutputDeviceMapping(this.z84c30a);
      this.psg1.getSoundPlayer1().play();
      this.psg2.getSoundPlayer2().play();
      System.out.println("PlayCity added...");
    } else {
      this.psg1.getSoundPlayer1().stop();
      this.psg2.getSoundPlayer2().stop();
      System.out.println("PlayCity removed...");
    } 
  }
  
  public Display getCPCDisplay() {
    return this.display;
  }
  
  public void formatDisk(int drive) {
    if (this.format == null) {
      this.format = new FormatPanel();
      this.forma = new JFrame("Format Disk");
      this.forma.add(this.format);
      this.forma.pack();
      this.forma.setResizable(false);
      this.forma.setVisible(false);
    } 
    this.format.drivesel.setSelectedIndex(drive);
    this.forma.setVisible(true);
  }
  
  public void formatDisk(int drive, int format) {
    String discimage = this.DSKImages[format];
    int discsize = this.DSKSizes[format];
    this.dskImage = null;
    byte[] bufferdsk = getRom("file/" + discimage, discsize);
    System.out.println("Formatting image in drive DF" + drive);
    if (drive == 0 && this.dskImageA != null)
      this.dskImage = this.dskImageA; 
    if (drive == 1 && this.dskImageB != null)
      this.dskImage = this.dskImageB; 
    if (drive == 2 && this.dskImageC != null)
      this.dskImage = this.dskImageC; 
    if (drive == 3 && this.dskImageD != null)
      this.dskImage = this.dskImageD; 
    if (this.dskImage != null) {
      String writeAs = this.dskImage.getName();
      int ok = JOptionPane.showConfirmDialog(new Frame(), "Are you sure to format your DSK\n\"" + writeAs + "\"?\nAll data will be erased!", "Confirm format", 0);
      if (ok == 0)
        try {
          BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(writeAs));
          bos.write(bufferdsk);
          bos.close();
          int drv = getCurrentDrive();
          setCurrentDrive(drive);
          boolean flop = Switches.FloppySound;
          Switches.FloppySound = false;
          DSK_Load(writeAs, bufferdsk);
          setCurrentDrive(drv);
          Switches.FloppySound = flop;
          Settings.set("file.drive" + Integer.toString(drive), writeAs);
          Settings.setBoolean("loaddrive" + Integer.toString(drive), true);
          Desktop.checkdrives = true;
        } catch (Exception exception) {} 
    } else {
      try {
        FileDialog filedia = new FileDialog(new Frame(), "Create DSK file", 1);
        if (Switches.uncompressed) {
          filedia.setFile("*.dsk");
        } else {
          filedia.setFile("*.dsz");
        } 
        filedia.setVisible(true);
        String filename = filedia.getFile();
        if (filename != null) {
          if (Switches.uncompressed) {
            if (!filename.toLowerCase().endsWith(".dsk"))
              filename = filename + ".dsk"; 
          } else if (!filename.toLowerCase().endsWith(".dsz")) {
            filename = filename + ".dsz";
          } 
          BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filename));
          bos.write(bufferdsk);
          bos.close();
          int drv = getCurrentDrive();
          setCurrentDrive(drive);
          DSK_Load(filename, bufferdsk);
          setCurrentDrive(drv);
          Settings.set("file.drive" + Integer.toString(drive), filename);
          Settings.setBoolean("loaddrive" + Integer.toString(drive), true);
          Desktop.checkdrives = true;
        } 
      } catch (Exception exception) {}
    } 
  }
  
  public JPanel VirtualKeys() {
    if (this.key == null)
      this.key = new VirtualKeyBoard(); 
    return (JPanel)this.key;
  }
  
  public Keyboard getKeyBoard() {
    return this.keyboarda;
  }
  
  private void initCPCType(String name) {
    checkArgs();
    if (Switches.Maxam)
      this.upperROMs.put("14", "MAXAM.ROM"); 
    if (usemem != null) {
      if (usemem.contains("64"))
        Switches.Memory = "TYPE_64K"; 
      if (usemem.contains("128"))
        Switches.Memory = "TYPE_128K"; 
      if (usemem.contains("256") || usemem.contains("320"))
        Switches.Memory = "TYPE_256K"; 
      if (usemem.contains("512") || usemem.contains("576"))
        Switches.Memory = "TYPE_512K"; 
    } 
    if (Switches.Memory.equals("TYPE_512K")) {
      memory = new CPCMemory(255);
    } else if (Switches.Memory.equals("TYPE_256K")) {
      memory = new CPCMemory(15);
    } else if (Switches.Memory.equals("TYPE_128K")) {
      memory = new CPCMemory(1);
    } else if (Switches.Memory.equals("TYPE_64K")) {
      memory = new CPCMemory(0);
    } else if (Switches.Memory.equals("TYPE_SILICON_DISC")) {
      memory = new CPCMemory(240);
    } else if (Switches.Memory.equals("TYPE_128_SILICON_DISC")) {
      memory = new CPCMemory(241);
    } else {
      memory = new CPCMemory(255);
    } 
    memory2 = new CPCMemory(1);
    System.out.println("Memory choosen: " + Switches.Memory);
    String name2 = name;
    if (cpctype != null)
      name = cpctype; 
    memory.setPlus(false);
    defineRoms(name);
    name = name2;
    Switches.computersys = 1;
  }
  
  protected void defineRoms(String name) {
    this.sfclock.setRunning(false);
    System.out.println("Full Clock reset");
    this.lowerROM = null;
    this.upperROMs.clear();
    memory.setLowerROM((byte[])null);
    for (int i = 0; i < 32; i++)
      memory.setUpperROM(i, (byte[])null); 
    this.CPCname = name;
    name = name.toUpperCase();
    if ("CPC464".equals(name)) {
      this.lowerROM = "OS464.ROM";
      this.upperROMs.put("0", "BASIC1-0.ROM");
      if (amsdos == null || !amsdos.equals("no"))
        this.upperROMs.put("7", "AMSDOS.ROM"); 
    } else if ("CPC464T".equals(name)) {
      this.lowerROM = "OS464.ROM";
      this.upperROMs.put("0", "BASIC1-0.ROM");
    } else if ("CPC664".equals(name)) {
      this.lowerROM = "OS664.ROM";
      this.upperROMs.put("0", "BASIC664.ROM");
      if (amsdos == null || !amsdos.equals("no"))
        this.upperROMs.put("7", "AMSDOS.ROM"); 
    } else if ("CPC464PARA".equals(name)) {
      this.lowerROM = "OS464.ROM";
      this.upperROMs.put("0", "BASIC1-0.ROM");
      this.upperROMs.put("7", "PARADOS.ROM");
    } else if ("CPC6128".equals(name)) {
      this.lowerROM = "OS6128.ROM";
      this.upperROMs.put("0", "BASIC1-1.ROM");
      if (amsdos == null || !amsdos.equals("no"))
        this.upperROMs.put("7", "AMSDOS.ROM"); 
    } else if ("ST128".equals(name)) {
      this.lowerROM = "OS6128.ROM";
      this.upperROMs.put("0", "BASIC1-1.ROM");
      this.upperROMs.put("1", "STK1.ROM");
      this.upperROMs.put("2", "STK2.ROM");
      if (amsdos == null || !amsdos.equals("no"))
        this.upperROMs.put("7", "AMSDOS.ROM"); 
    } else if ("ART".equals(name)) {
      this.lowerROM = "OS6128.ROM";
      this.upperROMs.put("0", "BASIC1-1.ROM");
      this.upperROMs.put("1", "ART0.ROM");
      this.upperROMs.put("2", "ART1.ROM");
      this.upperROMs.put("3", "ART2.ROM");
      if (amsdos == null || !amsdos.equals("no"))
        this.upperROMs.put("7", "AMSDOS.ROM"); 
    } else if ("PARADOS".equals(name)) {
      this.lowerROM = "OS6128.ROM";
      this.upperROMs.put("0", "BASIC1-1.ROM");
      this.upperROMs.put("7", "PARADOS.ROM");
    } else if ("ROMPACK".equals(name)) {
      this.lowerROM = "OS6128.ROM";
      this.upperROMs.put("0", "BASIC1-1.ROM");
      this.upperROMs.put("1", "ROMPKP1.ROM");
      this.upperROMs.put("2", "ROMPKP2.ROM");
      this.upperROMs.put("7", "PARADOS.ROM");
    } else if ("ROMSYM".equals(name)) {
      this.lowerROM = "OS6128.ROM";
      this.upperROMs.put("0", "BASIC1-1.ROM");
      this.upperROMs.put("1", "sym-romA.ROM");
      this.upperROMs.put("2", "sym-romB.ROM");
      this.upperROMs.put("3", "sym-romC.ROM");
      this.upperROMs.put("4", "sym-romD.ROM");
      this.upperROMs.put("5", "ROMPKP1.ROM");
      this.upperROMs.put("6", "ROMPKP2.ROM");
      if (amsdos == null || !amsdos.equals("no"))
        this.upperROMs.put("7", "AMSDOS.ROM"); 
    } else if ("CPC6128FR".equals(name)) {
      this.lowerROM = "OSFR.ROM";
      this.upperROMs.put("0", "BASICFR.ROM");
      if (amsdos == null || !amsdos.equals("no"))
        this.upperROMs.put("7", "AMSDOS.ROM"); 
    } else if ("CPC6128ES".equals(name)) {
      this.lowerROM = "OSES.ROM";
      this.upperROMs.put("0", "BASICES.ROM");
      if (amsdos == null || !amsdos.equals("no"))
        this.upperROMs.put("7", "AMSDOS.ROM"); 
    } else if ("SYMBOS".equals(name)) {
      this.lowerROM = "OS6128.ROM";
      this.upperROMs.put("0", "BASIC1-1.ROM");
      if (amsdos == null || !amsdos.equals("no"))
        this.upperROMs.put("7", "AMSDOS.ROM"); 
      this.upperROMs.put("1", "sym-romA.ROM");
      this.upperROMs.put("2", "sym-romB.ROM");
      this.upperROMs.put("3", "sym-romC.ROM");
      this.upperROMs.put("4", "sym-romD.ROM");
    } else if ("FUTUREOS".equals(name)) {
      this.lowerROM = "OS6128.ROM";
      this.upperROMs.put("0", "BASIC1-1.ROM");
      if (amsdos == null || !amsdos.equals("no"))
        this.upperROMs.put("7", "AMSDOS.ROM"); 
      this.upperROMs.put("10", "FOSC-E-A.ROM");
      this.upperROMs.put("11", "FOSC-E-B.ROM");
      this.upperROMs.put("12", "FOSC-E-C.ROM");
      this.upperROMs.put("13", "FOSC-E-D.ROM");
    } else if ("KCCOMPACT".equals(name)) {
      this.lowerROM = "KCCOS.ROM";
      this.upperROMs.put("0", "KCCBAS.ROM");
      if (amsdos == null || !amsdos.equals("no"))
        this.upperROMs.put("7", "AMSDOS.ROM"); 
    } else if ("COMCPC".equals(name)) {
      this.lowerROM = "OS-C64.ROM";
      this.upperROMs.put("0", "BASIC-C64.ROM");
      if (amsdos == null || !amsdos.equals("no"))
        this.upperROMs.put("7", "AMSDOS.ROM"); 
    } else if ("PLUS".equals(name)) {
      String rom = RSettings.get("lower", "none");
      if (!rom.equals("none"))
        this.lowerROM = rom; 
      rom = RSettings.get("upper_0", "none");
      if (!rom.equals("none"))
        this.upperROMs.put("0", rom); 
      rom = RSettings.get("upper_7", "none");
      if (!rom.equals("none"))
        if (amsdos != null) {
          if (amsdos.equals("yes")) {
            this.upperROMs.put("7", rom);
          } else if (!rom.toUpperCase().contains("DOS")) {
            this.upperROMs.put("7", rom);
          } 
        } else {
          this.upperROMs.put("7", rom);
        }  
      if (!Switches.disableroms) {
        rom = RSettings.get("upper_1", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("1", rom); 
        rom = RSettings.get("upper_2", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("2", rom); 
        rom = RSettings.get("upper_3", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("3", rom); 
        rom = RSettings.get("upper_4", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("4", rom); 
        rom = RSettings.get("upper_5", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("5", rom); 
        rom = RSettings.get("upper_6", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("6", rom); 
        rom = RSettings.get("upper_8", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("8", rom); 
        rom = RSettings.get("upper_9", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("9", rom); 
        rom = RSettings.get("upper_A", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("10", rom); 
        rom = RSettings.get("upper_B", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("11", rom); 
        rom = RSettings.get("upper_C", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("12", rom); 
        rom = RSettings.get("upper_D", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("13", rom); 
        rom = RSettings.get("upper_E", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("14", rom); 
        rom = RSettings.get("upper_F", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("15", rom); 
      } 
    } else if ("CUSTOM".equals(name)) {
      String rom = RSettings.get("lower", "none");
      if (!rom.equals("none"))
        this.lowerROM = rom; 
      rom = RSettings.get("upper_0", "none");
      if (!rom.equals("none"))
        this.upperROMs.put("0", rom); 
      rom = RSettings.get("upper_7", "none");
      if (!rom.equals("none"))
        if (amsdos != null) {
          if (amsdos.equals("yes")) {
            this.upperROMs.put("7", rom);
          } else if (!rom.toUpperCase().contains("DOS")) {
            this.upperROMs.put("7", rom);
          } 
        } else {
          this.upperROMs.put("7", rom);
        }  
      if (!Switches.disableroms) {
        rom = RSettings.get("upper_1", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("1", rom); 
        boolean hasramdisk = rom.contains("RDOS-EXT.ROM");
        Settings.setBoolean("ramdisk_available", hasramdisk);
        Desktop.saveram.setEnabled(hasramdisk);
        Desktop.loadram.setEnabled(hasramdisk);
        rom = RSettings.get("upper_2", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("2", rom); 
        rom = RSettings.get("upper_3", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("3", rom); 
        rom = RSettings.get("upper_4", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("4", rom); 
        rom = RSettings.get("upper_5", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("5", rom); 
        rom = RSettings.get("upper_6", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("6", rom); 
        rom = RSettings.get("upper_8", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("8", rom); 
        rom = RSettings.get("upper_9", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("9", rom); 
        rom = RSettings.get("upper_A", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("10", rom); 
        rom = RSettings.get("upper_B", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("11", rom); 
        rom = RSettings.get("upper_C", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("12", rom); 
        rom = RSettings.get("upper_D", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("13", rom); 
        rom = RSettings.get("upper_E", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("14", rom); 
        rom = RSettings.get("upper_F", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("15", rom); 
        rom = RSettings.get("m_upper_10", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("16", rom); 
        rom = RSettings.get("m_upper_11", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("17", rom); 
        rom = RSettings.get("m_upper_12", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("18", rom); 
        rom = RSettings.get("m_upper_13", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("19", rom); 
        rom = RSettings.get("m_upper_14", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("20", rom); 
        rom = RSettings.get("m_upper_15", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("21", rom); 
        rom = RSettings.get("m_upper_16", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("22", rom); 
        rom = RSettings.get("m_upper_17", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("23", rom); 
        rom = RSettings.get("m_upper_18", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("24", rom); 
        rom = RSettings.get("m_upper_19", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("25", rom); 
        rom = RSettings.get("m_upper_1a", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("26", rom); 
        rom = RSettings.get("m_upper_1b", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("27", rom); 
        rom = RSettings.get("m_upper_1c", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("28", rom); 
        rom = RSettings.get("m_upper_1d", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("29", rom); 
        rom = RSettings.get("m_upper_1e", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("30", rom); 
        rom = RSettings.get("m_upper_1f", "none");
        if (!rom.equals("none"))
          this.upperROMs.put("31", rom); 
      } 
    } 
    if (Switches.Expansion)
      this.upperROMs.put("6", "JAVACPC.ROM"); 
    Set roms = this.upperROMs.keySet();
    Iterator<String> romIt = roms.iterator();
    if (!memory.plus)
      while (romIt.hasNext()) {
        String romNum = romIt.next();
        String romName = (String)this.upperROMs.get(romNum);
        Byte slot = new Byte(romNum);
        int pos = slot.byteValue() & 0x1F;
        if (pos < 32) {
          if (romName.toLowerCase().startsWith("*")) {
            romName = romName.substring(1, romName.length());
            if ((!memory.roms32 && pos < 16) || memory.roms32) {
              memory.setUpperROM(pos, getRomFile(romName));
              System.out.println("Rom loaded: " + romName);
            } 
            continue;
          } 
          if ((!memory.roms32 && pos < 16) || memory.roms32)
            memory.setUpperROM(pos, getRomFile(this.romPath + romName)); 
        } 
      }  
  }
  
  public void initialise() {
    disableresync = false;
    this.AddressA.setEnabled(false);
    this.AddressB.setEnabled(false);
    this.AddressA.setText("");
    this.AddressB.setText("C000");
    this.AmHeader.addItemListener(new CheckBoxListener());
    this.AmHeader.setSelected(true);
    this.YMInterleaved.addItemListener(new CheckBoxListener());
    this.Overscan.addItemListener(new CheckBoxListener());
    this.YMInterleaved.setSelected(this.YM_Interleaved);
    ymcount = 0;
    YM_RecCount = 0;
    YM_vbl = 0;
    YM_Rec = false;
    YM_Play = false;
    YM_Stop = false;
    YM_Save = false;
    YM_Load = false;
    atari_st_mode = false;
    spectrum_mode = false;
    this.shouldcount = false;
    this.begincount = 0;
    YM_Minutes = 0;
    YM_Seconds = 0;
    YMControl.UpdateLCD("*YM PLAYER*");
    memory.plus = false;
    this.os_addr = 10662;
    if (!memory.plus) {
      if (this.lowerROM != null)
        if (this.lowerROM.toLowerCase().startsWith("*")) {
          this.lowerROM = this.lowerROM.substring(1, this.lowerROM.length());
          this.os = getRomFile(this.lowerROM);
          memory.setLowerROM(this.os);
        } else if (Desktop.localize.isSelected()) {
          if (this.lowerROM.toLowerCase().equals("os6128.rom")) {
            if (language.equals("fr")) {
              this.os = getRom("file/6128fr.rom", 16384);
              memory.setLowerROM(this.os);
            } else if (language.equals("es")) {
              this.os = getRom("file/6128es.rom", 16384);
              memory.setLowerROM(this.os);
            } else if (language.equals("dk")) {
              System.out.println("Danish CPC 6128 OS");
              this.os = getRom("file/6128dk.rom", 16384);
              memory.setLowerROM(this.os);
            } else {
              this.os = getRom("file/6128en.rom", 16384);
              memory.setLowerROM(this.os);
            } 
          } else if (this.lowerROM.toLowerCase().equals("os464.rom")) {
            this.os_addr = 10294;
            if (language.equals("fr")) {
              this.os = getRom("file/464fr.rom", 16384);
              memory.setLowerROM(this.os);
            } else if (language.equals("es")) {
              this.os = getRom("file/464es.rom", 16384);
              memory.setLowerROM(this.os);
            } else if (language.equals("dk")) {
              System.out.println("Danish CPC 464 OS");
              this.os = getRom("file/464dk.rom", 16384);
              memory.setLowerROM(this.os);
            } else {
              this.os = getRom("file/464en.rom", 16384);
              memory.setLowerROM(this.os);
            } 
          } else {
            this.os = getRomFile(this.romPath + this.lowerROM);
            memory.setLowerROM(this.os);
          } 
        } else {
          this.os = getRomFile(this.romPath + this.lowerROM);
          memory.setLowerROM(this.os);
        }  
      try {
        this.os_unpatch[0] = this.os[this.os_addr];
        this.os_unpatch[1] = this.os[this.os_addr + 1];
        if (Switches.ROM.equals("CPC464")) {
          this.a464 = this.os[10856];
          this.b464 = this.os[10349];
          this.c464 = this.os[10350];
          this.d464 = this.os[10351];
          this.e464 = this.os[10352];
          this.f464 = this.os[10353];
        } else {
          this.a464 = this.os[10856 + this.diff];
          this.b464 = this.os[10349 + this.diff];
          this.c464 = this.os[10350 + this.diff];
          this.d464 = this.os[10351 + this.diff];
          this.e464 = this.os[10352 + this.diff];
          this.f464 = this.os[10353 + this.diff];
        } 
      } catch (Exception exception) {}
    } 
    this.ramdisk = Settings.get("ramdisk_image", "null");
    if (!this.ramdisk.equals("null")) {
      System.out.println("Opening ramdisk image " + this.ramdisk);
      readRamDisk(this.ramdisk);
    } 
    Set roms = this.upperROMs.keySet();
    Iterator<String> romIt = roms.iterator();
    if (!memory.plus) {
      while (romIt.hasNext()) {
        String romNum = romIt.next();
        String romName = (String)this.upperROMs.get(romNum);
        Byte slot = new Byte(romNum);
        int pos = slot.byteValue() & 0x1F;
        if (pos < 32) {
          if (romName.toLowerCase().startsWith("*")) {
            romName = romName.substring(1, romName.length());
            if ((!memory.roms32 && pos < 16) || memory.roms32)
              memory.setUpperROM(pos, getRomFile(romName)); 
            continue;
          } 
          if ((!memory.roms32 && pos < 16) || memory.roms32)
            memory.setUpperROM(pos, getRomFile(this.romPath + romName)); 
        } 
      } 
      if (Switches.ROM.equals("CPC464") || Switches.ROM.equals("CPC664")) {
        memory.setMultiROM(getRom("file/mf86.rom", 8192));
      } else {
        memory.setMultiROM(getRom("file/mf0e.rom", 8192));
      } 
      this.upperROMs.clear();
      this.gateArray.setMemory(memory.getMemory());
      super.initialise();
      this.psg.getSoundPlayer().play();
      String magic = Settings.get("magicdisc_0", "empty");
      if (magic.equals("empty"))
        magic = null; 
      loadMagicCPCDisk(0, magic);
      magic = Settings.get("magicdisc_1", "empty");
      if (magic.equals("empty"))
        magic = null; 
      loadMagicCPCDisk(1, magic);
    } 
  }
  
  public void loadMagic(int drive) {
    if (this.fileDlg == null)
      this.fileDlg = new JFileChooser(); 
    this.fileDlg.setDialogTitle("Select Folder for Magic CPC Disk Image");
    this.fileDlg.setFileSelectionMode(1);
    String path = Settings.get("magicdisc_" + drive, null);
    if (path != null)
      this.fileDlg.setCurrentDirectory(new File(path)); 
    String file = (this.fileDlg.showOpenDialog(new JFrame()) == 0) ? this.fileDlg.getSelectedFile().toString() : null;
    if (file != null) {
      Settings.set("magicdisc_" + drive, file);
      loadMagicCPCDisk(drive, file);
    } 
  }
  
  public void storeMagicAsDSK() {
    for (int i = 0; i < 4; i++) {
      if (this.magicimage[i] != null)
        this.magicimage[i].copyAsDSK(); 
    } 
  }
  
  public void loadMagicCPCDisk(int drive, String path) {
    if (path == null)
      return; 
    this.magics[drive] = path;
    this.floppies[drive].setSides(2);
    this.fdc.setDrive(drive, this.floppies[drive]);
    this.magicimage[drive] = new MagicCPCDiscImage(path);
    this.fdc.getDrive(drive).setDisc(3, this.magicimage[drive]);
    disableSave[drive] = true;
    Desktop.checkdrives = true;
  }
  
  protected void scanActualFiles(int drive) {
    for (int i = 0; i < (this.actualMagicDir[drive]).length; i++) {
      File c = new File(this.magiccheck + "\\" + this.actualMagicDir[drive][i]);
      this.actualMagicSizes[drive][i] = c.length();
    } 
  }
  
  protected void scanLastFiles(int drive) {
    for (int i = 0; i < (this.lastMagicSizes[drive]).length; i++) {
      File c = new File(this.magiccheck + "\\" + this.lastMagicDir[drive][i]);
      this.lastMagicSizes[drive][i] = c.length();
    } 
  }
  
  public void checkMagic(int drive) {
    this.magiccheck = new File(this.magics[drive]);
    if (this.actualMagicDir[drive] == null) {
      this.actualMagicDir[drive] = this.magiccheck.list();
      this.actualMagicSizes[drive] = new long[(this.actualMagicDir[drive]).length];
      scanActualFiles(drive);
      return;
    } 
    boolean reload = false;
    this.lastMagicDir[drive] = this.magiccheck.list();
    this.lastMagicSizes[drive] = new long[(this.lastMagicDir[drive]).length];
    scanLastFiles(drive);
    if ((this.lastMagicDir[drive]).length != (this.actualMagicDir[drive]).length) {
      this.actualMagicDir[drive] = this.magiccheck.list();
      this.actualMagicSizes[drive] = new long[(this.actualMagicDir[drive]).length];
      scanActualFiles(drive);
      reload = true;
    } 
    if (!reload)
      for (int i = 0; i < (this.lastMagicDir[drive]).length; i++) {
        try {
          if (!this.lastMagicDir[drive][i].equals(this.actualMagicDir[drive][i])) {
            this.actualMagicDir[drive] = this.magiccheck.list();
            scanActualFiles(drive);
            reload = true;
            break;
          } 
        } catch (Exception e) {
          e.printStackTrace();
          this.actualMagicDir[drive] = this.magiccheck.list();
          this.lastMagicDir[drive] = this.magiccheck.list();
          this.actualMagicSizes[drive] = new long[(this.actualMagicDir[drive]).length];
          this.lastMagicSizes[drive] = new long[(this.lastMagicDir[drive]).length];
          scanActualFiles(drive);
          scanLastFiles(drive);
          reload = true;
          break;
        } 
      }  
    if (!reload)
      for (int i = 0; i < (this.lastMagicSizes[drive]).length; i++) {
        try {
          if (this.lastMagicSizes[drive][i] != this.actualMagicSizes[drive][i]) {
            this.actualMagicDir[drive] = this.magiccheck.list();
            scanActualFiles(drive);
            reload = true;
            break;
          } 
        } catch (Exception e) {
          e.printStackTrace();
          this.actualMagicDir[drive] = this.magiccheck.list();
          this.lastMagicDir[drive] = this.magiccheck.list();
          this.actualMagicSizes[drive] = new long[(this.actualMagicDir[drive]).length];
          this.lastMagicSizes[drive] = new long[(this.lastMagicDir[drive]).length];
          scanActualFiles(drive);
          scanLastFiles(drive);
          reload = true;
          break;
        } 
      }  
    if (reload) {
      if (protect) {
        System.out.println("Re-read of disk is not possible! Internal disk access!");
        protect = false;
        return;
      } 
      System.out.println("Re-scanning directory in " + this.magics[drive]);
      loadMagicSilent(drive, this.magics[drive]);
    } 
  }
  
  public void loadMagicSilent(int drive, String path) {
    if (path == null)
      return; 
    this.magicimage[drive] = new MagicCPCDiscImage(path);
    this.fdc.getDrive(drive).setDisc(3, this.magicimage[drive]);
    disableSave[drive] = true;
  }
  
  public void unloadMagicCPCDisk(int drive) {
    if (this.magicimage[drive] == null)
      return; 
    Settings.set("magicdisc_" + drive, "empty");
    this.magics[drive] = null;
    this.magicimage[drive] = null;
    this.fdc.setDrive(drive, null);
    disableSave[drive] = false;
    Desktop.checkdrives = true;
  }
  
  static boolean[] disableSave = new boolean[4];
  
  public void refreshRoms(String name) {
    if (Switches.Memory.equals("TYPE_512K")) {
      memory.setRAMType(255);
    } else if (Switches.Memory.equals("TYPE_256K")) {
      memory.setRAMType(15);
    } else if (Switches.Memory.equals("TYPE_128K")) {
      memory.setRAMType(1);
    } else if (Switches.Memory.equals("TYPE_64K")) {
      memory.setRAMType(0);
    } else if (Switches.Memory.equals("TYPE_SILICON_DISC")) {
      memory.setRAMType(240);
    } else if (Switches.Memory.equals("TYPE_128_SILICON_DISC")) {
      memory.setRAMType(241);
    } else {
      memory.setRAMType(255);
    } 
    defineRoms(name);
    memory.plus = false;
    this.os_addr = 10662;
    if (!memory.plus) {
      if (this.lowerROM != null)
        if (this.lowerROM.toLowerCase().startsWith("*")) {
          this.lowerROM = this.lowerROM.substring(1, this.lowerROM.length());
          this.os = getRomFile(this.lowerROM);
          memory.setLowerROM(this.os);
        } else if (Desktop.localize.isSelected()) {
          if (this.lowerROM.toLowerCase().equals("os6128.rom")) {
            if (language.equals("fr")) {
              this.os = getRom("file/6128fr.rom", 16384);
              memory.setLowerROM(this.os);
            } else if (language.equals("es")) {
              this.os = getRom("file/6128es.rom", 16384);
              memory.setLowerROM(this.os);
            } else if (language.equals("dk")) {
              System.out.println("Danish CPC 6128 OS");
              this.os = getRom("file/6128dk.rom", 16384);
              memory.setLowerROM(this.os);
            } else {
              this.os = getRom("file/6128en.rom", 16384);
              memory.setLowerROM(this.os);
            } 
          } else if (this.lowerROM.toLowerCase().equals("os464.rom")) {
            this.os_addr = 10294;
            if (language.equals("fr")) {
              this.os = getRom("file/464fr.rom", 16384);
              memory.setLowerROM(this.os);
            } else if (language.equals("es")) {
              this.os = getRom("file/464es.rom", 16384);
              memory.setLowerROM(this.os);
            } else if (language.equals("dk")) {
              System.out.println("Danish CPC 464 OS");
              this.os = getRom("file/464dk.rom", 16384);
              memory.setLowerROM(this.os);
            } else {
              this.os = getRom("file/464en.rom", 16384);
              memory.setLowerROM(this.os);
            } 
          } else {
            this.os = getRomFile(this.romPath + this.lowerROM);
            memory.setLowerROM(this.os);
          } 
        } else {
          this.os = getRomFile(this.romPath + this.lowerROM);
          memory.setLowerROM(this.os);
        }  
      try {
        this.os_unpatch[0] = this.os[this.os_addr];
        this.os_unpatch[1] = this.os[this.os_addr + 1];
        if (Switches.ROM.equals("CPC464")) {
          this.a464 = this.os[10856];
          this.b464 = this.os[10349];
          this.c464 = this.os[10350];
          this.d464 = this.os[10351];
          this.e464 = this.os[10352];
          this.f464 = this.os[10353];
        } else {
          this.a464 = this.os[10856 + this.diff];
          this.b464 = this.os[10349 + this.diff];
          this.c464 = this.os[10350 + this.diff];
          this.d464 = this.os[10351 + this.diff];
          this.e464 = this.os[10352 + this.diff];
          this.f464 = this.os[10353 + this.diff];
        } 
      } catch (Exception exception) {}
    } 
    this.ramdisk = Settings.get("ramdisk_image", "null");
    if (!this.ramdisk.equals("null")) {
      System.out.println("Opening ramdisk image " + this.ramdisk);
      readRamDisk(this.ramdisk);
    } 
    if (Switches.ROM.equals("CPC464") || Switches.ROM.equals("CPC664")) {
      memory.setMultiROM(getRom("file/mf86.rom", 8192));
    } else {
      memory.setMultiROM(getRom("file/mf0e.rom", 8192));
    } 
    this.gateArray.setMemory(memory.getMemory());
    reset();
  }
  
  public void writeRamDisk(String name) {
    if (!Settings.getBoolean("ramdisk_available", false))
      return; 
    stop();
    byte[] data = new byte[16384 * this.rdiskbanks.length];
    int bank = memory.getRAMBank();
    int pos = 0;
    for (int i = 0; i < this.rdiskbanks.length; i++) {
      this.z80.stop();
      memory.setForcedRAMBank(this.rdiskbanks[i]);
      for (int t = 0; t < 16384; t++)
        data[pos++] = (byte)memory.readWriteByte(16384 + t); 
    } 
    memory.setForcedRAMBank(bank);
    Settings.set("ramdisk_image", name);
    this.ramdisk = name;
    try {
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File(name)));
      bos.write(data);
      bos.close();
    } catch (Exception exception) {}
    start();
    reSync();
  }
  
  public void readRamDisk(String name) {
    if (!Settings.getBoolean("ramdisk_available", false))
      return; 
    stop();
    byte[] data = new byte[16384 * this.rdiskbanks.length];
    try {
      BufferedInputStream bos = new BufferedInputStream(new FileInputStream(new File(name)));
      bos.read(data);
      bos.close();
      int bank = memory.getRAMBank();
      int pos = 0;
      for (int i = 0; i < this.rdiskbanks.length; i++) {
        memory.setForcedRAMBank(this.rdiskbanks[i]);
        for (int t = 0; t < 16384; t++)
          memory.writeByte(16384 + t, data[pos++]); 
      } 
      memory.setForcedRAMBank(bank);
      Settings.set("ramdisk_image", name);
      this.ramdisk = name;
    } catch (Exception exception) {}
    start();
    reSync();
  }
  
  public void removeRamDiskImage() {
    Settings.set("ramdisk_image", "null");
    this.ramdisk = null;
  }
  
  public static boolean replay = false;
  
  public static boolean mfisconnected = Settings.getBoolean("multiface", false);
  
  public int plotlogo;
  
  boolean loadedplus;
  
  int monmode;
  
  public void connectMF(boolean connect) {
    mfisconnected = connect;
    Settings.setBoolean("multiface", connect);
  }
  
  public void rePlay() {
    this.audioAdd = this.psg.getSoundPlayer().getClockAdder(1073741824, 1000000);
    this.psg.getSoundPlayer().play();
    this.psg1.getSoundPlayer1().play();
    this.psg2.getSoundPlayer2().play();
    this.psg.resetRegisters();
    this.psg1.resetRegisters();
    this.psg2.resetRegisters();
  }
  
  public CPRLoader getLoader() {
    return this.CPRloader;
  }
  
  public void saveRamDisk() {
    if (!Settings.getBoolean("ramdisk_available", false))
      return; 
    FileDialog filedia = new FileDialog(new Frame(), "Store ramdisk file", 1);
    filedia.setFile("*.ramdisk");
    filedia.setVisible(true);
    String filename = filedia.getFile();
    if (filedia.getFile() != null) {
      filename = filedia.getDirectory() + filedia.getFile();
      if (!filename.toLowerCase().endsWith(".ramdisk"))
        filename = filename + ".ramdisk"; 
      writeRamDisk(filename);
    } 
  }
  
  public void loadRamDisk() {
    if (!Settings.getBoolean("ramdisk_available", false))
      return; 
    FileDialog filedia = new FileDialog(new Frame(), "Import ramdisk file", 0);
    filedia.setFile("*.ramdisk");
    filedia.setVisible(true);
    String filename = filedia.getFile();
    if (filedia.getFile() != null) {
      filename = filedia.getDirectory() + filedia.getFile();
      readRamDisk(filename);
    } 
  }
  
  public void openCartridge() {
    FileDialog filedia = new FileDialog(new Frame(), "Open CPC+ Cartridge file", 0);
    filedia.setFile("*.cpr");
    filedia.setVisible(true);
    String filename = filedia.getFile();
    if (filedia.getFile() != null) {
      filename = filedia.getDirectory() + filedia.getFile();
      openCartridge(filename);
    } 
  }
  
  public void openCartridge(String filename) {
    Settings.set("cpr_file", filename);
    this.CPRloader.openCPR(filename);
    this.loadedplus = true;
    for (int i = 0; i < 32; i++) {
      byte[] rom = this.CPRloader.getData(i);
      memory.setPlusROM(i, rom);
    } 
    this.upperROMs.clear();
    this.gateArray.setMemory(memory.getMemory());
    reset();
  }
  
  public static boolean inksEdited = false;
  
  int turbop;
  
  int turbob;
  
  int black;
  
  int freq;
  
  int lcount;
  
  int keytime;
  
  int register;
  
  boolean cycle;
  
  int waitlopos;
  
  public int slomo;
  
  int baswaitcycle;
  
  int speed;
  
  boolean floppymotorold;
  
  boolean bufferturbo;
  
  int clock;
  
  int movieDelay;
  
  int baud;
  
  boolean domorse;
  
  boolean readmorse;
  
  int error;
  
  int tapetime;
  
  int tapedelay;
  
  boolean tapeturbo;
  
  int oldPort;
  
  public void reset() {
    if (this.key != null)
      this.key.reset(); 
    int i;
    for (i = 0; i < 4; i++)
      this.sfmouse.writePort(i, 0); 
    this.basicchecktype = 1;
    this.sfclock.reset();
    AY_3_8910.tapeNoise = 0;
    resetRegisters();
    this.keytime = 0;
    this.tapei = this.tapep = 0;
    if (memory.plus && !this.loadedplus) {
      String cprname = Settings.get("cpr_file", "CPC_PLUS.CPR");
      if (cprname.equals("empty")) {
        this.CPRloader.OpenCPR();
      } else {
        openCartridge(cprname);
        return;
      } 
      this.loadedplus = true;
      for (int j = 0; j < 32; j++) {
        byte[] rom = this.CPRloader.getData(j);
        memory.setPlusROM(j, rom);
      } 
      this.upperROMs.clear();
      this.gateArray.setMemory(memory.getMemory());
    } 
    if (!inksEdited)
      GateArray.resetCPCColours(); 
    if (Switches.Expansion)
      this.plotlogo = 1; 
    System.out.println("Reset!");
    memory.reset();
    disableresync = false;
    if (this.crtc.CRTCType == 0) {
      this.crtc.setRegisterStatusMask(768, 0);
    } else {
      this.crtc.setRegisterStatusMask(768, 512);
    } 
    this.ssa1.reset();
    this.doLoad = 0;
    this.portB = 0;
    if (!recordKeys) {
      playKeys = false;
      this.keyNumber = 0;
      recordKeys = false;
    } 
    YMControl.displaycount1 = 0;
    YMControl.displaycount2 = 0;
    YMControl.DisplayStart = 0;
    this.psg.changeClockSpeed(1000000);
    this.psg.resetRegisters();
    this.psg1.resetRegisters();
    this.psg2.resetRegisters();
    st_mode = false;
    zx_mode = false;
    if (YM_Play) {
      YM_Play = false;
      YM_Stop = true;
      System.out.println("Playback stopped...");
    } 
    this.turbo = false;
    Switches.turbo = 1;
    JEMU.turbo.setState(false);
    Desktop.jCheckBox8.setSelected(false);
    try {
      this.keyboarda.keyReleased(this.eventArray[this.readkey]);
    } catch (Exception exception) {}
    Switches.blockKeyboard = false;
    this.autotyper = 0;
    Hold();
    super.reset();
    this.fdc.reset();
    reSync();
    this.z80.reset();
    this.gateArray.init();
    goOn();
    for (i = 0; i < 32; i++)
      GateArray.setPalette(i, Palette.getRGB(i)); 
    Desktop.updatePalette(false);
  }
  
  public void setInks() {
    for (int i = 0; i < 15; i++)
      GateArray.setInk(i, Util.random(30)); 
  }
  
  public void setInk(int pen, int ink) {
    GateArray.setInk(pen, ink);
  }
  
  public void ejectAll() {
    int f = getCurrentDrive();
    for (int i = 0; i < 4; i++) {
      setCurrentDrive(i);
      eject();
    } 
    setCurrentDrive(f);
  }
  
  public void eject() {
    if (this.TapeDrive.isVisible())
      this.TapeDrive.setVisible(false); 
    if (TapeDeck.tapeChanged) {
      Object[] options = { "Yes", "No" };
      int n = JOptionPane.showOptionDialog(new JFrame(), "Your WAV is not saved!\nDo you want to save it now?", "Save your tape?", 0, 2, null, options, options[0]);
      if (n != 1)
        tape_WAV_save(); 
    } 
    int drive = getCurrentDrive();
    if (drive == 0) {
      checkDF0();
      this.dskImageA = null;
      df0mod = false;
      unloadMagicCPCDisk(0);
    } 
    if (drive == 1) {
      checkDF1();
      this.dskImageB = null;
      df1mod = false;
      unloadMagicCPCDisk(1);
    } 
    if (drive == 2) {
      checkDF2();
      this.dskImageC = null;
      df2mod = false;
    } 
    if (drive == 3) {
      checkDF3();
      this.dskImageD = null;
      df3mod = false;
    } 
    if (Switches.FloppySound && Switches.audioenabler == 1)
      Samples.EJECT.play(); 
    this.fdc.setDrive(getCurrentDrive(), null);
    disableSave[drive] = false;
    if (getCurrentDrive() == 0)
      Switches.loaddrivea = "Drive is empty."; 
    if (getCurrentDrive() == 1)
      Switches.loaddriveb = "Drive is empty."; 
    if (getCurrentDrive() == 2)
      Switches.loaddrivec = "Drive is empty."; 
    if (getCurrentDrive() == 3)
      Switches.loaddrived = "Drive is empty."; 
  }
  
  public void dispose() {
    super.dispose();
    this.psg.resetRegisters();
    this.psg1.resetRegisters();
    this.psg2.resetRegisters();
    this.psg.getSoundPlayer().dispose();
    this.psg1.getSoundPlayer1().dispose();
    this.psg2.getSoundPlayer2().dispose();
  }
  
  public void cycle() {
    if (playmovie && initmovie) {
      this.movieDelay++;
      if (this.movieDelay > (int)(19968.0D / movieFPS * 50.8D)) {
        this.movieDelay = 0;
        playMovie();
      } 
    } 
    if (this.launchcount > 0) {
      int k = (int)(Math.random() * 31.0D);
      setInk(16, k);
      if (this.plotlogo == 0)
        this.plotlogo = 1; 
    } 
    if (this.floppymotorold != this.floppymotor) {
      this.floppymotorold = this.floppymotor;
      if (this.floppymotor && isZ80Turbo()) {
        this.bufferturbo = true;
        setZ80Turbo(false);
      } 
      if (!this.floppymotor && this.bufferturbo) {
        this.bufferturbo = false;
        setZ80Turbo(true);
      } 
    } 
    if (this.speed != this.z84c30.getClockSpeed()) {
      this.speed = this.z84c30.getClockSpeed();
      System.out.println("DUAL.YM clock changed to:" + this.speed);
      this.psg1.changeClockSpeed(this.speed * 2);
      this.psg2.changeClockSpeed(this.speed * 2);
    } 
    if (playSNP || StoreSNP) {
      this.register = (this.crtc.getRegisterValue(0) + 1) * (this.crtc.getRegisterValue(4) + 1) * (this.crtc.getRegisterValue(9) + 1);
      this.keytime++;
      this.gateArray.cycle();
      this.fdc.cycle();
      if (this.ssa1.doCycle)
        this.ssa1.cycle(); 
      if (this.dktronics.doCycle)
        this.dktronics.cycle(); 
      if ((this.audioCount += this.audioAdd / Switches.turbo) >= 1073741824) {
        if (this.isPlayCity) {
          this.psg1.writeAudio();
          this.psg2.writeAudio();
        } 
        this.psg.writeAudio();
        this.audioCount -= 1073741824;
      } 
      if (this.keytime >= this.register) {
        this.keytime = 0;
        UpdateSNP(false);
      } 
      return;
    } 
    if (this.bas != null) {
      if (this.bas.auto.isSelected() && !this.bas.track.isSelected()) {
        this.baswaitcycle++;
        if (this.baswaitcycle > 1000) {
          this.baswaitcycle = 0;
          if (this.bas.processNextLine())
            this.bas.cycle(); 
        } 
        this.baswait++;
        if (this.baswait > 2500) {
          this.baswait = 0;
          if (this.bas.processNextLine())
            this.bas.update(); 
        } 
      } 
      if (this.bas.track.isSelected()) {
        this.baswaitcycle++;
        if (this.baswaitcycle > 1000) {
          this.baswaitcycle = 0;
          this.bas.cycle();
        } 
        this.baswait++;
        if (this.baswait > 2500) {
          this.baswait = 0;
          if (this.bas.processNextLine()) {
            this.bas.update();
            if (this.bas.step)
              this.bas.stopstate = true; 
          } 
        } 
      } 
    } 
    if (Switches.Expansion && this.z80.getPC() == 1)
      this.plotlogo = 1; 
    if (this.lopos != 5000) {
      plotLogo(this.lopos);
      this.lopos += 3;
      if (this.lopos >= Logo.logo.length)
        this.lopos = 5000; 
    } 
    if (call && this.z80.getIFF1() == 0 && this.z80.getIFF2() == 0) {
      CALL(65528);
      call = false;
    } 
    if (tapeRelay && Switches.turbo != 1) {
      this.turbob++;
      if (this.turbob > Switches.turbo * 2) {
        this.gateArray.cycle();
        this.turbob = 0;
      } 
    } else if (this.crtc.Scratchdemo && this.gateArray.getScreenMode() == 1) {
      if (this.cycle) {
        this.gateArray.cycle();
        this.gateArray.cycle();
      } 
      this.cycle = !this.cycle;
    } else {
      this.gateArray.cycle();
    } 
    if (this.z80.getPC() < 3) {
      playmovie = false;
      stopTapeMotor();
      this.playMP3 = false;
    } 
    if (this.reloadsnp)
      SNP_Load(this.snpname, this.snpbyte, false); 
    if (this.snap)
      return; 
    if (this.freq != Switches.frequency) {
      if (!this.started) {
        this.started = true;
      } else {
        this.black = 1;
      } 
      this.freq = Switches.frequency;
    } 
    if (this.black != 0) {
      this.black++;
      for (int i = 0; i < 17; i++)
        setInk(i, 20); 
      if (this.black == 50000 || this.black == 70000) {
        softReset();
        softReset();
      } 
      if (this.black == 200000)
        this.black = 0; 
    } 
    if (resetcpc) {
      this.black = 1;
      resetcpc = false;
    } 
    if (Switches.breakinsts && this.z80.getPC() != 0 && PEEK(this.z80.getPC()) == 237 && PEEK(this.z80.getPC() + 1) == 255) {
      int address = this.z80.getPC();
      JEMU.debugthis.setSelected(true);
      Samples.BREAKI.play();
      stop();
      Debugger.setDisass(address);
      Debugger.setEditor(address);
    } 
    if (Switches.overrideP && this.z80.getPC() == 48251 && (PEEK(48250) == 207 || PEEK(48250) == 223))
      if (Switches.ROM.equals("CPC6128") || Switches.ROM.equals("CPC664")) {
        POKE(44588, 0);
      } else {
        POKE(44613, 0);
      }  
    if (shouldquit)
      goOn(); 
    if (tapeRelay && (tapePlay || tapeRec))
      tapeCycle(); 
    if (FDCReset) {
      this.fdc.resetb();
      FDCReset = false;
    } 
    this.fdc.cycle();
    if ((this.audioCount += this.audioAdd / Switches.turbo * this.slomo) >= 1073741824) {
      if (this.isPlayCity) {
        this.psg1.writeAudio();
        this.psg2.writeAudio();
      } 
      this.psg.writeAudio();
      this.audioCount -= 1073741824;
    } 
    if (this.ssa1.doCycle)
      this.ssa1.cycle(); 
    if (this.dktronics.doCycle)
      this.dktronics.cycle(); 
    if (launch != 90000) {
      runBinary(launch);
      launch = 90000;
    } 
  }
  
  public byte[] loadInternal(String name, int start, int length, int exec, int bank) {
    byte[] data = getRom(name, length);
    int g = memory.getRAMBank();
    if (bank != 0)
      memory.setForcedRAMBank(bank); 
    for (int i = 0; i < data.length; i++)
      memory.writeByte(start + i, data[i] & 0xFF); 
    memory.setForcedRAMBank(g);
    if (exec != 0)
      runBinary(exec); 
    return data;
  }
  
  public void runDeathSword() {
    loadInternal("B1.BIN", 16384, 16384, 0, 196);
    loadInternal("B2.BIN", 16384, 16384, 0, 197);
    loadInternal("B3.BIN", 16384, 16384, 0, 198);
    loadInternal("B4.BIN", 16384, 16384, 0, 199);
    loadInternal("BARIAN.BIN", 5956, 36695, 5956, 0);
  }
  
  public void setDisplay(Display value) {
    super.setDisplay(value);
    this.gateArray.setDisplay(value);
  }
  
  public Color[] getPalette() {
    Color[] cols = new Color[17];
    for (int i = 0; i < 17; i++)
      cols[i] = getCol(i); 
    return cols;
  }
  
  public void setFrameSkip(int value) {
    super.setFrameSkip(value);
    this.gateArray.setRendering((value == 0));
  }
  
  public void checkDF0() {
    storeMagicAsDSK();
    if (Switches.checksave && !disableSave[0]) {
      if (df0mod) {
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Your DSK in drive DF0 has been modified.\nDo you want to save it now?", "Please choose", 0);
        if (ok == 0)
          AutoSave(0); 
      } 
      df0mod = false;
    } 
  }
  
  public void checkDF1() {
    storeMagicAsDSK();
    if (Switches.checksave && !disableSave[1]) {
      if (df1mod) {
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Your DSK in drive DF1 has been modified.\nDo you want to save it now?", "Please choose", 0);
        if (ok == 0)
          AutoSave(1); 
      } 
      df1mod = false;
    } 
  }
  
  public void checkDF2() {
    storeMagicAsDSK();
    if (Switches.checksave && !disableSave[2]) {
      if (df2mod) {
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Your DSK in drive DF2 has been modified.\nDo you want to save it now?", "Please choose", 0);
        if (ok == 0)
          AutoSave(2); 
      } 
      df2mod = false;
    } 
  }
  
  public void checkDF3() {
    storeMagicAsDSK();
    if (Switches.checksave && !disableSave[3]) {
      if (df3mod) {
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Your DSK in drive DF3 has been modified.\nDo you want to save it now?", "Please choose", 0);
        if (ok == 0)
          AutoSave(3); 
      } 
      df3mod = false;
    } 
  }
  
  public void checkSave() {
    if (this.TapeDrive.isVisible())
      this.TapeDrive.setVisible(false); 
    if (TapeDeck.tapeChanged) {
      Object[] options = { "Yes", "No" };
      int n = JOptionPane.showOptionDialog(new JFrame(), "Your WAV is not saved!\nDo you want to save it now?", "Save your tape?", 0, 2, null, options, options[0]);
      if (n != 1)
        tape_WAV_save(); 
    } 
    storeMagicAsDSK();
    if (Switches.checksave) {
      if (df0mod && !disableSave[0]) {
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Your DSK in drive DF0 has been modified.\nDo you want to save it now?", "Please choose", 0);
        if (ok == 1)
          df0mod = false; 
      } 
      if (df1mod && !disableSave[1]) {
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Your DSK in drive DF1 has been modified.\nDo you want to save it now?", "Please choose", 0);
        if (ok == 1)
          df1mod = false; 
      } 
      if (df2mod && !disableSave[2]) {
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Your DSK in drive DF2 has been modified.\nDo you want to save it now?", "Please choose", 0);
        if (ok == 1)
          df2mod = false; 
      } 
      if (df3mod && !disableSave[3]) {
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Your DSK in drive DF3 has been modified.\nDo you want to save it now?", "Please choose", 0);
        if (ok == 1)
          df3mod = false; 
      } 
    } else {
      df0mod = df1mod = df2mod = df3mod = false;
    } 
    saveOn = 1;
  }
  
  public void checkSaveOnExit() {
    if (this.TapeDrive.isVisible())
      this.TapeDrive.setVisible(false); 
    if (TapeDeck.tapeChanged) {
      Object[] options = { "Yes", "No" };
      int n = JOptionPane.showOptionDialog(new JFrame(), "Your WAV is not saved!\nDo you want to save it now?", "Save your tape?", 0, 2, null, options, options[0]);
      if (n != 1)
        tape_WAV_save(); 
    } 
    storeMagicAsDSK();
    shouldquit = true;
    if (Switches.checksave) {
      if (df0mod && !disableSave[0]) {
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Your DSK in drive DF0 has been modified.\nDo you want to save it now?", "Please choose", 0);
        if (ok == 1)
          df0mod = false; 
      } 
      if (df1mod && !disableSave[1]) {
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Your DSK in drive DF1 has been modified.\nDo you want to save it now?", "Please choose", 0);
        if (ok == 1)
          df1mod = false; 
      } 
      if (df2mod && !disableSave[2]) {
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Your DSK in drive DF2 has been modified.\nDo you want to save it now?", "Please choose", 0);
        if (ok == 1)
          df2mod = false; 
      } 
      if (df3mod && !disableSave[3]) {
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Your DSK in drive DF3 has been modified.\nDo you want to save it now?", "Please choose", 0);
        if (ok == 1)
          df3mod = false; 
      } 
    } else {
      df0mod = df1mod = df2mod = df3mod = false;
    } 
    saveOnExit = 1;
  }
  
  public void startTapeMotor() {
    trueaudio = true;
    if (!tapeRelay)
      this.z80.out(62976, 16); 
  }
  
  public void stopTapeMotor() {
    if (tapeRelay)
      this.z80.out(62976, 0); 
  }
  
  public void TapeSound(int value) {
    value &= 0xFF;
    if (this.z80.getPC() > 9728 && this.z80.getPC() < 12288 && !savecheck) {
      if ((tapesample == null || tapesample.length < 500) && (this.z80.getIX() == 45412 || this.z80.getIX() == 47180)) {
        this.TapeDrive.pressRec(true);
        tapeBandPosition = recordcount = 250000;
        if (!this.TapeDrive.isVisible()) {
          this.TapeDrive.setVisible(true);
          Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
          this.TapeDrive.setLocation((d.width - (this.TapeDrive.getSize()).width) / 2, (d.height - (this.TapeDrive.getSize()).height) / 2);
          tapedeck = true;
          reSync();
          reSync();
          reSync();
          reSync();
        } 
      } 
      if (tapeRec)
        System.out.println("Tape is saving..."); 
      if (tapePlay && !tapeRec)
        System.out.println("Tape is loading..."); 
      savecheck = true;
    } 
    if ((value & 0x20) == 32) {
      AY_3_8910.tapeNoise = 155;
    } else {
      AY_3_8910.tapeNoise = 0;
    } 
  }
  
  public void TapeRelayCheck(int value) {
    value &= 0x10;
    this.previousPortValue = value;
    if (value == 16 && !tapeRelay) {
      tapeRelay = true;
      if (tapeRec)
        this.TapeDrive.createBlocks(tapesample); 
      savecheck = false;
      if (Switches.FloppySound && !Bypass) {
        Samples.RELAIS.play();
        if (tapePlay)
          Samples.TAPEMOTOR.loop(); 
      } 
    } else if ((value & 0x10) == 0 && tapeRelay) {
      playing = false;
      stoptape = true;
      this.tapestop = 1;
    } else {
      stoptape = false;
      playing = true;
      this.tapestop = 0;
    } 
  }
  
  public String printTapeTime() {
    int totalSecs = tapeBandPosition / this.frequency * (tape_stereo ? 2 : 1);
    int hours = totalSecs / 3600;
    int minutes = totalSecs % 3600 / 60;
    int seconds = totalSecs % 60;
    String hr = "" + hours;
    if (hours < 10)
      hr = "0" + hr; 
    String mn = "" + minutes;
    if (minutes < 10)
      mn = "0" + mn; 
    String sc = "" + seconds;
    if (seconds < 10)
      sc = "0" + sc; 
    String r = hr + ":" + mn + ":" + sc;
    this.TapeDrive.setTitle("TapeDeck " + r);
    return r;
  }
  
  public void tapeCycle() {
    if (tapesample == null) {
      tapeBandPosition = 0;
      return;
    } 
    if (this.tapeturbo != isZ80Turbo()) {
      this.tapeturbo = isZ80Turbo();
      tape_delay = (isZ80Turbo() ? (this.tapedelay >> 1) : this.tapedelay) / this.frequency;
    } 
    if (this.playMP3) {
      this.tapetime = 0;
    } else {
      this.tapetime = 2000000;
    } 
    if (!this.TapeDrive.paused) {
      if (tapeloaded && !tapeRec) {
        playcount++;
        playing = true;
        if (this.doLoad < this.tapetime + 1)
          this.doLoad++; 
        if (this.doLoad >= this.tapetime && playcount > tape_delay) {
          if (Switches.floppyturbo && Switches.turbo == 1)
            Switches.turbo = 2; 
          if (tapeBandPosition >= tapesample.length - 100) {
            restoreScreen();
            tapePlay = false;
            Samples.TAPEMOTOR.stop();
            Samples.TAPESTOP.play();
            this.TapeDrive.pressStop();
            tapeBandPosition -= 2;
            playcount = 0;
            return;
          } 
          if (this.readmorse) {
            this.baud = tapesample[tapeBandPosition];
            this.baud &= 0xFF;
            if (this.baud > 40) {
              this.domorse = true;
              this.error = 3;
            } 
            if (this.error == 0)
              this.domorse = false; 
            if (this.error > 0)
              this.error--; 
            if (tapeRelay) {
              if (this.domorse) {
                keyPressed(101);
              } else {
                keyReleased(101);
              } 
              setInk(16, this.domorse ? 20 : 40);
            } 
          } 
          if (this.compatibility) {
            this.portB = tapesample[tapeBandPosition];
          } else {
            this.portB = tapesample[tapeBandPosition] & 0x80;
          } 
          if ((tapeBandPosition & 0x1) == 1 && bitrate > 8)
            tapeBandPosition++; 
          tapeBandPosition++;
          if (bitrate > 8) {
            this.portB = tapesample[tapeBandPosition];
            tapeBandPosition++;
          } 
          playcount = 0;
          if (trueaudio) {
            if (bitrate > 8) {
              tapesound = this.portB;
            } else {
              tapesound = this.portB ^ 0x80;
            } 
          } else {
            tapesound = (this.portB ^ 0x80) * 1 / 100 ^ 0x80;
          } 
          if (tape_stereo) {
            this.portB = tapesample[tapeBandPosition];
            tapeBandPosition++;
            if (bitrate > 8) {
              this.portB = tapesample[tapeBandPosition];
              tapeBandPosition++;
            } 
            if (bitrate > 8) {
              tapesoundb = this.portB;
            } else {
              tapesoundb = this.portB ^ 0x80;
            } 
          } else {
            tapesoundb = tapesound;
          } 
          if (!trueaudio)
            tapesoundb = tapesound; 
          if (Switches.FloppySound || playmovie)
            if (Switches.turbo == 1) {
              if (trueaudio)
                AY_3_8910.tapeNoise = tapesound * Switches.Blastervolume / 100; 
            } else {
              this.turbocount++;
              if (this.turbocount > Switches.turbo) {
                this.turbocount = 0;
                this.TapeDrive.WAVBYTE = this.portB;
                if (trueaudio)
                  AY_3_8910.tapeNoise = tapesound * Switches.Blastervolume / 100; 
              } 
            }  
          if (!trueaudio) {
            int soundByte = (this.portB > 0) ? 218 : 38;
            this.portB = soundByte;
            AY_3_8910.tapeNoise = (soundByte >> 2) * Switches.Blastervolume / 100;
          } 
          if (Switches.changePolarity)
            this.portB ^= 0xFFFFFFFF; 
          if (changeBorder) {
            this.phase++;
            if (this.phase < 10000)
              tapeBorder(1); 
            if (this.phase > 10000 && this.phase < 20000)
              tapeBorder(2); 
            if (this.phase > 20000 && this.phase < 30000)
              tapeBorder(3); 
            if (this.phase == 30000)
              this.phase = 0; 
          } 
        } 
      } 
      if (tapeRec) {
        playcount++;
        playing = true;
        if (playcount >= tape_delay) {
          if (Switches.floppyturbo && Switches.turbo == 1)
            Switches.turbo = 2; 
          tapesample[tapeBandPosition] = this.TapeRecbyte;
          tapeBandPosition++;
          if (recordcount < tapeBandPosition)
            recordcount = tapeBandPosition; 
          if (tapeBandPosition >= tapesample.length) {
            tapeRec = false;
            Samples.TAPEMOTOR.stop();
            Samples.TAPESTOP.play();
            this.TapeDrive.pressStop();
            tapeBandPosition--;
            playcount = 0;
          } 
          playcount = 0;
        } 
      } 
    } 
  }
  
  public void restoreScreen() {
    if (havescreen && restorescreen) {
      for (int i = 49152; i < 65535; i++)
        POKE(i, screencontent[i - 49152]); 
      restorescreen = false;
      havescreen = false;
    } 
  }
  
  static int[] CodeOv = new int[] { 
      33, 69, 8, 205, 52, 8, 58, 0, 8, 205, 
      28, 189, 33, 1, 8, 175, 78, 65, 245, 229, 
      205, 50, 188, 225, 241, 35, 60, 254, 16, 32, 
      241, 201, 33, 85, 8, 1, 0, 188, 126, 167, 
      200, 237, 121, 4, 35, 126, 237, 121, 35, 5, 
      24, 242, 1, 48, 2, 50, 3, 137, 6, 34, 
      7, 35, 12, 13, 13, 0, 0, 0, 1, 40, 
      2, 46, 3, 142, 6, 25, 7, 30, 12, 48, 
      0, 0 };
  
  static int[] CodeOvP = new int[] { 
      243, 1, 17, 188, 33, 134, 8, 4, 237, 163, 
      13, 32, 250, 33, 151, 8, 205, 117, 8, 1, 
      184, 127, 58, 0, 8, 237, 73, 237, 121, 33, 
      1, 8, 17, 0, 100, 1, 32, 0, 237, 176, 
      175, 1, 14, 244, 237, 73, 1, 192, 246, 237, 
      73, 237, 121, 1, 146, 247, 237, 73, 1, 69, 
      246, 237, 73, 6, 244, 237, 120, 1, 130, 247, 
      237, 73, 23, 56, 221, 1, 160, 127, 237, 73, 
      251, 33, 165, 8, 1, 188, 0, 126, 167, 200, 
      237, 121, 4, 35, 126, 237, 121, 35, 5, 24, 
      242, 255, 0, 255, 119, 179, 81, 168, 212, 98, 
      57, 156, 70, 43, 21, 138, 205, 238, 1, 48, 
      2, 50, 6, 34, 7, 35, 12, 13, 13, 0, 
      0, 0, 1, 40, 2, 46, 6, 25, 7, 30, 
      12, 48 };
  
  public void plotLogo(int pos) {
    try {
      PLOT(Logo.logo[pos], 199 - Logo.logo[pos + 1] / 2, Logo.logo[pos + 2], 1, false);
    } catch (Exception exception) {}
  }
  
  public void SetFOS() {
    this.gateArray.setScreenMode(2);
    GateArray.setInk(0, 0);
    GateArray.setInk(1, 26);
    this.crtc.setRegister(1, 32);
    this.crtc.setRegister(2, 41);
    this.crtc.setRegister(7, 34);
    this.crtc.setRegister(6, 32);
    loadInternal("FOSCATCH.BIN", 36864, 2152, 0, 0);
    this.fromautoboot = true;
    BasicAutoType("CALL &9000");
  }
  
  public void FOSTest() {
    this.crtc.setRegister(1, 32);
    this.crtc.setRegister(2, 41);
    this.crtc.setRegister(7, 34);
    this.crtc.setRegister(6, 32);
    int i;
    for (i = 10; i < 400; i++) {
      PLOTFOS(i, 10, 1, 2);
      PLOTFOS(i, 100, 1, 2);
    } 
    for (i = 10; i < 100; i++) {
      PLOTFOS(10, i, 1, 2);
      PLOTFOS(400, i, 1, 2);
    } 
    int x = 0;
    int y = 0;
    for (int j = 0; j < 256; j++) {
      PLOTFOS(x, y, 1, 2);
      x++;
      y++;
    } 
    double yy = 0.0D;
    y = 0;
    x = 0;
    for (int k = 0; k < 512; k++) {
      PLOTFOS(x, y, 1, 2);
      x++;
      y = (int)yy;
      yy += 0.5D;
    } 
  }
  
  public static void PLOTFOS(int x, int y, int pen, int mode) {
    int charX, byteX, scraddr = 49152;
    int soffset = 0;
    switch (mode) {
      case 0:
        charX = x / 4;
        byteX = (x & 0x3) / 2;
        break;
      case 1:
        charX = x / 8;
        byteX = (x & 0x7) / 4;
        break;
      default:
        charX = x / 16;
        byteX = (x & 0xF) / 8;
        break;
    } 
    int char_offset = y / 8 * 32 + charX;
    scraddr += char_offset * 2 + byteX + (y & 0x7) * 2048;
    scraddr += soffset;
    int data = PEEK(scraddr);
    int pixel = x & 0x3;
    if (mode == 0)
      pixel = x & 0x1; 
    if (mode == 2)
      pixel = x & 0x7; 
    if (mode == 2) {
      data &= 1 << 7 - pixel ^ 0xFFFFFFFF;
      if (pen != 0)
        data |= 1 << 7 - pixel; 
    } 
    if (mode == 1)
      switch (pixel) {
        case 0:
          data &= 0xFFFFFF77;
          switch (pen) {
            case 1:
              data |= 0x80;
              break;
            case 2:
              data |= 0x8;
              break;
            case 3:
              data |= 0x88;
              break;
          } 
          break;
        case 1:
          data &= 0xFFFFFFBB;
          switch (pen) {
            case 1:
              data |= 0x40;
              break;
            case 2:
              data |= 0x4;
              break;
            case 3:
              data |= 0x44;
              break;
          } 
          break;
        case 2:
          data &= 0xFFFFFFDD;
          switch (pen) {
            case 1:
              data |= 0x20;
              break;
            case 2:
              data |= 0x2;
              break;
            case 3:
              data |= 0x22;
              break;
          } 
          break;
        case 3:
          data &= 0xFFFFFFEE;
          switch (pen) {
            case 1:
              data |= 0x10;
              break;
            case 2:
              data |= 0x1;
              break;
            case 3:
              data |= 0x11;
              break;
          } 
          break;
      }  
    if (mode == 0)
      switch (pixel) {
        case 0:
          data &= 0xFFFFFF55;
          data |= pixelsA[pen];
          break;
        case 1:
          data &= 0xFFFFFFAA;
          data |= pixelsB[pen];
          break;
      }  
    POKE(scraddr, data);
  }
  
  public static void PLOT(int x, int y, int pen, int mode, boolean overscan) {
    int scraddr = 0;
    int soffset = 0;
    if (overscan) {
      int charX, byteX;
      overcount = 1;
      switch (mode) {
        case 0:
          charX = x / 4;
          byteX = (x & 0x3) / 2;
          break;
        case 1:
          charX = x / 8;
          byteX = (x & 0x7) / 4;
          break;
        default:
          charX = x / 16;
          byteX = (x & 0xF) / 8;
          break;
      } 
      int char_offset = y / 8 * 48 + charX + 256;
      if (char_offset >= 1024) {
        soffset = 16384;
        char_offset &= 0x3FF;
      } 
      scraddr += char_offset * 2 + byteX + (y & 0x7) * 2048;
      scraddr += soffset;
    } else {
      int scrline = y / 8 * 80 + (y & 0x7) * 2048;
      scrline += 49152;
      int xbyteoffs = x / 4;
      if (mode == 0)
        xbyteoffs = x / 2; 
      if (mode == 2)
        xbyteoffs = x / 8; 
      scraddr = scrline + xbyteoffs;
    } 
    int data = PEEK(scraddr);
    int pixel = x & 0x3;
    if (mode == 0)
      pixel = x & 0x1; 
    if (mode == 2)
      pixel = x & 0x7; 
    if (mode == 2) {
      data &= 1 << 7 - pixel ^ 0xFFFFFFFF;
      if (pen != 0)
        data |= 1 << 7 - pixel; 
    } 
    if (mode == 1)
      switch (pixel) {
        case 0:
          data &= 0xFFFFFF77;
          switch (pen) {
            case 1:
              data |= 0x80;
              break;
            case 2:
              data |= 0x8;
              break;
            case 3:
              data |= 0x88;
              break;
          } 
          break;
        case 1:
          data &= 0xFFFFFFBB;
          switch (pen) {
            case 1:
              data |= 0x40;
              break;
            case 2:
              data |= 0x4;
              break;
            case 3:
              data |= 0x44;
              break;
          } 
          break;
        case 2:
          data &= 0xFFFFFFDD;
          switch (pen) {
            case 1:
              data |= 0x20;
              break;
            case 2:
              data |= 0x2;
              break;
            case 3:
              data |= 0x22;
              break;
          } 
          break;
        case 3:
          data &= 0xFFFFFFEE;
          switch (pen) {
            case 1:
              data |= 0x10;
              break;
            case 2:
              data |= 0x1;
              break;
            case 3:
              data |= 0x11;
              break;
          } 
          break;
      }  
    if (mode == 0)
      switch (pixel) {
        case 0:
          data &= 0xFFFFFF55;
          data |= pixelsA[pen];
          break;
        case 1:
          data &= 0xFFFFFFAA;
          data |= pixelsB[pen];
          break;
      }  
    POKE(scraddr, data);
  }
  
  protected static int[] pixelsA = new int[] { 
      0, 128, 8, 136, 32, 160, 40, 168, 2, 130, 
      10, 138, 34, 162, 42, 170 };
  
  protected static int[] pixelsB = new int[] { 
      0, 64, 4, 68, 16, 80, 20, 84, 1, 65, 
      5, 69, 17, 81, 21, 85 };
  
  int checktape;
  
  boolean updateled;
  
  static int overcount;
  
  protected int loadover;
  
  protected int loadnormal;
  
  protected boolean evenimage;
  
  protected boolean storeflipA;
  
  protected boolean storeflipB;
  
  public static void PLOT(boolean linear, int x, int pen, int mode, int scraddr) {
    int data = PEEK(scraddr);
    int pixel = x & 0x3;
    if (mode == 0)
      pixel = x & 0x1; 
    if (mode == 2)
      pixel = x & 0x7; 
    if (mode == 2) {
      data &= 1 << 7 - pixel ^ 0xFFFFFFFF;
      if (pen != 0)
        data |= 1 << 7 - pixel; 
    } 
    if (!linear) {
      if (mode == 1)
        switch (pixel) {
          case 0:
            data &= 0xFFFFFF77;
            if (pen == 1) {
              data |= 0x80;
              break;
            } 
            if (pen == 2) {
              data |= 0x8;
              break;
            } 
            if (pen == 3)
              data |= 0x88; 
            break;
          case 1:
            data &= 0xFFFFFFBB;
            if (pen == 1) {
              data |= 0x40;
              break;
            } 
            if (pen == 2) {
              data |= 0x4;
              break;
            } 
            if (pen == 3)
              data |= 0x44; 
            break;
          case 2:
            data &= 0xFFFFFFDD;
            if (pen == 1) {
              data |= 0x20;
              break;
            } 
            if (pen == 2) {
              data |= 0x2;
              break;
            } 
            if (pen == 3)
              data |= 0x22; 
            break;
          case 3:
            data &= 0xFFFFFFEE;
            if (pen == 1) {
              data |= 0x10;
              break;
            } 
            if (pen == 2) {
              data |= 0x1;
              break;
            } 
            if (pen == 3)
              data |= 0x11; 
            break;
        }  
      if (mode == 0)
        switch (pixel) {
          case 0:
            data &= 0xFFFFFF55;
            data |= pixelsA[pen];
            break;
          case 1:
            data &= 0xFFFFFFAA;
            data |= pixelsB[pen];
            break;
        }  
    } else {
      if (mode == 1)
        switch (pixel) {
          case 0:
            data &= 0xFFFFFF3F;
            if (pen == 2) {
              data |= 0x80;
              break;
            } 
            if (pen == 1) {
              data |= 0x40;
              break;
            } 
            if (pen == 3)
              data |= 0xC0; 
            break;
          case 1:
            data &= 0xFFFFFFCF;
            if (pen == 2) {
              data |= 0x20;
              break;
            } 
            if (pen == 1) {
              data |= 0x10;
              break;
            } 
            if (pen == 3)
              data |= 0x30; 
            break;
          case 2:
            data &= 0xFFFFFFF3;
            if (pen == 2) {
              data |= 0x8;
              break;
            } 
            if (pen == 1) {
              data |= 0x4;
              break;
            } 
            if (pen == 3)
              data |= 0xC; 
            break;
          case 3:
            data &= 0xFFFFFFFC;
            if (pen == 2) {
              data |= 0x2;
              break;
            } 
            if (pen == 1) {
              data |= 0x1;
              break;
            } 
            if (pen == 3)
              data |= 0x3; 
            break;
        }  
      if (mode == 0)
        switch (pixel) {
          case 0:
            data &= 0xFFFFFF0F;
            data |= pen * 16;
            break;
          case 1:
            data &= 0xFFFFFFF0;
            data |= pen;
            break;
        }  
    } 
    POKE(scraddr, data);
  }
  
  public void restorePaintDSK() {
    try {
      byte[] paintdisk = getRom("file/JavaCPC_Paint.dsk", 194816);
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("JavaCPC_Paint.dsk"));
      bos.write(paintdisk);
      bos.close();
    } catch (IOException iOException) {}
  }
  
  public void tapeBorder(int phase) {
    this;
    int tape_AudioByte = tapesound ^= 0x80;
    if (!trueaudio) {
      int ink = (tape_AudioByte == 0) ? 4 : 31;
      switch (phase) {
        case 2:
          ink = (tape_AudioByte == 0) ? 28 : 14;
          break;
        case 3:
          ink = (tape_AudioByte == 0) ? 22 : 25;
          break;
      } 
      setInk(16, ink);
      return;
    } 
    switch (phase) {
      case 1:
        if (tape_AudioByte > 32 && tape_AudioByte <= 144)
          setInk(16, 4); 
        if (tape_AudioByte > 144 && tape_AudioByte <= 160)
          setInk(16, 21); 
        if (tape_AudioByte > 160 && tape_AudioByte <= 176)
          setInk(16, 31); 
        if (tape_AudioByte > 176)
          setInk(16, 11); 
        if (tape_AudioByte <= 32)
          setInk(16, 20); 
        break;
      case 2:
        if (tape_AudioByte > 32 && tape_AudioByte <= 144)
          setInk(16, 28); 
        if (tape_AudioByte > 144 && tape_AudioByte <= 160)
          setInk(16, 12); 
        if (tape_AudioByte > 160 && tape_AudioByte <= 176)
          setInk(16, 14); 
        if (tape_AudioByte > 176)
          setInk(16, 3); 
        if (tape_AudioByte <= 32)
          setInk(16, 20); 
        break;
      case 3:
        if (tape_AudioByte > 32 && tape_AudioByte <= 144)
          setInk(16, 22); 
        if (tape_AudioByte > 144 && tape_AudioByte <= 160)
          setInk(16, 18); 
        if (tape_AudioByte > 160 && tape_AudioByte <= 176)
          setInk(16, 25); 
        if (tape_AudioByte > 176)
          setInk(16, 27); 
        if (tape_AudioByte <= 32)
          setInk(16, 20); 
        break;
    } 
  }
  
  public void TapeCheck() {
    if (tapeloaded) {
      if (tapeRewind) {
        if (TapeDeck.isMem && (int)TapeDeck.memCount == (int)TapeDeck.counter) {
          System.out.println("Tape REW stopped");
          this.TapeDrive.pressStop();
          tapePlay = false;
          tapeRewind = false;
        } 
        int speed = 200;
        if (tapeBandPosition >= 100000) {
          speed = tapePlay ? 30000 : 60000;
        } else if (tapeBandPosition >= 50000) {
          speed = tapePlay ? 15000 : 30000;
        } else if (tapeBandPosition >= 25000) {
          speed = 7500;
        } else if (tapeBandPosition >= 6000) {
          speed = 3250;
        } 
        tapeBandPosition -= speed;
        if (tapeBandPosition <= 800) {
          tapeBandPosition = 0;
          tapePlay = false;
          tapeRewind = false;
          this.TapeDrive.pressStop();
        } 
      } 
      if (tapeFastForward) {
        if (TapeDeck.isMem && (int)TapeDeck.memCount == (int)TapeDeck.counter) {
          System.out.println("Tape FF stopped");
          this.TapeDrive.pressStop();
          tapePlay = false;
          tapeFastForward = false;
        } 
        int speed = 200;
        if (tapeBandPosition <= tapesample.length - 100000) {
          speed = tapePlay ? 30000 : 60000;
        } else if (tapeBandPosition <= tapesample.length - 50000) {
          speed = tapePlay ? 15000 : 30000;
        } else if (tapeBandPosition <= tapesample.length - 25000) {
          speed = 7500;
        } else if (tapeBandPosition <= tapesample.length - 6000) {
          speed = 3250;
        } 
        tapeBandPosition += speed;
        if (tapeBandPosition > tapesample.length - 300) {
          tapeBandPosition = tapesample.length - 4;
          this.TapeDrive.rebuildBlocks(tapeBandPosition + 1000000);
          tapePlay = false;
          tapeRewind = false;
          this.TapeDrive.pressStop();
        } 
      } 
    } 
  }
  
  public void StopTape() {
    tapeRelay = false;
    playing = false;
    stoptape = false;
    this.doLoad = 0;
    if (Switches.floppyturbo)
      Switches.turbo = 1; 
    if (tapeRec)
      this.TapeDrive.createBlocks(tapesample); 
    trueaudio = false;
    AY_3_8910.tapeNoise = 0;
    this.TapeDrive.showText(this.TapeDrive.filename);
    if (Switches.FloppySound && !Bypass) {
      Samples.RELAISOFF.play();
      Samples.TAPEMOTOR.stop();
    } 
  }
  
  public static void Download(String download) {
    System.out.println("Downloading " + download + "...");
    String ending = download.substring(download.length() - 4, download.length());
    System.out.println("Downloading to buffer" + ending);
    String savename = "buffer" + ending;
    downloadname = download;
    Switches.booter = 1;
    downstring = savename;
    DoDownload = 1;
  }
  
  public void Download() {
    String[] arg = { downloadname, downstring };
    copyURL.download(arg, true);
  }
  
  public static int PEEK(int address) {
    return memory.readWriteByte(address);
  }
  
  public void reSync() {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            CPC.this.psg.getSoundPlayer().resync();
          }
        });
  }
  
  protected void performanceCheck() {
    this.recountFPS++;
    if (this.recountFPS > 500 && this.checkFPS != 44) {
      System.out.println("Good performance. Checkroutine new initialized.");
      this.errCount = 0;
      this.checkFPS = 44;
    } 
    if (this.recountFPS > 500)
      this.recountFPS = 501; 
    this.countFPS++;
    if (this.countFPS > 120)
      this.countFPS = 0; 
    if (Display.mCurrFPS < this.checkFPS && this.countFPS > 100) {
      this.recountFPS = 0;
      this.checkFPS--;
      if (this.checkFPS < 1) {
        System.err.println("Performance is too low. Good bye...");
        System.exit(0);
      } 
      if (!Display.lowperformance) {
        this.errCount++;
        if (this.errCount > 4) {
          Display.lowperformance = true;
          System.out.println("Turning off extra display features." + this.checkFPS);
          this.errCount = 3;
        } 
      } 
      System.out.println("Running out of performance! ReSync! CheckFPS set to:" + this.checkFPS);
      reSync();
      this.countFPS = 0;
    } 
  }
  
  public void putFlipA() {
    normalPaintBox.putFlipA();
  }
  
  public void putFlipB() {
    normalPaintBox.putFlipB();
  }
  
  public void getFlipA() {
    normalPaintBox.getFlipA();
  }
  
  public void getFlipB() {
    normalPaintBox.getFlipB();
  }
  
  public void previewFlip() {
    if (this.evenimage) {
      getFlipB();
    } else {
      getFlipA();
    } 
    this.evenimage = !this.evenimage;
  }
  
  public static boolean showflippreview = false;
  
  public static boolean playmovie = false;
  
  int stopper;
  
  public static boolean useGun = false;
  
  public int checkgun;
  
  public int guncolour;
  
  public int gunX;
  
  public int gunY;
  
  public int releasegun;
  
  public void lightShot(int x, int y) {
    if (this.checkgun != 0 && this.releasegun != 0)
      return; 
    MouseFire1();
    this.guncolour = this.display.lightGun(x, y);
    this.checkgun = 1;
    this.gunX = x;
    this.gunY = y;
  }
  
  public void lightGun() {
    if (this.checkgun != 0) {
      this.checkgun++;
      int checkg = this.display.lightGun(this.gunX, this.gunY);
      if (this.guncolour != checkg && checkg != 0) {
        this.checkgun = 0;
        lightgunShot();
        this.releasegun = 1;
      } 
      if (this.checkgun > 8) {
        this.checkgun = 0;
        MouseReleaseFire1();
      } 
    } 
    if (this.releasegun != 0) {
      this.releasegun++;
      if (this.releasegun == 3) {
        this.releasegun = 0;
        lightgunRelease();
      } 
    } 
  }
  
  public static int speedcontrol = 3;
  
  int bk;
  
  int lopos;
  
  boolean skip;
  
  String[] basictypetext;
  
  int basictypelength;
  
  int basicchecktype;
  
  int basictypepos;
  
  protected int BUFFER_START;
  
  protected int BUFFER_START_464;
  
  boolean rom464;
  
  boolean jumpline;
  
  int tapep;
  
  int tapei;
  
  int os_addr;
  
  byte[] os;
  
  byte[] os_unpatch;
  
  byte[] os_patch;
  
  byte a464;
  
  byte b464;
  
  byte c464;
  
  byte d464;
  
  byte e464;
  
  byte f464;
  
  byte[] TAPData;
  
  public void resetRegisters() {
    this.crtc.setRegister(0, 63);
    this.crtc.setRegister(1, 40);
    this.crtc.setRegister(2, 46);
    this.crtc.setRegister(3, 142);
    this.crtc.setRegister(4, 38);
    this.crtc.setRegister(5, 0);
    this.crtc.setRegister(6, 25);
    this.crtc.setRegister(7, 30);
    this.crtc.setRegister(8, 0);
    this.crtc.setRegister(9, 7);
    this.crtc.setRegister(10, 0);
    this.crtc.setRegister(11, 0);
  }
  
  public void BasicAutoType(String input) {
    BasicAutoType(input, false);
  }
  
  public void BasicAutoType(String input, boolean linejump) {
    while (input.endsWith("\n"))
      input = input.substring(0, input.length() - 1); 
    while (input.endsWith("\r"))
      input = input.substring(0, input.length() - 1); 
    while (input.endsWith("\n"))
      input = input.substring(0, input.length() - 1); 
    while (input.endsWith("\r"))
      input = input.substring(0, input.length() - 1); 
    this.jumpline = linejump;
    input = input.replace("\r", "");
    this.basictypetext = input.split("\n");
    this.basictypelength = this.basictypetext.length - 1;
    this.basictypepos = 0;
    this.rom464 = Switches.ROM.equals("CPC464");
  }
  
  public void BasicAutoType() {
    if (this.basictypetext == null) {
      this.basictypelength = -1;
      this.basicchecktype = 1;
      return;
    } 
    if (this.basictypepos > this.basictypelength) {
      this.basicchecktype = 1;
      this.basictypepos = 0;
      this.basictypelength = -1;
      this.basictypetext = null;
      return;
    } 
    String toput = this.basictypetext[this.basictypepos++];
    String put = "";
    if (toput.length() > 0)
      for (int i = 0; i < toput.length(); i++) {
        if (toput.charAt(i) >= 'ÿ') {
          put = put + (char)(toput.charAt(i) - 255);
        } else {
          put = put + toput.charAt(i);
        } 
      }  
    BasicPutText(put);
  }
  
  protected void setOS() {
    if (Switches.ROM.equals("CPC464")) {
      this.os_addr = 10294;
    } else {
      this.os_addr = 10662;
    } 
  }
  
  public void patchOS() {
    setOS();
    if (Switches.ROM.equals("CPC464")) {
      this.os[10856] = 1;
      this.os[10349] = 16;
      this.os[10350] = -2;
      this.os[10351] = 61;
      this.os[10352] = 32;
      this.os[10353] = -6;
    } else {
      this.os[10856 + this.diff] = 1;
      this.os[10349 + this.diff] = 16;
      this.os[10350 + this.diff] = -2;
      this.os[10351 + this.diff] = 61;
      this.os[10352 + this.diff] = 32;
      this.os[10353 + this.diff] = -6;
    } 
    this.os[this.os_addr] = this.os_patch[0];
    this.os[this.os_addr + 1] = this.os_patch[1];
    memory.setLowerROM(this.os);
  }
  
  public void unpatchOS() {
    setOS();
    if (Switches.ROM.equals("CPC464")) {
      this.os[10856] = this.a464;
      this.os[10349] = this.b464;
      this.os[10350] = this.c464;
      this.os[10351] = this.d464;
      this.os[10352] = this.e464;
      this.os[10353] = this.f464;
    } else {
      this.os[10856 + this.diff] = this.a464;
      this.os[10349 + this.diff] = this.b464;
      this.os[10350 + this.diff] = this.c464;
      this.os[10351 + this.diff] = this.d464;
      this.os[10352 + this.diff] = this.e464;
      this.os[10353 + this.diff] = this.f464;
    } 
    this.os[this.os_addr] = this.os_unpatch[0];
    this.os[this.os_addr + 1] = this.os_unpatch[1];
    memory.setLowerROM(this.os);
  }
  
  public static boolean loadtap = false;
  
  int mouseButton;
  
  boolean[] mbutton;
  
  int prepare;
  
  String typetext;
  
  boolean plusui;
  
  boolean releaseall;
  
  public Basic bas;
  
  int baswait;
  
  Thread basauto;
  
  public boolean fromautoboot;
  
  boolean enterpressed;
  
  int magicscheck;
  
  public int counterInit;
  
  int errorcode;
  
  protected boolean snpCapture;
  
  protected int mouseSensivity;
  
  public void loadTAP(byte[] data) {
    tapesample = null;
    patchOS();
    this.tapei = 0;
    this.tapep = 0;
    this.TAPData = new byte[data.length];
    System.arraycopy(data, 0, this.TAPData, 0, data.length);
    loadtap = true;
    System.out.println(getTAPBlocks());
    this.tapei = 0;
    this.tapep = 0;
  }
  
  public void loadblock() {
    try {
      if (Switches.floppyturbo && Switches.turbo == 1)
        Switches.turbo = 2; 
      int o = this.TAPData[this.tapep++] & 0xFF | this.TAPData[this.tapep++] << 8 & 0xFFFF;
      this.tapei++;
      System.out.println("Accessing TAP block:" + this.tapei);
      this.tapep++;
      for (int j = 0; j < o - 1; j++) {
        int hl = this.z80.getHL();
        int v = this.TAPData[this.tapep++] & 0xFF;
        memory.writeByte(hl, v);
        this.z80.incHL();
      } 
      int iff = 1;
      int f = 69;
      this.z80.setIM(iff);
      this.z80.ret();
      this.z80.setF(f);
      o = this.TAPData[this.tapep] & 0xFF | this.TAPData[this.tapep + 1] << 8 & 0xFFFF;
      if (o == 0)
        this.tapei = this.tapep = 0; 
    } catch (Exception e) {
      this.tapei = this.tapep = 0;
    } 
  }
  
  public void writeMouseMove(int x, int y) {
    this.sfmouse.writePort(0, x);
    this.sfmouse.writePort(1, y);
  }
  
  public void writeMouseButton(int button) {
    switch (button) {
      case 1:
        this.mbutton[0] = true;
        break;
      case 3:
        this.mbutton[1] = true;
        break;
      case 2:
        this.mbutton[2] = true;
        break;
    } 
    this.mouseButton = 0;
    if (this.mbutton[0])
      this.mouseButton++; 
    if (this.mbutton[1])
      this.mouseButton += 2; 
    if (this.mbutton[2])
      this.mouseButton += 4; 
    this.sfmouse.writePort(2, this.mouseButton);
  }
  
  public void releaseMouseButton(int button) {
    switch (button) {
      case 1:
        this.mbutton[0] = false;
        break;
      case 3:
        this.mbutton[1] = false;
        break;
      case 2:
        this.mbutton[2] = false;
        break;
    } 
    this.mouseButton = 0;
    if (this.mbutton[0])
      this.mouseButton++; 
    if (this.mbutton[1])
      this.mouseButton += 2; 
    if (this.mbutton[2])
      this.mouseButton += 4; 
    this.sfmouse.writePort(2, this.mouseButton);
  }
  
  public void writeMouseWheel(int wheel) {
    this.sfmouse.writePort(3, wheel);
  }
  
  public int getTAPBlocks() {
    this.tapei = 0;
    try {
      while (true) {
        int o = this.TAPData[this.tapep++] & 0xFF | this.TAPData[this.tapep++] << 8 & 0xFFFF;
        this.tapei++;
        this.tapep++;
        for (int j = 0; j < o - 1; j++)
          this.tapep++; 
        o = this.TAPData[this.tapep] & 0xFF | this.TAPData[this.tapep + 1] << 8 & 0xFFFF;
        if (o == 0)
          this.tapei = this.tapep = 0; 
      } 
    } catch (Exception e) {
      return this.tapei;
    } 
  }
  
  public void BasicPutText(String input) {
    if (input.length() > 255)
      return; 
    if (input.length() < 1) {
      this.basicchecktype = 1;
      return;
    } 
    int i;
    for (i = 0; i < 255; i++)
      memory.writeByte((this.rom464 ? this.BUFFER_START_464 : this.BUFFER_START) + i, 0); 
    for (i = 0; i < input.length(); i++)
      memory.writeByte((this.rom464 ? this.BUFFER_START_464 : this.BUFFER_START) + i, input.charAt(i)); 
    this.basicchecktype = 1;
  }
  
  public void prepareAutotype(String input) {
    this.prepare = 1;
    this.typetext = input;
  }
  
  public void vSync() {
    // Byte code:
    //   0: aload_0
    //   1: getfield counterInit : I
    //   4: ifgt -> 43
    //   7: getstatic jemu/system/cpc/CPC.tapeRewind : Z
    //   10: ifne -> 43
    //   13: getstatic jemu/system/cpc/CPC.tapeFastForward : Z
    //   16: ifne -> 43
    //   19: getstatic jemu/system/cpc/CPC.tapeRec : Z
    //   22: ifeq -> 31
    //   25: getstatic jemu/system/cpc/CPC.tapeRelay : Z
    //   28: ifne -> 43
    //   31: getstatic jemu/system/cpc/CPC.tapePlay : Z
    //   34: ifeq -> 93
    //   37: getstatic jemu/system/cpc/CPC.tapeRelay : Z
    //   40: ifeq -> 93
    //   43: getstatic jemu/system/cpc/CPC.tapesample : [B
    //   46: ifnull -> 62
    //   49: getstatic jemu/core/device/tape/TapeDeck.TapeCounter : Ljemu/core/device/tape/TapeCounter;
    //   52: aload_0
    //   53: invokevirtual getTapeCounter : ()D
    //   56: invokevirtual setCounter : (D)V
    //   59: goto -> 76
    //   62: getstatic jemu/core/device/tape/TapeDeck.TapeCounter : Ljemu/core/device/tape/TapeCounter;
    //   65: dconst_0
    //   66: invokevirtual setCounter : (D)V
    //   69: getstatic jemu/ui/JEMU.counterb : Ljemu/core/device/tape/TapeCounter;
    //   72: dconst_0
    //   73: invokevirtual setCounter : (D)V
    //   76: aload_0
    //   77: getfield counterInit : I
    //   80: ifle -> 93
    //   83: aload_0
    //   84: dup
    //   85: getfield counterInit : I
    //   88: iconst_1
    //   89: isub
    //   90: putfield counterInit : I
    //   93: aload_0
    //   94: dup
    //   95: getfield magicscheck : I
    //   98: iconst_1
    //   99: iadd
    //   100: putfield magicscheck : I
    //   103: aload_0
    //   104: getfield magicscheck : I
    //   107: bipush #10
    //   109: if_icmplt -> 173
    //   112: aload_0
    //   113: iconst_0
    //   114: putfield magicscheck : I
    //   117: aload_0
    //   118: getfield magics : [Ljava/lang/String;
    //   121: iconst_0
    //   122: aaload
    //   123: ifnull -> 131
    //   126: aload_0
    //   127: iconst_0
    //   128: invokevirtual checkMagic : (I)V
    //   131: aload_0
    //   132: getfield magics : [Ljava/lang/String;
    //   135: iconst_1
    //   136: aaload
    //   137: ifnull -> 145
    //   140: aload_0
    //   141: iconst_1
    //   142: invokevirtual checkMagic : (I)V
    //   145: aload_0
    //   146: getfield magics : [Ljava/lang/String;
    //   149: iconst_2
    //   150: aaload
    //   151: ifnull -> 159
    //   154: aload_0
    //   155: iconst_2
    //   156: invokevirtual checkMagic : (I)V
    //   159: aload_0
    //   160: getfield magics : [Ljava/lang/String;
    //   163: iconst_3
    //   164: aaload
    //   165: ifnull -> 173
    //   168: aload_0
    //   169: iconst_3
    //   170: invokevirtual checkMagic : (I)V
    //   173: aload_0
    //   174: getfield wasWinCPC : Z
    //   177: getstatic jemu/system/cpc/CPC.WinCPC : Z
    //   180: if_icmpeq -> 250
    //   183: aload_0
    //   184: getstatic jemu/system/cpc/CPC.WinCPC : Z
    //   187: putfield wasWinCPC : Z
    //   190: getstatic jemu/core/samples/Samples.SEEK : Ljemu/core/samples/Samples;
    //   193: invokevirtual stop : ()V
    //   196: getstatic jemu/core/samples/Samples.SEEKWINCPC : Ljemu/core/samples/Samples;
    //   199: invokevirtual stop : ()V
    //   202: getstatic jemu/core/samples/Samples.SEEKBACK : Ljemu/core/samples/Samples;
    //   205: invokevirtual stop : ()V
    //   208: getstatic jemu/core/samples/Samples.SEEKBACKWINCPC : Ljemu/core/samples/Samples;
    //   211: invokevirtual stop : ()V
    //   214: getstatic jemu/core/samples/Samples.TRACK : Ljemu/core/samples/Samples;
    //   217: invokevirtual stop : ()V
    //   220: getstatic jemu/core/samples/Samples.TRACKWINCPC : Ljemu/core/samples/Samples;
    //   223: invokevirtual stop : ()V
    //   226: getstatic jemu/core/samples/Samples.TRACKBACK : Ljemu/core/samples/Samples;
    //   229: invokevirtual stop : ()V
    //   232: getstatic jemu/core/samples/Samples.TRACKBACKWINCPC : Ljemu/core/samples/Samples;
    //   235: invokevirtual stop : ()V
    //   238: getstatic jemu/core/samples/Samples.MOTOR : Ljemu/core/samples/Samples;
    //   241: invokevirtual stop : ()V
    //   244: getstatic jemu/core/samples/Samples.MOTORWINCPC : Ljemu/core/samples/Samples;
    //   247: invokevirtual stop : ()V
    //   250: aload_0
    //   251: getfield recordvideo : Z
    //   254: ifeq -> 261
    //   257: aload_0
    //   258: invokevirtual recordFrame : ()V
    //   261: getstatic jemu/system/cpc/CPC.playvideo : Z
    //   264: ifeq -> 271
    //   267: aload_0
    //   268: invokevirtual playFrame : ()V
    //   271: aload_0
    //   272: getfield doimageexport : Z
    //   275: ifeq -> 285
    //   278: aload_0
    //   279: getfield exporter : Ljemu/core/device/internalfilesystem/ImageExporter;
    //   282: invokevirtual record : ()V
    //   285: aload_0
    //   286: getstatic jemu/system/cpc/CPC.memory : Ljemu/system/cpc/CPCMemory;
    //   289: getfield plus : Z
    //   292: putfield plusui : Z
    //   295: getstatic jemu/ui/Desktop.cprfile : Ljavax/swing/JTextField;
    //   298: aload_0
    //   299: getfield plusui : Z
    //   302: invokevirtual setEnabled : (Z)V
    //   305: getstatic jemu/ui/Desktop.cprload : Ljavax/swing/JButton;
    //   308: aload_0
    //   309: getfield plusui : Z
    //   312: invokevirtual setEnabled : (Z)V
    //   315: aload_0
    //   316: getfield releaseall : Z
    //   319: ifeq -> 334
    //   322: aload_0
    //   323: invokevirtual getKeyboard : ()Ljemu/system/cpc/Keyboard;
    //   326: invokevirtual reset : ()V
    //   329: aload_0
    //   330: iconst_0
    //   331: putfield releaseall : Z
    //   334: aload_0
    //   335: getfield basictypelength : I
    //   338: iconst_m1
    //   339: if_icmple -> 706
    //   342: aload_0
    //   343: getfield basictypetext : [Ljava/lang/String;
    //   346: ifnull -> 706
    //   349: aload_0
    //   350: dup
    //   351: getfield basicchecktype : I
    //   354: iconst_1
    //   355: iadd
    //   356: putfield basicchecktype : I
    //   359: aload_0
    //   360: getfield basicchecktype : I
    //   363: iconst_1
    //   364: if_icmpne -> 412
    //   367: aload_0
    //   368: getfield jumpline : Z
    //   371: ifeq -> 400
    //   374: aload_0
    //   375: getfield basictypepos : I
    //   378: aload_0
    //   379: getfield basictypetext : [Ljava/lang/String;
    //   382: arraylength
    //   383: if_icmpgt -> 400
    //   386: aload_0
    //   387: invokevirtual getKeyboard : ()Ljemu/system/cpc/Keyboard;
    //   390: bipush #38
    //   392: invokevirtual keyReleased : (I)V
    //   395: aload_0
    //   396: iconst_0
    //   397: putfield jumpline : Z
    //   400: aload_0
    //   401: invokevirtual BasicAutoType : ()V
    //   404: aload_0
    //   405: iconst_0
    //   406: putfield errorcode : I
    //   409: goto -> 602
    //   412: aload_0
    //   413: getfield basicchecktype : I
    //   416: iconst_2
    //   417: if_icmpne -> 449
    //   420: aload_0
    //   421: getfield fromautoboot : Z
    //   424: ifne -> 449
    //   427: aload_0
    //   428: iconst_0
    //   429: putfield errorcode : I
    //   432: aload_0
    //   433: invokevirtual getKeyboard : ()Ljemu/system/cpc/Keyboard;
    //   436: bipush #10
    //   438: invokevirtual keyPressed : (I)V
    //   441: aload_0
    //   442: iconst_1
    //   443: putfield enterpressed : Z
    //   446: goto -> 602
    //   449: getstatic jemu/system/cpc/CPC.memory : Ljemu/system/cpc/CPCMemory;
    //   452: aload_0
    //   453: getfield rom464 : Z
    //   456: ifeq -> 466
    //   459: aload_0
    //   460: getfield BUFFER_START_464 : I
    //   463: goto -> 470
    //   466: aload_0
    //   467: getfield BUFFER_START : I
    //   470: invokevirtual readByte : (I)I
    //   473: ifne -> 484
    //   476: aload_0
    //   477: getfield basicchecktype : I
    //   480: iconst_3
    //   481: if_icmpgt -> 499
    //   484: aload_0
    //   485: getfield fromautoboot : Z
    //   488: ifeq -> 580
    //   491: aload_0
    //   492: getfield basicchecktype : I
    //   495: iconst_3
    //   496: if_icmpne -> 580
    //   499: aload_0
    //   500: iconst_0
    //   501: putfield errorcode : I
    //   504: aload_0
    //   505: iconst_0
    //   506: putfield basicchecktype : I
    //   509: aload_0
    //   510: iconst_0
    //   511: putfield fromautoboot : Z
    //   514: aload_0
    //   515: getfield enterpressed : Z
    //   518: ifeq -> 530
    //   521: aload_0
    //   522: invokevirtual getKeyboard : ()Ljemu/system/cpc/Keyboard;
    //   525: bipush #10
    //   527: invokevirtual keyReleased : (I)V
    //   530: aload_0
    //   531: iconst_0
    //   532: putfield enterpressed : Z
    //   535: aload_0
    //   536: getfield keyboarda : Ljemu/system/cpc/KeyboardA;
    //   539: invokevirtual reset : ()V
    //   542: aload_0
    //   543: invokevirtual getKeyBoard : ()Ljemu/system/cpc/Keyboard;
    //   546: invokevirtual reset : ()V
    //   549: aload_0
    //   550: getfield jumpline : Z
    //   553: ifeq -> 602
    //   556: aload_0
    //   557: getfield basictypepos : I
    //   560: aload_0
    //   561: getfield basictypetext : [Ljava/lang/String;
    //   564: arraylength
    //   565: if_icmpge -> 602
    //   568: aload_0
    //   569: invokevirtual getKeyboard : ()Ljemu/system/cpc/Keyboard;
    //   572: bipush #38
    //   574: invokevirtual keyPressed : (I)V
    //   577: goto -> 602
    //   580: aload_0
    //   581: getfield basictypepos : I
    //   584: aload_0
    //   585: getfield basictypetext : [Ljava/lang/String;
    //   588: arraylength
    //   589: if_icmplt -> 602
    //   592: aload_0
    //   593: dup
    //   594: getfield errorcode : I
    //   597: iconst_1
    //   598: iadd
    //   599: putfield errorcode : I
    //   602: aload_0
    //   603: getfield errorcode : I
    //   606: bipush #10
    //   608: if_icmple -> 784
    //   611: aload_0
    //   612: iconst_0
    //   613: putfield errorcode : I
    //   616: aload_0
    //   617: getfield enterpressed : Z
    //   620: ifeq -> 784
    //   623: aload_0
    //   624: invokevirtual getKeyBoard : ()Ljemu/system/cpc/Keyboard;
    //   627: bipush #10
    //   629: invokevirtual keyReleased : (I)V
    //   632: aload_0
    //   633: invokevirtual getKeyBoard : ()Ljemu/system/cpc/Keyboard;
    //   636: ldc_w 65406
    //   639: invokevirtual keyReleased : (I)V
    //   642: aload_0
    //   643: invokevirtual getKeyBoard : ()Ljemu/system/cpc/Keyboard;
    //   646: bipush #17
    //   648: invokevirtual keyReleased : (I)V
    //   651: aload_0
    //   652: invokevirtual getKeyBoard : ()Ljemu/system/cpc/Keyboard;
    //   655: bipush #16
    //   657: invokevirtual keyReleased : (I)V
    //   660: aload_0
    //   661: invokevirtual getKeyBoard : ()Ljemu/system/cpc/Keyboard;
    //   664: bipush #35
    //   666: invokevirtual keyReleased : (I)V
    //   669: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   672: ldc_w '*** Last enter key released ***'
    //   675: invokevirtual println : (Ljava/lang/String;)V
    //   678: aload_0
    //   679: iconst_1
    //   680: putfield basicchecktype : I
    //   683: aload_0
    //   684: iconst_0
    //   685: putfield basictypepos : I
    //   688: aload_0
    //   689: iconst_m1
    //   690: putfield basictypelength : I
    //   693: aload_0
    //   694: aconst_null
    //   695: putfield basictypetext : [Ljava/lang/String;
    //   698: aload_0
    //   699: iconst_0
    //   700: putfield enterpressed : Z
    //   703: goto -> 784
    //   706: aload_0
    //   707: getfield enterpressed : Z
    //   710: ifeq -> 784
    //   713: aload_0
    //   714: invokevirtual getKeyBoard : ()Ljemu/system/cpc/Keyboard;
    //   717: bipush #10
    //   719: invokevirtual keyReleased : (I)V
    //   722: aload_0
    //   723: invokevirtual getKeyBoard : ()Ljemu/system/cpc/Keyboard;
    //   726: ldc_w 65406
    //   729: invokevirtual keyReleased : (I)V
    //   732: aload_0
    //   733: invokevirtual getKeyBoard : ()Ljemu/system/cpc/Keyboard;
    //   736: bipush #17
    //   738: invokevirtual keyReleased : (I)V
    //   741: aload_0
    //   742: invokevirtual getKeyBoard : ()Ljemu/system/cpc/Keyboard;
    //   745: bipush #16
    //   747: invokevirtual keyReleased : (I)V
    //   750: aload_0
    //   751: invokevirtual getKeyBoard : ()Ljemu/system/cpc/Keyboard;
    //   754: bipush #35
    //   756: invokevirtual keyReleased : (I)V
    //   759: aload_0
    //   760: iconst_1
    //   761: putfield basicchecktype : I
    //   764: aload_0
    //   765: iconst_0
    //   766: putfield basictypepos : I
    //   769: aload_0
    //   770: iconst_m1
    //   771: putfield basictypelength : I
    //   774: aload_0
    //   775: aconst_null
    //   776: putfield basictypetext : [Ljava/lang/String;
    //   779: aload_0
    //   780: iconst_0
    //   781: putfield enterpressed : Z
    //   784: aload_0
    //   785: getfield plotlogo : I
    //   788: ifeq -> 820
    //   791: aload_0
    //   792: dup
    //   793: getfield plotlogo : I
    //   796: iconst_1
    //   797: iadd
    //   798: putfield plotlogo : I
    //   801: aload_0
    //   802: getfield plotlogo : I
    //   805: bipush #15
    //   807: if_icmple -> 820
    //   810: aload_0
    //   811: iconst_0
    //   812: putfield plotlogo : I
    //   815: aload_0
    //   816: iconst_0
    //   817: putfield lopos : I
    //   820: getstatic jemu/system/cpc/CPC.replay : Z
    //   823: ifeq -> 834
    //   826: iconst_0
    //   827: putstatic jemu/system/cpc/CPC.replay : Z
    //   830: aload_0
    //   831: invokevirtual rePlay : ()V
    //   834: getstatic jemu/ui/Switches.turbo : I
    //   837: iconst_1
    //   838: if_icmpeq -> 879
    //   841: aload_0
    //   842: dup
    //   843: getfield turbop : I
    //   846: iconst_1
    //   847: iadd
    //   848: putfield turbop : I
    //   851: aload_0
    //   852: getfield turbop : I
    //   855: getstatic jemu/ui/Switches.turbo : I
    //   858: iconst_2
    //   859: imul
    //   860: if_icmple -> 965
    //   863: aload_0
    //   864: getfield display : Ljemu/ui/Display;
    //   867: iconst_0
    //   868: invokevirtual updateImage : (Z)V
    //   871: aload_0
    //   872: iconst_0
    //   873: putfield turbop : I
    //   876: goto -> 965
    //   879: aload_0
    //   880: getfield frameSkip : I
    //   883: ifne -> 965
    //   886: aload_0
    //   887: getfield display : Ljemu/ui/Display;
    //   890: pop
    //   891: getstatic jemu/ui/Display.skipframes : Z
    //   894: ifeq -> 953
    //   897: aload_0
    //   898: getfield display : Ljemu/ui/Display;
    //   901: pop
    //   902: getstatic jemu/ui/Display.superPAL : Z
    //   905: ifne -> 919
    //   908: aload_0
    //   909: getfield display : Ljemu/ui/Display;
    //   912: pop
    //   913: getstatic jemu/ui/Display.filter_dosbox : Z
    //   916: ifeq -> 953
    //   919: aload_0
    //   920: aload_0
    //   921: getfield skip : Z
    //   924: ifne -> 931
    //   927: iconst_1
    //   928: goto -> 932
    //   931: iconst_0
    //   932: putfield skip : Z
    //   935: aload_0
    //   936: getfield skip : Z
    //   939: ifne -> 961
    //   942: aload_0
    //   943: getfield display : Ljemu/ui/Display;
    //   946: iconst_1
    //   947: invokevirtual updateImage : (Z)V
    //   950: goto -> 961
    //   953: aload_0
    //   954: getfield display : Ljemu/ui/Display;
    //   957: iconst_1
    //   958: invokevirtual updateImage : (Z)V
    //   961: goto -> 965
    //   964: astore_1
    //   965: aload_0
    //   966: getfield bk : I
    //   969: getstatic jemu/system/cpc/CPC.memory : Ljemu/system/cpc/CPCMemory;
    //   972: invokevirtual getRAMBank : ()I
    //   975: if_icmpeq -> 988
    //   978: aload_0
    //   979: getstatic jemu/system/cpc/CPC.memory : Ljemu/system/cpc/CPCMemory;
    //   982: invokevirtual getRAMBank : ()I
    //   985: putfield bk : I
    //   988: aload_0
    //   989: getfield snacount : I
    //   992: ifeq -> 1037
    //   995: aload_0
    //   996: dup
    //   997: getfield snacount : I
    //   1000: iconst_1
    //   1001: iadd
    //   1002: putfield snacount : I
    //   1005: aload_0
    //   1006: ldc_w 'paint'
    //   1009: aload_0
    //   1010: getfield coden : [B
    //   1013: invokevirtual SNA_Load : (Ljava/lang/String;[B)V
    //   1016: aload_0
    //   1017: getfield snacount : I
    //   1020: bipush #10
    //   1022: if_icmpne -> 1037
    //   1025: aload_0
    //   1026: iconst_0
    //   1027: putfield snacount : I
    //   1030: ldc_w 36863
    //   1033: iconst_0
    //   1034: invokestatic POKE : (II)V
    //   1037: aload_0
    //   1038: getfield snaocount : I
    //   1041: ifeq -> 1087
    //   1044: aload_0
    //   1045: dup
    //   1046: getfield snaocount : I
    //   1049: iconst_1
    //   1050: iadd
    //   1051: putfield snaocount : I
    //   1054: aload_0
    //   1055: ldc_w 'overscanpaint'
    //   1058: aload_0
    //   1059: getfield codeo : [B
    //   1062: invokevirtual SNA_Load : (Ljava/lang/String;[B)V
    //   1065: aload_0
    //   1066: getfield snaocount : I
    //   1069: bipush #10
    //   1071: if_icmpne -> 1087
    //   1074: aload_0
    //   1075: iconst_0
    //   1076: putfield snaocount : I
    //   1079: ldc_w 36863
    //   1082: bipush #20
    //   1084: invokestatic POKE : (II)V
    //   1087: getstatic jemu/system/cpc/CPC.resetregisters : Z
    //   1090: ifeq -> 1101
    //   1093: iconst_0
    //   1094: putstatic jemu/system/cpc/CPC.resetregisters : Z
    //   1097: aload_0
    //   1098: invokevirtual resetRegisters : ()V
    //   1101: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   1104: ifnull -> 1191
    //   1107: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   1110: getfield manipframe : Ljavax/swing/JFrame;
    //   1113: ifnull -> 1191
    //   1116: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   1119: invokevirtual isDisplayable : ()Z
    //   1122: ifeq -> 1147
    //   1125: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   1128: getfield manipframe : Ljavax/swing/JFrame;
    //   1131: invokevirtual isVisible : ()Z
    //   1134: ifne -> 1147
    //   1137: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   1140: getfield manipframe : Ljavax/swing/JFrame;
    //   1143: iconst_1
    //   1144: invokevirtual setVisible : (Z)V
    //   1147: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   1150: invokevirtual isDisplayable : ()Z
    //   1153: ifne -> 1191
    //   1156: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   1159: getfield manipframe : Ljavax/swing/JFrame;
    //   1162: invokevirtual isVisible : ()Z
    //   1165: ifeq -> 1191
    //   1168: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   1171: getfield manipframe : Ljavax/swing/JFrame;
    //   1174: iconst_0
    //   1175: invokevirtual setVisible : (Z)V
    //   1178: iconst_1
    //   1179: putstatic jemu/system/cpc/CPC.reset : Z
    //   1182: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   1185: ldc_w 'Closing EffectMixer'
    //   1188: invokevirtual println : (Ljava/lang/String;)V
    //   1191: getstatic jemu/system/cpc/CPC.normalPaintBox : Ljemu/ui/paint/normalPaint;
    //   1194: ifnull -> 1281
    //   1197: getstatic jemu/system/cpc/CPC.normalPaintBox : Ljemu/ui/paint/normalPaint;
    //   1200: getfield manipframe : Ljavax/swing/JFrame;
    //   1203: ifnull -> 1281
    //   1206: getstatic jemu/system/cpc/CPC.normalPaintBox : Ljemu/ui/paint/normalPaint;
    //   1209: invokevirtual isDisplayable : ()Z
    //   1212: ifeq -> 1237
    //   1215: getstatic jemu/system/cpc/CPC.normalPaintBox : Ljemu/ui/paint/normalPaint;
    //   1218: getfield manipframe : Ljavax/swing/JFrame;
    //   1221: invokevirtual isVisible : ()Z
    //   1224: ifne -> 1237
    //   1227: getstatic jemu/system/cpc/CPC.normalPaintBox : Ljemu/ui/paint/normalPaint;
    //   1230: getfield manipframe : Ljavax/swing/JFrame;
    //   1233: iconst_1
    //   1234: invokevirtual setVisible : (Z)V
    //   1237: getstatic jemu/system/cpc/CPC.normalPaintBox : Ljemu/ui/paint/normalPaint;
    //   1240: invokevirtual isDisplayable : ()Z
    //   1243: ifne -> 1281
    //   1246: getstatic jemu/system/cpc/CPC.normalPaintBox : Ljemu/ui/paint/normalPaint;
    //   1249: getfield manipframe : Ljavax/swing/JFrame;
    //   1252: invokevirtual isVisible : ()Z
    //   1255: ifeq -> 1281
    //   1258: getstatic jemu/system/cpc/CPC.normalPaintBox : Ljemu/ui/paint/normalPaint;
    //   1261: getfield manipframe : Ljavax/swing/JFrame;
    //   1264: iconst_0
    //   1265: invokevirtual setVisible : (Z)V
    //   1268: iconst_1
    //   1269: putstatic jemu/system/cpc/CPC.reset : Z
    //   1272: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   1275: ldc_w 'Closing EffectMixer'
    //   1278: invokevirtual println : (Ljava/lang/String;)V
    //   1281: getstatic jemu/system/cpc/CPC.cat : Z
    //   1284: ifeq -> 1295
    //   1287: aload_0
    //   1288: invokevirtual CAT : ()V
    //   1291: iconst_0
    //   1292: putstatic jemu/system/cpc/CPC.cat : Z
    //   1295: aload_0
    //   1296: getfield doautotype : I
    //   1299: ifeq -> 1353
    //   1302: aload_0
    //   1303: dup
    //   1304: getfield doautotype : I
    //   1307: iconst_1
    //   1308: iadd
    //   1309: putfield doautotype : I
    //   1312: aload_0
    //   1313: getfield doautotype : I
    //   1316: sipush #200
    //   1319: if_icmple -> 1353
    //   1322: aload_0
    //   1323: iconst_0
    //   1324: putfield doautotype : I
    //   1327: aload_0
    //   1328: new java/lang/StringBuilder
    //   1331: dup
    //   1332: invokespecial <init> : ()V
    //   1335: getstatic jemu/system/cpc/CPC.autotypetext : Ljava/lang/String;
    //   1338: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1341: ldc_w '\\n'
    //   1344: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1347: invokevirtual toString : ()Ljava/lang/String;
    //   1350: invokevirtual AutoType : (Ljava/lang/String;)V
    //   1353: aload_0
    //   1354: getfield doargs : I
    //   1357: ifeq -> 1393
    //   1360: aload_0
    //   1361: dup
    //   1362: getfield doargs : I
    //   1365: iconst_1
    //   1366: iadd
    //   1367: putfield doargs : I
    //   1370: aload_0
    //   1371: getfield doargs : I
    //   1374: sipush #160
    //   1377: if_icmple -> 1393
    //   1380: aload_0
    //   1381: iconst_0
    //   1382: putfield doargs : I
    //   1385: aload_0
    //   1386: invokevirtual doArgs : ()V
    //   1389: goto -> 1393
    //   1392: astore_1
    //   1393: getstatic jemu/system/cpc/CPC.playmovie : Z
    //   1396: ifeq -> 1433
    //   1399: getstatic jemu/system/cpc/CPC.initmovie : Z
    //   1402: ifne -> 1433
    //   1405: aload_0
    //   1406: dup
    //   1407: getfield stopper : I
    //   1410: iconst_1
    //   1411: iadd
    //   1412: putfield stopper : I
    //   1415: aload_0
    //   1416: getfield stopper : I
    //   1419: bipush #70
    //   1421: if_icmpne -> 1433
    //   1424: iconst_1
    //   1425: putstatic jemu/system/cpc/CPC.initmovie : Z
    //   1428: aload_0
    //   1429: iconst_0
    //   1430: putfield stopper : I
    //   1433: aload_0
    //   1434: getfield storeflipA : Z
    //   1437: ifeq -> 1449
    //   1440: aload_0
    //   1441: iconst_0
    //   1442: putfield storeflipA : Z
    //   1445: aload_0
    //   1446: invokevirtual putFlipA : ()V
    //   1449: aload_0
    //   1450: getfield storeflipB : Z
    //   1453: ifeq -> 1465
    //   1456: aload_0
    //   1457: iconst_0
    //   1458: putfield storeflipB : Z
    //   1461: aload_0
    //   1462: invokevirtual putFlipB : ()V
    //   1465: getstatic jemu/system/cpc/CPC.getbuff : Z
    //   1468: ifeq -> 1486
    //   1471: iconst_0
    //   1472: putstatic jemu/system/cpc/CPC.getbuff : Z
    //   1475: aload_0
    //   1476: aload_0
    //   1477: sipush #512
    //   1480: invokevirtual getSNA : (I)[B
    //   1483: putfield buffSNA : [B
    //   1486: getstatic jemu/system/cpc/CPC.up0 : Z
    //   1489: ifeq -> 1501
    //   1492: aload_0
    //   1493: iconst_0
    //   1494: invokevirtual updateDrive : (I)V
    //   1497: iconst_0
    //   1498: putstatic jemu/system/cpc/CPC.up0 : Z
    //   1501: getstatic jemu/system/cpc/CPC.up1 : Z
    //   1504: ifeq -> 1516
    //   1507: aload_0
    //   1508: iconst_1
    //   1509: invokevirtual updateDrive : (I)V
    //   1512: iconst_0
    //   1513: putstatic jemu/system/cpc/CPC.up1 : Z
    //   1516: getstatic jemu/system/cpc/CPC.formNo : I
    //   1519: bipush #100
    //   1521: if_icmpeq -> 1573
    //   1524: getstatic jemu/system/cpc/CPC.formNo : I
    //   1527: sipush #200
    //   1530: if_icmpne -> 1558
    //   1533: aload_0
    //   1534: getfield forma : Ljavax/swing/JFrame;
    //   1537: ifnull -> 1548
    //   1540: aload_0
    //   1541: getfield forma : Ljavax/swing/JFrame;
    //   1544: iconst_0
    //   1545: invokevirtual setVisible : (Z)V
    //   1548: iconst_1
    //   1549: putstatic jemu/ui/Desktop.closeFormat : Z
    //   1552: bipush #100
    //   1554: putstatic jemu/system/cpc/CPC.formNo : I
    //   1557: return
    //   1558: aload_0
    //   1559: getstatic jemu/system/cpc/CPC.seldrive : I
    //   1562: getstatic jemu/system/cpc/CPC.formNo : I
    //   1565: invokevirtual formatDisk : (II)V
    //   1568: bipush #100
    //   1570: putstatic jemu/system/cpc/CPC.formNo : I
    //   1573: aload_0
    //   1574: getfield overscan : Z
    //   1577: ifeq -> 1808
    //   1580: getstatic jemu/system/cpc/CPC.overcount : I
    //   1583: ifeq -> 1808
    //   1586: getstatic jemu/system/cpc/CPC.overcount : I
    //   1589: iconst_1
    //   1590: iadd
    //   1591: putstatic jemu/system/cpc/CPC.overcount : I
    //   1594: aload_0
    //   1595: getfield overscan : Z
    //   1598: ifeq -> 1808
    //   1601: getstatic jemu/system/cpc/CPC.overcount : I
    //   1604: bipush #10
    //   1606: if_icmple -> 1808
    //   1609: iconst_0
    //   1610: putstatic jemu/system/cpc/CPC.overcount : I
    //   1613: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   1616: invokevirtual getPlus : ()Z
    //   1619: istore_1
    //   1620: iload_1
    //   1621: ifne -> 1701
    //   1624: iconst_0
    //   1625: istore_2
    //   1626: iload_2
    //   1627: getstatic jemu/system/cpc/CPC.CodeOv : [I
    //   1630: arraylength
    //   1631: if_icmpge -> 1655
    //   1634: getstatic jemu/system/cpc/GateArray.screenmemory : [B
    //   1637: sipush #2065
    //   1640: iload_2
    //   1641: iadd
    //   1642: getstatic jemu/system/cpc/CPC.CodeOv : [I
    //   1645: iload_2
    //   1646: iaload
    //   1647: i2b
    //   1648: bastore
    //   1649: iinc #2, 1
    //   1652: goto -> 1626
    //   1655: iconst_0
    //   1656: istore_2
    //   1657: iload_2
    //   1658: bipush #16
    //   1660: if_icmpge -> 1683
    //   1663: getstatic jemu/system/cpc/GateArray.screenmemory : [B
    //   1666: sipush #2049
    //   1669: iload_2
    //   1670: iadd
    //   1671: iload_2
    //   1672: invokestatic getInk : (I)I
    //   1675: i2b
    //   1676: bastore
    //   1677: iinc #2, 1
    //   1680: goto -> 1657
    //   1683: getstatic jemu/system/cpc/GateArray.screenmemory : [B
    //   1686: sipush #2048
    //   1689: aload_0
    //   1690: getfield gateArray : Ljemu/system/cpc/GateArray;
    //   1693: invokevirtual getScreenMode : ()I
    //   1696: i2b
    //   1697: bastore
    //   1698: goto -> 1808
    //   1701: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   1704: ldc_w 'Defining Pluspalette'
    //   1707: invokevirtual println : (Ljava/lang/String;)V
    //   1710: iconst_0
    //   1711: istore_2
    //   1712: iload_2
    //   1713: getstatic jemu/system/cpc/CPC.CodeOvP : [I
    //   1716: arraylength
    //   1717: if_icmpge -> 1741
    //   1720: getstatic jemu/system/cpc/GateArray.screenmemory : [B
    //   1723: sipush #2081
    //   1726: iload_2
    //   1727: iadd
    //   1728: getstatic jemu/system/cpc/CPC.CodeOvP : [I
    //   1731: iload_2
    //   1732: iaload
    //   1733: i2b
    //   1734: bastore
    //   1735: iinc #2, 1
    //   1738: goto -> 1712
    //   1741: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   1744: invokevirtual getPlusPalette : ()[B
    //   1747: astore_2
    //   1748: aload_2
    //   1749: iconst_0
    //   1750: getstatic jemu/system/cpc/GateArray.screenmemory : [B
    //   1753: sipush #2049
    //   1756: bipush #32
    //   1758: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   1761: aload_0
    //   1762: getfield gateArray : Ljemu/system/cpc/GateArray;
    //   1765: invokevirtual getScreenMode : ()I
    //   1768: istore_3
    //   1769: bipush #-116
    //   1771: istore #4
    //   1773: iload_3
    //   1774: iconst_1
    //   1775: if_icmpne -> 1782
    //   1778: bipush #-115
    //   1780: istore #4
    //   1782: iload_3
    //   1783: iconst_2
    //   1784: if_icmpne -> 1791
    //   1787: bipush #-114
    //   1789: istore #4
    //   1791: getstatic jemu/system/cpc/GateArray.screenmemory : [B
    //   1794: sipush #2048
    //   1797: iload #4
    //   1799: bastore
    //   1800: sipush #2048
    //   1803: iload #4
    //   1805: invokestatic POKE : (II)V
    //   1808: aload_0
    //   1809: getfield snap : Z
    //   1812: ifeq -> 1816
    //   1815: return
    //   1816: aload_0
    //   1817: invokevirtual Check : ()V
    //   1820: aload_0
    //   1821: getfield portB : I
    //   1824: sipush #128
    //   1827: if_icmpge -> 1834
    //   1830: iconst_1
    //   1831: goto -> 1835
    //   1834: iconst_0
    //   1835: istore_1
    //   1836: getstatic jemu/system/cpc/CPC.tapeRelay : Z
    //   1839: ifne -> 1844
    //   1842: iconst_0
    //   1843: istore_1
    //   1844: iload_1
    //   1845: aload_0
    //   1846: getfield updateled : Z
    //   1849: if_icmpeq -> 1857
    //   1852: iconst_4
    //   1853: iload_1
    //   1854: invokestatic setLed : (IZ)V
    //   1857: aload_0
    //   1858: iload_1
    //   1859: putfield updateled : Z
    //   1862: getstatic jemu/system/cpc/CPC.tapeRewind : Z
    //   1865: ifne -> 1886
    //   1868: getstatic jemu/system/cpc/CPC.tapeFastForward : Z
    //   1871: ifne -> 1886
    //   1874: getstatic jemu/system/cpc/CPC.tapePlay : Z
    //   1877: ifeq -> 1896
    //   1880: getstatic jemu/system/cpc/CPC.tapeRelay : Z
    //   1883: ifeq -> 1896
    //   1886: aload_0
    //   1887: getfield TapeDrive : Ljemu/core/device/tape/TapeDeck;
    //   1890: getstatic jemu/system/cpc/CPC.tapeBandPosition : I
    //   1893: invokevirtual rebuildBlocks : (I)V
    //   1896: aload_0
    //   1897: getfield amsspeech : Z
    //   1900: ifne -> 1942
    //   1903: getstatic jemu/core/device/speech/Speech.enabled : Z
    //   1906: ifeq -> 1942
    //   1909: getstatic jemu/core/device/speech/Speech.SSA : Z
    //   1912: ifeq -> 1942
    //   1915: aload_0
    //   1916: getfield z80 : Ljemu/system/cpc/Z80;
    //   1919: aload_0
    //   1920: getfield amstradSpeech : Ljemu/core/device/DeviceMapping;
    //   1923: invokevirtual addOutputDeviceMapping : (Ljemu/core/device/DeviceMapping;)V
    //   1926: aload_0
    //   1927: getfield z80 : Ljemu/system/cpc/Z80;
    //   1930: aload_0
    //   1931: getfield amstradSpeech : Ljemu/core/device/DeviceMapping;
    //   1934: invokevirtual addInputDeviceMapping : (Ljemu/core/device/DeviceMapping;)V
    //   1937: aload_0
    //   1938: iconst_1
    //   1939: putfield amsspeech : Z
    //   1942: aload_0
    //   1943: getfield dkspeech : Z
    //   1946: ifne -> 1988
    //   1949: getstatic jemu/core/device/speech/Speech.enabled : Z
    //   1952: ifeq -> 1988
    //   1955: getstatic jemu/core/device/speech/Speech.SSA : Z
    //   1958: ifne -> 1988
    //   1961: aload_0
    //   1962: getfield z80 : Ljemu/system/cpc/Z80;
    //   1965: aload_0
    //   1966: getfield dktronicsSpeech : Ljemu/core/device/DeviceMapping;
    //   1969: invokevirtual addOutputDeviceMapping : (Ljemu/core/device/DeviceMapping;)V
    //   1972: aload_0
    //   1973: getfield z80 : Ljemu/system/cpc/Z80;
    //   1976: aload_0
    //   1977: getfield dktronicsSpeech : Ljemu/core/device/DeviceMapping;
    //   1980: invokevirtual addInputDeviceMapping : (Ljemu/core/device/DeviceMapping;)V
    //   1983: aload_0
    //   1984: iconst_1
    //   1985: putfield dkspeech : Z
    //   1988: getstatic jemu/system/cpc/CPC.xms : I
    //   1991: ifeq -> 2018
    //   1994: getstatic jemu/system/cpc/CPC.xms : I
    //   1997: iconst_1
    //   1998: iadd
    //   1999: putstatic jemu/system/cpc/CPC.xms : I
    //   2002: getstatic jemu/system/cpc/CPC.xms : I
    //   2005: bipush #120
    //   2007: if_icmpne -> 2018
    //   2010: aload_0
    //   2011: invokevirtual launchXMS : ()V
    //   2014: iconst_0
    //   2015: putstatic jemu/system/cpc/CPC.xms : I
    //   2018: getstatic jemu/system/cpc/CPC.loadalarm : Z
    //   2021: ifeq -> 2032
    //   2024: iconst_0
    //   2025: putstatic jemu/system/cpc/CPC.loadalarm : Z
    //   2028: aload_0
    //   2029: invokevirtual loadAlarm : ()V
    //   2032: getstatic jemu/system/cpc/CPC.setPaintOnTop : Z
    //   2035: ifeq -> 2068
    //   2038: getstatic jemu/system/cpc/CPC.overscanPaintFrame : Ljavax/swing/JFrame;
    //   2041: getstatic jemu/system/cpc/CPC.PaintOnTop : Z
    //   2044: invokevirtual setAlwaysOnTop : (Z)V
    //   2047: goto -> 2051
    //   2050: astore_2
    //   2051: getstatic jemu/system/cpc/CPC.normalPaintFrame : Ljavax/swing/JFrame;
    //   2054: getstatic jemu/system/cpc/CPC.PaintOnTop : Z
    //   2057: invokevirtual setAlwaysOnTop : (Z)V
    //   2060: goto -> 2064
    //   2063: astore_2
    //   2064: iconst_0
    //   2065: putstatic jemu/system/cpc/CPC.setPaintOnTop : Z
    //   2068: aload_0
    //   2069: dup
    //   2070: getfield checktape : I
    //   2073: iconst_1
    //   2074: iadd
    //   2075: putfield checktape : I
    //   2078: aload_0
    //   2079: getfield checktape : I
    //   2082: bipush #10
    //   2084: if_icmpne -> 2109
    //   2087: aload_0
    //   2088: iconst_0
    //   2089: putfield checktape : I
    //   2092: aload_0
    //   2093: getfield TapeDrive : Ljemu/core/device/tape/TapeDeck;
    //   2096: invokevirtual isVisible : ()Z
    //   2099: ifeq -> 2109
    //   2102: aload_0
    //   2103: getfield TapeDrive : Ljemu/core/device/tape/TapeDeck;
    //   2106: invokevirtual checkTape : ()V
    //   2109: aload_0
    //   2110: getfield TapeDrive : Ljemu/core/device/tape/TapeDeck;
    //   2113: invokevirtual isVisible : ()Z
    //   2116: ifeq -> 2126
    //   2119: aload_0
    //   2120: getfield TapeDrive : Ljemu/core/device/tape/TapeDeck;
    //   2123: invokevirtual paintWheels : ()V
    //   2126: getstatic jemu/system/cpc/CPC.updatebox : Z
    //   2129: ifeq -> 2146
    //   2132: iconst_0
    //   2133: putstatic jemu/system/cpc/CPC.updatebox : Z
    //   2136: aload_0
    //   2137: invokevirtual updateBox : ()V
    //   2140: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   2143: invokevirtual loadDsk : ()V
    //   2146: getstatic jemu/system/cpc/CPC.normalupdatebox : Z
    //   2149: ifeq -> 2166
    //   2152: iconst_0
    //   2153: putstatic jemu/system/cpc/CPC.normalupdatebox : Z
    //   2156: aload_0
    //   2157: invokevirtual NormalupdateBox : ()V
    //   2160: getstatic jemu/system/cpc/CPC.normalPaintBox : Ljemu/ui/paint/normalPaint;
    //   2163: invokevirtual loadDsk : ()V
    //   2166: getstatic jemu/system/cpc/CPC.restorePaint : Z
    //   2169: ifeq -> 2180
    //   2172: iconst_0
    //   2173: putstatic jemu/system/cpc/CPC.restorePaint : Z
    //   2176: aload_0
    //   2177: invokevirtual restorePaintDSK : ()V
    //   2180: getstatic jemu/system/cpc/CPC.insertOverscanPaintDisk : Z
    //   2183: ifeq -> 2200
    //   2186: aload_0
    //   2187: iconst_1
    //   2188: putfield loadover : I
    //   2191: iconst_0
    //   2192: putstatic jemu/system/cpc/CPC.insertOverscanPaintDisk : Z
    //   2195: aload_0
    //   2196: iconst_1
    //   2197: putfield overscan : Z
    //   2200: getstatic jemu/system/cpc/CPC.insertNormalPaintDisk : Z
    //   2203: ifeq -> 2220
    //   2206: aload_0
    //   2207: iconst_1
    //   2208: putfield loadnormal : I
    //   2211: aload_0
    //   2212: iconst_0
    //   2213: putfield overscan : Z
    //   2216: iconst_0
    //   2217: putstatic jemu/system/cpc/CPC.insertNormalPaintDisk : Z
    //   2220: getstatic jemu/system/cpc/CPC.importoverscanscr : I
    //   2223: iconst_1
    //   2224: if_icmpne -> 2241
    //   2227: aload_0
    //   2228: iconst_1
    //   2229: putfield loadover : I
    //   2232: aload_0
    //   2233: iconst_1
    //   2234: putfield overscan : Z
    //   2237: iconst_0
    //   2238: putstatic jemu/system/cpc/CPC.importoverscanscr : I
    //   2241: getstatic jemu/system/cpc/CPC.importnormalscr : I
    //   2244: iconst_1
    //   2245: if_icmpne -> 2262
    //   2248: aload_0
    //   2249: iconst_1
    //   2250: putfield loadnormal : I
    //   2253: aload_0
    //   2254: iconst_0
    //   2255: putfield overscan : Z
    //   2258: iconst_0
    //   2259: putstatic jemu/system/cpc/CPC.importnormalscr : I
    //   2262: aload_0
    //   2263: getfield loadover : I
    //   2266: ifeq -> 2297
    //   2269: aload_0
    //   2270: dup
    //   2271: getfield loadover : I
    //   2274: iconst_1
    //   2275: iadd
    //   2276: putfield loadover : I
    //   2279: aload_0
    //   2280: getfield loadover : I
    //   2283: bipush #10
    //   2285: if_icmpne -> 2297
    //   2288: aload_0
    //   2289: iconst_0
    //   2290: putfield loadover : I
    //   2293: aload_0
    //   2294: invokevirtual loadOverscanPaint : ()V
    //   2297: aload_0
    //   2298: getfield loadnormal : I
    //   2301: ifeq -> 2332
    //   2304: aload_0
    //   2305: dup
    //   2306: getfield loadnormal : I
    //   2309: iconst_1
    //   2310: iadd
    //   2311: putfield loadnormal : I
    //   2314: aload_0
    //   2315: getfield loadnormal : I
    //   2318: bipush #10
    //   2320: if_icmpne -> 2332
    //   2323: aload_0
    //   2324: iconst_0
    //   2325: putfield loadnormal : I
    //   2328: aload_0
    //   2329: invokevirtual loadNormalPaint : ()V
    //   2332: getstatic jemu/system/cpc/CPC.writePal : I
    //   2335: ifle -> 2436
    //   2338: getstatic jemu/system/cpc/CPC.writePal : I
    //   2341: iconst_1
    //   2342: iadd
    //   2343: putstatic jemu/system/cpc/CPC.writePal : I
    //   2346: getstatic jemu/system/cpc/CPC.writePal : I
    //   2349: bipush #10
    //   2351: if_icmple -> 2436
    //   2354: iconst_0
    //   2355: putstatic jemu/system/cpc/CPC.writePal : I
    //   2358: ldc_w 38921
    //   2361: istore_2
    //   2362: iload_2
    //   2363: aload_0
    //   2364: getfield gateArray : Ljemu/system/cpc/GateArray;
    //   2367: invokevirtual getScreenMode : ()I
    //   2370: i2b
    //   2371: invokestatic POKE : (II)V
    //   2374: iinc #2, 3
    //   2377: iconst_0
    //   2378: istore_3
    //   2379: iload_3
    //   2380: bipush #17
    //   2382: if_icmpge -> 2428
    //   2385: iconst_0
    //   2386: istore #4
    //   2388: iload #4
    //   2390: bipush #12
    //   2392: if_icmpge -> 2422
    //   2395: iload_3
    //   2396: invokestatic getInk : (I)I
    //   2399: istore #5
    //   2401: iload_2
    //   2402: aload_0
    //   2403: getfield PAL_INK : [I
    //   2406: iload #5
    //   2408: iaload
    //   2409: i2b
    //   2410: invokestatic POKE : (II)V
    //   2413: iinc #2, 1
    //   2416: iinc #4, 1
    //   2419: goto -> 2388
    //   2422: iinc #3, 1
    //   2425: goto -> 2379
    //   2428: ldc_w 36863
    //   2431: bipush #100
    //   2433: invokestatic POKE : (II)V
    //   2436: getstatic jemu/system/cpc/CPC.reset : Z
    //   2439: ifeq -> 2458
    //   2442: iconst_0
    //   2443: putstatic jemu/system/cpc/CPC.reset : Z
    //   2446: aload_0
    //   2447: iconst_0
    //   2448: invokevirtual runBinary : (I)V
    //   2451: aload_0
    //   2452: getfield gateArray : Ljemu/system/cpc/GateArray;
    //   2455: invokevirtual reset : ()V
    //   2458: getstatic jemu/system/cpc/CPC.overscanPaintFrame : Ljavax/swing/JFrame;
    //   2461: ifnull -> 2494
    //   2464: getstatic jemu/system/cpc/CPC.overscanPaintFrame : Ljavax/swing/JFrame;
    //   2467: invokevirtual getTitle : ()Ljava/lang/String;
    //   2470: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   2473: invokevirtual showname : ()Ljava/lang/String;
    //   2476: invokevirtual equals : (Ljava/lang/Object;)Z
    //   2479: ifne -> 2494
    //   2482: getstatic jemu/system/cpc/CPC.overscanPaintFrame : Ljavax/swing/JFrame;
    //   2485: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   2488: invokevirtual showname : ()Ljava/lang/String;
    //   2491: invokevirtual setTitle : (Ljava/lang/String;)V
    //   2494: getstatic jemu/system/cpc/CPC.normalPaintFrame : Ljavax/swing/JFrame;
    //   2497: ifnull -> 2530
    //   2500: getstatic jemu/system/cpc/CPC.normalPaintFrame : Ljavax/swing/JFrame;
    //   2503: invokevirtual getTitle : ()Ljava/lang/String;
    //   2506: getstatic jemu/system/cpc/CPC.normalPaintBox : Ljemu/ui/paint/normalPaint;
    //   2509: invokevirtual showname : ()Ljava/lang/String;
    //   2512: invokevirtual equals : (Ljava/lang/Object;)Z
    //   2515: ifne -> 2530
    //   2518: getstatic jemu/system/cpc/CPC.normalPaintFrame : Ljavax/swing/JFrame;
    //   2521: getstatic jemu/system/cpc/CPC.normalPaintBox : Ljemu/ui/paint/normalPaint;
    //   2524: invokevirtual showname : ()Ljava/lang/String;
    //   2527: invokevirtual setTitle : (Ljava/lang/String;)V
    //   2530: ldc_w 36864
    //   2533: invokestatic PEEK : (I)I
    //   2536: bipush #42
    //   2538: if_icmpne -> 2599
    //   2541: ldc_w 37160
    //   2544: invokestatic PEEK : (I)I
    //   2547: bipush #82
    //   2549: if_icmpne -> 2599
    //   2552: ldc_w 37415
    //   2555: invokestatic PEEK : (I)I
    //   2558: bipush #65
    //   2560: if_icmpne -> 2599
    //   2563: aload_0
    //   2564: getfield overscan : Z
    //   2567: ifeq -> 2599
    //   2570: getstatic jemu/system/cpc/CPC.overscanPaintFrame : Ljavax/swing/JFrame;
    //   2573: ifnonnull -> 2580
    //   2576: aload_0
    //   2577: invokevirtual StartOverscanPaint : ()V
    //   2580: getstatic jemu/system/cpc/CPC.overscanPaintFrame : Ljavax/swing/JFrame;
    //   2583: ifnull -> 2599
    //   2586: getstatic jemu/system/cpc/CPC.overscanPaintFrame : Ljavax/swing/JFrame;
    //   2589: invokevirtual isVisible : ()Z
    //   2592: ifne -> 2599
    //   2595: aload_0
    //   2596: invokevirtual StartOverscanPaint : ()V
    //   2599: ldc_w 36864
    //   2602: invokestatic PEEK : (I)I
    //   2605: bipush #42
    //   2607: if_icmpne -> 2668
    //   2610: ldc_w 37160
    //   2613: invokestatic PEEK : (I)I
    //   2616: bipush #82
    //   2618: if_icmpne -> 2668
    //   2621: ldc_w 37415
    //   2624: invokestatic PEEK : (I)I
    //   2627: bipush #65
    //   2629: if_icmpne -> 2668
    //   2632: aload_0
    //   2633: getfield overscan : Z
    //   2636: ifne -> 2668
    //   2639: getstatic jemu/system/cpc/CPC.normalPaintFrame : Ljavax/swing/JFrame;
    //   2642: ifnonnull -> 2649
    //   2645: aload_0
    //   2646: invokevirtual StartNormalPaint : ()V
    //   2649: getstatic jemu/system/cpc/CPC.normalPaintFrame : Ljavax/swing/JFrame;
    //   2652: ifnull -> 2668
    //   2655: getstatic jemu/system/cpc/CPC.normalPaintFrame : Ljavax/swing/JFrame;
    //   2658: invokevirtual isVisible : ()Z
    //   2661: ifne -> 2668
    //   2664: aload_0
    //   2665: invokevirtual StartNormalPaint : ()V
    //   2668: aload_0
    //   2669: getfield coscreen : I
    //   2672: ifle -> 2706
    //   2675: aload_0
    //   2676: dup
    //   2677: getfield coscreen : I
    //   2680: iconst_1
    //   2681: iadd
    //   2682: putfield coscreen : I
    //   2685: aload_0
    //   2686: getfield coscreen : I
    //   2689: bipush #10
    //   2691: if_icmpne -> 2706
    //   2694: aload_0
    //   2695: ldc_w 53200
    //   2698: invokevirtual runBinary : (I)V
    //   2701: aload_0
    //   2702: iconst_0
    //   2703: putfield coscreen : I
    //   2706: getstatic jemu/system/cpc/CPC.savescreen : Z
    //   2709: ifeq -> 2870
    //   2712: getstatic jemu/system/cpc/CPC.PaintOnTop : Z
    //   2715: ifeq -> 2739
    //   2718: getstatic jemu/system/cpc/CPC.normalPaintFrame : Ljavax/swing/JFrame;
    //   2721: getstatic jemu/system/cpc/CPC.PaintOnTop : Z
    //   2724: ifne -> 2731
    //   2727: iconst_1
    //   2728: goto -> 2732
    //   2731: iconst_0
    //   2732: invokevirtual setAlwaysOnTop : (Z)V
    //   2735: goto -> 2739
    //   2738: astore_2
    //   2739: iconst_0
    //   2740: putstatic jemu/system/cpc/CPC.savescreen : Z
    //   2743: aload_0
    //   2744: getfield AddressA : Ljavax/swing/JTextField;
    //   2747: ldc_w 'SCREEN'
    //   2750: invokevirtual setText : (Ljava/lang/String;)V
    //   2753: aload_0
    //   2754: getfield AddressA : Ljavax/swing/JTextField;
    //   2757: iconst_1
    //   2758: invokevirtual setEnabled : (Z)V
    //   2761: new javax/swing/JCheckBox
    //   2764: dup
    //   2765: ldc_w 'Write PAL-file'
    //   2768: invokespecial <init> : (Ljava/lang/String;)V
    //   2771: astore_2
    //   2772: aload_2
    //   2773: aload_0
    //   2774: getfield OCPListener : Ljava/awt/event/ItemListener;
    //   2777: invokevirtual addItemListener : (Ljava/awt/event/ItemListener;)V
    //   2780: aload_2
    //   2781: iconst_1
    //   2782: invokevirtual setSelected : (Z)V
    //   2785: iconst_3
    //   2786: anewarray java/lang/Object
    //   2789: dup
    //   2790: iconst_0
    //   2791: ldc_w 'Enter Filename'
    //   2794: aastore
    //   2795: dup
    //   2796: iconst_1
    //   2797: aload_0
    //   2798: getfield AddressA : Ljavax/swing/JTextField;
    //   2801: aastore
    //   2802: dup
    //   2803: iconst_2
    //   2804: aload_2
    //   2805: aastore
    //   2806: astore_3
    //   2807: new java/awt/Frame
    //   2810: dup
    //   2811: invokespecial <init> : ()V
    //   2814: aload_3
    //   2815: ldc_w 'Enter Filename:'
    //   2818: iconst_2
    //   2819: iconst_2
    //   2820: aconst_null
    //   2821: aconst_null
    //   2822: aconst_null
    //   2823: invokestatic showOptionDialog : (Ljava/awt/Component;Ljava/lang/Object;Ljava/lang/String;IILjavax/swing/Icon;[Ljava/lang/Object;Ljava/lang/Object;)I
    //   2826: istore #4
    //   2828: getstatic jemu/system/cpc/CPC.normalPaintFrame : Ljavax/swing/JFrame;
    //   2831: getstatic jemu/system/cpc/CPC.PaintOnTop : Z
    //   2834: invokevirtual setAlwaysOnTop : (Z)V
    //   2837: goto -> 2842
    //   2840: astore #5
    //   2842: iload #4
    //   2844: ifeq -> 2848
    //   2847: return
    //   2848: aload_0
    //   2849: getfield AddressA : Ljavax/swing/JTextField;
    //   2852: iconst_0
    //   2853: invokevirtual setEnabled : (Z)V
    //   2856: aload_0
    //   2857: aload_0
    //   2858: getfield AddressA : Ljavax/swing/JTextField;
    //   2861: invokevirtual getText : ()Ljava/lang/String;
    //   2864: invokevirtual toUpperCase : ()Ljava/lang/String;
    //   2867: invokevirtual saveScreen : (Ljava/lang/String;)V
    //   2870: getstatic jemu/system/cpc/CPC.saveoverscanscreen : Z
    //   2873: ifeq -> 3038
    //   2876: getstatic jemu/system/cpc/CPC.PaintOnTop : Z
    //   2879: ifeq -> 2903
    //   2882: getstatic jemu/system/cpc/CPC.overscanPaintFrame : Ljavax/swing/JFrame;
    //   2885: getstatic jemu/system/cpc/CPC.PaintOnTop : Z
    //   2888: ifne -> 2895
    //   2891: iconst_1
    //   2892: goto -> 2896
    //   2895: iconst_0
    //   2896: invokevirtual setAlwaysOnTop : (Z)V
    //   2899: goto -> 2903
    //   2902: astore_2
    //   2903: iconst_0
    //   2904: putstatic jemu/system/cpc/CPC.setPaintOnTop : Z
    //   2907: iconst_0
    //   2908: putstatic jemu/system/cpc/CPC.saveoverscanscreen : Z
    //   2911: aload_0
    //   2912: getfield AddressA : Ljavax/swing/JTextField;
    //   2915: ldc_w 'SCREEN'
    //   2918: invokevirtual setText : (Ljava/lang/String;)V
    //   2921: aload_0
    //   2922: getfield AddressA : Ljavax/swing/JTextField;
    //   2925: iconst_1
    //   2926: invokevirtual setEnabled : (Z)V
    //   2929: new javax/swing/JCheckBox
    //   2932: dup
    //   2933: ldc_w 'Write PAL-file'
    //   2936: invokespecial <init> : (Ljava/lang/String;)V
    //   2939: astore_2
    //   2940: aload_2
    //   2941: aload_0
    //   2942: getfield OCPListener : Ljava/awt/event/ItemListener;
    //   2945: invokevirtual addItemListener : (Ljava/awt/event/ItemListener;)V
    //   2948: aload_2
    //   2949: iconst_1
    //   2950: invokevirtual setSelected : (Z)V
    //   2953: iconst_3
    //   2954: anewarray java/lang/Object
    //   2957: dup
    //   2958: iconst_0
    //   2959: ldc_w 'Enter Filename'
    //   2962: aastore
    //   2963: dup
    //   2964: iconst_1
    //   2965: aload_0
    //   2966: getfield AddressA : Ljavax/swing/JTextField;
    //   2969: aastore
    //   2970: dup
    //   2971: iconst_2
    //   2972: aload_2
    //   2973: aastore
    //   2974: astore_3
    //   2975: new java/awt/Frame
    //   2978: dup
    //   2979: invokespecial <init> : ()V
    //   2982: aload_3
    //   2983: ldc_w 'Enter Filename:'
    //   2986: iconst_2
    //   2987: iconst_2
    //   2988: aconst_null
    //   2989: aconst_null
    //   2990: aconst_null
    //   2991: invokestatic showOptionDialog : (Ljava/awt/Component;Ljava/lang/Object;Ljava/lang/String;IILjavax/swing/Icon;[Ljava/lang/Object;Ljava/lang/Object;)I
    //   2994: istore #4
    //   2996: getstatic jemu/system/cpc/CPC.overscanPaintFrame : Ljavax/swing/JFrame;
    //   2999: getstatic jemu/system/cpc/CPC.PaintOnTop : Z
    //   3002: invokevirtual setAlwaysOnTop : (Z)V
    //   3005: goto -> 3010
    //   3008: astore #5
    //   3010: iload #4
    //   3012: ifeq -> 3016
    //   3015: return
    //   3016: aload_0
    //   3017: getfield AddressA : Ljavax/swing/JTextField;
    //   3020: iconst_0
    //   3021: invokevirtual setEnabled : (Z)V
    //   3024: aload_0
    //   3025: aload_0
    //   3026: getfield AddressA : Ljavax/swing/JTextField;
    //   3029: invokevirtual getText : ()Ljava/lang/String;
    //   3032: invokevirtual toUpperCase : ()Ljava/lang/String;
    //   3035: invokevirtual saveOverscanScreen : (Ljava/lang/String;)V
    //   3038: getstatic jemu/system/cpc/CPC.overscanPaintFrame : Ljavax/swing/JFrame;
    //   3041: ifnonnull -> 3064
    //   3044: getstatic jemu/ui/Switches.turbo : I
    //   3047: iconst_1
    //   3048: if_icmpne -> 3090
    //   3051: getstatic jemu/ui/Switches.watch : Z
    //   3054: ifeq -> 3090
    //   3057: aload_0
    //   3058: invokevirtual performanceCheck : ()V
    //   3061: goto -> 3090
    //   3064: getstatic jemu/ui/Switches.turbo : I
    //   3067: iconst_1
    //   3068: if_icmpne -> 3090
    //   3071: getstatic jemu/ui/Switches.watch : Z
    //   3074: ifeq -> 3090
    //   3077: getstatic jemu/system/cpc/CPC.overscanPaintFrame : Ljavax/swing/JFrame;
    //   3080: invokevirtual isVisible : ()Z
    //   3083: ifne -> 3090
    //   3086: aload_0
    //   3087: invokevirtual performanceCheck : ()V
    //   3090: getstatic jemu/system/cpc/CPC.resync : Z
    //   3093: ifeq -> 3104
    //   3096: aload_0
    //   3097: invokevirtual reSync : ()V
    //   3100: iconst_0
    //   3101: putstatic jemu/system/cpc/CPC.resync : Z
    //   3104: aload_0
    //   3105: getfield inspect : I
    //   3108: ifle -> 3143
    //   3111: aload_0
    //   3112: dup
    //   3113: getfield inspect : I
    //   3116: iconst_1
    //   3117: iadd
    //   3118: putfield inspect : I
    //   3121: aload_0
    //   3122: getfield inspect : I
    //   3125: bipush #20
    //   3127: if_icmpne -> 3143
    //   3130: aload_0
    //   3131: iconst_0
    //   3132: putfield inspect : I
    //   3135: aload_0
    //   3136: aload_0
    //   3137: getfield inspectdrive : I
    //   3140: invokevirtual diskInspector : (I)V
    //   3143: aload_0
    //   3144: getfield boot : I
    //   3147: ifle -> 3183
    //   3150: aload_0
    //   3151: dup
    //   3152: getfield boot : I
    //   3155: iconst_1
    //   3156: iadd
    //   3157: putfield boot : I
    //   3160: aload_0
    //   3161: getfield boot : I
    //   3164: bipush #20
    //   3166: if_icmpne -> 3183
    //   3169: aload_0
    //   3170: iconst_0
    //   3171: putfield boot : I
    //   3174: aload_0
    //   3175: aload_0
    //   3176: getfield inspectdrive : I
    //   3179: iconst_0
    //   3180: invokevirtual bootDisk : (IZ)V
    //   3183: getstatic jemu/system/cpc/CPC.bootthis : Z
    //   3186: ifeq -> 3199
    //   3189: iconst_0
    //   3190: putstatic jemu/system/cpc/CPC.bootthis : Z
    //   3193: aload_0
    //   3194: iconst_0
    //   3195: iconst_0
    //   3196: invokevirtual bootDisk : (IZ)V
    //   3199: getstatic jemu/system/cpc/CPC.inspectA : Z
    //   3202: ifeq -> 3214
    //   3205: iconst_0
    //   3206: putstatic jemu/system/cpc/CPC.inspectA : Z
    //   3209: aload_0
    //   3210: iconst_0
    //   3211: invokevirtual diskInspector : (I)V
    //   3214: getstatic jemu/system/cpc/CPC.inspectB : Z
    //   3217: ifeq -> 3229
    //   3220: iconst_0
    //   3221: putstatic jemu/system/cpc/CPC.inspectB : Z
    //   3224: aload_0
    //   3225: iconst_1
    //   3226: invokevirtual diskInspector : (I)V
    //   3229: getstatic jemu/system/cpc/CPC.resetInk : I
    //   3232: ifle -> 3247
    //   3235: iconst_0
    //   3236: putstatic jemu/system/cpc/CPC.resetInk : I
    //   3239: aload_0
    //   3240: getfield gateArray : Ljemu/system/cpc/GateArray;
    //   3243: pop
    //   3244: invokestatic resetInks : ()V
    //   3247: aload_0
    //   3248: getfield mp3count : I
    //   3251: ifle -> 3277
    //   3254: aload_0
    //   3255: dup
    //   3256: getfield mp3count : I
    //   3259: iconst_1
    //   3260: iadd
    //   3261: putfield mp3count : I
    //   3264: aload_0
    //   3265: getfield mp3count : I
    //   3268: bipush #10
    //   3270: if_icmpne -> 3277
    //   3273: aload_0
    //   3274: invokevirtual MP3Load : ()V
    //   3277: getstatic jemu/system/cpc/CPC.doOptimize : Z
    //   3280: ifeq -> 3291
    //   3283: aload_0
    //   3284: invokevirtual optimizeWAV : ()V
    //   3287: iconst_0
    //   3288: putstatic jemu/system/cpc/CPC.doOptimize : Z
    //   3291: getstatic jemu/system/cpc/CPC.DoDownload : I
    //   3294: iconst_1
    //   3295: if_icmplt -> 3322
    //   3298: getstatic jemu/system/cpc/CPC.DoDownload : I
    //   3301: iconst_1
    //   3302: iadd
    //   3303: putstatic jemu/system/cpc/CPC.DoDownload : I
    //   3306: getstatic jemu/system/cpc/CPC.DoDownload : I
    //   3309: bipush #100
    //   3311: if_icmplt -> 3322
    //   3314: iconst_0
    //   3315: putstatic jemu/system/cpc/CPC.DoDownload : I
    //   3318: aload_0
    //   3319: invokevirtual Download : ()V
    //   3322: getstatic jemu/system/cpc/CPC.savetape : Z
    //   3325: ifeq -> 3336
    //   3328: iconst_0
    //   3329: putstatic jemu/system/cpc/CPC.savetape : Z
    //   3332: aload_0
    //   3333: invokevirtual tape_WAV_save : ()V
    //   3336: getstatic jemu/system/cpc/CPC.tapeload : Z
    //   3339: ifeq -> 3350
    //   3342: iconst_0
    //   3343: putstatic jemu/system/cpc/CPC.tapeload : Z
    //   3346: aload_0
    //   3347: invokevirtual tape_load : ()V
    //   3350: getstatic jemu/system/cpc/CPC.inserttape : Z
    //   3353: ifeq -> 3377
    //   3356: iconst_0
    //   3357: putstatic jemu/system/cpc/CPC.inserttape : Z
    //   3360: aload_0
    //   3361: iconst_0
    //   3362: getstatic jemu/system/cpc/CPC.loadtape : Ljava/lang/String;
    //   3365: invokevirtual loadFile : (ILjava/lang/String;)V
    //   3368: goto -> 3373
    //   3371: astore_2
    //   3372: return
    //   3373: iconst_1
    //   3374: putstatic jemu/system/cpc/CPC.tapestarttimer : I
    //   3377: getstatic jemu/system/cpc/CPC.tapestarttimer : I
    //   3380: iconst_1
    //   3381: if_icmplt -> 3475
    //   3384: iconst_1
    //   3385: putstatic jemu/ui/Switches.blockKeyboard : Z
    //   3388: aload_0
    //   3389: getfield TapeDrive : Ljemu/core/device/tape/TapeDeck;
    //   3392: iconst_1
    //   3393: putfield buttonpressed : Z
    //   3396: getstatic jemu/system/cpc/CPC.tapestarttimer : I
    //   3399: iconst_1
    //   3400: iadd
    //   3401: putstatic jemu/system/cpc/CPC.tapestarttimer : I
    //   3404: getstatic jemu/system/cpc/CPC.tapestarttimer : I
    //   3407: bipush #56
    //   3409: if_icmplt -> 3475
    //   3412: iconst_0
    //   3413: putstatic jemu/system/cpc/CPC.tapestarttimer : I
    //   3416: iconst_1
    //   3417: putstatic jemu/system/cpc/CPC.tapePlay : Z
    //   3420: aload_0
    //   3421: getfield TapeDrive : Ljemu/core/device/tape/TapeDeck;
    //   3424: invokevirtual pressPlay : ()V
    //   3427: aload_0
    //   3428: getfield CPCname : Ljava/lang/String;
    //   3431: ldc_w 'CPC464T'
    //   3434: invokevirtual equals : (Ljava/lang/Object;)Z
    //   3437: ifne -> 3458
    //   3440: getstatic jemu/system/cpc/CPC.amsdos : Ljava/lang/String;
    //   3443: ifnull -> 3468
    //   3446: getstatic jemu/system/cpc/CPC.amsdos : Ljava/lang/String;
    //   3449: ldc_w 'no'
    //   3452: invokevirtual equals : (Ljava/lang/Object;)Z
    //   3455: ifeq -> 3468
    //   3458: aload_0
    //   3459: ldc_w 'RUN"\\n\\n\\n'
    //   3462: invokevirtual AutoType : (Ljava/lang/String;)V
    //   3465: goto -> 3475
    //   3468: aload_0
    //   3469: ldc_w '|TAPE\\nRUN"\\n\\n\\n'
    //   3472: invokevirtual AutoType : (Ljava/lang/String;)V
    //   3475: aload_0
    //   3476: getfield tapeEnabled : Z
    //   3479: ifeq -> 3568
    //   3482: getstatic jemu/system/cpc/CPC.tapePlay : Z
    //   3485: ifeq -> 3500
    //   3488: getstatic jemu/system/cpc/CPC.playing : Z
    //   3491: ifeq -> 3500
    //   3494: getstatic jemu/system/cpc/CPC.tapeRelay : Z
    //   3497: ifne -> 3512
    //   3500: getstatic jemu/system/cpc/CPC.tapeRewind : Z
    //   3503: ifne -> 3512
    //   3506: getstatic jemu/system/cpc/CPC.tapeFastForward : Z
    //   3509: ifeq -> 3516
    //   3512: aload_0
    //   3513: invokevirtual TapeCheck : ()V
    //   3516: getstatic jemu/system/cpc/CPC.tapeRelay : Z
    //   3519: ifne -> 3527
    //   3522: aload_0
    //   3523: iconst_0
    //   3524: putfield portB : I
    //   3527: getstatic jemu/system/cpc/CPC.stoptape : Z
    //   3530: ifeq -> 3568
    //   3533: aload_0
    //   3534: getfield tapestop : I
    //   3537: iconst_1
    //   3538: if_icmplt -> 3568
    //   3541: aload_0
    //   3542: dup
    //   3543: getfield tapestop : I
    //   3546: iconst_1
    //   3547: iadd
    //   3548: putfield tapestop : I
    //   3551: aload_0
    //   3552: getfield tapestop : I
    //   3555: iconst_2
    //   3556: if_icmpne -> 3568
    //   3559: aload_0
    //   3560: invokevirtual StopTape : ()V
    //   3563: aload_0
    //   3564: iconst_0
    //   3565: putfield tapestop : I
    //   3568: getstatic jemu/system/cpc/CPC.saveOnExit : I
    //   3571: iconst_1
    //   3572: if_icmplt -> 3583
    //   3575: getstatic jemu/system/cpc/CPC.saveOnExit : I
    //   3578: iconst_1
    //   3579: iadd
    //   3580: putstatic jemu/system/cpc/CPC.saveOnExit : I
    //   3583: getstatic jemu/system/cpc/CPC.saveOnExit : I
    //   3586: iconst_2
    //   3587: if_icmpne -> 3634
    //   3590: getstatic jemu/system/cpc/CPC.df0mod : Z
    //   3593: ifeq -> 3601
    //   3596: aload_0
    //   3597: iconst_0
    //   3598: invokevirtual AutoSave : (I)V
    //   3601: getstatic jemu/system/cpc/CPC.df1mod : Z
    //   3604: ifeq -> 3612
    //   3607: aload_0
    //   3608: iconst_1
    //   3609: invokevirtual AutoSave : (I)V
    //   3612: getstatic jemu/system/cpc/CPC.df2mod : Z
    //   3615: ifeq -> 3623
    //   3618: aload_0
    //   3619: iconst_2
    //   3620: invokevirtual AutoSave : (I)V
    //   3623: getstatic jemu/system/cpc/CPC.df3mod : Z
    //   3626: ifeq -> 3634
    //   3629: aload_0
    //   3630: iconst_3
    //   3631: invokevirtual AutoSave : (I)V
    //   3634: getstatic jemu/system/cpc/CPC.saveOnExit : I
    //   3637: bipush #10
    //   3639: if_icmpne -> 3680
    //   3642: getstatic jemu/system/cpc/CPC.tapeRelay : Z
    //   3645: ifeq -> 3676
    //   3648: getstatic jemu/ui/Switches.FloppySound : Z
    //   3651: ifeq -> 3672
    //   3654: getstatic jemu/system/cpc/CPC.Bypass : Z
    //   3657: ifne -> 3672
    //   3660: getstatic jemu/core/samples/Samples.RELAISOFF : Ljemu/core/samples/Samples;
    //   3663: invokevirtual play : ()V
    //   3666: getstatic jemu/core/samples/Samples.TAPEMOTOR : Ljemu/core/samples/Samples;
    //   3669: invokevirtual stop : ()V
    //   3672: iconst_0
    //   3673: putstatic jemu/system/cpc/CPC.tapeRelay : Z
    //   3676: iconst_0
    //   3677: invokestatic exit : (I)V
    //   3680: getstatic jemu/system/cpc/CPC.saveOn : I
    //   3683: iconst_1
    //   3684: if_icmpne -> 3751
    //   3687: getstatic jemu/system/cpc/CPC.df0mod : Z
    //   3690: ifeq -> 3698
    //   3693: aload_0
    //   3694: iconst_0
    //   3695: invokevirtual AutoSave : (I)V
    //   3698: getstatic jemu/system/cpc/CPC.df1mod : Z
    //   3701: ifeq -> 3709
    //   3704: aload_0
    //   3705: iconst_1
    //   3706: invokevirtual AutoSave : (I)V
    //   3709: getstatic jemu/system/cpc/CPC.df2mod : Z
    //   3712: ifeq -> 3720
    //   3715: aload_0
    //   3716: iconst_2
    //   3717: invokevirtual AutoSave : (I)V
    //   3720: getstatic jemu/system/cpc/CPC.df3mod : Z
    //   3723: ifeq -> 3731
    //   3726: aload_0
    //   3727: iconst_3
    //   3728: invokevirtual AutoSave : (I)V
    //   3731: iconst_0
    //   3732: putstatic jemu/system/cpc/CPC.saveOn : I
    //   3735: iconst_0
    //   3736: dup
    //   3737: putstatic jemu/system/cpc/CPC.df3mod : Z
    //   3740: dup
    //   3741: putstatic jemu/system/cpc/CPC.df2mod : Z
    //   3744: dup
    //   3745: putstatic jemu/system/cpc/CPC.df1mod : Z
    //   3748: putstatic jemu/system/cpc/CPC.df0mod : Z
    //   3751: getstatic jemu/system/cpc/CPC.savetimer : I
    //   3754: iconst_1
    //   3755: if_icmplt -> 3838
    //   3758: getstatic jemu/system/cpc/CPC.savetimer : I
    //   3761: iconst_1
    //   3762: iadd
    //   3763: putstatic jemu/system/cpc/CPC.savetimer : I
    //   3766: getstatic jemu/system/cpc/CPC.savetimer : I
    //   3769: bipush #100
    //   3771: if_icmpne -> 3838
    //   3774: iconst_0
    //   3775: putstatic jemu/system/cpc/CPC.savetimer : I
    //   3778: getstatic jemu/system/cpc/CPC.df0mod : Z
    //   3781: ifeq -> 3789
    //   3784: aload_0
    //   3785: iconst_0
    //   3786: invokevirtual AutoSave : (I)V
    //   3789: getstatic jemu/system/cpc/CPC.df1mod : Z
    //   3792: ifeq -> 3800
    //   3795: aload_0
    //   3796: iconst_1
    //   3797: invokevirtual AutoSave : (I)V
    //   3800: getstatic jemu/system/cpc/CPC.df2mod : Z
    //   3803: ifeq -> 3811
    //   3806: aload_0
    //   3807: iconst_2
    //   3808: invokevirtual AutoSave : (I)V
    //   3811: getstatic jemu/system/cpc/CPC.df3mod : Z
    //   3814: ifeq -> 3822
    //   3817: aload_0
    //   3818: iconst_3
    //   3819: invokevirtual AutoSave : (I)V
    //   3822: iconst_0
    //   3823: dup
    //   3824: putstatic jemu/system/cpc/CPC.df3mod : Z
    //   3827: dup
    //   3828: putstatic jemu/system/cpc/CPC.df2mod : Z
    //   3831: dup
    //   3832: putstatic jemu/system/cpc/CPC.df1mod : Z
    //   3835: putstatic jemu/system/cpc/CPC.df0mod : Z
    //   3838: aload_0
    //   3839: getfield blastercount : I
    //   3842: iconst_1
    //   3843: if_icmplt -> 3937
    //   3846: iconst_1
    //   3847: putstatic jemu/ui/Switches.blockKeyboard : Z
    //   3850: aload_0
    //   3851: dup
    //   3852: getfield blastercount : I
    //   3855: iconst_1
    //   3856: iadd
    //   3857: putfield blastercount : I
    //   3860: aload_0
    //   3861: getfield blastercount : I
    //   3864: sipush #170
    //   3867: if_icmpeq -> 3880
    //   3870: aload_0
    //   3871: getfield blastercount : I
    //   3874: sipush #180
    //   3877: if_icmpne -> 3889
    //   3880: aload_0
    //   3881: getfield keyboarda : Ljemu/system/cpc/KeyboardA;
    //   3884: bipush #110
    //   3886: invokevirtual keyPressed : (I)V
    //   3889: aload_0
    //   3890: getfield blastercount : I
    //   3893: sipush #175
    //   3896: if_icmpeq -> 3909
    //   3899: aload_0
    //   3900: getfield blastercount : I
    //   3903: sipush #185
    //   3906: if_icmpne -> 3937
    //   3909: aload_0
    //   3910: getfield keyboarda : Ljemu/system/cpc/KeyboardA;
    //   3913: bipush #110
    //   3915: invokevirtual keyReleased : (I)V
    //   3918: aload_0
    //   3919: getfield blastercount : I
    //   3922: sipush #185
    //   3925: if_icmpne -> 3937
    //   3928: iconst_0
    //   3929: putstatic jemu/ui/Switches.blockKeyboard : Z
    //   3932: aload_0
    //   3933: iconst_0
    //   3934: putfield blastercount : I
    //   3937: aload_0
    //   3938: getfield launchcount : I
    //   3941: iconst_1
    //   3942: if_icmplt -> 4055
    //   3945: aload_0
    //   3946: dup
    //   3947: getfield launchcount : I
    //   3950: iconst_1
    //   3951: iadd
    //   3952: putfield launchcount : I
    //   3955: aload_0
    //   3956: getfield launchcount : I
    //   3959: iconst_5
    //   3960: if_icmpne -> 3967
    //   3963: aload_0
    //   3964: invokevirtual softReset : ()V
    //   3967: aload_0
    //   3968: getfield launchcount : I
    //   3971: bipush #10
    //   3973: if_icmpne -> 3980
    //   3976: aload_0
    //   3977: invokevirtual softReset : ()V
    //   3980: aload_0
    //   3981: getfield launchcount : I
    //   3984: bipush #15
    //   3986: if_icmpne -> 3993
    //   3989: aload_0
    //   3990: invokevirtual softReset : ()V
    //   3993: aload_0
    //   3994: getfield launchcount : I
    //   3997: bipush #20
    //   3999: if_icmpne -> 4055
    //   4002: aload_0
    //   4003: iconst_0
    //   4004: putfield launchcount : I
    //   4007: aload_0
    //   4008: getfield launchcode : I
    //   4011: iconst_1
    //   4012: if_icmpne -> 4019
    //   4015: aload_0
    //   4016: invokevirtual launchDigitracker : ()V
    //   4019: aload_0
    //   4020: getfield launchcode : I
    //   4023: iconst_3
    //   4024: if_icmpne -> 4031
    //   4027: aload_0
    //   4028: invokevirtual launchDigitrackerMC : ()V
    //   4031: aload_0
    //   4032: getfield launchcode : I
    //   4035: iconst_4
    //   4036: if_icmpne -> 4043
    //   4039: aload_0
    //   4040: invokevirtual launchDigitrackerPG : ()V
    //   4043: aload_0
    //   4044: getfield launchcode : I
    //   4047: iconst_2
    //   4048: if_icmpne -> 4055
    //   4051: aload_0
    //   4052: invokevirtual launchCheat : ()V
    //   4055: getstatic jemu/ui/Switches.autofire : Z
    //   4058: ifeq -> 4133
    //   4061: aload_0
    //   4062: dup
    //   4063: getfield firetimer : I
    //   4066: iconst_1
    //   4067: iadd
    //   4068: putfield firetimer : I
    //   4071: aload_0
    //   4072: getfield firetimer : I
    //   4075: getstatic jemu/system/cpc/CPC.timefire : I
    //   4078: if_icmplt -> 4158
    //   4081: aload_0
    //   4082: getfield fired : Z
    //   4085: ifeq -> 4111
    //   4088: getstatic jemu/ui/Switches.blockKeyboard : Z
    //   4091: ifne -> 4111
    //   4094: aload_0
    //   4095: getfield keyboarda : Ljemu/system/cpc/KeyboardA;
    //   4098: bipush #101
    //   4100: invokevirtual keyPressed : (I)V
    //   4103: aload_0
    //   4104: iconst_0
    //   4105: putfield fired : Z
    //   4108: goto -> 4125
    //   4111: aload_0
    //   4112: getfield keyboarda : Ljemu/system/cpc/KeyboardA;
    //   4115: bipush #101
    //   4117: invokevirtual keyReleased : (I)V
    //   4120: aload_0
    //   4121: iconst_1
    //   4122: putfield fired : Z
    //   4125: aload_0
    //   4126: iconst_0
    //   4127: putfield firetimer : I
    //   4130: goto -> 4158
    //   4133: aload_0
    //   4134: getfield fired : Z
    //   4137: ifne -> 4158
    //   4140: aload_0
    //   4141: getfield keyboarda : Ljemu/system/cpc/KeyboardA;
    //   4144: bipush #101
    //   4146: invokevirtual keyReleased : (I)V
    //   4149: aload_0
    //   4150: iconst_1
    //   4151: putfield fired : Z
    //   4154: goto -> 4158
    //   4157: astore_2
    //   4158: getstatic jemu/ui/Switches.turbo : I
    //   4161: iconst_1
    //   4162: if_icmple -> 4197
    //   4165: aload_0
    //   4166: dup
    //   4167: getfield turbotimer : I
    //   4170: iconst_1
    //   4171: iadd
    //   4172: putfield turbotimer : I
    //   4175: aload_0
    //   4176: getfield turbotimer : I
    //   4179: bipush #100
    //   4181: if_icmplt -> 4197
    //   4184: aload_0
    //   4185: iconst_0
    //   4186: putfield turbotimer : I
    //   4189: getstatic jemu/ui/Switches.turbo : I
    //   4192: iconst_1
    //   4193: iadd
    //   4194: putstatic jemu/ui/Switches.turbo : I
    //   4197: getstatic jemu/ui/Desktop.sync : Ljavax/swing/JCheckBox;
    //   4200: invokevirtual isSelected : ()Z
    //   4203: ifne -> 4212
    //   4206: getstatic jemu/system/cpc/CPC.disableresync : Z
    //   4209: ifeq -> 4219
    //   4212: aload_0
    //   4213: invokevirtual syncProcessor : ()V
    //   4216: goto -> 4230
    //   4219: aload_0
    //   4220: aload_0
    //   4221: getfield psg : Ljemu/core/device/sound/AY_3_8910;
    //   4224: invokevirtual getSoundPlayer : ()Ljemu/core/device/sound/SoundPlayer;
    //   4227: invokevirtual syncProcessor : (Ljemu/core/device/ComputerTimer;)V
    //   4230: goto -> 4234
    //   4233: astore_2
    //   4234: getstatic jemu/system/cpc/CPC.YM_Play : Z
    //   4237: ifne -> 4248
    //   4240: aload_0
    //   4241: invokevirtual typeAuto : ()V
    //   4244: aload_0
    //   4245: invokevirtual joyReader : ()V
    //   4248: getstatic jemu/system/cpc/CPC.YM_Rec : Z
    //   4251: ifne -> 4278
    //   4254: getstatic jemu/system/cpc/CPC.YM_Play : Z
    //   4257: ifne -> 4278
    //   4260: getstatic jemu/system/cpc/CPC.YM_Stop : Z
    //   4263: ifne -> 4278
    //   4266: getstatic jemu/system/cpc/CPC.YM_Load : Z
    //   4269: ifne -> 4278
    //   4272: getstatic jemu/system/cpc/CPC.YM_Save : Z
    //   4275: ifeq -> 4282
    //   4278: aload_0
    //   4279: invokespecial YMCheck : ()V
    //   4282: getstatic jemu/system/cpc/CPC.overscanPaintFrame : Ljavax/swing/JFrame;
    //   4285: ifnull -> 4313
    //   4288: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   4291: ifnull -> 4313
    //   4294: getstatic jemu/system/cpc/CPC.overscanPaintFrame : Ljavax/swing/JFrame;
    //   4297: invokevirtual isVisible : ()Z
    //   4300: ifeq -> 4309
    //   4303: getstatic jemu/system/cpc/CPC.overscanPaintBox : Ljemu/ui/paint/overscanPaint;
    //   4306: invokevirtual cycle : ()V
    //   4309: goto -> 4313
    //   4312: astore_2
    //   4313: getstatic jemu/system/cpc/CPC.normalPaintFrame : Ljavax/swing/JFrame;
    //   4316: ifnull -> 4344
    //   4319: getstatic jemu/system/cpc/CPC.normalPaintBox : Ljemu/ui/paint/normalPaint;
    //   4322: ifnull -> 4344
    //   4325: getstatic jemu/system/cpc/CPC.normalPaintFrame : Ljavax/swing/JFrame;
    //   4328: invokevirtual isVisible : ()Z
    //   4331: ifeq -> 4340
    //   4334: getstatic jemu/system/cpc/CPC.normalPaintBox : Ljemu/ui/paint/normalPaint;
    //   4337: invokevirtual cycle : ()V
    //   4340: goto -> 4344
    //   4343: astore_2
    //   4344: aload_0
    //   4345: getfield restorebuf : Z
    //   4348: ifeq -> 4367
    //   4351: aload_0
    //   4352: iconst_0
    //   4353: putfield restorebuf : Z
    //   4356: aload_0
    //   4357: ldc_w 'buffer'
    //   4360: aload_0
    //   4361: getfield buffSNA : [B
    //   4364: invokevirtual SNA_Load : (Ljava/lang/String;[B)V
    //   4367: aload_0
    //   4368: getfield storebuf : Z
    //   4371: ifeq -> 4383
    //   4374: aload_0
    //   4375: iconst_0
    //   4376: putfield storebuf : Z
    //   4379: aload_0
    //   4380: invokevirtual stoSNA : ()V
    //   4383: aload_0
    //   4384: getfield snpCapture : Z
    //   4387: ifeq -> 4399
    //   4390: aload_0
    //   4391: iconst_0
    //   4392: putfield snpCapture : Z
    //   4395: aload_0
    //   4396: invokespecial SNP_Capture : ()V
    //   4399: getstatic jemu/system/cpc/CPC.showflippreview : Z
    //   4402: ifeq -> 4409
    //   4405: aload_0
    //   4406: invokevirtual previewFlip : ()V
    //   4409: getstatic jemu/ui/Switches.lightGun : Z
    //   4412: ifeq -> 4419
    //   4415: aload_0
    //   4416: invokevirtual lightGun : ()V
    //   4419: return
    // Line number table:
    //   Java source line number -> byte code offset
    //   #4598	-> 0
    //   #4599	-> 43
    //   #4600	-> 49
    //   #4602	-> 62
    //   #4603	-> 69
    //   #4605	-> 76
    //   #4606	-> 83
    //   #4609	-> 93
    //   #4610	-> 103
    //   #4611	-> 112
    //   #4612	-> 117
    //   #4613	-> 126
    //   #4615	-> 131
    //   #4616	-> 140
    //   #4618	-> 145
    //   #4619	-> 154
    //   #4621	-> 159
    //   #4622	-> 168
    //   #4626	-> 173
    //   #4627	-> 183
    //   #4628	-> 190
    //   #4629	-> 196
    //   #4630	-> 202
    //   #4631	-> 208
    //   #4632	-> 214
    //   #4633	-> 220
    //   #4634	-> 226
    //   #4635	-> 232
    //   #4636	-> 238
    //   #4637	-> 244
    //   #4639	-> 250
    //   #4640	-> 257
    //   #4642	-> 261
    //   #4643	-> 267
    //   #4645	-> 271
    //   #4646	-> 278
    //   #4649	-> 285
    //   #4650	-> 295
    //   #4651	-> 305
    //   #4659	-> 315
    //   #4660	-> 322
    //   #4661	-> 329
    //   #4663	-> 334
    //   #4664	-> 349
    //   #4665	-> 359
    //   #4666	-> 367
    //   #4667	-> 386
    //   #4668	-> 395
    //   #4670	-> 400
    //   #4671	-> 404
    //   #4672	-> 412
    //   #4673	-> 427
    //   #4674	-> 432
    //   #4675	-> 441
    //   #4677	-> 449
    //   #4678	-> 499
    //   #4679	-> 504
    //   #4680	-> 509
    //   #4681	-> 514
    //   #4682	-> 521
    //   #4684	-> 530
    //   #4686	-> 535
    //   #4687	-> 542
    //   #4688	-> 549
    //   #4689	-> 568
    //   #4691	-> 580
    //   #4692	-> 592
    //   #4694	-> 602
    //   #4695	-> 611
    //   #4696	-> 616
    //   #4697	-> 623
    //   #4698	-> 632
    //   #4699	-> 642
    //   #4700	-> 651
    //   #4701	-> 660
    //   #4702	-> 669
    //   #4704	-> 678
    //   #4705	-> 683
    //   #4706	-> 688
    //   #4707	-> 693
    //   #4710	-> 698
    //   #4714	-> 706
    //   #4715	-> 713
    //   #4716	-> 722
    //   #4717	-> 732
    //   #4718	-> 741
    //   #4719	-> 750
    //   #4720	-> 759
    //   #4721	-> 764
    //   #4722	-> 769
    //   #4723	-> 774
    //   #4726	-> 779
    //   #4729	-> 784
    //   #4730	-> 791
    //   #4731	-> 801
    //   #4732	-> 810
    //   #4733	-> 815
    //   #4736	-> 820
    //   #4737	-> 826
    //   #4738	-> 830
    //   #4740	-> 834
    //   #4741	-> 841
    //   #4742	-> 851
    //   #4743	-> 863
    //   #4744	-> 871
    //   #4746	-> 879
    //   #4748	-> 886
    //   #4749	-> 919
    //   #4750	-> 935
    //   #4751	-> 942
    //   #4754	-> 953
    //   #4757	-> 961
    //   #4756	-> 964
    //   #4759	-> 965
    //   #4760	-> 978
    //   #4763	-> 988
    //   #4764	-> 995
    //   #4765	-> 1005
    //   #4767	-> 1016
    //   #4768	-> 1025
    //   #4769	-> 1030
    //   #4772	-> 1037
    //   #4773	-> 1044
    //   #4774	-> 1054
    //   #4775	-> 1065
    //   #4776	-> 1074
    //   #4777	-> 1079
    //   #4780	-> 1087
    //   #4781	-> 1093
    //   #4782	-> 1097
    //   #4784	-> 1101
    //   #4785	-> 1116
    //   #4786	-> 1137
    //   #4788	-> 1147
    //   #4789	-> 1168
    //   #4790	-> 1178
    //   #4791	-> 1182
    //   #4794	-> 1191
    //   #4795	-> 1206
    //   #4796	-> 1227
    //   #4799	-> 1237
    //   #4800	-> 1258
    //   #4801	-> 1268
    //   #4802	-> 1272
    //   #4805	-> 1281
    //   #4806	-> 1287
    //   #4807	-> 1291
    //   #4810	-> 1295
    //   #4811	-> 1302
    //   #4812	-> 1312
    //   #4813	-> 1322
    //   #4814	-> 1327
    //   #4817	-> 1353
    //   #4818	-> 1360
    //   #4819	-> 1370
    //   #4820	-> 1380
    //   #4822	-> 1385
    //   #4824	-> 1389
    //   #4823	-> 1392
    //   #4827	-> 1393
    //   #4828	-> 1405
    //   #4829	-> 1415
    //   #4833	-> 1424
    //   #4834	-> 1428
    //   #4837	-> 1433
    //   #4838	-> 1440
    //   #4839	-> 1445
    //   #4841	-> 1449
    //   #4842	-> 1456
    //   #4843	-> 1461
    //   #4853	-> 1465
    //   #4854	-> 1471
    //   #4855	-> 1475
    //   #4857	-> 1486
    //   #4858	-> 1492
    //   #4859	-> 1497
    //   #4861	-> 1501
    //   #4862	-> 1507
    //   #4863	-> 1512
    //   #4865	-> 1516
    //   #4866	-> 1524
    //   #4867	-> 1533
    //   #4868	-> 1540
    //   #4870	-> 1548
    //   #4871	-> 1552
    //   #4872	-> 1557
    //   #4874	-> 1558
    //   #4875	-> 1568
    //   #4877	-> 1573
    //   #4878	-> 1586
    //   #4879	-> 1594
    //   #4880	-> 1609
    //   #4881	-> 1613
    //   #4882	-> 1620
    //   #4883	-> 1624
    //   #4884	-> 1634
    //   #4883	-> 1649
    //   #4888	-> 1655
    //   #4889	-> 1663
    //   #4888	-> 1677
    //   #4891	-> 1683
    //   #4893	-> 1701
    //   #4894	-> 1710
    //   #4895	-> 1720
    //   #4894	-> 1735
    //   #4897	-> 1741
    //   #4898	-> 1748
    //   #4899	-> 1761
    //   #4900	-> 1769
    //   #4901	-> 1773
    //   #4902	-> 1778
    //   #4904	-> 1782
    //   #4905	-> 1787
    //   #4907	-> 1791
    //   #4908	-> 1800
    //   #4913	-> 1808
    //   #4914	-> 1815
    //   #4916	-> 1816
    //   #4917	-> 1820
    //   #4919	-> 1836
    //   #4920	-> 1842
    //   #4923	-> 1844
    //   #4924	-> 1852
    //   #4926	-> 1857
    //   #4928	-> 1862
    //   #4929	-> 1886
    //   #4932	-> 1896
    //   #4933	-> 1915
    //   #4934	-> 1926
    //   #4935	-> 1937
    //   #4938	-> 1942
    //   #4939	-> 1961
    //   #4940	-> 1972
    //   #4941	-> 1983
    //   #4944	-> 1988
    //   #4945	-> 1994
    //   #4946	-> 2002
    //   #4947	-> 2010
    //   #4948	-> 2014
    //   #4952	-> 2018
    //   #4953	-> 2024
    //   #4954	-> 2028
    //   #4956	-> 2032
    //   #4958	-> 2038
    //   #4960	-> 2047
    //   #4959	-> 2050
    //   #4962	-> 2051
    //   #4964	-> 2060
    //   #4963	-> 2063
    //   #4965	-> 2064
    //   #4967	-> 2068
    //   #4968	-> 2078
    //   #4969	-> 2087
    //   #4970	-> 2092
    //   #4971	-> 2102
    //   #4974	-> 2109
    //   #4975	-> 2119
    //   #4979	-> 2126
    //   #4980	-> 2132
    //   #4981	-> 2136
    //   #4982	-> 2140
    //   #4984	-> 2146
    //   #4985	-> 2152
    //   #4986	-> 2156
    //   #4987	-> 2160
    //   #4989	-> 2166
    //   #4990	-> 2172
    //   #4991	-> 2176
    //   #4993	-> 2180
    //   #4994	-> 2186
    //   #4995	-> 2191
    //   #4996	-> 2195
    //   #4999	-> 2200
    //   #5000	-> 2206
    //   #5001	-> 2211
    //   #5002	-> 2216
    //   #5005	-> 2220
    //   #5006	-> 2227
    //   #5007	-> 2232
    //   #5008	-> 2237
    //   #5010	-> 2241
    //   #5011	-> 2248
    //   #5012	-> 2253
    //   #5013	-> 2258
    //   #5016	-> 2262
    //   #5017	-> 2269
    //   #5018	-> 2279
    //   #5019	-> 2288
    //   #5020	-> 2293
    //   #5023	-> 2297
    //   #5024	-> 2304
    //   #5025	-> 2314
    //   #5026	-> 2323
    //   #5027	-> 2328
    //   #5042	-> 2332
    //   #5043	-> 2338
    //   #5044	-> 2346
    //   #5045	-> 2354
    //   #5046	-> 2358
    //   #5047	-> 2362
    //   #5048	-> 2374
    //   #5049	-> 2377
    //   #5050	-> 2385
    //   #5051	-> 2395
    //   #5052	-> 2401
    //   #5053	-> 2413
    //   #5050	-> 2416
    //   #5049	-> 2422
    //   #5056	-> 2428
    //   #5059	-> 2436
    //   #5060	-> 2442
    //   #5061	-> 2446
    //   #5062	-> 2451
    //   #5064	-> 2458
    //   #5065	-> 2482
    //   #5068	-> 2494
    //   #5069	-> 2518
    //   #5072	-> 2530
    //   #5073	-> 2570
    //   #5074	-> 2576
    //   #5076	-> 2580
    //   #5077	-> 2586
    //   #5078	-> 2595
    //   #5082	-> 2599
    //   #5083	-> 2639
    //   #5084	-> 2645
    //   #5086	-> 2649
    //   #5087	-> 2655
    //   #5088	-> 2664
    //   #5093	-> 2668
    //   #5094	-> 2675
    //   #5095	-> 2685
    //   #5096	-> 2694
    //   #5097	-> 2701
    //   #5100	-> 2706
    //   #5101	-> 2712
    //   #5103	-> 2718
    //   #5105	-> 2735
    //   #5104	-> 2738
    //   #5107	-> 2739
    //   #5108	-> 2743
    //   #5109	-> 2753
    //   #5110	-> 2761
    //   #5111	-> 2772
    //   #5112	-> 2780
    //   #5113	-> 2785
    //   #5114	-> 2807
    //   #5117	-> 2828
    //   #5119	-> 2837
    //   #5118	-> 2840
    //   #5120	-> 2842
    //   #5121	-> 2847
    //   #5123	-> 2848
    //   #5124	-> 2856
    //   #5126	-> 2870
    //   #5127	-> 2876
    //   #5129	-> 2882
    //   #5131	-> 2899
    //   #5130	-> 2902
    //   #5133	-> 2903
    //   #5134	-> 2907
    //   #5135	-> 2911
    //   #5136	-> 2921
    //   #5137	-> 2929
    //   #5138	-> 2940
    //   #5139	-> 2948
    //   #5140	-> 2953
    //   #5141	-> 2975
    //   #5145	-> 2996
    //   #5147	-> 3005
    //   #5146	-> 3008
    //   #5148	-> 3010
    //   #5149	-> 3015
    //   #5151	-> 3016
    //   #5152	-> 3024
    //   #5154	-> 3038
    //   #5155	-> 3044
    //   #5156	-> 3057
    //   #5158	-> 3064
    //   #5159	-> 3086
    //   #5161	-> 3090
    //   #5162	-> 3096
    //   #5163	-> 3100
    //   #5165	-> 3104
    //   #5166	-> 3111
    //   #5167	-> 3121
    //   #5168	-> 3130
    //   #5169	-> 3135
    //   #5172	-> 3143
    //   #5173	-> 3150
    //   #5174	-> 3160
    //   #5175	-> 3169
    //   #5176	-> 3174
    //   #5179	-> 3183
    //   #5180	-> 3189
    //   #5181	-> 3193
    //   #5183	-> 3199
    //   #5184	-> 3205
    //   #5185	-> 3209
    //   #5187	-> 3214
    //   #5188	-> 3220
    //   #5189	-> 3224
    //   #5191	-> 3229
    //   #5192	-> 3235
    //   #5193	-> 3239
    //   #5195	-> 3247
    //   #5196	-> 3254
    //   #5197	-> 3264
    //   #5198	-> 3273
    //   #5201	-> 3277
    //   #5202	-> 3283
    //   #5203	-> 3287
    //   #5205	-> 3291
    //   #5206	-> 3298
    //   #5207	-> 3306
    //   #5208	-> 3314
    //   #5209	-> 3318
    //   #5212	-> 3322
    //   #5213	-> 3328
    //   #5214	-> 3332
    //   #5216	-> 3336
    //   #5217	-> 3342
    //   #5218	-> 3346
    //   #5220	-> 3350
    //   #5221	-> 3356
    //   #5223	-> 3360
    //   #5226	-> 3368
    //   #5224	-> 3371
    //   #5225	-> 3372
    //   #5227	-> 3373
    //   #5229	-> 3377
    //   #5230	-> 3384
    //   #5231	-> 3388
    //   #5232	-> 3396
    //   #5233	-> 3404
    //   #5234	-> 3412
    //   #5236	-> 3416
    //   #5237	-> 3420
    //   #5238	-> 3427
    //   #5239	-> 3458
    //   #5241	-> 3468
    //   #5245	-> 3475
    //   #5246	-> 3482
    //   #5248	-> 3512
    //   #5250	-> 3516
    //   #5251	-> 3522
    //   #5253	-> 3527
    //   #5254	-> 3541
    //   #5255	-> 3551
    //   #5256	-> 3559
    //   #5257	-> 3563
    //   #5261	-> 3568
    //   #5262	-> 3575
    //   #5264	-> 3583
    //   #5265	-> 3590
    //   #5266	-> 3596
    //   #5268	-> 3601
    //   #5269	-> 3607
    //   #5271	-> 3612
    //   #5272	-> 3618
    //   #5274	-> 3623
    //   #5275	-> 3629
    //   #5278	-> 3634
    //   #5279	-> 3642
    //   #5280	-> 3648
    //   #5281	-> 3660
    //   #5282	-> 3666
    //   #5284	-> 3672
    //   #5286	-> 3676
    //   #5289	-> 3680
    //   #5290	-> 3687
    //   #5291	-> 3693
    //   #5293	-> 3698
    //   #5294	-> 3704
    //   #5296	-> 3709
    //   #5297	-> 3715
    //   #5299	-> 3720
    //   #5300	-> 3726
    //   #5302	-> 3731
    //   #5303	-> 3735
    //   #5305	-> 3751
    //   #5306	-> 3758
    //   #5307	-> 3766
    //   #5308	-> 3774
    //   #5309	-> 3778
    //   #5310	-> 3784
    //   #5312	-> 3789
    //   #5313	-> 3795
    //   #5315	-> 3800
    //   #5316	-> 3806
    //   #5318	-> 3811
    //   #5319	-> 3817
    //   #5321	-> 3822
    //   #5324	-> 3838
    //   #5325	-> 3846
    //   #5326	-> 3850
    //   #5328	-> 3860
    //   #5329	-> 3880
    //   #5332	-> 3889
    //   #5333	-> 3909
    //   #5334	-> 3918
    //   #5335	-> 3928
    //   #5336	-> 3932
    //   #5340	-> 3937
    //   #5341	-> 3945
    //   #5342	-> 3955
    //   #5343	-> 3963
    //   #5346	-> 3967
    //   #5347	-> 3976
    //   #5349	-> 3980
    //   #5350	-> 3989
    //   #5352	-> 3993
    //   #5354	-> 4002
    //   #5355	-> 4007
    //   #5356	-> 4015
    //   #5358	-> 4019
    //   #5359	-> 4027
    //   #5361	-> 4031
    //   #5362	-> 4039
    //   #5364	-> 4043
    //   #5365	-> 4051
    //   #5369	-> 4055
    //   #5370	-> 4061
    //   #5371	-> 4071
    //   #5372	-> 4081
    //   #5373	-> 4094
    //   #5374	-> 4103
    //   #5376	-> 4111
    //   #5377	-> 4120
    //   #5379	-> 4125
    //   #5381	-> 4133
    //   #5383	-> 4140
    //   #5384	-> 4149
    //   #5386	-> 4154
    //   #5385	-> 4157
    //   #5389	-> 4158
    //   #5390	-> 4165
    //   #5391	-> 4175
    //   #5392	-> 4184
    //   #5393	-> 4189
    //   #5398	-> 4197
    //   #5399	-> 4212
    //   #5401	-> 4219
    //   #5405	-> 4230
    //   #5403	-> 4233
    //   #5407	-> 4234
    //   #5408	-> 4240
    //   #5409	-> 4244
    //   #5411	-> 4248
    //   #5412	-> 4278
    //   #5414	-> 4282
    //   #5416	-> 4294
    //   #5417	-> 4303
    //   #5420	-> 4309
    //   #5419	-> 4312
    //   #5422	-> 4313
    //   #5424	-> 4325
    //   #5425	-> 4334
    //   #5428	-> 4340
    //   #5427	-> 4343
    //   #5431	-> 4344
    //   #5432	-> 4351
    //   #5433	-> 4356
    //   #5435	-> 4367
    //   #5436	-> 4374
    //   #5437	-> 4379
    //   #5439	-> 4383
    //   #5440	-> 4390
    //   #5441	-> 4395
    //   #5443	-> 4399
    //   #5444	-> 4405
    //   #5446	-> 4409
    //   #5447	-> 4415
    //   #5449	-> 4419
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   1626	29	2	i	I
    //   1657	26	2	i	I
    //   1712	29	2	i	I
    //   1748	60	2	pluspal	[B
    //   1769	39	3	mode	I
    //   1773	35	4	mo	B
    //   1620	188	1	plusmode	Z
    //   2401	15	5	numb	I
    //   2388	34	4	g	I
    //   2379	49	3	i	I
    //   2362	74	2	adr	I
    //   2772	98	2	OCP	Ljavax/swing/JCheckBox;
    //   2807	63	3	object	[Ljava/lang/Object;
    //   2828	42	4	selectedValue	I
    //   2940	98	2	OCP	Ljavax/swing/JCheckBox;
    //   2975	63	3	object	[Ljava/lang/Object;
    //   2996	42	4	selectedValue	I
    //   3372	1	2	emil	Ljava/lang/Exception;
    //   0	4420	0	this	Ljemu/system/cpc/CPC;
    //   1836	2584	1	ledupdate	Z
    // Exception table:
    //   from	to	target	type
    //   886	961	964	java/lang/Exception
    //   1385	1389	1392	java/lang/Exception
    //   2038	2047	2050	java/lang/Exception
    //   2051	2060	2063	java/lang/Exception
    //   2718	2735	2738	java/lang/Exception
    //   2828	2837	2840	java/lang/Exception
    //   2882	2899	2902	java/lang/Exception
    //   2996	3005	3008	java/lang/Exception
    //   3360	3368	3371	java/lang/Exception
    //   4140	4154	4157	java/lang/Exception
    //   4197	4230	4233	java/lang/Exception
    //   4294	4309	4312	java/lang/Exception
    //   4325	4340	4343	java/lang/Exception
  }
  
  protected void putDSKImage(int drive) {
    switch (drive) {
      case 1:
        if (this.dskImageB != null)
          this.dskImage = this.dskImageB; 
        return;
      case 2:
        if (this.dskImageC != null)
          this.dskImage = this.dskImageC; 
        return;
      case 3:
        if (this.dskImageD != null)
          this.dskImage = this.dskImageD; 
        return;
    } 
    if (this.dskImageA != null)
      this.dskImage = this.dskImageA; 
  }
  
  public void SaveDSK() {
    this.dskImage = null;
    int drive = getCurrentDrive();
    System.out.println("Saving image from drive DF" + drive);
    putDSKImage(drive);
    if (this.dskImage != null) {
      this.floppies[drive].setSides(this.dskImage.getNumberOfSides());
      int heads = (this.dskImage.getNumberOfSides() == 1) ? 1 : 3;
      this.fdc.setDrive(drive, this.floppies[drive]);
      this.fdc.getDrive(drive).setDisc(heads, this.dskImage);
      this.dskImage.saveImage();
    } else {
      System.out.println("Failed to save... Probably drive empty?");
    } 
    setCurrentDrive(0);
  }
  
  public void AutoSave(int drive) {
    this.dskImage = null;
    System.out.println("Saving image from drive DF" + drive);
    putDSKImage(drive);
    if (this.dskImage != null) {
      this.floppies[drive].setSides(this.dskImage.getNumberOfSides());
      int heads = (this.dskImage.getNumberOfSides() == 1) ? 1 : 3;
      this.fdc.setDrive(drive, this.floppies[drive]);
      this.fdc.getDrive(drive).setDisc(heads, this.dskImage);
      this.dskImage.saveImage();
    } else {
      System.out.println("Failed to save... Probably drive empty?");
    } 
    setCurrentDrive(0);
  }
  
  public void mouseRight(boolean release) {
    if (release) {
      this.keyboarda.keyReleased(102);
    } else {
      this.keyboarda.keyPressed(102);
    } 
  }
  
  public void mouseLeft(boolean release) {
    if (release) {
      this.keyboarda.keyReleased(100);
    } else {
      this.keyboarda.keyPressed(100);
    } 
  }
  
  public void mouseUp(boolean release) {
    if (release) {
      this.keyboarda.keyReleased(104);
    } else {
      this.keyboarda.keyPressed(104);
    } 
  }
  
  public void mouseDown(boolean release) {
    if (release) {
      this.keyboarda.keyReleased(98);
    } else {
      this.keyboarda.keyPressed(98);
    } 
  }
  
  public void joyReader() {
    if (!Switches.blockKeyboard && Switches.MouseJoy) {
      if (Switches.directxR.equals("Right")) {
        this.keyboarda.keyPressed(102);
        Switches.directxR = "none";
      } 
      if (Switches.directxL.equals("Left")) {
        this.keyboarda.keyPressed(100);
        Switches.directxL = "none";
      } 
      if (Switches.directyU.equals("Up")) {
        this.keyboarda.keyPressed(104);
        Switches.directyU = "none";
      } 
      if (Switches.directyD.equals("Down")) {
        this.keyboarda.keyPressed(98);
        Switches.directyD = "none";
      } 
      Switches.directL++;
      if (Switches.directL >= this.mouseSensivity) {
        Switches.directL = this.mouseSensivity + 1;
        this.keyboarda.keyReleased(100);
      } 
      Switches.directR++;
      if (Switches.directR >= this.mouseSensivity) {
        Switches.directR = this.mouseSensivity + 1;
        this.keyboarda.keyReleased(102);
      } 
      Switches.directU++;
      if (Switches.directU >= this.mouseSensivity) {
        Switches.directU = this.mouseSensivity + 1;
        this.keyboarda.keyReleased(104);
      } 
      Switches.directD++;
      if (Switches.directD >= this.mouseSensivity) {
        Switches.directD = this.mouseSensivity + 1;
        this.keyboarda.keyReleased(98);
      } 
    } 
  }
  
  public static boolean getfromconsole = false;
  
  public static boolean recordKeys;
  
  public void typeAuto() {
    if (Switches.getfromautotype != 0) {
      Switches.getfromautotype = 0;
      AutoType(Autotype.autotext);
    } 
    if (getfromconsole) {
      getfromconsole = false;
      AutoType(Console.autotext);
    } 
    if (this.autotyper != 0) {
      if (Switches.turbo == 1)
        Switches.turbo = 4; 
      this.autotyper++;
      if (this.autotyper == 4)
        try {
          if (Switches.KeyboardSound) {
            if (this.eventArray[this.readkey] != 32 && this.eventArray[this.readkey] != 10)
              Samples.KEYRELEASE.play(); 
            if (this.eventArray[this.readkey] == 32)
              Samples.SPACERELEASE.play(); 
            if (this.eventArray[this.readkey] == 10)
              Samples.ENTERRELEASE.play(); 
          } 
          this.keyboarda.keyReleased(this.eventArray[this.readkey]);
          if (this.shifter[this.readkey + 1]) {
            this.keyboarda.keyPressed(16);
          } else {
            this.keyboarda.keyReleased(16);
          } 
        } catch (Exception e) {
          this.keyboarda.keyReleased(16);
          this.autotyper = 0;
          if (this.turbo) {
            Switches.turbo = 4;
          } else {
            Switches.turbo = 1;
          } 
          Switches.blockKeyboard = false;
        }  
      if (this.autotyper == 7)
        try {
          if (Switches.KeyboardSound) {
            if (this.eventArray[this.readkey] != 32 && this.eventArray[this.readkey] != 10)
              Samples.KEYPRESS.play(); 
            if (this.eventArray[this.readkey] == 32)
              Samples.SPACEPRESS.play(); 
            if (this.eventArray[this.readkey] == 10)
              Samples.ENTERPRESS.play(); 
          } 
          this.readkey++;
          this.keyboarda.keyPressed(this.eventArray[this.readkey]);
          this.autotyper = 1;
        } catch (Exception e) {
          this.keyboarda.keyReleased(16);
          this.autotyper = 0;
          if (this.turbo) {
            Switches.turbo = 4;
          } else {
            Switches.turbo = 1;
          } 
          Switches.blockKeyboard = false;
        }  
    } 
  }
  
  public Memory getMemory() {
    return (Memory)memory;
  }
  
  public static Memory getMem() {
    return (Memory)memory2;
  }
  
  public Processor getProcessor() {
    return (Processor)this.z80;
  }
  
  public Dimension getDisplaySize(boolean large) {
    return this.gateArray.getDisplaySize(large);
  }
  
  public Dimension getDisplayScale(boolean large) {
    return large ? Display.SCALE_1x2 : Display.SCALE_1;
  }
  
  public void setLarge(boolean value) {
    this.gateArray.setHalfSize(!value);
  }
  
  public Disassembler getDisassembler() {
    return this.disassembler;
  }
  
  protected Keyboard getKeyboard() {
    if (Switches.joystick == 0)
      return this.keyboardb; 
    if (Switches.notebook)
      return this.keyboardn; 
    return this.keyboarda;
  }
  
  public static boolean playKeys = false;
  
  protected int keyNumber;
  
  protected int totalKeyNumber;
  
  protected byte[] keyStroke;
  
  public void recordKeys() {
    this.totalKeyNumber = 0;
    this.keyNumber = 0;
    playKeys = false;
    recordKeys = true;
  }
  
  public void playKeys() {
    playKeys = true;
    recordKeys = false;
    this.keyNumber = 0;
  }
  
  public void stopKeys() {
    if (recordKeys) {
      this.totalKeyNumber = this.keyNumber;
      SNK_Save();
    } 
    playKeys = false;
    recordKeys = false;
    this.keyNumber = 0;
  }
  
  public static boolean printeronline = true;
  
  boolean compatibility;
  
  public boolean floppymotor;
  
  public int readPort(int port) {
    int result;
    switch (port) {
      case -3:
        result = 1;
        System.out.println("Port read..." + Util.hex(port) + " result:" + result);
        return result;
      case -2:
        result = ((Switches.Printer && printeronline) ? 0 : 64) | Switches.frequency | Switches.computername * 2 | (this.crtc.isVSync() ? 1 : 0) | this.portB;
        return result;
      case -1:
        if (recordKeys) {
          this.keyStroke[this.keyNumber] = (byte)this.keyboarda.readSelectedRow();
          this.keyNumber++;
          if (this.keyNumber >= 10000000) {
            this.keyNumber = 0;
            recordKeys = false;
            System.out.println("Recording stopped... Buffer full");
          } 
        } 
        if (playKeys) {
          result = this.keyStroke[this.keyNumber];
          this.keyNumber++;
          if (this.keyNumber >= this.totalKeyNumber) {
            System.out.println("Playback finished");
            this.keyNumber = 0;
            playKeys = false;
          } 
        } else if (Switches.blockKeyboard) {
          result = this.keyboarda.readSelectedRow();
        } else {
          result = getKeyboard().readSelectedRow();
        } 
        return result;
    } 
    throw new RuntimeException("Unexpected Port Read: " + Util.hex((short)port));
  }
  
  public void writePort(int port, int value) {
    switch (port) {
      case -3:
        this.psg.setBDIR_BC2_BC1(this.PSG_VALUES[value >> 6], this.ppi.readOutput(0));
        if (Switches.blockKeyboard) {
          this.keyboarda.setSelectedRow(value & 0xF);
        } else {
          getKeyboard().setSelectedRow(value & 0xF);
        } 
        if (this.tapeEnabled) {
          this.TapeRecbyte = (byte)((value & 0x20 ^ 0xFFFFFFFF) * 7);
          if (this.TapeRecbyte == 25) {
            this.TapeRecbyte = 38;
          } else if (this.TapeRecbyte == -7) {
            this.TapeRecbyte = -38;
          } else {
            this.TapeRecbyte = Byte.MIN_VALUE;
          } 
          if (this.compatibility) {
            this.TapeRecbyte = (byte)value;
            if (this.TapeRecbyte == 120) {
              this.TapeRecbyte = -38;
            } else if (this.TapeRecbyte == 88) {
              this.TapeRecbyte = 38;
            } else {
              this.TapeRecbyte = Byte.MIN_VALUE;
            } 
          } 
          if (tapeRelay && this.TapeRecbyte != Byte.MIN_VALUE)
            TapeSound(this.TapeRecbyte); 
          if (((value ^ this.previousPortValue) & 0x10) != 0 || (value & 0x10) == 16)
            TapeRelayCheck(value); 
        } 
        return;
    } 
    if (playvideo)
      return; 
    if ((port & 0x581) == 0) {
      this.floppymotor = ((value & 0x1) != 0);
      Desktop.fdcm.setSelected(this.floppymotor);
      if (!this.floppymotor) {
        if (Switches.FloppySound && Switches.audioenabler == 1 && !Bypass)
          if (WinCPC) {
            Samples.MOTORWINCPC.stop();
          } else {
            Samples.MOTOR.stop();
          }  
      } else if (Switches.FloppySound && Switches.audioenabler == 1 && !Bypass) {
        if (WinCPC) {
          Samples.MOTORWINCPC.loop();
        } else {
          Samples.MOTOR.loop();
        } 
      } 
    } else {
      throw new RuntimeException("Unexpected Port Write: " + Util.hex((short)port) + " with " + Util.hex((byte)value));
    } 
  }
  
  public static boolean WinCPC = true;
  
  public boolean wasWinCPC;
  
  ImageExporter exporter;
  
  boolean doimageexport;
  
  public boolean isPlayCity;
  
  public void keyPressed(KeyEvent e) {
    if (this.key != null)
      this.key.pressKey(e.getKeyCode()); 
    this.display.keyPress(e.getKeyCode());
    if (this.basictypetext == null || e.getKeyCode() == 27) {
      if (e.getKeyCode() == 36 && mfisconnected)
        return; 
      if (normalPaintBox != null && normalPaintBox.isShowing()) {
        if (e.getKeyCode() == 49) {
          this.storeflipA = true;
          return;
        } 
        if (e.getKeyCode() == 50) {
          this.storeflipB = true;
          return;
        } 
        if (e.getKeyCode() == 52) {
          getFlipA();
          return;
        } 
        if (e.getKeyCode() == 53) {
          getFlipB();
          return;
        } 
        if (e.getKeyCode() == 51) {
          showflippreview = !showflippreview;
          return;
        } 
        if (e.getKeyCode() == 54) {
          normalPaintBox.deFlip();
          return;
        } 
        if (e.getKeyCode() == 55) {
          normalPaintBox.makeMovie();
          return;
        } 
        if (e.getKeyCode() == 56) {
          normalPaintBox.resetMovie();
          playmovie = !playmovie;
          return;
        } 
        if (e.getKeyCode() == 57) {
          normalPaintBox.resetMovie();
          return;
        } 
        if (e.getKeyCode() == 48) {
          normalPaintBox.resetMovie();
          normalPaintBox.renderMovie();
          return;
        } 
        if (e.getKeyCode() == 83) {
          normalPaintBox.storeMovie();
          return;
        } 
        if (e.getKeyCode() == 76) {
          normalPaintBox.restoreMovie();
          return;
        } 
      } 
      if (e.getKeyCode() == 32 && playmovie)
        stopMovie(); 
      playSNP = false;
      keySample(e, false);
      if (!Switches.blockKeyboard)
        getKeyboard().keyPressed(e.getKeyCode()); 
      return;
    } 
  }
  
  public void keyPressed(int e) {
    playSNP = false;
    getKeyboard().keyPressed(e);
  }
  
  public void keyReleased(int e) {
    playSNP = false;
    getKeyboard().keyReleased(e);
  }
  
  public void doSong() {
    int adr = 16384;
    int t = 0;
    memory.setForcedRAMBank(192);
    int p;
    for (p = 0; p < 16384; p++) {
      POKE(adr++, (t >> 6 | t | t >> t >> 16) * 10 + (t >> 11 & 0x7));
      t++;
    } 
    adr = 16384;
    memory.setForcedRAMBank(196);
    for (p = 0; p < 16384; p++) {
      POKE(adr++, (t >> 6 | t | t >> t >> 16) * 10 + (t >> 11 & 0x7));
      t++;
    } 
    adr = 16384;
    memory.setForcedRAMBank(197);
    for (p = 0; p < 16384; p++) {
      POKE(adr++, (t >> 6 | t | t >> t >> 16) * 10 + (t >> 11 & 0x7));
      t++;
    } 
    adr = 16384;
    memory.setForcedRAMBank(198);
    for (p = 0; p < 16384; p++) {
      POKE(adr++, (t >> 6 | t | t >> t >> 16) * 10 + (t >> 11 & 0x7));
      t++;
    } 
    adr = 16384;
    memory.setForcedRAMBank(196);
    for (p = 0; p < 16384; p++) {
      POKE(adr++, (t >> 6 | t | t >> t >> 16) * 10 + (t >> 11 & 0x7));
      t++;
    } 
    adr = 16384;
    memory.setForcedRAMBank(198);
    for (p = 0; p < 16384; p++) {
      POKE(adr++, (t >> 6 | t | t >> t >> 16) * 10 + (t >> 11 & 0x7));
      t++;
    } 
    adr = 16384;
    memory.setForcedRAMBank(199);
    for (p = 0; p < 16384; p++) {
      POKE(adr++, (t >> 6 | t | t >> t >> 16) * 10 + (t >> 11 & 0x7));
      t++;
    } 
    memory.setForcedRAMBank(192);
  }
  
  public void keyReleased(KeyEvent e) {
    if (this.key != null)
      this.key.releaseKey(e.getKeyCode()); 
    this.display.keyRelease(e.getKeyCode());
    if (this.basictypetext != null)
      if (e.getKeyCode() == 27) {
        this.basictypetext = null;
      } else {
        return;
      }  
    int disabled = -782585363;
    if (e.getKeyCode() == disabled + 36) {
      if (this.exporter == null)
        this.exporter = new ImageExporter(); 
      this.doimageexport = !this.doimageexport;
    } 
    if (e.getKeyCode() == 36)
      PackAll(); 
    if (e.getKeyCode() == 97);
    if (e.getKeyCode() == 103);
    if (e.getKeyCode() == 105);
    if (e.getKeyCode() == 36 && memory.plus) {
      this.loadedplus = false;
      Settings.set("cpr_file", "empty");
      reset();
      return;
    } 
    if (e.getKeyCode() == 36) {
      if (!memory.multi && mfisconnected)
        doMultiface(); 
      return;
    } 
    if (normalPaintBox != null && normalPaintBox.isShowing()) {
      if (e.getKeyCode() == 49)
        return; 
      if (e.getKeyCode() == 50)
        return; 
      if (e.getKeyCode() == 51)
        return; 
      if (e.getKeyCode() == 52)
        return; 
      if (e.getKeyCode() == 53)
        return; 
      if (e.getKeyCode() == 54)
        return; 
      if (e.getKeyCode() == 55)
        return; 
      if (e.getKeyCode() == 56)
        return; 
      if (e.getKeyCode() == 57)
        return; 
      if (e.getKeyCode() == 83)
        return; 
      if (e.getKeyCode() == 76)
        return; 
    } 
    playSNP = false;
    keySample(e, true);
    if (!Switches.blockKeyboard)
      getKeyboard().keyReleased(e.getKeyCode()); 
    if (!Switches.blockKeyboard)
      getKeyboard().keyReleased(e.getKeyCode()); 
  }
  
  public static void dump() {
    try {
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("output.bin"));
      bos.write(memory.getMemory());
      bos.close();
    } catch (Exception exception) {}
  }
  
  public void AtKey() {
    AutoType("@");
  }
  
  public void bootDisk() {
    int drive = this.fdc.getDrive();
    System.out.println("booting from drive " + drive);
    bootDisk(0, false);
  }
  
  public void bootDiskb() {
    bootDisk(1, false);
  }
  
  public void bootCPM() {
    this.fromautoboot = true;
    BasicAutoType("|CPM");
  }
  
  public void typeRun() {
    AutoType("RUN\"");
  }
  
  public void typeCat() {
    AutoType("CAT\n");
  }
  
  public void AutoType() {
    AutoType(Switches.loadauto);
  }
  
  public void MouseFire1() {
    if (!Switches.blockKeyboard)
      this.keyboarda.keyPressed(101); 
  }
  
  public void MouseFire2() {
    if (!Switches.blockKeyboard)
      this.keyboarda.keyPressed(96); 
  }
  
  public void lightgunShot() {
    if (!Switches.blockKeyboard)
      this.keyboarda.keyPressed(98); 
  }
  
  public void lightgunRelease() {
    if (!Switches.blockKeyboard) {
      this.keyboarda.keyReleased(101);
      this.keyboarda.keyReleased(98);
    } 
  }
  
  public void MouseReleaseFire1() {
    if (!Switches.blockKeyboard)
      this.keyboarda.keyReleased(101); 
  }
  
  public void MouseReleaseFire2() {
    if (!Switches.blockKeyboard)
      this.keyboarda.keyReleased(96); 
  }
  
  public void AutoType(String textinput) {
    if (textinput == null || textinput.length() < 1)
      return; 
    if (Switches.turbo >= 2) {
      this.turbo = true;
    } else {
      this.turbo = false;
    } 
    Switches.turbo = 4;
    Switches.blockKeyboard = true;
    this.readkey = 0;
    this.eventArray = new int[textinput.length()];
    this.shifter = new boolean[textinput.length()];
    for (int i = 0; i < textinput.length(); i++) {
      this.eventArray[i] = convertCharToVK(textinput.charAt(i));
      this.shifter[i] = shift;
    } 
    this.keyboarda.keyReleased(65406);
    this.keyboarda.keyReleased(17);
    this.keyboarda.keyReleased(16);
    if (this.shifter[0])
      this.keyboarda.keyPressed(16); 
    this.keyboarda.keyPressed(this.eventArray[0]);
    this.autotyper = 1;
  }
  
  public void keyType(String textinput) {
    Switches.blockKeyboard = true;
    this.readkey = 0;
    this.eventArray = new int[textinput.length()];
    this.shifter = new boolean[textinput.length()];
    for (int i = 0; i < textinput.length(); i++) {
      this.eventArray[i] = convertCharToVK(textinput.charAt(i));
      this.shifter[i] = shift;
    } 
    this.keyboarda.keyReleased(65406);
    this.keyboarda.keyReleased(17);
    this.keyboarda.keyReleased(16);
    if (this.shifter[0])
      this.keyboarda.keyPressed(16); 
    this.keyboarda.keyPressed(this.eventArray[0]);
    this.autotyper = 1;
  }
  
  protected static final int[] ASC_TO_KEY = new int[] { 
      32, 49, 50, 51, 52, 53, 54, 55, 56, 57, 
      59, 222, 44, 45, 46, 47, 48, 49, 50, 51, 
      52, 53, 54, 55, 56, 57, 59, 222, 44, 45, 
      46, 47, 91, 65, 66, 67, 68, 69, 70, 71, 
      72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 
      82, 83, 84, 85, 86, 87, 88, 89, 90, 65406, 
      92, 93, 61, 48, 92, 65, 66, 67, 68, 69, 
      70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 
      80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 
      90, 65406, 91, 93 };
  
  protected static final String ASC_TO_SHIFT = "FTTTTTTTTTTTFFFFFFFFFFFFFFFFTTTTFTTTTTTTTTTTTTTTTTTTTTTTTTTFFFFTTFFFFFFFFFFFFFFFFFFFFFFFFFFTTT";
  
  protected static final String SNA_HEADER = "MV - SNA";
  
  protected static final String SNP_HEADER = "MV - SNP";
  
  protected static final String SNK_HEADER = "MH - SNK CAPTURE";
  
  protected static final String SNKO_HEADER = "MV - SNK";
  
  public static int convertCharToVK(char in) {
    int result;
    switch (in) {
      case '\n':
        shift = false;
        result = 10;
        return result;
      case '£':
        shift = true;
        result = 61;
        return result;
    } 
    if (in >= ' ' && in <= '}') {
      in = (char)(in - 32);
      result = ASC_TO_KEY[in];
      shift = ("FTTTTTTTTTTTFFFFFFFFFFFFFFFFTTTTFTTTTTTTTTTTTTTTTTTTTTTTTTTFFFFTTFFFFFFFFFFFFFFFFFFFFFFFFFFTTT".charAt(in) == 'T');
    } else {
      shift = false;
      result = 65535;
    } 
    return result;
  }
  
  protected static final String SNP_EYECATCHER = "JavaCPC " + Main.version + Main.subversion;
  
  protected static final String SNK_EYECATCHER = "JavaCPC Keyboard   record file  ";
  
  protected static String SNK_FLOPPY_A = "empty";
  
  protected static String SNK_FLOPPY_B = "empty";
  
  protected static String BIN_HEADER = "JAVACPC BIN";
  
  protected static String BIN_EYECATCHER = "File exported by     JavaCPC    ";
  
  protected static String SNA_EYECATCHER = "JavaCPC Snapshot";
  
  protected static final String k64 = "64k Snapshot    ";
  
  protected static final String k128 = "128k Snapshot   ";
  
  protected static final String k256 = "320k Snapshot   ";
  
  protected static final String k512 = "576k Snapshot   ";
  
  protected static final String k4096 = "4MB Snapshot    ";
  
  protected static final String DSK_HEADER = "MV - CPC";
  
  protected static final String DSK_HEADER_EXT = "EXTENDED";
  
  protected static final String CDT_HEADER = "ZXTAPE";
  
  protected static final int CRTC_FLAG_VSYNC_ACTIVE = 1;
  
  protected static final int CRTC_FLAG_HSYNC_ACTIVE = 2;
  
  protected static final int CRTC_FLAG_HDISP_ACTIVE = 4;
  
  protected static final int CRTC_FLAG_VDISP_ACTIVE = 8;
  
  protected static final int CRTC_FLAG_HTOT_REACHED = 16;
  
  protected static final int CRTC_FLAG_VTOT_REACHED = 32;
  
  protected static final int CRTC_FLAG_MAXIMUM_RASTER_COUNT_REACHED = 64;
  
  protected static final int SNAPSHOT_ID = 0;
  
  protected static final int VERSION = 16;
  
  protected static final int AF = 17;
  
  protected static final int BC = 19;
  
  protected static final int DE = 21;
  
  protected static final int HL = 23;
  
  protected static final int R = 25;
  
  protected static final int I = 26;
  
  protected static final int IFF1 = 27;
  
  protected static final int IFF2 = 28;
  
  protected static final int IX = 29;
  
  protected static final int IY = 31;
  
  protected static final int SP = 33;
  
  protected static final int PC = 35;
  
  protected static final int IM = 37;
  
  protected static final int AF1 = 38;
  
  protected static final int BC1 = 40;
  
  protected static final int DE1 = 42;
  
  protected static final int HL1 = 44;
  
  protected static final int GA_PEN = 46;
  
  protected static final int GA_INKS = 47;
  
  protected static final int GA_ROM = 64;
  
  protected static final int GA_RAM = 65;
  
  protected static final int CRTC_REG = 66;
  
  protected static final int CRTC_REGS = 67;
  
  protected static final int UPPER_ROM = 85;
  
  protected static final int PPI_A = 86;
  
  protected static final int PPI_B = 87;
  
  protected static final int PPI_C = 88;
  
  protected static final int PPI_CONTROL = 89;
  
  protected static final int PSG_REG = 90;
  
  protected static final int PSG_REGS = 91;
  
  protected static final int MEM_SIZE = 107;
  
  protected static final int CPC_TYPE = 109;
  
  protected static final int PLAY_CITY_A = 186;
  
  protected static final int PLAY_CITY_B = 206;
  
  protected static final int CRTC = 112;
  
  protected static final int HEADER_SIZE = 256;
  
  int sectorsize;
  
  protected EditorPanel argAssembler;
  
  protected int doautotype;
  
  protected int doargs;
  
  public int frequency;
  
  String df0;
  
  byte[] codeo;
  
  byte[] coden;
  
  int snacount;
  
  int snaocount;
  
  int[] rdiskbanks;
  
  int[] banks;
  
  protected int[] banks4mb;
  
  private int SNAsize;
  
  public void loadFile(int type, String name) throws Exception {
    this.hasMP3 = false;
    this.mp3loaded = false;
    if (name.equals("empty") || name.length() < 1)
      return; 
    restoreScreen();
    Switches.name = name;
    System.out.println("opening: " + name);
    byte[] data = null;
    try {
      data = getFile(name);
    } catch (NullPointerException e) {
      return;
    } 
    if (data.length < 1)
      return; 
    if (name.toLowerCase().endsWith(".sample")) {
      Switches.booter = 1;
      RAW_Load(data);
      JEMU.isTape = true;
    } else if (name.toLowerCase().endsWith(".tap")) {
      Switches.booter = 0;
      loadTAP(data);
      JEMU.isTape = true;
    } else if (name.toLowerCase().endsWith(".ani") || name.toLowerCase().endsWith(".anz")) {
      Switches.booter = 1;
      restoreMovie(name, data);
      JEMU.isTape = true;
    } else if ("MV - SNA".equals((new String(data, 0, "MV - SNA".length())).toUpperCase())) {
      SNA_Load(name, data);
      System.out.println("Loading MV - SNA snapshot file...");
      JEMU.isTape = true;
    } else if ("MH - SNK CAPTURE".equals((new String(data, 0, "MH - SNK CAPTURE".length())).toUpperCase())) {
      SNK_Load(name, data);
      System.out.println("Loading MH - SNK snapshot record file...");
      JEMU.isTape = true;
    } else if ("MV - SNP".equals((new String(data, 0, "MV - SNP".length())).toUpperCase())) {
      SNP_Load(name, data, true);
      System.out.println("Loading MV - SNP snapshot record file...");
      JEMU.isTape = true;
    } else if (name.toLowerCase().endsWith(".snp")) {
      SNP_Load(name, data, true);
      System.out.println("Loading MV - SNP snapshot record file...");
      JEMU.isTape = true;
    } else if ("MV - SNK".equals((new String(data, 0, "MV - SNK".length())).toUpperCase())) {
      SNK_Load(name, data);
      System.out.println("Loading MV - SNP snapshot record file...");
      JEMU.isTape = true;
    } else if ("MV - CPC".equals((new String(data, 0, "MV - CPC".length())).toUpperCase())) {
      DSK_Load(name, data);
      System.out.println("Loading MV - CPCEMU DSK file...");
    } else if (name.toLowerCase().endsWith(".dsk.png")) {
      LoadPNGDisk(name, data);
      System.out.println("Loading PNG Disk image file...");
    } else if ("EXTENDED".equals((new String(data, 0, "EXTENDED".length())).toUpperCase())) {
      DSK_Load(name, data);
      System.out.println("Loading EXTENDED CPC DSK file...");
    } else if ("ZXTAPE".equals((new String(data, 0, "ZXTAPE".length())).toUpperCase())) {
      System.out.println("Loading ZXTAPE file...");
      ids = null;
      blocks = null;
      CDT_Load(name, data);
      this.counterInit = 20;
      TapeDeck.tapeChanged = false;
      this.TapeDrive.buildTapeBlocks();
    } else if (this.WAV_HEADER.equals((new String(data, 0, this.WAV_HEADER.length())).toUpperCase())) {
      Switches.booter = 0;
      System.out.println("Loading WAV-tape file...");
      ids = null;
      blocks = null;
      TapeLoad(name, data);
      TapeDeck.tapeChanged = false;
      this.TapeDrive.buildTapeBlocks();
      this.TapeDrive.showText(this.TapeDrive.filename);
      JEMU.isTape = true;
    } else if ("YM".equals((new String(data, 0, "YM".length())).toUpperCase()) || name.contains(".ym")) {
      JEMU.isTape = true;
      System.out.println("Loading YM audio-file...");
      Switches.booter = 1;
      loadYM(unLHA(name), false);
      YM_Play = true;
    } else if (this.CSW_HEADER.equals(new String(data, 0, this.CSW_HEADER.length())) || name.toUpperCase().endsWith(".CSW")) {
      Switches.booter = 0;
      System.out.println("Loading CSW-compressed square wave tape file...");
      ids = null;
      blocks = null;
      CSWLoad(name, data);
      this.counterInit = 20;
      TapeDeck.tapeChanged = false;
      this.TapeDrive.buildTapeBlocks();
      this.TapeDrive.showText(this.TapeDrive.filename);
      JEMU.isTape = true;
    } else if (this.MP3_HEADER_A.equals((new String(data, 0, this.MP3_HEADER_A.length())).toUpperCase())) {
      Switches.booter = 1;
      System.out.println("Loading and converting MP3 file...");
      ids = null;
      blocks = null;
      MP3Load(name);
      TapeDeck.tapeChanged = false;
      this.TapeDrive.buildTapeBlocks();
      this.TapeDrive.showText(this.TapeDrive.filename);
      JEMU.isTape = true;
    } else if (this.MP3_HEADER_B.equals((new String(data, 0, this.MP3_HEADER_B.length())).toUpperCase())) {
      Switches.booter = 1;
      System.out.println("Loading and converting MP3 file...");
      ids = null;
      blocks = null;
      MP3Load(name);
      TapeDeck.tapeChanged = false;
      this.TapeDrive.buildTapeBlocks();
      this.TapeDrive.showText(this.TapeDrive.filename);
      JEMU.isTape = true;
    } else if (name.toUpperCase().endsWith("MP3")) {
      Switches.booter = 1;
      System.out.println("Loading and converting MP3 file...");
      ids = null;
      blocks = null;
      MP3Load(name);
      TapeDeck.tapeChanged = false;
      this.TapeDrive.buildTapeBlocks();
      JEMU.isTape = true;
      this.TapeDrive.showText(this.TapeDrive.filename);
    } else if (name.toUpperCase().endsWith("YM")) {
      Switches.booter = 1;
      System.out.println("Loading and converting YM file...");
      JEMU.isTape = true;
      loadYM(unLHA(name), true);
      YM_Play = true;
    } else if (name.toUpperCase().endsWith("MFM")) {
      Switches.booter = 0;
      System.out.println("Loading KyroFluxDisk file...");
      loadKyroFluxDisk(name, data);
    } else if (name.toUpperCase().endsWith("WAV") || name.toUpperCase().endsWith("JTP")) {
      ids = null;
      blocks = null;
      TapeLoad(name, data);
      TapeDeck.tapeChanged = false;
      this.TapeDrive.buildTapeBlocks();
      this.TapeDrive.showText(this.TapeDrive.filename);
      JEMU.isTape = true;
    } else if (!JEMU.isTape) {
      BIN_Load(name, data);
    } 
    reSync();
  }
  
  public void DSK2MFM() {
    byte[] data = null;
    FileDialog filedia = new FileDialog(new Frame(), "Open DSK to convert...", 0);
    filedia.setFile("*.dsk");
    filedia.setVisible(true);
    String filename = filedia.getDirectory() + filedia.getFile();
    if (filedia.getFile() != null)
      try {
        FileInputStream fin = new FileInputStream(filename);
        data = new byte[fin.available()];
        fin.read(data);
        fin.close();
        KryoFluxDisk.DskToI4(data, filename);
      } catch (Exception exception) {} 
  }
  
  public void loadKyroFluxDisk(String name, byte[] data) {
    int result = 0;
    for (int i = 0; i < this.sectorsize; i++)
      result += data[i] & 0xFF; 
    boolean datadisk = false;
    result /= this.sectorsize;
    result &= 0xFFFF;
    System.out.println("MFM checksum: " + result);
    if (result == 141) {
      datadisk = false;
      System.out.println("CPM plus System");
    } else if (result == 122) {
      datadisk = false;
      System.out.println("CPM 2.2 System");
    } else if (result == 229) {
      datadisk = false;
      System.out.println("System without bootblock");
    } else if ((data[0] & 0xFF) != 229) {
      datadisk = true;
      System.out.println("DATA disk");
    } else {
      datadisk = false;
      System.out.println("Unknown system disk");
    } 
    byte[] outFileData = new byte[194816];
    KryoFluxDisk.i4ToDsk(data, outFileData, datadisk);
    try {
      DSK_Load(name, outFileData);
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public static int[] getBlocks() {
    return blocks;
  }
  
  public static String[] getIDs() {
    return ids;
  }
  
  public void assemble(String file, String code) {
    if (this.argAssembler == null)
      this.argAssembler = new EditorPanel(null, 0); 
    this.argAssembler.printInfo = true;
    this.argAssembler.asmFile = file;
    this.argAssembler.Assemble(code, false);
  }
  
  public void checkArgs() {
    if (drivea != null) {
      this.doargs = 1;
      this.loaddrivea = true;
    } 
    if (assemblercode != null) {
      this.doargs = 1;
      this.assemblecode = true;
    } 
    if (snapshot != null) {
      this.doargs = 1;
      this.loadsnapshot = true;
    } 
    if (driveb != null) {
      this.doargs = 1;
      this.loaddriveb = true;
    } 
    if (tape != null) {
      this.doargs = 1;
      this.loadtapedrive = true;
    } 
    if (autotypetext != null)
      this.doautotype = 1; 
  }
  
  public void doArgs() throws Exception {
    if (assemblercode != null) {
      this.assemblecode = false;
      byte[] data = getFile(assemblercode);
      StringBuilder builder = new StringBuilder();
      for (int i = 0; i < data.length; i++)
        builder.append((char)(data[i] & 0xFF)); 
      this.argAssembler = new EditorPanel(null, 0);
      this.argAssembler.asmFile = assemblercode;
      this.argAssembler.printInfo = true;
      this.argAssembler.Assemble(builder.toString(), false);
    } 
    if (drivea != null) {
      this.loaddrivea = false;
      byte[] data = getFile(drivea);
      DSK_Load(drivea, data, 0);
    } 
    if (snapshot != null) {
      this.loadsnapshot = false;
      byte[] data = getFile(snapshot);
      SNA_Load(snapshot, data);
      snapshot = null;
    } 
    if (driveb != null) {
      this.loaddriveb = false;
      byte[] data = getFile(driveb);
      DSK_Load(drivea, data, 1);
    } 
    if (tape != null) {
      this.loadtapedrive = false;
      byte[] data = getFile(tape);
      CDT_Load(drivea, data);
    } 
    if (bootdrive.equals("df0"))
      bootDisk(0, true); 
    if (bootdrive.equals("df1"))
      bootDisk(1, true); 
    if (bootdrive.equals("tape"))
      tapestarttimer = 1; 
    resync = true;
  }
  
  public void CDT_Load(String name, byte[] data) throws Exception {
    if (loadtap)
      unpatchOS(); 
    loadtap = false;
    if (this.loadtapedrive)
      return; 
    blocks = null;
    ids = null;
    tape_stereo = false;
    bitrate = 8;
    tapeloaded = false;
    JEMU.isTape = true;
    int freq = 44100;
    if (Switches.khz44)
      freq = 44100; 
    if (Switches.khz11)
      freq = 11025; 
    if (!Switches.khz11 && !Switches.khz44)
      freq = 22050; 
    this.frequency = freq;
    System.out.println("Converting CDT to " + freq + "hz WAV...");
    System.out.println("CDT size is:" + data.length);
    isCDT = true;
    Switches.booter = 0;
    CDT2WAV cdt2wav = new CDT2WAV(data, freq);
    tapesample = cdt2wav.convert();
    blocks = cdt2wav.blocks;
    ids = cdt2wav.ids;
    blocks[blocks.length - 1] = tapesample.length - 44;
    ids[ids.length - 1] = "Eject tape";
    cdt2wav.dispose();
    tape_delay = 1050000 / freq;
    this.tapedelay = 1050000;
    tapeBandPosition = 0;
    tapePlay = true;
    if (Switches.FloppySound && !tapeloaded)
      Samples.TAPEINSERT.play(); 
    this.TapeDrive.pressPlay();
    tapeloaded = true;
    recordcount = tapesample.length;
    System.out.println("Tape size is:" + tapesample.length + " bytes");
    this.TapeDrive.showText(this.TapeDrive.filename);
    getTapeCounter();
    printTapeTime();
    reSync();
  }
  
  public String getDrive0Name() {
    return this.df0;
  }
  
  public void DSK_Load(String name, byte[] data, int drive) throws Exception {
    int i = getCurrentDrive();
    if (drive == 0) {
      System.out.println(name);
      this.df0 = name;
    } 
    setCurrentDrive(drive);
    DSK_Load(name, data);
    setCurrentDrive(i);
  }
  
  public byte[] getDSKImage(int drive, int head) {
    byte[] dump = null;
    dump = this.fdc.getDrive(drive).getDisc(head).getImage();
    return dump;
  }
  
  public byte[] getDSKImage(int drive) {
    byte[] dump = null;
    dump = this.fdc.getDrive(drive).getDisc(0).getImage();
    return dump;
  }
  
  public void DSK_Load(String name, byte[] data) throws Exception {
    byte[] sector0 = new byte[512];
    System.arraycopy(data, 512, sector0, 0, 512);
    int result = 0;
    for (int i = 0; i < this.sectorsize; i++)
      result += sector0[i] & 0xFF; 
    result /= this.sectorsize;
    result &= 0xFFFF;
    System.out.println("DSK checksum:" + result);
    if (Switches.FloppySound && Switches.audioenabler == 1)
      Samples.INSERT.play(); 
    Switches.booter = 0;
    int drive = getCurrentDrive();
    if (drive == 0) {
      System.out.println(name);
      this.df0 = name;
    } 
    disableSave[drive] = false;
    if (this.loaddrivea && drive == 0)
      return; 
    if (this.loaddriveb && drive == 1)
      return; 
    CPCDiscImage image = new CPCDiscImage(name, data);
    System.out.println("data length:" + data.length);
    if (drive == 0) {
      checkDF0();
      this.dskImageA = image;
      df0mod = false;
    } 
    if (drive == 1) {
      checkDF1();
      this.dskImageB = image;
      df1mod = false;
    } 
    if (drive == 2) {
      checkDF2();
      this.dskImageC = image;
      df2mod = false;
    } 
    if (drive == 3) {
      checkDF3();
      this.dskImageD = image;
      df3mod = false;
    } 
    this.floppies[drive].setSides(image.getNumberOfSides());
    int heads = (image.getNumberOfSides() == 1) ? 1 : 3;
    this.fdc.setDrive(drive, this.floppies[drive]);
    this.fdc.getDrive(drive).setDisc(heads, image);
    this.fdc.changeFloppyInDrive(drive);
    if (getCurrentDrive() == 0)
      Switches.loaddrivea = name; 
    if (getCurrentDrive() == 1)
      Switches.loaddriveb = name; 
    if (getCurrentDrive() == 2)
      Switches.loaddrivec = name; 
    if (getCurrentDrive() == 3)
      Switches.loaddrived = name; 
    if (Switches.inspector) {
      this.inspectdrive = drive;
      this.inspect = 1;
    } 
    if (shouldBoot) {
      this.inspectdrive = drive;
      this.boot = 1;
    } 
    reSync();
  }
  
  public void updateBox() {
    boolean sys = this.fdc.showSys;
    this.fdc.showSys = true;
    int drive = getCurrentDrive();
    overscanPaint.files = this.fdc.getInfo(drive);
    this.fdc.showSys = sys;
  }
  
  public String[] getDir() {
    return this.fdc.getInfo(0);
  }
  
  public void NormalupdateBox() {
    boolean sys = this.fdc.showSys;
    this.fdc.showSys = true;
    int drive = getCurrentDrive();
    normalPaint.files = this.fdc.getInfo(drive);
    this.fdc.showSys = sys;
  }
  
  public void loadNormalPaint2() {
    disableresync = true;
    if (this.coden == null)
      this.coden = getRom("file/normalpaint.sna"); 
    this.snacount = 1;
  }
  
  public void loadOverscanPaint2() {
    disableresync = true;
    if (this.codeo == null)
      this.codeo = getRom("file/overscanpaint.sna"); 
    this.snaocount = 1;
  }
  
  public void loadOverscanPaint() {
    if (this.codeo == null)
      this.codeo = getRom("file/CODEOV.BIN", 935); 
    POKE(36863, 20);
    for (int i = 0; i < this.codeo.length; i++)
      POKE(36864 + i, this.codeo[i]); 
    runBinary(36864);
  }
  
  public void loadNormalPaint() {
    if (this.coden == null)
      this.coden = getRom("file/CODENO.BIN", 935); 
    int i;
    for (i = 512; i < 40960; i++)
      POKE(i, 0); 
    for (i = 0; i < this.coden.length; i++)
      POKE(36864 + i, this.coden[i]); 
    POKE(36863, 0);
    runBinary(36864);
  }
  
  private void RAW_Load(byte[] data) {
    int pos = 0;
    boolean mb4 = (data.length > 606208);
    int m = memory.getRAMBank();
    for (int i = 0; i < data.length; i += 16384) {
      if (mb4) {
        memory.set4MBRamBank(this.banks4mb[pos++]);
      } else {
        memory.setForcedRAMBank(this.banks[pos++]);
      } 
      for (int g = 0; g < 16384; g++)
        POKE(16384 + g, data[i + g]); 
    } 
    memory.setForcedRAMBank(m);
  }
  
  public void SNA_Load(String name, byte[] data) {
    Switches.booter = 1;
    this.z80.setAF(getWord(data, 17));
    this.z80.setBC(getWord(data, 19));
    this.z80.setDE(getWord(data, 21));
    this.z80.setHL(getWord(data, 23));
    this.z80.setR(data[25]);
    this.z80.setI(data[26]);
    this.z80.setIFF1((data[27] != 0));
    this.z80.setIFF2((data[28] != 0));
    this.z80.setIX(getWord(data, 29));
    this.z80.setIY(getWord(data, 31));
    this.z80.setSP(getWord(data, 33));
    this.z80.setPC(getWord(data, 35));
    this.z80.setIM(data[37]);
    this.z80.setAF1(getWord(data, 38));
    this.z80.setBC1(getWord(data, 40));
    this.z80.setDE1(getWord(data, 42));
    this.z80.setHL1(getWord(data, 44));
    this.gateArray.setSelectedInk(data[46]);
    int i;
    for (i = 0; i < 17; i++)
      GateArray.setInk(i, data[47 + i]); 
    this.gateArray.setModeAndROMEnable(memory, data[64]);
    memory.setMemoryRAMBank(data[65]);
    this.crtc.setSelectedRegister(data[66]);
    for (i = 0; i < 18; i++)
      this.crtc.setRegister(i, data[67 + i]); 
    memory.setUpperROM(data[85]);
    this.ppi.setControl(data[89] & 0xFF | 0x80);
    this.ppi.setOutputValue(0, data[86] & 0xFF);
    this.ppi.setOutputValue(1, data[87] & 0xFF);
    int portC = data[88] & 0xFF;
    this.ppi.setOutputValue(2, portC);
    this.psg.setBDIR_BC2_BC1(this.PSG_VALUES[portC >> 6], this.ppi.readOutput(0));
    this.psg.reset();
    this.psg.setSelectedRegister(data[90]);
    for (int j = 0; j < 14; j++)
      this.psg.setRegister(j, data[91 + j] & 0xFF); 
    int checkplaycity = 0;
    int k;
    for (k = 0; k < 16; k++)
      checkplaycity += data[186 + k] & 0xFF; 
    if (checkplaycity > 0) {
      this.psg1.reset();
      this.psg1.resetRegisters();
      this.psg2.reset();
      this.psg2.resetRegisters();
      this.z84c30.reset();
      this.z84c30.counter = data[185];
      this.z84c30.docycle = (data[184] != 0);
      this.psg1.setBDIR_BC2_BC1(this.PSG_VALUES[portC >> 6], this.ppi.readOutput(0));
      this.psg2.setBDIR_BC2_BC1(this.PSG_VALUES[portC >> 6], this.ppi.readOutput(0));
      this.psg1.setSelectedRegister(data[186] & 0xFF);
      for (k = 0; k < 16; k++)
        this.psg1.setRegister(k, data[187 + k] & 0xFF); 
      this.psg2.setSelectedRegister(data[206] & 0xFF);
      for (k = 0; k < 16; k++)
        this.psg2.setRegister(k, data[207 + k] & 0xFF); 
    } 
    int crt = data[112];
    if (crt > 0)
      this.crtc.setCRTC(data[112] - 1); 
    int memSize = getWord(data, 107) * 1024;
    this.SNAsize = 256 + memSize;
    if (memory.has4MB && memSize > 589824) {
      memSize = 4259840;
    } else if (memory.getRAMType() == 0 && memSize > 65536) {
      memSize = 65536;
    } else if (memory.getRAMType() == 1 && memSize > 131072) {
      memSize = 131072;
    } else if (memory.getRAMType() == 15 && memSize > 327680) {
      memSize = 327680;
    } else if (memory.getRAMType() == 255 && memSize > 589824) {
      memSize = 589824;
    } 
    byte[] mem = memory.getMemory();
    System.arraycopy(data, 256, mem, 0, memSize);
  }
  
  private void SNA_Play(String name, byte[] data) {
    this.z80.setAF(getWord(data, 17));
    this.z80.setBC(getWord(data, 19));
    this.z80.setDE(getWord(data, 21));
    this.z80.setHL(getWord(data, 23));
    this.z80.setR(data[25]);
    this.z80.setI(data[26]);
    this.z80.setIFF1((data[27] != 0));
    this.z80.setIFF2((data[28] != 0));
    this.z80.setIX(getWord(data, 29));
    this.z80.setIY(getWord(data, 31));
    this.z80.setSP(getWord(data, 33));
    this.z80.setPC(getWord(data, 35));
    this.z80.setIM(data[37]);
    this.z80.setAF1(getWord(data, 38));
    this.z80.setBC1(getWord(data, 40));
    this.z80.setDE1(getWord(data, 42));
    this.z80.setHL1(getWord(data, 44));
    this.gateArray.setSelectedInk(data[46]);
    int i;
    for (i = 0; i < 17; i++)
      GateArray.setInk(i, data[47 + i]); 
    this.gateArray.setModeAndROMEnable(memory, data[64]);
    memory.setMemoryRAMBank(data[65]);
    this.crtc.setSelectedRegister(data[66]);
    i = 0;
    for (; i < 18; i++)
      this.crtc.setRegister(i, data[67 + i]); 
    memory.setUpperROM(data[85]);
    this.ppi.setControl(data[89] & 0xFF | 0x80);
    this.ppi.setOutputValue(0, data[86] & 0xFF);
    this.ppi.setOutputValue(1, data[87] & 0xFF);
    int portC = data[88] & 0xFF;
    this.ppi.setOutputValue(2, portC);
    this.psg.setBDIR_BC2_BC1(this.PSG_VALUES[portC >> 6], this.ppi.readOutput(0));
    this.psg.setSelectedRegister(data[90]);
    int j = 0;
    for (; j < 14; j++)
      this.psg.setRegister(j, data[91 + j] & 0xFF); 
    int crt = data[112];
    if (crt > 0)
      this.crtc.setCRTC(data[112] - 1); 
    int memSize = getWord(data, 107) * 1024;
    this.SNAsize = 256 + memSize;
    if (memory.getRAMType() == 0 && memSize > 65536) {
      memSize = 65536;
    } else if (memory.getRAMType() == 1 && memSize > 131072) {
      memSize = 131072;
    } else if (memory.getRAMType() == 15 && memSize > 327680) {
      memSize = 327680;
    } else if (memory.getRAMType() == 255 && memSize > 589824) {
      memSize = 589824;
    } 
    byte[] mem = memory.getMemory();
    System.arraycopy(data, 256, mem, 0, memSize);
    System.arraycopy(data, 256, GateArray.screenmemory, 0, 65536);
  }
  
  public static boolean playSNP = false;
  
  private byte[] keys;
  
  private byte[] snpbyte;
  
  private String snpname;
  
  private int keyOffset;
  
  private int FrameCount;
  
  private int numKeys;
  
  private int time;
  
  private boolean reloadsnp;
  
  private byte[] keybytes;
  
  private BufferedOutputStream snpout;
  
  private int snpcounter;
  
  private void SNP_Load(String name, byte[] data, boolean showinfo) {
    System.out.println("Recorded data file opened");
    this.reloadsnp = false;
    this.snpname = name;
    this.snpbyte = data;
    int memSize = getWord(data, 107) * 1024;
    this.SNAsize = 256 + memSize;
    byte[] s = new byte[this.SNAsize];
    System.arraycopy(data, 0, s, 0, this.SNAsize);
    int keylength = data.length - this.SNAsize;
    this.keys = new byte[keylength];
    System.arraycopy(data, this.SNAsize, this.keys, 0, keylength);
    byte[] info = new byte[32];
    System.arraycopy(data, 224, info, 0, 32);
    String inf = "";
    int p = 0;
    try {
      while (info[p] != 0) {
        inf = inf + (char)info[p];
        p++;
      } 
    } catch (Exception exception) {}
    if (showinfo)
      JOptionPane.showMessageDialog(new Frame(), "Recorded with " + inf); 
    memory.reset();
    this.z80.reset();
    SNA_Load("buffer", s);
    playSNP = true;
    this.keyOffset = 0;
    this.FrameCount = 0;
    GetFrameCount();
    this.keytime = 0;
  }
  
  private void SetKeys() {
    this.numKeys = this.keys[this.keyOffset++] & 0xFF;
    while (this.numKeys > 0) {
      this.numKeys--;
      getKeyboard().processKey(this.keys[this.keyOffset++]);
    } 
  }
  
  private void UpdateSNP(boolean loop) {
    if (playSNP) {
      this.FrameCount--;
      if (this.FrameCount <= 0)
        try {
          SetKeys();
          GetFrameCount();
        } catch (Exception e) {
          for (int i = 0; i <= 127; i++)
            getKeyboard().ReleaseKey((byte)i); 
          playSNP = false;
          if (loop)
            this.reloadsnp = true; 
        }  
    } else if (StoreSNP) {
      StoreSNP();
    } 
  }
  
  private void GetFrameCount() {
    if ((this.time = this.keys[this.keyOffset++] & 0xFF) != 0) {
      this.FrameCount = this.time;
      return;
    } 
    this.FrameCount = getDWord(this.keys, this.keyOffset);
    this.keyOffset += 4;
  }
  
  public static boolean StoreSNP = false;
  
  byte[] buffSNA;
  
  public static boolean getbuff;
  
  private final File snapfile;
  
  private boolean restorebuf;
  
  private boolean storebuf;
  
  public boolean playcity;
  
  boolean snap;
  
  public void SNP_Save() {
    this.snpCapture = true;
  }
  
  private void SNP_Capture() {
    try {
      if (this.snpout != null)
        return; 
      byte[] sna = getSNA(512);
      this.snpcounter = 0;
      String catcher = SNP_EYECATCHER;
      int i = 0;
      for (; i < 19; i++)
        catcher = catcher + Character.MIN_VALUE; 
      System.arraycopy("MV - SNP".getBytes("UTF-8"), 0, sna, 0, "MV - SNP".length());
      System.arraycopy(catcher.getBytes("UTF-8"), 0, sna, 224, catcher.length());
      if (this.snpout == null) {
        File snpfile = new File("output.snp");
        String add = "_";
        int ad = 0;
        while (snpfile.exists())
          snpfile = new File("output" + add + ad++ + ".snp"); 
        this.snpout = new BufferedOutputStream(new FileOutputStream(snpfile));
        this.snpout.write(sna);
        StoreSNP = true;
        this.keytime = 0;
        getKeyboard().initBytes();
      } 
    } catch (IOException iox) {
      iox.printStackTrace();
    } 
  }
  
  public void SNP_Stop() {
    if (this.snpout != null)
      try {
        this.snpout.close();
      } catch (IOException iOException) {} 
    this.snpout = null;
    StoreSNP = false;
  }
  
  private void StoreSNP() {
    try {
      this.snpcounter++;
      this.keybytes = getKeyboard().getKeyNum();
      if (this.keybytes.length > 0) {
        if (this.snpcounter < 256) {
          this.snpout.write(this.snpcounter);
        } else {
          this.snpout.write(0);
          byte[] leng = new byte[4];
          putDWord(leng, 0, this.snpcounter);
          this.snpout.write(leng);
        } 
        this.snpout.write(this.keybytes.length);
        this.snpout.write(this.keybytes);
        this.snpcounter = 0;
      } 
    } catch (IOException iOException) {}
  }
  
  public void SNK_Load(String name, byte[] data) {
    Switches.booter = 1;
    this.totalKeyNumber = getDWord(data, 20);
    int f1l = getDWord(data, 40);
    int f2l = getDWord(data, 50);
    int rl = getDWord(data, 60);
    byte[] ram = new byte[rl];
    byte[] f1 = new byte[f1l];
    byte[] f2 = new byte[f2l];
    System.arraycopy(data, 256 + this.totalKeyNumber, f1, 0, f1l);
    System.arraycopy(data, 256 + this.totalKeyNumber + f1l, f2, 0, f2l);
    System.arraycopy(data, 256 + this.totalKeyNumber + f1l + f2l, ram, 0, rl);
    System.arraycopy(data, 256, this.keyStroke, 0, this.totalKeyNumber);
    String flop1 = "";
    String flop2 = "";
    int i;
    for (i = 0; i < f1.length; i++)
      flop1 = flop1 + (char)f1[i]; 
    for (i = 0; i < f2.length; i++)
      flop2 = flop2 + (char)f2[i]; 
    Settings.set("file.drive" + Integer.toString(0), flop1);
    Settings.set("file.drive" + Integer.toString(1), flop2);
    updateDrive(0);
    updateDrive(1);
    SNA_Load("buffer", ram);
    System.out.println("Length is " + this.totalKeyNumber);
    playKeys();
  }
  
  public void restoreState() {
    try {
      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(this.snapfile));
      this.buffSNA = new byte[bis.available()];
      bis.read(this.buffSNA);
      bis.close();
      this.restorebuf = true;
    } catch (Exception exception) {}
  }
  
  public void storeState() {
    this.storebuf = true;
  }
  
  protected void stoSNA() {
    this.buffSNA = getSNA(512);
    try {
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(this.snapfile));
      bos.write(this.buffSNA);
      bos.close();
    } catch (Exception exception) {}
  }
  
  public void SNK_Save() {
    SNK_FLOPPY_A = Settings.get("file.drive" + Integer.toString(0), "empty");
    SNK_FLOPPY_B = Settings.get("file.drive" + Integer.toString(1), "empty");
    FileDialog filedia = new FileDialog(new Frame(), "Save SNK Snapshot File", 1);
    if (Switches.uncompressed) {
      filedia.setFile("*.snk");
    } else {
      filedia.setFile("*.szk");
    } 
    filedia.setVisible(true);
    String filename = filedia.getFile();
    if (filename != null) {
      filename = filedia.getDirectory() + filedia.getFile();
      String savename = filename;
      File file = new File(savename);
      try {
        byte[] ram = this.buffSNA;
        byte[] flopa = SNK_FLOPPY_A.getBytes("UTF-8");
        byte[] flopb = SNK_FLOPPY_B.getBytes("UTF-8");
        int len = 0;
        if (ram != null)
          len += ram.length; 
        if (flopa != null)
          len += flopa.length; 
        if (flopb != null)
          len += flopb.length; 
        byte[] data = new byte[256 + this.totalKeyNumber + len];
        try {
          System.arraycopy("MH - SNK CAPTURE".getBytes("UTF-8"), 0, data, 0, "MH - SNK CAPTURE".length());
        } catch (Exception exception) {}
        try {
          System.arraycopy("JavaCPC Keyboard   record file  ".getBytes("UTF-8"), 0, data, 224, "JavaCPC Keyboard   record file  ".length());
        } catch (Exception exception) {}
        System.out.println("Length is " + this.totalKeyNumber);
        putDWord(data, 40, flopa.length);
        putDWord(data, 50, flopb.length);
        putDWord(data, 60, ram.length);
        putDWord(data, 20, this.totalKeyNumber);
        System.arraycopy(this.keyStroke, 0, data, 256, this.totalKeyNumber);
        System.arraycopy(flopa, 0, data, 256 + this.totalKeyNumber, flopa.length);
        System.arraycopy(flopb, 0, data, 256 + this.totalKeyNumber + flopa.length, flopb.length);
        System.arraycopy(ram, 0, data, 256 + this.totalKeyNumber + flopa.length + flopb.length, ram.length);
        try {
          Thread.sleep(200L);
        } catch (Exception exception) {}
        if (Switches.uncompressed) {
          try {
            savename = "";
            if (!file.toString().toLowerCase().endsWith(".snk"))
              savename = savename + ".snk"; 
            BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file + savename));
            bos.write(data);
            bos.close();
          } catch (IOException iox) {
            System.out.println("can't write to file ");
          } 
        } else {
          savename = "";
          if (!file.toString().toLowerCase().endsWith(".szk"))
            savename = savename + ".szk"; 
          File gzip_output = new File(file + savename);
          try {
            FileOutputStream out = new FileOutputStream(gzip_output);
            GZIPOutputStream gzip_out_stream = new GZIPOutputStream(new BufferedOutputStream(out));
            gzip_out_stream.write(data, 0, data.length);
            gzip_out_stream.close();
          } catch (IOException iOException) {}
        } 
      } catch (Exception e) {
        e.printStackTrace();
        System.exit(0);
      } 
    } 
  }
  
  public byte[] getSNA(int sizemem) {
    if (memory.getRAMType() == 0 && sizemem > 64)
      sizemem = 64; 
    if (memory.getRAMType() == 1 && sizemem > 128)
      sizemem = 128; 
    if (memory.getRAMType() == 15 && sizemem > 256)
      sizemem = 256; 
    if (memory.getRAMType() == 255 && sizemem > 512)
      sizemem = 512; 
    int memSize = 65536;
    if (sizemem == 128)
      memSize = 131072; 
    if (sizemem == 256)
      memSize = 327680; 
    if (sizemem == 512)
      memSize = 589824; 
    byte[] data = new byte[256 + memSize];
    try {
      System.arraycopy("MV - SNA".getBytes("UTF-8"), 0, data, 0, "MV - SNA".length());
    } catch (IOException iOException) {}
    String snasize = "64k Snapshot    ";
    if (sizemem == 64)
      snasize = "64k Snapshot    "; 
    if (sizemem == 128)
      snasize = "128k Snapshot   "; 
    if (sizemem == 256)
      snasize = "320k Snapshot   "; 
    if (sizemem == 512)
      snasize = "576k Snapshot   "; 
    if (sizemem == 4096)
      snasize = "4MB Snapshot    "; 
    try {
      SNA_EYECATCHER += snasize;
      System.arraycopy(SNA_EYECATCHER.getBytes("UTF-8"), 0, data, 224, SNA_EYECATCHER.length());
    } catch (IOException iOException) {}
    data[16] = 1;
    putWord(data, 17, this.z80.getAF());
    putWord(data, 19, this.z80.getBC());
    putWord(data, 21, this.z80.getDE());
    putWord(data, 23, this.z80.getHL());
    data[25] = (byte)this.z80.getR();
    data[26] = (byte)this.z80.getI();
    data[27] = (byte)this.z80.getIFF1();
    data[28] = (byte)this.z80.getIFF2();
    putWord(data, 29, this.z80.getIX());
    putWord(data, 31, this.z80.getIY());
    putWord(data, 33, this.z80.getSP());
    putWord(data, 35, this.z80.getPC());
    data[37] = (byte)this.z80.getIM();
    putWord(data, 38, this.z80.getAF1());
    putWord(data, 40, this.z80.getBC1());
    putWord(data, 42, this.z80.getDE1());
    putWord(data, 44, this.z80.getHL1());
    data[46] = (byte)this.gateArray.getSelectedInk();
    int i;
    for (i = 0; i < 17; i++) {
      data[47 + i] = (byte)GateArray.getInks(i);
      System.out.print((byte)GateArray.getInks(i) + ", ");
    } 
    System.out.println();
    data[66] = (byte)this.crtc.getSelectedRegister();
    i = 0;
    for (; i < 18; i++)
      data[67 + i] = (byte)this.crtc.getReg(i); 
    data[112] = (byte)(this.crtc.getCRTC() + 1);
    data[89] = (byte)this.ppi.getPORT_CONTROL();
    data[86] = (byte)this.ppi.getPORT_A();
    data[87] = (byte)this.ppi.getPORT_B();
    data[88] = (byte)this.ppi.getPORT_C();
    data[90] = (byte)this.psg.getSelectedRegister();
    for (i = 0; i < 16; i++)
      data[91 + i] = (byte)this.psg.getRegister(i); 
    data[64] = (byte)this.gateArray.getMode();
    data[65] = (byte)this.Pal16L8.getRAMBank();
    data[85] = (byte)memory.getUpperROM();
    putWord(data, 107, 64);
    if (sizemem == 128)
      putWord(data, 107, 128); 
    if (sizemem == 256)
      putWord(data, 107, 320); 
    if (sizemem == 512)
      putWord(data, 107, 576); 
    data[109] = 2;
    byte[] mem = memory.getMemory();
    System.arraycopy(mem, 0, data, 256, memSize);
    System.arraycopy(GateArray.screenmemory, 0, data, 256, 65536);
    return data;
  }
  
  public void SNA_Save(int sizemem) {
    if (memory.getRAMType() == 0 && sizemem > 64)
      sizemem = 64; 
    if (memory.getRAMType() == 1 && sizemem > 128)
      sizemem = 128; 
    if (memory.getRAMType() == 15 && sizemem > 256)
      sizemem = 256; 
    if (memory.getRAMType() == 255 && sizemem > 512)
      sizemem = 512; 
    if (memory.has4MB)
      sizemem = 4096; 
    this.snap = true;
    Hold();
    int memSize = 65536;
    if (sizemem == 128)
      memSize = 131072; 
    if (sizemem == 256)
      memSize = 327680; 
    if (sizemem == 512)
      memSize = 589824; 
    if (sizemem == 4096)
      memSize = 4259840; 
    byte[] data = new byte[256 + memSize];
    try {
      System.arraycopy("MV - SNA".getBytes("UTF-8"), 0, data, 0, "MV - SNA".length());
    } catch (IOException iOException) {}
    String snasize = "64k Snapshot    ";
    if (sizemem == 64)
      snasize = "64k Snapshot    "; 
    if (sizemem == 128)
      snasize = "128k Snapshot   "; 
    if (sizemem == 256)
      snasize = "320k Snapshot   "; 
    if (sizemem == 512)
      snasize = "576k Snapshot   "; 
    if (sizemem == 4096)
      snasize = "4MB Snapshot    "; 
    try {
      SNA_EYECATCHER += snasize;
      System.arraycopy(SNA_EYECATCHER.getBytes("UTF-8"), 0, data, 224, SNA_EYECATCHER.length());
    } catch (IOException iOException) {}
    data[16] = 1;
    putWord(data, 17, this.z80.getAF());
    putWord(data, 19, this.z80.getBC());
    putWord(data, 21, this.z80.getDE());
    putWord(data, 23, this.z80.getHL());
    data[25] = (byte)this.z80.getR();
    data[26] = (byte)this.z80.getI();
    data[27] = (byte)this.z80.getIFF1();
    data[28] = (byte)this.z80.getIFF2();
    putWord(data, 29, this.z80.getIX());
    putWord(data, 31, this.z80.getIY());
    putWord(data, 33, this.z80.getSP());
    putWord(data, 35, this.z80.getPC());
    data[37] = (byte)this.z80.getIM();
    putWord(data, 38, this.z80.getAF1());
    putWord(data, 40, this.z80.getBC1());
    putWord(data, 42, this.z80.getDE1());
    putWord(data, 44, this.z80.getHL1());
    data[46] = (byte)this.gateArray.getSelectedInk();
    System.out.print("CPC Palette is: ");
    int i = 0;
    for (; i < 17; i++) {
      data[47 + i] = (byte)GateArray.getInks(i);
      System.out.print((byte)GateArray.getInks(i) + ", ");
    } 
    System.out.println();
    data[66] = (byte)this.crtc.getSelectedRegister();
    i = 0;
    for (; i < 18; i++)
      data[67 + i] = (byte)this.crtc.getReg(i); 
    data[112] = (byte)(this.crtc.getCRTC() + 1);
    data[89] = (byte)this.ppi.getPORT_CONTROL();
    data[86] = (byte)this.ppi.getPORT_A();
    data[87] = (byte)this.ppi.getPORT_B();
    data[88] = (byte)this.ppi.getPORT_C();
    data[90] = (byte)this.psg.getSelectedRegister();
    for (i = 0; i < 16; i++)
      data[91 + i] = (byte)this.psg.getRegister(i); 
    data[64] = (byte)this.gateArray.getMode();
    data[65] = (byte)this.Pal16L8.getRAMBank();
    data[85] = (byte)memory.getUpperROM();
    putWord(data, 107, 64);
    if (sizemem == 128)
      putWord(data, 107, 128); 
    if (sizemem == 256)
      putWord(data, 107, 320); 
    if (sizemem == 512)
      putWord(data, 107, 576); 
    if (sizemem == 4096)
      putWord(data, 107, 4160); 
    data[109] = 2;
    if (this.playcity) {
      data[185] = (byte)this.z84c30.getCounter();
      data[184] = (byte)(this.z84c30.getCycle() ? 0 : 1);
      data[186] = (byte)this.psg1.getSelectedRegister();
      for (i = 0; i < 16; i++)
        data[187 + i] = (byte)this.psg1.getRegister(i); 
      data[206] = (byte)this.psg1.getSelectedRegister();
      for (i = 0; i < 16; i++)
        data[207 + i] = (byte)this.psg2.getRegister(i); 
    } 
    byte[] mem = memory.getMemory();
    System.arraycopy(mem, 0, data, 256, memSize);
    System.arraycopy(GateArray.screenmemory, 0, data, 256, 65536);
    FileDialog filedia = new FileDialog(new Frame(), "Save " + sizemem + "k Snapshot File", 1);
    if (Switches.uncompressed) {
      filedia.setFile("*.sna");
    } else {
      filedia.setFile("*.snz");
    } 
    filedia.setVisible(true);
    String filename = filedia.getFile();
    if (filename != null) {
      filename = filedia.getDirectory() + filedia.getFile();
      String savename = filename;
      File file = new File(savename);
      if (Switches.uncompressed) {
        try {
          savename = "";
          if (!file.toString().toLowerCase().endsWith(".sna"))
            savename = savename + ".sna"; 
          BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file + savename));
          bos.write(data);
          bos.close();
        } catch (IOException iox) {
          System.out.println("can't write to file ");
        } 
      } else {
        savename = "";
        if (!file.toString().toLowerCase().endsWith(".snz"))
          savename = savename + ".snz"; 
        File gzip_output = new File(file + savename);
        try {
          FileOutputStream out = new FileOutputStream(gzip_output);
          GZIPOutputStream gzip_out_stream = new GZIPOutputStream(new BufferedOutputStream(out));
          gzip_out_stream.write(data, 0, data.length);
          gzip_out_stream.close();
        } catch (IOException iOException) {}
      } 
    } 
    goOn();
    this.snap = false;
    filedia.dispose();
    reSync();
  }
  
  public void SNA_Save(int sizemem, String filename) {
    if (memory.getRAMType() == 0 && sizemem > 64)
      sizemem = 64; 
    if (memory.getRAMType() == 1 && sizemem > 128)
      sizemem = 128; 
    if (memory.getRAMType() == 15 && sizemem > 256)
      sizemem = 256; 
    if (memory.getRAMType() == 255 && sizemem > 512)
      sizemem = 512; 
    if (memory.has4MB)
      sizemem = 4096; 
    this.snap = true;
    Hold();
    int memSize = 65536;
    if (sizemem == 128)
      memSize = 131072; 
    if (sizemem == 256)
      memSize = 327680; 
    if (sizemem == 512)
      memSize = 589824; 
    if (sizemem == 4096)
      memSize = 4259840; 
    byte[] data = new byte[256 + memSize];
    try {
      System.arraycopy("MV - SNA".getBytes("UTF-8"), 0, data, 0, "MV - SNA".length());
    } catch (IOException iOException) {}
    String snasize = "64k Snapshot    ";
    if (sizemem == 64)
      snasize = "64k Snapshot    "; 
    if (sizemem == 128)
      snasize = "128k Snapshot   "; 
    if (sizemem == 256)
      snasize = "320k Snapshot   "; 
    if (sizemem == 512)
      snasize = "576k Snapshot   "; 
    if (sizemem == 4096)
      snasize = "4MB Snapshot    "; 
    try {
      SNA_EYECATCHER += snasize;
      System.arraycopy(SNA_EYECATCHER.getBytes("UTF-8"), 0, data, 224, SNA_EYECATCHER.length());
    } catch (IOException iOException) {}
    data[16] = 1;
    putWord(data, 17, this.z80.getAF());
    putWord(data, 19, this.z80.getBC());
    putWord(data, 21, this.z80.getDE());
    putWord(data, 23, this.z80.getHL());
    data[25] = (byte)this.z80.getR();
    data[26] = (byte)this.z80.getI();
    data[27] = (byte)this.z80.getIFF1();
    data[28] = (byte)this.z80.getIFF2();
    putWord(data, 29, this.z80.getIX());
    putWord(data, 31, this.z80.getIY());
    putWord(data, 33, this.z80.getSP());
    putWord(data, 35, this.z80.getPC());
    data[37] = (byte)this.z80.getIM();
    putWord(data, 38, this.z80.getAF1());
    putWord(data, 40, this.z80.getBC1());
    putWord(data, 42, this.z80.getDE1());
    putWord(data, 44, this.z80.getHL1());
    data[46] = (byte)this.gateArray.getSelectedInk();
    System.out.print("CPC Palette is: ");
    int i = 0;
    for (; i < 17; i++) {
      data[47 + i] = (byte)GateArray.getInks(i);
      System.out.print((byte)GateArray.getInks(i) + ", ");
    } 
    System.out.println();
    data[66] = (byte)this.crtc.getSelectedRegister();
    i = 0;
    for (; i < 18; i++)
      data[67 + i] = (byte)this.crtc.getReg(i); 
    data[112] = (byte)(this.crtc.getCRTC() + 1);
    data[89] = (byte)this.ppi.getPORT_CONTROL();
    data[86] = (byte)this.ppi.getPORT_A();
    data[87] = (byte)this.ppi.getPORT_B();
    data[88] = (byte)this.ppi.getPORT_C();
    data[90] = (byte)this.psg.getSelectedRegister();
    for (i = 0; i < 16; i++)
      data[91 + i] = (byte)this.psg.getRegister(i); 
    data[64] = (byte)this.gateArray.getMode();
    data[65] = (byte)this.Pal16L8.getRAMBank();
    data[85] = (byte)memory.getUpperROM();
    putWord(data, 107, 64);
    if (sizemem == 128)
      putWord(data, 107, 128); 
    if (sizemem == 256)
      putWord(data, 107, 320); 
    if (sizemem == 512)
      putWord(data, 107, 576); 
    if (sizemem == 4096)
      putWord(data, 107, 4160); 
    data[109] = 2;
    if (this.playcity) {
      data[185] = (byte)this.z84c30.getCounter();
      data[184] = (byte)(this.z84c30.getCycle() ? 0 : 1);
      data[186] = (byte)this.psg1.getSelectedRegister();
      for (i = 0; i < 16; i++)
        data[187 + i] = (byte)this.psg1.getRegister(i); 
      data[206] = (byte)this.psg1.getSelectedRegister();
      for (i = 0; i < 16; i++)
        data[207 + i] = (byte)this.psg2.getRegister(i); 
    } 
    byte[] mem = memory.getMemory();
    System.arraycopy(mem, 0, data, 256, memSize);
    System.arraycopy(GateArray.screenmemory, 0, data, 256, 65536);
    if (filename != null) {
      String savename = filename;
      File file = new File(savename);
      if (Switches.uncompressed) {
        try {
          savename = "";
          if (!file.toString().toLowerCase().endsWith(".sna"))
            savename = savename + ".sna"; 
          BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file + savename));
          bos.write(data);
          bos.close();
        } catch (IOException iox) {
          System.out.println("can't write to file ");
        } 
      } else {
        savename = "";
        if (!file.toString().toLowerCase().endsWith(".snz"))
          savename = savename + ".snz"; 
        File gzip_output = new File(file + savename);
        try {
          FileOutputStream out = new FileOutputStream(gzip_output);
          GZIPOutputStream gzip_out_stream = new GZIPOutputStream(new BufferedOutputStream(out));
          gzip_out_stream.write(data, 0, data.length);
          gzip_out_stream.close();
        } catch (IOException iOException) {}
      } 
    } 
    goOn();
    this.snap = false;
    reSync();
  }
  
  public int getPPI_A() {
    return this.ppi.getPORT_A();
  }
  
  public int getPPI_B() {
    return this.ppi.getPORT_B();
  }
  
  public int getPPI_C() {
    return this.ppi.getPORT_C();
  }
  
  public int getPPI_Control() {
    return this.ppi.getPORT_CONTROL();
  }
  
  public void tape_WAV_save() {
    if (tapesample == null || tapesample.length < 1000)
      return; 
    if (recordcount >= 100) {
      FileDialog filedia = new FileDialog(new Frame(), "Export JavaCPC tape file...", 1);
      if (Switches.uncompressed) {
        if (TapeDeck.ascdt.isSelected() && TapeDeck.ascdt.isVisible()) {
          filedia.setFile("*.cdt");
        } else {
          filedia.setFile("*.wav");
        } 
      } else {
        filedia.setFile("*.taz");
      } 
      filedia.setVisible(true);
      String filename = filedia.getDirectory() + filedia.getFile();
      if (filename != null) {
        tape_WAV_save(filename);
        TapeDeck.tapeChanged = false;
      } 
    } 
  }
  
  public void CDT2WAV() {
    FileDialog filedia = new FileDialog(new Frame(), "Open CDT to convert...", 0);
    filedia.setFile("*.cdt; *.tzx; *.zip");
    filedia.setVisible(true);
    String filename = filedia.getDirectory() + filedia.getFile();
    if (filedia.getFile() != null)
      CDT2WAV(filename); 
  }
  
  public void tape_load() {
    FileDialog filedia = new FileDialog(new Frame(), "Open Tape image...", 0);
    filedia.setFile("*.cdt; *.tzx; *.wav; *.csw; *.mp3; *.zip");
    filedia.setVisible(true);
    String filename = filedia.getDirectory() + filedia.getFile();
    if (filedia.getFile() != null) {
      setInfo(filename, true);
      try {
        loadFile(0, filename);
        Settings.set("file.tape", filename);
        Settings.setBoolean("loadtape", true);
        TapeDeck.tapeChanged = false;
        this.TapeDrive.buildTapeBlocks();
      } catch (Exception exception) {}
    } 
  }
  
  public void setInfo(String name, boolean store) {
    int cutter = 0;
    int i = 0;
    for (; i < name.length(); i++) {
      if (name.charAt(i) == '/' || name.charAt(i) == '\\')
        cutter = i + 1; 
    } 
    name = name.substring(cutter);
    name = name.replaceAll("%20", " ");
    this.TapeDrive.setName(name);
    name = name.replaceAll("_", " ");
    this.TapeDrive.setInfo(name.substring(0, name.length() - 4), store);
  }
  
  public void CDT2WAV(String name) {
    try {
      byte[] data = getFile(name);
      CDT_Load(name, data);
      tape_WAV_save();
    } catch (Exception exception) {}
  }
  
  public static boolean recordFull = true;
  
  public void tape_WAV_save(String filename) {
    if (tapesample.length < 1000)
      return; 
    if (fromCapture) {
      fromCapture = false;
      Switches.khz44 = true;
      Switches.khz11 = false;
      tape_stereo = true;
      bitrate = 8;
    } 
    if (Switches.uncompressed) {
      String cdt_name = filename;
      if (!cdt_name.toUpperCase().endsWith(".CDT")) {
        if (cdt_name.toLowerCase().endsWith(".wav"))
          cdt_name = cdt_name.substring(0, cdt_name.length() - 4); 
        cdt_name = cdt_name + ".cdt";
      } 
      if (!filename.toUpperCase().endsWith(".WAV"))
        filename = filename + ".wav"; 
      try {
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filename));
        if (!this.WAV_HEADER.equals((new String(tapesample, 0, this.WAV_HEADER.length())).toUpperCase())) {
          int lastSize = recordcount;
          if (recordFull)
            recordcount = tapesample.length; 
          if (Switches.khz44) {
            if (tape_stereo) {
              this.WAV_HEADER_44KHz[22] = 2;
              this.WAV_HEADER_44KHz[32] = 2;
              putLong(this.WAV_HEADER_44KHz, 28, 88200);
            } 
            putLong(this.WAV_HEADER_44KHz, 40, recordcount);
            putLong(this.WAV_HEADER_44KHz, 4, 36 + recordcount);
            for (int j = 0; j < 44; j++)
              bos.write((byte)this.WAV_HEADER_44KHz[j]); 
          } 
          if (Switches.khz11) {
            putLong(this.WAV_HEADER_11KHz, 40, recordcount);
            putLong(this.WAV_HEADER_11KHz, 4, 36 + recordcount);
            for (int j = 0; j < 44; j++)
              bos.write((byte)this.WAV_HEADER_11KHz[j]); 
          } 
          if (!Switches.khz11 && !Switches.khz44) {
            putLong(this.WAV_HEADER_22KHz, 40, recordcount);
            putLong(this.WAV_HEADER_22KHz, 4, 36 + recordcount);
            for (int j = 0; j < 44; j++)
              bos.write((byte)this.WAV_HEADER_22KHz[j]); 
          } 
          for (int i = 0; i < recordcount; i++)
            bos.write(tapesample[i]); 
          recordcount = lastSize;
        } else {
          bos.write(tapesample);
        } 
        bos.close();
        if (TapeDeck.ascdt.isSelected() && TapeDeck.ascdt.isVisible()) {
          samp2cdt.SAMP2CDT(filename, cdt_name);
        } else {
          cdt_name = filename;
        } 
      } catch (IOException iox) {
        System.out.println("can't write to file ");
      } 
      try {
        loadFile(0, cdt_name);
        if (!cdt_name.toLowerCase().contains("buffer.wav"))
          setInfo(cdt_name, true); 
        Settings.set("file.tape", cdt_name);
        Settings.setBoolean("loadtape", true);
      } catch (Exception exception) {}
    } else {
      String savename = "";
      if (!filename.toLowerCase().endsWith(".taz"))
        savename = savename + ".taz"; 
      System.out.println("Saving to " + filename);
      File gzip_output = new File(filename + savename);
      try {
        FileOutputStream out = new FileOutputStream(gzip_output);
        GZIPOutputStream gzip_out_stream = new GZIPOutputStream(new BufferedOutputStream(out));
        if (!this.WAV_HEADER.equals((new String(tapesample, 0, this.WAV_HEADER.length())).toUpperCase())) {
          if (Switches.khz44) {
            putLong(this.WAV_HEADER_44KHz, 40, recordcount);
            int j = 0;
            for (; j < 44; j++)
              gzip_out_stream.write((byte)this.WAV_HEADER_44KHz[j]); 
          } 
          if (Switches.khz11) {
            putLong(this.WAV_HEADER_11KHz, 40, recordcount);
            int j = 0;
            for (; j < 44; j++)
              gzip_out_stream.write((byte)this.WAV_HEADER_11KHz[j]); 
          } 
          if (!Switches.khz11 && !Switches.khz44) {
            putLong(this.WAV_HEADER_22KHz, 40, recordcount);
            int j = 0;
            for (; j < 44; j++)
              gzip_out_stream.write((byte)this.WAV_HEADER_22KHz[j]); 
          } 
          int i = 0;
          for (; i < recordcount; i++)
            gzip_out_stream.write(tapesample[i]); 
        } else {
          gzip_out_stream.write(tapesample);
        } 
        gzip_out_stream.close();
      } catch (IOException iOException) {}
    } 
  }
  
  public void loadFile(byte[] data, int start) {
    if ("MV - SNA".equals((new String(data, 0, "MV - SNA".length())).toUpperCase())) {
      SNA_Load(this.name, data);
      return;
    } 
    int pos = 0;
    int filetype = 2;
    int BasicEnd = 0;
    this;
    if (CheckAMSDOS(data)) {
      if (start == 0) {
        start = getWord(data, 21);
        int filelength = getWord(data, 24);
        BasicEnd = start + filelength;
        filetype = data[18];
      } 
      pos = 128;
    } 
    for (int i = pos; i < data.length; i++) {
      if (start < 65536)
        POKE(start++, data[i]); 
    } 
    if (filetype == 0) {
      if (Switches.ROM.equals("CPC6128"))
        importBasic1_1(BasicEnd); 
      if (Switches.ROM.equals("CPC664"))
        importBasic664(BasicEnd); 
      if (Switches.ROM.equals("CPC464"))
        importBasic1_0(BasicEnd); 
    } 
  }
  
  public void BIN_Load() {
    FileDialog filedia = new FileDialog(new Frame(), "Import CPC file...", 0);
    filedia.setVisible(true);
    String filename = filedia.getFile();
    if (filename != null) {
      filename = filedia.getDirectory() + filedia.getFile();
      BIN_Load(filename, getFile(filename));
    } 
  }
  
  public void BIN_Load(String name, byte[] data) {
    Switches.booter = 1;
    stop();
    int header = 0;
    int start = 0;
    int execaddress = 0;
    int BasicEnd = 0;
    String Sexc = "";
    byte filetype = 0;
    if (CheckAMSDOS(data)) {
      int startaddress = getWord(data, 21);
      execaddress = getWord(data, 26);
      int filelength = getWord(data, 24);
      filetype = data[18];
      String ftype = "";
      if (filetype == 0)
        ftype = "BASIC"; 
      if (filetype == 1)
        ftype = "BASIC (protected)"; 
      if (filetype == 2)
        ftype = "BINARY"; 
      if (filetype == 3)
        ftype = "BINARY (protected)"; 
      if (filetype == 4)
        ftype = "IMAGE"; 
      if (filetype == 5)
        ftype = "IMAGE (protected)"; 
      if (filetype == 6)
        ftype = "ASCII"; 
      if (filetype == 7)
        ftype = "ASCII (protected)"; 
      start = startaddress;
      String Sadr = Util.hex(start).substring(4);
      String Slen = Util.hex(filelength).substring(4);
      Sexc = Util.hex(execaddress).substring(4);
      BasicEnd = start + filelength;
      Object[] oheader = { "AMSDOS header found...\n\n&" + Sadr + " - Load address\n&" + Slen + " - File length\n&" + Sexc + " - Exec. address\n\nFiletype is: " + ftype + "\n\nEnter load address:\n(Hexadecimal)" };
      String CNG_CHECK = new String(data, 140, 12);
      this.CNG = false;
      if (CNG_CHECK.equals(this.CNG_HEADER))
        this.CNG = true; 
      CNG_CHECK = null;
      this.CNGBIN = false;
      CNG_CHECK = new String(data, 128, 12);
      if (CNG_CHECK.equals(this.CNG_HEADER)) {
        this.CNG = true;
        this.CNGBIN = true;
      } 
      String selectedHeader = null;
      String bak = null;
      if (filetype == 0)
        selectedHeader = "170"; 
      if (filetype >= 1 && !this.CNG)
        selectedHeader = JOptionPane.showInputDialog(new Frame(), oheader, Sadr); 
      if (selectedHeader == null) {
        start();
        return;
      } 
      if (!selectedHeader.equals(""))
        try {
          start = Util.hexValue(selectedHeader);
          if (start != Util.hexValue(Sadr))
            execaddress = 0; 
        } catch (Exception iox) {
          start();
          return;
        }  
      header = 128;
    } else {
      String result, CNG_CHECK = new String(data, 12, 12);
      this.CNG = false;
      if (CNG_CHECK.equals(this.CNG_HEADER))
        this.CNG = true; 
      this.CNGBIN = false;
      CNG_CHECK = null;
      CNG_CHECK = new String(data, 128, 12);
      if (CNG_CHECK.equals(this.CNG_HEADER)) {
        this.CNG = true;
        this.CNGBIN = true;
      } 
      if (!this.CNG) {
        result = JOptionPane.showInputDialog(new Frame(), "No AMSDOS header found...\n\nPlease enter start address:\n(Hexadecimal)\n");
      } else {
        result = "100";
      } 
      if (result == null) {
        start();
        return;
      } 
      if (!result.equals("")) {
        try {
          start = Util.hexValue(result);
        } catch (Exception iox) {
          start();
          return;
        } 
      } else {
        start();
        return;
      } 
      header = 0;
    } 
    System.out.println(start);
    int length = data.length;
    if (CheckAMSDOS(data))
      length -= 128; 
    int chb = memory.getRAMBank();
    if (start + length < 32769 && start > 16383) {
      Object[] rbanks = { 
          "C0", "C4", "C5", "C6", "C7", "CC", "CD", "CE", "CF", "D4", 
          "D5", "D6", "D7", "DC", "DD", "DE", "DF", "E4", "E5", "E6", 
          "E7", "EC", "ED", "EE", "EF", "F4", "F5", "F6", "F7", "FC", 
          "FD", "FE", "FF" };
      String s = (String)JOptionPane.showInputDialog(new JFrame(), "Please choose ram bank:", "Select", 3, null, rbanks, "C0");
      System.out.println(s);
      if (s != null)
        try {
          memory.setForcedRAMBank(Util.hexValue(s));
        } catch (Exception exception) {} 
    } 
    byte[] mem = memory.getMemory();
    int memSize = data.length;
    if (start + memSize - header >= 65537) {
      JOptionPane.showMessageDialog(null, "An error occured during importing file:\nno or wrong start address entered...\n");
    } else {
      int addr = start;
      int i = header;
      for (; i < data.length; i++) {
        if (addr > 47103 && addr < 47360)
          firmwareErased = true; 
        POKE(addr++, data[i]);
      } 
      System.out.println("Firmware has been disabled: " + firmwareErased);
    } 
    if (CheckAMSDOS(data) && ((execaddress != 0 && !this.CNG) || (filetype == 0 && !this.CNG)))
      if (filetype == 2) {
        if (execaddress != 0 && filetype >= 2 && filetype <= 3) {
          int ok = JOptionPane.showConfirmDialog(new Frame(), "Execute binary?", "Please choose", 0);
          if (ok == 0) {
            launch = execaddress;
          } else {
            start();
            return;
          } 
        } 
      } else {
        if (Switches.ROM.equals("CPC6128"))
          importBasic1_1(BasicEnd); 
        if (Switches.ROM.equals("CPC664"))
          importBasic664(BasicEnd); 
        if (Switches.ROM.equals("CPC464"))
          importBasic1_0(BasicEnd); 
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Execute basic?\n(at your own risk)", "Please choose", 0);
        if (ok == 0) {
          executeBasic();
          start();
        } else {
          start();
          return;
        } 
      }  
    if (this.CNG) {
      if (!this.CNGBIN) {
        if (execaddress == 0)
          execaddress = 304; 
        if (execaddress == 368)
          execaddress = 416; 
      } else {
        execaddress = 288;
      } 
      runBinary(execaddress);
    } 
    memory.setForcedRAMBank(chb);
    start();
  }
  
  protected static boolean call = false;
  
  public static boolean firmwareErased = false;
  
  Baslist lister;
  
  public void runBinary(int address) {
    if (firmwareErased) {
      memory.setLowerEnabled(false);
      this.z80.setPC(address);
    } else {
      POKE(65528, 14);
      POKE(65529, 255);
      POKE(65530, 33);
      POKE(65531, address & 0xFF);
      POKE(65532, address / 256 & 0xFF);
      POKE(65533, 195);
      POKE(65534, 22);
      POKE(65535, 189);
      call = true;
    } 
    firmwareErased = false;
  }
  
  public Baslist getBasLister() {
    if (this.lister == null)
      this.lister = new Baslist(); 
    return this.lister;
  }
  
  public String getBasList() {
    if (this.lister == null)
      this.lister = new Baslist(); 
    int siz = GateArray.cpc.getBasSize1_1();
    if (Switches.ROM.equals("CPC464"))
      siz = GateArray.cpc.getBasSize1_0(); 
    int pos = 368;
    byte[] data = new byte[siz + 2];
    int d = 0;
    for (int i = pos; i < pos + siz; i++)
      data[d++] = (byte)memory.readWriteByte(i); 
    try {
      return this.lister.LIST(data);
    } catch (Exception e) {
      return "";
    } 
  }
  
  public int getBasSize1_0() {
    int a = PEEK(44675);
    int b = PEEK(44676);
    String c = "" + Util.hex((byte)b) + Util.hex((byte)a);
    try {
      return Util.hexValue(c) - 368;
    } catch (Exception exception) {
      return 0;
    } 
  }
  
  public int getBasSize1_1() {
    int a = PEEK(44646);
    int b = PEEK(44647);
    String c = "" + Util.hex((byte)b) + Util.hex((byte)a);
    try {
      return Util.hexValue(c) - 368;
    } catch (Exception exception) {
      return 0;
    } 
  }
  
  public void importBasic1_0(int BasicEnd) {
    POKE(44675, BasicEnd & 0xFF);
    POKE(44676, BasicEnd >> 8 & 0xFF);
    POKE(44677, BasicEnd & 0xFF);
    POKE(44678, BasicEnd >> 8 & 0xFF);
    POKE(44679, BasicEnd & 0xFF);
    POKE(44680, BasicEnd >> 8 & 0xFF);
  }
  
  public void importBasic1_1(int BasicEnd) {
    POKE(44646, BasicEnd & 0xFF);
    POKE(44647, BasicEnd >> 8 & 0xFF);
    POKE(44648, BasicEnd & 0xFF);
    POKE(44649, BasicEnd >> 8 & 0xFF);
    POKE(44650, BasicEnd & 0xFF);
    POKE(44651, BasicEnd >> 8 & 0xFF);
  }
  
  public void importBasic664(int BasicEnd) {
    POKE(44646, BasicEnd & 0xFF);
    POKE(44647, BasicEnd >> 8 & 0xFF);
    POKE(44648, BasicEnd & 0xFF);
    POKE(44649, BasicEnd >> 8 & 0xFF);
    POKE(44650, BasicEnd & 0xFF);
    POKE(44651, BasicEnd >> 8 & 0xFF);
  }
  
  public void executeBasic() {
    POKE(48896, 14);
    POKE(48897, 0);
    POKE(48898, 33);
    POKE(48899, 120);
    POKE(48900, 234);
    POKE(48901, 195);
    POKE(48902, 22);
    POKE(48903, 189);
    CALL(48896);
  }
  
  public static int launch = 90000;
  
  Cruncher cruncher;
  
  byte[] buff;
  
  String[] toPackfiles;
  
  public void CALL(int address) {
    this.z80.setPC(address);
  }
  
  public void POKE() {
    int address = 0;
    int value = 0;
    JTextField Address = new JTextField();
    JTextField Value = new JTextField();
    Object[] message = { "Address", Address, "Value", Value };
    JOptionPane pane = new JOptionPane(message, 2, 2);
    pane.createDialog(null, "Poke Memory").setVisible(true);
    if (Address.getText().equals("")) {
      JOptionPane.showMessageDialog(null, "nothing poked...");
      return;
    } 
    String Address1 = Address.getText();
    String Value1 = Value.getText();
    try {
      address = Util.hexValue(Address1);
      value = Util.hexValue(Value1);
      POKE(address, value);
    } catch (Exception iox) {
      JOptionPane.showMessageDialog(null, "nothing poked...");
      return;
    } 
  }
  
  public byte[] GetScreenLinear(int lines) {
    byte[] buffer = new byte[lines * 80];
    int address = 49152;
    int offset = 0;
    for (int i = 0; i < lines; i++) {
      for (int line = 0; line < 80; line++)
        buffer[offset++] = (byte)PEEK(address + line); 
      address += 2048;
      if (address > 65535)
        address -= 16304; 
    } 
    return buffer;
  }
  
  void testPack() {
    File a = new File("C:\\Brad Stallion\\SexOlympics\\SCR1.PAK");
    byte[] buffer = getScreenPacked();
    try {
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(a));
      bos.write(buffer);
      bos.close();
    } catch (Exception exception) {}
  }
  
  void testUnpack() {
    File a = new File("C:\\Brad Stallion\\SexOlympics\\SCR1.PAK");
    byte[] buffer = new byte[(int)a.length()];
    try {
      BufferedInputStream bin = new BufferedInputStream(new FileInputStream(a));
      bin.read(buffer);
      bin.close();
      writeScreenPacked(buffer);
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void writeScreenPacked(byte[] packed) {
    this;
    if (CheckAMSDOS(packed)) {
      byte[] buffer = new byte[packed.length - 128];
      System.arraycopy(packed, 128, buffer, 0, buffer.length);
      packed = new byte[buffer.length];
      System.arraycopy(buffer, 0, packed, 0, packed.length);
    } 
    byte[] data = this.cruncher.Depack(packed);
    for (int i = 0; i < data.length; i++)
      POKE(49152 + i, data[i] & 0xFF); 
  }
  
  public byte[] getScreenPacked() {
    byte[] screen = new byte[16384];
    for (int i = 0; i < screen.length; i++)
      screen[i] = (byte)PEEK(49152 + i); 
    return AddBINHeader(16384, this.cruncher.Pack(screen));
  }
  
  public byte[] getBlockScreen(byte[] data) {
    ByteArrayOutputStream buffout = new ByteArrayOutputStream();
    for (int i = 0; i < 8; i++) {
      int blockAddress = i * 2048;
      System.arraycopy(data, blockAddress, this.buff, 0, this.buff.length);
      byte[] tmp = this.cruncher.Pack(this.buff);
      buffout.write(tmp.length >> 8);
      buffout.write(tmp.length & 0xFF);
      for (int e = 0; e < tmp.length; e++)
        buffout.write(tmp[e] & 0xFF); 
    } 
    return buffout.toByteArray();
  }
  
  public void PackAll() {
    String path = "C:\\cpc\\PIX\\";
    for (int i = 0; i < this.toPackfiles.length; i += 2) {
      File fila = new File(path + this.toPackfiles[i]);
      File filb = new File(path + this.toPackfiles[i + 1]);
      String dest = this.toPackfiles[i];
      dest = dest.substring(0, dest.length() - 5);
      dest = dest + ".PAK";
      try {
        BufferedInputStream bin = new BufferedInputStream(new FileInputStream(fila));
        byte[] dataA = new byte[(int)fila.length()];
        bin.read(dataA);
        bin.close();
        bin = new BufferedInputStream(new FileInputStream(filb));
        byte[] dataB = new byte[(int)filb.length()];
        bin.read(dataB);
        bin.close();
        byte[] buffer = new byte[dataA.length - 128];
        System.arraycopy(dataA, 128, buffer, 0, buffer.length);
        dataA = new byte[buffer.length];
        System.arraycopy(buffer, 0, dataA, 0, dataA.length);
        buffer = new byte[dataB.length - 128];
        System.arraycopy(dataB, 128, buffer, 0, buffer.length);
        dataB = new byte[buffer.length];
        System.arraycopy(buffer, 0, dataB, 0, dataB.length);
        byte[] pal = new byte[3];
        pal[0] = dataA[6098];
        pal[1] = dataA[6099];
        pal[2] = dataA[6100];
        dataA = this.cruncher.Pack(dataA);
        dataB = this.cruncher.Pack(dataB);
        int pointer = dataA.length;
        byte[] result = new byte[3 + dataA.length + dataB.length];
        int offset = 0;
        System.arraycopy(pal, 0, result, offset, pal.length);
        offset += 3;
        System.arraycopy(dataA, 0, result, offset, dataA.length);
        offset += pointer;
        System.arraycopy(dataB, 0, result, offset, dataB.length);
        File pack = new File(path + dest);
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(pack));
        bos.write(AddBINHeader(16384, result));
        bos.close();
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
  }
  
  public byte[] GetScreenLinear(byte[] screendata, int lines) {
    byte[] buffer = new byte[lines * 80];
    int address = 0;
    int offset = 0;
    for (int i = 0; i < lines; i++) {
      for (int line = 0; line < 80; line++)
        buffer[offset++] = screendata[address + line]; 
      address += 2048;
      if (address > 16383)
        address -= 16304; 
    } 
    return buffer;
  }
  
  public byte[] AddBINHeader(int address, byte[] input) {
    if (this.exporter == null)
      this.exporter = new ImageExporter(); 
    input = this.exporter.makeHeader(2, address, input.length, 0, "PACKEDSCR", input);
    return input;
  }
  
  public static void POKE(int address, int value) {
    memory.writeByte(address & 0xFFFF, (byte)(value & 0xFF));
    if (memory.getRAMBank() == 192 || address < 16384 || address > 32768)
      GateArray.screenmemory[address] = (byte)(value & 0xFF); 
  }
  
  public void BIN_Export() {
    FileDialog filedia = new FileDialog(new Frame(), "Export CPC file...", 1);
    filedia.setFile("*.bin");
    filedia.setVisible(true);
    String filename = filedia.getFile();
    if (filename != null) {
      String ss = filename.toUpperCase();
      if (ss.endsWith(".BIN"))
        ss = ss.substring(0, ss.length() - 4); 
      ss = ss + "             ";
      String newname = "";
      int i = 0;
      for (; i < 8; i++) {
        if (ss.charAt(i) != '.' && ss.charAt(i) != '_' && ss.charAt(i) != '-') {
          newname = newname + ss.charAt(i);
        } else {
          newname = newname + " ";
        } 
      } 
      BIN_HEADER = newname + "BIN";
      filename = filedia.getDirectory() + filedia.getFile();
      if (!filename.toLowerCase().endsWith(".bin"))
        filename = filename + ".bin"; 
      int address = 0;
      int length = 0;
      int exec = 0;
      JTextField Address = new JTextField();
      JTextField Startaddress = new JTextField();
      JTextField Exec = new JTextField();
      JTextField InternalName = new JTextField();
      InternalName.setText(BIN_HEADER);
      InternalName.setEditable(false);
      Object[] message = { "Internal name", InternalName, "Start address", Address, "Length", Startaddress, "Exec. address (optional)", Exec, this.AmHeader };
      JOptionPane pane = new JOptionPane(message, 3, 2);
      pane.createDialog(null, "Export binary").setVisible(true);
      if (Address.getText().equals("") || Startaddress.getText().equals("")) {
        JOptionPane.showMessageDialog(null, "An error occurred...");
        return;
      } 
      String Address1 = Address.getText();
      String Startaddress1 = Startaddress.getText();
      String Exec1 = Exec.getText();
      String intname = "";
      if (InternalName != null)
        intname = InternalName.getText(); 
      if (intname.length() == 11)
        BIN_HEADER = intname; 
      if (Exec1 == null)
        Exec1 = "0"; 
      try {
        address = Util.hexValue(Address1);
        length = Util.hexValue(Startaddress1);
        exec = Util.hexValue(Exec1);
        BIN_Export(filename, address, length, exec, this.amheader);
      } catch (Exception iox) {
        JOptionPane.showMessageDialog(null, "An error occurred...");
        return;
      } 
    } 
  }
  
  public static void BIN_Export(String filename, int fileaddress, int filelength, int exaddress, boolean writeheader) {
    byte[] header = new byte[128];
    byte[] data = new byte[filelength];
    putWord(header, 21, fileaddress);
    putWord(header, 26, exaddress);
    putWord(header, 24, filelength);
    putWord(header, 64, filelength);
    header[18] = 2;
    byte[] mem = memory.getMemory();
    try {
      System.arraycopy(BIN_HEADER.getBytes("UTF-8"), 0, header, 1, BIN_HEADER.length());
      System.arraycopy(BIN_EYECATCHER.getBytes("UTF-8"), 0, header, 96, BIN_EYECATCHER.length());
    } catch (IOException iOException) {}
    putWord(header, 67, ChecksumAMSDOS(header));
    System.arraycopy(mem, fileaddress, data, 0, filelength - 1);
    try {
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filename));
      if (writeheader) {
        int j = 0;
        for (; j < 128; j++)
          bos.write(header[j]); 
      } 
      int i = 0;
      for (; i < filelength; i++)
        bos.write(data[i]); 
      bos.close();
    } catch (IOException iOException) {}
  }
  
  public class CheckBoxListener implements ItemListener {
    public void itemStateChanged(ItemEvent e) {
      if (e.getSource() == CPC.this.AmHeader)
        if (e.getStateChange() == 2) {
          CPC.this.amheader = false;
        } else {
          CPC.this.amheader = true;
        }  
      if (e.getSource() == CPC.this.YMInterleaved)
        if (e.getStateChange() == 2) {
          CPC.this.YM_Interleaved = false;
        } else {
          CPC.this.YM_Interleaved = true;
        }  
      if (e.getSource() == CPC.this.Overscan)
        if (e.getStateChange() == 2) {
          CPC.this.soverscan = false;
          CPC.this.AddressA.setEnabled(false);
          CPC.this.AddressB.setEnabled(false);
          CPC.this.AddressA.setText("");
          CPC.this.AddressB.setText("C000");
        } else {
          CPC.this.soverscan = true;
          CPC.this.AddressA.setEnabled(true);
          CPC.this.AddressB.setEnabled(true);
          CPC.this.AddressA.setText("4000");
          CPC.this.AddressB.setText("C000");
        }  
    }
  }
  
  public void displayLostFocus() {
    this.keyboardb.reset();
    this.keyboarda.reset();
    this.keyboardn.reset();
  }
  
  public Drive[] getFloppyDrives() {
    return this.floppies;
  }
  
  private static GridBagConstraints getGridBagConstraints(int x, int y, double weightx, double weighty, int width, int fill) {
    if (gbcConstraints == null)
      gbcConstraints = new GridBagConstraints(); 
    gbcConstraints.gridx = x;
    gbcConstraints.gridy = y;
    gbcConstraints.weightx = weightx;
    gbcConstraints.weighty = weighty;
    gbcConstraints.gridwidth = width;
    gbcConstraints.fill = fill;
    return gbcConstraints;
  }
  
  public static Color getCol(int pen) {
    Color colo = Palcols[GateArray.getInk(pen)];
    return colo;
  }
  
  public static Color getGCol(int pen) {
    Color colo = Greencols[GateArray.getInk(pen)];
    return colo;
  }
  
  public static JPanel showPalette() {
    JPanel Output = new JPanel();
    Output.setLayout(new GridBagLayout());
    for (int i = 0; i < 17; i++) {
      Palette[i] = "" + GateArray.getInk(i);
      String pals = Palette[i];
      int cols = GateArray.getInk(i);
      String hcols = "" + Util.hex(GateArray.getInks(i));
      hcols = hcols.substring(6);
      String gcols = "" + Util.hex(GateArray.getInks(i) | 0x40);
      gcols = gcols.substring(6);
      if (GateArray.getInk(i) <= 9)
        pals = "0" + pals; 
      int x = i;
      JButton Palettes = new JButton(pals);
      JButton Paletteg = new JButton(gcols);
      JButton Paletteh = new JButton(hcols);
      JPanel Paletten = new JPanel();
      Paletten.setPreferredSize(new Dimension(20, 20));
      Paletten.setSize(20, 20);
      Paletten.setBackground(Palcols[cols]);
      Paletten.setFocusable(false);
      Palettes.setFont(new Font("Monospaced", 1, 16));
      Palettes.setBorder(new EtchedBorder(1));
      Palettes.setFocusable(false);
      Paletteg.setFont(new Font("Monospaced", 1, 16));
      Paletteg.setBorder(new EtchedBorder(1));
      Paletteg.setFocusable(false);
      Paletteh.setFont(new Font("Monospaced", 1, 16));
      Paletteh.setBorder(new EtchedBorder(1));
      Paletteh.setFocusable(false);
      Output.add(Paletten, getGridBagConstraints(x, 1, 0.0D, 0.0D, 1, 1));
      Output.add(Palettes, getGridBagConstraints(x, 2, 0.0D, 0.0D, 1, 1));
      Output.add(Paletteg, getGridBagConstraints(x, 3, 0.0D, 0.0D, 1, 1));
      Output.add(Paletteh, getGridBagConstraints(x, 4, 0.0D, 0.0D, 1, 1));
    } 
    BufferedImage images = new BufferedImage(384, 272, 4);
    images.getGraphics().drawImage(Display.image, 0, 0, 384, 272, null);
    JLabel Display = new JLabel(new ImageIcon(images));
    Output.add(Display, getGridBagConstraints(0, 5, 0.0D, 0.0D, 17, 1));
    Output.setVisible(true);
    return Output;
  }
  
  public void saveScreen(String filename) {
    filename = filename + "        ";
    System.out.println("Saving screen");
    boolean plusmode = false;
    try {
      plusmode = normalPaintBox.getPlus();
    } catch (Exception exception) {}
    if (!plusmode) {
      int i;
      for (i = 0; i < 16; i++)
        POKE(55249 + i, (byte)GateArray.getInk(i)); 
      for (i = 0; i < this.SCR_CODE.length; i++)
        POKE(51152 + i, (byte)this.SCR_CODE[i]); 
      for (i = 0; i < this.FLIP_CODE.length; i++)
        POKE(59344 + i, (byte)this.FLIP_CODE[i]); 
      POKE(55248, (byte)this.gateArray.getScreenMode());
    } else {
      int i;
      for (i = 0; i < CodeP0.length; i++)
        POKE(51152 + i, (byte)CodeP0[i]); 
      for (i = 0; i < CodeP1.length; i++)
        POKE(53200 + i, (byte)CodeP1[i]); 
      for (i = 0; i < CodeP3.length; i++)
        POKE(57296 + i, (byte)CodeP3[i]); 
      for (i = 0; i < this.FLIP_CODE.length; i++)
        POKE(59344 + i, (byte)this.FLIP_CODE[i]); 
      int mode = this.gateArray.getScreenMode();
      byte mo = -116;
      if (mode == 1)
        mo = -115; 
      if (mode == 2)
        mo = -114; 
      POKE(55248, mo);
      byte[] pluspal = normalPaintBox.getPlusPalette();
      System.arraycopy(pluspal, 0, GateArray.screenmemory, 55249, 32);
    } 
    try {
      int ad2 = 541;
      byte[] save = filename.getBytes("UTF-8");
      for (int i = 285; i < 293; i++) {
        POKE(36864 + i, save[i - 285]);
        POKE(36864 + ad2, save[i - 285]);
        ad2++;
      } 
    } catch (Exception exception) {}
    POKE(36863, 200);
    if (this.saveOCP)
      writePal = 1; 
  }
  
  public void saveOverscanScreen(String filename) {
    filename = filename + "        ";
    System.out.println("Saving screen");
    boolean plusmode = false;
    try {
      plusmode = overscanPaintBox.getPlus();
    } catch (Exception exception) {}
    if (!plusmode) {
      POKE(2048, (byte)this.gateArray.getScreenMode());
      for (int i = 0; i < 16; i++)
        POKE(2049 + i, (byte)GateArray.getInk(i)); 
    } else {
      int mode = this.gateArray.getScreenMode();
      byte mo = -116;
      if (mode == 1)
        mo = -115; 
      if (mode == 2)
        mo = -114; 
      GateArray.screenmemory[2048] = mo;
      POKE(2048, mo);
    } 
    try {
      int ad2 = 541;
      byte[] save = filename.getBytes("UTF-8");
      for (int i = 285; i < 293; i++) {
        POKE(36864 + i, save[i - 285]);
        POKE(36864 + ad2, save[i - 285]);
        ad2++;
      } 
    } catch (Exception exception) {}
    POKE(36863, 200);
    if (this.saveOCP)
      writePal = 1; 
  }
  
  public static boolean packScreen = false;
  
  byte[] packeddata;
  
  int countequal;
  
  int countdiff;
  
  boolean crunchdata;
  
  public void exportScreen(boolean overscan) {
    int selectedValue;
    boolean plusmode = false;
    try {
      plusmode = normalPaintBox.getPlus();
    } catch (Exception exception) {}
    if (packScreen && !overscan && !plusmode) {
      if (PaintOnTop)
        try {
          normalPaintFrame.setAlwaysOnTop(!PaintOnTop);
        } catch (Exception exception) {} 
      packScreen = false;
      if (this.exporter == null)
        this.exporter = new ImageExporter(); 
      int memSize = 16384;
      byte[] data = new byte[memSize];
      byte[] mem = memory.getMemory();
      System.arraycopy(mem, 49152, data, 0, memSize - 1);
      int i;
      for (i = 0; i < 16; i++)
        data[6097 + i] = (byte)GateArray.getInk(i); 
      for (i = 0; i < 36; i++)
        data[2000 + i] = (byte)this.SCR_CODE[i]; 
      for (i = 0; i < this.FLIP_CODE.length; i++)
        data[10192 + i] = (byte)this.FLIP_CODE[i]; 
      data[6096] = (byte)this.gateArray.getScreenMode();
      byte[] packedData = crunch(data);
      int l = packedData.length;
      byte[] len = new byte[2];
      Device.putWord(len, 0, l);
      byte[] result = new byte[l + 2];
      System.arraycopy(len, 0, result, 0, 2);
      System.arraycopy(packedData, 0, result, 2, l);
      data = this.exporter.makeHeader(2, 8192, l, 0, "PACKEDSCR", result);
      FileDialog fileDialog = new FileDialog(new Frame(), "Save crunched PAK", 1);
      fileDialog.setFile("*.pak");
      fileDialog.setVisible(true);
      if (PaintOnTop)
        try {
          normalPaintFrame.setAlwaysOnTop(PaintOnTop);
        } catch (Exception exception) {} 
      String str = fileDialog.getFile();
      if (str != null) {
        str = fileDialog.getDirectory() + fileDialog.getFile();
        String savename = str;
        if (!savename.toLowerCase().endsWith(".pak"))
          savename = savename + ".pak"; 
        savename = savename.toUpperCase();
        try {
          BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File(savename)));
          bos.write(data);
          bos.close();
        } catch (Exception exception) {}
      } 
      return;
    } 
    if (PaintOnTop)
      try {
        normalPaintFrame.setAlwaysOnTop(!PaintOnTop);
      } catch (Exception exception) {} 
    boolean RETURN = false;
    this.AddressA.setText("4000");
    this.AddressB.setText("C000");
    Object[] object = { "You can set the screen-mode and inks\nwith a CALL &C7D0 after you loaded\nan exported screen.\nPlease choose now:\nYES:\nWait for a key before return to BASIC", "NO:\nReturn to BASIC after a CALL &C7D0\n\n", this.Overscan, "Start part A", this.AddressA, "Start part B", this.AddressB };
    Object[] objectb = { "You can set the screen-mode and inks\nwith a CALL &C7D0 after you loaded\nan exported screen.\nPlease choose now:\nYES:\nWait for a key before return to BASIC", "NO:\nReturn to BASIC after a CALL &C7D0\n\n" };
    if (overscan) {
      selectedValue = JOptionPane.showOptionDialog(new Frame(), object, "Please choose:", 1, 3, null, null, null);
    } else {
      selectedValue = JOptionPane.showOptionDialog(new Frame(), objectb, "Please choose:", 1, 3, null, null, null);
    } 
    if (selectedValue == 1)
      RETURN = true; 
    if (selectedValue == 2) {
      try {
        normalPaintFrame.setAlwaysOnTop(PaintOnTop);
      } catch (Exception exception) {}
      return;
    } 
    try {
      this.startimageA = Util.hexValue(this.AddressA.getText());
      this.startimageB = Util.hexValue(this.AddressB.getText());
    } catch (Exception error) {
      error.printStackTrace();
      try {
        normalPaintFrame.setAlwaysOnTop(PaintOnTop);
      } catch (Exception exception) {}
    } 
    FileDialog filedia = new FileDialog(new Frame(), "Save 16k CPC Screen File + PAL", 1);
    filedia.setFile("*.scr");
    filedia.setVisible(true);
    String filename = filedia.getFile();
    try {
      normalPaintFrame.setAlwaysOnTop(PaintOnTop);
    } catch (Exception exception) {}
    if (filename != null) {
      filename = filedia.getDirectory() + filedia.getFile();
      String savename = filename;
      savename = savename.toUpperCase();
      String palname = filename;
      int length = savename.length();
      String temp = savename;
      if (savename.toLowerCase().endsWith(".scr"))
        temp = savename.substring(0, length - 4); 
      if (savename.toLowerCase().endsWith(".bin"))
        temp = savename.substring(0, length - 4); 
      savename = temp + ".SCR";
      palname = temp + ".PAL";
      if (this.soverscan) {
        String savename2 = temp + ".SC1";
        savename = temp + ".SC2";
        File fileb = new File(savename2);
        try {
          int memSize = 16384;
          byte[] data = new byte[128 + memSize];
          int i = 0;
          for (; i < 128; i++)
            data[i] = (byte)this.SCR_HEADER[i]; 
          byte[] mem = memory.getMemory();
          System.arraycopy(mem, this.startimageA, data, 128, memSize - 1);
          BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(fileb));
          int j = 0;
          for (; j < 128 + memSize; j++)
            bos.write(data[j]); 
          bos.close();
        } catch (IOException iOException) {}
      } 
      File file = new File(savename);
      try {
        int memSize = 16384;
        byte[] data = new byte[128 + memSize];
        for (int i = 0; i < 128; i++)
          data[i] = (byte)this.SCR_HEADER[i]; 
        byte[] mem = memory.getMemory();
        System.arraycopy(mem, this.startimageB, data, 128, memSize - 1);
        if (!this.soverscan) {
          plusmode = false;
          try {
            plusmode = normalPaintBox.getPlus();
          } catch (Exception exception) {}
          if (!plusmode) {
            int k;
            for (k = 0; k < 16; k++)
              data[6097 + k + 128] = (byte)GateArray.getInk(k); 
            for (k = 0; k < 36; k++)
              data[2000 + k + 128] = (byte)this.SCR_CODE[k]; 
            for (k = 0; k < this.FLIP_CODE.length; k++)
              data[10192 + k + 128] = (byte)this.FLIP_CODE[k]; 
            data[6224] = (byte)this.gateArray.getScreenMode();
          } else {
            int k;
            for (k = 0; k < CodeP0.length; k++)
              data[2000 + k + 128] = (byte)CodeP0[k]; 
            for (k = 0; k < CodeP1.length; k++)
              data[4048 + k + 128] = (byte)CodeP1[k]; 
            for (k = 0; k < CodeP3.length; k++)
              data[8144 + k + 128] = (byte)CodeP3[k]; 
            for (k = 0; k < this.FLIP_CODE.length; k++)
              data[10192 + k + 128] = (byte)this.FLIP_CODE[k]; 
            int moded = this.gateArray.getScreenMode();
            byte mo = -116;
            if (moded == 1)
              mo = -115; 
            if (moded == 2)
              mo = -114; 
            data[6224] = mo;
            byte[] pluspal = normalPaintBox.getPlusPalette();
            System.arraycopy(pluspal, 0, data, 6225, 32);
          } 
          int adr = 2128;
          if (!RETURN) {
            data[adr + 33] = -61;
            data[adr + 34] = 24;
            data[adr + 35] = -69;
          } 
        } 
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
        for (int j = 0; j < 128 + memSize; j++)
          bos.write(data[j]); 
        bos.close();
        if (!this.soverscan)
          exportPal(palname); 
      } catch (IOException iOException) {}
    } 
  }
  
  public byte[] crunch(byte[] data) {
    int packedpos = 0, unpackedpos = 0, tempcount = 0, tempunpackedpos = 0, i = 0;
    this.packeddata = new byte[data.length * 2];
    int datalength = data.length - 1;
    unpackedpos = 0;
    packedpos = 0;
    this.countequal = 0;
    this.countdiff = 0;
    this.crunchdata = true;
    while (this.crunchdata) {
      byte temp = data[unpackedpos];
      if (data[unpackedpos] != data[unpackedpos + 1]) {
        tempcount = 0;
        tempunpackedpos = unpackedpos;
        while (tempcount < 126 && data[tempunpackedpos] != data[tempunpackedpos + 1] && tempunpackedpos < datalength - 1) {
          tempcount++;
          tempunpackedpos++;
        } 
        tempunpackedpos++;
        this.packeddata[packedpos] = (byte)(127 + tempcount + 1);
        packedpos++;
        for (i = 0; i < tempcount; i++) {
          this.packeddata[packedpos] = data[unpackedpos];
          packedpos++;
          unpackedpos++;
        } 
        if (tempunpackedpos >= datalength - 1) {
          this.crunchdata = false;
          break;
        } 
        continue;
      } 
      tempcount = 0;
      while (tempcount < 126 && temp == data[unpackedpos + 1] && unpackedpos < datalength - 1) {
        tempcount++;
        unpackedpos++;
      } 
      unpackedpos++;
      this.packeddata[packedpos] = (byte)(tempcount + 1);
      this.packeddata[packedpos + 1] = temp;
      packedpos += 2;
      if (unpackedpos >= datalength - 1) {
        this.crunchdata = false;
        break;
      } 
    } 
    byte[] packed = new byte[packedpos];
    System.arraycopy(this.packeddata, 0, packed, 0, packed.length);
    return packed;
  }
  
  public void exportPal(String name) {
    File file = new File(name);
    try {
      int memSize = 239;
      byte[] data = new byte[128 + memSize];
      int i = 0;
      for (; i < 128; i++)
        data[i] = (byte)this.PAL_HEADER[i]; 
      data[128] = (byte)this.gateArray.getScreenMode();
      int adr = 131;
      int j = 0;
      for (; j < 17; j++) {
        int g = 0;
        for (; g < 12; g++) {
          int numb = GateArray.getInk(j);
          data[adr] = (byte)this.PAL_INK[numb];
          adr++;
        } 
      } 
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
      int k = 0;
      for (; k < 128 + memSize; k++)
        bos.write(data[k]); 
      bos.close();
    } catch (IOException iOException) {}
  }
  
  public void doMultiface() {
    Hold();
    memory.setLowerEnabled(true);
    memory.setMultiEnabled(true);
    this.gateArray.setModeAndROMEnable(memory, 137);
    this.z80.nmi();
    goOn();
    reSync();
  }
  
  public void Check() {
    if (Switches.save64) {
      Switches.save64 = false;
      SNA_Save(64);
    } 
    if (Switches.save128) {
      Switches.save128 = false;
      SNA_Save(128);
    } 
    if (Switches.save256) {
      Switches.save256 = false;
      SNA_Save(256);
    } 
    if (Switches.save512) {
      Switches.save512 = false;
      SNA_Save(512);
    } 
    if (Switches.save4096) {
      Switches.save4096 = false;
      SNA_Save(4096);
    } 
    if (Switches.scores) {
      Switches.scores = false;
      getScores.getDW3Scores();
    } 
    if (Switches.poke) {
      Switches.poke = false;
      POKE();
    } 
    if (Switches.devil) {
      Cheat();
      Switches.devil = false;
    } 
    if (Switches.export) {
      Switches.export = false;
      BIN_Export();
    } 
    if (Switches.saveScr) {
      Switches.saveScr = false;
      exportScreen(true);
    } 
    if (Switches.savePScr) {
      Switches.savePScr = false;
      exportScreen(false);
    } 
    if (Switches.showPalette) {
      Switches.showPalette = false;
      showPalette();
    } 
    if (Switches.dskcheck == true) {
      Switches.dskcheck = false;
      SaveDSK();
    } 
    if (Switches.BINImport) {
      Switches.BINImport = false;
      BIN_Load();
    } 
    if (Switches.digi) {
      Switches.digi = false;
      Digitracker();
    } 
    if (Switches.digimc) {
      Switches.digimc = false;
      DigitrackerMC();
    } 
    if (Switches.digipg) {
      Switches.digipg = false;
      DigitrackerPG();
    } 
  }
  
  public void StartOverscanPaint(String fname) {
    if (normalPaintFrame != null && normalPaintFrame.isVisible())
      return; 
    StartOverscanPaint();
    overscanPaintBox.setFilename(fname);
  }
  
  public static boolean resetregisters = false;
  
  int YM_Hours;
  
  int YM_size;
  
  boolean del;
  
  int ym_loop;
  
  boolean mp3loaded;
  
  BufferedImage diskimage;
  
  String dskname;
  
  public void StartOverscanPaint() {
    if (normalPaintFrame != null && normalPaintFrame.isVisible())
      return; 
    if (overscanPaintFrame == null) {
      overscanPaintBox = new overscanPaint();
      overscanPaintFrame = new JFrame() {
          protected void processWindowEvent(WindowEvent we) {
            super.processWindowEvent(we);
            if (we.getID() == 201) {
              CPC.overscanPaintBox.manipframe.setVisible(false);
              if (CPC.PEEK(36864) == 42 && CPC.PEEK(37160) == 82 && CPC.PEEK(37415) == 65) {
                for (int i = 368; i < 40959; i++)
                  CPC.POKE(i, 0); 
                CPC.resetregisters = true;
                CPC.reset = true;
                CPC.disableresync = false;
              } 
              CPC.overscanPaintFrame.dispose();
            } 
          }
        };
      overscanPaintFrame.setTitle("JavaCPC Paint");
      overscanPaintFrame.add((Component)overscanPaintBox);
      overscanPaintBox.initialize();
      overscanPaintFrame.pack();
      overscanPaintFrame.setSize(870, 890);
      overscanPaintFrame.setResizable(false);
      overscanPaintFrame.setAlwaysOnTop(false);
      overscanPaintBox.makeUndo();
      overscanPaintFrame.setVisible(true);
      overscanPaintFrame.addComponentListener(new ComponentListener() {
            public void componentHidden(ComponentEvent e) {}
            
            public void componentShown(ComponentEvent e) {}
            
            public void componentResized(ComponentEvent e) {}
            
            public void componentMoved(ComponentEvent e) {
              int width = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
              int height = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
              if (width >= 1920) {
                int x = (CPC.overscanPaintFrame.getLocationOnScreen()).x;
                int y = (CPC.overscanPaintFrame.getLocationOnScreen()).y;
                if ((x + CPC.overscanPaintBox.manipframe.getWidth() + CPC.overscanPaintBox.getWidth()) < Toolkit.getDefaultToolkit().getScreenSize().getWidth()) {
                  CPC.overscanPaintBox.manipframe.setLocation(x + CPC.overscanPaintBox.getWidth() + 6, y);
                } else {
                  CPC.overscanPaintBox.manipframe.setLocation(x - CPC.overscanPaintBox.manipframe.getWidth(), y);
                } 
              } 
            }
          });
    } else {
      try {
        overscanPaintBox.makeUndo();
        overscanPaintFrame.setVisible(true);
        overscanPaintBox.manipframe.setVisible(true);
      } catch (Exception exception) {}
    } 
  }
  
  public void StartNormalPaint(String fname) {
    if (overscanPaintFrame != null && overscanPaintFrame.isVisible())
      return; 
    StartNormalPaint();
    normalPaintBox.setFilename(fname);
  }
  
  public void endFlip() {
    showflippreview = false;
    (normalPaintBox.getFlip()).flip.setSelected(false);
  }
  
  public void StartNormalPaint() {
    if (overscanPaintFrame != null && overscanPaintFrame.isVisible())
      return; 
    if (normalPaintFrame == null) {
      normalPaintBox = new normalPaint();
      normalPaintFrame = new JFrame() {
          protected void processWindowEvent(WindowEvent we) {
            super.processWindowEvent(we);
            if (we.getID() == 201) {
              CPC.normalPaintBox.manipframe.setVisible(false);
              CPC.this.endFlip();
              if (CPC.PEEK(36864) == 42 && CPC.PEEK(37160) == 82 && CPC.PEEK(37415) == 65) {
                for (int i = 368; i < 40959; i++)
                  CPC.POKE(i, 0); 
                CPC.disableresync = false;
                CPC.reset = true;
              } 
              CPC.normalPaintFrame.dispose();
            } 
          }
        };
      normalPaintFrame.setTitle("JavaCPC Paint");
      normalPaintFrame.add((Component)normalPaintBox);
      normalPaintBox.initialize();
      normalPaintFrame.pack();
      int w = 756;
      int h = 768;
      normalPaintFrame.setSize(w, h);
      normalPaintFrame.setPreferredSize(new Dimension(w, h));
      normalPaintFrame.setResizable(false);
      normalPaintFrame.setAlwaysOnTop(false);
      normalPaintBox.makeUndo();
      normalPaintFrame.setVisible(true);
      normalPaintFrame.addComponentListener(new ComponentListener() {
            public void componentHidden(ComponentEvent e) {}
            
            public void componentShown(ComponentEvent e) {}
            
            public void componentResized(ComponentEvent e) {}
            
            public void componentMoved(ComponentEvent e) {
              int width = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
              int height = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
              if (width >= 1600) {
                int x = (CPC.normalPaintFrame.getLocationOnScreen()).x;
                int y = (CPC.normalPaintFrame.getLocationOnScreen()).y;
                if ((x + CPC.normalPaintBox.manipframe.getWidth() + CPC.normalPaintBox.getWidth()) < Toolkit.getDefaultToolkit().getScreenSize().getWidth()) {
                  CPC.normalPaintBox.manipframe.setLocation(x + CPC.normalPaintBox.getWidth() + 6, y);
                } else {
                  CPC.normalPaintBox.manipframe.setLocation(x - CPC.normalPaintBox.manipframe.getWidth(), y);
                } 
              } 
            }
          });
    } else {
      try {
        normalPaintBox.makeUndo();
        normalPaintFrame.setVisible(true);
        normalPaintBox.manipframe.setVisible(true);
      } catch (Exception exception) {}
    } 
  }
  
  public void Digitracker() {
    this.launchcount = 1;
    this.launchcode = 1;
  }
  
  public void DigitrackerMC() {
    this.launchcount = 1;
    this.launchcode = 3;
  }
  
  public void DigitrackerPG() {
    this.launchcount = 1;
    this.launchcode = 4;
  }
  
  public void LOAD(String name, int address, int length, int launchaddress, boolean type) {
    byte[] data = getRom(name, length);
    type = false;
    byte[] mem = memory.getMemory();
    System.arraycopy(data, 0, mem, address, length);
    System.arraycopy(data, 0, GateArray.screenmemory, address, length);
    if (launchaddress > 0) {
      if (type) {
        AutoType("CALL &" + Util.hex(launchaddress).substring(4) + "\n");
      } else {
        runBinary(launchaddress);
      } 
      reSync();
      reSync();
      reSync();
    } 
  }
  
  public void SNAP(String name) {
    byte[] data = getRom(name, 131328);
    SNA_Load("nix", data);
  }
  
  public void launchDigitracker() {
    LOAD("file/DIGITRAK.DT", 23923, 18829, 23923, false);
    this.blastercount = 1;
  }
  
  public void launchXMS() {
    LOAD("XMAS19.BIN", 23040, 17536, 23040, false);
    reSync();
  }
  
  public void launchDigitrackerMC() {
    LOAD("file/DIGITRAK.MC", 15404, 9473, 24704, false);
  }
  
  public void launchDigitrackerPG() {
    LOAD("file/DIGITRAK.PG", 15948, 7905, 23680, false);
  }
  
  public void Cheat() {
    this.launchcode = 2;
    this.launchcount = 1;
  }
  
  public void launchCheat() {
    Devil.Devil();
    runBinary(36864);
  }
  
  public void storeYM() {
    if ((this.psg.readRegister(8) != 0 || this.psg.readRegister(9) != 0 || this.psg.readRegister(10) != 0) && !doRecord)
      doRecord = true; 
    if (doRecord) {
      vcount++;
      if (vcount >= 50) {
        vcount = 0;
        YM_Seconds++;
        if (YM_Seconds >= 60) {
          YM_Seconds = 0;
          YM_Minutes++;
          if (YM_Minutes >= 60) {
            YM_Minutes = 0;
            this.YM_Hours++;
          } 
        } 
      } 
      String minutes = "" + YM_Minutes;
      if (YM_Minutes <= 9)
        minutes = "0" + minutes; 
      String hours = "" + this.YM_Hours;
      if (this.YM_Hours <= 9)
        hours = "0" + hours; 
      String seconds = "" + YM_Seconds;
      if (YM_Seconds <= 9)
        seconds = "0" + seconds; 
      String milliseconds = "" + (vcount * 2);
      if (vcount <= 4)
        milliseconds = "0" + milliseconds; 
      YMControl.doYMDisplay(hours + ":" + minutes, seconds, milliseconds, "*RECORDING*", minutes, seconds);
      int i = 0;
      for (; i < 16; i++) {
        if (i == 13) {
          if (this.psg.registerUpdated()) {
            this.YM_Data[ymcount] = this.psg.readRegister(i);
          } else {
            this.YM_Data[ymcount] = 255;
          } 
        } else {
          this.YM_Data[ymcount] = this.psg.readRegister(i);
        } 
        if (i == 14 || i == 15)
          this.YM_Data[ymcount] = 0; 
        ymcount++;
        YM_RecCount++;
      } 
      if (ymcount >= 999980) {
        System.out.println("Recording stopped... Buffer full!");
        YM_Rec = false;
        ymcount = 0;
      } 
      YM_vbl++;
      this.psg.resetUpdated();
    } 
  }
  
  public void Slide(int pos) {
    if (!YM_Rec) {
      ymcount = pos * 50 * YM_registers;
      vcount = 0;
    } 
  }
  
  int[] secondsToTime(int secs) {
    double hours = Math.floor((secs / 3600));
    double divisor_for_minutes = (secs % 3600);
    double minutes = Math.floor(divisor_for_minutes / 60.0D);
    double divisor_for_seconds = divisor_for_minutes % 60.0D;
    double seconds = Math.ceil(divisor_for_seconds);
    int[] obj = { (int)hours, (int)minutes, (int)seconds };
    return obj;
  }
  
  public void playYM() {
    if (atari_st_mode && !st_mode) {
      this.psg.changeClockSpeed(2000000);
      st_mode = true;
    } 
    if (spectrum_mode && !zx_mode) {
      this.psg.changeClockSpeed(1773400);
      zx_mode = true;
    } 
    vcount++;
    this.YM_size = YM_RecCount / 50 / YM_registers;
    YMControl.ympos.setMaximum(this.YM_size);
    if (vcount == 50)
      vcount = 0; 
    int second = ymcount / 50 / YM_registers;
    int[] timer = secondsToTime(second);
    YM_Minutes = timer[1];
    YM_Seconds = timer[2];
    String minutes = "" + YM_Minutes;
    if (YM_Minutes <= 9)
      minutes = "0" + minutes; 
    minutes = timer[0] + ":" + minutes;
    if (timer[0] < 10);
    minutes = "0" + minutes;
    String seconds = "" + YM_Seconds;
    if (YM_Seconds <= 9)
      seconds = "0" + seconds; 
    int ms = vcount * 2;
    if (ms > 99)
      ms = 99; 
    String milliseconds = ((ms < 10) ? "0" : "") + ms;
    YMControl.doYMDisplay(minutes, seconds, milliseconds, this.YMtitle, this.YMauthor, this.YMcreator);
    YMControl.ympos.setValue(ymcount / 50 / YM_registers);
    if (YM_RecCount >= 1) {
      int i = 0;
      for (; i < YM_registers; i++) {
        if (i == 13) {
          if (this.YM_Data[ymcount] != 255)
            try {
              this.psg.setRegister(i, this.YM_Data[ymcount]);
            } catch (Exception exception) {} 
        } else {
          try {
            this.psg.setRegister(i, this.YM_Data[ymcount]);
          } catch (Exception exception) {}
        } 
        ymcount++;
      } 
      if (ymcount >= YM_RecCount) {
        ymcount = this.ym_loop * YM_registers;
        YMControl.UpdateLCD("*YM PLAYER*");
      } 
    } else {
      this.psg.changeClockSpeed(1000000);
      st_mode = false;
      YM_Play = false;
      System.out.println("Sorry, no playback-data in buffer");
    } 
  }
  
  public void loadAlarm() {
    loadYM(System.getProperty("user.home") + "/JavaCPC/aha.ym", false);
    YM_Play = true;
  }
  
  public void loadYM() {
    JEMU.ymControl.setVisible(false);
    FileDialog filedia = new FileDialog(new Frame(), "Load YM audio File", 0);
    filedia.setFile("*.ym; *.bin");
    filedia.setVisible(true);
    String filename = filedia.getFile();
    if (filename != null) {
      filename = filedia.getDirectory() + filedia.getFile();
      String loadname = filename;
      try {
        loadYM(unLHA(loadname), false);
      } catch (Exception e) {
        loadYM(loadname, false);
      } 
    } 
    JEMU.ymControl.setVisible(true);
  }
  
  public void loadYM(String loadname, boolean delete) {
    YMControl.displaycount1 = 0;
    YMControl.displaycount2 = 0;
    YMControl.DisplayStart = 0;
    YM_Minutes = 0;
    YM_Seconds = 0;
    ymcount = 0;
    YMControl.UpdateLCD("*YM PLAYER*");
    if (loadname.startsWith("http://") || loadname.startsWith("www.")) {
      if (loadname.startsWith("www."))
        loadname = "http://" + loadname; 
      String savename = "buffer.ym";
      String[] arg = { loadname, savename };
      copyURL.download(arg, true);
      loadname = savename;
    } 
    this.psg.changeClockSpeed(1000000);
    st_mode = false;
    this.YMtitle = "";
    this.YMauthor = "";
    this.YMcreator = "";
    this.shouldcount = false;
    this.begincount = 0;
    YM_RecCount = 0;
    int value0 = 0;
    int value1 = 0;
    int value2 = 0;
    int value3 = 0;
    int YM_length = 0;
    atari_st_mode = false;
    spectrum_mode = false;
    this.YM_Interleaved = false;
    File file = new File(loadname);
    int ym_read_byte = 0;
    this.ym_loop = 0;
    try {
      BufferedInputStream bos = new BufferedInputStream(new FileInputStream(file));
      long len = file.length();
      int ym_filepos = 0;
      for (; ym_filepos <= len; ym_filepos++) {
        ym_read_byte = bos.read();
        if (ym_filepos == 2)
          if (ym_read_byte == 53 || ym_read_byte == 54 || ym_read_byte == 51 || ym_read_byte == 50) {
            if (ym_read_byte == 51 || ym_read_byte == 50) {
              YM_registers = 14;
              this.YM_Interleaved = true;
              oldYM = true;
              atari_st_mode = true;
              spectrum_mode = false;
              if (ym_read_byte == 50) {
                System.out.println("opening YM2! file...");
              } else {
                System.out.println("opening YM3! file...");
              } 
            } 
            if (ym_read_byte == 53) {
              YM_registers = 16;
              oldYM = false;
              System.out.println("opening YM5! file...");
              try {
                BufferedInputStream boss = new BufferedInputStream(new FileInputStream(file));
                byte[] check = new byte[boss.available()];
                boss.read(check);
                boss.close();
                this.ym_loop = Device.getLWord(check, 28);
                System.out.println("loop is " + this.ym_loop);
              } catch (Exception exception) {}
            } 
            if (ym_read_byte == 54) {
              YM_registers = 16;
              oldYM = false;
              System.out.println("opening YM6! file...");
              try {
                BufferedInputStream boss = new BufferedInputStream(new FileInputStream(file));
                byte[] check = new byte[bos.available()];
                boss.read(check);
                boss.close();
                this.ym_loop = Device.getLWord(check, 28);
                System.out.println("loop is " + this.ym_loop);
              } catch (Exception exception) {}
            } 
          } else {
            System.out.println("Wrong format... Cannot playback!");
            this.YM_Interleaved = false;
            atari_st_mode = false;
            spectrum_mode = false;
            YM_RecCount = 0;
            bos.close();
            return;
          }  
        if (ym_filepos == 12)
          value0 = ym_read_byte; 
        if (ym_filepos == 13)
          value1 = ym_read_byte; 
        if (ym_filepos == 14)
          value2 = ym_read_byte; 
        if (ym_filepos == 15)
          value3 = ym_read_byte; 
        if (!oldYM && ym_filepos == 19 && (ym_read_byte & 0x1) == 1) {
          System.out.println("Found an interleaved file of " + YM_registers + " registers.");
          this.YM_Interleaved = true;
        } 
        if (ym_filepos == 25) {
          if (ym_read_byte == 128) {
            atari_st_mode = true;
            spectrum_mode = false;
          } 
          if (ym_read_byte == 88) {
            atari_st_mode = false;
            spectrum_mode = true;
          } 
        } 
        if (!oldYM && ym_filepos >= 34 && !this.shouldcount) {
          if (this.begincount >= 3)
            this.shouldcount = true; 
          if (ym_read_byte == 0 && this.begincount <= 5)
            this.begincount++; 
          if (this.begincount == 0 && ym_read_byte != 0) {
            char c = (char)ym_read_byte;
            this.YMtitle += c;
          } 
          if (this.begincount == 1 && ym_read_byte != 0) {
            char c = (char)ym_read_byte;
            this.YMauthor += c;
          } 
          if (this.begincount == 2 && ym_read_byte != 0) {
            char c = (char)ym_read_byte;
            this.YMcreator += c;
          } 
        } 
        if (oldYM && ym_filepos >= 4 && !this.shouldcount) {
          this.YMtitle = "none";
          this.YMauthor = "none";
          this.YMcreator = "none";
          this.shouldcount = true;
        } 
        if (this.shouldcount)
          if (!this.YM_Interleaved) {
            this.YM_Data[YM_RecCount] = ym_read_byte;
            YM_RecCount++;
          } else {
            this.YM_DataInterleaved[YM_RecCount] = ym_read_byte;
            YM_RecCount++;
          }  
      } 
      bos.close();
      if (delete || this.del)
        try {
          File check = new File(loadname);
          check.delete();
        } catch (Exception exception) {} 
      if (!oldYM) {
        YM_length = value0 * 256 + value1 * 256 + value2 * 256 + value3;
        System.out.println("YM_RecCount " + Util.hex(YM_RecCount));
        System.out.println("YM_length " + Util.hex(YM_length));
        YM_registers = YM_RecCount / YM_length;
        if (YM_registers > 16)
          YM_registers = 16; 
        System.out.println("Registers: " + YM_registers);
        YM_vbl = YM_length;
      } else {
        YM_vbl = YM_RecCount / YM_registers;
      } 
      YMControl.UpdateLCD("*YM PLAYER*");
      ymcount = 0;
      if (this.YM_Interleaved && !oldYM) {
        int counted = 0;
        int jk = 0;
        for (; jk < YM_registers; jk++) {
          int ik = 0;
          for (; ik < YM_length; ik++) {
            this.YM_Data[jk + ik * YM_registers] = this.YM_DataInterleaved[counted];
            counted++;
          } 
        } 
      } else if (this.YM_Interleaved) {
        int counted = 0;
        int jk = 0;
        for (; jk < YM_registers; jk++) {
          int ik = 0;
          for (; ik < YM_RecCount / YM_registers; ik++) {
            this.YM_Data[ik * YM_registers + jk] = this.YM_DataInterleaved[counted];
            counted++;
          } 
        } 
      } 
      Display.title = this.YMtitle;
      Display.author = this.YMauthor;
      Display.creator = this.YMcreator;
      System.out.println("Title: " + this.YMtitle);
      System.out.println("Author: " + this.YMauthor);
      System.out.println("Creator: " + this.YMcreator);
      if (atari_st_mode) {
        System.out.println("AY speed is 2000000 hz!");
      } else if (spectrum_mode) {
        System.out.println("AY speed is 1773400 hz!");
      } else {
        System.out.println("AY speed is 1000000 hz!");
      } 
    } catch (IOException iox) {
      System.out.println("can't read file ");
    } 
  }
  
  public void saveYM() {
    JEMU.ymControl.setVisible(false);
    if (YM_RecCount >= 1) {
      FileDialog filedia = new FileDialog(new Frame(), "Save YM audio File", 1);
      filedia.setFile("*.ym");
      filedia.setVisible(true);
      String filename = filedia.getFile();
      if (filename != null) {
        filename = filedia.getDirectory() + filedia.getFile();
        String savename = filename;
        if (!savename.toLowerCase().endsWith(".ym"))
          savename = savename + ".ym"; 
        saveYM(savename);
      } 
    } else {
      System.out.println("Sorry, no data in buffer, cannot save!");
    } 
    JEMU.ymControl.setVisible(true);
  }
  
  public void saveYM(String savename) {
    atari_st_mode = false;
    spectrum_mode = false;
    this.psg.changeClockSpeed(1000000);
    st_mode = false;
    this.YM_Interleaved = true;
    File file = new File(savename);
    String HeaderYM = "YM5!LeOnArD!";
    String title = "";
    String author = "";
    if (!oldYM) {
      JTextField YMTitle = new JTextField();
      JTextField YMAuthor = new JTextField();
      YMAuthor.setText(author);
      YMTitle.setText(title);
      Object[] message = { "Song name", YMTitle, "Authors name", YMAuthor };
      JOptionPane pane = new JOptionPane(message, 3, -1);
      pane.createDialog(null, "Create YM file").setVisible(true);
      title = YMTitle.getText();
      author = YMAuthor.getText();
    } 
    try {
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
      if (!oldYM) {
        if (title == null)
          title = "none"; 
        if (author == null)
          author = "none"; 
        String recorded = "recorded with JavaCPC";
        byte[] header = new byte[34];
        byte[] authorbyte = new byte[1000];
        byte[] titlebyte = new byte[1000];
        byte[] recbyte = new byte[40];
        System.arraycopy(HeaderYM.getBytes("UTF-8"), 0, header, 0, HeaderYM.length());
        System.arraycopy(title.getBytes("UTF-8"), 0, titlebyte, 0, title.length());
        System.arraycopy(author.getBytes("UTF-8"), 0, authorbyte, 0, author.length());
        System.arraycopy(recorded.getBytes("UTF-8"), 0, recbyte, 0, recorded.length());
        putLongBigEndian(header, 12, YM_vbl);
        putWordBigEndian(header, 16, 0);
        if (this.YM_Interleaved) {
          header[19] = 1;
        } else {
          header[19] = 0;
        } 
        putLongBigEndian(header, 22, 1000000);
        putWordBigEndian(header, 26, 50);
        putLongBigEndian(header, 28, this.ym_loop);
        int i;
        for (i = 0; i < 34; i++)
          bos.write(header[i]); 
        i = 0;
        for (; i < title.length() + 1; i++)
          bos.write(titlebyte[i]); 
        i = 0;
        for (; i < author.length() + 1; i++)
          bos.write(authorbyte[i]); 
        i = 0;
        for (; i < recorded.length() + 1; i++)
          bos.write(recbyte[i]); 
      } else {
        String YMHeader = "YM3!";
        byte[] header = new byte[14];
        System.arraycopy(YMHeader.getBytes("UTF-8"), 0, header, 0, YMHeader.length());
        int i = 0;
        for (; i < 4; i++)
          bos.write(header[i]); 
        this.YM_Interleaved = true;
      } 
      if (this.YM_Interleaved) {
        int j = 0;
        for (; j < YM_registers; j++) {
          int i = 0;
          for (; i < YM_RecCount / YM_registers; i++)
            bos.write(this.YM_Data[i * YM_registers + j]); 
        } 
      } else {
        int j = 0;
        for (; j <= YM_RecCount; j++)
          bos.write(this.YM_Data[j]); 
      } 
      if (!oldYM) {
        String EndYM = "End!";
        byte[] headerend = new byte[14];
        System.arraycopy(EndYM.getBytes("UTF-8"), 0, headerend, 0, EndYM.length());
        int i = 0;
        for (; i < 4; i++)
          bos.write(headerend[i]); 
      } 
      bos.close();
    } catch (IOException iox) {
      System.out.println("can't write to file ");
    } 
  }
  
  private void YMCheck() {
    if (YM_Rec)
      storeYM(); 
    if (YM_Play && !YM_Stop) {
      Switches.blockKeyboard = true;
      playYM();
    } 
    if (YM_Stop && !YM_Rec) {
      Switches.blockKeyboard = false;
      this.psg.changeClockSpeed(1000000);
      st_mode = false;
      YM_Stop = false;
      this.psg.resetRegisters();
    } 
    if (YM_Stop && YM_Rec) {
      Switches.blockKeyboard = false;
      this.psg.changeClockSpeed(1000000);
      st_mode = false;
      YM_Stop = false;
    } 
    if (YM_Save) {
      YM_Save = false;
      saveYM();
    } 
    if (YM_Load) {
      YM_Load = false;
      loadYM();
    } 
  }
  
  protected void TapeLoad(String loadname, byte[] data) {
    this.counterInit = 20;
    tape_stereo = false;
    bitrate = 8;
    tapeloaded = false;
    isCDT = false;
    tapeBandPosition = 0;
    this.doLoad = 0;
    JEMU.isTape = true;
    tapesample = null;
    tapesample = data;
    int tapelength = getDWord(tapesample, 40);
    this.frequency = getDWord(tapesample, 24);
    int channels = tapesample[22];
    int bits = tapesample[34];
    tape_delay = 1010000 / this.frequency;
    this.tapedelay = 1010000;
    System.out.println("Tape delay is: " + tape_delay);
    bitrate = bits;
    if (tapelength > (int)Switches.availmem) {
      System.out.println("Sorry, the file is too large");
      tapesample = new byte[0];
      return;
    } 
    if (tapelength > data.length) {
      System.out.println("Reloading file... File is larger than buffer.");
      tapesample = null;
      tapesample = getFile(loadname);
    } 
    System.out.println("Stream has " + this.frequency + " hz, " + tapelength + " bytes, " + channels + " channels, " + bits + " bits");
    if (channels >= 2) {
      tape_stereo = true;
    } else {
      tape_stereo = false;
    } 
    tapePlay = true;
    this.TapeDrive.pressPlay();
    if (Switches.FloppySound && !tapeloaded)
      Samples.TAPEINSERT.play(); 
    tapeloaded = true;
    recordcount = tapesample.length;
    this.TapeDrive.createBlocks(tapesample);
    this.TapeDrive.showText(this.TapeDrive.filename);
    getTapeCounter();
    printTapeTime();
    reSync();
    if (data != null && this.key != null)
      this.key.reset(); 
  }
  
  public void tapeEject() {
    this.TAPData = null;
    if (loadtap)
      unpatchOS(); 
    loadtap = false;
    this.counterInit = 20;
    this.TapeDrive.pressEject();
  }
  
  protected void optimizeWAV() {
    FileDialog filedia = new FileDialog(new Frame(), "Load WAV file", 0);
    filedia.setFile("*.wav");
    filedia.setVisible(true);
    String filename = filedia.getFile();
    if (filename != null) {
      filename = filedia.getDirectory() + filedia.getFile();
      String loadname = filename;
      this.SetByte.setText("6F");
      Object[] object = { "Enter togglebyte-value", this.SetByte };
      int selectedValue = JOptionPane.showOptionDialog(new Frame(), object, "Please enter:", -1, 3, null, null, null);
      if (selectedValue == 1)
        return; 
      if (selectedValue == 2)
        return; 
      optimizeWAV(loadname, this.SetByte.getText());
    } 
  }
  
  protected void optimizeWAV(String name, String setbyte) {
    try {
      int setByte = Util.hexValue(setbyte);
      try {
        BufferedInputStream bos = new BufferedInputStream(new FileInputStream(name));
        tapesample = null;
        tapesample = new byte[bos.available()];
        bos.read(tapesample);
        bos.close();
        int length = tapesample.length - 44;
        for (int i = 0; i < length; i++) {
          int value = tapesample[i + 44] ^ 0x80;
          if (tapesample[i + 44] != Byte.MIN_VALUE)
            if (value <= setByte) {
              tapesample[i + 44] = 38;
            } else {
              tapesample[i + 44] = -38;
            }  
        } 
        BufferedOutputStream boss = new BufferedOutputStream(new FileOutputStream(name + "_optimized.wav"));
        boss.write(tapesample);
        boss.close();
        System.out.println("Successfully optimized");
      } catch (IOException iox) {
        System.out.println("can't read/write file ");
      } 
    } catch (Exception exception) {}
  }
  
  public void CSWLoad(String name, byte[] data) {
    tapeloaded = false;
    tape_stereo = false;
    bitrate = 8;
    tapesample = null;
    int length = data.length;
    this.frequency = getWord(data, 25);
    if (data[27] != 1) {
      System.err.println("Wrong compression format!");
      return;
    } 
    int polarity = 127 + data[28] % 2;
    boolean odd = ((data[28] + 2) % 2 == 0);
    String pol = "positive";
    if (odd)
      pol = "negative"; 
    tape_delay = 1010000 / this.frequency;
    this.tapedelay = 1010000;
    System.out.println("CSW loaded.");
    System.out.println("polarity  = " + pol);
    System.out.println("frequency = " + this.frequency);
    int size = 0;
    int i = 32;
    while (i < length) {
      int a = data[i++] & 0xFF;
      if (a == 0)
        a = data[i++] + (data[i++] << 8) + (data[i++] << 16) + (data[i++] << 24); 
      while (a-- > 0)
        size++; 
    } 
    tapesample = new byte[size];
    int tapecount = 0;
    i = 32;
    while (i < length) {
      int a = data[i++] & 0xFF;
      if (a == 0)
        a = data[i++] + (data[i++] << 8) + (data[i++] << 16) + (data[i++] << 24); 
      if (!odd)
        polarity = 255 - polarity; 
      while (a-- > 0) {
        tapesample[tapecount] = (byte)(polarity ^ 0x80);
        if (tapesample[tapecount] == 0) {
          tapesample[tapecount] = -38;
        } else {
          tapesample[tapecount] = 38;
        } 
        tapecount++;
      } 
      if (odd)
        polarity = 255 - polarity; 
    } 
    tapePlay = true;
    this.TapeDrive.pressPlay();
    if (Switches.FloppySound && !tapeloaded)
      Samples.TAPEINSERT.play(); 
    tapeloaded = true;
    recordcount = tapesample.length;
  }
  
  public void MP3Load(String name) {
    this.mp3loaded = false;
    this.mp3name = name;
    if (!playmovie)
      this.mp3.setVisible(true); 
    this.mp3count = 1;
  }
  
  public void MP3Load() {
    this.mp3count = 0;
    Thread importmp3 = new Thread() {
        public void run() {
          try {
            CPC.bitrate = 8;
            CPC.tapesample = null;
            CPC.tapesample = CPC.this.mp3c.convertToArray(CPC.this.mp3name);
            FileOutputStream buffer = new FileOutputStream("buffer.wav");
            buffer.write(CPC.tapesample);
            buffer.close();
            CPC.this.TapeLoad(CPC.this.mp3name, CPC.tapesample);
            CPC.this.mp3loaded = true;
            CPC.this.mp3.setVisible(false);
          } catch (Exception error) {
            System.out.println(error.getMessage());
          } 
          CPC.this.reSync();
        }
      };
    importmp3.start();
  }
  
  public void keySample(KeyEvent e, boolean release) {
    if (Switches.KeyboardSound)
      keySample(e.getKeyCode(), release); 
  }
  
  public void keySample(int e, boolean release) {
    if (!release) {
      if (Switches.ROM.equals("CPC664") || Switches.ROM.equals("CPC464")) {
        if (e == 32) {
          Samples.SPRESS.play();
        } else if (e == 10) {
          Samples.EPRESS.play();
        } else {
          Samples.KPRESS.play();
        } 
      } else if (e == 32) {
        Samples.SPACEPRESS.play();
      } else if (e == 10) {
        Samples.ENTERPRESS.play();
      } else {
        Samples.KEYPRESS.play();
      } 
    } else if (Switches.ROM.equals("CPC664") || Switches.ROM.equals("CPC464")) {
      if (e == 32) {
        Samples.SRELEASE.play();
      } else if (e == 10) {
        Samples.ERELEASE.play();
      } else {
        Samples.KRELEASE.play();
      } 
    } else if (e == 32) {
      Samples.SPACERELEASE.play();
    } else if (e == 10) {
      Samples.ENTERRELEASE.play();
    } else {
      Samples.KEYRELEASE.play();
    } 
  }
  
  public void LoadPNGDisk(String name, byte[] data) {
    this.dskname = name;
    while (this.dskname.contains("\\"))
      this.dskname = this.dskname.substring(1); 
    this.dskname = this.dskname.replace(".png", "");
    try {
      int dskloc = ArrayFind.indexOf(data, "PNGDIVIDER".getBytes("UTF-8")) + 10;
      byte[] dsk = new byte[data.length - dskloc];
      System.arraycopy(data, dskloc, dsk, 0, dsk.length);
      byte[] disk = Compressor.gUnzip(dsk);
      DSK_Load(name, disk);
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void savePNGDisk() {
    Thread save = new Thread() {
        public void run() {
          BufferedImage image = new BufferedImage(384, 272, 1);
          image.getGraphics().drawImage(CPC.this.display.getImag(), 0, 0, 384, 272, null);
          FileDialog filedia = new FileDialog(new JFrame(), "Save PNG Disk image", 1);
          filedia.setFile("*dsk.png");
          filedia.setVisible(true);
          String filename = filedia.getFile();
          if (filename != null) {
            filename = filedia.getDirectory() + filedia.getFile();
            if (!filename.toLowerCase().endsWith(".dsk.png"))
              filename = filename + ".dsk.png"; 
            try {
              byte[] disk = CPC.this.fdc.getDrive(0).getDisc(0).getImage();
              byte[] dsk = Compressor.gZip(disk);
              File file = new File(filename);
              ImageIO.write(image, "PNG", file);
              BufferedInputStream bin = new BufferedInputStream(new FileInputStream(file));
              byte[] png = new byte[bin.available()];
              bin.read(png);
              bin.close();
              BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
              bos.write(png);
              bos.write("PNGDIVIDER".getBytes("UTF-8"));
              bos.write(dsk);
              bos.close();
            } catch (Exception e) {
              e.printStackTrace();
            } 
          } 
        }
      };
    save.start();
  }
  
  public void CAT() {
    System.out.println("Directory of drive DF" + catdrive + ":");
    System.out.println("-----------------------");
    try {
      String[] entry = this.fdc.getInfo(catdrive);
      int i = 0;
      for (; i < entry.length; i += 2) {
        System.out.print(entry[i] + "    ");
        try {
          System.out.println(entry[i + 1]);
        } catch (Exception f) {
          System.out.println();
        } 
      } 
      System.out.println();
    } catch (Exception e) {
      System.out.println("Directory or Drive is empty.\r\n");
    } 
  }
  
  public static boolean cat = false;
  
  public static int catdrive = 0;
  
  ItemListener OCPListener;
  
  double aR;
  
  double iR;
  
  double lR;
  
  double dR;
  
  double nR;
  
  double[] bandThickness;
  
  int timerDelay;
  
  int lastcounter;
  
  public static byte[][] movie;
  
  public void bootDisk(final int drive, final boolean sys) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            CPC.this.fdc.showSys = sys;
            CPC.this.entries = CPC.this.fdc.getInfo(drive);
            CPC.this.users = CPC.this.fdc.getUser();
            int notfound = 0;
            String dr = "";
            String typethis = "";
            String loadthis = "";
            if (drive > 1)
              return; 
            if (drive == 0) {
              dr = "";
            } else {
              dr = "|B:";
            } 
            if (CPC.this.entries == null && !sys) {
              System.out.println("Checking for system files");
              CPC.this.bootDisk(drive, true);
              return;
            } 
            if (CPC.this.entries == null && sys) {
              CPC.this.fromautoboot = true;
              CPC.this.BasicAutoType("|CPM");
              return;
            } 
            System.out.println(CPC.this.entries.length + " entries found...");
            if (CPC.this.entries.length < 1 && !sys) {
              System.out.println("Checking for system files");
              CPC.this.bootDisk(drive, true);
              return;
            } 
            if (CPC.this.entries.length < 1 && sys) {
              CPC.this.fromautoboot = true;
              CPC.this.BasicAutoType("|CPM");
              return;
            } 
            if (CPC.this.entries.length == 1) {
              CPC.this.cleanEntries(0);
              if (CPC.this.users[0] != 0)
                dr = dr + "|USER," + CPC.this.users[0] + ":"; 
              loadthis = CPC.this.entries[0];
            } else {
              int i;
              for (i = 0; i < CPC.this.entries.length; i++) {
                CPC.this.entries[i] = CPC.this.entries[i].toUpperCase();
                if (CPC.this.entries[i].endsWith(".BIN") || CPC.this.entries[i].endsWith(".BIN<") || CPC.this.entries[i].endsWith(".BIN<>") || CPC.this.entries[i].endsWith(".BIN>"))
                  notfound = i; 
              } 
              for (i = 0; i < CPC.this.entries.length; i++) {
                try {
                  while (CPC.this.entries[i].charAt(0) < '-' || CPC.this.entries[i].charAt(0) > 'Z')
                    i++; 
                } catch (Exception e) {
                  i--;
                  break;
                } 
                try {
                  while (CPC.this.users[i] != 0)
                    i++; 
                } catch (Exception e) {
                  i--;
                  break;
                } 
                System.out.println("Analysing: " + CPC.this.entries[i]);
                if (CPC.this.entries[i].startsWith("-")) {
                  CPC.this.cleanEntries(i);
                  loadthis = CPC.this.entries[i];
                  if (CPC.this.users[i] != 0)
                    dr = dr + "|USER," + CPC.this.users[0] + ":"; 
                  break;
                } 
                if (CPC.this.entries[i].contains(".  ") || CPC.this.entries[i].contains("  <") || CPC.this.entries[i].contains("  <>") || CPC.this.entries[i].contains("  >")) {
                  CPC.this.cleanEntries(i);
                  loadthis = CPC.this.entries[i];
                  if (CPC.this.users[i] != 0)
                    dr = dr + "|USER," + CPC.this.users[0] + ":"; 
                  break;
                } 
                if (CPC.this.entries[i].contains("#")) {
                  CPC.this.cleanEntries(i);
                  loadthis = CPC.this.entries[i];
                  if (CPC.this.users[i] != 0)
                    dr = dr + "|USER," + CPC.this.users[0] + ":"; 
                  break;
                } 
                if (CPC.this.entries[i].startsWith("DISC.") || CPC.this.entries[i].startsWith("DISK.")) {
                  CPC.this.cleanEntries(i);
                  loadthis = CPC.this.entries[i];
                  if (CPC.this.users[i] != 0)
                    dr = dr + "|USER," + CPC.this.users[0] + ":"; 
                  break;
                } 
                if (CPC.this.entries[i].endsWith(".BAS") || CPC.this.entries[i].endsWith(".BAS<") || CPC.this.entries[i].endsWith(".BAS<>") || CPC.this.entries[i].endsWith(".BAS>")) {
                  CPC.this.cleanEntries(i);
                  loadthis = CPC.this.entries[i];
                  if (CPC.this.users[i] != 0)
                    dr = dr + "|USER," + CPC.this.users[0] + ":"; 
                  break;
                } 
                if (i == CPC.this.entries.length - 1 && CPC.this.fdc.getSystem()) {
                  CPC.this.fromautoboot = true;
                  CPC.this.BasicAutoType("|CPM");
                  CPC.this.fdc.seek(0, 0);
                  return;
                } 
              } 
            } 
            if (loadthis.length() <= 1) {
              CPC.this.cleanEntries(notfound);
              loadthis = CPC.this.entries[notfound];
            } 
            typethis = typethis + dr;
            if (loadthis.endsWith(".BAS"))
              loadthis = loadthis.replace(".BAS", ""); 
            if (loadthis.endsWith("."))
              loadthis = loadthis.replace(".", ""); 
            typethis = typethis + "RUN\"" + loadthis + "\"\r\n";
            CPC.this.fromautoboot = true;
            CPC.this.BasicAutoType(typethis);
          }
        });
  }
  
  public void cleanEntries(int i) {
    this.entries[i] = this.entries[i].replaceAll(">", "");
    this.entries[i] = this.entries[i].replaceAll("<", "");
    this.entries[i] = this.entries[i].replaceAll(" ", "");
  }
  
  public int[] getUser() {
    return this.fdc.getUser();
  }
  
  public void diskInspector(int drive) {
    final int drivec = drive;
    this.loadFile.dispose();
    final int choosend = drive;
    this.enter = (String[][])null;
    this.entries = null;
    this.entries = this.fdc.getInfo(drive);
    if (this.entries == null)
      return; 
    System.out.println(this.entries.length + " entries found...");
    final int[] user = this.fdc.getUser();
    this.enter = new String[this.entries.length][4];
    int i = 0;
    for (; i < this.entries.length; i++) {
      if (this.entries[i].endsWith(">")) {
        this.entries[i] = this.entries[i].replaceAll(">", "");
        this.enter[i][2] = "*";
      } else {
        this.enter[i][2] = "";
      } 
      if (this.entries[i].endsWith("<")) {
        this.entries[i] = this.entries[i].replaceAll("<", "");
        this.enter[i][3] = "*";
      } else {
        this.enter[i][3] = "";
      } 
      this.enter[i][0] = this.entries[i];
      this.enter[i][1] = "USER:" + user[i];
    } 
    if (this.entries != null) {
      this.fileTable = new JTable(new driveTable());
      this.fileTable.repaint();
      this.fileTable.setShowGrid(true);
      this.fileTable.setFocusable(false);
      this.fileTable.setColumnSelectionAllowed(false);
      this.fileTable.setSelectionMode(0);
      this.fileTable.setFont(new Font("Monospaced", 1, 12));
      this.fileTable.setSelectionBackground(Color.BLUE);
      this.fileTable.setSelectionForeground(Color.WHITE);
      this.loadFile = new JDialog(new Frame(), "Load file from disk");
      this.loadFile.setAlwaysOnTop(true);
      this.loadFile.setLayout(new BorderLayout());
      this.loadFile.add(new JScrollPane(this.fileTable), "Center");
      this.loadFile.add(this.fileTable.getTableHeader(), "North");
      JPanel jp = new JPanel();
      if (this.fdc.getSystem() && drive == 0) {
        JButton jButton;
        jp.add(jButton = new JButton("Boot CPM"));
        jButton.setBorder(new BevelBorder(0));
        jButton.addActionListener(new ActionListener() {
              public void actionPerformed(ActionEvent ae) {
                CPC.this.fromautoboot = true;
                CPC.this.BasicAutoType("|CPM");
                CPC.this.loadFile.setVisible(false);
              }
            });
      } 
      JButton jb;
      jp.add(jb = new JButton("Run file"));
      jb.setBorder(new BevelBorder(0));
      jb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
              int choosen = CPC.this.fileTable.getSelectedRow();
              if (choosen >= 0) {
                System.out.println("file choosen:" + choosen);
                CPC.this.entries[choosen] = CPC.this.entries[choosen].replace(" ", "");
                if (CPC.this.entries[choosen].endsWith("."))
                  CPC.this.entries[choosen] = CPC.this.entries[choosen].replace(".", ""); 
                String us = "|USER," + user[choosen] + ":";
                String before = "";
                if (choosend == 0)
                  before = "|A:"; 
                if (choosend == 1)
                  before = "|B:"; 
                CPC.this.fromautoboot = true;
                CPC.this.BasicAutoType(before + us + "RUN\"" + CPC.this.entries[choosen] + "\"");
              } 
              CPC.this.loadFile.setVisible(false);
            }
          });
      jp.add(jb = new JButton("Load file"));
      jb.setBorder(new BevelBorder(0));
      jb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
              int choosen = CPC.this.fileTable.getSelectedRow();
              if (choosen >= 0) {
                System.out.println("file choosen:" + choosen);
                CPC.this.entries[choosen] = CPC.this.entries[choosen].replace(" ", "");
                if (CPC.this.entries[choosen].endsWith("."))
                  CPC.this.entries[choosen] = CPC.this.entries[choosen].replace(".", ""); 
                String us = "|USER," + user[choosen] + ":";
                String before = "";
                if (choosend == 0)
                  before = "|A:"; 
                if (choosend == 1)
                  before = "|B:"; 
                CPC.this.fromautoboot = true;
                CPC.this.BasicAutoType(before + us + "LOAD\"" + CPC.this.entries[choosen] + "\"");
              } 
              CPC.this.loadFile.setVisible(false);
            }
          });
      jp.add(jb = new JButton("Autoboot"));
      jb.setBorder(new BevelBorder(0));
      jb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
              if (CPC.this.fdc.showSys) {
                CPC.this.bootDisk(drivec, true);
              } else {
                CPC.this.bootDisk(drivec, false);
              } 
              CPC.this.loadFile.setVisible(false);
            }
          });
      if (this.fdc.showSys) {
        jp.add(jb = new JButton("Hide Systemfiles"));
        jb.setBorder(new BevelBorder(0));
        jb.addActionListener(new ActionListener() {
              public void actionPerformed(ActionEvent ae) {
                CPC.this.fdc.showSys = false;
                CPC.this.loadFile.setVisible(false);
                CPC.this.diskInspector(drivec);
              }
            });
      } else {
        jp.add(jb = new JButton("Show Systemfiles"));
        jb.setBorder(new BevelBorder(0));
        jb.addActionListener(new ActionListener() {
              public void actionPerformed(ActionEvent ae) {
                CPC.this.fdc.showSys = true;
                CPC.this.loadFile.setVisible(false);
                CPC.this.diskInspector(drivec);
              }
            });
      } 
      jp.add(jb = new JButton("Cancel"));
      jb.setBorder(new BevelBorder(0));
      jb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
              CPC.this.loadFile.setVisible(false);
            }
          });
      this.loadFile.add(jp, "Last");
      JTextField jl;
      this.loadFile.add(jl = new JTextField(this.entries.length + " directory entries found"), "First");
      jl.setEditable(false);
      this.loadFile.setSize(440, 300);
      this.loadFile.setResizable(false);
      Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
      this.loadFile.setLocation((d.width - (this.loadFile.getSize()).width) / 2, (d.height - (this.loadFile.getSize()).height) / 2);
      this.loadFile.setVisible(true);
    } 
  }
  
  protected class driveTable extends AbstractTableModel {
    String[][] data = CPC.this.enter;
    
    String[] columns = new String[] { "Filename:", "User:", "SYS:", "R/O:" };
    
    public int getColumnCount() {
      return 4;
    }
    
    public int getRowCount() {
      return this.data.length;
    }
    
    public String getColumnName(int c) {
      return this.columns[c];
    }
    
    public Object getValueAt(int rowIndex, int colIndex) {
      return this.data[rowIndex][colIndex];
    }
    
    public boolean isCellEditable(int rowIndex, int colIndex) {
      return false;
    }
  }
  
  public String unLHA(String name) {
    this.del = false;
    String ret = name;
    try {
      int BUFFSER_SIZE = 4096;
      byte[] buff = new byte[BUFFSER_SIZE];
      File check = new File(name);
      LhaFile file = new LhaFile(name);
      Iterator<LhaEntry> iter = file.entryIterator();
      while (iter.hasNext()) {
        LhaEntry entry = iter.next();
        File dst = entry.getFile();
        System.out.println("EXTRACT FILE        = " + entry.getFile());
        System.out.println("    METHOD          = " + entry.getMethod());
        System.out.println("    COMPRESSED SIZE = " + entry.getCompressedSize());
        System.out.println("    ORIGINAL SIZE   = " + entry.getOriginalSize());
        System.out.println("    TIME STAMP      = " + entry.getTimeStamp());
        if (entry.getMethod().equals("-lhd-")) {
          dst.mkdirs();
          continue;
        } 
        File parent = dst.getParentFile();
        if (parent != null)
          parent.mkdirs(); 
        InputStream in = new BufferedInputStream(file.getInputStream(entry), BUFFSER_SIZE);
        OutputStream out = new BufferedOutputStream(new FileOutputStream(check.getPath() + "_" + dst), BUFFSER_SIZE);
        while (true) {
          int len = in.read(buff, 0, BUFFSER_SIZE);
          if (len < 0)
            break; 
          out.write(buff, 0, len);
        } 
        out.flush();
        out.close();
        ret = check.getPath() + "_" + dst.getName();
      } 
      file.close();
      this.del = true;
    } catch (Exception exception) {}
    System.out.println(ret);
    return ret;
  }
  
  public void loadEntry(int index, int drive) {
    try {
      if (this.disknames[index].toLowerCase().endsWith("dsk")) {
        int drv = getCurrentDrive();
        setCurrentDrive(drive);
        DSK_Load(this.disknames[index], this.disks[index]);
        setCurrentDrive(drv);
      } 
      if (this.disknames[index].toLowerCase().endsWith("cdt") || this.disknames[index].toLowerCase().endsWith("tzx"))
        CDT_Load(this.disknames[index], this.disks[index]); 
      if (this.disknames[index].toLowerCase().endsWith("sna"))
        SNA_Load(this.disknames[index], this.disks[index]); 
      if (this.disknames[index].toLowerCase().endsWith("csw"))
        CSWLoad(this.disknames[index], this.disks[index]); 
    } catch (Exception er) {
      er.printStackTrace();
    } 
  }
  
  public void pressPlay() {
    this.TapeDrive.pressPlay();
  }
  
  public void pressRec() {
    this.TapeDrive.pressRec(false);
  }
  
  public void pressRew() {
    this.TapeDrive.pressRew();
  }
  
  public void pressFwd() {
    this.TapeDrive.pressFwd();
  }
  
  public void pressStop() {
    this.TapeDrive.pressStop();
  }
  
  public void pressPause() {
    this.TapeDrive.pressPause();
  }
  
  public void doACalc() {
    double a = this.aR;
    double i = this.iR;
    double l = this.lR;
    double d = this.dR / 10.0D;
    double n = this.nR;
    if (a > 0.0D && i > 0.0D && d > 0.0D) {
      n = (a - i) / d;
      l = Math.PI * (a * a - i * i) / d;
    } else if (a > 0.0D && i > 0.0D && n > 0.0D) {
      d = (a - i) / n;
      l = Math.PI * (a * a - i * i) / d;
    } else if (a > 0.0D && d > 0.0D && n > 0.0D) {
      i = a - d * n;
      l = Math.PI * (a * a - i * i) / d;
    } else if (i > 0.0D && d > 0.0D && n > 0.0D) {
      a = d * n + i;
      l = Math.PI * (a * a - i * i) / d;
    } else if (a > 0.0D && i > 0.0D && l > 0.0D) {
      d = Math.PI * (a * a - i * i) / l;
      n = (a - i) / d;
    } else if (a > 0.0D && d > 0.0D && l > 0.0D) {
      i = Math.sqrt((Math.PI * a * a - l * d) / Math.PI);
      n = (a - i) / d;
    } else if (i > 0.0D && d > 0.0D && l > 0.0D) {
      a = Math.sqrt((l * d + Math.PI * i * i) / Math.PI);
      n = (a - i) / d;
    } 
    this.aR = a;
    this.iR = i;
    this.lR = l;
    this.dR = d;
    this.nR = n;
  }
  
  public double getTapeCounter() {
    return getTapeCounter(tapeBandPosition);
  }
  
  public int getLeftRadius() {
    return (int)(getAmount((tapesample.length - tapeBandPosition)) / 16.5D);
  }
  
  public int getRightRadius() {
    return (int)(getAmount(tapeBandPosition) / 16.5D);
  }
  
  public double getRadius(double diff) {
    this.aR = -1.0D;
    this.iR = 1.1D;
    this.lR = getConsumedTapeLengthInCM(diff);
    this.nR = -1.0D;
    doACalc();
    return this.aR;
  }
  
  public double getAmount(double diff) {
    int totalSecs = tapesample.length / this.frequency * (tape_stereo ? 2 : 1);
    int minutes = totalSecs % 3600 / 60;
    int thickIndex = 0;
    if (minutes > 25)
      thickIndex = 1; 
    if (minutes > 40)
      thickIndex = 2; 
    this.dR = this.bandThickness[thickIndex];
    if (isCDT)
      this.dR -= 2.0E-4D; 
    this.aR = getRadius(diff);
    this.dR = this.bandThickness[thickIndex];
    if (isCDT)
      this.dR -= 2.0E-4D; 
    this.iR = 1.1D;
    this.lR = getConsumedTapeLengthInCM(diff);
    this.nR = -1.0D;
    doACalc();
    return this.nR;
  }
  
  public double getTapeCounter(double tapeBandPosition) {
    if (tapesample == null) {
      TapeDeck.counter = 0.0D;
      JEMU.counterb.setCounter(TapeDeck.counter);
      return 0.0D;
    } 
    this.timerDelay++;
    if (this.timerDelay > 25) {
      this.timerDelay = 0;
      printTapeTime();
    } 
    double left = getAmount(tapesample.length - tapeBandPosition);
    double total = getAmount(tapesample.length);
    double a = total - left;
    TapeDeck.counter = a * 0.865D;
    JEMU.counterb.setCounter(TapeDeck.counter);
    return TapeDeck.counter;
  }
  
  public double getConsumedTapeLengthInCM() {
    return getConsumedTapeLengthInCM(tapeBandPosition);
  }
  
  public double getConsumedTapeLengthInCM(double tapeBandPosition) {
    double totalSecs = tapeBandPosition / (this.frequency * (tape_stereo ? 2 : 1));
    double cmConsumed = totalSecs * 4.7625D;
    return cmConsumed;
  }
  
  public void jumpTape(final int count) {
    Thread v = new Thread() {
        public void run() {
          if (count < 0)
            return; 
          int bandPos = CPC.tapeBandPosition;
          try {
            CPC.tapeBandPosition = CPC.tapesample.length - 1000;
            int max = (int)CPC.this.getTapeCounter(CPC.tapeBandPosition);
            if (max < count) {
              CPC.tapeBandPosition = bandPos;
              return;
            } 
            while (max > count) {
              CPC.tapeBandPosition -= 120000;
              max = (int)CPC.this.getTapeCounter(CPC.tapeBandPosition);
              CPC.this.printTapeTime();
              if (CPC.tapeBandPosition < 0) {
                CPC.tapeBandPosition = bandPos;
                break;
              } 
            } 
          } catch (Exception e) {
            CPC.tapeBandPosition = bandPos;
          } 
          TapeDeck.TapeCounter.setCounter(CPC.this.getTapeCounter());
          CPC.this.printTapeTime();
        }
      };
    v.start();
  }
  
  public String getCounter() {
    int counter = (int)getTapeCounter();
    String before = "";
    if (counter > 999 || counter < 0) {
      counter = this.lastcounter;
    } else {
      this.lastcounter = counter;
    } 
    if (counter <= 99)
      before = "0"; 
    if (counter <= 9)
      before = "00"; 
    return before + counter;
  }
  
  public static int moviecount = 0;
  
  public static int maxcount = 0;
  
  protected int smode;
  
  public static boolean initmovie;
  
  protected boolean hasMP3;
  
  public static int movieFPS = 30;
  
  byte[] moviePalette;
  
  boolean playMP3;
  
  int infotimer;
  
  protected int[] GateArrayINKs;
  
  public void restoreMovie(final String filename, final byte[] data) {
    reset();
    Thread thread = new Thread() {
        public void run() {
          try {
            System.arraycopy(data, 0, CPC.this.moviePalette, 0, CPC.this.moviePalette.length);
            CPC.this.infotimer = 1;
            CPC.playmovie = true;
            String mp3name = filename;
            mp3name = mp3name.substring(0, mp3name.length() - 4);
            mp3name = mp3name + ".mp3";
            File b = new File(mp3name);
            if (b.exists()) {
              CPC.this.loadFile(0, mp3name);
              CPC.this.hasMP3 = true;
            } 
            CPC.movie = (byte[][])null;
            System.gc();
            CPC.movie = new byte[(data.length - 17) / 16384][16384];
            System.out.println("Movie has " + CPC.movie.length + " frames");
            CPC.initmovie = false;
            int testFPS = data[0] & 0xFF;
            int off = 0;
            if (testFPS > 3) {
              CPC.movieFPS = testFPS;
              off++;
            } else {
              CPC.movieFPS = 20;
            } 
            CPC.this.smode = data[off];
            int mcount = 0;
            int mlen = 0;
            for (int i = 17 + off; i < data.length && mcount <= 24999; i++) {
              CPC.movie[mcount][mlen] = data[i];
              mlen++;
              if (mlen == 16384) {
                mlen = 0;
                mcount++;
              } 
            } 
            System.out.println("Movie has " + mcount + " frames");
            CPC.maxcount = mcount - 1;
            CPC.moviecount = 0;
            CPC.resync = true;
          } catch (Exception exception) {}
        }
      };
    thread.start();
  }
  
  public void stopMovie() {
    System.out.println("Stopping Movie");
    moviecount = 0;
    playmovie = false;
    stopTapeMotor();
    this.playMP3 = false;
    this.hasMP3 = false;
    reset();
  }
  
  public void playMovie() {
    try {
      if (this.hasMP3 && !this.mp3loaded)
        return; 
      if (this.infotimer > 0) {
        this.infotimer++;
        if (this.infotimer == 10) {
          INK(0, 0);
          INK(1, 26);
          INK(16, 2);
          this.fromautoboot = true;
          BasicAutoType("'    **** JavaCPC MoviePlayer *****                                               Movie info: " + movieFPS + " FPS - " + maxcount + " Frames                    ");
          reSync();
        } 
        if (this.infotimer == 90) {
          reSync();
          int testFPS = this.moviePalette[0] & 0xFF;
          int off = 0;
          if (testFPS > 3) {
            movieFPS = testFPS;
            off++;
          } else {
            movieFPS = 20;
          } 
          this.smode = this.moviePalette[off];
          INK(-1, this.moviePalette[off + 1]);
          for (int i = off + 1; i < off + 17; i++)
            INK(i - 1 - off, this.moviePalette[i]); 
          this.fromautoboot = true;
          BasicAutoType("MODE " + this.smode);
        } 
        if (this.infotimer == 120)
          this.infotimer = 0; 
        return;
      } 
      if (!this.playMP3 && this.mp3loaded && this.hasMP3) {
        startTapeMotor();
        this;
        tapeBandPosition = 0;
        this.playMP3 = true;
      } 
      if (moviecount >= maxcount) {
        if (MovieMaker.loop.isSelected()) {
          System.out.println("Repeating Movie");
          moviecount = 0;
          if (this.hasMP3) {
            this;
            tapeBandPosition = 0;
            this.TapeDrive.pressPlay();
            startTapeMotor();
            this.playMP3 = true;
          } 
        } else {
          stopMovie();
        } 
        return;
      } 
      System.arraycopy(movie[moviecount++], 0, GateArray.screenmemory, 49152, 16384);
    } catch (Exception e) {
      stopMovie();
    } 
  }
  
  public void INK(int pen, int ink) {
    if (pen == 16)
      pen = -1; 
    int addressA = 47060;
    int addressB = 47077;
    if (Switches.ROM.equals("CPC464")) {
      addressA = 45529;
      addressB = 45546;
    } 
    POKE(addressA + 1 + pen, this.GateArrayINKs[ink]);
    POKE(addressB + 1 + pen, this.GateArrayINKs[ink]);
  }
  
  public void INK(int pen, int ink, int inkb) {
    if (pen == 16)
      pen = -1; 
    int addressA = 47060;
    int addressB = 47077;
    if (Switches.ROM.equals("CPC464")) {
      addressA = 45529;
      addressB = 45546;
    } 
    POKE(addressA + 1 + pen, this.GateArrayINKs[ink]);
    POKE(addressB + 1 + pen, this.GateArrayINKs[inkb]);
  }
  
  public void softReset() {
    this.tapei = this.tapep = 0;
    disableresync = false;
    this.ssa1.reset();
    this.doLoad = 0;
    this.portB = 0;
    YMControl.displaycount1 = 0;
    YMControl.displaycount2 = 0;
    YMControl.DisplayStart = 0;
    this.psg.changeClockSpeed(1000000);
    st_mode = false;
    zx_mode = false;
    if (YM_Play) {
      YM_Play = false;
      YM_Stop = true;
      System.out.println("Playback stopped...");
    } 
    Switches.turbo = 1;
    JEMU.turbo.setState(false);
    Desktop.jCheckBox8.setSelected(false);
    this.z80.setPC(0);
    this.fdc.reset();
    memory.reset();
    reSync();
    this.z80.reset();
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\CPC.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */