package jemu.system.cpc;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import jemu.core.device.Device;

public class Baslist {
  protected int charPos = 0;
  
  static String[] Keywords = new String[] { 
      "AFTER", "AUTO", "BORDER", "CALL", "CAT", "CHAIN", "CLEAR", "CLG", "CLOSEIN", "CLOSEOUT", 
      "CLS", "CONT", "DATA", "DEF", "DEFINT", "DEFREAL", "DEFSTR", "DEG", "DELETE", "DIM", 
      "DRAW", "DRAWR", "EDIT", "ELSE", "END", "ENT", "ENV", "ERASE", "ERROR", "EVERY", 
      "FOR", "GOSUB", "GOTO", "IF", "INK", "INPUT", "KEY", "LET", "LINE", "LIST", 
      "LOAD", "LOCATE", "MEMORY", "MERGE", "MID$", "MODE", "MOVE", "MOVER", "NEXT", "NEW", 
      "ON", "ON BREAK", "ON ERROR GOTO", "SQ", "OPENIN", "OPENOUT", "ORIGIN", "OUT", "PAPER", "PEN", 
      "PLOT", "PLOTR", "POKE", "PRINT", "'", "RAD", "RANDOMIZE", "READ", "RELEASE", "REM", 
      "RENUM", "RESTORE", "RESUME", "RETURN", "RUN", "SAVE", "SOUND", "SPEED", "STOP", "SYMBOL", 
      "TAG", "TAGOFF", "TROFF", "TRON", "WAIT", "WEND", "WHILE", "WIDTH", "WINDOW", "WRITE", 
      "ZONE", "DI", "EI", "FILL", "GRAPHICS", "MASK", "FRAME", "CURSOR", null, "ERL", 
      "FN", "SPC", "STEP", "SWAP", null, null, "TAB", "THEN", "TO", "USING", 
      ">", "=", ">=", "<", "<>", "<=", "+", "-", "*", "/", 
      "^", "\\", "AND", "MOD", "OR", "XOR", "NOT", null };
  
  static String[] AdditionalKeywords = new String[] { 
      "ABS", "ASC", "ATN", "CHR$", "CINT", "COS", "CREAL", "EXP", "FIX", "FRE", 
      "INKEY", "INP", "INT", "JOY", "LEN", "LOG", "LOG10", "LOWER$", "PEEK", "REMAIN", 
      "SGN", "SIN", "SPACE$", "SQ", "SQR", "STR$", "TAN", "UNT", "UPPER$", "VAL", 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, "EOF", "ERR", "HIMEM", "INKEY$", "PI", "RND", 
      "TIME", "XPOS", "YPOS", "DERR", null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, "BIN$", "DEC$", "HEX$", "INSTR", "LEFT$", "MAX", "MIN", 
      "POS", "RIGHT$", "ROUND", "STRING$", "TEST", "TESTR", "COPYCHR$", "VPOS", null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null, null, null, null, null, 
      null, null, null, null, null, null };
  
  String result = "";
  
  protected static final String HEX_CHARS = "0123456789ABCDEF";
  
  static String str;
  
  protected String DisplayVariable(String pLinePtr) {
    char ch;
    do {
      ch = pLinePtr.charAt(this.charPos);
      this.charPos++;
      this.result += (char)(ch & 0x7F);
    } while ((ch & 0x80) == 0);
    return pLinePtr;
  }
  
  public double Round(double r, int decimalPlace) {
    BigDecimal bd = new BigDecimal(r);
    bd = bd.setScale(decimalPlace, RoundingMode.HALF_EVEN);
    r = bd.doubleValue();
    return r;
  }
  
  protected void TranslateLine(String pLinePtr, long LineLength) {
    char Token;
    String pLocalLinePtr = pLinePtr;
    this.charPos = 0;
    do {
      int Num;
      short Number;
      int bIgnoreDigit, j;
      String r;
      byte[] d;
      char[] bufFile;
      double f, exp;
      String e;
      char ch, Keyword;
      Token = pLocalLinePtr.charAt(this.charPos);
      this.charPos++;
      switch (Token) {
        case '\000':
          this.result += "x666666666xZZyyT222T";
          break;
        case '\001':
          if (pLocalLinePtr.charAt(this.charPos) == '' || pLocalLinePtr.charAt(this.charPos) == 'À')
            break; 
          this.result += ":";
        case '\002':
          this.charPos += 2;
          pLocalLinePtr = DisplayVariable(pLocalLinePtr);
          this.result += "%";
        case '\003':
          this.charPos += 2;
          pLocalLinePtr = DisplayVariable(pLocalLinePtr);
          this.result += "$";
        case '\004':
          this.charPos += 2;
          pLocalLinePtr = DisplayVariable(pLocalLinePtr);
          this.result += "!";
        case '\005':
        case '\006':
        case '\007':
        case '\b':
        case '\t':
        case '\n':
        case '\013':
        case '\f':
        case '\r':
          this.charPos += 2;
          pLocalLinePtr = DisplayVariable(pLocalLinePtr);
        case '\016':
        case '\017':
        case '\020':
        case '\021':
        case '\022':
        case '\023':
        case '\024':
        case '\025':
        case '\026':
        case '\027':
        case '\030':
          Num = Token - 14;
          this.result += Num & 0xFF;
        case '\031':
          Number = (short)(pLocalLinePtr.charAt(this.charPos) & 0xFF);
          this.result += Number & 0xFF;
          this.charPos++;
        case '\032':
          Number = (short)(pLocalLinePtr.charAt(this.charPos) & 0xFF | (pLocalLinePtr.charAt(this.charPos + 1) & 0xFF) << 8);
          this.result += Number & 0xFFFF;
          this.charPos += 2;
        case '\033':
          bIgnoreDigit = 1;
          Number = (short)(pLocalLinePtr.charAt(this.charPos) & 0xFF | (pLocalLinePtr.charAt(this.charPos + 1) & 0xFF) << 8);
          this.result += "&X";
          for (j = 0; j < 16; j++) {
            int bd = Number >> 15 - j & 0x1;
            if (bd != 0)
              bIgnoreDigit = 0; 
            if (bIgnoreDigit == 0)
              this.result += (char)(48 + bd); 
          } 
          this.charPos += 2;
        case '\034':
          Number = (short)(pLocalLinePtr.charAt(this.charPos) & 0xFF | (pLocalLinePtr.charAt(this.charPos + 1) & 0xFF) << 8);
          r = hex((short)(Number & 0xFFFF));
          while (r.startsWith("0"))
            r = r.substring(1); 
          this.result += "&" + r;
          this.charPos += 2;
        case '\035':
          Number = (short)(pLocalLinePtr.charAt(this.charPos) & 0xFF | (pLocalLinePtr.charAt(this.charPos + 1) & 0xFF) << 8);
          this.actlinenumber = Number & 0xFFFF;
          d = new byte[2];
          d[0] = (byte)CPC.memory.readWriteByte(this.actlinenumber + 3);
          d[1] = (byte)CPC.memory.readWriteByte(this.actlinenumber + 4);
          this.result += Device.getWord(d, 0);
          this.charPos += 2;
        case '\036':
          Number = (short)(pLocalLinePtr.charAt(this.charPos) & 0xFF | (pLocalLinePtr.charAt(this.charPos + 1) & 0xFF) << 8);
          this.result += Number & 0xFFFF;
          this.charPos += 2;
        case '\037':
          bufFile = new char[5];
          bufFile[0] = pLocalLinePtr.charAt(this.charPos);
          bufFile[1] = pLocalLinePtr.charAt(this.charPos + 1);
          bufFile[2] = pLocalLinePtr.charAt(this.charPos + 2);
          bufFile[3] = pLocalLinePtr.charAt(this.charPos + 3);
          bufFile[4] = pLocalLinePtr.charAt(this.charPos + 4);
          f = (((bufFile[3] & 0x7F) << 24) + (bufFile[2] << 16) + (bufFile[1] << 8) + bufFile[0]);
          f = 1.0D + f / Math.pow(2.0D, 31.0D);
          if ((bufFile[3] & 0x80) != 0)
            f = -f; 
          exp = (bufFile[4] & 0xFF) - 129.0D;
          e = "" + Round(f * Math.pow(2.0D, exp), 9);
          if (e.contains("E-")) {
            String b = e;
            while (!b.startsWith("E-"))
              b = b.substring(1); 
            b = b.replace("E-", "");
            while (!e.endsWith("E"))
              e = e.substring(0, e.length() - 1); 
            e = e.replace("E", "");
            e = e.replace(".", "");
            int c = Integer.parseInt(b);
            String t = "";
            for (int i = 1; i < c; i++)
              t = "0" + t; 
            t = t + e;
            while (t.endsWith("0"))
              t = t.substring(0, t.length() - 1); 
            t = "0." + t;
            e = t;
          } 
          this.result += e;
          this.charPos += 5;
        case '"':
          ch = Token;
          this.result += ch;
          do {
            ch = pLocalLinePtr.charAt(this.charPos);
            this.charPos++;
            if (ch == '\000') {
              this.charPos--;
            } else {
              this.result += ch;
            } 
          } while (ch != '"' && ch != '\000');
        case 'ÿ':
          Keyword = pLocalLinePtr.charAt(this.charPos);
          this.charPos++;
          if (AdditionalKeywords[Keyword & 0xFF] != null)
            this.result += AdditionalKeywords[Keyword & 0xFF]; 
        case '|':
          this.result += "|";
          this.charPos++;
          pLocalLinePtr = DisplayVariable(pLocalLinePtr);
        default:
          if (Token >= '' && Token <= 'þ') {
            if (Keywords[Token - 128] != null)
              this.result += Keywords[Token - 128]; 
            if (Token == '¿') {
              char NextToken = pLocalLinePtr.charAt(this.charPos);
              if (NextToken == 'ÿ' || (NextToken >= '' && NextToken <= 'þ') || (NextToken >= '\002' && NextToken <= '\r'))
                this.result += " "; 
            } 
          } else if (Token >= ' ' && Token <= '') {
            this.result += Token;
          } else {
            if (Keywords[Token & 0x7F] == null)
              break; 
            this.result += Keywords[Token & 0x7F];
          } 
      } 
    } while (Token != '\000');
  }
  
  final String lineholder = "fejo23435rj2djejfuiuigheroifjioer";
  
  final String placeholder = "x666666666xZZyyT222T";
  
  protected String formattedString(String replace) {
    replace = replace.replace("x666666666xZZyyT222T", "");
    return replace;
  }
  
  protected String formatASCII(String input) {
    String result = "";
    for (int i = 0; i < input.length(); i++) {
      if (input.charAt(i) < ' ' || input.charAt(i) > '}') {
        result = result + (char)(input.charAt(i) + 255);
      } else {
        result = result + input.charAt(i);
      } 
    } 
    result = "\"" + result + "\"";
    return result;
  }
  
  protected void format() {
    if (!this.result.contains("\"")) {
      this.result = formattedString(this.result);
    } else {
      boolean string = false;
      String[] res = this.result.split("\"");
      int i;
      for (i = 0; i < res.length; i++) {
        if (!string) {
          res[i] = formattedString(res[i]);
        } else {
          res[i] = formatASCII(res[i]);
        } 
        string = !string;
      } 
      this.result = "";
      for (i = 0; i < res.length; i++)
        this.result += res[i]; 
    } 
  }
  
  public static int getWord(byte[] buffer, int offs) {
    return buffer[offs] & 0xFF | buffer[offs + 1] << 8 & 0xFF00;
  }
  
  public static int ChecksumAMSDOS(byte[] pHeader) {
    int Checksum = 0;
    for (int i = 0; i < 67; i++) {
      int CheckSumByte = pHeader[i] & 0xFF;
      Checksum += CheckSumByte;
    } 
    return Checksum;
  }
  
  public static boolean CheckAMSDOS(byte[] pHeader) {
    try {
      int CalculatedChecksum = ChecksumAMSDOS(pHeader);
      int ChecksumFromHeader = pHeader[67] & 0xFF | (pHeader[68] & 0xFF) << 8;
      if (ChecksumFromHeader == CalculatedChecksum && ChecksumFromHeader != 0)
        return true; 
      return false;
    } catch (Exception e) {
      return false;
    } 
  }
  
  public String LIST(String filename) {
    File test = new File(filename);
    if (!test.exists())
      test = new File(filename + ".bas"); 
    if (!test.exists())
      return ""; 
    String basresult = "";
    try {
      Baslist list = new Baslist();
      BufferedInputStream bin = new BufferedInputStream(new FileInputStream(test));
      byte[] data = new byte[bin.available()];
      bin.read(data);
      bin.close();
      if (CheckAMSDOS(data)) {
        int length = getWord(data, 24);
        byte[] newdata = new byte[length];
        System.arraycopy(data, 128, newdata, 0, length);
        data = new byte[length];
        System.arraycopy(newdata, 0, data, 0, length);
      } 
      int baspos = 0;
      while (baspos < data.length - 2) {
        int linelength = getWord(data, baspos) - 4;
        if (linelength != 0) {
          int linenumber = getWord(data, baspos + 2);
          String code = "";
          baspos += 4;
          int pos = 0;
          for (int i = baspos; i < baspos + linelength; i++) {
            code = code + (char)(data[i] & 0xFF);
            pos++;
          } 
          list.result = "";
          try {
            list.TranslateLine(code, linelength);
            if (list.result.length() > 255)
              System.out.println("Line too long in line " + linenumber); 
            baspos += linelength;
          } catch (Exception e) {
            return basresult.toString().replace("x666666666xZZyyT222T", "");
          } 
          basresult = basresult + linenumber;
          basresult = basresult + list.result + "\r\n";
        } 
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
    return basresult.toString().replace("x666666666xZZyyT222T", "");
  }
  
  public int[] addresses = new int[65537];
  
  public int[] lines = new int[65537];
  
  public String[] codes = new String[65537];
  
  int actlinenumber;
  
  public String LIST(byte[] data) {
    StringBuilder basresult = new StringBuilder();
    try {
      Baslist list = new Baslist();
      if (CheckAMSDOS(data)) {
        int length = getWord(data, 24);
        byte[] newdata = new byte[length];
        System.arraycopy(data, 128, newdata, 0, length);
        data = new byte[length];
        System.arraycopy(newdata, 0, data, 0, length);
      } 
      int baspos = 0;
      int adrpos = 0;
      for (int i = 0; i < this.lines.length; i++) {
        this.lines[i] = 0;
        this.addresses[i] = 0;
        this.codes[i] = null;
      } 
      while (baspos < data.length - 2) {
        int linelength = getWord(data, baspos) - 4;
        if (linelength != 0) {
          int linenumber = getWord(data, baspos + 2);
          this.lines[adrpos] = linenumber;
          this.addresses[adrpos] = baspos + 2 + 368;
          String code = "";
          baspos += 4;
          int pos = 0;
          for (int j = baspos; j < baspos + linelength; j++) {
            try {
              code = code + (char)(data[j] & 0xFF);
            } catch (Exception e) {
              break;
            } 
            pos++;
          } 
          list.result = "";
          try {
            list.TranslateLine(code, linelength);
            list.format();
            if (list.result.length() > 255)
              System.out.println("Line too long in line " + linenumber); 
            baspos += linelength;
          } catch (Exception e) {
            String str = basresult.toString().replace("x666666666xZZyyT222T", "");
            if (str.endsWith("\r\n"))
              str = str.substring(0, str.length() - 2); 
            return str;
          } 
          this.codes[adrpos] = linenumber + " " + list.result.replace("fejo23435rj2djejfuiuigheroifjioer", "" + linenumber);
          adrpos++;
          basresult.append(linenumber + " ");
          basresult.append(list.result.replace("fejo23435rj2djejfuiuigheroifjioer", "" + linenumber) + "\r\n");
        } 
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
    String d = basresult.toString().replace("x666666666xZZyyT222T", "");
    if (d.endsWith("\r\n"))
      d = d.substring(0, d.length() - 2); 
    return d;
  }
  
  public static String hex(byte value) {
    str = "XY";
    str = str.replace('X', "0123456789ABCDEF".charAt((value & 0xF0) >> 4));
    str = str.replace('Y', "0123456789ABCDEF".charAt(value & 0xF));
    return str;
  }
  
  public static String hex(short value) {
    return hex((byte)(value >> 8)) + hex((byte)value);
  }
  
  public static String hex(int value) {
    return hex((short)(value >> 16)) + hex((short)value);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\system\cpc\Baslist.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */