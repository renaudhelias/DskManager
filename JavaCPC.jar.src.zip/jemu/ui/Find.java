package jemu.ui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;

public class Find extends JFrame {
  public JCheckBox ashex;
  
  public JTextField input;
  
  public JButton jButton2;
  
  private JLabel jLabel1;
  
  public JButton search;
  
  public JCheckBox wild;
  
  public Find() {
    initComponents();
  }
  
  private void initComponents() {
    this.input = new JTextField();
    this.jLabel1 = new JLabel();
    this.ashex = new JCheckBox();
    this.search = new JButton();
    this.jButton2 = new JButton();
    this.wild = new JCheckBox();
    setTitle("Search memory");
    setResizable(false);
    this.jLabel1.setText("Search for:");
    this.ashex.setText("as HEX data (input like 00 AB CD EF)");
    this.ashex.setFocusPainted(false);
    this.ashex.setFocusable(false);
    this.search.setText("Search");
    this.search.setFocusPainted(false);
    this.search.setFocusable(false);
    this.jButton2.setText("Cancel");
    this.jButton2.setFocusPainted(false);
    this.jButton2.setFocusable(false);
    this.jButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Find.this.jButton2ActionPerformed(evt);
          }
        });
    this.wild.setSelected(true);
    this.wild.setText("Use ? as wildcard");
    this.wild.setFocusPainted(false);
    this.wild.setFocusable(false);
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
          .addContainerGap(115, 32767)
          .addComponent(this.search)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.jButton2)
          .addContainerGap())
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.wild)
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.jLabel1)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.input, -2, 182, -2))
            .addComponent(this.ashex))
          .addContainerGap(-1, 32767)));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jLabel1)
            .addComponent(this.input, -2, -1, -2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.ashex)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.wild)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jButton2)
            .addComponent(this.search))
          .addContainerGap(-1, 32767)));
    pack();
  }
  
  private void jButton2ActionPerformed(ActionEvent evt) {
    setVisible(false);
  }
  
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new Find()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\Find.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */