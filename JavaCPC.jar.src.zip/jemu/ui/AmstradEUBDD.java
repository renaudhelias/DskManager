package jemu.ui;

import JCPC.core.Util;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Scanner;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import jemu.settings.Settings;
import jemu.system.cpc.CPC;

public class AmstradEUBDD extends JPanel {
  CPC cpc;
  
  public JFrame fram;
  
  int lastfind;
  
  int lastrow;
  
  Object[][] rows;
  
  public static void main(String[] args) {
    AmstradEUBDD bdd = new AmstradEUBDD(null);
    JFrame fram = new JFrame("BDD - CPC File Databases");
    fram.setDefaultCloseOperation(3);
    fram.setLayout(new BorderLayout());
    fram.add(bdd, "Center");
    fram.pack();
    fram.setVisible(true);
  }
  
  protected void search(String s) {
    if (s.length() < 1)
      return; 
    boolean found = false;
    int i;
    for (i = this.lastfind; i < this.rows.length; i++) {
      if (this.rows[i][0].toString().toLowerCase().contains(s.toLowerCase())) {
        this.bdd.setRowSelectionInterval(i, i);
        this.lastfind = i + 1;
        this.bdd.scrollRectToVisible(this.bdd.getCellRect(i, 0, true));
        found = true;
        selectGame(false);
        break;
      } 
    } 
    if (!found)
      for (i = 0; i < this.lastfind; i++) {
        if (this.rows[i][0].toString().toLowerCase().contains(s.toLowerCase())) {
          this.bdd.setRowSelectionInterval(i, i);
          this.lastfind = i + 1;
          this.bdd.scrollRectToVisible(this.bdd.getCellRect(i, 0, true));
          found = true;
          selectGame(false);
          break;
        } 
      }  
    if (!found)
      this.lastfind = 0; 
  }
  
  void selectGame(boolean update) {
    try {
      int k = this.bdd.getSelectedRow();
      if (this.lastrow != k) {
        this.lastrow = k;
        if (this.wasenabled)
          this.auto.setSelected(true); 
        this.wasenabled = false;
      } 
      readDetail(k);
      if (update)
        this.jTextField1.setText(this.rows[k][0].toString()); 
    } catch (Exception exception) {}
  }
  
  public void buildBDD() {
    if (this.fram == null) {
      this.fram = new JFrame("BDD - CPC File Databases");
      this.fram.setDefaultCloseOperation(1);
      this.fram.setLayout(new BorderLayout());
      this.fram.setResizable(false);
      this.fram.add(this, "Center");
      this.fram.pack();
    } 
    JEMU.centerFrame(this.fram);
    this.fram.setVisible(true);
  }
  
  protected void browse() {
    String url = this.urls[this.domains.getSelectedIndex()];
    if (this.domains.getSelectedIndex() == 0) {
      String a = "/modules/pdb/?id=" + this.actiondetail;
      url = url + a;
    } else if (this.domains.getSelectedIndex() == 1 || this.domains.getSelectedIndex() == 2) {
      String a = this.gameid.replace(".png", "");
      a = a.replace("./", "");
      String[] g = a.split("/");
      url = url + "?id=" + g[0] + "&title=" + g[1];
    } 
    if (Desktop.isDesktop && 0 == this.browser.getSelectedIndex()) {
      Desktop.openPage(url);
    } else {
      JEMU.openWebPage(url);
    } 
  }
  
  String[] urls = new String[] { "http://amstrad.eu", "http://cpc.devilmarkus.de/game.php", "http://cpc.devilmarkus.de/demo.php", "https://cpc-power.com/", "http://cngsoft.no-ip.org/", "" };
  
  String[] icon = new String[] { "amstradeu.png", "javacpc.png", "javacpc.png", "cpcpower_160x18.jpg", "cngsoft.gif" };
  
  String[] domain = new String[] { "http://amstrad.eu/modules/pdb/", "http://cpc.devilmarkus.de/games/", "http://cpc.devilmarkus.de/demos/", "https://www.cpc-power.com/_javacpc_markus/", "http://cngsoft.no-ip.org/" };
  
  protected String detailist = this.domain[1] + "api.php?action=detailist";
  
  String[] result;
  
  String[] detail;
  
  String[] bootoption;
  
  String[] rrr;
  
  String[] screenshot;
  
  String actiondetail;
  
  String file_id;
  
  int screenid;
  
  String[] dsk;
  
  String[] sna;
  
  String[] dskn;
  
  String[] snan;
  
  String[] mediadata;
  
  int dskcount;
  
  int snacount;
  
  String gameid;
  
  protected boolean backup;
  
  boolean isshowing;
  
  boolean isloading;
  
  FileDialog filedia;
  
  boolean breakme;
  
  String buttonLoad;
  
  String buttonBackup;
  
  String buttonBackupRunning;
  
  String[][] media;
  
  protected DefaultTableModel model;
  
  boolean isBuilding;
  
  boolean wasenabled;
  
  private JCheckBox auto;
  
  private JButton bck;
  
  private JTable bdd;
  
  private JLabel bootinfo;
  
  private JComboBox browser;
  
  private JTextField disk;
  
  private JComboBox domains;
  
  private JButton fwd;
  
  private JButton jButton1;
  
  private JButton jButton2;
  
  private JButton jButton3;
  
  private JButton jButton4;
  
  private JButton jButton5;
  
  private JCheckBox jCheckBox1;
  
  private JCheckBox jCheckBox2;
  
  private JLabel jLabel1;
  
  private JLabel jLabel2;
  
  private JLabel jLabel3;
  
  private JPanel jPanel1;
  
  private JPanel jPanel2;
  
  private JPanel jPanel3;
  
  private JScrollPane jScrollPane1;
  
  private JTextField jTextField1;
  
  private JButton load;
  
  private JCheckBox prefer;
  
  private JProgressBar prog;
  
  private JLabel shot;
  
  private JTextField snap;
  
  protected String getDetail(String a) {
    try {
      URL url = new URL(this.domain[this.domains.getSelectedIndex()] + "api.php?action=detail&id=" + a);
      this.actiondetail = a;
      Scanner s = new Scanner(url.openStream());
      StringBuilder b = new StringBuilder();
      while (s.hasNextLine())
        b.append(s.nextLine()); 
      String c = this.file_id = b.toString();
      if (c.contains("<media"))
        while (!c.startsWith("<media"))
          c = c.substring(1);  
      if (c.contains("</game")) {
        while (c.contains("</game"))
          c = c.substring(0, c.length() - 1); 
        c = c.replace("</gam", "");
      } 
      return c;
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public AmstradEUBDD(CPC cpc) {
    this.screenid = 0;
    this.backup = false;
    this.breakme = false;
    this.buttonLoad = "Load into JavaCPC";
    this.buttonBackup = "Create local backup";
    this.buttonBackupRunning = "Backup is running...";
    this.isBuilding = false;
    this.cpc = cpc;
    initComponents();
    this.jCheckBox1.setSelected(false);
    this.backup = false;
    this.jCheckBox1.setVisible(false);
    this.jCheckBox2.setVisible(false);
    this.domains.setSelectedIndex(Settings.getInt("bdd_lastlist", 1));
    if (!Desktop.isDesktop)
      this.browser.setVisible(false); 
    readList();
  }
  
  protected void readDetail(int i) {
    String d = this.result[i];
    String[] v = d.split(" ");
    int g;
    for (g = 0; g < v.length; g++) {
      if (v[g].toLowerCase().contains("id=")) {
        String a = v[g];
        a = getString("id=", a);
        this.detail[i] = getDetail(a);
      } 
    } 
    this.mediadata = new String[(this.media[i]).length];
    for (g = 0; g < this.mediadata.length; g++)
      this.mediadata[g] = this.media[i][g]; 
    int count = 0;
    int j;
    for (j = 0; j < this.mediadata.length; j++) {
      if (this.mediadata[j].toLowerCase().contains("screenshot"))
        count++; 
    } 
    this.screenshot = new String[count];
    this.bootoption = new String[this.result.length];
    this.screenid = 0;
    this.dsk = null;
    this.sna = null;
    count = 0;
    this.dsk = new String[20];
    this.sna = new String[20];
    this.dskn = new String[20];
    this.snan = new String[20];
    this.dskcount = 0;
    this.snacount = 0;
    this.bootinfo.setText("AUTOBOOT");
    for (j = 0; j < this.mediadata.length; j++) {
      if (this.mediadata[j].toLowerCase().contains("bootoption")) {
        String boot = this.mediadata[j];
        while (!boot.toLowerCase().startsWith("file="))
          boot = boot.substring(1); 
        boot = boot.substring(6);
        while (boot.contains("\""))
          boot = boot.substring(0, boot.length() - 1); 
        this.bootoption[j] = boot;
        this.bootinfo.setText(boot);
      } 
      if (this.mediadata[j].toLowerCase().contains("disquette")) {
        String dskfile = this.mediadata[j];
        if (!this.detailist.contains("cpc-power")) {
          while (!dskfile.toLowerCase().startsWith("file="))
            dskfile = dskfile.substring(1); 
        } else {
          while (!dskfile.toLowerCase().startsWith("name="))
            dskfile = dskfile.substring(1); 
        } 
        dskfile = dskfile.substring(6);
        while (dskfile.contains("\""))
          dskfile = dskfile.substring(0, dskfile.length() - 1); 
        while (!this.mediadata[j].startsWith("\""))
          this.mediadata[j] = this.mediadata[j].substring(1); 
        this.mediadata[j] = this.mediadata[j].substring(1);
        while (this.mediadata[j].contains("\""))
          this.mediadata[j] = this.mediadata[j].substring(0, this.mediadata[j].length() - 1); 
        if (!dskfile.toLowerCase().contains(".dsk") && !dskfile.toLowerCase().contains(".cdt") && !dskfile.toLowerCase().contains(".tap"))
          dskfile = dskfile + ".dsk"; 
        dskfile = dskfile.replace("\\", "");
        this.dskn[this.dskcount] = dskfile;
        this.dsk[this.dskcount++] = this.mediadata[j];
      } 
      if (this.mediadata[j].toLowerCase().contains("snapshot")) {
        String dskfile = this.mediadata[j];
        while (!dskfile.toLowerCase().startsWith("file="))
          dskfile = dskfile.substring(1); 
        dskfile = dskfile.substring(6);
        dskfile = dskfile.substring(0, dskfile.length() - 4);
        while (!this.mediadata[j].startsWith("\""))
          this.mediadata[j] = this.mediadata[j].substring(1); 
        this.mediadata[j] = this.mediadata[j].substring(1);
        while (this.mediadata[j].contains("\""))
          this.mediadata[j] = this.mediadata[j].substring(0, this.mediadata[j].length() - 1); 
        this.snan[this.snacount] = dskfile;
        this.sna[this.snacount++] = this.mediadata[j];
      } 
      if (this.mediadata[j].toLowerCase().contains("screenshot")) {
        if (this.mediadata[j].contains("\"")) {
          while (!this.mediadata[j].startsWith("\""))
            this.mediadata[j] = this.mediadata[j].substring(1); 
          this.mediadata[j] = this.mediadata[j].substring(1);
          while (this.mediadata[j].contains("\""))
            this.mediadata[j] = this.mediadata[j].substring(0, this.mediadata[j].length() - 1); 
        } 
        this.gameid = this.mediadata[j];
        this.screenshot[count++] = this.mediadata[j];
      } 
    } 
    if (!this.backup)
      showScreen(this.screenid); 
    if (this.dskcount > 1) {
      this.bck.setEnabled(true);
      this.fwd.setEnabled(true);
    } else {
      this.bck.setEnabled(false);
      this.fwd.setEnabled(false);
    } 
    this.dskcount = 0;
    this.disk.setText((this.dskn[this.dskcount] != null) ? this.dskn[0].replace(".zip", "") : "None");
    this.jButton5.setEnabled((this.dskn[this.dskcount] != null));
    this.snap.setText((this.snan[0] != null) ? this.snan[0].replace(".zip", "") : "None");
    this.jPanel1.setVisible((this.snan[0] != null));
    this.jButton4.setEnabled((this.snan[0] != null));
    this.snap.setEnabled((this.snan[0] != null));
    this.prefer.setEnabled((this.snan[0] != null));
  }
  
  protected void downloadSNA(int id) {
    try {
      String file = this.sna[0];
      URL url = new URL(this.domain[this.domains.getSelectedIndex()] + "api.php?action=get&id=" + file);
      if (this.detailist.contains("cngsoft."))
        url = new URL(this.domain[this.domains.getSelectedIndex()] + file); 
      byte[] data = downloadUrl(url);
      String a = this.snan[0];
      if (this.detailist.contains("cngsoft."))
        a = a.replace(".zip", ""); 
      if (this.filedia == null)
        this.filedia = new FileDialog(new JFrame(), "Save...", 1); 
      this.filedia.setFile(a);
      this.filedia.setVisible(true);
      a = this.filedia.getDirectory();
      if (a != null) {
        a = this.filedia.getDirectory() + this.filedia.getFile();
        if (!this.detailist.contains("cngsoft.") && !a.toLowerCase().endsWith(".sna"))
          a = a + ".sna"; 
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File(a)));
        bos.write(data);
        bos.close();
      } 
    } catch (Exception exception) {}
  }
  
  protected void downloadDSK(int id) {
    try {
      String file = this.dsk[this.dskcount];
      URL url = new URL(this.domain[this.domains.getSelectedIndex()] + "api.php?action=get&id=" + file);
      if (this.detailist.contains("cngsoft."))
        url = new URL(this.domain[this.domains.getSelectedIndex()] + file); 
      System.out.println("Downloading " + url.toString());
      byte[] data = downloadUrl(url);
      String a = this.dskn[this.dskcount];
      if (this.detailist.contains("cngsoft."))
        a = a.replace(".zip", ""); 
      if (this.filedia == null)
        this.filedia = new FileDialog(new JFrame(), "Save...", 1); 
      this.filedia.setFile(a);
      this.filedia.setVisible(true);
      a = this.filedia.getDirectory();
      if (a != null) {
        a = this.filedia.getDirectory() + this.filedia.getFile();
        if (!a.toLowerCase().endsWith(".dsk"))
          a = a + ".dsk"; 
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File(a)));
        bos.write(data);
        bos.close();
      } 
    } catch (Exception exception) {}
  }
  
  void makeDir(String folder) {
    File fold = new File(folder);
    if (!fold.exists())
      fold.mkdir(); 
  }
  
  protected void getFile(int i) {
    if (!this.isloading)
      this.breakme = false; 
    this.isloading = true;
    Thread v = new Thread() {
        public void run() {
          try {
            if (AmstradEUBDD.this.backup) {
              AmstradEUBDD.this.load.setText(AmstradEUBDD.this.buttonBackupRunning);
              AmstradEUBDD.this.prog.setIndeterminate(false);
              AmstradEUBDD.this.prog.setVisible(true);
              AmstradEUBDD.this.prog.setMaximum(AmstradEUBDD.this.bdd.getRowCount());
              AmstradEUBDD.this.prog.setStringPainted(true);
              for (int id = AmstradEUBDD.this.bdd.getSelectedRow(); id < AmstradEUBDD.this.bdd.getRowCount(); id++) {
                if (AmstradEUBDD.this.breakme) {
                  AmstradEUBDD.this.isloading = false;
                  AmstradEUBDD.this.breakme = false;
                  AmstradEUBDD.this.prog.setVisible(false);
                  break;
                } 
                AmstradEUBDD.this.prog.setValue(id);
                AmstradEUBDD.this.readDetail(id);
                for (int i = 0; i < AmstradEUBDD.this.dsk.length; i++) {
                  String str = "";
                  if (AmstradEUBDD.this.dsk[AmstradEUBDD.this.dskcount] != null) {
                    str = AmstradEUBDD.this.dsk[AmstradEUBDD.this.dskcount];
                  } else {
                    str = AmstradEUBDD.this.sna[0];
                  } 
                  AmstradEUBDD.this.prog.setString("Accessing " + AmstradEUBDD.this.dskn[AmstradEUBDD.this.dskcount] + " - ID " + id + " of " + AmstradEUBDD.this.bdd.getRowCount());
                  URL uRL = new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + "api.php?action=get&id=" + str);
                  if (AmstradEUBDD.this.detailist.contains("cngsoft."))
                    uRL = new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + str); 
                  if (AmstradEUBDD.this.dsk[AmstradEUBDD.this.dskcount] != null) {
                    String folder = "./Backup_";
                    if (AmstradEUBDD.this.detailist.contains("cpc-power")) {
                      folder = folder + "cpc-power";
                    } else if (AmstradEUBDD.this.detailist.contains("cngsoft")) {
                      folder = folder + "cngsoft";
                    } else if (AmstradEUBDD.this.detailist.contains("devilmarkus") && AmstradEUBDD.this.detailist.contains("demos")) {
                      folder = folder + "javacpc_demos";
                    } else if (AmstradEUBDD.this.detailist.contains("devilmarkus") && AmstradEUBDD.this.detailist.contains("games")) {
                      folder = folder + "javacpc_games";
                    } else {
                      folder = folder + "amstrad_eu";
                    } 
                    AmstradEUBDD.this.makeDir(folder);
                    String writeAs = folder;
                    if (AmstradEUBDD.this.dskn[AmstradEUBDD.this.dskcount].toLowerCase().endsWith(".sna")) {
                      writeAs = writeAs + "/SNA/";
                    } else if (AmstradEUBDD.this.dskn[AmstradEUBDD.this.dskcount].toLowerCase().endsWith(".cdt")) {
                      writeAs = writeAs + "/CDT/";
                    } else if (AmstradEUBDD.this.dskn[AmstradEUBDD.this.dskcount].toLowerCase().endsWith(".tap")) {
                      writeAs = writeAs + "/TAP/";
                    } else if (AmstradEUBDD.this.dskn[AmstradEUBDD.this.dskcount].toLowerCase().endsWith(".dsk")) {
                      writeAs = writeAs + "/DSK/";
                    } else if (AmstradEUBDD.this.dskn[AmstradEUBDD.this.dskcount].toLowerCase().endsWith(".zip")) {
                      writeAs = writeAs + "/ZIP/";
                    } else {
                      writeAs = writeAs + "./MISC/";
                    } 
                    AmstradEUBDD.this.makeDir(writeAs);
                    String gameName = "" + AmstradEUBDD.this.rows[id][0];
                    while (gameName.endsWith(" "))
                      gameName = gameName.substring(0, gameName.length() - 1); 
                    while (gameName.endsWith("."))
                      gameName = gameName.substring(0, gameName.length() - 1); 
                    gameName = gameName.replace(":", "-");
                    gameName = gameName.replace(" ", "_");
                    gameName = gameName.replace("*", "");
                    writeAs = writeAs + gameName + "/";
                    AmstradEUBDD.this.makeDir(writeAs);
                    File write = new File(writeAs + AmstradEUBDD.this.dskn[AmstradEUBDD.this.dskcount]);
                    if (AmstradEUBDD.this.jCheckBox2.isSelected() && write.exists() && write.length() > 10L)
                      continue; 
                    try {
                      byte[] arrayOfByte = AmstradEUBDD.this.downloadUrl(uRL);
                      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(write));
                      bos.write(arrayOfByte);
                      bos.close();
                    } catch (Exception e) {
                      e.printStackTrace();
                    } 
                    if (AmstradEUBDD.this.dskcount == 0)
                      for (int si = 0; si < AmstradEUBDD.this.screenshot.length; si++) {
                        try {
                          uRL = new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + "api.php?action=get&id=" + AmstradEUBDD.this.screenshot[si]);
                          if (AmstradEUBDD.this.detailist.contains("cngsoft."))
                            uRL = new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + AmstradEUBDD.this.screenshot[si]); 
                          BufferedImage b = ImageIO.read(uRL);
                          BufferedImage c = new BufferedImage(384, 270, 1);
                          if (b.getWidth() > 400) {
                            int ypos = (270 - b.getHeight() / 2) / 2;
                            c.createGraphics().drawImage(b, 0, ypos, b.getWidth() / 2, b.getHeight() / 2, null);
                          } else {
                            int ypos = (270 - b.getHeight()) / 2;
                            c.createGraphics().drawImage(b, 0, ypos, (ImageObserver)null);
                          } 
                          String imageName = AmstradEUBDD.this.dskn[AmstradEUBDD.this.dskcount].replace(".dsk", "");
                          imageName = imageName.replace(".cdt", "");
                          imageName = imageName.replace(".sna", "");
                          imageName = imageName.replace(".tap", "");
                          imageName = imageName + "_" + si;
                          imageName = imageName + ".png";
                          write = new File(writeAs + imageName);
                          ImageIO.write(c, "PNG", write);
                          AmstradEUBDD.this.shot.setIcon(new ImageIcon(c));
                        } catch (Exception exception) {}
                      }  
                    AmstradEUBDD.this.isshowing = false;
                  } 
                  AmstradEUBDD.this.dskcount++;
                  continue;
                } 
                AmstradEUBDD.this.dskcount = 0;
              } 
              AmstradEUBDD.this.isloading = false;
              AmstradEUBDD.this.breakme = false;
              AmstradEUBDD.this.prog.setVisible(false);
              AmstradEUBDD.this.jCheckBox1.setSelected(false);
              AmstradEUBDD.this.jCheckBox1.setVisible(false);
              AmstradEUBDD.this.jCheckBox2.setVisible(false);
              AmstradEUBDD.this.prog.setStringPainted(false);
              AmstradEUBDD.this.backup = false;
              AmstradEUBDD.this.load.setText(AmstradEUBDD.this.buttonLoad);
              return;
            } 
            String file = "";
            if (AmstradEUBDD.this.dsk[AmstradEUBDD.this.dskcount] != null) {
              file = AmstradEUBDD.this.dsk[AmstradEUBDD.this.dskcount];
            } else {
              file = AmstradEUBDD.this.sna[0];
            } 
            URL url = new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + "api.php?action=get&id=" + file);
            if (AmstradEUBDD.this.detailist.contains("cngsoft."))
              url = new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + file); 
            byte[] data = AmstradEUBDD.this.downloadUrl(url);
            System.out.println(Util.dumpBytes(data, 0, 128));
            if (AmstradEUBDD.this.cpc != null)
              if (AmstradEUBDD.this.dsk[AmstradEUBDD.this.dskcount] != null) {
                if (AmstradEUBDD.this.dskn[AmstradEUBDD.this.dskcount].toLowerCase().endsWith(".sna")) {
                  if ((AmstradEUBDD.this.cpc != null && AmstradEUBDD.this.auto.isSelected() && !AmstradEUBDD.this.prefer.isSelected()) || (AmstradEUBDD.this.sna[0] == null && AmstradEUBDD.this.prefer.isSelected())) {
                    AmstradEUBDD.this.cpc.reset();
                    Thread.sleep(2000L);
                  } 
                  AmstradEUBDD.this.cpc.SNA_Load("none", data);
                } else if (AmstradEUBDD.this.dskn[AmstradEUBDD.this.dskcount].toLowerCase().contains(".cdt")) {
                  AmstradEUBDD.this.cpc.CDT_Load(file, data);
                  AmstradEUBDD.this.cpc.reset();
                  Thread.sleep(2000L);
                  AmstradEUBDD.this.cpc.fromautoboot = true;
                  AmstradEUBDD.this.cpc.BasicAutoType("|TAPE:RUN\"!\"");
                } else if (AmstradEUBDD.this.dskn[AmstradEUBDD.this.dskcount].toLowerCase().contains(".tap")) {
                  AmstradEUBDD.this.cpc.loadTAP(data);
                  AmstradEUBDD.this.cpc.reset();
                  Thread.sleep(2000L);
                  AmstradEUBDD.this.cpc.fromautoboot = true;
                  AmstradEUBDD.this.cpc.BasicAutoType("|TAPE:RUN\"!\"");
                } else {
                  if (!AmstradEUBDD.this.detailist.contains("cngsoft.") || !AmstradEUBDD.this.prefer.isSelected())
                    AmstradEUBDD.this.cpc.DSK_Load("none", data, 0); 
                  if ((AmstradEUBDD.this.cpc != null && AmstradEUBDD.this.auto.isSelected() && !AmstradEUBDD.this.prefer.isSelected()) || (AmstradEUBDD.this.sna[0] == null && AmstradEUBDD.this.prefer.isSelected())) {
                    AmstradEUBDD.this.cpc.reset();
                    Thread.sleep(2000L);
                  } 
                  if (AmstradEUBDD.this.sna[0] != null && AmstradEUBDD.this.prefer.isSelected()) {
                    url = new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + "api.php?action=get&id=" + AmstradEUBDD.this.sna[0]);
                    if (AmstradEUBDD.this.detailist.contains("cngsoft."))
                      url = new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + AmstradEUBDD.this.sna[0]); 
                    data = AmstradEUBDD.this.downloadUrl(url);
                    if (AmstradEUBDD.this.sna[0].contains(".cdt")) {
                      AmstradEUBDD.this.cpc.CDT_Load(file, data);
                      if (AmstradEUBDD.this.auto.isSelected()) {
                        AmstradEUBDD.this.cpc.reset();
                        Thread.sleep(2000L);
                        AmstradEUBDD.this.cpc.fromautoboot = true;
                        AmstradEUBDD.this.cpc.BasicAutoType("|TAPE:RUN\"!\"");
                      } 
                    } else {
                      AmstradEUBDD.this.cpc.SNA_Load("none", data);
                    } 
                  } else if (AmstradEUBDD.this.auto.isSelected()) {
                    String g = AmstradEUBDD.this.bootinfo.getText();
                    if (g.toLowerCase().equals("autoboot")) {
                      AmstradEUBDD.this.cpc.bootDisk();
                    } else {
                      AmstradEUBDD.this.cpc.fromautoboot = true;
                      if (g.toLowerCase().contains("|cpm")) {
                        AmstradEUBDD.this.cpc.BasicAutoType(g);
                      } else {
                        AmstradEUBDD.this.cpc.BasicAutoType("RUN\"" + g + "\"");
                      } 
                    } 
                  } 
                } 
              } else if (file.contains(".cdt")) {
                AmstradEUBDD.this.cpc.CDT_Load(file, data);
              } else {
                AmstradEUBDD.this.cpc.SNA_Load("none", data);
              }  
            AmstradEUBDD.this.isloading = false;
          } catch (Exception exception) {}
        }
      };
    v.start();
  }
  
  protected byte[] unZip(byte[] compressedData) {
    try {
      ByteArrayInputStream bis = new ByteArrayInputStream(compressedData);
      ZipInputStream zis = new ZipInputStream(bis);
      ByteArrayOutputStream bos = new ByteArrayOutputStream(compressedData.length);
      byte[] buffer = new byte[1024];
      ZipEntry ze = zis.getNextEntry();
      if (ze != null) {
        int len;
        while ((len = zis.read(buffer)) > 0)
          bos.write(buffer, 0, len); 
      } 
      bos.close();
      bis.close();
      if (bos.toByteArray() != null && (bos.toByteArray()).length > 4)
        return bos.toByteArray(); 
    } catch (Exception e) {
      e.printStackTrace();
    } 
    return compressedData;
  }
  
  private byte[] downloadUrl(URL toDownload) {
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    try {
      byte[] chunk = new byte[4096];
      InputStream stream = toDownload.openStream();
      int bytesRead;
      while ((bytesRead = stream.read(chunk)) > 0)
        outputStream.write(chunk, 0, bytesRead); 
    } catch (IOException e) {
      e.printStackTrace();
      return null;
    } 
    return unZip(outputStream.toByteArray());
  }
  
  protected void showScreen(final int id) {
    this.isshowing = true;
    Thread v = new Thread() {
        public void run() {
          try {
            URL url = new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + "api.php?action=get&id=" + AmstradEUBDD.this.screenshot[id]);
            if (AmstradEUBDD.this.detailist.contains("cngsoft."))
              url = new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + AmstradEUBDD.this.screenshot[id]); 
            BufferedImage b = ImageIO.read(url);
            BufferedImage c = new BufferedImage(384, 270, 1);
            if (b.getWidth() > 400) {
              int ypos = (270 - b.getHeight() / 2) / 2;
              c.createGraphics().drawImage(b, 0, ypos, b.getWidth() / 2, b.getHeight() / 2, null);
            } else {
              int ypos = (270 - b.getHeight()) / 2;
              c.createGraphics().drawImage(b, 0, ypos, (ImageObserver)null);
            } 
            AmstradEUBDD.this.shot.setIcon(new ImageIcon(c));
            AmstradEUBDD.this.isshowing = false;
          } catch (Exception exception) {}
        }
      };
    v.start();
  }
  
  protected void buildMedia(int id, int i) {
    int m = 0;
    String[] buffer = this.rrr[i].split("<");
    int g;
    for (g = 0; g < buffer.length; g++) {
      if (buffer[g].toLowerCase().startsWith("media"))
        m++; 
    } 
    this.media[id] = new String[m];
    m = 0;
    for (g = 0; g < buffer.length; g++) {
      if (buffer[g].toLowerCase().startsWith("media")) {
        String a = buffer[g];
        this.media[id][m++] = a;
      } 
    } 
  }
  
  protected void readList() {
    if (this.isBuilding)
      return; 
    this.isBuilding = true;
    this.domains.setEnabled(false);
    this.bdd.removeAll();
    this.rows = new Object[0][1];
    this.bdd.setModel(new DefaultTableModel(this.rows, (Object[])new String[] { "No database available!!!" }));
    Thread r = new Thread() {
        public void run() {
          try {
            AmstradEUBDD.this.prefer.setText("Prefer SNA first");
            AmstradEUBDD.this.jPanel1.setBorder(BorderFactory.createTitledBorder("SNA"));
            AmstradEUBDD.this.jLabel3.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/" + AmstradEUBDD.this.icon[AmstradEUBDD.this.domains.getSelectedIndex()])));
            AmstradEUBDD.this.jScrollPane1.setVisible(false);
            AmstradEUBDD.this.prog.setIndeterminate(true);
            AmstradEUBDD.this.prog.setVisible(true);
            AmstradEUBDD.this.load.setEnabled(false);
            AmstradEUBDD.this.detailist = AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + "api.php?action=detailist";
            if (AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()].contains("cngsoft.no-ip.org"))
              AmstradEUBDD.this.detailist = AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + "cpc_lzx.htm"; 
            String detailist2 = AmstradEUBDD.this.detailist;
            File check = new File(System.getProperty("user.home"), "/JavaCPC/bdd_cngsoft.txt");
            if (!check.exists())
              Settings.set("bdd_cngsoft", "0"); 
            check = new File(System.getProperty("user.home"), "/JavaCPC/bdd_javacpcgames.txt");
            if (!check.exists())
              Settings.set("bdd_javacpc_games", "0"); 
            check = new File(System.getProperty("user.home"), "/JavaCPC/bdd_javacpcdemos.txt");
            if (!check.exists())
              Settings.set("bdd_javacpc_demos", "0"); 
            check = new File(System.getProperty("user.home"), "/JavaCPC/bdd_cpcpower.txt");
            if (!check.exists())
              Settings.set("bdd_cpcpower", "0"); 
            if (AmstradEUBDD.this.detailist.contains("devilmarkus") && AmstradEUBDD.this.detailist.contains("games")) {
              try {
                Scanner s = new Scanner((new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + "api.php?")).openStream());
                String no = "";
                while (s.hasNextLine()) {
                  String a = s.nextLine();
                  no = no + a;
                } 
                int ab = Integer.parseInt(no);
                int bb = Settings.getInt("bdd_javacpc_games", 0);
                if (ab != bb) {
                  Settings.set("bdd_javacpc_games", "" + ab);
                  StringBuilder stringBuilder = new StringBuilder();
                  URL uRL = new URL(AmstradEUBDD.this.detailist);
                  s = new Scanner(uRL.openStream());
                  while (s.hasNextLine()) {
                    String a = s.nextLine();
                    stringBuilder.append(a + "\r\n");
                  } 
                  File file = new File(System.getProperty("user.home"), "/JavaCPC/bdd_javacpcgames.txt");
                  BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
                  bos.write(stringBuilder.toString().getBytes("UTF-8"));
                  bos.close();
                  AmstradEUBDD.this.detailist = "file:" + file.getAbsolutePath();
                } else {
                  File file = new File(System.getProperty("user.home"), "/JavaCPC/bdd_javacpcgames.txt");
                  if (file.exists()) {
                    AmstradEUBDD.this.detailist = "file:" + file.getAbsolutePath();
                  } else {
                    Settings.set("bdd_javacpc_games", "0");
                  } 
                } 
              } catch (Exception exception) {}
            } else if (AmstradEUBDD.this.detailist.contains("cngsoft.no-ip.org")) {
              try {
                AmstradEUBDD.this.prefer.setText("Use CDT image");
                AmstradEUBDD.this.jPanel1.setBorder(BorderFactory.createTitledBorder("CDT"));
                Scanner s = new Scanner((new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + "api.php")).openStream(), "Windows-1250");
                String no = "";
                while (s.hasNextLine())
                  no = no + s.nextLine(); 
                s.close();
                int ab = Integer.parseInt(no);
                int bb = Settings.getInt("bdd_cngsoft", 0);
                if (ab != bb) {
                  System.out.println("Reloading CNGSoft Database - old: " + bb + " - new: " + ab);
                  Settings.set("bdd_cngsoft", "" + ab);
                  String str = "";
                  try {
                    s = new Scanner((new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + "cpc_lzx.htm")).openStream(), "Windows-1250");
                    while (s.hasNextLine()) {
                      String a = s.nextLine();
                      byte[] input = a.getBytes("Windows-1250");
                      byte[] output = (new String(input, "Windows-1250")).getBytes("UTF-8");
                      str = str + new String(output, "UTF-8") + "\r\n";
                    } 
                    s.close();
                    str = AmstradEUBDD.this.getApi(str);
                  } catch (Exception e) {
                    e.printStackTrace();
                  } 
                  File file = new File(System.getProperty("user.home"), "/JavaCPC/bdd_cngsoft.txt");
                  BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
                  bos.write(str.getBytes("UTF-8"));
                  bos.close();
                  AmstradEUBDD.this.detailist = "file:" + file.getAbsolutePath();
                } else {
                  File file = new File(System.getProperty("user.home"), "/JavaCPC/bdd_cngsoft.txt");
                  if (file.exists()) {
                    AmstradEUBDD.this.detailist = "file:" + file.getAbsolutePath();
                  } else {
                    Settings.set("bdd_cngsoft", "0");
                  } 
                } 
              } catch (Exception exception) {}
            } else if (AmstradEUBDD.this.detailist.contains("devilmarkus") && AmstradEUBDD.this.detailist.contains("demos")) {
              try {
                Scanner s = new Scanner((new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + "api.php?")).openStream());
                String no = "";
                while (s.hasNextLine()) {
                  String a = s.nextLine();
                  no = no + a;
                } 
                int ab = Integer.parseInt(no);
                int bb = Settings.getInt("bdd_javacpc_demos", 0);
                if (ab != bb) {
                  Settings.set("bdd_javacpc_demos", "" + ab);
                  StringBuilder stringBuilder = new StringBuilder();
                  URL uRL = new URL(AmstradEUBDD.this.detailist);
                  s = new Scanner(uRL.openStream());
                  while (s.hasNextLine()) {
                    String a = s.nextLine();
                    stringBuilder.append(a + "\r\n");
                  } 
                  File file = new File(System.getProperty("user.home"), "/JavaCPC/bdd_javacpcdemos.txt");
                  BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
                  bos.write(stringBuilder.toString().getBytes("UTF-8"));
                  bos.close();
                  AmstradEUBDD.this.detailist = "file:" + file.getAbsolutePath();
                } else {
                  File file = new File(System.getProperty("user.home"), "/JavaCPC/bdd_javacpcdemos.txt");
                  if (file.exists()) {
                    AmstradEUBDD.this.detailist = "file:" + file.getAbsolutePath();
                  } else {
                    Settings.set("bdd_javacpc_demos", "0");
                  } 
                } 
              } catch (Exception exception) {}
            } else if (AmstradEUBDD.this.detailist.contains("cpc-power")) {
              try {
                Scanner s = new Scanner((new URL(AmstradEUBDD.this.domain[AmstradEUBDD.this.domains.getSelectedIndex()] + "api.php?")).openStream());
                String no = "";
                while (s.hasNextLine()) {
                  String a = s.nextLine();
                  no = no + a;
                } 
                int ab = Integer.parseInt(no);
                int bb = Settings.getInt("bdd_cpcpower", 0);
                if (ab != bb) {
                  Settings.set("bdd_cpcpower", "" + ab);
                  StringBuilder stringBuilder = new StringBuilder();
                  URL uRL = new URL(AmstradEUBDD.this.detailist);
                  s = new Scanner(uRL.openStream());
                  while (s.hasNextLine()) {
                    String a = s.nextLine();
                    stringBuilder.append(a + "\r\n");
                  } 
                  File file = new File(System.getProperty("user.home"), "/JavaCPC/bdd_cpcpower.txt");
                  BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
                  bos.write(stringBuilder.toString().getBytes("UTF-8"));
                  bos.close();
                  AmstradEUBDD.this.detailist = "file:" + file.getAbsolutePath();
                } else {
                  File file = new File(System.getProperty("user.home"), "/JavaCPC/bdd_cpcpower.txt");
                  if (file.exists()) {
                    AmstradEUBDD.this.detailist = "file:" + file.getAbsolutePath();
                  } else {
                    Settings.set("bdd_cpcpower", "0");
                  } 
                } 
              } catch (Exception exception) {}
            } 
            URL url = new URL(AmstradEUBDD.this.detailist);
            StringBuilder b = new StringBuilder();
            System.out.println("Opening http connection to: " + AmstradEUBDD.this.detailist);
            System.out.println("Using http.agent: " + System.getProperty("http.agent").toString());
            try {
              Scanner s = new Scanner(url.openStream(), "UTF-8");
              while (s.hasNextLine()) {
                String a = s.nextLine();
                b.append(a);
              } 
              s.close();
            } catch (Exception e) {
              e.printStackTrace();
              JOptionPane.showMessageDialog(new JFrame("Error!"), "No BDD database found!\r\nPerhaps the server is not reachable...");
              AmstradEUBDD.this.jScrollPane1.setVisible(true);
              AmstradEUBDD.this.prog.setIndeterminate(false);
              AmstradEUBDD.this.prog.setVisible(false);
              AmstradEUBDD.this.domains.setEnabled(true);
              AmstradEUBDD.this.isBuilding = false;
              return;
            } 
            String c = b.toString();
            if (!c.contains("<games")) {
              JOptionPane.showMessageDialog(new JFrame("Error!"), "No BDD database found!\r\nPerhaps the server is not reachable...");
              AmstradEUBDD.this.jScrollPane1.setVisible(true);
              AmstradEUBDD.this.prog.setIndeterminate(false);
              AmstradEUBDD.this.prog.setVisible(false);
              AmstradEUBDD.this.domains.setEnabled(true);
              AmstradEUBDD.this.isBuilding = false;
              return;
            } 
            while (!c.startsWith("<game"))
              c = c.substring(1); 
            c = c.replace("\n", "");
            c = c.replace("\r", "");
            c = c.replace("</game>", "</game>\n");
            c = c.replace("<games>", "");
            AmstradEUBDD.this.rrr = c.split("\n");
            int found = 0;
            int i;
            for (i = 0; i < AmstradEUBDD.this.rrr.length; i++) {
              if (AmstradEUBDD.this.rrr[i].toLowerCase().contains("title=") && AmstradEUBDD.this.rrr[i].toLowerCase().contains("id=") && !AmstradEUBDD.this.rrr[i].toLowerCase().contains("cpc 464") && !AmstradEUBDD.this.rrr[i].toLowerCase().contains("cpc 6128"))
                found++; 
            } 
            AmstradEUBDD.this.result = new String[found];
            AmstradEUBDD.this.detail = new String[found];
            AmstradEUBDD.this.media = new String[found][];
            found = 0;
            for (i = 0; i < AmstradEUBDD.this.rrr.length; i++) {
              if (AmstradEUBDD.this.rrr[i].toLowerCase().contains("title=") && AmstradEUBDD.this.rrr[i].toLowerCase().contains("id=") && !AmstradEUBDD.this.rrr[i].toLowerCase().contains("cpc 464") && !AmstradEUBDD.this.rrr[i].toLowerCase().contains("cpc 6128")) {
                AmstradEUBDD.this.result[found] = AmstradEUBDD.this.rrr[i];
                AmstradEUBDD.this.buildMedia(found++, i);
              } 
            } 
            AmstradEUBDD.this.detailist = detailist2;
            AmstradEUBDD.this.rows = new Object[found][(AmstradEUBDD.this.domains.getSelectedIndex() != 0) ? 2 : 4];
            if (AmstradEUBDD.this.detailist.contains("no-ip."))
              AmstradEUBDD.this.rows = new Object[found][4]; 
            for (i = 0; i < AmstradEUBDD.this.result.length; i++) {
              try {
                while (AmstradEUBDD.this.result[i].startsWith(" "))
                  AmstradEUBDD.this.result[i] = AmstradEUBDD.this.result[i].substring(1); 
                while (AmstradEUBDD.this.result[i].contains(">"))
                  AmstradEUBDD.this.result[i] = AmstradEUBDD.this.result[i].substring(0, AmstradEUBDD.this.result[i].length() - 1); 
              } catch (Exception e) {}
              String d = AmstradEUBDD.this.result[i];
              d = d.replace(" title=", "XXXXXXtitle=");
              d = d.replace(" company=", "XXXXXXcompany=");
              d = d.replace(" year=", "XXXXXXyear=");
              d = d.replace(" genre=", "XXXXXXgenre=");
              d = d.replace(" comment=", "XXXXXXcomment=");
              String[] v = d.split("XXXXXX");
              AmstradEUBDD.this.rows[i][0] = "????";
              AmstradEUBDD.this.rows[i][1] = "????";
              if (AmstradEUBDD.this.domains.getSelectedIndex() == 0) {
                AmstradEUBDD.this.rows[i][2] = "????";
                AmstradEUBDD.this.rows[i][3] = "????";
              } 
              String publisher = "????";
              for (int g = 0; g < v.length; g++) {
                if (v[g].toLowerCase().contains("title=")) {
                  String a = v[g];
                  a = AmstradEUBDD.this.getString("title=", a);
                  if (AmstradEUBDD.this.domains.getSelectedIndex() != 0) {
                    a = a.replace("\\", "");
                    if (a.contains("(")) {
                      String x = a;
                      while (!x.startsWith("("))
                        x = x.substring(1); 
                      x = x.substring(1);
                      if (x.contains("(")) {
                        while (!x.startsWith("("))
                          x = x.substring(1); 
                      } else {
                        x = "(" + x;
                      } 
                      x = x.replace("(", "");
                      x = x.replace(")", "");
                      publisher = x;
                      AmstradEUBDD.this.rows[i][1] = publisher;
                      while (!a.endsWith("("))
                        a = a.substring(0, a.length() - 1); 
                      a = a.substring(0, a.length() - 1);
                    } 
                  } 
                  AmstradEUBDD.this.rows[i][0] = a;
                } 
                if (v[g].toLowerCase().contains("year=")) {
                  String a = v[g];
                  a = AmstradEUBDD.this.getString("year=", a);
                  AmstradEUBDD.this.rows[i][1] = a;
                } 
                if (v[g].toLowerCase().contains("genre=") && !AmstradEUBDD.this.detailist.contains("cngsoft.")) {
                  String a = v[g];
                  a = AmstradEUBDD.this.getString("genre=", a);
                  AmstradEUBDD.this.rows[i][AmstradEUBDD.this.detailist.contains("cpc-power") ? 1 : 2] = a;
                } 
                if (v[g].toLowerCase().contains("company=")) {
                  String a = v[g];
                  a = AmstradEUBDD.this.getString("company=", a);
                  AmstradEUBDD.this.rows[i][AmstradEUBDD.this.detailist.contains("cngsoft.") ? 2 : 3] = a;
                } 
              } 
            } 
            if (AmstradEUBDD.this.domains.getSelectedIndex() != 0 && !AmstradEUBDD.this.detailist.contains("cngsoft.")) {
              AmstradEUBDD.this
                
                .model = new DefaultTableModel(AmstradEUBDD.this.rows, (Object[])new String[] { "Name:", this.this$0.detailist.contains("cpc-power") ? "Genre:" : "Publisher:" });
            } else if (!AmstradEUBDD.this.detailist.contains("cngsoft.")) {
              AmstradEUBDD.this.model = new DefaultTableModel(AmstradEUBDD.this.rows, (Object[])new String[] { "Name:", "Year:", "Genre:", "Publisher:" });
            } else {
              AmstradEUBDD.this.model = new DefaultTableModel(AmstradEUBDD.this.rows, (Object[])new String[] { "Name:", "Year:", "Publisher:" });
            } 
            SwingUtilities.invokeLater(new Runnable() {
                  public void run() {
                    AmstradEUBDD.this.bdd.setModel(AmstradEUBDD.this.model);
                    AmstradEUBDD.this.bdd.setRowSelectionInterval(0, 0);
                    AmstradEUBDD.this.bdd.scrollRectToVisible(AmstradEUBDD.this.bdd.getCellRect(0, 0, true));
                    AmstradEUBDD.this.readDetail(0);
                    AmstradEUBDD.this.jTextField1.setText(AmstradEUBDD.this.rows[1][0].toString());
                  }
                });
            AmstradEUBDD.this.jScrollPane1.setVisible(true);
            AmstradEUBDD.this.prog.setIndeterminate(false);
            AmstradEUBDD.this.prog.setVisible(false);
            AmstradEUBDD.this.load.setEnabled(true);
            AmstradEUBDD.this.domains.setEnabled(true);
            AmstradEUBDD.this.isBuilding = false;
          } catch (IOException ex) {
            ex.printStackTrace();
          } 
        }
      };
    r.start();
  }
  
  protected String parseCNG(String no) {
    while (!no.startsWith("<tr class=\"p0\">"))
      no = no.substring(1); 
    while (!no.endsWith("</table>"))
      no = no.substring(0, no.length() - 1); 
    no = no.replace("</table>", "");
    String[] check = no.split("</tr>");
    return "" + check.length;
  }
  
  protected String getApi(String i) {
    while (!i.startsWith("<tr class=\"p"))
      i = i.substring(1); 
    while (!i.endsWith("</table>"))
      i = i.substring(0, i.length() - 1); 
    i = i.replace("<tr class=\"p1\"><td><b> ", "");
    i = i.replace("<tr class=\"p0\"><td><b> ", "");
    i = i.replace("</table>", "");
    i = i.replace("\r", "");
    i = i.replace("\n", "");
    i = i.replace("</td>", "");
    String[] files = i.split("</tr>");
    i = "<games>\r\n";
    for (int g = 0; g < files.length; g++) {
      String k = files[g];
      i = i + "<game id=\"" + g + "\" title=\"";
      String c = k;
      while (c.contains("<"))
        c = c.substring(0, c.length() - 1); 
      c = c.substring(0, c.length() - 1);
      i = i + c + "\" company=\"";
      c = k;
      while (!c.startsWith("</b><br><i> "))
        c = c.substring(1); 
      c = c.replace("</b><br><i> ", "");
      while (c.contains("<"))
        c = c.substring(0, c.length() - 1); 
      String a = c.charAt(0) + "" + c.charAt(1) + "" + c.charAt(2) + "" + c.charAt(3);
      c = c.substring(5);
      while (c.endsWith(" "))
        c = c.substring(0, c.length() - 1); 
      i = i + c + "\" year=\"" + a + "\">\r\n";
      while (k.contains("href=\"http")) {
        while (!k.startsWith("href=\"http"))
          k = k.substring(1); 
        k = k.substring(1);
      } 
      c = k;
      while (!c.startsWith("showIt"))
        c = c.substring(1); 
      c = c.substring(8);
      while (c.contains("'"))
        c = c.substring(0, c.length() - 1); 
      i = i + "<media id=\"" + c + "\" type=\"Screenshot\" file=\"" + c + "\" />\r\n";
      c = k;
      while (!c.startsWith("href=\""))
        c = c.substring(1); 
      c = c.substring(6);
      while (!c.endsWith(".dsk.zip"))
        c = c.substring(0, c.length() - 1); 
      i = i + "<media id=\"" + c + "\" type=\"Disquette\" file=\"" + c + "\" />\r\n";
      c = k;
      while (!c.startsWith("href=\""))
        c = c.substring(1); 
      if (c.startsWith("http")) {
        c = c.substring(6);
        while (!c.startsWith("href=\""))
          c = c.substring(1); 
      } 
      c = c.substring(10);
      while (!c.startsWith("href=\""))
        c = c.substring(1); 
      c = c.substring(6);
      while (!c.endsWith(".cdt.zip"))
        c = c.substring(0, c.length() - 1); 
      i = i + "<media id=\"" + c + "\" type=\"Snapshot\" file=\"" + c + "\" />\r\n";
      i = i + "</game>\r\n";
    } 
    i = i + "</games>\r\n";
    return i;
  }
  
  protected String getString(String sub, String a) {
    a = a.replace(sub, "");
    a = a.replace("\"", "");
    return a;
  }
  
  private void initComponents() {
    this.jTextField1 = new JTextField();
    this.jButton1 = new JButton();
    this.shot = new JLabel();
    this.jButton2 = new JButton();
    this.load = new JButton();
    this.jPanel1 = new JPanel();
    this.snap = new JTextField();
    this.prefer = new JCheckBox();
    this.jButton4 = new JButton();
    this.jPanel3 = new JPanel();
    this.disk = new JTextField();
    this.bck = new JButton();
    this.fwd = new JButton();
    this.auto = new JCheckBox();
    this.jButton5 = new JButton();
    this.domains = new JComboBox();
    this.jLabel2 = new JLabel();
    this.bootinfo = new JLabel();
    this.jPanel2 = new JPanel();
    this.jScrollPane1 = new JScrollPane();
    this.bdd = new JTable() {
        private static final long serialVersionUID = 1L;
        
        public boolean isCellEditable(int row, int column) {
          return false;
        }
      };
    this.prog = new JProgressBar();
    this.jLabel3 = new JLabel();
    this.jButton3 = new JButton();
    this.browser = new JComboBox();
    this.jLabel1 = new JLabel();
    this.jCheckBox1 = new JCheckBox();
    this.jCheckBox2 = new JCheckBox();
    setMaximumSize(new Dimension(820, 580));
    setMinimumSize(new Dimension(820, 580));
    this.jTextField1.addKeyListener(new KeyAdapter() {
          public void keyReleased(KeyEvent evt) {
            AmstradEUBDD.this.jTextField1KeyReleased(evt);
          }
        });
    this.jButton1.setText("<");
    this.jButton1.setFocusable(false);
    this.jButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            AmstradEUBDD.this.jButton1ActionPerformed(evt);
          }
        });
    this.shot.setPreferredSize(new Dimension(384, 270));
    this.jButton2.setText(">");
    this.jButton2.setFocusable(false);
    this.jButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            AmstradEUBDD.this.jButton2ActionPerformed(evt);
          }
        });
    this.load.setFont(new Font("Tahoma", 1, 24));
    this.load.setText("Load into JavaCPC");
    this.load.setEnabled(false);
    this.load.setFocusable(false);
    this.load.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            AmstradEUBDD.this.loadActionPerformed(evt);
          }
        });
    this.jPanel1.setBorder(BorderFactory.createTitledBorder("SNA"));
    this.snap.setFocusable(false);
    this.prefer.setText("Prefer SNA first");
    this.prefer.setFocusable(false);
    this.jButton4.setText("Download");
    this.jButton4.setEnabled(false);
    this.jButton4.setFocusable(false);
    this.jButton4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            AmstradEUBDD.this.jButton4ActionPerformed(evt);
          }
        });
    GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
    this.jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(jPanel1Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel1Layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
              .addComponent(this.prefer)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
              .addComponent(this.jButton4))
            .addComponent(this.snap))
          .addContainerGap()));
    jPanel1Layout.setVerticalGroup(jPanel1Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel1Layout.createSequentialGroup()
          .addComponent(this.snap, -2, -1, -2)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.prefer)
            .addComponent(this.jButton4))
          .addGap(0, 13, 32767)));
    this.jPanel3.setBorder(BorderFactory.createTitledBorder("DSK"));
    this.disk.setFocusable(false);
    this.bck.setText("<");
    this.bck.setFocusable(false);
    this.bck.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            AmstradEUBDD.this.bckActionPerformed(evt);
          }
        });
    this.fwd.setText(">");
    this.fwd.setFocusable(false);
    this.fwd.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            AmstradEUBDD.this.fwdActionPerformed(evt);
          }
        });
    this.auto.setSelected(true);
    this.auto.setText("Autoboot");
    this.auto.setFocusable(false);
    this.jButton5.setText("Download");
    this.jButton5.setEnabled(false);
    this.jButton5.setFocusable(false);
    this.jButton5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            AmstradEUBDD.this.jButton5ActionPerformed(evt);
          }
        });
    GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
    this.jPanel3.setLayout(jPanel3Layout);
    jPanel3Layout.setHorizontalGroup(jPanel3Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel3Layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.disk)
            .addGroup(jPanel3Layout.createSequentialGroup()
              .addComponent(this.bck)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.auto)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
              .addComponent(this.jButton5)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.fwd)))
          .addContainerGap()));
    jPanel3Layout.setVerticalGroup(jPanel3Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel3Layout.createSequentialGroup()
          .addComponent(this.disk, -2, -1, -2)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.bck)
            .addComponent(this.fwd)
            .addComponent(this.auto)
            .addComponent(this.jButton5))
          .addGap(0, 13, 32767)));
    this.domains.setModel(new DefaultComboBoxModel<>(new String[] { "Amstrad.eu", "JavaCPC Games", "JavaCPC Demos", "CPC Power", "CNGSoft" }));
    this.domains.setFocusable(false);
    this.domains.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent evt) {
            AmstradEUBDD.this.domainsItemStateChanged(evt);
          }
        });
    this.jLabel2.setText("Bootinfo: ");
    this.bootinfo.setText("autoboot");
    this.jPanel2.setPreferredSize(new Dimension(800, 256));
    this.jPanel2.setLayout(new BorderLayout());
    this.bdd.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[] { "Name:", "Year:", "Genre:", "Publisher:" }));
    this.bdd.setRequestFocusEnabled(false);
    this.bdd.setSelectionMode(0);
    this.bdd.setShowVerticalLines(false);
    this.bdd.getTableHeader().setReorderingAllowed(false);
    this.bdd.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            AmstradEUBDD.this.bddMouseClicked(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            AmstradEUBDD.this.bddMouseReleased(evt);
          }
        });
    this.bdd.addKeyListener(new KeyAdapter() {
          public void keyReleased(KeyEvent evt) {
            AmstradEUBDD.this.bddKeyReleased(evt);
          }
        });
    this.jScrollPane1.setViewportView(this.bdd);
    this.jPanel2.add(this.jScrollPane1, "Center");
    this.prog.setIndeterminate(true);
    this.prog.setPreferredSize(new Dimension(146, 256));
    this.jPanel2.add(this.prog, "South");
    this.jLabel3.setHorizontalAlignment(0);
    this.jLabel3.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/javacpc.png")));
    this.jLabel3.setVerticalAlignment(3);
    this.jButton3.setText("Visit");
    this.jButton3.setFocusable(false);
    this.jButton3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            AmstradEUBDD.this.jButton3ActionPerformed(evt);
          }
        });
    this.browser.setModel(new DefaultComboBoxModel<>(new String[] { "Internal", "External" }));
    this.browser.setFocusable(false);
    this.jLabel1.setText("Search:");
    this.jCheckBox1.setText("Local Backup");
    this.jCheckBox1.setFocusable(false);
    this.jCheckBox1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            AmstradEUBDD.this.jCheckBox1ActionPerformed(evt);
          }
        });
    this.jCheckBox2.setSelected(true);
    this.jCheckBox2.setText("Update");
    this.jCheckBox2.setFocusable(false);
    GroupLayout layout = new GroupLayout(this);
    setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jPanel2, -1, -1, 32767)
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.jButton1)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.shot, -2, -1, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jButton2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(this.jPanel1, -1, -1, 32767)
                .addComponent(this.jPanel3, -1, -1, 32767)
                .addComponent(this.load, -1, -1, 32767)
                .addGroup(layout.createSequentialGroup()
                  .addComponent(this.jLabel2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.bootinfo)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
                  .addComponent(this.jCheckBox1)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.jCheckBox2))))
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.jLabel1)
              .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
              .addComponent(this.jTextField1, -2, 354, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.domains, -2, -1, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jLabel3, -2, 160, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jButton3)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.browser, -2, -1, -2)))
          .addContainerGap()));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addComponent(this.jPanel2, -1, 263, 32767)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
              .addComponent(this.jButton3)
              .addComponent(this.browser, -2, -1, -2))
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
              .addComponent(this.jLabel1, GroupLayout.Alignment.LEADING, -1, -1, 32767)
              .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(this.jTextField1, -2, -1, -2)
                .addComponent(this.domains, -2, -1, -2)))
            .addComponent(this.jLabel3, -2, 20, -2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(this.shot, -2, -1, -2)
            .addComponent(this.jButton1, -2, 270, -2)
            .addComponent(this.jButton2, -2, 270, -2)
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.jPanel1, -2, -1, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jPanel3, -2, -1, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(this.jLabel2)
                .addComponent(this.bootinfo)
                .addComponent(this.jCheckBox1)
                .addComponent(this.jCheckBox2))
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.load, -1, -1, 32767)))
          .addContainerGap()));
  }
  
  private void bddMouseReleased(MouseEvent evt) {
    selectGame(true);
  }
  
  private void jButton1ActionPerformed(ActionEvent evt) {
    try {
      if (this.isshowing)
        return; 
      if (this.screenid > 0) {
        this.screenid--;
        showScreen(this.screenid);
      } else {
        this.screenid = this.screenshot.length - 1;
        showScreen(this.screenid);
      } 
    } catch (Exception exception) {}
  }
  
  private void jButton2ActionPerformed(ActionEvent evt) {
    try {
      if (this.isshowing)
        return; 
      if (this.screenid < this.screenshot.length - 1) {
        this.screenid++;
        showScreen(this.screenid);
      } else {
        this.screenid = 0;
        showScreen(this.screenid);
      } 
    } catch (Exception exception) {}
  }
  
  private void bddKeyReleased(KeyEvent evt) {
    try {
      int k = this.bdd.getSelectedRow();
      readDetail(k);
      this.jTextField1.setText(this.rows[k][0].toString());
      if (evt.getKeyCode() == 32) {
        evt.consume();
        getFile(k);
      } 
    } catch (Exception exception) {}
  }
  
  private void loadActionPerformed(ActionEvent evt) {
    try {
      int k = this.bdd.getSelectedRow();
      if (this.isloading) {
        this.breakme = true;
        return;
      } 
      getFile(k);
    } catch (Exception exception) {}
  }
  
  private void fwdActionPerformed(ActionEvent evt) {
    if (this.dskn[this.dskcount + 1] != null) {
      this.dskcount++;
      this.disk.setText(this.dskn[this.dskcount]);
    } 
    if (this.auto.isSelected())
      this.wasenabled = true; 
    this.auto.setSelected(false);
  }
  
  private void bckActionPerformed(ActionEvent evt) {
    if (this.dskcount > 0) {
      this.dskcount--;
      this.disk.setText(this.dskn[this.dskcount]);
    } 
    if (this.auto.isSelected())
      this.wasenabled = true; 
    this.auto.setSelected(false);
  }
  
  private void jButton4ActionPerformed(ActionEvent evt) {
    try {
      int k = this.bdd.getSelectedRow();
      downloadSNA(k);
    } catch (Exception exception) {}
  }
  
  private void jButton5ActionPerformed(ActionEvent evt) {
    try {
      int k = this.bdd.getSelectedRow();
      downloadDSK(k);
    } catch (Exception exception) {}
  }
  
  private void domainsItemStateChanged(ItemEvent evt) {
    readList();
    Settings.set("bdd_lastlist", "" + this.domains.getSelectedIndex());
  }
  
  private void jButton3ActionPerformed(ActionEvent evt) {
    browse();
  }
  
  private void jTextField1KeyReleased(KeyEvent evt) {
    if (evt.getKeyCode() == 10) {
      String search = this.jTextField1.getText();
      if (search.toLowerCase().equals("lemme download")) {
        this.jCheckBox1.setVisible(true);
        this.jCheckBox2.setVisible(true);
        return;
      } 
      search(this.jTextField1.getText());
    } 
  }
  
  private void bddMouseClicked(MouseEvent evt) {
    this.bdd.requestFocus();
    if (evt.getClickCount() == 2)
      try {
        int k = this.bdd.getSelectedRow();
        getFile(k);
      } catch (Exception exception) {} 
  }
  
  private void jCheckBox1ActionPerformed(ActionEvent evt) {
    this.backup = this.jCheckBox1.isSelected();
    this.load.setText(this.backup ? this.buttonBackup : this.buttonLoad);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\AmstradEUBDD.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */