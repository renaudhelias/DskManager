package jemu.ui;

import Core.WallpaperBox;
import JCPC.ui.GX4000;
import JaC64.JaC64;
import com.nilo.plaf.nimrod.NimRODLookAndFeel;
import com.nilo.plaf.nimrod.NimRODTheme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.BufferedImage;
import java.beans.PropertyVetoException;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JDesktopPane;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.LayoutStyle;
import javax.swing.LookAndFeel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.plaf.metal.MetalTheme;
import jemu.core.Util;
import jemu.core.device.crtc.Basic6845;
import jemu.core.device.floppy.UPD765A;
import jemu.core.device.printer.Printer;
import jemu.core.device.sound.AY_3_8910;
import jemu.core.device.sound.AY_3_8910_A;
import jemu.core.device.sound.AY_3_8910_B;
import jemu.core.device.sound.AudioCapture;
import jemu.core.device.sound.AudioFilter;
import jemu.core.device.sound.YMControl;
import jemu.core.device.speech.SPO256;
import jemu.core.device.speech.Speech;
import jemu.core.device.tape.TapeDeck;
import jemu.core.samples.Samples;
import jemu.settings.DSettings;
import jemu.settings.Palette;
import jemu.settings.RSettings;
import jemu.settings.Settings;
import jemu.system.cpc.CPC;
import jemu.system.cpc.CPCMemory;
import jemu.system.cpc.FormatPanel;
import jemu.system.cpc.GateArray;
import jemu.system.cpc.GraphicsViewer;
import jemu.ui.cpcgamescd.CPCGamesCDGUI;
import jemu.ui.dskutil.DSKUtil;
import jemu.ui.paint.RasterPaint;
import jemu.util.ass.Interface;
import jemu.util.ass.SciCalc;
import jemu.util.hexeditor.HexEditor;
import jemu.util.pokefinder.PokeFinder;
import org.netbeans.lib.awtextra.AbsoluteConstraints;
import org.netbeans.lib.awtextra.AbsoluteLayout;
import pacman.Main;
import tiled.mapeditor.MapEditor;
import vulcano.chat.Runner;

public class Desktop extends JFrame implements WindowListener, MouseMotionListener, ActionListener {
  JFrame cdfram;
  
  CPCGamesCDGUI cdgui;
  
  public static boolean setVis = true;
  
  public static int visTimer;
  
  DesktopHelper helper = new DesktopHelper();
  
  BufferedImage labelstart;
  
  public void setGamesCD() {
    if (this.cdgui == null) {
      this.cdgui = new CPCGamesCDGUI(GateArray.cpc, this);
      if (!isDesktop) {
        this.cdfram = new JFrame("CPCGamesCD - Test GUI");
        this.cdfram.setLayout(new BorderLayout());
        this.cdfram.setDefaultCloseOperation(1);
        this.cdfram.add((Component)this.cdgui, "Center");
        this.cdfram.pack();
        this.cdfram.setResizable(false);
      } else {
        this.gamescdgui.add((Component)this.cdgui, "Center");
        this.gamescdgui.pack();
      } 
    } 
    if (!isDesktop) {
      this.cdfram.setVisible(true);
    } else {
      this.gamescdgui.setVisible(true);
      this.gamescdgui.toFront();
    } 
  }
  
  public void windowDeactivated(WindowEvent w) {}
  
  public void windowActivated(WindowEvent w) {}
  
  public void windowDeiconified(WindowEvent w) {}
  
  public void windowIconified(WindowEvent w) {}
  
  protected void quit() {
    if (JEMU.iframe == null)
      System.exit(0); 
    if (isUndecorated()) {
      System.out.println("This is undecorated!");
      try {
        setOpacity(1.0F);
        this.splasher = new Thread() {
            public void run() {
              try {
                Thread.sleep(1000L);
              } catch (Exception exception) {}
              float sweep = 1.0F;
              while (sweep > 0.0F) {
                sweep -= 0.00125F;
                if (sweep < 0.0F)
                  sweep = 0.0F; 
                Desktop.this.setOpacity(sweep);
                try {
                  Thread.sleep(1L);
                } catch (Exception exception) {}
              } 
            }
          };
      } catch (Exception exception) {}
      this.splasher.start();
      try {
        Thread.sleep(3000L);
      } catch (Exception exception) {}
    } 
    if (!JEMU.iframe.isVisible() && !JEMU.undocked) {
      JEMU.iframe.setVisible(true);
      GateArray.cpc.start();
    } 
    JEMU.runComputer.setSelected(true);
    GateArray.cpc.checkSaveOnExit();
    CPC.playSNP = false;
    CPC.StoreSNP = false;
  }
  
  protected void showStartMenu() {
    this.starttab.setLocation(8, this.desktop.getHeight() - this.starttab.getHeight());
    this.starttab.setVisible(!this.starttab.isVisible());
    this.starttab.requestFocus();
  }
  
  protected void addMore() {
    Thread more = new Thread() {
        public void run() {
          while (GateArray.cpc == null) {
            try {
              Thread.sleep(10L);
            } catch (Exception exception) {}
          } 
          boolean tr = Settings.getBoolean("z80_turbo", false);
          Desktop.jCheckBox19.setSelected(tr);
          GateArray.cpc.setZ80Turbo(tr);
        }
      };
    more.start();
  }
  
  private String alarmon = "On";
  
  private String alarmoff = "Off";
  
  public void localize(String lang) {
    int c = this.filterChooser.getSelectedIndex();
    switch (lang.toLowerCase()) {
      case "de_de":
        this.clock.setTitle("Uhr");
        this.jLabel27.setText("Stellen");
        this.alarmon = "Ein";
        this.alarmoff = "Aus";
        this.alarmenable.setText(this.alarmenabled ? this.alarmon : this.alarmoff);
        printframe.setTitle("Drucker");
        textprinter.setBorder(BorderFactory.createTitledBorder("Ausgabe"));
        this.jPanel33.setBorder(BorderFactory.createTitledBorder("Funktionen"));
        this.jButton35.setText("Löschen");
        this.jButton36.setText("Kopieren");
        this.jButton37.setText("Speichern");
        this.jButton38.setText("An CPC senden");
        this.jPanel40.setBorder(BorderFactory.createTitledBorder("Optionen"));
        this.jPanel39.setBorder(BorderFactory.createTitledBorder("Hintergrundbild & Stil"));
        OptionPane.setTitleAt(_ABOUT, "Über");
        OptionPane.setTitleAt(_MISC, "Verschiedenes");
        OptionPane.setTitleAt(_DRIVES, "Laufwerke");
        this.deskcheck.setText("Desktop");
        this.expand.setText("Voll");
        this.useconsole.setText("Java Konsole");
        this.sinfo.setText("Zeige Kurztipps");
        this.jToggleButton3.setText("Immer im Vordergrund");
        this.jButton21.setText("Icons Zurücksetzen");
        this.jButton39.setText("Registry-Werte setzen");
        this.jLabel22.setText("Stil:");
        this.forced.setText("Erzwingen");
        slic.setText("Synthetica Liz.");
        this.restartj.setText("JavaCPC bitte neustarten");
        this.jButton31.setText("Wallpaper laden");
        this.jButton32.setText("Löschen");
        this.jButton40.setText("Wallpaper Herunterladen");
        this.wallcenter.setText("Zentriert");
        this.wallstretch.setText("Strecken");
        this.walltile.setText("Kachel");
        this.jTabbedPane1.setTitleAt(0, "Typ");
        this.jTabbedPane1.setTitleAt(1, "Erweitert");
        this.videopanel.setBorder(BorderFactory.createTitledBorder("Monitortyp"));
        this.jPanel7.setBorder(BorderFactory.createTitledBorder("Bild"));
        this.jPanel8.setBorder(BorderFactory.createTitledBorder("Anzeigeeigenschaften"));
        this.scanl.setText("Scanlinien");
        this.jLabel78.setText("Hell");
        this.filterChooser.setModel(new DefaultComboBoxModel<>(new String[] { "Keine", "RGB 2x", "RGB 2x B", "AdvMame", "Eagle", "AdvMame Sm", "Eagle Sm", "Embossed" }));
        break;
      case "fr_fr":
        this.clock.setTitle("Horloge");
        this.jLabel27.setText("Régler");
        this.alarmon = "On";
        this.alarmoff = "Off";
        this.alarmenable.setText(this.alarmenabled ? this.alarmon : this.alarmoff);
        printframe.setTitle("Imprimante");
        textprinter.setBorder(BorderFactory.createTitledBorder("Sortie"));
        this.jPanel33.setBorder(BorderFactory.createTitledBorder("Fonctions"));
        this.jButton35.setText("Effacer");
        this.jButton36.setText("Copier");
        this.jButton37.setText("Sauvegarder");
        this.jButton38.setText("Envoyer au CPC");
        this.jPanel40.setBorder(BorderFactory.createTitledBorder("Options"));
        this.jPanel39.setBorder(BorderFactory.createTitledBorder("Fond d'écran & Style"));
        OptionPane.setTitleAt(_ABOUT, "A propos");
        OptionPane.setTitleAt(_MISC, "Divers");
        OptionPane.setTitleAt(_DRIVES, "Lecteurs");
        this.deskcheck.setText("Bureau");
        this.expand.setText("Plein");
        this.useconsole.setText("Console Java");
        this.sinfo.setText("Montrer Quickinfo");
        this.jToggleButton3.setText("Toujours au-dessus");
        this.jButton21.setText("Reset des icônes");
        this.jButton39.setText("Régler les valeurs du registre");
        this.jLabel22.setText("Style:");
        this.forced.setText("Forcer");
        slic.setText("Lic. Synthetica");
        this.restartj.setText("Svp redémarrez JavaCPC");
        this.jButton31.setText("Charger Fond d'écran");
        this.jButton32.setText("Effacer");
        this.jButton40.setText("Télécharger Fond d'écran");
        this.wallcenter.setText("Centrer");
        this.wallstretch.setText("Etirer");
        this.walltile.setText("Mosaïque");
        this.jTabbedPane1.setTitleAt(0, "Type");
        this.jTabbedPane1.setTitleAt(1, "Avancé");
        this.videopanel.setBorder(BorderFactory.createTitledBorder("Type de moniteur"));
        this.jPanel7.setBorder(BorderFactory.createTitledBorder("Ecran"));
        this.jPanel8.setBorder(BorderFactory.createTitledBorder("Afficher fonctions"));
        this.scanl.setText("Scanlines");
        this.jLabel78.setText("Brillance");
        this.filterChooser.setModel(new DefaultComboBoxModel<>(new String[] { "Aucun", "RGB 2x", "RGB 2x B", "AdvMame", "Eagle", "AdvMame Sm", "Eagle Sm", "Embossed" }));
        break;
      case "es_es":
        this.clock.setTitle("Reloj");
        this.jLabel27.setText("Set");
        this.alarmon = "On";
        this.alarmoff = "Off";
        this.alarmenable.setText(this.alarmenabled ? this.alarmon : this.alarmoff);
        printframe.setTitle("Impresora");
        textprinter.setBorder(BorderFactory.createTitledBorder("Salida"));
        this.jPanel33.setBorder(BorderFactory.createTitledBorder("Funciones"));
        this.jButton35.setText("Vaciar");
        this.jButton36.setText("Copiar");
        this.jButton37.setText("Guardar");
        this.jButton38.setText("Enviar a CPC");
        this.jPanel40.setBorder(BorderFactory.createTitledBorder("Opciones"));
        this.jPanel39.setBorder(BorderFactory.createTitledBorder("Wallpaper & Estilo"));
        OptionPane.setTitleAt(_ABOUT, "Acerca");
        OptionPane.setTitleAt(_MISC, "Varios");
        OptionPane.setTitleAt(_DRIVES, "Unidades");
        this.deskcheck.setText("Escritorio");
        this.expand.setText("Completo");
        this.useconsole.setText("Consola Java");
        this.sinfo.setText("Mostrar Quickinfo");
        this.jToggleButton3.setText("Siempre arriba");
        this.jButton21.setText("Reset iconos");
        this.jButton39.setText("Añadir valores registro");
        this.jLabel22.setText("Estilo:");
        this.forced.setText("Forzar");
        slic.setText("Synthetica Lic.");
        this.restartj.setText("Por favor reinicie JavaCPC");
        this.jButton31.setText("Cargar Wallpaper");
        this.jButton32.setText("Vaciar");
        this.jButton40.setText("Descargar Wallpaper");
        this.wallcenter.setText("Centrar");
        this.wallstretch.setText("Ajustar");
        this.walltile.setText("Mosaico");
        this.jTabbedPane1.setTitleAt(0, "Tipo");
        this.jTabbedPane1.setTitleAt(1, "Avanzado");
        this.videopanel.setBorder(BorderFactory.createTitledBorder("Tipo monitor"));
        this.jPanel7.setBorder(BorderFactory.createTitledBorder("Pantalla"));
        this.jPanel8.setBorder(BorderFactory.createTitledBorder("Carac. Pantalla"));
        this.scanl.setText("Scanlines");
        this.jLabel78.setText("Brillo");
        this.filterChooser.setModel(new DefaultComboBoxModel<>(new String[] { "Ninguno", "RGB 2x", "RGB 2x B", "AdvMame", "Eagle", "AdvMame Sm", "Eagle Sm", "Embossed" }));
        break;
      default:
        this.clock.setTitle("Clock");
        this.jLabel27.setText("Set");
        this.alarmon = "On";
        this.alarmoff = "Off";
        this.alarmenable.setText(this.alarmenabled ? this.alarmon : this.alarmoff);
        printframe.setTitle("Printer");
        textprinter.setBorder(BorderFactory.createTitledBorder("Output"));
        this.jPanel33.setBorder(BorderFactory.createTitledBorder("Functions"));
        this.jButton35.setText("Clear");
        this.jButton36.setText("Copy");
        this.jButton37.setText("Save");
        this.jButton38.setText("Send to CPC");
        this.jPanel40.setBorder(BorderFactory.createTitledBorder("Options"));
        this.jPanel39.setBorder(BorderFactory.createTitledBorder("Wallpaper & Style"));
        OptionPane.setTitleAt(_ABOUT, "About");
        OptionPane.setTitleAt(_MISC, "Miscellaneous");
        OptionPane.setTitleAt(_DRIVES, "Drives");
        this.deskcheck.setText("Desktop");
        this.expand.setText("Full");
        this.useconsole.setText("Java Console");
        this.sinfo.setText("Show Quickinfo");
        this.jToggleButton3.setText("Always On Top");
        this.jButton21.setText("Reset icons");
        this.jButton39.setText("Apply Registry-settings");
        this.jLabel22.setText("Style:");
        this.forced.setText("Force");
        slic.setText("Synthetica Lic.");
        this.restartj.setText("Please restart JavaCPC");
        this.jButton31.setText("Load Wallpaper");
        this.jButton32.setText("Clear");
        this.jButton40.setText("Download Wallpaper");
        this.wallcenter.setText("Center");
        this.wallstretch.setText("Stretch");
        this.walltile.setText("Tile");
        this.jTabbedPane1.setTitleAt(0, "Type");
        this.jTabbedPane1.setTitleAt(1, "Advanced");
        this.videopanel.setBorder(BorderFactory.createTitledBorder("Monitor type"));
        this.jPanel7.setBorder(BorderFactory.createTitledBorder("Screen"));
        this.jPanel8.setBorder(BorderFactory.createTitledBorder("Display features"));
        this.scanl.setText("Scanlines");
        this.jLabel78.setText("Bright");
        this.filterChooser.setModel(new DefaultComboBoxModel<>(new String[] { "None", "RGB 2x", "RGB 2x B", "AdvMame", "Eagle", "AdvMame Sm", "Eagle Sm", "Embossed" }));
        break;
    } 
    this.filterChooser.setSelectedIndex(c);
  }
  
  public void windowClosed(WindowEvent w) {
    if (JEMU.iframe == null)
      System.exit(0); 
    if (this.Assembler != null)
      this.Assembler.closeAllTabs(); 
    JEMU.runComputer.setSelected(true);
    GateArray.cpc.checkSaveOnExit();
    CPC.playSNP = false;
    CPC.StoreSNP = false;
  }
  
  public static String asmfile = null;
  
  AmstradEUBDD bdd;
  
  public static int openbdd;
  
  public Runner chat;
  
  protected JInternalFrame gfxview;
  
  private Thread pokes;
  
  protected JInternalFrame subpop;
  
  protected JInternalFrame dsk2cd;
  
  protected static JFrame dskut;
  
  AtariPanel atari;
  
  GX4000 plus;
  
  JInternalFrame gx4000;
  
  public void createBDD() {
    if (GateArray.cpc == null)
      return; 
    if (this.bdd == null) {
      this.bdd = new AmstradEUBDD(GateArray.cpc);
      this.bddFrame.add(this.bdd, "Center");
      this.bddFrame.pack();
    } 
    this.bddFrame.setVisible(true);
  }
  
  public void openASM() {
    checkAssembler();
    this.Assembler.openTab(asmfile);
    asmfile = null;
  }
  
  public void windowClosing(WindowEvent w) {
    if (JEMU.iframe == null)
      System.exit(0); 
    if (!JEMU.iframe.isVisible() && !JEMU.undocked) {
      JEMU.iframe.setVisible(true);
      GateArray.cpc.start();
    } 
    if (this.Assembler != null)
      this.Assembler.closeAllTabs(); 
    JEMU.runComputer.setSelected(true);
    GateArray.cpc.checkSaveOnExit();
    CPC.playSNP = false;
    CPC.StoreSNP = false;
  }
  
  protected void align() {
    int xalign = 90;
    int yalign = 70;
    int x = (this.capi.getLocation()).x / xalign * xalign;
    int y = (this.capi.getLocation()).y / yalign * yalign;
    DSettings.set("icon1x", "" + x);
    DSettings.set("icon1y", "" + (y + 30));
    this.capi.setLocation(x, y + 30);
    x = (this.ymi.getLocation()).x / xalign * xalign;
    y = (this.ymi.getLocation()).y / yalign * yalign;
    DSettings.set("icon2x", "" + x);
    DSettings.set("icon2y", "" + (y + 30));
    this.ymi.setLocation(x, y + 30);
    x = (this.hexi.getLocation()).x / xalign * xalign;
    y = (this.hexi.getLocation()).y / yalign * yalign;
    DSettings.set("icon3x", "" + x);
    DSettings.set("icon3y", "" + (y + 30));
    this.hexi.setLocation(x, y + 30);
    x = (this.clocki.getLocation()).x / xalign * xalign;
    y = (this.clocki.getLocation()).y / yalign * yalign;
    DSettings.set("icon4x", "" + x);
    DSettings.set("icon4y", "" + (y + 30));
    this.clocki.setLocation(x, y + 30);
    x = (this.infoi.getLocation()).x / xalign * xalign;
    y = (this.infoi.getLocation()).y / yalign * yalign;
    DSettings.set("icon5x", "" + x);
    DSettings.set("icon5y", "" + (y + 30));
    this.infoi.setLocation(x, y + 30);
    x = (this.consoli.getLocation()).x / xalign * xalign;
    y = (this.consoli.getLocation()).y / yalign * yalign;
    DSettings.set("icon6x", "" + x);
    DSettings.set("icon6y", "" + (y + 30));
    this.consoli.setLocation(x, y + 30);
    x = (this.minii.getLocation()).x / xalign * xalign;
    y = (this.minii.getLocation()).y / yalign * yalign;
    DSettings.set("icon7x", "" + x);
    DSettings.set("icon7y", "" + (y + 30));
    this.minii.setLocation(x, y + 30);
    x = (this.browsi.getLocation()).x / xalign * xalign;
    y = (this.browsi.getLocation()).y / yalign * yalign;
    DSettings.set("icon8x", "" + x);
    DSettings.set("icon8y", "" + (y + 30));
    this.browsi.setLocation(x, y + 30);
    x = (this.configi.getLocation()).x / xalign * xalign;
    y = (this.configi.getLocation()).y / yalign * yalign;
    DSettings.set("icon9x", "" + x);
    DSettings.set("icon9y", "" + (y + 30));
    this.configi.setLocation(x, y + 30);
    x = (this.debugi.getLocation()).x / xalign * xalign;
    y = (this.debugi.getLocation()).y / yalign * yalign;
    DSettings.set("icon10x", "" + x);
    DSettings.set("icon10y", "" + (y + 30));
    this.debugi.setLocation(x, y + 30);
    x = (this.tapei.getLocation()).x / xalign * xalign;
    y = (this.tapei.getLocation()).y / yalign * yalign;
    DSettings.set("icon11x", "" + x);
    DSettings.set("icon11y", "" + (y + 30));
    this.tapei.setLocation(x, y + 30);
    x = (this.painti.getLocation()).x / xalign * xalign;
    y = (this.painti.getLocation()).y / yalign * yalign;
    DSettings.set("icon12x", "" + x);
    DSettings.set("icon12y", "" + (y + 30));
    this.painti.setLocation(x, y + 30);
    x = (this.inii.getLocation()).x / xalign * xalign;
    y = (this.inii.getLocation()).y / yalign * yalign;
    DSettings.set("icon13x", "" + x);
    DSettings.set("icon13y", "" + (y + 30));
    this.inii.setLocation(x, y + 30);
    x = (this.newii.getLocation()).x / xalign * xalign;
    y = (this.newii.getLocation()).y / yalign * yalign;
    DSettings.set("icon14x", "" + x);
    DSettings.set("icon14y", "" + (y + 30));
    this.newii.setLocation(x, y + 30);
    x = (this.oldii.getLocation()).x / xalign * xalign;
    y = (this.oldii.getLocation()).y / yalign * yalign;
    DSettings.set("icon15x", "" + x);
    DSettings.set("icon15y", "" + (y + 30));
    this.oldii.setLocation(x, y + 30);
    x = (this.tiledi.getLocation()).x / xalign * xalign;
    y = (this.tiledi.getLocation()).y / yalign * yalign;
    DSettings.set("icon16x", "" + x);
    DSettings.set("icon16y", "" + (y + 30));
    this.tiledi.setLocation(x, y + 30);
    x = (this.assembli.getLocation()).x / xalign * xalign;
    y = (this.assembli.getLocation()).y / yalign * yalign;
    DSettings.set("icon17x", "" + x);
    DSettings.set("icon17y", "" + (y + 30));
    this.assembli.setLocation(x, y + 30);
    x = (this.calci.getLocation()).x / xalign * xalign;
    y = (this.calci.getLocation()).y / yalign * yalign;
    DSettings.set("icon18x", "" + x);
    DSettings.set("icon18y", "" + (y + 30));
    this.calci.setLocation(x, y + 30);
    x = (this.paci.getLocation()).x / xalign * xalign;
    y = (this.paci.getLocation()).y / yalign * yalign;
    DSettings.set("icon19x", "" + x);
    DSettings.set("icon19y", "" + (y + 30));
    this.paci.setLocation(x, y + 30);
    x = (this.flopyi.getLocation()).x / xalign * xalign;
    y = (this.flopyi.getLocation()).y / yalign * yalign;
    DSettings.set("icon20x", "" + x);
    DSettings.set("icon20y", "" + (y + 30));
    this.flopyi.setLocation(x, y + 30);
    x = (this.pokei.getLocation()).x / xalign * xalign;
    y = (this.pokei.getLocation()).y / yalign * yalign;
    DSettings.set("icon21x", "" + x);
    DSettings.set("icon21y", "" + (y + 30));
    this.pokei.setLocation(x, y + 30);
    x = (this.webi.getLocation()).x / xalign * xalign;
    y = (this.webi.getLocation()).y / yalign * yalign;
    DSettings.set("icon22x", "" + x);
    DSettings.set("icon22y", "" + (y + 30));
    this.webi.setLocation(x, y + 30);
    x = (this.radioi.getLocation()).x / xalign * xalign;
    y = (this.radioi.getLocation()).y / yalign * yalign;
    DSettings.set("icon23x", "" + x);
    DSettings.set("icon23y", "" + (y + 30));
    this.radioi.setLocation(x, y + 30);
    x = (this.chati.getLocation()).x / xalign * xalign;
    y = (this.chati.getLocation()).y / yalign * yalign;
    DSettings.set("icon24x", "" + x);
    DSettings.set("icon24y", "" + (y + 30));
    this.chati.setLocation(x, y + 30);
    x = (this.favi.getLocation()).x / xalign * xalign;
    y = (this.favi.getLocation()).y / yalign * yalign;
    DSettings.set("icon25x", "" + x);
    DSettings.set("icon25y", "" + (y + 30));
    this.favi.setLocation(x, y + 30);
    x = (this.dski.getLocation()).x / xalign * xalign;
    y = (this.dski.getLocation()).y / yalign * yalign;
    DSettings.set("icon26x", "" + x);
    DSettings.set("icon26y", "" + (y + 30));
    this.dski.setLocation(x, y + 30);
    x = (this.atarii.getLocation()).x / xalign * xalign;
    y = (this.atarii.getLocation()).y / yalign * yalign;
    DSettings.set("icon27x", "" + x);
    DSettings.set("icon27y", "" + (y + 30));
    this.atarii.setLocation(x, y + 30);
    x = (this.gx4000i.getLocation()).x / xalign * xalign;
    y = (this.gx4000i.getLocation()).y / yalign * yalign;
    DSettings.set("icon28x", "" + x);
    DSettings.set("icon28y", "" + (y + 30));
    this.gx4000i.setLocation(x, y + 30);
    x = (this.deathi.getLocation()).x / xalign * xalign;
    y = (this.deathi.getLocation()).y / yalign * yalign;
    DSettings.set("icon29x", "" + x);
    DSettings.set("icon29y", "" + (y + 30));
    this.deathi.setLocation(x, y + 30);
    x = (this.bddi.getLocation()).x / xalign * xalign;
    y = (this.bddi.getLocation()).y / yalign * yalign;
    DSettings.set("icon30x", "" + x);
    DSettings.set("icon30y", "" + (y + 30));
    this.bddi.setLocation(x, y + 30);
    x = (this.cdi.getLocation()).x / xalign * xalign;
    y = (this.cdi.getLocation()).y / yalign * yalign;
    DSettings.set("icon31x", "" + x);
    DSettings.set("icon31y", "" + (y + 30));
    this.cdi.setLocation(x, y + 30);
    x = (this.rolandi.getLocation()).x / xalign * xalign;
    y = (this.rolandi.getLocation()).y / yalign * yalign;
    DSettings.set("icon32x", "" + x);
    DSettings.set("icon32y", "" + (y + 30));
    this.rolandi.setLocation(x, y + 30);
    x = (this.rasteri.getLocation()).x / xalign * xalign;
    y = (this.rasteri.getLocation()).y / yalign * yalign;
    DSettings.set("icon33x", "" + x);
    DSettings.set("icon33y", "" + (y + 30));
    this.rasteri.setLocation(x, y + 30);
  }
  
  public static void checkDSKUtil() {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            if (Desktop.dsku == null) {
              Desktop.dsku = new DSKUtil();
              Desktop.dskutil.setLayout(new BorderLayout());
              Desktop.dskutil.add(Desktop.dsku.disktools);
              Desktop.dskutil.pack();
            } 
            Desktop.dskutil.setVisible(true);
          }
        });
  }
  
  protected void addAtari() {
    if (this.atari == null) {
      String[] args = new String[0];
      this.atari = new AtariPanel(args);
      this.at800.add(this.atari.emu(args), "Center");
      this.at800.pack();
      Display.showpause = 4;
      JEMU.pausetimer = 1;
    } 
    this.at800.setVisible(true);
  }
  
  boolean isPlusShowing = false;
  
  JaC64 c64;
  
  private ArrayList<DropTarget> dropTargetList;
  
  JInternalFrame pacframe;
  
  static DSKUtil dsku;
  
  protected void addC64() {
    if (this.c64 == null) {
      this.c64 = new JaC64();
      Thread c64Engine = new Thread() {
          public void run() {
            Desktop.this.c64.cpu.start();
          }
        };
      c64Engine.start();
      EventQueue.invokeLater(new Runnable() {
            public void run() {
              Desktop.this.desktop.add(Desktop.this.c64.C64Win);
              Desktop.this.c64.C64Win.requestFocus();
              Desktop.this.c64.C64Win.setLocation(JEMU.iframe.getLocation());
              Desktop.this.c64.C64Win.setVisible(true);
              Desktop.this.c64.C64Win.toFront();
              JEMU.iframe.setVisible(false);
            }
          });
    } else {
      this.c64.C64Win.requestFocus();
      this.c64.C64Win.setVisible(true);
      this.c64.C64Win.toFront();
      this.c64.C64Win.setLocation(JEMU.iframe.getLocation());
      JEMU.iframe.setVisible(false);
    } 
  }
  
  protected void addPlus() {
    if (this.plus == null) {
      Thread d = new Thread() {
          public void run() {
            if (Desktop.this.plus == null) {
              Desktop.this.plus = new GX4000();
              Desktop.this.plus.init(Desktop.this.getLocale().toString().toUpperCase());
              GX4000.isStandalone = false;
              Desktop.this.plus.startEmbedded();
            } 
            EventQueue.invokeLater(new Runnable() {
                  public void run() {
                    Desktop.this.gx4000 = Desktop.this.plus.getEmu(Desktop.this.plus);
                    Desktop.this.desktop.add(Desktop.this.gx4000);
                    Desktop.this.gx4000.setLocation(100, 100);
                    Desktop.this.plus.getComputer().start();
                    Desktop.this.isPlusShowing = true;
                    Desktop.this.gx4000.setVisible(true);
                    Desktop.this.plus.startMotor();
                    Desktop.this.plus.display.requestFocus();
                  }
                });
          }
        };
      d.start();
    } 
    if (this.gx4000 != null) {
      this.isPlusShowing = true;
      this.gx4000.setVisible(true);
      this.plus.startMotor();
      this.plus.display.requestFocus();
    } 
    JEMU.pausetimer = 1;
    Display.showpause = 4;
  }
  
  protected void dsk2cdt() {
    if (this.dsk2cd == null) {
      this.dsk2cd = new JInternalFrame("DSK2CDT");
      this.dsk2cd.setLayout(new BorderLayout());
      this.dsk2cd.add(new DSK2CDT());
      this.dsk2cd.pack();
      this.dsk2cd.setClosable(true);
      this.dsk2cd.setResizable(true);
      this.dsk2cd.setIconifiable(true);
      this.dsk2cd.setMaximizable(true);
      this.dsk2cd.setDefaultCloseOperation(1);
      this.desktop.add(this.dsk2cd);
    } 
    this.dsk2cd.setVisible(true);
  }
  
  protected void makeGFXViewer() {
    if ((GateArray.cpc.getDisplay()).gfxView == null) {
      (GateArray.cpc.getDisplay()).gfxView = new GraphicsViewer();
      this.gfxview = new JInternalFrame("JavaCPC GFXViewer");
      this.gfxview.setLayout(new BorderLayout());
      this.gfxview.add((GateArray.cpc.getDisplay()).gfxView.getPanel(), "Center");
      this.gfxview.pack();
      this.gfxview.setClosable(true);
      this.gfxview.setResizable(true);
      this.gfxview.setIconifiable(true);
      this.gfxview.setMaximizable(true);
      this.gfxview.setDefaultCloseOperation(1);
      this.desktop.add(this.gfxview);
    } 
    this.gfxview.setVisible(true);
  }
  
  public void windowOpened(WindowEvent w) {}
  
  public static boolean brenabled = false;
  
  protected Interface Assembler;
  
  public static boolean isDesktop = false;
  
  Mandel3 mand;
  
  MapEditor map = null;
  
  static boolean packed = true;
  
  int pages = 6;
  
  int infoindex = 1;
  
  public int ic1x;
  
  public int ic1y;
  
  public int ic2x;
  
  public int ic2y;
  
  public int ic3x;
  
  public int ic3y;
  
  public int ic4x;
  
  public int ic4y;
  
  public int ic5x;
  
  public int ic5y;
  
  public int ic6x;
  
  public int ic6y;
  
  public int ic7x;
  
  public int ic7y;
  
  public int ic8x;
  
  public int ic8y;
  
  public int ic9x;
  
  public int ic9y;
  
  public int ic10x;
  
  public int ic10y;
  
  public int ic11x;
  
  public int ic11y;
  
  public int ic12x;
  
  public int ic12y;
  
  public int ic13x;
  
  public int ic13y;
  
  public int ic14x;
  
  public int ic14y;
  
  public int ic15x;
  
  public int ic15y;
  
  public int ic16x;
  
  public int ic16y;
  
  public int ic17x;
  
  public int ic17y;
  
  public int ic18x;
  
  public int ic18y;
  
  public int ic19x;
  
  public int ic19y;
  
  public int ic20x;
  
  public int ic20y;
  
  public int ic21x;
  
  public int ic21y;
  
  public int ic22x;
  
  public int ic22y;
  
  public int ic23x;
  
  public int ic23y;
  
  public int ic24x;
  
  public int ic24y;
  
  public int ic25x;
  
  public int ic25y;
  
  public int ic26x;
  
  public int ic26y;
  
  public int ic27x;
  
  public int ic27y;
  
  public int ic28x;
  
  public int ic28y;
  
  public int ic29x;
  
  public int ic29y;
  
  public int ic30x;
  
  public int ic30y;
  
  public int ic31x;
  
  public int ic31y;
  
  public int ic32x;
  
  public int ic32y;
  
  public int ic33x;
  
  public int ic33y;
  
  public int ic34x;
  
  public int ic34y;
  
  public int ic35x;
  
  public int ic35y;
  
  public int clockx;
  
  public int clocky;
  
  private Image wallpaper;
  
  private boolean stretch;
  
  private boolean tiled;
  
  JPanel keyBoard;
  
  JInternalFrame ini;
  
  public static boolean ej0;
  
  public static boolean ej1;
  
  public static boolean ej2;
  
  public static boolean ej3;
  
  public static boolean checkdrives;
  
  public static boolean ld0;
  
  public static boolean ld1;
  
  public static boolean ld2;
  
  public static boolean ld3;
  
  public static boolean loadtape;
  
  public static boolean savetape;
  
  public static boolean convert;
  
  public static JInternalFrame debug;
  
  private int starttimer = 0;
  
  public static boolean started = false;
  
  boolean xms = false;
  
  private int makeemu = 0;
  
  HexEditor hex;
  
  public static Browser web;
  
  public static int _DESKTOP = 0;
  
  public static int _VIDEO = 1;
  
  public static int _AUDIO = 2;
  
  public static int _SYSTEM = 3;
  
  public static int _ROMS = 4;
  
  public static int _DRIVES = 5;
  
  public static int _MISC = 6;
  
  public static int _ABOUT = 7;
  
  public static AudioCapture cap;
  
  boolean enable = true;
  
  YMControl ymplayer;
  
  boolean alarmenabled = false;
  
  String min = "";
  
  String hour = "";
  
  String sec = "";
  
  Calendar cal;
  
  int almin;
  
  int alhour;
  
  String amin;
  
  String ahour;
  
  protected String time = "";
  
  protected String adate = "";
  
  Console console;
  
  public static double[] volumes;
  
  protected DKnob volumeslider = new DKnob("AY-Volume");
  
  protected DKnob digiblastervolumeslider = new DKnob("Digiblaster");
  
  public int getInt(String input) {
    return Integer.parseInt(input);
  }
  
  public void unRegistered(String subject) {}
  
  public void OpenBrowser() {
    siteurl = "http://cpc-live.com";
    browsertimer = 1;
  }
  
  public static void openPage(String url) {
    siteurl = url;
    browsertimer = 1;
  }
  
  static int browsertimer = 0;
  
  static String siteurl;
  
  private JInternalFrame pokeframe;
  
  public void reArrange() {
    this.GlossyClock.setLocation(this.clockx, this.clocky);
    this.capi.setLocation(this.ic1x, this.ic1y);
    this.ymi.setLocation(this.ic2x, this.ic2y);
    this.hexi.setLocation(this.ic3x, this.ic3y);
    this.clocki.setLocation(this.ic4x, this.ic4y);
    this.infoi.setLocation(this.ic5x, this.ic5y);
    this.consoli.setLocation(this.ic6x, this.ic6y);
    this.minii.setLocation(this.ic7x, this.ic7y);
    this.browsi.setLocation(this.ic8x, this.ic8y);
    this.configi.setLocation(this.ic9x, this.ic9y);
    this.debugi.setLocation(this.ic10x, this.ic10y);
    this.tapei.setLocation(this.ic11x, this.ic11y);
    this.painti.setLocation(this.ic12x, this.ic12y);
    this.inii.setLocation(this.ic13x, this.ic13y);
    this.newii.setLocation(this.ic14x, this.ic14y);
    this.oldii.setLocation(this.ic15x, this.ic15y);
    this.tiledi.setLocation(this.ic16x, this.ic16y);
    this.assembli.setLocation(this.ic17x, this.ic17y);
    this.calci.setLocation(this.ic18x, this.ic18y);
    this.paci.setLocation(this.ic19x, this.ic19y);
    this.flopyi.setLocation(this.ic20x, this.ic20y);
    this.pokei.setLocation(this.ic21x, this.ic21y);
    this.webi.setLocation(this.ic22x, this.ic22y);
    this.radioi.setLocation(this.ic23x, this.ic23y);
    this.chati.setLocation(this.ic24x, this.ic24y);
    this.favi.setLocation(this.ic25x, this.ic25y);
    this.dski.setLocation(this.ic26x, this.ic26y);
    this.atarii.setLocation(this.ic27x, this.ic27y);
    this.gx4000i.setLocation(this.ic28x, this.ic28y);
    this.deathi.setLocation(this.ic29x, this.ic29y);
    this.bddi.setLocation(this.ic30x, this.ic30y);
    this.cdi.setLocation(this.ic31x, this.ic31y);
    this.rolandi.setLocation(this.ic32x, this.ic32y);
    this.rasteri.setLocation(this.ic33x, this.ic33y);
    DSettings.set("clockx", "" + this.clockx);
    DSettings.set("clocky", "" + this.clocky);
    DSettings.set("icon1x", "" + this.ic1x);
    DSettings.set("icon1y", "" + this.ic1y);
    DSettings.set("icon2x", "" + this.ic2x);
    DSettings.set("icon2y", "" + this.ic2y);
    DSettings.set("icon3x", "" + this.ic3x);
    DSettings.set("icon3y", "" + this.ic3y);
    DSettings.set("icon4x", "" + this.ic4x);
    DSettings.set("icon4y", "" + this.ic4y);
    DSettings.set("icon5x", "" + this.ic5x);
    DSettings.set("icon5y", "" + this.ic5y);
    DSettings.set("icon6x", "" + this.ic6x);
    DSettings.set("icon6y", "" + this.ic6y);
    DSettings.set("icon7x", "" + this.ic7x);
    DSettings.set("icon7y", "" + this.ic7y);
    DSettings.set("icon8x", "" + this.ic8x);
    DSettings.set("icon8y", "" + this.ic8y);
    DSettings.set("icon9x", "" + this.ic9x);
    DSettings.set("icon9y", "" + this.ic9y);
    DSettings.set("icon10x", "" + this.ic10x);
    DSettings.set("icon10y", "" + this.ic10y);
    DSettings.set("icon11x", "" + this.ic11x);
    DSettings.set("icon11y", "" + this.ic11y);
    DSettings.set("icon12x", "" + this.ic12x);
    DSettings.set("icon12y", "" + this.ic12y);
    DSettings.set("icon13x", "" + this.ic13x);
    DSettings.set("icon13y", "" + this.ic13y);
    DSettings.set("icon14x", "" + this.ic14x);
    DSettings.set("icon14y", "" + this.ic14y);
    DSettings.set("icon15x", "" + this.ic15x);
    DSettings.set("icon15y", "" + this.ic15y);
    DSettings.set("icon16x", "" + this.ic16x);
    DSettings.set("icon16y", "" + this.ic16y);
    DSettings.set("icon17x", "" + this.ic17x);
    DSettings.set("icon17y", "" + this.ic17y);
    DSettings.set("icon18x", "" + this.ic18x);
    DSettings.set("icon18y", "" + this.ic18y);
    DSettings.set("icon19x", "" + this.ic19x);
    DSettings.set("icon19y", "" + this.ic19y);
    DSettings.set("icon20x", "" + this.ic20x);
    DSettings.set("icon20y", "" + this.ic20y);
    DSettings.set("icon21x", "" + this.ic21x);
    DSettings.set("icon21y", "" + this.ic21y);
    DSettings.set("icon22x", "" + this.ic22x);
    DSettings.set("icon22y", "" + this.ic22y);
    DSettings.set("icon23x", "" + this.ic23x);
    DSettings.set("icon23y", "" + this.ic23y);
    DSettings.set("icon24x", "" + this.ic24x);
    DSettings.set("icon24y", "" + this.ic24y);
    DSettings.set("icon25x", "" + this.ic25x);
    DSettings.set("icon25y", "" + this.ic25y);
    DSettings.set("icon26x", "" + this.ic26x);
    DSettings.set("icon26y", "" + this.ic26y);
    DSettings.set("icon27x", "" + this.ic27x);
    DSettings.set("icon27y", "" + this.ic27y);
    DSettings.set("icon28x", "" + this.ic28x);
    DSettings.set("icon28y", "" + this.ic28y);
    DSettings.set("icon29x", "" + this.ic29x);
    DSettings.set("icon29y", "" + this.ic29y);
    DSettings.set("icon30x", "" + this.ic30x);
    DSettings.set("icon30y", "" + this.ic30y);
    DSettings.set("icon31x", "" + this.ic31x);
    DSettings.set("icon31y", "" + this.ic31y);
    DSettings.set("icon32x", "" + this.ic32x);
    DSettings.set("icon32y", "" + this.ic32y);
    DSettings.set("icon33x", "" + this.ic33x);
    DSettings.set("icon33y", "" + this.ic33y);
  }
  
  private static void registerDropListener(ArrayList<DropTarget> list, Container basePanel, DropListener myListener) {
    list.add(new DropTarget(basePanel, myListener));
    Component[] components = basePanel.getComponents();
    for (int i = 0; i < components.length; i++) {
      Component component = components[i];
      if (component instanceof Container) {
        registerDropListener(list, (Container)component, myListener);
      } else {
        list.add(new DropTarget(component, myListener));
      } 
    } 
  }
  
  private class DropListener extends DropTargetAdapter {
    private DropListener() {}
    
    public void drop(DropTargetDropEvent droptarget) {
      try {
        Transferable t = droptarget.getTransferable();
        if (t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
          droptarget.acceptDrop(3);
          Object userObject = t.getTransferData(DataFlavor.javaFileListFlavor);
          if (userObject instanceof List) {
            String fileName = ((List<E>)userObject).get(0).toString();
            if (fileName.toLowerCase().endsWith(".jpg") || fileName
              .toLowerCase().endsWith(".png") || fileName
              .toLowerCase().endsWith(".gif")) {
              DSettings.set("wallpaper", fileName);
              Desktop.this.setWallpaper();
              Desktop.this.desktop.repaint();
              return;
            } 
          } 
          droptarget.dropComplete(true);
        } 
      } catch (Exception exception) {}
    }
  }
  
  public void launchPokes() {
    if (this.pokeframe == null) {
      this.pokeframe = new JInternalFrame("JavaCPC Pokefinder");
      this.desktop.add(this.pokeframe);
      this.pokeframe.toFront();
      this.pokeframe.setIconifiable(true);
      this.pokeframe.setClosable(true);
      this.pokeframe.setDefaultCloseOperation(1);
      this.pokes = new Thread() {
          public void run() {
            PokeFinder poke = new PokeFinder();
            Desktop.this.pokeframe.add(poke.getComponent(0));
            Desktop.this.pokeframe.pack();
            Desktop.this.pokeframe.setVisible(true);
          }
        };
      this.pokes.start();
    } 
    this.pokeframe.setVisible(true);
    this.pokeframe.toFront();
    try {
      this.pokeframe.setSelected(true);
    } catch (Exception exception) {}
  }
  
  ActionListener updateClock = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Desktop.this.clock();
      }
    };
  
  Timer clocker = new Timer(125, this.updateClock);
  
  VolumeDiagram vdig;
  
  RasterPaint rasterpaint;
  
  JInternalFrame chatframe;
  
  Favourites favs;
  
  JInternalFrame favp;
  
  int openchat;
  
  WallpaperBox wallpaperbox;
  
  Color flow1;
  
  Color flow2;
  
  Color selected;
  
  Color white;
  
  Color black;
  
  Color sec1;
  
  Color sec2;
  
  Color sec3;
  
  NimRODTheme nt;
  
  int choosenlook;
  
  boolean pluslook;
  
  GameBrowser browser;
  
  public String[] loroms;
  
  public String[] upr0;
  
  public String[] upr1;
  
  public String[] upr2;
  
  public String[] upr3;
  
  public String[] upr4;
  
  public String[] upr5;
  
  public String[] upr6;
  
  public String[] upr7;
  
  public String[] upr8;
  
  public String[] upr9;
  
  public String[] upr10;
  
  public String[] upr11;
  
  public String[] upr12;
  
  public String[] upr13;
  
  public String[] upr14;
  
  public String[] upr15;
  
  public String[] rom;
  
  ImageIcon pressed;
  
  ImageIcon hovered;
  
  Panel[] pan;
  
  JPanel[] jpan;
  
  JLabel[] pans;
  
  JTextField[] pant;
  
  JTextField[] pants;
  
  boolean haspan;
  
  SyntheticaLic lic;
  
  Romsetter32 romSetter32;
  
  Robot fillrobot;
  
  Rectangle[] fillrect;
  
  BufferedImage[] fillimage;
  
  int[] puffer;
  
  public void setLook() {
    File check = new File("lib/synthetica.jar");
    String version = System.getProperty("java.version");
    if ((check.exists() && version.contains("1.7.0")) || version.contains("1.8.0")) {
      this.helper.synthetica = true;
    } else {
      this.helper.synthetica = false;
    } 
    UIManager.put("InternalFrame.closeButtonToolTip", "");
    UIManager.put("InternalFrame.iconButtonToolTip", "");
    UIManager.put("InternalFrame.restoreButtonToolTip", "");
    UIManager.put("InternalFrame.maxButtonToolTip", "");
    this.helper.look = Integer.parseInt(DSettings.get("look", "4"));
    setLook(this.helper.look);
  }
  
  private void jComboBox1ItemStateChanged(ItemEvent evt) {
    checkvideo(this.filterChooser.getSelectedIndex());
  }
  
  public void openRadio() {
    if (this.subpop == null || (!this.subpop.isShowing() && !this.subpop.isIcon())) {
      this.subpop = (new SceneRadio()).getPlayer();
      this.desktop.add(this.subpop);
    } 
    this.subpop.setVisible(true);
    this.subpop.toFront();
  }
  
  public void openRasterPaint() {
    if (this.rasterpaint == null) {
      this.rasterpaint = new RasterPaint();
      this.rasterFrame.add(this.rasterpaint.rasterpaint, "Center");
    } 
    this.rasterpaint.init();
    this.rasterFrame.setVisible(true);
  }
  
  public void addRadio() {
    debugger = true;
    debug.setVisible(true);
    JEMU.debugger.computer.stop();
    Display.initgfxviewer = 1;
  }
  
  public void addFavs() {
    if (this.favs == null) {
      this.favs = new Favourites();
      this.favp = new JInternalFrame("Favourite-Browser");
      this.favp.setLayout(new BorderLayout());
      this.favp.add(this.favs);
      this.favp.setDefaultCloseOperation(1);
      this.favp.setIconifiable(true);
      this.favp.setClosable(true);
      this.favp.setMaximizable(true);
      this.favp.setPreferredSize(new Dimension(500, 400));
      this.favp.pack();
      this.desktop.add(this.favp);
      this.favp.setLocation(100, 100);
      this.favp.setResizable(true);
    } 
    this.favp.setVisible(true);
  }
  
  public void openWebPage() {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            try {
              if (Desktop.web == null) {
                Desktop.web = new Browser();
                Desktop.webbrowser.setLayout(new GridLayout(1, 1));
                Desktop.webbrowser.add(Desktop.web);
              } 
              Desktop.web.setURL(Desktop.siteurl);
              Desktop.webbrowser.setVisible(true);
            } catch (Exception e) {
              JEMU.openWebPage(Desktop.siteurl);
            } 
          }
        });
  }
  
  public Desktop() {
    this.openchat = 0;
    this.pluslook = true;
    this.pressed = new ImageIcon(getClass().getResource("/jemu/ui/icon/icborderclicked.png"));
    this.hovered = new ImageIcon(getClass().getResource("/jemu/ui/icons/icborder.png"));
    this.pan = new Panel[17];
    this.jpan = new JPanel[17];
    this.pans = new JLabel[17];
    this.pant = new JTextField[17];
    this.pants = new JTextField[17];
    this.haspan = false;
    this.fillrect = new Rectangle[10];
    this.fillimage = new BufferedImage[10];
    this.puffer = new int[] { 256, 512, 1024, 2048, 4096, 6144 };
    this.slots = new String[] { 
        "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
        "A", "B", "C", "D", "E", "F" };
    this.causedalarm = false;
    this.lighttimer = 0;
    this.thisWidth = 0;
    this.headpos = 0;
    this.oldpos = 0;
    this.hideglass = 0;
    this.palupdated = false;
    this.errcount = 0;
    this.hasstarted = 0;
    this.alignIcons = true;
    if (isDesktop)
      setLook(); 
    this.cal = Calendar.getInstance();
    this.time = "  " + this.cal.get(11) + ":" + this.cal.get(12) + ":" + this.cal.get(13);
    this.adate = "  " + this.cal.get(5) + "." + this.cal.get(2) + "." + this.cal.get(1);
    Clock clocks = new Clock();
    clocks.setSize(250, 250);
    try {
      this.labelstart = ImageIO.read(getClass().getResource("/jemu/ui/icon/startmenu.png"));
    } catch (Exception exception) {}
    initComponents();
    CPCMemory.showram = Settings.getBoolean("display_mem", false);
    this.memorydisplay.setSelected(CPCMemory.showram);
    JEMU.SF2Mouse = Settings.getBoolean("sf3_mouse", false);
    this.jCheckBox20.setSelected(JEMU.SF2Mouse);
    this.jMon8.setVisible(false);
    this.keyclash.setSelected(Settings.getBoolean("keyboard_clash", true));
    hideMouse.setSelected(Settings.getBoolean("hidemouse", false));
    this.chipnoise.setSelected(Settings.getBoolean("chipnoise", false));
    AY_3_8910.liveNoise = this.chipnoise.isSelected();
    Printer.matrixprinter = Settings.getBoolean("dmp_printer", false);
    this.jRadioButton3.setSelected(!Printer.matrixprinter);
    this.jRadioButton4.setSelected(Printer.matrixprinter);
    this.accelerate.setSelected(!Settings.getBoolean("3d_acceleration", false));
    int p = Settings.getInt("audio_puffersize", this.puffer[this.jComboBox3.getSelectedIndex()]);
    for (int i = 0; i < this.puffer.length; i++) {
      if (this.puffer[i] == p) {
        this.jComboBox3.setSelectedIndex(i);
        break;
      } 
    } 
    this.pufferl.setVisible(false);
    this.alignIcons = DSettings.getBoolean("align", false);
    this.iconsAlign.setSelected(this.alignIcons);
    this.starttab.setVisible(false);
    this.starttab.pack();
    this.desktop.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent e) {
            if (e.isPopupTrigger())
              Desktop.this.pop.show(Desktop.this.desktop, e.getX(), e.getY()); 
          }
        });
    CPC.WinCPC = Settings.getBoolean("wincpc_floppy_samples", false);
    this.jComboBox2.setSelectedIndex(CPC.WinCPC ? 1 : 0);
    sync.setSelected(Settings.getBoolean("sync_64bit", false));
    this.atarii.setVisible(false);
    File checkegg = new File(Main.path, "ATARIXL.ROM");
    if (checkegg.exists()) {
      checkegg = new File(Main.path, "ATARIBAS.ROM");
      if (checkegg.exists())
        this.atarii.setVisible(true); 
    } 
    this.roms32.setSelected(Settings.getBoolean("32_roms_enabled", false));
    this.set32roms.setEnabled(this.roms32.isSelected());
    JEMU.update3d = Settings.getBoolean("use_3d", false);
    Display.use3d = JEMU.update3d;
    JEMU.pckeyboard = Settings.getBoolean("native_keyboard", false);
    this.jCheckBox18.setSelected(JEMU.pckeyboard);
    this.jCheckBox16.setSelected(Display.use3d);
    this.jCheckBox17.setSelected(Settings.getBoolean("simple_textures", true));
    cprload.setVisible(false);
    this.pluson.setVisible(false);
    this;
    cprfile.setVisible(false);
    this.jPanel58.setVisible(false);
    this.audiodisplay.setLayout(new BorderLayout());
    this.vdig = new VolumeDiagram();
    this.vdig.put();
    this.audiodisplay.add(this.vdig, "Center");
    slic.setVisible(false);
    if (this.choosenlook > 21 && this.choosenlook < 36)
      slic.setVisible(true); 
    setVisible(false);
    this.pal.setSelected(Settings.getBoolean("pal", false));
    Display.PAL = this.pal.isSelected();
    this.pal1.setSelected(Settings.getBoolean("pal_double", false));
    Display.reverse = this.pal1.isSelected();
    this.palvalue.setValue(Integer.parseInt(Settings.get("pal_value", "1")));
    Display.blur = this.palvalue.getValue();
    this.palvalue1.setValue(Integer.parseInt(Settings.get("pal_snow", "124")));
    Display.snow = this.palvalue1.getValue();
    Display.PAL = this.pal.isSelected();
    this.jCheckBox14.setSelected(Settings.getBoolean("speaker", false));
    int r = 20;
    String a = Settings.get("filtervalue", "20");
    try {
      r = Integer.parseInt(a);
    } catch (Exception exception) {}
    a = Settings.get("ga_type", "40008");
    if (a.equals("40010")) {
      this.jRadioButton2.setSelected(true);
      this.jRadioButton1.setSelected(false);
      setGaType();
    } else {
      this.jRadioButton2.setSelected(false);
      this.jRadioButton1.setSelected(true);
      setGaType();
    } 
    level.setValue(r);
    this.jCheckBox15.setSelected(Settings.getBoolean("filter", false));
    AY_3_8910.Speaker = this.jCheckBox14.isSelected();
    AudioFilter.lowpass = this.jCheckBox15.isSelected();
    localize.setSelected(Settings.getBoolean("localize_roms", true));
    fullSize.setSelected(Settings.getBoolean("large", true));
    doubSize.setSelected(Settings.getBoolean("double_size", false));
    tripleSize.setSelected(Settings.getBoolean("triple_size", false));
    quadSize.setSelected(Settings.getBoolean("quadro_size", false));
    freeSize.setSelected(Settings.getBoolean("free_size", false));
    if (!fullSize.isSelected() && !doubSize.isSelected() && !tripleSize.isSelected() && !quadSize.isSelected() && !freeSize.isSelected())
      simpSize.setSelected(true); 
    this.clockPanel.add(clocks);
    clocks.fireUpdate.start();
    showGlass.setVisible(false);
    InputStream in = getClass().getResourceAsStream("printer.ttf");
    try {
      Font fonts = Font.createFont(0, in).deriveFont(0, 9.0F);
      printout.setFont(fonts);
    } catch (Exception e) {
      printout.setFont(new Font("Monospaced", 1, 12));
    } 
    this.helper.scroll = new Scroller();
    this.scrollinfo.add(this.helper.scroll);
    this.helper.scroll.init();
    this.helper.scroll.setCols(this.infopanel.getBackground(), this.infopanel.getForeground());
    Display.superPAL = Settings.getBoolean("superpal", false);
    this.jCheckBox11.setSelected(Settings.getBoolean("multiface", false));
    this.superPal.setSelected(Display.superPAL);
    this.dropTargetList = new ArrayList<>();
    DropListener myListener = new DropListener();
    registerDropListener(this.dropTargetList, this.desktop, myListener);
    this.calc.add((new SciCalc()).getContentPane());
    this.calc.pack();
    checkDisabled();
    addWindowListener(this);
    this.audioformat.setSelectedIndex(Integer.parseInt(Settings.get("samplerate", "1")));
    this.restartj.setVisible(false);
    this.forced.setVisible(false);
    Switches.frequency = Settings.getInt("frequency", 16);
    if (Switches.frequency == 0)
      this.freq.setSelected(true); 
    Basic6845.patch = Settings.getBoolean("crtcpatch", true);
    this.crtc.setSelected(Basic6845.patch);
    Speech.enabled = Settings.getBoolean("speech", false);
    this.spenable.setSelected(Speech.enabled);
    this.ssa1.setEnabled(Speech.enabled);
    this.ssa1.setSelected(Settings.getBoolean("ssa1_mode", false));
    Speech.SSA = this.ssa1.isSelected();
    this.dkt.setSelected(!Speech.SSA);
    this.dkt.setEnabled(Speech.enabled);
    this.fastdisk.setSelected(Settings.getBoolean("fastdisk", true));
    UPD765A.fastdisk = this.fastdisk.isSelected();
    this;
    setExtendedState(getExtendedState() | 0x6);
    setWallpaper();
    this.stretch = DSettings.getBoolean("stretch", false);
    this.tiled = DSettings.getBoolean("tiled", false);
    this.expand.setSelected(DSettings.getBoolean("undecorate", false));
    if (DSettings.get("use_desktop", "yes").equals("yes")) {
      this.expand.setEnabled(true);
    } else {
      this.expand.setEnabled(false);
    } 
    if (Main.stretch != null) {
      Main.stretch = Main.stretch.toLowerCase();
      if (Main.stretch.equals("yes") || Main.stretch.equals("1") || Main.stretch.equals("true")) {
        this.stretch = true;
        this.tiled = false;
      } else {
        this.stretch = false;
        this.tiled = false;
      } 
    } 
    this.wallstretch.setSelected(this.stretch);
    this.wallcenter.setSelected(!this.stretch);
    this.wallpreview.setFocusable(false);
    this.wallpreview.setBorder(new EtchedBorder(1));
    Display.interlace = Settings.getBoolean("de-interlace", false);
    this.jToggleButton4.setSelected(Display.interlace);
    copyURL.copyResource("aha.ym");
    if (DSettings.get("use_desktop", "not_set").equals("yes")) {
      this.deskcheck.setSelected(true);
    } else {
      this.deskcheck.setSelected(false);
    } 
    this.clocker.start();
    checkDrives();
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            Thread doDebugger = new Thread() {
                public void run() {
                  while (GateArray.cpc == null) {
                    try {
                      Thread.sleep(10L);
                    } catch (Exception exception) {}
                  } 
                  try {
                    JEMU.debugger = (Debugger)Util.secureConstructor(Debugger.class, new Class[0], new Object[0]);
                    JEMU.debugger.setBounds(0, 0, 850, 640);
                    JEMU.debugger.setMinimumSize(new Dimension(850, 640));
                    Desktop.debug = new JInternalFrame("Debugger");
                    Desktop.debug.setLayout(new BorderLayout());
                    JTabbedPane tabs = new JTabbedPane();
                    tabs.addTab("Debugger", JEMU.debugger.getContentPane());
                    if (Desktop.isDesktop) {
                      GateArray.cpc.bas = new Basic();
                      tabs.addTab("Basic Debugger", GateArray.cpc.bas.getContentPane());
                      tabs.addTab("Periphery", Desktop.this.periphery);
                    } 
                    tabs.setBounds(0, 0, 840, 600);
                    tabs.setPreferredSize(new Dimension(840, 600));
                    tabs.setMinimumSize(new Dimension(840, 600));
                    tabs.setTabPlacement(3);
                    tabs.setFocusable(false);
                    Desktop.debug.add(tabs);
                    Desktop.debug.pack();
                    Desktop.this.desktop.add(Desktop.debug);
                    Desktop.debug.setResizable(true);
                    Desktop.debug.setMaximizable(true);
                    Desktop.debug.setClosable(true);
                    Desktop.debug.setIconifiable(true);
                    Desktop.debug.setDefaultCloseOperation(1);
                  } catch (Exception e) {
                    e.printStackTrace();
                  } 
                }
              };
            doDebugger.start();
          }
        });
    options.setVisible(false);
    this.jLabel8.setCursor(new Cursor(12));
    this.jLabel85.setCursor(new Cursor(12));
    this.jLabel96.setCursor(new Cursor(12));
    this.jLabel70.setCursor(new Cursor(12));
    this.makeemu = 0;
    checkConsole();
    if (isDesktop) {
      this.starttimer = 1;
      JEMU.desktop(addToEmu);
    } 
    Switches.khz11 = Settings.getBoolean("recrate11", false);
    Switches.khz44 = Settings.getBoolean("recrate44", true);
    if (Switches.khz11) {
      this.freq11.setSelected(true);
    } else if (Switches.khz44) {
      this.freq44.setSelected(true);
    } else {
      this.freq22.setSelected(true);
    } 
    Switches.neverOverwrite = Settings.getBoolean("never_rename", false);
    this.noOverwrite.setSelected(Switches.neverOverwrite);
    this.clockx = this.GlossyClock.getX();
    this.clocky = this.GlossyClock.getY();
    this.ic1x = this.capi.getX();
    this.ic1y = this.capi.getY();
    this.ic2x = this.ymi.getX();
    this.ic2y = this.ymi.getY();
    this.ic3x = this.hexi.getX();
    this.ic3y = this.hexi.getY();
    this.ic4x = this.clocki.getX();
    this.ic4y = this.clocki.getY();
    this.ic5x = this.infoi.getX();
    this.ic5y = this.infoi.getY();
    this.ic6x = this.consoli.getX();
    this.ic6y = this.consoli.getY();
    this.ic7x = this.minii.getX();
    this.ic7y = this.minii.getY();
    this.ic8x = this.browsi.getX();
    this.ic8y = this.browsi.getY();
    this.ic9x = this.configi.getX();
    this.ic9y = this.configi.getY();
    this.ic10x = this.debugi.getX();
    this.ic10y = this.debugi.getY();
    this.ic11x = this.tapei.getX();
    this.ic11y = this.tapei.getY();
    this.ic12x = this.painti.getX();
    this.ic12y = this.painti.getY();
    this.ic13x = this.inii.getX();
    this.ic13y = this.inii.getY();
    this.ic14x = this.newii.getX();
    this.ic14y = this.newii.getY();
    this.ic15x = this.oldii.getX();
    this.ic15y = this.oldii.getY();
    this.ic16x = this.tiledi.getX();
    this.ic16y = this.tiledi.getY();
    this.ic17x = this.assembli.getX();
    this.ic17y = this.assembli.getY();
    this.ic18x = this.calci.getX();
    this.ic18y = this.calci.getY();
    this.ic19x = this.paci.getX();
    this.ic19y = this.paci.getY();
    this.ic20x = this.flopyi.getX();
    this.ic20y = this.flopyi.getY();
    this.ic21x = this.pokei.getX();
    this.ic21y = this.pokei.getY();
    this.ic22x = this.webi.getX();
    this.ic22y = this.webi.getY();
    this.ic23x = this.radioi.getX();
    this.ic23y = this.radioi.getY();
    this.ic24x = this.chati.getX();
    this.ic24y = this.chati.getY();
    this.ic25x = this.favi.getX();
    this.ic25y = this.favi.getY();
    this.ic26x = this.dski.getX();
    this.ic26y = this.dski.getY();
    this.ic27x = this.atarii.getX();
    this.ic27y = this.atarii.getY();
    this.ic28x = this.gx4000i.getX();
    this.ic28y = this.gx4000i.getY();
    this.ic29x = this.deathi.getX();
    this.ic29y = this.deathi.getY();
    this.ic30x = this.bddi.getX();
    this.ic30y = this.bddi.getY();
    this.ic31x = this.cdi.getX();
    this.ic31y = this.cdi.getY();
    this.ic32x = this.rolandi.getX();
    this.ic32y = this.rolandi.getY();
    this.ic33x = this.rasteri.getX();
    this.ic33y = this.rasteri.getY();
    this.GlossyClock.setLocation(getInt(DSettings.get("clockx", "" + this.GlossyClock.getX())), getInt(DSettings.get("clocky", "" + this.GlossyClock.getY())));
    this.capi.setLocation(getInt(DSettings.get("icon1x", "" + this.capi.getX())), getInt(DSettings.get("icon1y", "" + this.capi.getY())));
    this.ymi.setLocation(getInt(DSettings.get("icon2x", "" + this.ymi.getX())), getInt(DSettings.get("icon2y", "" + this.ymi.getY())));
    this.hexi.setLocation(getInt(DSettings.get("icon3x", "" + this.hexi.getX())), getInt(DSettings.get("icon3y", "" + this.hexi.getY())));
    this.clocki.setLocation(getInt(DSettings.get("icon4x", "" + this.clocki.getX())), getInt(DSettings.get("icon4y", "" + this.clocki.getY())));
    this.infoi.setLocation(getInt(DSettings.get("icon5x", "" + this.infoi.getX())), getInt(DSettings.get("icon5y", "" + this.infoi.getY())));
    this.consoli.setLocation(getInt(DSettings.get("icon6x", "" + this.consoli.getX())), getInt(DSettings.get("icon6y", "" + this.consoli.getY())));
    this.minii.setLocation(getInt(DSettings.get("icon7x", "" + this.minii.getX())), getInt(DSettings.get("icon7y", "" + this.minii.getY())));
    this.browsi.setLocation(getInt(DSettings.get("icon8x", "" + this.browsi.getX())), getInt(DSettings.get("icon8y", "" + this.browsi.getY())));
    this.configi.setLocation(getInt(DSettings.get("icon9x", "" + this.configi.getX())), getInt(DSettings.get("icon9y", "" + this.configi.getY())));
    this.debugi.setLocation(getInt(DSettings.get("icon10x", "" + this.debugi.getX())), getInt(DSettings.get("icon10y", "" + this.debugi.getY())));
    this.tapei.setLocation(getInt(DSettings.get("icon11x", "" + this.tapei.getX())), getInt(DSettings.get("icon11y", "" + this.tapei.getY())));
    this.painti.setLocation(getInt(DSettings.get("icon12x", "" + this.painti.getX())), getInt(DSettings.get("icon12y", "" + this.painti.getY())));
    this.inii.setLocation(getInt(DSettings.get("icon13x", "" + this.inii.getX())), getInt(DSettings.get("icon13y", "" + this.inii.getY())));
    this.newii.setLocation(getInt(DSettings.get("icon14x", "" + this.newii.getX())), getInt(DSettings.get("icon14y", "" + this.newii.getY())));
    this.oldii.setLocation(getInt(DSettings.get("icon15x", "" + this.oldii.getX())), getInt(DSettings.get("icon15y", "" + this.oldii.getY())));
    this.tiledi.setLocation(getInt(DSettings.get("icon16x", "" + this.tiledi.getX())), getInt(DSettings.get("icon16y", "" + this.tiledi.getY())));
    this.assembli.setLocation(getInt(DSettings.get("icon17x", "" + this.assembli.getX())), getInt(DSettings.get("icon17y", "" + this.assembli.getY())));
    this.calci.setLocation(getInt(DSettings.get("icon18x", "" + this.calci.getX())), getInt(DSettings.get("icon18y", "" + this.calci.getY())));
    this.paci.setLocation(getInt(DSettings.get("icon19x", "" + this.paci.getX())), getInt(DSettings.get("icon19y", "" + this.paci.getY())));
    this.flopyi.setLocation(getInt(DSettings.get("icon20x", "" + this.flopyi.getX())), getInt(DSettings.get("icon20y", "" + this.flopyi.getY())));
    this.pokei.setLocation(getInt(DSettings.get("icon21x", "" + this.pokei.getX())), getInt(DSettings.get("icon21y", "" + this.pokei.getY())));
    this.webi.setLocation(getInt(DSettings.get("icon22x", "" + this.webi.getX())), getInt(DSettings.get("icon22y", "" + this.webi.getY())));
    this.radioi.setLocation(getInt(DSettings.get("icon23x", "" + this.radioi.getX())), getInt(DSettings.get("icon23y", "" + this.radioi.getY())));
    this.chati.setLocation(getInt(DSettings.get("icon24x", "" + this.chati.getX())), getInt(DSettings.get("icon24y", "" + this.chati.getY())));
    this.favi.setLocation(getInt(DSettings.get("icon25x", "" + this.favi.getX())), getInt(DSettings.get("icon25y", "" + this.favi.getY())));
    this.dski.setLocation(getInt(DSettings.get("icon26x", "" + this.dski.getX())), getInt(DSettings.get("icon26y", "" + this.dski.getY())));
    this.atarii.setLocation(getInt(DSettings.get("icon27x", "" + this.atarii.getX())), getInt(DSettings.get("icon27y", "" + this.atarii.getY())));
    this.gx4000i.setLocation(getInt(DSettings.get("icon28x", "" + this.gx4000i.getX())), getInt(DSettings.get("icon28y", "" + this.gx4000i.getY())));
    this.deathi.setLocation(getInt(DSettings.get("icon29x", "" + this.deathi.getX())), getInt(DSettings.get("icon29y", "" + this.deathi.getY())));
    this.bddi.setLocation(getInt(DSettings.get("icon30x", "" + this.bddi.getX())), getInt(DSettings.get("icon30y", "" + this.bddi.getY())));
    this.cdi.setLocation(getInt(DSettings.get("icon31x", "" + this.cdi.getX())), getInt(DSettings.get("icon31y", "" + this.cdi.getY())));
    this.rolandi.setLocation(getInt(DSettings.get("icon32x", "" + this.rolandi.getX())), getInt(DSettings.get("icon32y", "" + this.rolandi.getY())));
    this.rasteri.setLocation(getInt(DSettings.get("icon33x", "" + this.rasteri.getX())), getInt(DSettings.get("icon33y", "" + this.rasteri.getY())));
    this.desktop.addMouseMotionListener(this);
    this.capi.addMouseMotionListener(this);
    this.ymi.addMouseMotionListener(this);
    this.hexi.addMouseMotionListener(this);
    this.clocki.addMouseMotionListener(this);
    this.infoi.addMouseMotionListener(this);
    this.consoli.addMouseMotionListener(this);
    this.minii.addMouseMotionListener(this);
    this.browsi.addMouseMotionListener(this);
    this.configi.addMouseMotionListener(this);
    this.debugi.addMouseMotionListener(this);
    this.tapei.addMouseMotionListener(this);
    this.painti.addMouseMotionListener(this);
    this.inii.addMouseMotionListener(this);
    this.newii.addMouseMotionListener(this);
    this.oldii.addMouseMotionListener(this);
    this.tiledi.addMouseMotionListener(this);
    this.assembli.addMouseMotionListener(this);
    this.calci.addMouseMotionListener(this);
    this.paci.addMouseMotionListener(this);
    this.flopyi.addMouseMotionListener(this);
    this.pokei.addMouseMotionListener(this);
    this.webi.addMouseMotionListener(this);
    this.radioi.addMouseMotionListener(this);
    this.chati.addMouseMotionListener(this);
    this.favi.addMouseMotionListener(this);
    this.dski.addMouseMotionListener(this);
    this.atarii.addMouseMotionListener(this);
    this.gx4000i.addMouseMotionListener(this);
    this.deathi.addMouseMotionListener(this);
    this.bddi.addMouseMotionListener(this);
    this.cdi.addMouseMotionListener(this);
    this.rolandi.addMouseMotionListener(this);
    this.rasteri.addMouseMotionListener(this);
    this.clock.setVisible(false);
    cap = new AudioCapture();
    cap.setSize(420, 190);
    this.desktop.add((Component)cap);
    cap.setResizable(false);
    cap.setClosable(true);
    cap.setIconifiable(true);
    cap.setDefaultCloseOperation(1);
    cap.showCapture();
    cap.setVisible(false);
    if (this.console != null);
    open(_DESKTOP);
    setAlwaysOnTop(false);
    this.autosave.setSelected(Settings.getBoolean("autosave", true));
    this.asksave.setSelected(Settings.getBoolean("checksave", false));
    Switches.checksave = this.asksave.isSelected();
    Switches.autosave = this.autosave.isSelected();
    Switches.watch = Settings.getBoolean("observe_performance", false);
    this.jCheckBox7.setSelected(Switches.watch);
    Switches.floppyturbo = Settings.getBoolean("floppyturbo", false);
    this.jCheckBox9.setSelected(Switches.floppyturbo);
    Switches.mask = Settings.getBoolean("mask", false);
    this.mask2.setSelected(Switches.mask);
    this.mask1.setSelected(!Switches.mask);
    this.desktop.add((Component)(this.hex = new HexEditor()));
    this.hex.setTitle("HexEditor");
    this.hex.setSize(500, 340);
    this.hex.setLocation(4, 4);
    this.hex.setDefaultCloseOperation(1);
    this.hex.setIconifiable(true);
    this.hex.setResizable(true);
    this.hex.setMaximizable(true);
    this.hex.setClosable(true);
    this.hex.setVisible(false);
    setAlarmPanel();
    checkAlarm();
    checkSet();
    info(0);
    this.ymplayer = new YMControl();
    this.desktop.add((Component)this.ymplayer);
    this.ymplayer.setVisible(false);
    this.ymplayer.setDefaultCloseOperation(1);
    this.ymplayer.setLocation(300, 10);
    this.ymplayer.setIconifiable(true);
    this.ymplayer.setClosable(true);
    boolean showwelcome = Settings.getBoolean("welcome", true);
    if (!showwelcome) {
      this.Welcome.setVisible(false);
      this.ymplayer.toFront();
      this.sinfo.setSelected(false);
    } else {
      this.Welcome.setVisible(true);
      this.sinfo.setSelected(true);
      try {
        this.Welcome.setIcon(false);
        this.Welcome.toFront();
        this.Welcome.setSelected(true);
      } catch (Exception exception) {}
    } 
    Switches.amdrum = Settings.getBoolean("amdrum", false);
    this.amdrum.setSelected(Switches.amdrum);
    Switches.digiblaster = Settings.getBoolean("digiblaster", false);
    Switches.Printer = Settings.getBoolean("printer", false);
    if (Switches.Printer)
      this.printer.setSelected(true); 
    if (Switches.digiblaster)
      this.digiblaster.setSelected(true); 
    Switches.Expansion = Settings.getBoolean("expansion", false);
    this.jCheckBox5.setSelected(Switches.Expansion);
    this.up6.setEnabled(!Switches.Expansion);
    this.selU7.setEnabled(!Switches.Expansion);
    this.jCheckBox3.setSelected(Settings.getBoolean("override_p", false));
    Switches.overrideP = this.jCheckBox3.isSelected();
    String memo = Settings.get("memory", "TYPE_512K");
    if (memo.equals("TYPE_64K"))
      this.mem0.setSelected(true); 
    if (memo.equals("TYPE_128K"))
      this.mem1.setSelected(true); 
    if (memo.equals("TYPE_SILICON_DISC"))
      this.mem2.setSelected(true); 
    if (memo.equals("TYPE_256K"))
      this.mem3.setSelected(true); 
    if (memo.equals("TYPE_512K")) {
      boolean has4mb = Settings.getBoolean("memory_4mb", false);
      if (has4mb) {
        this.mem5.setSelected(true);
      } else {
        this.mem4.setSelected(true);
      } 
    } 
    memo = Settings.get("computername", "7");
    if (memo.equals("0"))
      this.jRadioButton7.setSelected(true); 
    if (memo.equals("1"))
      this.jRadioButton8.setSelected(true); 
    if (memo.equals("2"))
      this.jRadioButton9.setSelected(true); 
    if (memo.equals("3"))
      this.jRadioButton10.setSelected(true); 
    if (memo.equals("4"))
      this.jRadioButton11.setSelected(true); 
    if (memo.equals("5"))
      this.jRadioButton12.setSelected(true); 
    if (memo.equals("6"))
      this.jRadioButton13.setSelected(true); 
    if (memo.equals("7"))
      this.jRadioButton14.setSelected(true); 
    this.helper.coname = Integer.parseInt(memo);
    this.helper.look = Integer.parseInt(DSettings.get("look", "20"));
    for (int j = 0; j < this.helper.looks.length; j++)
      this.lookSelector.addItem(this.helper.looks[j]); 
    if (!this.helper.synthetica)
      for (int t = 38; t > 21; t--)
        this.lookSelector.removeItemAt(t);  
    try {
      this.lookSelector.setSelectedIndex(this.helper.look);
      System.out.println("Selector set to " + this.helper.looks[this.helper.look]);
    } catch (Exception e) {
      e.printStackTrace();
      this.lookSelector.setSelectedIndex(0);
      DSettings.set("look", "0");
    } 
    this.cchooser.setVisible(false);
    this.lookSelector.addActionListener(this);
    DesktopHelper.blast = new JProgressBar();
    DesktopHelper.audio = new JProgressBar();
    volumes = new double[16];
    try {
      DesktopHelper.blast.setOrientation(1);
      DesktopHelper.blast.setMaximum(100);
      DesktopHelper.blast.setMinimum(0);
      DesktopHelper.blast.setMaximumSize(new Dimension(10, 100));
      DesktopHelper.audio.setOrientation(1);
      DesktopHelper.audio.setMaximum(100);
      DesktopHelper.audio.setMinimum(0);
      DesktopHelper.audio.setMaximumSize(new Dimension(10, 100));
      this.Avol.add(this.volumeslider, "Center");
      this.Avol.add(DesktopHelper.audio, "East");
      this.Dvol.add(this.digiblastervolumeslider, "Center");
      this.Dvol.add(DesktopHelper.blast, "East");
      Switches.KAYOut = Settings.getBoolean("hacker_kay_output", true);
      if (Switches.KAYOut)
        this.jAY1.setSelected(Switches.KAYOut); 
      Switches.VSoftOutput = Settings.getBoolean("vsoft_output", false);
      if (Switches.VSoftOutput)
        this.jAY2.setSelected(Switches.VSoftOutput); 
      Switches.CPCE95 = Settings.getBoolean("cpce95_output", false);
      if (Switches.CPCE95)
        this.jAY3.setSelected(Switches.CPCE95); 
      Switches.HACKER = Settings.getBoolean("hacker_kay_II_output", false);
      if (Switches.HACKER)
        this.jAY6.setSelected(Switches.HACKER); 
      Switches.LION = Settings.getBoolean("lion_output", false);
      if (Switches.LION)
        this.jAY5.setSelected(Switches.LION); 
      Switches.ayeffect = Settings.getBoolean("ay_effect", false);
      this.jAYE.setSelected(Switches.ayeffect);
      Switches.dbeffect = Settings.getBoolean("db_effect", false);
      this.jAYE1.setSelected(Switches.dbeffect);
      Switches.linear = Settings.getBoolean("linear_sound", false);
      if (Switches.linear)
        this.jAY4.setSelected(Switches.linear); 
      this.jSlider2.setValue(Util.hexValue(Settings.get("vertical_hold", "23")));
    } catch (Exception e) {
      e.printStackTrace();
    } 
    setVols();
    this.playcity.setSelected(Settings.getBoolean("playcity", false));
    Switches.Blastervolume = Integer.parseInt(Settings.get("digiblaster_volume", "9")) * 10;
    this.digiblastervolumeslider.setValue(Integer.parseInt(Settings.get("digiblaster_volume", "9")) / 9.0F);
    this.digiblastervolumeslider.setPreferredSize(new Dimension(110, 110));
    this.digiblastervolumeslider.setBackground(Color.DARK_GRAY);
    this.digiblastervolumeslider.setForeground(new Color(255, 255, 255));
    this.digiblastervolumeslider.setBorder(new EtchedBorder());
    this.digiblastervolumeslider.setDoubleBuffered(false);
    if (Switches.audioenabler == 1) {
      DesktopHelper.blast.setValue((int)(this.digiblastervolumeslider.getValue() * 100.0F));
    } else {
      DesktopHelper.blast.setValue(4);
    } 
    this.digiblastervolumeslider.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent e) {
            int dbvolume = (int)(Desktop.this.digiblastervolumeslider.getValue() * 9.0F);
            Switches.Blastervolume = dbvolume * 10;
            if (Switches.audioenabler == 1) {
              DesktopHelper.blast.setValue((int)(Desktop.this.digiblastervolumeslider.getValue() * 100.0F));
            } else {
              DesktopHelper.blast.setValue(4);
            } 
            Settings.set("digiblaster_volume", "" + dbvolume);
          }
        });
    Switches.volume = Integer.parseInt(Settings.get("volume", "1000")) / 1000.0D;
    this.volumeslider.setValue((float)Switches.volume);
    this.volumeslider.setPreferredSize(new Dimension(110, 110));
    this.volumeslider.setBackground(Color.DARK_GRAY);
    this.volumeslider.setForeground(new Color(255, 255, 255));
    this.volumeslider.setBorder(new EtchedBorder());
    this.volumeslider.setDoubleBuffered(false);
    if (Switches.audioenabler == 1) {
      DesktopHelper.audio.setValue((int)(this.volumeslider.getValue() * 100.0F));
    } else {
      DesktopHelper.audio.setValue(4);
    } 
    this.volumeslider.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent e) {
            Switches.volume = Desktop.this.volumeslider.getValue();
            if (Switches.audioenabler == 1) {
              DesktopHelper.audio.setValue((int)(Desktop.this.volumeslider.getValue() * 100.0F));
            } else {
              DesktopHelper.audio.setValue(4);
            } 
            Settings.set("volume", "" + (int)(Switches.volume * 1000.0D));
          }
        });
    Switches.ayeffect = Settings.getBoolean("ay_effect", false);
    this.jAYE.setSelected(Switches.ayeffect);
    Basic6845.CRTC = Integer.parseInt(Settings.get("crtc", "1"));
    if (CPC.crtctype != null)
      Basic6845.CRTC = Integer.parseInt(CPC.crtctype); 
    if (Basic6845.CRTC == 1) {
      this.crtc1.setSelected(true);
    } else {
      this.crtc0.setSelected(true);
    } 
    this.mute.setSelected(!Settings.getBoolean("audio", true));
    if (this.mute.isSelected()) {
      Switches.audioenabler = 0;
    } else {
      Switches.audioenabler = 1;
    } 
    if (Switches.audioenabler == 1) {
      DesktopHelper.audio.setValue((int)(this.volumeslider.getValue() * 100.0F));
      DesktopHelper.blast.setValue((int)(this.digiblastervolumeslider.getValue() * 100.0F));
    } else {
      DesktopHelper.audio.setValue(4);
      DesktopHelper.blast.setValue(4);
    } 
    Switches.FloppySound = Settings.getBoolean("floppy_sound", true);
    this.drivenoises.setSelected(Switches.FloppySound);
    Switches.KeyboardSound = Settings.getBoolean("key_sound", false);
    this.keynoise.setSelected(Switches.KeyboardSound);
    this.jSlider1.setValue(Integer.parseInt(Settings.get("brightness", "0")));
    Display.setFade(this.jSlider1.getValue() ^ 0xFFFFFFFF);
    String Monitor = Settings.get("monitor", "COLOR");
    if (Main.monitor != null)
      Monitor = Main.monitor.toUpperCase(); 
    if (Monitor != null) {
      if (Monitor.equals("COLOR"))
        Switches.monitormode = 1; 
      if (Monitor.equals("COLOUR"))
        Switches.monitormode = 1; 
      if (Monitor.equals("CPCE"))
        Switches.monitormode = 5; 
      if (Monitor.equals("GRIM"))
        Switches.monitormode = 6; 
      if (Monitor.equals("LINEAR"))
        Switches.monitormode = 0; 
      if (Monitor.equals("GREEN"))
        Switches.monitormode = 2; 
      if (Monitor.equals("GRAY"))
        Switches.monitormode = 3; 
      if (Monitor.equals("GREY"))
        Switches.monitormode = 3; 
      if (Monitor.equals("MONO"))
        Switches.monitormode = 4; 
      if (Monitor.equals("GRIM"))
        Switches.monitormode = 7; 
      if (Monitor.equals("C64"))
        Switches.monitormode = 8; 
    } 
    int mon = Switches.monitormode;
    if (mon == 6) {
      this.jMon7.setSelected(true);
      this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon7.gif")));
    } 
    if (mon == 5) {
      this.jMon3.setSelected(true);
      this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon3.gif")));
    } 
    if (mon == 1) {
      this.jMon1.setSelected(true);
      this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon1.gif")));
    } 
    if (mon == 0) {
      this.jMon2.setSelected(true);
      this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon2.gif")));
    } 
    if (mon == 2) {
      this.jMon4.setSelected(true);
      this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon4.gif")));
    } 
    if (mon == 3) {
      this.jMon5.setSelected(true);
      this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon5.gif")));
    } 
    if (mon == 4) {
      this.jMon6.setSelected(true);
      this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon6.gif")));
    } 
    if (mon == 8) {
      this.jMon8.setSelected(true);
      this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon6.gif")));
    } 
    this.filter.setSelected(Settings.getBoolean("bilinear", false));
    Switches.bilinear = this.filter.isSelected();
    this.scanl.setSelected(Settings.getBoolean("scanlines", false));
    Switches.ScanLines = this.scanl.isSelected();
    this.mmask.setSelected(Settings.getBoolean("display_effect", false));
    Display.scaneffect = this.mmask.isSelected();
    if (Settings.getBoolean("filter_dosbox", false)) {
      Display.filter_dosbox = true;
      Display.filter_dosboxb = false;
      Display.filter_eagle = false;
      Display.filter_advmame = false;
      Display.filter_eagle_smooth = false;
      Display.filter_advmame_smooth = false;
      Display.filter_embossed = false;
      this.filterChooser.setSelectedIndex(1);
    } else if (Settings.getBoolean("filter_dosboxb", false)) {
      Display.filter_dosbox = false;
      Display.filter_dosboxb = true;
      Display.filter_eagle = false;
      Display.filter_advmame = false;
      Display.filter_eagle_smooth = false;
      Display.filter_advmame_smooth = false;
      Display.filter_embossed = false;
      this.filterChooser.setSelectedIndex(2);
    } else if (Settings.getBoolean("filter_advmame", false)) {
      Display.filter_dosbox = false;
      Display.filter_dosboxb = false;
      Display.filter_eagle = false;
      Display.filter_advmame = true;
      Display.filter_eagle_smooth = false;
      Display.filter_advmame_smooth = false;
      Display.filter_embossed = false;
      this.filterChooser.setSelectedIndex(3);
    } else if (Settings.getBoolean("filter_eagle", false)) {
      Display.filter_dosbox = false;
      Display.filter_dosboxb = false;
      Display.filter_eagle = true;
      Display.filter_advmame = false;
      Display.filter_eagle_smooth = false;
      Display.filter_advmame_smooth = false;
      Display.filter_embossed = false;
      this.filterChooser.setSelectedIndex(4);
    } else if (Settings.getBoolean("filter_advmame_smooth", false)) {
      Display.filter_dosbox = false;
      Display.filter_dosboxb = false;
      Display.filter_eagle = false;
      Display.filter_advmame = false;
      Display.filter_eagle_smooth = false;
      Display.filter_advmame_smooth = true;
      Display.filter_embossed = false;
      this.filterChooser.setSelectedIndex(5);
    } else if (Settings.getBoolean("filter_eagle_smooth", false)) {
      Display.filter_dosbox = false;
      Display.filter_dosboxb = false;
      Display.filter_eagle = false;
      Display.filter_advmame = false;
      Display.filter_eagle_smooth = true;
      Display.filter_advmame_smooth = false;
      Display.filter_embossed = false;
      this.filterChooser.setSelectedIndex(6);
    } else if (Settings.getBoolean("filter_embossed", false)) {
      Display.filter_dosbox = false;
      Display.filter_dosboxb = false;
      Display.filter_eagle = false;
      Display.filter_advmame = false;
      Display.filter_eagle_smooth = false;
      Display.filter_advmame_smooth = false;
      Display.filter_embossed = true;
      this.filterChooser.setSelectedIndex(7);
    } 
    this.filterChooser.setEnabled(true);
    buildRoms();
    this.filterChooser.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent evt) {
            Desktop.this.jComboBox1ItemStateChanged(evt);
          }
        });
    checkPerformance(false);
    setDriveHeads();
    this.chooser = new JFileChooser();
    addMore();
    this.fdcenabled.setSelected(Settings.getBoolean("fdc_enabled", true));
  }
  
  public void addChat() {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            try {
              if (Desktop.web == null) {
                Desktop.web = new Browser();
                Desktop.webbrowser.setLayout(new GridLayout(1, 1));
                Desktop.webbrowser.add(Desktop.web);
              } 
              Desktop.this.openchat = 1;
              Desktop.web.setURL(Desktop.siteurl);
              Desktop.webbrowser.setVisible(false);
            } catch (Exception e) {
              JEMU.openWebPage(Desktop.siteurl);
            } 
          }
        });
  }
  
  void openChat() {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            if (Desktop.this.chat == null) {
              Desktop.this.chat = new Runner();
              Desktop.this.chat.init();
              Desktop.this.chatframe = Desktop.this.chat.getChat();
              Desktop.this.chatframe.setClosable(true);
              Desktop.this.chatframe.setDefaultCloseOperation(1);
              Desktop.this.desktop.add(Desktop.this.chatframe);
            } 
            Desktop.this.chattimer = 0;
            Desktop.this.chat.updateChat();
            Desktop.this.chatframe.setVisible(true);
            Desktop.this.chatframe.toFront();
          }
        });
  }
  
  public void downloadWallpaper() {
    if (this.wallpaperbox == null)
      this.wallpaperbox = new WallpaperBox(); 
    this.wallpaperbox.setAlwaysOnTop(true);
    this.wallpaperbox.setVisible(true);
  }
  
  protected void setupReg() {
    try {
      Main.setupReg();
    } catch (Exception exception) {}
  }
  
  public void launchPacMan() {
    if (this.pacframe == null) {
      this.pacframe = new JInternalFrame("PacMan");
      this.pacframe.setResizable(false);
      Main pac = new Main();
      pac.setPreferredSize(new Dimension(784, 568));
      pac.init();
      this.pacframe.add((Component)pac, "Center");
      this.desktop.add(this.pacframe);
      this.pacframe.setResizable(false);
      this.pacframe.setDefaultCloseOperation(1);
      this.pacframe.setClosable(true);
      this.pacframe.setIconifiable(true);
      this.pacframe.pack();
    } 
    this.pacframe.setVisible(true);
    this.pacframe.toFront();
  }
  
  public void checkDisabled() {
    boolean disable = Settings.getBoolean("disable_roms", false);
    System.out.println("ROMs are disabled: " + disable);
    Switches.disableroms = disable;
    this.jCheckBox1.setSelected(disable);
    if (disable) {
      this.up1.setEnabled(false);
      this.up2.setEnabled(false);
      this.up3.setEnabled(false);
      this.up4.setEnabled(false);
      this.up5.setEnabled(false);
      this.up6.setEnabled(false);
      this.up8.setEnabled(false);
      this.up9.setEnabled(false);
      this.up10.setEnabled(false);
      this.up11.setEnabled(false);
      this.up12.setEnabled(false);
      this.up13.setEnabled(false);
      this.up14.setEnabled(false);
      this.up15.setEnabled(false);
    } else {
      this.up1.setEnabled(true);
      this.up2.setEnabled(true);
      this.up3.setEnabled(true);
      this.up4.setEnabled(true);
      this.up5.setEnabled(true);
      this.up6.setEnabled(true);
      this.up8.setEnabled(true);
      this.up9.setEnabled(true);
      this.up10.setEnabled(true);
      this.up11.setEnabled(true);
      this.up12.setEnabled(true);
      this.up13.setEnabled(true);
      this.up14.setEnabled(true);
      this.up15.setEnabled(true);
    } 
  }
  
  public void checkAssembler() {
    if (this.Assembler == null) {
      this.Assembler = new Interface();
      this.desktop.add((Component)this.Assembler);
    } 
    this.Assembler.pack();
    this.Assembler.setVisible(true);
    try {
      this.Assembler.setSelected(true);
    } catch (Exception exception) {}
  }
  
  public void setPlus() {
    try {
      NimRODTheme nt = new NimRODTheme();
      Color flow1 = new Color(4915205);
      Color flow3 = new Color(15397362);
      Color black = new Color(0);
      Color white = new Color(16777215);
      Color sec1 = new Color(10747936);
      Color sec2 = new Color(9647933);
      Color sec3 = new Color(16184554);
      Color select = new Color(10747936);
      nt.setPrimary(white);
      nt.setSecondary(white);
      nt.setPrimary1(flow1);
      nt.setPrimary3(flow3);
      nt.setPrimary2(select);
      nt.setSecondary1(sec1);
      nt.setSecondary2(sec2);
      nt.setSecondary3(sec3);
      nt.setBlack(black);
      nt.setWhite(white);
      nt.setMenuOpacity(195);
      nt.setFrameOpacity(120);
      NimRODLookAndFeel NimRODLF = new NimRODLookAndFeel();
      NimRODLookAndFeel.setCurrentTheme((MetalTheme)nt);
      UIManager.setLookAndFeel((LookAndFeel)NimRODLF);
    } catch (Exception exception) {}
  }
  
  public void setLook(int look) {
    this.choosenlook = look;
    if (slic != null)
      slic.setVisible(false); 
    try {
      if (this.helper.synthetica) {
        if (slic != null && this.choosenlook > 21 && this.choosenlook < 39)
          slic.setVisible(true); 
        if (look > 21 && look < 39) {
          (new SyntheticaLicense()).register();
          UIManager.setLookAndFeel(this.helper.syntheticaStyles[look - 22]);
        } 
      } 
      if (look == 0)
        UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel"); 
      if (look == 1)
        UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel"); 
      if (look == 2)
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); 
      if (look == 3)
        UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel"); 
      if (look == 4) {
        this.nt = new NimRODTheme();
        this.flow1 = new Color(5526720);
        this.flow2 = new Color(13158634);
        this.selected = new Color(6184650);
        this.white = new Color(4802644);
        this.black = new Color(16777215);
        this.sec1 = new Color(1646119);
        this.sec2 = new Color(2304049);
        this.sec3 = new Color(2961979);
        this.nt.setPrimary1(this.flow1);
        this.nt.setPrimary3(this.flow2);
        this.nt.setPrimary2(this.selected);
        this.nt.setSecondary1(this.sec1);
        this.nt.setSecondary2(this.sec2);
        this.nt.setSecondary3(this.sec3);
        this.nt.setBlack(this.black);
        this.nt.setWhite(this.white);
        this.nt.setMenuOpacity(195);
        this.nt.setFrameOpacity(120);
        NimRODLookAndFeel NimRODLF = new NimRODLookAndFeel();
        NimRODLookAndFeel.setCurrentTheme((MetalTheme)this.nt);
        UIManager.setLookAndFeel((LookAndFeel)NimRODLF);
      } 
      if (look == this.helper.looks.length - 1) {
        this.nt = new NimRODTheme();
        this.flow1 = new Color(5526720);
        this.flow2 = new Color(13158634);
        this.selected = new Color(6184650);
        this.white = new Color(4802644);
        this.black = new Color(16777215);
        this.sec1 = new Color(1646119);
        this.sec2 = new Color(2304049);
        this.sec3 = new Color(2961979);
        String g1 = DSettings.get("themecolor" + Integer.toString(0), "nocolor");
        if (!g1.equals("nocolor"))
          this.flow1 = new Color(Integer.parseInt(g1)); 
        String g2 = DSettings.get("themecolor" + Integer.toString(1), "nocolor");
        if (!g2.equals("nocolor"))
          this.flow2 = new Color(Integer.parseInt(g2)); 
        String g3 = DSettings.get("themecolor" + Integer.toString(2), "nocolor");
        if (!g3.equals("nocolor"))
          this.selected = new Color(Integer.parseInt(g3)); 
        String g4 = DSettings.get("themecolor" + Integer.toString(3), "nocolor");
        if (!g4.equals("nocolor"))
          this.white = new Color(Integer.parseInt(g4)); 
        String g5 = DSettings.get("themecolor" + Integer.toString(4), "nocolor");
        if (!g5.equals("nocolor"))
          this.black = new Color(Integer.parseInt(g5)); 
        String g6 = DSettings.get("themecolor" + Integer.toString(5), "nocolor");
        if (!g6.equals("nocolor"))
          this.sec1 = new Color(Integer.parseInt(g6)); 
        String g7 = DSettings.get("themecolor" + Integer.toString(6), "nocolor");
        if (!g7.equals("nocolor"))
          this.sec2 = new Color(Integer.parseInt(g7)); 
        String g8 = DSettings.get("themecolor" + Integer.toString(7), "nocolor");
        if (!g8.equals("nocolor"))
          this.sec3 = new Color(Integer.parseInt(g8)); 
        this.nt.setPrimary1(this.flow1);
        this.nt.setPrimary3(this.flow2);
        this.nt.setPrimary2(this.selected);
        this.nt.setSecondary1(this.sec1);
        this.nt.setSecondary2(this.sec2);
        this.nt.setSecondary3(this.sec3);
        this.nt.setBlack(this.black);
        this.nt.setWhite(this.white);
        this.nt.setMenuOpacity(195);
        this.nt.setFrameOpacity(120);
        NimRODLookAndFeel NimRODLF = new NimRODLookAndFeel();
        NimRODLookAndFeel.setCurrentTheme((MetalTheme)this.nt);
        UIManager.setLookAndFeel((LookAndFeel)NimRODLF);
      } 
      if (look == 5) {
        this.nt = new NimRODTheme();
        this.nt.setPrimary1(new Color(2043450));
        this.nt.setPrimary2(new Color(2701380));
        this.nt.setPrimary3(new Color(3359310));
        this.nt.setSecondary1(new Color(3881787));
        this.nt.setSecondary2(new Color(4539717));
        this.nt.setSecondary3(new Color(5197647));
        this.nt.setWhite(new Color(7434609));
        this.nt.setBlack(new Color(16777215));
        this.nt.setFrameOpacity(180);
        this.nt.setMenuOpacity(0);
        NimRODLookAndFeel NimRODLF = new NimRODLookAndFeel();
        NimRODLookAndFeel.setCurrentTheme((MetalTheme)this.nt);
        UIManager.setLookAndFeel((LookAndFeel)NimRODLF);
        UIManager.setLookAndFeel((LookAndFeel)NimRODLF);
      } 
      if (look == 6) {
        this.nt = new NimRODTheme();
        this.nt.setPrimary1(new Color(34283));
        this.nt.setPrimary2(new Color(36853));
        this.nt.setPrimary3(new Color(39423));
        this.nt.setSecondary1(new Color(14474460));
        this.nt.setSecondary2(new Color(15132390));
        this.nt.setSecondary3(new Color(15790320));
        this.nt.setWhite(new Color(16448250));
        this.nt.setBlack(new Color(0));
        this.nt.setMenuOpacity(195);
        this.nt.setFrameOpacity(180);
        NimRODLookAndFeel NimRODLF = new NimRODLookAndFeel();
        NimRODLookAndFeel.setCurrentTheme((MetalTheme)this.nt);
        UIManager.setLookAndFeel((LookAndFeel)NimRODLF);
        UIManager.setLookAndFeel((LookAndFeel)NimRODLF);
      } 
      if (look == 7)
        setPlus(); 
      if (look == 8) {
        this.nt = new NimRODTheme();
        this.nt.setPrimary1(new Color(10770944));
        this.nt.setPrimary2(new Color(11428864));
        this.nt.setPrimary3(new Color(12086784));
        this.nt.setSecondary1(new Color(5918246));
        this.nt.setSecondary2(new Color(6576176));
        this.nt.setSecondary3(new Color(7234106));
        this.nt.setWhite(new Color(5196844));
        this.nt.setBlack(new Color(15327696));
        this.nt.setMenuOpacity(120);
        this.nt.setFrameOpacity(180);
        NimRODLookAndFeel NimRODLF = new NimRODLookAndFeel();
        NimRODLookAndFeel.setCurrentTheme((MetalTheme)this.nt);
        UIManager.setLookAndFeel((LookAndFeel)NimRODLF);
        UIManager.setLookAndFeel((LookAndFeel)NimRODLF);
      } 
      if (look == 9)
        UIManager.setLookAndFeel("com.incors.plaf.kunststoff.KunststoffLookAndFeel"); 
      if (look == 10)
        UIManager.setLookAndFeel("com.pagosoft.plaf.PgsLookAndFeel"); 
      if (look == 11)
        UIManager.setLookAndFeel("com.jtattoo.plaf.acryl.AcrylLookAndFeel"); 
      if (look == 12)
        UIManager.setLookAndFeel("com.jtattoo.plaf.aero.AeroLookAndFeel"); 
      if (look == 13)
        UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel"); 
      if (look == 14)
        UIManager.setLookAndFeel("com.jtattoo.plaf.bernstein.BernsteinLookAndFeel"); 
      if (look == 15)
        UIManager.setLookAndFeel("com.jtattoo.plaf.fast.FastLookAndFeel"); 
      if (look == 16)
        UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel"); 
      if (look == 17)
        UIManager.setLookAndFeel("com.jtattoo.plaf.luna.LunaLookAndFeel"); 
      if (look == 18)
        UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel"); 
      if (look == 19)
        UIManager.setLookAndFeel("com.jtattoo.plaf.mint.MintLookAndFeel"); 
      if (look == 20)
        UIManager.setLookAndFeel("com.jtattoo.plaf.noire.NoireLookAndFeel"); 
      if (look == 21)
        UIManager.setLookAndFeel("com.jtattoo.plaf.texture.TextureLookAndFeel"); 
      if (cap != null)
        SwingUtilities.updateComponentTreeUI((Component)cap); 
      if (this.ymplayer != null)
        SwingUtilities.updateComponentTreeUI((Component)this.ymplayer); 
      if (this.hex != null)
        SwingUtilities.updateComponentTreeUI((Component)this.hex); 
      if (this.console != null)
        SwingUtilities.updateComponentTreeUI(this.console); 
      SwingUtilities.updateComponentTreeUI(this);
      if (JEMU.iframe != null && JEMU.iframe.isVisible())
        JEMU.checksize = 1; 
      if (this.resbutton != null) {
        this.resbutton.setBorder((Border)null);
        this.quitbutton.setBorder((Border)null);
        this.syncbutton.setBorder((Border)null);
        this.recb.setBorder((Border)null);
        this.playb.setBorder((Border)null);
        this.rewb.setBorder((Border)null);
        this.ffwb.setBorder((Border)null);
        this.stopb.setBorder((Border)null);
        this.pauseb.setBorder((Border)null);
      } 
    } catch (Exception exception) {}
  }
  
  public void setLook(String look) {
    setLook(Integer.parseInt(look));
  }
  
  public void updateLook() {
    int c = this.colo.getSelectedIndex();
    switch (c) {
      case 0:
        this.flow1 = this.colchoos.getColor();
        break;
      case 1:
        this.flow2 = this.colchoos.getColor();
        break;
      case 2:
        this.selected = this.colchoos.getColor();
        break;
      case 3:
        this.black = this.colchoos.getColor();
        break;
      case 4:
        this.white = this.colchoos.getColor();
        break;
      case 5:
        this.sec1 = this.colchoos.getColor();
        break;
      case 6:
        this.sec2 = this.colchoos.getColor();
        break;
      case 7:
        this.sec3 = this.colchoos.getColor();
        break;
    } 
    DSettings.set("themecolor" + Integer.toString(c), "" + this.colchoos.getColor().getRGB());
    this.nt.setPrimary1(this.flow1);
    this.nt.setPrimary3(this.flow2);
    this.nt.setPrimary2(this.selected);
    this.nt.setSecondary1(this.sec1);
    this.nt.setSecondary2(this.sec2);
    this.nt.setSecondary3(this.sec3);
    this.nt.setBlack(this.black);
    this.nt.setWhite(this.white);
    NimRODLookAndFeel NimRODLF = new NimRODLookAndFeel();
    NimRODLookAndFeel.setCurrentTheme((MetalTheme)this.nt);
    try {
      UIManager.setLookAndFeel((LookAndFeel)NimRODLF);
      SwingUtilities.updateComponentTreeUI(this);
    } catch (Exception exception) {}
    repaint();
  }
  
  private void initComponents() {
    this.jLabel70 = new JLabel();
    this.jLabel71 = new JLabel();
    this.jLabel20 = new JLabel();
    this.mongroup1 = new ButtonGroup();
    this.jAYGroup = new ButtonGroup();
    this.crtcg = new ButtonGroup();
    this.memGroup = new ButtonGroup();
    this.cname = new ButtonGroup();
    this.buttonGroup1 = new ButtonGroup();
    this.dskcontrol = new ButtonGroup();
    this.tapequality = new ButtonGroup();
    this.wallbehaviour = new ButtonGroup();
    this.speechgroup = new ButtonGroup();
    this.moniset = new ButtonGroup();
    this.df0head = new ButtonGroup();
    this.df1head = new ButtonGroup();
    this.df2head = new ButtonGroup();
    this.df3head = new ButtonGroup();
    this.periphery = new JPanel();
    this.jButton23 = new JButton();
    this.jButton22 = new JButton();
    this.jButton41 = new JButton();
    this.jButton42 = new JButton();
    this.jButton43 = new JButton();
    this.jScrollPane4 = new JScrollPane();
    this.jPanel57 = new JPanel();
    this.palpan = new JPanel();
    this.jPanel52 = new JPanel();
    this.jPanel53 = new JPanel();
    this.jLabel12 = new JLabel();
    this.modo = new JLabel();
    this.jPanel58 = new JPanel();
    sprite1 = new JLabel();
    sprite2 = new JLabel();
    sprite3 = new JLabel();
    sprite4 = new JLabel();
    sprite5 = new JLabel();
    sprite6 = new JLabel();
    sprite7 = new JLabel();
    sprite8 = new JLabel();
    sprite9 = new JLabel();
    sprite10 = new JLabel();
    sprite11 = new JLabel();
    sprite12 = new JLabel();
    sprite13 = new JLabel();
    sprite14 = new JLabel();
    sprite15 = new JLabel();
    sprite16 = new JLabel();
    mag1 = new JLabel();
    mag2 = new JLabel();
    this.jPanel55 = new JPanel();
    this.jTextField1 = new JTextField();
    this.jLabel28 = new JLabel();
    this.jLabel35 = new JLabel();
    this.jTextField2 = new JTextField();
    this.jTextField3 = new JTextField();
    this.jLabel36 = new JLabel();
    this.jLabel37 = new JLabel();
    this.jTextField4 = new JTextField();
    this.jTextField5 = new JTextField();
    this.jLabel38 = new JLabel();
    this.jTextField6 = new JTextField();
    this.jLabel39 = new JLabel();
    this.jLabel40 = new JLabel();
    this.jTextField7 = new JTextField();
    this.jTextField8 = new JTextField();
    this.jLabel41 = new JLabel();
    this.jTextField9 = new JTextField();
    this.jLabel42 = new JLabel();
    this.jTextField10 = new JTextField();
    this.jLabel43 = new JLabel();
    this.jLabel44 = new JLabel();
    this.jTextField11 = new JTextField();
    this.jTextField12 = new JTextField();
    this.jLabel45 = new JLabel();
    this.jLabel46 = new JLabel();
    this.jTextField13 = new JTextField();
    this.jTextField14 = new JTextField();
    this.jLabel47 = new JLabel();
    this.jLabel48 = new JLabel();
    this.jTextField15 = new JTextField();
    this.jTextField16 = new JTextField();
    this.jLabel49 = new JLabel();
    this.mprev = new JLabel();
    this.jButton44 = new JButton();
    this.jPanel54 = new JPanel();
    this.jTextField32 = new JTextField();
    this.jLabel65 = new JLabel();
    this.jTextField31 = new JTextField();
    this.jLabel64 = new JLabel();
    this.jTextField30 = new JTextField();
    this.jLabel63 = new JLabel();
    this.jTextField29 = new JTextField();
    this.jLabel62 = new JLabel();
    this.jTextField28 = new JTextField();
    this.jLabel61 = new JLabel();
    this.jTextField27 = new JTextField();
    this.jLabel60 = new JLabel();
    this.jTextField26 = new JTextField();
    this.jLabel59 = new JLabel();
    this.jTextField25 = new JTextField();
    this.jLabel58 = new JLabel();
    this.jTextField24 = new JTextField();
    this.jLabel57 = new JLabel();
    this.jLabel56 = new JLabel();
    this.jTextField23 = new JTextField();
    this.jTextField22 = new JTextField();
    this.jLabel55 = new JLabel();
    this.jTextField21 = new JTextField();
    this.jLabel54 = new JLabel();
    this.jTextField20 = new JTextField();
    this.jLabel53 = new JLabel();
    this.jLabel52 = new JLabel();
    this.jTextField19 = new JTextField();
    this.jTextField18 = new JTextField();
    this.jLabel51 = new JLabel();
    this.jTextField17 = new JTextField();
    this.jLabel50 = new JLabel();
    this.jPanel56 = new JPanel();
    this.jLabel15 = new JLabel();
    this.jLabel16 = new JLabel();
    this.jPanel37 = new JPanel();
    this.jLabel13 = new JLabel();
    cmd = new JTextField();
    fdcm = new JCheckBox();
    this.jLabel14 = new JLabel();
    statinf = new JTextField();
    statinf1 = new JTextField();
    this.buttonGroup2 = new ButtonGroup();
    this.pop = new JPopupMenu();
    this.jMenu1 = new JMenu();
    this.jMenuItem1 = new JMenuItem();
    this.jMenuItem3 = new JMenuItem();
    this.iconsAlign = new JCheckBoxMenuItem();
    this.jMenu2 = new JMenu();
    this.jMenuItem2 = new JMenuItem();
    this.buttonGroup3 = new ButtonGroup();
    this.desktop = new JDesktopPane() {
        public void paintComponent(Graphics g) {
          super.paintComponent(g);
          Graphics2D g2 = (Graphics2D)g;
          g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
          g = g2;
          if (Desktop.this.wallpaper != null)
            if (Desktop.this.stretch) {
              g.drawImage(Desktop.this.wallpaper, 0, 0, Desktop.this.desktop.getWidth(), Desktop.this.desktop.getHeight(), this);
            } else if (Desktop.this.tiled) {
              for (int x = 0; x < 4000; x += Desktop.this.wallpaper.getWidth(this)) {
                int y;
                for (y = 0; y < 3000; y += Desktop.this.wallpaper.getHeight(this)) {
                  if (x < Desktop.this.desktop.getWidth() && y < Desktop.this.desktop.getHeight())
                    g.drawImage(Desktop.this.wallpaper, x, y, this); 
                } 
              } 
            } else {
              int xpos = Desktop.this.desktop.getWidth() / 2 - Desktop.this.wallpaper.getWidth(this) / 2;
              int ypos = Desktop.this.desktop.getHeight() / 2 - Desktop.this.wallpaper.getHeight(this) / 2;
              g.drawImage(Desktop.this.wallpaper, xpos, ypos, Desktop.this.wallpaper.getWidth(this), Desktop.this.wallpaper.getHeight(this), this);
            }  
        }
      };
    this.starttab = new JInternalFrame() {
        protected void paintComponent(Graphics g) {
          g.setColor(getBackground());
          g.fillRect(0, 0, (getSize()).width, (getSize()).height);
        }
      };
    this.starttab.setOpaque(false);
    ((BasicInternalFrameUI)this.starttab.getUI()).setNorthPane(null);
    ((BasicInternalFrameUI)this.starttab.getUI()).setEastPane(null);
    ((BasicInternalFrameUI)this.starttab.getUI()).setSouthPane(null);
    ((BasicInternalFrameUI)this.starttab.getUI()).setWestPane(null);
    this.starttab.setBackground(new Color(128, 128, 180, 80));
    this.startlabel = new JLabel() {
        protected void paintComponent(Graphics g) {
          g.setColor(getBackground());
          g.fillRect(0, 0, (getSize()).width, (getSize()).height);
          g.drawImage(Desktop.this.labelstart, 0, 0, null);
        }
      };
    this.startlabel.setOpaque(false);
    this.startlabel.setBackground(new Color(20, 20, 22, 60));
    this.jLabel73 = new JLabel();
    this.jLabel80 = new JLabel();
    this.jLabel82 = new JLabel();
    this.jLabel83 = new JLabel();
    this.jLabel84 = new JLabel();
    this.jLabel87 = new JLabel();
    this.jLabel88 = new JLabel();
    this.jLabel89 = new JLabel();
    this.jLabel90 = new JLabel();
    this.jLabel91 = new JLabel();
    this.gamescdgui = new JInternalFrame();
    webbrowser = new JInternalFrame();
    printframe = new JInternalFrame();
    textprinter = new JPanel();
    this.jScrollPane3 = new JScrollPane();
    printout = new JTextArea();
    this.jPanel33 = new JPanel();
    this.jButton35 = new JButton();
    this.jButton36 = new JButton();
    this.jButton37 = new JButton();
    this.jButton38 = new JButton();
    floppy = new JInternalFrame();
    this.jPanel10 = new JPanel();
    head = new JLabel();
    fled3 = new Panel();
    fled2 = new Panel();
    fled1 = new Panel();
    fled0 = new Panel();
    this.jLabel86 = new JLabel();
    this.maped = new JInternalFrame();
    options = new JInternalFrame();
    OptionPane = new JTabbedPane();
    this.jPanel38 = new JPanel();
    this.jPanel39 = new JPanel();
    this.wallstretch = new JRadioButton();
    this.wallcenter = new JRadioButton();
    this.lookSelector = new JComboBox();
    this.jLabel22 = new JLabel();
    this.restartj = new JLabel();
    this.jButton31 = new JButton();
    this.jButton32 = new JButton();
    this.forced = new JButton();
    this.jButton40 = new JButton();
    slic = new JButton();
    this.walltile = new JRadioButton();
    this.wallpreview = new JDesktopPane() {
        public void paintComponent(Graphics g) {
          super.paintComponent(g);
          Graphics2D g2 = (Graphics2D)g;
          g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
          g = g2;
          if (Desktop.this.wallpaper != null)
            if (Desktop.this.stretch) {
              g.drawImage(Desktop.this.wallpaper, 0, 0, Desktop.this.wallpreview.getWidth(), Desktop.this.wallpreview.getHeight(), this);
            } else if (Desktop.this.tiled) {
              for (int x = 0; x < 4000; x += Desktop.this.wallpaper.getWidth(this) / 6) {
                int y;
                for (y = 0; y < 3000; y += Desktop.this.wallpaper.getHeight(this) / 6) {
                  if (x < Desktop.this.wallpreview.getWidth() && y < Desktop.this.wallpreview.getHeight())
                    g.drawImage(Desktop.this.wallpaper, x, y, Desktop.this.wallpaper.getWidth(this) / 6, Desktop.this.wallpaper.getHeight(this) / 6, this); 
                } 
              } 
            } else {
              int xpos = Desktop.this.wallpreview.getWidth() / 2 - Desktop.this.wallpaper.getWidth(this) / 12;
              int ypos = Desktop.this.wallpreview.getHeight() / 2 - Desktop.this.wallpaper.getHeight(this) / 12;
              g.drawImage(Desktop.this.wallpaper, xpos, ypos, Desktop.this.wallpaper.getWidth(this) / 6, Desktop.this.wallpaper.getHeight(this) / 6, this);
            }  
        }
      };
    this.jPanel40 = new JPanel();
    this.jButton21 = new JButton();
    this.useconsole = new JCheckBox();
    this.sinfo = new JCheckBox();
    this.jToggleButton3 = new JToggleButton();
    this.jLabel68 = new JLabel();
    this.deskcheck = new JCheckBox();
    this.jButton39 = new JButton();
    this.expand = new JCheckBox();
    this.jPanel2 = new JPanel();
    this.jTabbedPane1 = new JTabbedPane();
    this.jPanel61 = new JPanel();
    this.videopanel = new JPanel();
    this.jMon1 = new JRadioButton();
    this.jMon2 = new JRadioButton();
    this.jMon3 = new JRadioButton();
    this.jMon4 = new JRadioButton();
    this.jMon5 = new JRadioButton();
    this.jPanel6 = new JPanel();
    this.MonLabel = new JLabel();
    this.jMon7 = new JRadioButton();
    this.scanl = new JCheckBox();
    this.jRadioButton1 = new JRadioButton();
    this.jRadioButton2 = new JRadioButton();
    this.freq = new JCheckBox();
    this.jMon6 = new JRadioButton();
    this.jToggleButton4 = new JToggleButton();
    this.jLabel10 = new JLabel();
    this.crtc0 = new JRadioButton();
    this.crtc1 = new JRadioButton();
    hideMouse = new JCheckBox();
    this.jPanel64 = new JPanel();
    simpSize = new JRadioButton();
    doubSize = new JRadioButton();
    fullSize = new JRadioButton();
    tripleSize = new JRadioButton();
    quadSize = new JRadioButton();
    freeSize = new JRadioButton();
    this.jMon8 = new JRadioButton();
    this.jPanel62 = new JPanel();
    this.jPanel8 = new JPanel();
    this.mmask = new JCheckBox();
    this.filter = new JCheckBox();
    this.mask2 = new JRadioButton();
    this.mask1 = new JRadioButton();
    this.superPal = new JCheckBox();
    this.frameskip = new JCheckBox();
    this.filterChooser = new JComboBox();
    level = new JSlider();
    this.jPanel7 = new JPanel();
    this.jSlider1 = new JSlider();
    this.jCheckBox12 = new JCheckBox();
    this.jLabel79 = new JLabel();
    this.bright = new JLabel();
    this.jLabel78 = new JLabel();
    this.jPanel59 = new JPanel();
    red = new JSlider();
    green = new JSlider();
    blue = new JSlider();
    this.jLabel3 = new JLabel();
    this.jSlider2 = new JSlider();
    this.jPanel60 = new JPanel();
    this.pal = new JCheckBox();
    this.pal1 = new JCheckBox();
    this.palvalue = new JSlider();
    this.palvalue1 = new JSlider();
    this.jLabel2 = new JLabel();
    this.jLabel7 = new JLabel();
    this.jLabel17 = new JLabel();
    this.jPanel32 = new JPanel();
    this.jCheckBox16 = new JCheckBox();
    this.accelerate = new JCheckBox();
    this.jCheckBox17 = new JCheckBox();
    this.jPanel65 = new JPanel();
    this.jPanel66 = new JPanel();
    pan1 = new JTextField();
    pan2 = new JTextField();
    pan3 = new JTextField();
    pan4 = new JTextField();
    pan5 = new JTextField();
    pan6 = new JTextField();
    pan7 = new JTextField();
    pan8 = new JTextField();
    pan9 = new JTextField();
    pan10 = new JTextField();
    pan11 = new JTextField();
    pan12 = new JTextField();
    pan13 = new JTextField();
    pan14 = new JTextField();
    pan15 = new JTextField();
    pan16 = new JTextField();
    pan17 = new JTextField();
    pan18 = new JTextField();
    pan19 = new JTextField();
    pan20 = new JTextField();
    pan21 = new JTextField();
    pan22 = new JTextField();
    pan23 = new JTextField();
    pan24 = new JTextField();
    pan25 = new JTextField();
    pan26 = new JTextField();
    pan27 = new JTextField();
    pan28 = new JTextField();
    pan29 = new JTextField();
    pan30 = new JTextField();
    pan31 = new JTextField();
    pan32 = new JTextField();
    this.jPanel67 = new JPanel();
    selpan = new JTextField();
    this.jButton48 = new JButton();
    this.jPanel68 = new JPanel();
    jSlider3 = new JSlider();
    jSlider4 = new JSlider();
    jSlider5 = new JSlider();
    fieldRed = new JTextField();
    fieldGreen = new JTextField();
    fieldBlue = new JTextField();
    rgb = new JTextField();
    this.jLabel93 = new JLabel();
    this.jPanel1 = new JPanel();
    this.jPanel5 = new JPanel();
    this.jAY4 = new JToggleButton();
    this.jAY2 = new JToggleButton();
    this.jAY1 = new JToggleButton();
    this.jAY3 = new JToggleButton();
    this.jAYE = new JCheckBox();
    this.jAYE1 = new JCheckBox();
    this.drivenoises = new JCheckBox();
    this.keynoise = new JCheckBox();
    this.mute = new JCheckBox();
    this.buffersize = new JSlider();
    this.audiodisplay = new JPanel();
    this.jAY5 = new JToggleButton();
    this.jAY6 = new JToggleButton();
    this.lock = new JCheckBox();
    this.jComboBox2 = new JComboBox();
    this.chipnoise = new JCheckBox();
    this.jPanel4 = new JPanel();
    this.audioformat = new JComboBox();
    this.formatlabel = new JLabel();
    this.jPanel46 = new JPanel();
    leftvumeter = new JProgressBar();
    midvumeter = new JProgressBar();
    rightvumeter = new JProgressBar();
    this.jPanel51 = new JPanel();
    chanA = new JToggleButton();
    chanB = new JToggleButton();
    chanC = new JToggleButton();
    this.jCheckBox14 = new JCheckBox();
    this.jCheckBox15 = new JCheckBox();
    this.jComboBox3 = new JComboBox();
    this.jLabel92 = new JLabel();
    this.pufferl = new JLabel();
    this.jPanel41 = new JPanel();
    psg1a = new JProgressBar();
    psg1b = new JProgressBar();
    psg1c = new JProgressBar();
    psg2a = new JProgressBar();
    psg2b = new JProgressBar();
    psg2c = new JProgressBar();
    this.jPanel42 = new JPanel();
    this.jLabel94 = new JLabel();
    this.Avol = new JPanel();
    this.Dvol = new JPanel();
    this.jPanel12 = new JPanel();
    this.jPanel13 = new JPanel();
    this.mem0 = new JRadioButton();
    this.mem1 = new JRadioButton();
    this.mem2 = new JRadioButton();
    this.mem3 = new JRadioButton();
    this.mem5 = new JRadioButton();
    this.mem4 = new JRadioButton();
    this.jCheckBox3 = new JCheckBox();
    this.jButton30 = new JButton();
    this.keyclash = new JCheckBox();
    this.memorydisplay = new JCheckBox();
    this.jPanel14 = new JPanel();
    this.jRadioButton7 = new JRadioButton();
    this.jRadioButton8 = new JRadioButton();
    this.jRadioButton9 = new JRadioButton();
    this.jRadioButton10 = new JRadioButton();
    this.jRadioButton11 = new JRadioButton();
    this.jRadioButton12 = new JRadioButton();
    this.jRadioButton13 = new JRadioButton();
    this.jRadioButton14 = new JRadioButton();
    this.jButton4 = new JButton();
    this.jLabel98 = new JLabel();
    this.jPanel18 = new JPanel();
    this.jCheckBox2 = new JCheckBox();
    this.jCheckBox11 = new JCheckBox();
    sync = new JCheckBox();
    this.jCheckBox20 = new JCheckBox();
    this.crtc = new JCheckBox();
    this.jPanel28 = new JPanel();
    this.jCheckBox6 = new JCheckBox();
    this.fps = new JProgressBar();
    this.jLabel29 = new JLabel();
    this.jCheckBox7 = new JCheckBox();
    this.cpu = new JProgressBar();
    this.jLabel30 = new JLabel();
    this.jSeparator1 = new JSeparator();
    this.jSeparator2 = new JSeparator();
    jCheckBox8 = new JCheckBox();
    this.memoryBar = new JProgressBar();
    this.jLabel67 = new JLabel();
    this.jButton2 = new JButton();
    jCheckBox19 = new JCheckBox();
    this.jPanel15 = new JPanel();
    this.jPanel16 = new JPanel();
    this.up0 = new JComboBox();
    this.up1 = new JComboBox();
    this.up2 = new JComboBox();
    this.up3 = new JComboBox();
    this.up4 = new JComboBox();
    this.up5 = new JComboBox();
    this.up6 = new JComboBox();
    this.up7 = new JComboBox();
    this.up8 = new JComboBox();
    this.up9 = new JComboBox();
    this.up10 = new JComboBox();
    this.up11 = new JComboBox();
    this.up12 = new JComboBox();
    this.up13 = new JComboBox();
    this.up14 = new JComboBox();
    this.up15 = new JComboBox();
    this.label1 = new JLabel();
    this.label3 = new JLabel();
    this.label4 = new JLabel();
    this.label5 = new JLabel();
    this.label6 = new JLabel();
    this.label7 = new JLabel();
    this.label8 = new JLabel();
    this.label9 = new JLabel();
    this.label10 = new JLabel();
    this.label11 = new JLabel();
    this.label12 = new JLabel();
    this.label13 = new JLabel();
    this.label14 = new JLabel();
    this.label15 = new JLabel();
    this.label16 = new JLabel();
    this.label17 = new JLabel();
    this.jCheckBox1 = new JCheckBox();
    this.jCheckBox5 = new JCheckBox();
    this.jButton6 = new JButton();
    this.selU1 = new JButton();
    this.selU2 = new JButton();
    this.selU3 = new JButton();
    this.selU4 = new JButton();
    this.selU5 = new JButton();
    this.selU6 = new JButton();
    this.selU7 = new JButton();
    this.selU8 = new JButton();
    this.selU9 = new JButton();
    this.selU10 = new JButton();
    this.selU11 = new JButton();
    this.selU12 = new JButton();
    this.selU13 = new JButton();
    this.selU14 = new JButton();
    this.selU15 = new JButton();
    this.selU16 = new JButton();
    localize = new JCheckBox();
    this.pluson = new JButton();
    cprfile = new JTextField();
    cprload = new JButton();
    this.setRoms = new JButton();
    this.jButton46 = new JButton();
    this.roms32 = new JCheckBox();
    this.set32roms = new JButton();
    this.jPanel17 = new JPanel();
    this.loROM = new JComboBox();
    this.label2 = new JLabel();
    this.selL0 = new JButton();
    this.jPanel19 = new JPanel();
    this.sysselect = new JComboBox();
    this.jLabel21 = new JLabel();
    loadram = new JButton();
    saveram = new JButton();
    this.jPanel26 = new JPanel();
    this.jPanel29 = new JPanel();
    this.eject0 = new JToggleButton();
    this.load0 = new JButton();
    this.jLabel31 = new JLabel();
    this.eject1 = new JToggleButton();
    this.load1 = new JButton();
    this.jLabel32 = new JLabel();
    this.eject2 = new JToggleButton();
    this.load2 = new JButton();
    this.jLabel34 = new JLabel();
    this.eject3 = new JToggleButton();
    this.load3 = new JButton();
    this.autosave = new JRadioButton();
    this.asksave = new JRadioButton();
    this.noOverwrite = new JCheckBox();
    this.jButton19 = new JButton();
    this.jButton20 = new JButton();
    this.jLabel33 = new JLabel();
    this.name3 = new JTextField();
    name0 = new JTextField();
    name1 = new JTextField();
    this.name2 = new JTextField();
    this.h01 = new JRadioButton();
    this.h00 = new JRadioButton();
    this.jLabel74 = new JLabel();
    this.jLabel75 = new JLabel();
    this.h10 = new JRadioButton();
    this.h11 = new JRadioButton();
    this.h21 = new JRadioButton();
    this.jLabel76 = new JLabel();
    this.h20 = new JRadioButton();
    this.h31 = new JRadioButton();
    this.h30 = new JRadioButton();
    this.jLabel77 = new JLabel();
    this.fastdisk = new JCheckBox();
    this.fdcenabled = new JCheckBox();
    this.load4 = new JButton();
    this.load5 = new JButton();
    this.jPanel30 = new JPanel();
    this.jCheckBox9 = new JCheckBox();
    this.jPanel31 = new JPanel();
    this.freq11 = new JRadioButton();
    this.freq22 = new JRadioButton();
    this.freq44 = new JRadioButton();
    this.jLabel23 = new JLabel();
    this.jCheckBox10 = new JCheckBox();
    this.jToggleButton2 = new JToggleButton();
    this.jButton15 = new JButton();
    this.jButton17 = new JButton();
    this.jButton18 = new JButton();
    this.jButton14 = new JButton();
    this.tapename = new JTextField();
    this.jButton34 = new JButton();
    this.jPanel20 = new JPanel();
    this.jPanel22 = new JPanel();
    this.printer = new JCheckBox();
    this.digiblaster = new JCheckBox();
    this.jButton5 = new JButton();
    this.amdrum = new JCheckBox();
    this.playcity = new JCheckBox();
    this.jRadioButton3 = new JRadioButton();
    this.jRadioButton4 = new JRadioButton();
    this.jPanel23 = new JPanel();
    this.jButton7 = new JButton();
    this.jButton8 = new JButton();
    this.jButton9 = new JButton();
    this.jButton10 = new JButton();
    this.jPanel25 = new JPanel();
    this.jScrollPane1 = new JScrollPane();
    autotype = new JTextArea();
    this.jButton11 = new JButton();
    this.jButton1 = new JButton();
    this.jCheckBox13 = new JCheckBox();
    this.jPanel21 = new JPanel();
    this.spenable = new JCheckBox();
    this.dkt = new JRadioButton();
    this.ssa1 = new JRadioButton();
    this.jPanel24 = new JPanel();
    this.jCheckBox18 = new JCheckBox();
    this.keyc = new JLabel();
    keycode = new JLabel();
    this.infopanel = new JPanel();
    this.jLabel4 = new JLabel();
    this.jLabel5 = new JLabel();
    this.jLabel6 = new JLabel();
    aboutline = new JLabel();
    this.jLabel8 = new JLabel();
    this.jPanel11 = new JPanel();
    this.jLabel9 = new JLabel();
    this.jPanel9 = new JPanel();
    this.jLabel1 = new JLabel();
    this.jLabel18 = new JLabel();
    this.jLabel19 = new JLabel();
    this.jLabel69 = new JLabel();
    this.jLabel85 = new JLabel();
    this.scrollinfo = new JPanel();
    this.jLabel11 = new JLabel();
    this.jButton45 = new JButton();
    this.jLabel95 = new JLabel();
    this.jLabel96 = new JLabel();
    this.Welcome = new JInternalFrame();
    this.jLabel25 = new JLabel();
    this.jButton12 = new JButton();
    this.jButton13 = new JButton();
    this.jButton24 = new JButton();
    this.jCheckBox4 = new JCheckBox();
    this.jScrollPane2 = new JScrollPane();
    this.qinfo = new JEditorPane();
    this.clock = new JInternalFrame();
    this.jPanel27 = new JPanel();
    this.alarmhour = new JTextField();
    this.addhour = new JButton();
    this.subhour = new JButton();
    this.addmin = new JButton();
    this.alarmmin = new JTextField();
    this.submin = new JButton();
    this.light = new JToggleButton();
    this.alarmpanel = new JPanel();
    this.timedisplay = new JLabel();
    this.date = new JLabel();
    this.jButton16 = new JButton();
    this.jToggleButton1 = new JToggleButton();
    this.jLabel27 = new JLabel();
    this.alarmenable = new JLabel();
    this.jLabel26 = new JLabel();
    this.cchooser = new JInternalFrame();
    this.colchoos = new JColorChooser();
    this.jButton25 = new JButton();
    this.colo = new JComboBox();
    this.jButton33 = new JButton();
    this.jLabel81 = new JLabel();
    dskutil = new JInternalFrame();
    this.at800 = new JInternalFrame();
    this.bddFrame = new JInternalFrame();
    this.tapedeck = new JInternalFrame();
    this.keyboard = new JInternalFrame();
    this.keypanel = new JPanel();
    this.mandel = new JInternalFrame();
    this.jPanel36 = new JPanel();
    this.jButton26 = new JButton();
    this.jButton27 = new JButton();
    this.jButton49 = new JButton();
    this.jButton28 = new JButton();
    this.jButton29 = new JButton();
    this.jToggleButton5 = new JToggleButton();
    this.calc = new JInternalFrame();
    this.rasterFrame = new JInternalFrame();
    this.GlossyClock = new JLayeredPane();
    this.transparentFace = new JLabel();
    this.clockPanel = new JPanel();
    showGlass = new JCheckBox();
    this.deathi = new JLabel();
    this.atarii = new JLabel();
    this.hexi = new JLabel();
    this.capi = new JLabel();
    this.consoli = new JLabel();
    this.ymi = new JLabel();
    this.clocki = new JLabel();
    this.infoi = new JLabel();
    this.minii = new JLabel();
    this.chati = new JLabel();
    this.radioi = new JLabel();
    this.browsi = new JLabel();
    this.configi = new JLabel();
    this.debugi = new JLabel();
    this.tapei = new JLabel();
    this.painti = new JLabel();
    this.inii = new JLabel();
    this.newii = new JLabel();
    this.oldii = new JLabel();
    this.tiledi = new JLabel();
    this.assembli = new JLabel();
    this.calci = new JLabel();
    this.flopyi = new JLabel();
    this.paci = new JLabel();
    this.pokei = new JLabel();
    this.jLabel24 = new JLabel();
    this.webi = new JLabel();
    this.favi = new JLabel();
    this.dski = new JLabel();
    this.gx4000i = new JLabel();
    this.bddi = new JLabel();
    this.cdi = new JLabel();
    this.rasteri = new JLabel();
    this.rolandi = new JLabel();
    this.taskbar = new JPanel();
    this.jPanel34 = new JPanel();
    this.jLabel72 = new JLabel();
    this.jPanel47 = new JPanel();
    fpsled = new JPanel();
    this.jPanel45 = new JPanel();
    led0 = new JPanel();
    led1 = new JPanel();
    led2 = new JPanel();
    led3 = new JPanel();
    this.jPanel49 = new JPanel();
    led5 = new JPanel();
    this.jSeparator4 = new JSeparator();
    this.recb = new JButton();
    this.playb = new JButton();
    this.rewb = new JButton();
    this.ffwb = new JButton();
    this.stopb = new JButton();
    this.pauseb = new JButton();
    this.jSeparator7 = new JSeparator();
    this.jLabel66 = new JLabel();
    this.jPanel35 = new JPanel();
    this.setbutton3 = new JButton();
    this.setbutton = new JButton();
    this.syncbutton = new JButton();
    this.resbutton = new JButton();
    this.quitbutton = new JButton();
    this.jPanel63 = new JPanel();
    this.timepanel = new JLabel();
    this.jLabel70.setFont(new Font("Tahoma", 1, 11));
    this.jLabel70.setForeground(new Color(0, 0, 204));
    this.jLabel70.setText("<html><u>www.javasoft.de</u></html>");
    this.jLabel70.setFocusable(false);
    this.jLabel70.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel70MouseReleased(evt);
          }
        });
    this.jLabel71.setFont(new Font("Tahoma", 0, 10));
    this.jLabel71.setText("Synthetica styles from:");
    this.jLabel71.setFocusable(false);
    this.jLabel20.setFont(new Font("Tahoma", 0, 10));
    this.jLabel20.setText("Freeware licensed");
    this.jLabel20.setFocusable(false);
    this.periphery.setBorder(BorderFactory.createEtchedBorder());
    this.periphery.setFocusable(false);
    this.periphery.setMinimumSize(new Dimension(536, 157));
    this.jButton23.setText("Update");
    this.jButton23.setFocusable(false);
    this.jButton23.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton23ActionPerformed(evt);
          }
        });
    this.jButton22.setText("Run");
    this.jButton22.setFocusPainted(false);
    this.jButton22.setFocusable(false);
    this.jButton22.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton22ActionPerformed(evt);
          }
        });
    this.jButton41.setText("Stop");
    this.jButton41.setFocusPainted(false);
    this.jButton41.setFocusable(false);
    this.jButton41.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton41ActionPerformed(evt);
          }
        });
    this.jButton42.setText("Step");
    this.jButton42.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton42ActionPerformed(evt);
          }
        });
    this.jButton42.addKeyListener(new KeyAdapter() {
          public void keyPressed(KeyEvent evt) {
            Desktop.this.jButton42KeyPressed(evt);
          }
        });
    this.jButton43.setText("Step Over");
    this.jButton43.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton43ActionPerformed(evt);
          }
        });
    this.jButton43.addKeyListener(new KeyAdapter() {
          public void keyPressed(KeyEvent evt) {
            Desktop.this.jButton43KeyPressed(evt);
          }
        });
    this.jPanel57.setPreferredSize(new Dimension(650, 580));
    this.palpan.setBorder(BorderFactory.createTitledBorder("CPC-Palette"));
    this.palpan.setLayout(new GridBagLayout());
    this.jPanel52.setPreferredSize(new Dimension(100, 25));
    this.jPanel52.setLayout(new BorderLayout());
    this.jPanel53.setLayout(new BorderLayout());
    this.jLabel12.setText("Mode:");
    this.jPanel53.add(this.jLabel12, "Before");
    this.modo.setText(" 0");
    this.jPanel53.add(this.modo, "Center");
    this.jPanel52.add(this.jPanel53, "Center");
    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridy = 6;
    gridBagConstraints.gridwidth = -1;
    gridBagConstraints.gridheight = 0;
    gridBagConstraints.ipadx = 61;
    gridBagConstraints.ipady = 11;
    gridBagConstraints.anchor = 17;
    this.palpan.add(this.jPanel52, gridBagConstraints);
    this.jPanel58.setBorder(BorderFactory.createTitledBorder("Plus-Sprites"));
    sprite1.setHorizontalAlignment(0);
    sprite1.setBorder(BorderFactory.createEtchedBorder());
    sprite2.setHorizontalAlignment(0);
    sprite2.setBorder(BorderFactory.createEtchedBorder());
    sprite3.setHorizontalAlignment(0);
    sprite3.setBorder(BorderFactory.createEtchedBorder());
    sprite4.setHorizontalAlignment(0);
    sprite4.setBorder(BorderFactory.createEtchedBorder());
    sprite5.setHorizontalAlignment(0);
    sprite5.setBorder(BorderFactory.createEtchedBorder());
    sprite6.setHorizontalAlignment(0);
    sprite6.setBorder(BorderFactory.createEtchedBorder());
    sprite7.setHorizontalAlignment(0);
    sprite7.setBorder(BorderFactory.createEtchedBorder());
    sprite8.setHorizontalAlignment(0);
    sprite8.setBorder(BorderFactory.createEtchedBorder());
    sprite9.setHorizontalAlignment(0);
    sprite9.setBorder(BorderFactory.createEtchedBorder());
    sprite10.setHorizontalAlignment(0);
    sprite10.setBorder(BorderFactory.createEtchedBorder());
    sprite11.setHorizontalAlignment(0);
    sprite11.setBorder(BorderFactory.createEtchedBorder());
    sprite12.setHorizontalAlignment(0);
    sprite12.setBorder(BorderFactory.createEtchedBorder());
    sprite13.setHorizontalAlignment(0);
    sprite13.setBorder(BorderFactory.createEtchedBorder());
    sprite14.setHorizontalAlignment(0);
    sprite14.setBorder(BorderFactory.createEtchedBorder());
    sprite15.setHorizontalAlignment(0);
    sprite15.setBorder(BorderFactory.createEtchedBorder());
    sprite16.setHorizontalAlignment(0);
    sprite16.setBorder(BorderFactory.createEtchedBorder());
    GroupLayout jPanel58Layout = new GroupLayout(this.jPanel58);
    this.jPanel58.setLayout(jPanel58Layout);
    jPanel58Layout.setHorizontalGroup(jPanel58Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel58Layout.createSequentialGroup().addContainerGap().addGroup(jPanel58Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel58Layout.createSequentialGroup().addComponent(sprite1, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(sprite2, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(sprite3, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(sprite4, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(sprite5, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(sprite6, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(sprite7, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(sprite8, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(mag1)).addGroup(jPanel58Layout.createSequentialGroup().addComponent(sprite9, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(sprite10, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(sprite11, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(sprite12, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(sprite13, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(sprite14, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(sprite15, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(sprite16, -2, 36, -2).addGap(6, 6, 6).addComponent(mag2))).addContainerGap(284, 32767)));
    jPanel58Layout.setVerticalGroup(jPanel58Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel58Layout.createSequentialGroup().addGroup(jPanel58Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel58Layout.createSequentialGroup().addGroup(jPanel58Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(sprite8, -2, 36, -2).addComponent(sprite7, -2, 36, -2).addComponent(sprite6, -2, 36, -2).addComponent(sprite5, -2, 36, -2).addComponent(sprite4, -2, 36, -2).addComponent(sprite3, -2, 36, -2).addComponent(sprite2, -2, 36, -2).addComponent(sprite1, -2, 36, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel58Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(sprite14, -2, 36, -2).addComponent(sprite13, -2, 36, -2).addComponent(sprite12, -2, 36, -2).addComponent(sprite11, -2, 36, -2).addComponent(sprite10, -2, 36, -2).addComponent(sprite9, -2, 36, -2).addComponent(sprite15, -2, 36, -2).addComponent(sprite16, -2, 36, -2).addComponent(mag2))).addComponent(mag1)).addContainerGap(-1, 32767)));
    this.jPanel55.setBorder(BorderFactory.createTitledBorder("CRTC Registers"));
    this.jTextField1.setColumns(2);
    this.jTextField1.setFont(new Font("Courier New", 0, 11));
    this.jTextField1.setHorizontalAlignment(0);
    this.jTextField1.setText("00");
    this.jTextField1.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField1.setDoubleBuffered(true);
    this.jTextField1.setFocusable(false);
    this.jLabel28.setFont(new Font("Courier New", 0, 11));
    this.jLabel28.setHorizontalAlignment(0);
    this.jLabel28.setText("00");
    this.jLabel28.setFocusable(false);
    this.jLabel35.setFont(new Font("Courier New", 0, 11));
    this.jLabel35.setHorizontalAlignment(0);
    this.jLabel35.setText("01");
    this.jLabel35.setFocusable(false);
    this.jTextField2.setColumns(2);
    this.jTextField2.setFont(new Font("Courier New", 0, 11));
    this.jTextField2.setHorizontalAlignment(0);
    this.jTextField2.setText("00");
    this.jTextField2.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField2.setDoubleBuffered(true);
    this.jTextField2.setFocusable(false);
    this.jTextField3.setColumns(2);
    this.jTextField3.setFont(new Font("Courier New", 0, 11));
    this.jTextField3.setHorizontalAlignment(0);
    this.jTextField3.setText("00");
    this.jTextField3.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField3.setDoubleBuffered(true);
    this.jTextField3.setFocusable(false);
    this.jLabel36.setFont(new Font("Courier New", 0, 11));
    this.jLabel36.setHorizontalAlignment(0);
    this.jLabel36.setText("02");
    this.jLabel36.setFocusable(false);
    this.jLabel37.setFont(new Font("Courier New", 0, 11));
    this.jLabel37.setHorizontalAlignment(0);
    this.jLabel37.setText("03");
    this.jLabel37.setFocusable(false);
    this.jTextField4.setColumns(2);
    this.jTextField4.setFont(new Font("Courier New", 0, 11));
    this.jTextField4.setHorizontalAlignment(0);
    this.jTextField4.setText("00");
    this.jTextField4.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField4.setDoubleBuffered(true);
    this.jTextField4.setFocusable(false);
    this.jTextField5.setColumns(2);
    this.jTextField5.setFont(new Font("Courier New", 0, 11));
    this.jTextField5.setHorizontalAlignment(0);
    this.jTextField5.setText("00");
    this.jTextField5.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField5.setDoubleBuffered(true);
    this.jTextField5.setFocusable(false);
    this.jLabel38.setFont(new Font("Courier New", 0, 11));
    this.jLabel38.setHorizontalAlignment(0);
    this.jLabel38.setText("04");
    this.jLabel38.setFocusable(false);
    this.jTextField6.setColumns(2);
    this.jTextField6.setFont(new Font("Courier New", 0, 11));
    this.jTextField6.setHorizontalAlignment(0);
    this.jTextField6.setText("00");
    this.jTextField6.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField6.setDoubleBuffered(true);
    this.jTextField6.setFocusable(false);
    this.jLabel39.setFont(new Font("Courier New", 0, 11));
    this.jLabel39.setHorizontalAlignment(0);
    this.jLabel39.setText("05");
    this.jLabel39.setFocusable(false);
    this.jLabel40.setFont(new Font("Courier New", 0, 11));
    this.jLabel40.setHorizontalAlignment(0);
    this.jLabel40.setText("06");
    this.jLabel40.setFocusable(false);
    this.jTextField7.setColumns(2);
    this.jTextField7.setFont(new Font("Courier New", 0, 11));
    this.jTextField7.setHorizontalAlignment(0);
    this.jTextField7.setText("00");
    this.jTextField7.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField7.setDoubleBuffered(true);
    this.jTextField7.setFocusable(false);
    this.jTextField8.setColumns(2);
    this.jTextField8.setFont(new Font("Courier New", 0, 11));
    this.jTextField8.setHorizontalAlignment(0);
    this.jTextField8.setText("00");
    this.jTextField8.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField8.setDoubleBuffered(true);
    this.jTextField8.setFocusable(false);
    this.jLabel41.setFont(new Font("Courier New", 0, 11));
    this.jLabel41.setHorizontalAlignment(0);
    this.jLabel41.setText("07");
    this.jLabel41.setFocusable(false);
    this.jTextField9.setColumns(2);
    this.jTextField9.setFont(new Font("Courier New", 0, 11));
    this.jTextField9.setHorizontalAlignment(0);
    this.jTextField9.setText("00");
    this.jTextField9.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField9.setDoubleBuffered(true);
    this.jTextField9.setFocusable(false);
    this.jLabel42.setFont(new Font("Courier New", 0, 11));
    this.jLabel42.setHorizontalAlignment(0);
    this.jLabel42.setText("08");
    this.jLabel42.setFocusable(false);
    this.jTextField10.setColumns(2);
    this.jTextField10.setFont(new Font("Courier New", 0, 11));
    this.jTextField10.setHorizontalAlignment(0);
    this.jTextField10.setText("00");
    this.jTextField10.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField10.setDoubleBuffered(true);
    this.jTextField10.setFocusable(false);
    this.jLabel43.setFont(new Font("Courier New", 0, 11));
    this.jLabel43.setHorizontalAlignment(0);
    this.jLabel43.setText("09");
    this.jLabel43.setFocusable(false);
    this.jLabel44.setFont(new Font("Courier New", 0, 11));
    this.jLabel44.setHorizontalAlignment(0);
    this.jLabel44.setText("10");
    this.jLabel44.setFocusable(false);
    this.jTextField11.setColumns(2);
    this.jTextField11.setFont(new Font("Courier New", 0, 11));
    this.jTextField11.setHorizontalAlignment(0);
    this.jTextField11.setText("00");
    this.jTextField11.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField11.setDoubleBuffered(true);
    this.jTextField11.setFocusable(false);
    this.jTextField12.setColumns(2);
    this.jTextField12.setFont(new Font("Courier New", 0, 11));
    this.jTextField12.setHorizontalAlignment(0);
    this.jTextField12.setText("00");
    this.jTextField12.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField12.setDoubleBuffered(true);
    this.jTextField12.setFocusable(false);
    this.jLabel45.setFont(new Font("Courier New", 0, 11));
    this.jLabel45.setHorizontalAlignment(0);
    this.jLabel45.setText("11");
    this.jLabel45.setFocusable(false);
    this.jLabel46.setFont(new Font("Courier New", 0, 11));
    this.jLabel46.setHorizontalAlignment(0);
    this.jLabel46.setText("12");
    this.jLabel46.setFocusable(false);
    this.jTextField13.setColumns(2);
    this.jTextField13.setFont(new Font("Courier New", 0, 11));
    this.jTextField13.setHorizontalAlignment(0);
    this.jTextField13.setText("00");
    this.jTextField13.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField13.setDoubleBuffered(true);
    this.jTextField13.setFocusable(false);
    this.jTextField14.setColumns(2);
    this.jTextField14.setFont(new Font("Courier New", 0, 11));
    this.jTextField14.setHorizontalAlignment(0);
    this.jTextField14.setText("00");
    this.jTextField14.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField14.setDoubleBuffered(true);
    this.jTextField14.setFocusable(false);
    this.jLabel47.setFont(new Font("Courier New", 0, 11));
    this.jLabel47.setHorizontalAlignment(0);
    this.jLabel47.setText("13");
    this.jLabel47.setFocusable(false);
    this.jLabel48.setFont(new Font("Courier New", 0, 11));
    this.jLabel48.setHorizontalAlignment(0);
    this.jLabel48.setText("14");
    this.jLabel48.setFocusable(false);
    this.jTextField15.setColumns(2);
    this.jTextField15.setFont(new Font("Courier New", 0, 11));
    this.jTextField15.setHorizontalAlignment(0);
    this.jTextField15.setText("00");
    this.jTextField15.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField15.setDoubleBuffered(true);
    this.jTextField15.setFocusable(false);
    this.jTextField16.setColumns(2);
    this.jTextField16.setFont(new Font("Courier New", 0, 11));
    this.jTextField16.setHorizontalAlignment(0);
    this.jTextField16.setText("00");
    this.jTextField16.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField16.setDoubleBuffered(true);
    this.jTextField16.setFocusable(false);
    this.jLabel49.setFont(new Font("Courier New", 0, 11));
    this.jLabel49.setHorizontalAlignment(0);
    this.jLabel49.setText("15");
    this.jLabel49.setFocusable(false);
    this.mprev.setPreferredSize(new Dimension(96, 68));
    this.jButton44.setText("Dump as Basic code");
    this.jButton44.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton44ActionPerformed(evt);
          }
        });
    GroupLayout jPanel55Layout = new GroupLayout(this.jPanel55);
    this.jPanel55.setLayout(jPanel55Layout);
    jPanel55Layout.setHorizontalGroup(jPanel55Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel55Layout.createSequentialGroup().addContainerGap().addGroup(jPanel55Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel55Layout.createSequentialGroup().addComponent(this.jTextField1, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField2, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField3, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField4, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField5, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField6, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField7, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField8, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField9, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField10, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField11, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField12, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField13, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField14, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField15, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField16, -2, 20, -2)).addGroup(jPanel55Layout.createSequentialGroup().addComponent(this.jLabel28, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel35, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel36, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel37, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel38, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel39, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel40, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel41, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel42, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel43, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel44, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel45, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel46, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel47, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel48, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel49, -2, 20, -2)).addComponent(this.jButton44)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.mprev, -2, 74, -2).addContainerGap(70, 32767)));
    jPanel55Layout.setVerticalGroup(jPanel55Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel55Layout.createSequentialGroup().addGroup(jPanel55Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel55Layout.createSequentialGroup().addGroup(jPanel55Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel28, -2, 10, -2).addComponent(this.jLabel35, -2, 10, -2).addComponent(this.jLabel36, -2, 10, -2).addComponent(this.jLabel37, -2, 10, -2).addComponent(this.jLabel38, -2, 10, -2).addComponent(this.jLabel39, -2, 10, -2).addComponent(this.jLabel40, -2, 10, -2).addComponent(this.jLabel41, -2, 10, -2).addComponent(this.jLabel42, -2, 10, -2).addComponent(this.jLabel43, -2, 10, -2).addComponent(this.jLabel44, -2, 10, -2).addComponent(this.jLabel45, -2, 10, -2).addComponent(this.jLabel46, -2, 10, -2).addComponent(this.jLabel47, -2, 10, -2).addComponent(this.jLabel48, -2, 10, -2).addComponent(this.jLabel49, -2, 10, -2)).addGroup(jPanel55Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jTextField1, -2, -1, -2).addComponent(this.jTextField2, -2, -1, -2).addComponent(this.jTextField3, -2, -1, -2).addComponent(this.jTextField4, -2, -1, -2).addComponent(this.jTextField5, -2, -1, -2).addComponent(this.jTextField6, -2, -1, -2).addComponent(this.jTextField7, -2, -1, -2).addComponent(this.jTextField8, -2, -1, -2).addComponent(this.jTextField9, -2, -1, -2).addComponent(this.jTextField10, -2, -1, -2).addComponent(this.jTextField11, -2, -1, -2).addComponent(this.jTextField12, -2, -1, -2).addComponent(this.jTextField13, -2, -1, -2).addComponent(this.jTextField14, -2, -1, -2).addComponent(this.jTextField15, -2, -1, -2).addComponent(this.jTextField16, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton44)).addComponent(this.mprev, -2, 54, -2)).addContainerGap()));
    this.jPanel54.setBorder(BorderFactory.createTitledBorder("PSG Registers"));
    this.jTextField32.setColumns(2);
    this.jTextField32.setFont(new Font("Courier New", 0, 11));
    this.jTextField32.setHorizontalAlignment(0);
    this.jTextField32.setText("00");
    this.jTextField32.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField32.setDoubleBuffered(true);
    this.jTextField32.setFocusable(false);
    this.jLabel65.setFont(new Font("Courier New", 0, 11));
    this.jLabel65.setHorizontalAlignment(0);
    this.jLabel65.setText("15");
    this.jLabel65.setFocusable(false);
    this.jTextField31.setColumns(2);
    this.jTextField31.setFont(new Font("Courier New", 0, 11));
    this.jTextField31.setHorizontalAlignment(0);
    this.jTextField31.setText("00");
    this.jTextField31.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField31.setDoubleBuffered(true);
    this.jTextField31.setFocusable(false);
    this.jLabel64.setFont(new Font("Courier New", 0, 11));
    this.jLabel64.setHorizontalAlignment(0);
    this.jLabel64.setText("14");
    this.jLabel64.setFocusable(false);
    this.jTextField30.setColumns(2);
    this.jTextField30.setFont(new Font("Courier New", 0, 11));
    this.jTextField30.setHorizontalAlignment(0);
    this.jTextField30.setText("00");
    this.jTextField30.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField30.setDoubleBuffered(true);
    this.jTextField30.setFocusable(false);
    this.jLabel63.setFont(new Font("Courier New", 0, 11));
    this.jLabel63.setHorizontalAlignment(0);
    this.jLabel63.setText("13");
    this.jLabel63.setFocusable(false);
    this.jTextField29.setColumns(2);
    this.jTextField29.setFont(new Font("Courier New", 0, 11));
    this.jTextField29.setHorizontalAlignment(0);
    this.jTextField29.setText("00");
    this.jTextField29.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField29.setDoubleBuffered(true);
    this.jTextField29.setFocusable(false);
    this.jLabel62.setFont(new Font("Courier New", 0, 11));
    this.jLabel62.setHorizontalAlignment(0);
    this.jLabel62.setText("12");
    this.jLabel62.setFocusable(false);
    this.jTextField28.setColumns(2);
    this.jTextField28.setFont(new Font("Courier New", 0, 11));
    this.jTextField28.setHorizontalAlignment(0);
    this.jTextField28.setText("00");
    this.jTextField28.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField28.setDoubleBuffered(true);
    this.jTextField28.setFocusable(false);
    this.jLabel61.setFont(new Font("Courier New", 0, 11));
    this.jLabel61.setHorizontalAlignment(0);
    this.jLabel61.setText("11");
    this.jLabel61.setFocusable(false);
    this.jTextField27.setColumns(2);
    this.jTextField27.setFont(new Font("Courier New", 0, 11));
    this.jTextField27.setHorizontalAlignment(0);
    this.jTextField27.setText("00");
    this.jTextField27.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField27.setDoubleBuffered(true);
    this.jTextField27.setFocusable(false);
    this.jLabel60.setFont(new Font("Courier New", 0, 11));
    this.jLabel60.setHorizontalAlignment(0);
    this.jLabel60.setText("10");
    this.jLabel60.setFocusable(false);
    this.jTextField26.setColumns(2);
    this.jTextField26.setFont(new Font("Courier New", 0, 11));
    this.jTextField26.setHorizontalAlignment(0);
    this.jTextField26.setText("00");
    this.jTextField26.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField26.setDoubleBuffered(true);
    this.jTextField26.setFocusable(false);
    this.jLabel59.setFont(new Font("Courier New", 0, 11));
    this.jLabel59.setHorizontalAlignment(0);
    this.jLabel59.setText("09");
    this.jLabel59.setFocusable(false);
    this.jTextField25.setColumns(2);
    this.jTextField25.setFont(new Font("Courier New", 0, 11));
    this.jTextField25.setHorizontalAlignment(0);
    this.jTextField25.setText("00");
    this.jTextField25.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField25.setDoubleBuffered(true);
    this.jTextField25.setFocusable(false);
    this.jLabel58.setFont(new Font("Courier New", 0, 11));
    this.jLabel58.setHorizontalAlignment(0);
    this.jLabel58.setText("08");
    this.jLabel58.setFocusable(false);
    this.jTextField24.setColumns(2);
    this.jTextField24.setFont(new Font("Courier New", 0, 11));
    this.jTextField24.setHorizontalAlignment(0);
    this.jTextField24.setText("00");
    this.jTextField24.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField24.setDoubleBuffered(true);
    this.jTextField24.setFocusable(false);
    this.jLabel57.setFont(new Font("Courier New", 0, 11));
    this.jLabel57.setHorizontalAlignment(0);
    this.jLabel57.setText("07");
    this.jLabel57.setFocusable(false);
    this.jLabel56.setFont(new Font("Courier New", 0, 11));
    this.jLabel56.setHorizontalAlignment(0);
    this.jLabel56.setText("06");
    this.jLabel56.setFocusable(false);
    this.jTextField23.setColumns(2);
    this.jTextField23.setFont(new Font("Courier New", 0, 11));
    this.jTextField23.setHorizontalAlignment(0);
    this.jTextField23.setText("00");
    this.jTextField23.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField23.setDoubleBuffered(true);
    this.jTextField23.setFocusable(false);
    this.jTextField22.setColumns(2);
    this.jTextField22.setFont(new Font("Courier New", 0, 11));
    this.jTextField22.setHorizontalAlignment(0);
    this.jTextField22.setText("00");
    this.jTextField22.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField22.setDoubleBuffered(true);
    this.jTextField22.setFocusable(false);
    this.jLabel55.setFont(new Font("Courier New", 0, 11));
    this.jLabel55.setHorizontalAlignment(0);
    this.jLabel55.setText("05");
    this.jLabel55.setFocusable(false);
    this.jTextField21.setColumns(2);
    this.jTextField21.setFont(new Font("Courier New", 0, 11));
    this.jTextField21.setHorizontalAlignment(0);
    this.jTextField21.setText("00");
    this.jTextField21.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField21.setDoubleBuffered(true);
    this.jTextField21.setFocusable(false);
    this.jLabel54.setFont(new Font("Courier New", 0, 11));
    this.jLabel54.setHorizontalAlignment(0);
    this.jLabel54.setText("04");
    this.jLabel54.setFocusable(false);
    this.jTextField20.setColumns(2);
    this.jTextField20.setFont(new Font("Courier New", 0, 11));
    this.jTextField20.setHorizontalAlignment(0);
    this.jTextField20.setText("00");
    this.jTextField20.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField20.setDoubleBuffered(true);
    this.jTextField20.setFocusable(false);
    this.jLabel53.setFont(new Font("Courier New", 0, 11));
    this.jLabel53.setHorizontalAlignment(0);
    this.jLabel53.setText("03");
    this.jLabel53.setFocusable(false);
    this.jLabel52.setFont(new Font("Courier New", 0, 11));
    this.jLabel52.setHorizontalAlignment(0);
    this.jLabel52.setText("02");
    this.jLabel52.setFocusable(false);
    this.jTextField19.setColumns(2);
    this.jTextField19.setFont(new Font("Courier New", 0, 11));
    this.jTextField19.setHorizontalAlignment(0);
    this.jTextField19.setText("00");
    this.jTextField19.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField19.setDoubleBuffered(true);
    this.jTextField19.setFocusable(false);
    this.jTextField18.setColumns(2);
    this.jTextField18.setFont(new Font("Courier New", 0, 11));
    this.jTextField18.setHorizontalAlignment(0);
    this.jTextField18.setText("00");
    this.jTextField18.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField18.setDoubleBuffered(true);
    this.jTextField18.setFocusable(false);
    this.jLabel51.setFont(new Font("Courier New", 0, 11));
    this.jLabel51.setHorizontalAlignment(0);
    this.jLabel51.setText("01");
    this.jLabel51.setFocusable(false);
    this.jTextField17.setColumns(2);
    this.jTextField17.setFont(new Font("Courier New", 0, 11));
    this.jTextField17.setHorizontalAlignment(0);
    this.jTextField17.setText("00");
    this.jTextField17.setBorder(BorderFactory.createEtchedBorder());
    this.jTextField17.setDoubleBuffered(true);
    this.jTextField17.setFocusable(false);
    this.jLabel50.setFont(new Font("Courier New", 0, 11));
    this.jLabel50.setHorizontalAlignment(0);
    this.jLabel50.setText("00");
    this.jLabel50.setFocusable(false);
    this.jPanel56.setLayout(new BorderLayout());
    this.jLabel15.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/psg/psg0.gif")));
    this.jLabel15.setBorder(BorderFactory.createEtchedBorder());
    this.jLabel16.setText("Envelope");
    GroupLayout jPanel54Layout = new GroupLayout(this.jPanel54);
    this.jPanel54.setLayout(jPanel54Layout);
    jPanel54Layout.setHorizontalGroup(jPanel54Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel54Layout.createSequentialGroup().addContainerGap().addGroup(jPanel54Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel54Layout.createSequentialGroup().addComponent(this.jTextField17, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField18, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField19, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField20, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField21, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField22, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField23, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField24, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField25, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField26, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField27, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField28, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField29, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField30, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField31, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jTextField32, -2, 20, -2)).addGroup(jPanel54Layout.createSequentialGroup().addComponent(this.jLabel50, -2, 20, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jLabel51, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel52, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel53, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel54, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel55, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel56, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel57, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel58, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel59, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel60, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel61, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel62, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel63, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel64, -2, 20, -2).addGap(10, 10, 10).addComponent(this.jLabel65, -2, 20, -2))).addGap(18, 18, 18).addGroup(jPanel54Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel16, -2, 96, -2).addComponent(this.jLabel15)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 36, 32767).addComponent(this.jPanel56, -2, -1, -2)));
    jPanel54Layout.setVerticalGroup(jPanel54Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel56, -2, -1, -2).addGroup(jPanel54Layout.createSequentialGroup().addGroup(jPanel54Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel54Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel51, -2, 10, -2).addComponent(this.jLabel50, -2, 10, -2)).addComponent(this.jLabel52, -2, 10, -2).addComponent(this.jLabel53, -2, 10, -2).addComponent(this.jLabel54, -2, 10, -2).addComponent(this.jLabel55, -2, 10, -2).addComponent(this.jLabel56, -2, 10, -2).addComponent(this.jLabel57, -2, 10, -2).addComponent(this.jLabel58, -2, 10, -2).addComponent(this.jLabel59, -2, 10, -2).addComponent(this.jLabel60, -2, 10, -2).addComponent(this.jLabel61, -2, 10, -2).addComponent(this.jLabel62, -2, 10, -2).addComponent(this.jLabel63, -2, 10, -2).addComponent(this.jLabel64, -2, 10, -2).addComponent(this.jLabel65, -2, 10, -2)).addGroup(jPanel54Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jTextField17, -2, -1, -2).addComponent(this.jTextField18, -2, -1, -2).addComponent(this.jTextField19, -2, -1, -2).addComponent(this.jTextField20, -2, -1, -2).addComponent(this.jTextField21, -2, -1, -2).addComponent(this.jTextField22, -2, -1, -2).addComponent(this.jTextField23, -2, -1, -2).addComponent(this.jTextField24, -2, -1, -2).addComponent(this.jTextField25, -2, -1, -2).addComponent(this.jTextField26, -2, -1, -2).addComponent(this.jTextField27, -2, -1, -2).addComponent(this.jTextField28, -2, -1, -2).addComponent(this.jTextField29, -2, -1, -2).addComponent(this.jTextField30, -2, -1, -2).addComponent(this.jTextField31, -2, -1, -2).addComponent(this.jTextField32, -2, -1, -2))).addGroup(jPanel54Layout.createSequentialGroup().addComponent(this.jLabel16).addComponent(this.jLabel15)));
    this.jPanel37.setBorder(BorderFactory.createTitledBorder("FDC info"));
    this.jLabel13.setText("Command:");
    cmd.setEditable(false);
    cmd.setColumns(14);
    cmd.setText("???");
    cmd.setBorder(BorderFactory.createEtchedBorder());
    fdcm.setText("FDC Motor on");
    fdcm.setFocusable(false);
    this.jLabel14.setText("Statusinfo:");
    statinf.setEditable(false);
    statinf.setColumns(14);
    statinf.setText("???");
    statinf.setBorder(BorderFactory.createEtchedBorder());
    statinf1.setEditable(false);
    statinf1.setColumns(14);
    statinf1.setText("???");
    statinf1.setBorder(BorderFactory.createEtchedBorder());
    GroupLayout jPanel37Layout = new GroupLayout(this.jPanel37);
    this.jPanel37.setLayout(jPanel37Layout);
    jPanel37Layout.setHorizontalGroup(jPanel37Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel37Layout.createSequentialGroup().addContainerGap().addGroup(jPanel37Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel37Layout.createSequentialGroup().addComponent(fdcm).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 41, 32767).addComponent(this.jLabel13).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(cmd, -2, -1, -2)).addGroup(jPanel37Layout.createSequentialGroup().addComponent(this.jLabel14).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(statinf, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(statinf1, -2, -1, -2))).addContainerGap(317, 32767)));
    jPanel37Layout.setVerticalGroup(jPanel37Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel37Layout.createSequentialGroup().addGroup(jPanel37Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(fdcm).addComponent(this.jLabel13).addComponent(cmd, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel37Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel14).addComponent(statinf, -2, -1, -2).addComponent(statinf1, -2, -1, -2)).addContainerGap(-1, 32767)));
    GroupLayout jPanel57Layout = new GroupLayout(this.jPanel57);
    this.jPanel57.setLayout(jPanel57Layout);
    jPanel57Layout.setHorizontalGroup(jPanel57Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel57Layout.createSequentialGroup().addContainerGap().addGroup(jPanel57Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.jPanel37, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.palpan, GroupLayout.Alignment.LEADING, -1, 642, 32767).addComponent(this.jPanel54, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.jPanel55, -1, -1, 32767).addComponent(this.jPanel58, GroupLayout.Alignment.LEADING, -1, -1, 32767)).addContainerGap()));
    jPanel57Layout.setVerticalGroup(jPanel57Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel57Layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel55, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel54, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.palpan, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel58, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel37, -2, -1, -2).addContainerGap(134, 32767)));
    this.jScrollPane4.setViewportView(this.jPanel57);
    GroupLayout peripheryLayout = new GroupLayout(this.periphery);
    this.periphery.setLayout(peripheryLayout);
    peripheryLayout.setHorizontalGroup(peripheryLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(peripheryLayout.createSequentialGroup().addGroup(peripheryLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(peripheryLayout.createSequentialGroup().addGap(10, 10, 10).addComponent(this.jButton22).addGap(6, 6, 6).addComponent(this.jButton41).addGap(6, 6, 6).addComponent(this.jButton42).addGap(6, 6, 6).addComponent(this.jButton43).addGap(355, 355, 355).addComponent(this.jButton23)).addGroup(peripheryLayout.createSequentialGroup().addContainerGap().addComponent(this.jScrollPane4, -1, 681, 32767))).addContainerGap()));
    peripheryLayout.setVerticalGroup(peripheryLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(peripheryLayout.createSequentialGroup().addContainerGap().addComponent(this.jScrollPane4, -2, 378, -2).addGap(11, 11, 11).addGroup(peripheryLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jButton22).addComponent(this.jButton41).addComponent(this.jButton42).addGroup(peripheryLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton43).addComponent(this.jButton23)))));
    this.jMenu1.setText("Icons");
    this.jMenuItem1.setText("Re-Arrange");
    this.jMenuItem1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jMenuItem1ActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem1);
    this.jMenuItem3.setText("Align icons");
    this.jMenuItem3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jMenuItem3ActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem3);
    this.iconsAlign.setSelected(true);
    this.iconsAlign.setText("Align icons to grid");
    this.iconsAlign.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.iconsAlignActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.iconsAlign);
    this.pop.add(this.jMenu1);
    this.jMenu2.setText("Wallpaper");
    this.jMenuItem2.setText("Load Wallpaper");
    this.jMenuItem2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jMenuItem2ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem2);
    this.pop.add(this.jMenu2);
    setDefaultCloseOperation(0);
    setTitle("JavaCPC Desktop");
    setCursor(new Cursor(0));
    setFocusable(false);
    setName("dialogbox");
    this.desktop.setBorder(BorderFactory.createEtchedBorder());
    this.desktop.setDoubleBuffered(true);
    this.desktop.setSelectedFrame(this.Welcome);
    this.desktop.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.desktopMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.desktopMouseEntered(evt);
          }
        });
    this.starttab.setVisible(true);
    this.startlabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/startmenu.png")));
    this.jLabel73.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/df0.png")));
    this.jLabel73.setText("Load DSK into DF0");
    this.jLabel73.setCursor(new Cursor(12));
    this.jLabel73.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jLabel73MouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.jLabel73MouseExited(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel73MouseReleased(evt);
          }
        });
    this.jLabel80.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/df1.png")));
    this.jLabel80.setText("Load DSK into DF1");
    this.jLabel80.setCursor(new Cursor(12));
    this.jLabel80.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jLabel80MouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.jLabel80MouseExited(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel80MouseReleased(evt);
          }
        });
    this.jLabel82.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/sna_load.png")));
    this.jLabel82.setText("Load Snapshot");
    this.jLabel82.setCursor(new Cursor(12));
    this.jLabel82.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jLabel82MouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.jLabel82MouseExited(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel82MouseReleased(evt);
          }
        });
    this.jLabel83.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/sna_save.png")));
    this.jLabel83.setText("Save Snapshot");
    this.jLabel83.setCursor(new Cursor(12));
    this.jLabel83.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jLabel83MouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.jLabel83MouseExited(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel83MouseReleased(evt);
          }
        });
    this.jLabel84.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/dock.png")));
    this.jLabel84.setText("Undock Emulator Window");
    this.jLabel84.setCursor(new Cursor(12));
    this.jLabel84.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jLabel84MouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.jLabel84MouseExited(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel84MouseReleased(evt);
          }
        });
    this.jLabel87.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/settingsb.png")));
    this.jLabel87.setText("Configure Emulator");
    this.jLabel87.setCursor(new Cursor(12));
    this.jLabel87.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jLabel87MouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.jLabel87MouseExited(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel87MouseReleased(evt);
          }
        });
    this.jLabel88.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/resyncb.png")));
    this.jLabel88.setText("Re-Sync Emulator");
    this.jLabel88.setCursor(new Cursor(12));
    this.jLabel88.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jLabel88MouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.jLabel88MouseExited(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel88MouseReleased(evt);
          }
        });
    this.jLabel89.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/ico/donate_small.gif")));
    this.jLabel89.setText("Support JavaCPC");
    this.jLabel89.setCursor(new Cursor(12));
    this.jLabel89.setPreferredSize(new Dimension(162, 32));
    this.jLabel89.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jLabel89MouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.jLabel89MouseExited(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel89MouseReleased(evt);
          }
        });
    this.jLabel90.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/resetb.png")));
    this.jLabel90.setText("Reset");
    this.jLabel90.setCursor(new Cursor(12));
    this.jLabel90.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jLabel90MouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.jLabel90MouseExited(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel90MouseReleased(evt);
          }
        });
    this.jLabel91.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/quitb.png")));
    this.jLabel91.setText("Quit JavaCPC");
    this.jLabel91.setCursor(new Cursor(12));
    this.jLabel91.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jLabel91MouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.jLabel91MouseExited(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel91MouseReleased(evt);
          }
        });
    GroupLayout starttabLayout = new GroupLayout(this.starttab.getContentPane());
    this.starttab.getContentPane().setLayout(starttabLayout);
    starttabLayout.setHorizontalGroup(starttabLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(starttabLayout.createSequentialGroup().addContainerGap().addComponent(this.startlabel).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(starttabLayout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(starttabLayout.createSequentialGroup().addComponent(this.jLabel90, -2, 80, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel91, -2, 150, -2)).addGroup(starttabLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel73, -2, 200, -2).addComponent(this.jLabel80, -2, 200, -2).addComponent(this.jLabel82, -2, 200, -2).addComponent(this.jLabel83, -2, 200, -2).addComponent(this.jLabel84, -2, 200, -2).addComponent(this.jLabel87, -2, 200, -2).addComponent(this.jLabel88, -2, 200, -2).addComponent(this.jLabel89, -2, 200, -2))).addContainerGap(15, 32767)));
    starttabLayout.setVerticalGroup(starttabLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(starttabLayout.createSequentialGroup().addContainerGap().addGroup(starttabLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(starttabLayout.createSequentialGroup().addComponent(this.jLabel73).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel80).addGap(18, 18, 18).addComponent(this.jLabel82).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel83).addGap(18, 18, 18).addComponent(this.jLabel84).addGap(18, 18, 18).addComponent(this.jLabel87).addGap(18, 18, 18).addComponent(this.jLabel88).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jLabel89, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addGroup(starttabLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel90).addComponent(this.jLabel91))).addComponent(this.startlabel)).addContainerGap(29, 32767)));
    this.desktop.add(this.starttab);
    this.starttab.setBounds(820, 40, 320, 469);
    this.gamescdgui.setClosable(true);
    this.gamescdgui.setDefaultCloseOperation(1);
    this.gamescdgui.setIconifiable(true);
    this.gamescdgui.setTitle("CPCGamesCD GUI");
    this.gamescdgui.setVisible(false);
    this.desktop.add(this.gamescdgui);
    this.gamescdgui.setBounds(50, 40, 160, 120);
    webbrowser.setClosable(true);
    webbrowser.setDefaultCloseOperation(1);
    webbrowser.setIconifiable(true);
    webbrowser.setMaximizable(true);
    webbrowser.setResizable(true);
    webbrowser.setTitle("JavaCPC WebBrowser");
    GroupLayout webbrowserLayout = new GroupLayout(webbrowser.getContentPane());
    webbrowser.getContentPane().setLayout(webbrowserLayout);
    webbrowserLayout.setHorizontalGroup(webbrowserLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 784, 32767));
    webbrowserLayout.setVerticalGroup(webbrowserLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 575, 32767));
    this.desktop.add(webbrowser);
    webbrowser.setBounds(20, 30, 800, 600);
    printframe.setClosable(true);
    printframe.setDefaultCloseOperation(1);
    printframe.setIconifiable(true);
    printframe.setTitle("Printer");
    printframe.setDoubleBuffered(true);
    textprinter.setBorder(BorderFactory.createTitledBorder("Output"));
    textprinter.setMaximumSize((Dimension)null);
    printout.setColumns(20);
    printout.setFont(new Font("Monospaced", 1, 12));
    printout.setRows(5);
    this.jScrollPane3.setViewportView(printout);
    this.jPanel33.setBorder(BorderFactory.createTitledBorder("Functions"));
    this.jPanel33.setMaximumSize((Dimension)null);
    this.jButton35.setText("Clear");
    this.jButton35.setFocusPainted(false);
    this.jButton35.setFocusable(false);
    this.jButton35.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton35ActionPerformed(evt);
          }
        });
    this.jButton36.setText("Copy");
    this.jButton36.setFocusPainted(false);
    this.jButton36.setFocusable(false);
    this.jButton36.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton36ActionPerformed(evt);
          }
        });
    this.jButton37.setText("Save");
    this.jButton37.setFocusPainted(false);
    this.jButton37.setFocusable(false);
    this.jButton37.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton37ActionPerformed(evt);
          }
        });
    this.jButton38.setText("Send to CPC");
    this.jButton38.setFocusPainted(false);
    this.jButton38.setFocusable(false);
    this.jButton38.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton38ActionPerformed(evt);
          }
        });
    GroupLayout jPanel33Layout = new GroupLayout(this.jPanel33);
    this.jPanel33.setLayout(jPanel33Layout);
    jPanel33Layout.setHorizontalGroup(jPanel33Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel33Layout.createSequentialGroup().addContainerGap().addComponent(this.jButton35).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton36).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton37).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton38).addContainerGap(270, 32767)));
    jPanel33Layout.setVerticalGroup(jPanel33Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel33Layout.createSequentialGroup().addGroup(jPanel33Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton35).addComponent(this.jButton36).addComponent(this.jButton37).addComponent(this.jButton38)).addContainerGap(-1, 32767)));
    GroupLayout textprinterLayout = new GroupLayout(textprinter);
    textprinter.setLayout(textprinterLayout);
    textprinterLayout.setHorizontalGroup(textprinterLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(textprinterLayout.createSequentialGroup().addContainerGap().addComponent(this.jScrollPane3, -1, 552, 32767).addContainerGap()).addComponent(this.jPanel33, -1, -1, 32767));
    textprinterLayout.setVerticalGroup(textprinterLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(textprinterLayout.createSequentialGroup().addComponent(this.jScrollPane3, -1, 304, 32767).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel33, -2, -1, -2)));
    printframe.getContentPane().add(textprinter, "Center");
    this.desktop.add(printframe);
    printframe.setBounds(20, 20, 600, 410);
    floppy.setClosable(true);
    floppy.setDefaultCloseOperation(1);
    floppy.setIconifiable(true);
    floppy.setTitle("FDI");
    this.jPanel10.setPreferredSize(new Dimension(196, 320));
    this.jPanel10.setLayout((LayoutManager)new AbsoluteLayout());
    head.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/drive_head.png")));
    head.setFocusable(false);
    this.jPanel10.add(head, new AbsoluteConstraints(70, 42, -1, -1));
    fled3.setBackground(new Color(51, 0, 0));
    GroupLayout fled3Layout = new GroupLayout(fled3);
    fled3.setLayout(fled3Layout);
    fled3Layout.setHorizontalGroup(fled3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 14, 32767));
    fled3Layout.setVerticalGroup(fled3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 6, 32767));
    this.jPanel10.add(fled3, new AbsoluteConstraints(66, 310, 14, 6));
    fled2.setBackground(new Color(51, 0, 0));
    GroupLayout fled2Layout = new GroupLayout(fled2);
    fled2.setLayout(fled2Layout);
    fled2Layout.setHorizontalGroup(fled2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 14, 32767));
    fled2Layout.setVerticalGroup(fled2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 6, 32767));
    this.jPanel10.add(fled2, new AbsoluteConstraints(48, 310, 14, 6));
    fled1.setBackground(new Color(51, 0, 0));
    GroupLayout fled1Layout = new GroupLayout(fled1);
    fled1.setLayout(fled1Layout);
    fled1Layout.setHorizontalGroup(fled1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 14, 32767));
    fled1Layout.setVerticalGroup(fled1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 6, 32767));
    this.jPanel10.add(fled1, new AbsoluteConstraints(30, 310, 14, 6));
    fled0.setBackground(new Color(51, 0, 0));
    GroupLayout fled0Layout = new GroupLayout(fled0);
    fled0.setLayout(fled0Layout);
    fled0Layout.setHorizontalGroup(fled0Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 14, 32767));
    fled0Layout.setVerticalGroup(fled0Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 6, 32767));
    this.jPanel10.add(fled0, new AbsoluteConstraints(12, 310, 14, 6));
    this.jLabel86.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/drive.png")));
    this.jPanel10.add(this.jLabel86, new AbsoluteConstraints(0, 0, 200, 320));
    GroupLayout floppyLayout = new GroupLayout(floppy.getContentPane());
    floppy.getContentPane().setLayout(floppyLayout);
    floppyLayout.setHorizontalGroup(floppyLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(floppyLayout.createSequentialGroup().addComponent(this.jPanel10, -2, 196, -2).addContainerGap(-1, 32767)));
    floppyLayout.setVerticalGroup(floppyLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel10, -2, -1, -2));
    this.desktop.add(floppy);
    floppy.setBounds(10, 30, 204, 348);
    this.maped.setClosable(true);
    this.maped.setDefaultCloseOperation(1);
    this.maped.setIconifiable(true);
    this.maped.setMaximizable(true);
    this.maped.setResizable(true);
    this.maped.setTitle("Tiled");
    this.desktop.add(this.maped);
    this.maped.setBounds(80, 30, 580, 470);
    options.setClosable(true);
    options.setDefaultCloseOperation(1);
    options.setIconifiable(true);
    options.setTitle("Options");
    options.setMaximumSize(new Dimension(510, 410));
    options.setMinimumSize(new Dimension(510, 410));
    options.setPreferredSize(new Dimension(510, 410));
    OptionPane.setFocusable(false);
    OptionPane.setMaximumSize(new Dimension(510, 410));
    OptionPane.setMinimumSize(new Dimension(510, 410));
    OptionPane.setPreferredSize(new Dimension(510, 410));
    this.jPanel38.setFocusable(false);
    this.jPanel38.setMinimumSize(new Dimension(490, 360));
    this.jPanel38.setPreferredSize(new Dimension(490, 360));
    this.jPanel38.setLayout((LayoutManager)new AbsoluteLayout());
    this.jPanel39.setBorder(BorderFactory.createTitledBorder("Wallpaper & Style"));
    this.jPanel39.setFocusable(false);
    this.wallbehaviour.add(this.wallstretch);
    this.wallstretch.setText("Stretch");
    this.wallstretch.setFocusPainted(false);
    this.wallstretch.setFocusable(false);
    this.wallstretch.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.wallstretchActionPerformed(evt);
          }
        });
    this.wallbehaviour.add(this.wallcenter);
    this.wallcenter.setText("Center");
    this.wallcenter.setFocusPainted(false);
    this.wallcenter.setFocusable(false);
    this.wallcenter.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.wallcenterActionPerformed(evt);
          }
        });
    this.lookSelector.setFocusable(false);
    this.lookSelector.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent evt) {
            Desktop.this.lookSelectorItemStateChanged(evt);
          }
        });
    this.jLabel22.setText("Style:");
    this.jLabel22.setFocusable(false);
    this.restartj.setFont(new Font("Tahoma", 1, 12));
    this.restartj.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/view_refresh.png")));
    this.restartj.setText("Please restart JavaCPC");
    this.jButton31.setText("Load Wallpaper");
    this.jButton31.setFocusable(false);
    this.jButton31.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton31ActionPerformed(evt);
          }
        });
    this.jButton32.setText("Clear");
    this.jButton32.setFocusable(false);
    this.jButton32.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton32ActionPerformed(evt);
          }
        });
    this.forced.setText("Force");
    this.forced.setFocusable(false);
    this.forced.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.forcedActionPerformed(evt);
          }
        });
    this.jButton40.setText("Download Wallpaper");
    this.jButton40.setFocusPainted(false);
    this.jButton40.setFocusable(false);
    this.jButton40.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton40ActionPerformed(evt);
          }
        });
    slic.setText("Synthetica Lic.");
    slic.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.slicActionPerformed(evt);
          }
        });
    this.wallbehaviour.add(this.walltile);
    this.walltile.setText("Tile");
    this.walltile.setFocusPainted(false);
    this.walltile.setFocusable(false);
    this.walltile.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.walltileActionPerformed(evt);
          }
        });
    this.wallpreview.setPreferredSize(new Dimension(210, 160));
    GroupLayout wallpreviewLayout = new GroupLayout(this.wallpreview);
    this.wallpreview.setLayout(wallpreviewLayout);
    wallpreviewLayout.setHorizontalGroup(wallpreviewLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 210, 32767));
    wallpreviewLayout.setVerticalGroup(wallpreviewLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 160, 32767));
    GroupLayout jPanel39Layout = new GroupLayout(this.jPanel39);
    this.jPanel39.setLayout(jPanel39Layout);
    jPanel39Layout.setHorizontalGroup(jPanel39Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel39Layout.createSequentialGroup().addContainerGap().addComponent(this.wallpreview, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel39Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel39Layout.createSequentialGroup().addComponent(this.jButton31).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton32)).addGroup(jPanel39Layout.createSequentialGroup().addComponent(this.jLabel22, -2, 40, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.lookSelector, -2, -1, -2)).addGroup(jPanel39Layout.createSequentialGroup().addComponent(this.forced).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(slic)).addComponent(this.restartj).addGroup(jPanel39Layout.createSequentialGroup().addComponent(this.wallcenter).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.wallstretch).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.walltile)).addComponent(this.jButton40)).addGap(20, 20, 20)));
    jPanel39Layout.setVerticalGroup(jPanel39Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel39Layout.createSequentialGroup().addContainerGap().addGroup(jPanel39Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel39Layout.createSequentialGroup().addGroup(jPanel39Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel22, -2, 20, -2).addComponent(this.lookSelector, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel39Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.forced).addComponent(slic)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.restartj).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 15, 32767).addGroup(jPanel39Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton31, -2, 20, -2).addComponent(this.jButton32, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton40, -2, 20, -2).addGap(7, 7, 7).addGroup(jPanel39Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.wallstretch).addComponent(this.wallcenter).addComponent(this.walltile))).addGroup(jPanel39Layout.createSequentialGroup().addComponent(this.wallpreview, -2, -1, -2).addGap(0, 0, 32767))).addContainerGap()));
    this.jPanel38.add(this.jPanel39, new AbsoluteConstraints(10, 130, 480, 210));
    this.jPanel40.setBorder(BorderFactory.createTitledBorder("Options"));
    this.jPanel40.setFocusable(false);
    this.jButton21.setText("Reset icons");
    this.jButton21.setFocusable(false);
    this.jButton21.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton21ActionPerformed(evt);
          }
        });
    this.useconsole.setText("Java Console");
    this.useconsole.setFocusable(false);
    this.useconsole.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.useconsoleActionPerformed(evt);
          }
        });
    this.sinfo.setText("Show Quickinfo");
    this.sinfo.setFocusable(false);
    this.sinfo.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.sinfoActionPerformed(evt);
          }
        });
    this.jToggleButton3.setText("Always On Top");
    this.jToggleButton3.setFocusable(false);
    this.jToggleButton3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jToggleButton3ActionPerformed(evt);
          }
        });
    this.jLabel68.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/ms6128.gif")));
    this.jLabel68.setBorder(BorderFactory.createEtchedBorder());
    this.jLabel68.setFocusable(false);
    this.deskcheck.setText("Desktop");
    this.deskcheck.setFocusable(false);
    this.deskcheck.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.deskcheckActionPerformed(evt);
          }
        });
    this.jButton39.setText("Apply Registry-settings");
    this.jButton39.setFocusPainted(false);
    this.jButton39.setFocusable(false);
    this.jButton39.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton39ActionPerformed(evt);
          }
        });
    this.expand.setText("Full");
    this.expand.setFocusPainted(false);
    this.expand.setFocusable(false);
    this.expand.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.expandActionPerformed(evt);
          }
        });
    GroupLayout jPanel40Layout = new GroupLayout(this.jPanel40);
    this.jPanel40.setLayout(jPanel40Layout);
    jPanel40Layout.setHorizontalGroup(jPanel40Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel40Layout.createSequentialGroup().addContainerGap().addComponent(this.jLabel68).addGap(6, 6, 6).addGroup(jPanel40Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel40Layout.createSequentialGroup().addComponent(this.deskcheck).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.expand)).addComponent(this.useconsole).addComponent(this.sinfo)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 32, 32767).addGroup(jPanel40Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.jButton39, -1, -1, 32767).addComponent(this.jButton21, -1, -1, 32767).addComponent(this.jToggleButton3, -1, -1, 32767)).addContainerGap()));
    jPanel40Layout.setVerticalGroup(jPanel40Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel40Layout.createSequentialGroup().addGroup(jPanel40Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel40Layout.createSequentialGroup().addGroup(jPanel40Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jToggleButton3, -2, 18, -2).addComponent(this.deskcheck, -2, 20, -2).addComponent(this.expand)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton21, -2, 18, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton39, 0, 23, 32767)).addGroup(jPanel40Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(GroupLayout.Alignment.LEADING, jPanel40Layout.createSequentialGroup().addGap(22, 22, 22).addComponent(this.useconsole, -2, 20, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.sinfo, -2, 20, -2)).addComponent(this.jLabel68, -2, 70, -2))).addContainerGap(14, 32767)));
    this.jPanel38.add(this.jPanel40, new AbsoluteConstraints(10, 10, 480, 110));
    OptionPane.addTab("Desktop", new ImageIcon(getClass().getResource("/jemu/ui/ico/monitor.png")), this.jPanel38);
    this.jPanel2.setMinimumSize(new Dimension(490, 360));
    this.jPanel2.setPreferredSize(new Dimension(490, 360));
    this.jPanel2.setLayout(new BorderLayout());
    this.jTabbedPane1.setTabPlacement(2);
    this.videopanel.setBorder(BorderFactory.createTitledBorder("Monitor type"));
    this.videopanel.setFocusable(false);
    this.mongroup1.add(this.jMon1);
    this.jMon1.setText("CTM 644 Color");
    this.jMon1.setFocusable(false);
    this.jMon1.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jMon7MouseEntered(evt);
          }
        });
    this.jMon1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jMon1ActionPerformed(evt);
          }
        });
    this.mongroup1.add(this.jMon2);
    this.jMon2.setText("CTM 644 User");
    this.jMon2.setFocusable(false);
    this.jMon2.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jMon7MouseEntered(evt);
          }
        });
    this.jMon2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jMon2ActionPerformed(evt);
          }
        });
    this.mongroup1.add(this.jMon3);
    this.jMon3.setText("CTM 644 CPCe");
    this.jMon3.setFocusable(false);
    this.jMon3.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jMon7MouseEntered(evt);
          }
        });
    this.jMon3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jMon3ActionPerformed(evt);
          }
        });
    this.mongroup1.add(this.jMon4);
    this.jMon4.setText("GT64 Green");
    this.jMon4.setFocusable(false);
    this.jMon4.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jMon7MouseEntered(evt);
          }
        });
    this.jMon4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jMon4ActionPerformed(evt);
          }
        });
    this.mongroup1.add(this.jMon5);
    this.jMon5.setText("MM12 Grey");
    this.jMon5.setFocusable(false);
    this.jMon5.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jMon7MouseEntered(evt);
          }
        });
    this.jMon5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jMon5ActionPerformed(evt);
          }
        });
    this.jPanel6.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel6.setLayout(new GridLayout(1, 0));
    this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon1.gif")));
    this.jPanel6.add(this.MonLabel);
    this.mongroup1.add(this.jMon7);
    this.jMon7.setText("CTM 644 Real");
    this.jMon7.setFocusable(false);
    this.jMon7.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jMon7MouseEntered(evt);
          }
        });
    this.jMon7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jMon7ActionPerformed(evt);
          }
        });
    this.scanl.setText("Scanlines");
    this.scanl.setFocusable(false);
    this.scanl.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.scanlActionPerformed(evt);
          }
        });
    this.buttonGroup2.add(this.jRadioButton1);
    this.jRadioButton1.setSelected(true);
    this.jRadioButton1.setText("40007/8");
    this.jRadioButton1.setFocusPainted(false);
    this.jRadioButton1.setFocusable(false);
    this.jRadioButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jRadioButton1ActionPerformed(evt);
          }
        });
    this.buttonGroup2.add(this.jRadioButton2);
    this.jRadioButton2.setText("40010");
    this.jRadioButton2.setFocusPainted(false);
    this.jRadioButton2.setFocusable(false);
    this.jRadioButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jRadioButton2ActionPerformed(evt);
          }
        });
    this.freq.setText("60hz");
    this.freq.setFocusable(false);
    this.freq.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.freqActionPerformed(evt);
          }
        });
    this.mongroup1.add(this.jMon6);
    this.jMon6.setText("MM12 Mono");
    this.jMon6.setFocusable(false);
    this.jMon6.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jMon6MouseEntered(evt);
          }
        });
    this.jMon6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jMon6ActionPerformed(evt);
          }
        });
    this.jToggleButton4.setFont(new Font("Tahoma", 1, 11));
    this.jToggleButton4.setText("De-Interlace");
    this.jToggleButton4.setFocusable(false);
    this.jToggleButton4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jToggleButton4ActionPerformed(evt);
          }
        });
    this.jLabel10.setText("CRTC:");
    this.crtcg.add(this.crtc0);
    this.crtc0.setText("0");
    this.crtc0.setFocusable(false);
    this.crtc0.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.crtc0ActionPerformed(evt);
          }
        });
    this.crtcg.add(this.crtc1);
    this.crtc1.setText("1");
    this.crtc1.setFocusable(false);
    this.crtc1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.crtc1ActionPerformed(evt);
          }
        });
    hideMouse.setText("Hide mousecursor");
    hideMouse.setFocusable(false);
    hideMouse.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.hideMouseActionPerformed(evt);
          }
        });
    this.jPanel64.setBorder(BorderFactory.createTitledBorder("Display Size"));
    this.moniset.add(simpSize);
    simpSize.setFont(new Font("Tahoma", 0, 10));
    simpSize.setText("Simple");
    simpSize.setFocusable(false);
    simpSize.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent evt) {
            Desktop.this.simpSizeItemStateChanged(evt);
          }
        });
    this.moniset.add(doubSize);
    doubSize.setFont(new Font("Tahoma", 0, 10));
    doubSize.setText("2x Simple");
    doubSize.setFocusable(false);
    doubSize.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent evt) {
            Desktop.this.doubSizeItemStateChanged(evt);
          }
        });
    this.moniset.add(fullSize);
    fullSize.setFont(new Font("Tahoma", 0, 10));
    fullSize.setText("2x");
    fullSize.setFocusable(false);
    fullSize.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent evt) {
            Desktop.this.fullSizeItemStateChanged(evt);
          }
        });
    this.moniset.add(tripleSize);
    tripleSize.setFont(new Font("Tahoma", 0, 10));
    tripleSize.setText("3x");
    tripleSize.setFocusable(false);
    tripleSize.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent evt) {
            Desktop.this.tripleSizeItemStateChanged(evt);
          }
        });
    this.moniset.add(quadSize);
    quadSize.setFont(new Font("Tahoma", 0, 10));
    quadSize.setText("4x");
    quadSize.setFocusable(false);
    quadSize.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent evt) {
            Desktop.this.quadSizeItemStateChanged(evt);
          }
        });
    this.moniset.add(freeSize);
    freeSize.setFont(new Font("Tahoma", 0, 10));
    freeSize.setText("Free size");
    freeSize.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent evt) {
            Desktop.this.freeSizeItemStateChanged(evt);
          }
        });
    GroupLayout jPanel64Layout = new GroupLayout(this.jPanel64);
    this.jPanel64.setLayout(jPanel64Layout);
    jPanel64Layout.setHorizontalGroup(jPanel64Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel64Layout.createSequentialGroup().addContainerGap().addComponent(simpSize).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(doubSize).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(fullSize).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(tripleSize).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(quadSize).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(freeSize).addContainerGap(-1, 32767)));
    jPanel64Layout.setVerticalGroup(jPanel64Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel64Layout.createSequentialGroup().addGroup(jPanel64Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel64Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(fullSize).addComponent(tripleSize).addComponent(quadSize).addComponent(freeSize, -1, -1, 32767)).addGroup(jPanel64Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(doubSize).addComponent(simpSize))).addGap(0, 0, 32767)));
    this.mongroup1.add(this.jMon8);
    this.jMon8.setText("C64 ;-)");
    this.jMon8.setFocusable(false);
    this.jMon8.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.jMon8MouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.jMon8MouseExited(evt);
          }
        });
    this.jMon8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jMon8ActionPerformed(evt);
          }
        });
    GroupLayout videopanelLayout = new GroupLayout(this.videopanel);
    this.videopanel.setLayout(videopanelLayout);
    videopanelLayout.setHorizontalGroup(videopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(videopanelLayout.createSequentialGroup().addContainerGap().addGroup(videopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(hideMouse).addGroup(videopanelLayout.createSequentialGroup().addGroup(videopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jPanel6, -2, 140, -2).addGroup(videopanelLayout.createSequentialGroup().addComponent(this.scanl).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.freq)).addComponent(this.jToggleButton4, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(videopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(videopanelLayout.createSequentialGroup().addComponent(this.jMon6).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.jMon8)).addGroup(videopanelLayout.createSequentialGroup().addGroup(videopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jMon3).addComponent(this.jMon4).addComponent(this.jMon5).addGroup(videopanelLayout.createSequentialGroup().addComponent(this.jRadioButton1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jRadioButton2)).addComponent(this.jMon2).addGroup(videopanelLayout.createSequentialGroup().addComponent(this.jLabel10).addGap(2, 2, 2).addComponent(this.crtc0).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.crtc1)).addComponent(this.jMon7).addComponent(this.jMon1)).addGap(0, 0, 32767))))).addContainerGap()).addGroup(videopanelLayout.createSequentialGroup().addComponent(this.jPanel64, -2, -1, -2).addGap(0, 0, 32767)));
    videopanelLayout.setVerticalGroup(videopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(videopanelLayout.createSequentialGroup().addGroup(videopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(videopanelLayout.createSequentialGroup().addComponent(this.jMon1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jMon2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jMon3).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jMon7).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jMon4).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jMon5).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(videopanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jMon6).addComponent(this.jMon8)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(videopanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jRadioButton1).addComponent(this.jRadioButton2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(videopanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel10, -2, 20, -2).addComponent(this.crtc0).addComponent(this.crtc1))).addGroup(videopanelLayout.createSequentialGroup().addComponent(this.jPanel6, -2, 150, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(videopanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.scanl).addComponent(this.freq, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jToggleButton4, -2, 20, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(hideMouse))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel64, -2, -1, -2).addContainerGap(57, 32767)));
    GroupLayout jPanel61Layout = new GroupLayout(this.jPanel61);
    this.jPanel61.setLayout(jPanel61Layout);
    jPanel61Layout.setHorizontalGroup(jPanel61Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel61Layout.createSequentialGroup().addContainerGap().addComponent(this.videopanel, -2, -1, -2).addContainerGap(-1, 32767)));
    jPanel61Layout.setVerticalGroup(jPanel61Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel61Layout.createSequentialGroup().addContainerGap().addComponent(this.videopanel, -1, -1, 32767).addContainerGap()));
    this.jTabbedPane1.addTab("Type", new ImageIcon(getClass().getResource("/jemu/ui/ico/monitor.png")), this.jPanel61);
    this.jPanel8.setBorder(BorderFactory.createTitledBorder("Display features"));
    this.jPanel8.setFocusable(false);
    this.mmask.setFont(new Font("Tahoma", 0, 10));
    this.mmask.setText("Mask:");
    this.mmask.setFocusable(false);
    this.mmask.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.mmaskActionPerformed(evt);
          }
        });
    this.filter.setFont(new Font("Tahoma", 0, 10));
    this.filter.setText("Bilinear filter");
    this.filter.setFocusable(false);
    this.filter.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.filterActionPerformed(evt);
          }
        });
    this.buttonGroup1.add(this.mask2);
    this.mask2.setFont(new Font("Tahoma", 0, 10));
    this.mask2.setText("2");
    this.mask2.setFocusable(false);
    this.mask2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.mask2ActionPerformed(evt);
          }
        });
    this.buttonGroup1.add(this.mask1);
    this.mask1.setFont(new Font("Tahoma", 0, 10));
    this.mask1.setText("1");
    this.mask1.setFocusable(false);
    this.mask1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.mask1ActionPerformed(evt);
          }
        });
    this.superPal.setFont(new Font("Tahoma", 0, 10));
    this.superPal.setText("Blur");
    this.superPal.setFocusable(false);
    this.superPal.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.superPalActionPerformed(evt);
          }
        });
    this.frameskip.setFont(new Font("Tahoma", 0, 10));
    this.frameskip.setText("Frameskip");
    this.frameskip.setFocusPainted(false);
    this.frameskip.setFocusable(false);
    this.frameskip.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.frameskipActionPerformed(evt);
          }
        });
    this.filterChooser.setModel(new DefaultComboBoxModel<>(new String[] { "None", "RGB 2x", "RGB 2x B", "AdvMame", "Eagle", "AdvMame Sm", "Eagle Sm", "Embossed" }));
    level.setMajorTickSpacing(10);
    level.setMaximum(40);
    level.setMinimum(10);
    level.setMinorTickSpacing(2);
    level.setPaintTicks(true);
    level.setSnapToTicks(true);
    level.setValue(20);
    level.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent evt) {
            Desktop.this.levelStateChanged(evt);
          }
        });
    GroupLayout jPanel8Layout = new GroupLayout(this.jPanel8);
    this.jPanel8.setLayout(jPanel8Layout);
    jPanel8Layout.setHorizontalGroup(jPanel8Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel8Layout.createSequentialGroup().addGroup(jPanel8Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel8Layout.createSequentialGroup().addGap(4, 4, 4).addComponent(this.filterChooser, -2, 90, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel8Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel8Layout.createSequentialGroup().addComponent(this.mmask).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.mask1).addGap(4, 4, 4).addComponent(this.mask2)).addGroup(jPanel8Layout.createSequentialGroup().addComponent(this.filter).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.superPal).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.frameskip)))).addComponent(level, -2, 90, -2)).addContainerGap(-1, 32767)));
    jPanel8Layout.setVerticalGroup(jPanel8Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel8Layout.createSequentialGroup().addGap(8, 8, 8).addGroup(jPanel8Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.filterChooser, -2, -1, -2).addComponent(this.mmask).addComponent(this.mask1).addComponent(this.mask2)).addGap(5, 5, 5).addGroup(jPanel8Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel8Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.superPal).addComponent(this.filter).addComponent(this.frameskip)).addComponent(level, GroupLayout.Alignment.TRAILING, -2, 20, -2))));
    this.jPanel7.setBorder(BorderFactory.createTitledBorder("Screen"));
    this.jPanel7.setFocusable(false);
    this.jPanel7.setMaximumSize(new Dimension(400, 400));
    this.jPanel7.setPreferredSize(new Dimension(251, 200));
    this.jSlider1.setMajorTickSpacing(32);
    this.jSlider1.setMaximum(255);
    this.jSlider1.setMinimum(-255);
    this.jSlider1.setMinorTickSpacing(32);
    this.jSlider1.setOrientation(1);
    this.jSlider1.setPaintTicks(true);
    this.jSlider1.setFocusable(false);
    this.jSlider1.setInverted(true);
    this.jSlider1.setPreferredSize(new Dimension(24, 122));
    this.jSlider1.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent evt) {
            Desktop.this.jSlider1StateChanged(evt);
          }
        });
    this.jCheckBox12.setText("Enable");
    this.jCheckBox12.setFocusable(false);
    this.jCheckBox12.setHorizontalAlignment(0);
    this.jCheckBox12.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox12ActionPerformed(evt);
          }
        });
    this.jLabel79.setHorizontalAlignment(0);
    this.jLabel79.setText("R  G  B");
    this.jLabel79.setFocusable(false);
    this.bright.setText("0");
    this.bright.setFocusable(false);
    this.jLabel78.setText("Bright");
    this.jLabel78.setFocusable(false);
    this.jPanel59.setBorder(BorderFactory.createEtchedBorder());
    red.setMajorTickSpacing(5);
    red.setMaximum(255);
    red.setMinimum(-255);
    red.setMinorTickSpacing(5);
    red.setOrientation(1);
    red.setValue(0);
    red.setFocusable(false);
    red.setPreferredSize(new Dimension(10, 140));
    this.jPanel59.add(red);
    green.setMajorTickSpacing(5);
    green.setMaximum(255);
    green.setMinimum(-255);
    green.setMinorTickSpacing(5);
    green.setOrientation(1);
    green.setValue(0);
    green.setFocusable(false);
    green.setPreferredSize(new Dimension(10, 140));
    this.jPanel59.add(green);
    blue.setMajorTickSpacing(5);
    blue.setMaximum(255);
    blue.setMinimum(-255);
    blue.setMinorTickSpacing(5);
    blue.setOrientation(1);
    blue.setValue(0);
    blue.setFocusable(false);
    blue.setPreferredSize(new Dimension(10, 140));
    this.jPanel59.add(blue);
    this.jLabel3.setText("VHold");
    this.jLabel3.setFocusable(false);
    this.jSlider2.setMajorTickSpacing(5);
    this.jSlider2.setMaximum(70);
    this.jSlider2.setMinimum(-60);
    this.jSlider2.setOrientation(1);
    this.jSlider2.setPaintTicks(true);
    this.jSlider2.setSnapToTicks(true);
    this.jSlider2.setFocusable(false);
    this.jSlider2.setPreferredSize(new Dimension(24, 122));
    this.jSlider2.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent evt) {
            Desktop.this.jSlider2StateChanged(evt);
          }
        });
    GroupLayout jPanel7Layout = new GroupLayout(this.jPanel7);
    this.jPanel7.setLayout(jPanel7Layout);
    jPanel7Layout.setHorizontalGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel7Layout.createSequentialGroup().addContainerGap().addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel3, -1, 40, 32767).addComponent(this.jSlider2, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel7Layout.createSequentialGroup().addComponent(this.jLabel78).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel59, -2, -1, -2).addComponent(this.bright, -2, 30, -2).addGroup(jPanel7Layout.createSequentialGroup().addGap(6, 6, 6).addComponent(this.jLabel79)))).addGroup(jPanel7Layout.createSequentialGroup().addComponent(this.jSlider1, -2, 24, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jCheckBox12))).addContainerGap(-1, 32767)));
    jPanel7Layout.setVerticalGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup().addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(jPanel7Layout.createSequentialGroup().addComponent(this.jPanel59, -2, 128, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel79, -2, 14, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.jCheckBox12)).addGroup(GroupLayout.Alignment.LEADING, jPanel7Layout.createSequentialGroup().addComponent(this.jSlider1, -2, 185, -2).addGap(0, 30, 32767)).addComponent(this.jSlider2, GroupLayout.Alignment.LEADING, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel78).addComponent(this.bright).addComponent(this.jLabel3)).addContainerGap()));
    this.jPanel60.setBorder(BorderFactory.createTitledBorder("Palfilter"));
    this.pal.setText("PAL");
    this.pal.setFocusPainted(false);
    this.pal.setFocusable(false);
    this.pal.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.palActionPerformed(evt);
          }
        });
    this.pal1.setText("<>");
    this.pal1.setFocusPainted(false);
    this.pal1.setFocusable(false);
    this.pal1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.pal1ActionPerformed(evt);
          }
        });
    this.palvalue.setMaximum(3);
    this.palvalue.setMinorTickSpacing(1);
    this.palvalue.setPaintTicks(true);
    this.palvalue.setSnapToTicks(true);
    this.palvalue.setValue(1);
    this.palvalue.setFocusable(false);
    this.palvalue.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent evt) {
            Desktop.this.palvalueStateChanged(evt);
          }
        });
    this.palvalue1.setMaximum(124);
    this.palvalue1.setMinimum(14);
    this.palvalue1.setMinorTickSpacing(11);
    this.palvalue1.setPaintTicks(true);
    this.palvalue1.setValue(124);
    this.palvalue1.setFocusable(false);
    this.palvalue1.setInverted(true);
    this.palvalue1.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent evt) {
            Desktop.this.palvalue1StateChanged(evt);
          }
        });
    this.jLabel2.setText("direction:");
    this.jLabel7.setText("Strength:");
    this.jLabel17.setText("Fault:");
    GroupLayout jPanel60Layout = new GroupLayout(this.jPanel60);
    this.jPanel60.setLayout(jPanel60Layout);
    jPanel60Layout.setHorizontalGroup(jPanel60Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel60Layout.createSequentialGroup().addContainerGap().addGroup(jPanel60Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(jPanel60Layout.createSequentialGroup().addComponent(this.pal).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel2).addGap(2, 2, 2).addComponent(this.pal1)).addGroup(jPanel60Layout.createSequentialGroup().addGroup(jPanel60Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel7, -1, -1, 32767).addComponent(this.jLabel17, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel60Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.palvalue1, -2, 0, 32767).addComponent(this.palvalue, -2, 0, 32767)))).addContainerGap(164, 32767)));
    jPanel60Layout.setVerticalGroup(jPanel60Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel60Layout.createSequentialGroup().addGroup(jPanel60Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.pal, -2, 20, -2).addComponent(this.jLabel2).addComponent(this.pal1, -2, 20, -2)).addGap(9, 9, 9).addGroup(jPanel60Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.palvalue, GroupLayout.Alignment.LEADING, -2, 30, -2).addComponent(this.jLabel7, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel60Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.palvalue1, -2, 30, -2).addComponent(this.jLabel17, -1, -1, 32767))));
    this.jPanel32.setBorder(BorderFactory.createTitledBorder("3D Display"));
    this.jCheckBox16.setFont(new Font("Tahoma", 0, 10));
    this.jCheckBox16.setText("3D!");
    this.jCheckBox16.setFocusable(false);
    this.jCheckBox16.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox16ActionPerformed(evt);
          }
        });
    this.accelerate.setFont(new Font("Tahoma", 0, 10));
    this.accelerate.setText("Accelerated");
    this.accelerate.setFocusable(false);
    this.accelerate.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.accelerateActionPerformed(evt);
          }
        });
    this.jCheckBox17.setFont(new Font("Tahoma", 0, 10));
    this.jCheckBox17.setText("Smaller Texture (1024x512)");
    this.jCheckBox17.setFocusable(false);
    this.jCheckBox17.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox17ActionPerformed(evt);
          }
        });
    GroupLayout jPanel32Layout = new GroupLayout(this.jPanel32);
    this.jPanel32.setLayout(jPanel32Layout);
    jPanel32Layout.setHorizontalGroup(jPanel32Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel32Layout.createSequentialGroup().addContainerGap().addGroup(jPanel32Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel32Layout.createSequentialGroup().addComponent(this.jCheckBox16).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.accelerate)).addComponent(this.jCheckBox17)).addContainerGap(-1, 32767)));
    jPanel32Layout.setVerticalGroup(jPanel32Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel32Layout.createSequentialGroup().addContainerGap().addGroup(jPanel32Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jCheckBox16).addComponent(this.accelerate)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jCheckBox17).addContainerGap(-1, 32767)));
    GroupLayout jPanel62Layout = new GroupLayout(this.jPanel62);
    this.jPanel62.setLayout(jPanel62Layout);
    jPanel62Layout.setHorizontalGroup(jPanel62Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel62Layout.createSequentialGroup().addContainerGap().addGroup(jPanel62Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel8, -1, -1, 32767).addGroup(jPanel62Layout.createSequentialGroup().addComponent(this.jPanel7, -2, 167, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel62Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel60, -1, -1, 32767).addComponent(this.jPanel32, -1, -1, 32767)))).addContainerGap()));
    jPanel62Layout.setVerticalGroup(jPanel62Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel62Layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel8, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel62Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel62Layout.createSequentialGroup().addComponent(this.jPanel60, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel32, -1, -1, 32767)).addComponent(this.jPanel7, -1, 269, 32767)).addContainerGap()));
    this.jTabbedPane1.addTab("Features", new ImageIcon(getClass().getResource("/jemu/ui/ico/gfx.png")), this.jPanel62);
    this.jPanel66.setBorder(BorderFactory.createTitledBorder("User defined palette"));
    pan1.setColumns(2);
    pan1.setFont(new Font("Monospaced", 0, 14));
    pan1.setBorder(new SoftBevelBorder(1));
    pan1.setCursor(new Cursor(12));
    pan1.setFocusable(false);
    pan1.setMaximumSize(new Dimension(28, 28));
    pan1.setMinimumSize(new Dimension(28, 28));
    pan1.setPreferredSize(new Dimension(28, 28));
    pan1.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan2.setColumns(2);
    pan2.setFont(new Font("Monospaced", 0, 14));
    pan2.setBorder(new SoftBevelBorder(0));
    pan2.setCursor(new Cursor(12));
    pan2.setFocusable(false);
    pan2.setMaximumSize(new Dimension(28, 28));
    pan2.setMinimumSize(new Dimension(28, 28));
    pan2.setPreferredSize(new Dimension(28, 28));
    pan2.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan3.setColumns(2);
    pan3.setFont(new Font("Monospaced", 0, 14));
    pan3.setBorder(new SoftBevelBorder(0));
    pan3.setCursor(new Cursor(12));
    pan3.setFocusable(false);
    pan3.setMaximumSize(new Dimension(28, 28));
    pan3.setMinimumSize(new Dimension(28, 28));
    pan3.setPreferredSize(new Dimension(28, 28));
    pan3.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan4.setColumns(2);
    pan4.setFont(new Font("Monospaced", 0, 14));
    pan4.setBorder(new SoftBevelBorder(0));
    pan4.setCursor(new Cursor(12));
    pan4.setFocusable(false);
    pan4.setMaximumSize(new Dimension(28, 28));
    pan4.setMinimumSize(new Dimension(28, 28));
    pan4.setPreferredSize(new Dimension(28, 28));
    pan4.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan5.setColumns(2);
    pan5.setFont(new Font("Monospaced", 0, 14));
    pan5.setBorder(new SoftBevelBorder(0));
    pan5.setCursor(new Cursor(12));
    pan5.setFocusable(false);
    pan5.setMaximumSize(new Dimension(28, 28));
    pan5.setMinimumSize(new Dimension(28, 28));
    pan5.setPreferredSize(new Dimension(28, 28));
    pan5.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan6.setColumns(2);
    pan6.setFont(new Font("Monospaced", 0, 14));
    pan6.setBorder(new SoftBevelBorder(0));
    pan6.setCursor(new Cursor(12));
    pan6.setFocusable(false);
    pan6.setMaximumSize(new Dimension(28, 28));
    pan6.setMinimumSize(new Dimension(28, 28));
    pan6.setPreferredSize(new Dimension(28, 28));
    pan6.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan7.setColumns(2);
    pan7.setFont(new Font("Monospaced", 0, 14));
    pan7.setBorder(new SoftBevelBorder(0));
    pan7.setCursor(new Cursor(12));
    pan7.setFocusable(false);
    pan7.setMaximumSize(new Dimension(28, 28));
    pan7.setMinimumSize(new Dimension(28, 28));
    pan7.setPreferredSize(new Dimension(28, 28));
    pan7.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan8.setColumns(2);
    pan8.setFont(new Font("Monospaced", 0, 14));
    pan8.setBorder(new SoftBevelBorder(0));
    pan8.setCursor(new Cursor(12));
    pan8.setFocusable(false);
    pan8.setMaximumSize(new Dimension(28, 28));
    pan8.setMinimumSize(new Dimension(28, 28));
    pan8.setPreferredSize(new Dimension(28, 28));
    pan8.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan9.setColumns(2);
    pan9.setFont(new Font("Monospaced", 0, 14));
    pan9.setBorder(new SoftBevelBorder(0));
    pan9.setCursor(new Cursor(12));
    pan9.setFocusable(false);
    pan9.setMaximumSize(new Dimension(28, 28));
    pan9.setMinimumSize(new Dimension(28, 28));
    pan9.setPreferredSize(new Dimension(28, 28));
    pan9.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan10.setColumns(2);
    pan10.setFont(new Font("Monospaced", 0, 14));
    pan10.setBorder(new SoftBevelBorder(0));
    pan10.setCursor(new Cursor(12));
    pan10.setFocusable(false);
    pan10.setMaximumSize(new Dimension(28, 28));
    pan10.setMinimumSize(new Dimension(28, 28));
    pan10.setPreferredSize(new Dimension(28, 28));
    pan10.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan11.setColumns(2);
    pan11.setFont(new Font("Monospaced", 0, 14));
    pan11.setBorder(new SoftBevelBorder(0));
    pan11.setCursor(new Cursor(12));
    pan11.setFocusable(false);
    pan11.setMaximumSize(new Dimension(28, 28));
    pan11.setMinimumSize(new Dimension(28, 28));
    pan11.setPreferredSize(new Dimension(28, 28));
    pan11.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan12.setColumns(2);
    pan12.setFont(new Font("Monospaced", 0, 14));
    pan12.setBorder(new SoftBevelBorder(0));
    pan12.setCursor(new Cursor(12));
    pan12.setFocusable(false);
    pan12.setMaximumSize(new Dimension(28, 28));
    pan12.setMinimumSize(new Dimension(28, 28));
    pan12.setPreferredSize(new Dimension(28, 28));
    pan12.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan13.setColumns(2);
    pan13.setFont(new Font("Monospaced", 0, 14));
    pan13.setBorder(new SoftBevelBorder(0));
    pan13.setCursor(new Cursor(12));
    pan13.setFocusable(false);
    pan13.setMaximumSize(new Dimension(28, 28));
    pan13.setMinimumSize(new Dimension(28, 28));
    pan13.setPreferredSize(new Dimension(28, 28));
    pan13.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan14.setColumns(2);
    pan14.setFont(new Font("Monospaced", 0, 14));
    pan14.setBorder(new SoftBevelBorder(0));
    pan14.setCursor(new Cursor(12));
    pan14.setFocusable(false);
    pan14.setMaximumSize(new Dimension(28, 28));
    pan14.setMinimumSize(new Dimension(28, 28));
    pan14.setPreferredSize(new Dimension(28, 28));
    pan14.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan15.setColumns(2);
    pan15.setFont(new Font("Monospaced", 0, 14));
    pan15.setBorder(new SoftBevelBorder(0));
    pan15.setCursor(new Cursor(12));
    pan15.setFocusable(false);
    pan15.setMaximumSize(new Dimension(28, 28));
    pan15.setMinimumSize(new Dimension(28, 28));
    pan15.setPreferredSize(new Dimension(28, 28));
    pan15.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan16.setColumns(2);
    pan16.setFont(new Font("Monospaced", 0, 14));
    pan16.setBorder(new SoftBevelBorder(0));
    pan16.setCursor(new Cursor(12));
    pan16.setFocusable(false);
    pan16.setMaximumSize(new Dimension(28, 28));
    pan16.setMinimumSize(new Dimension(28, 28));
    pan16.setPreferredSize(new Dimension(28, 28));
    pan16.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan17.setColumns(2);
    pan17.setFont(new Font("Monospaced", 0, 14));
    pan17.setBorder(new SoftBevelBorder(0));
    pan17.setCursor(new Cursor(12));
    pan17.setFocusable(false);
    pan17.setMaximumSize(new Dimension(28, 28));
    pan17.setMinimumSize(new Dimension(28, 28));
    pan17.setPreferredSize(new Dimension(28, 28));
    pan17.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan18.setColumns(2);
    pan18.setFont(new Font("Monospaced", 0, 14));
    pan18.setBorder(new SoftBevelBorder(0));
    pan18.setCursor(new Cursor(12));
    pan18.setFocusable(false);
    pan18.setMaximumSize(new Dimension(28, 28));
    pan18.setMinimumSize(new Dimension(28, 28));
    pan18.setPreferredSize(new Dimension(28, 28));
    pan18.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan19.setColumns(2);
    pan19.setFont(new Font("Monospaced", 0, 14));
    pan19.setBorder(new SoftBevelBorder(0));
    pan19.setCursor(new Cursor(12));
    pan19.setFocusable(false);
    pan19.setMaximumSize(new Dimension(28, 28));
    pan19.setMinimumSize(new Dimension(28, 28));
    pan19.setPreferredSize(new Dimension(28, 28));
    pan19.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan20.setColumns(2);
    pan20.setFont(new Font("Monospaced", 0, 14));
    pan20.setBorder(new SoftBevelBorder(0));
    pan20.setCursor(new Cursor(12));
    pan20.setFocusable(false);
    pan20.setMaximumSize(new Dimension(28, 28));
    pan20.setMinimumSize(new Dimension(28, 28));
    pan20.setPreferredSize(new Dimension(28, 28));
    pan20.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan21.setColumns(2);
    pan21.setFont(new Font("Monospaced", 0, 14));
    pan21.setBorder(new SoftBevelBorder(0));
    pan21.setCursor(new Cursor(12));
    pan21.setFocusable(false);
    pan21.setMaximumSize(new Dimension(28, 28));
    pan21.setMinimumSize(new Dimension(28, 28));
    pan21.setPreferredSize(new Dimension(28, 28));
    pan21.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan22.setColumns(2);
    pan22.setFont(new Font("Monospaced", 0, 14));
    pan22.setBorder(new SoftBevelBorder(0));
    pan22.setCursor(new Cursor(12));
    pan22.setFocusable(false);
    pan22.setMaximumSize(new Dimension(28, 28));
    pan22.setMinimumSize(new Dimension(28, 28));
    pan22.setPreferredSize(new Dimension(28, 28));
    pan22.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan23.setColumns(2);
    pan23.setFont(new Font("Monospaced", 0, 14));
    pan23.setBorder(new SoftBevelBorder(0));
    pan23.setCursor(new Cursor(12));
    pan23.setFocusable(false);
    pan23.setMaximumSize(new Dimension(28, 28));
    pan23.setMinimumSize(new Dimension(28, 28));
    pan23.setPreferredSize(new Dimension(28, 28));
    pan23.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan24.setColumns(2);
    pan24.setFont(new Font("Monospaced", 0, 14));
    pan24.setBorder(new SoftBevelBorder(0));
    pan24.setCursor(new Cursor(12));
    pan24.setFocusable(false);
    pan24.setMaximumSize(new Dimension(28, 28));
    pan24.setMinimumSize(new Dimension(28, 28));
    pan24.setPreferredSize(new Dimension(28, 28));
    pan24.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan25.setColumns(2);
    pan25.setFont(new Font("Monospaced", 0, 14));
    pan25.setBorder(new SoftBevelBorder(0));
    pan25.setCursor(new Cursor(12));
    pan25.setFocusable(false);
    pan25.setMaximumSize(new Dimension(28, 28));
    pan25.setMinimumSize(new Dimension(28, 28));
    pan25.setPreferredSize(new Dimension(28, 28));
    pan25.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan26.setColumns(2);
    pan26.setFont(new Font("Monospaced", 0, 14));
    pan26.setBorder(new SoftBevelBorder(0));
    pan26.setCursor(new Cursor(12));
    pan26.setFocusable(false);
    pan26.setMaximumSize(new Dimension(28, 28));
    pan26.setMinimumSize(new Dimension(28, 28));
    pan26.setPreferredSize(new Dimension(28, 28));
    pan26.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan27.setColumns(2);
    pan27.setFont(new Font("Monospaced", 0, 14));
    pan27.setBorder(new SoftBevelBorder(0));
    pan27.setCursor(new Cursor(12));
    pan27.setFocusable(false);
    pan27.setMaximumSize(new Dimension(28, 28));
    pan27.setMinimumSize(new Dimension(28, 28));
    pan27.setPreferredSize(new Dimension(28, 28));
    pan27.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan28.setColumns(2);
    pan28.setFont(new Font("Monospaced", 0, 14));
    pan28.setBorder(new SoftBevelBorder(0));
    pan28.setCursor(new Cursor(12));
    pan28.setFocusable(false);
    pan28.setMaximumSize(new Dimension(28, 28));
    pan28.setMinimumSize(new Dimension(28, 28));
    pan28.setPreferredSize(new Dimension(28, 28));
    pan28.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan29.setColumns(2);
    pan29.setFont(new Font("Monospaced", 0, 14));
    pan29.setBorder(new SoftBevelBorder(0));
    pan29.setCursor(new Cursor(12));
    pan29.setFocusable(false);
    pan29.setMaximumSize(new Dimension(28, 28));
    pan29.setMinimumSize(new Dimension(28, 28));
    pan29.setPreferredSize(new Dimension(28, 28));
    pan29.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan30.setColumns(2);
    pan30.setFont(new Font("Monospaced", 0, 14));
    pan30.setBorder(new SoftBevelBorder(0));
    pan30.setCursor(new Cursor(12));
    pan30.setFocusable(false);
    pan30.setMaximumSize(new Dimension(28, 28));
    pan30.setMinimumSize(new Dimension(28, 28));
    pan30.setPreferredSize(new Dimension(28, 28));
    pan30.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan31.setColumns(2);
    pan31.setFont(new Font("Monospaced", 0, 14));
    pan31.setBorder(new SoftBevelBorder(0));
    pan31.setCursor(new Cursor(12));
    pan31.setFocusable(false);
    pan31.setMaximumSize(new Dimension(28, 28));
    pan31.setMinimumSize(new Dimension(28, 28));
    pan31.setPreferredSize(new Dimension(28, 28));
    pan31.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    pan32.setColumns(2);
    pan32.setFont(new Font("Monospaced", 0, 14));
    pan32.setBorder(new SoftBevelBorder(0));
    pan32.setCursor(new Cursor(12));
    pan32.setFocusable(false);
    pan32.setMaximumSize(new Dimension(28, 28));
    pan32.setMinimumSize(new Dimension(28, 28));
    pan32.setPreferredSize(new Dimension(28, 28));
    pan32.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pan2MouseReleased(evt);
          }
        });
    this.jPanel67.setBorder(BorderFactory.createEtchedBorder());
    selpan.setFocusable(false);
    this.jButton48.setText("Reset INKs");
    this.jButton48.setFocusable(false);
    this.jButton48.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton48ActionPerformed(evt);
          }
        });
    GroupLayout jPanel67Layout = new GroupLayout(this.jPanel67);
    this.jPanel67.setLayout(jPanel67Layout);
    jPanel67Layout.setHorizontalGroup(jPanel67Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel67Layout.createSequentialGroup().addContainerGap().addGroup(jPanel67Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(selpan, -1, 99, 32767).addComponent(this.jButton48, -1, -1, 32767)).addContainerGap()));
    jPanel67Layout.setVerticalGroup(jPanel67Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel67Layout.createSequentialGroup().addContainerGap().addComponent(selpan).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton48).addContainerGap()));
    this.jPanel68.setBorder(BorderFactory.createEtchedBorder());
    jSlider3.setMaximum(255);
    jSlider3.setMinorTickSpacing(16);
    jSlider3.setOrientation(1);
    jSlider3.setPaintTicks(true);
    jSlider3.setValue(0);
    jSlider3.setBorder(BorderFactory.createEtchedBorder());
    jSlider3.setFocusable(false);
    jSlider3.setPreferredSize(new Dimension(32, 50));
    jSlider3.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent evt) {
            Desktop.this.jSlider3StateChanged(evt);
          }
        });
    jSlider4.setMaximum(255);
    jSlider4.setMinorTickSpacing(16);
    jSlider4.setOrientation(1);
    jSlider4.setPaintTicks(true);
    jSlider4.setValue(0);
    jSlider4.setBorder(BorderFactory.createEtchedBorder());
    jSlider4.setFocusable(false);
    jSlider4.setPreferredSize(new Dimension(32, 50));
    jSlider4.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent evt) {
            Desktop.this.jSlider4StateChanged(evt);
          }
        });
    jSlider5.setMaximum(255);
    jSlider5.setMinorTickSpacing(16);
    jSlider5.setOrientation(1);
    jSlider5.setPaintTicks(true);
    jSlider5.setValue(0);
    jSlider5.setBorder(BorderFactory.createEtchedBorder());
    jSlider5.setFocusable(false);
    jSlider5.setPreferredSize(new Dimension(32, 50));
    jSlider5.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent evt) {
            Desktop.this.jSlider5StateChanged(evt);
          }
        });
    fieldRed.setColumns(3);
    fieldRed.setText("0");
    fieldRed.setBorder(BorderFactory.createEtchedBorder());
    fieldRed.addKeyListener(new KeyAdapter() {
          public void keyReleased(KeyEvent evt) {
            Desktop.this.fieldRedKeyReleased(evt);
          }
        });
    fieldGreen.setColumns(3);
    fieldGreen.setText("0");
    fieldGreen.setBorder(BorderFactory.createEtchedBorder());
    fieldGreen.addKeyListener(new KeyAdapter() {
          public void keyReleased(KeyEvent evt) {
            Desktop.this.fieldGreenKeyReleased(evt);
          }
        });
    fieldBlue.setColumns(3);
    fieldBlue.setText("0");
    fieldBlue.setBorder(BorderFactory.createEtchedBorder());
    fieldBlue.addKeyListener(new KeyAdapter() {
          public void keyReleased(KeyEvent evt) {
            Desktop.this.fieldBlueKeyReleased(evt);
          }
        });
    rgb.setText("000000");
    rgb.addKeyListener(new KeyAdapter() {
          public void keyReleased(KeyEvent evt) {
            Desktop.this.rgbKeyReleased(evt);
          }
        });
    this.jLabel93.setText("RGB #");
    GroupLayout jPanel68Layout = new GroupLayout(this.jPanel68);
    this.jPanel68.setLayout(jPanel68Layout);
    jPanel68Layout.setHorizontalGroup(jPanel68Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel68Layout.createSequentialGroup().addContainerGap().addGroup(jPanel68Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(jSlider3, -1, -1, 32767).addComponent(fieldRed, -1, 40, 32767).addComponent(this.jLabel93, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel68Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(rgb, GroupLayout.Alignment.TRAILING).addGroup(jPanel68Layout.createSequentialGroup().addGroup(jPanel68Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(jSlider4, -1, -1, 32767).addComponent(fieldGreen, -1, 40, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel68Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(jSlider5, -1, -1, 32767).addComponent(fieldBlue, -1, 40, 32767)).addGap(0, 0, 32767))).addContainerGap()));
    jPanel68Layout.setVerticalGroup(jPanel68Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel68Layout.createSequentialGroup().addContainerGap().addGroup(jPanel68Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(jSlider5, -1, 90, 32767).addComponent(jSlider3, -1, -1, 32767).addComponent(jSlider4, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel68Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(fieldRed, -2, -1, -2).addComponent(fieldGreen, -2, -1, -2).addComponent(fieldBlue, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel68Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(rgb, -2, -1, -2).addComponent(this.jLabel93)).addContainerGap(-1, 32767)));
    GroupLayout jPanel66Layout = new GroupLayout(this.jPanel66);
    this.jPanel66.setLayout(jPanel66Layout);
    jPanel66Layout.setHorizontalGroup(jPanel66Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel66Layout.createSequentialGroup().addContainerGap().addGroup(jPanel66Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(GroupLayout.Alignment.LEADING, jPanel66Layout.createSequentialGroup().addComponent(this.jPanel67, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel68, -2, -1, -2)).addGroup(GroupLayout.Alignment.LEADING, jPanel66Layout.createSequentialGroup().addComponent(pan1, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan2, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan3, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan4, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan5, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan6, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan7, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan8, -2, 28, -2)).addGroup(GroupLayout.Alignment.LEADING, jPanel66Layout.createSequentialGroup().addComponent(pan9, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan10, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan11, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan12, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan13, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan14, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan15, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan16, -2, 28, -2)).addGroup(GroupLayout.Alignment.LEADING, jPanel66Layout.createSequentialGroup().addComponent(pan17, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan18, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan19, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan20, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan21, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan22, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan23, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan24, -2, 28, -2)).addGroup(GroupLayout.Alignment.LEADING, jPanel66Layout.createSequentialGroup().addComponent(pan25, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan26, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan27, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan28, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan29, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan30, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan31, -2, 28, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(pan32, -2, 28, -2))).addContainerGap(183, 32767)));
    jPanel66Layout.setVerticalGroup(jPanel66Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel66Layout.createSequentialGroup().addGroup(jPanel66Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(pan1, -2, 28, -2).addComponent(pan2, -2, 28, -2).addComponent(pan3, -2, 28, -2).addComponent(pan4, -2, 28, -2).addComponent(pan5, -2, 28, -2).addComponent(pan6, -2, 28, -2).addComponent(pan7, -2, 28, -2).addComponent(pan8, -2, 28, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel66Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(pan9, -2, 28, -2).addComponent(pan10, -2, 28, -2).addComponent(pan11, -2, 28, -2).addComponent(pan12, -2, 28, -2).addComponent(pan13, -2, 28, -2).addComponent(pan14, -2, 28, -2).addComponent(pan15, -2, 28, -2).addComponent(pan16, -2, 28, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel66Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(pan17, -2, 28, -2).addComponent(pan18, -2, 28, -2).addComponent(pan19, -2, 28, -2).addComponent(pan20, -2, 28, -2).addComponent(pan21, -2, 28, -2).addComponent(pan22, -2, 28, -2).addComponent(pan23, -2, 28, -2).addComponent(pan24, -2, 28, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel66Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(pan25, -2, 28, -2).addComponent(pan26, -2, 28, -2).addComponent(pan27, -2, 28, -2).addComponent(pan28, -2, 28, -2).addComponent(pan29, -2, 28, -2).addComponent(pan30, -2, 28, -2).addComponent(pan31, -2, 28, -2).addComponent(pan32, -2, 28, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel66Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jPanel68, -1, -1, 32767).addComponent(this.jPanel67, -1, -1, 32767)).addGap(0, 28, 32767)));
    GroupLayout jPanel65Layout = new GroupLayout(this.jPanel65);
    this.jPanel65.setLayout(jPanel65Layout);
    jPanel65Layout.setHorizontalGroup(jPanel65Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel65Layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel66, -1, -1, 32767).addContainerGap()));
    jPanel65Layout.setVerticalGroup(jPanel65Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel65Layout.createSequentialGroup().addContainerGap().addComponent(this.jPanel66, -1, -1, 32767).addContainerGap()));
    this.jTabbedPane1.addTab("Palette", new ImageIcon(getClass().getResource("/jemu/ui/icon/colpal.gif")), this.jPanel65);
    this.jPanel2.add(this.jTabbedPane1, "Center");
    OptionPane.addTab("Video", new ImageIcon(getClass().getResource("/jemu/ui/ico/gfx.png")), this.jPanel2);
    this.jPanel1.setMinimumSize(new Dimension(490, 360));
    this.jPanel1.setPreferredSize(new Dimension(490, 360));
    this.jPanel5.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel5.setFocusable(false);
    this.jAYGroup.add(this.jAY4);
    this.jAY4.setFont(new Font("Tahoma", 0, 8));
    this.jAY4.setText("User");
    this.jAY4.setFocusable(false);
    this.jAY4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jAY4ActionPerformed(evt);
          }
        });
    this.jAYGroup.add(this.jAY2);
    this.jAY2.setFont(new Font("Tahoma", 0, 9));
    this.jAY2.setText("V-Soft");
    this.jAY2.setFocusable(false);
    this.jAY2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jAY2ActionPerformed(evt);
          }
        });
    this.jAYGroup.add(this.jAY1);
    this.jAY1.setFont(new Font("Tahoma", 0, 9));
    this.jAY1.setText("Hacker Kay");
    this.jAY1.setFocusable(false);
    this.jAY1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jAY1ActionPerformed(evt);
          }
        });
    this.jAYGroup.add(this.jAY3);
    this.jAY3.setFont(new Font("Tahoma", 0, 9));
    this.jAY3.setText("CPCe95");
    this.jAY3.setFocusable(false);
    this.jAY3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jAY3ActionPerformed(evt);
          }
        });
    this.jAYE.setText("AY-Effect");
    this.jAYE.setFocusable(false);
    this.jAYE.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jAYEActionPerformed(evt);
          }
        });
    this.jAYE1.setText("Wide");
    this.jAYE1.setFocusable(false);
    this.jAYE1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jAYE1ActionPerformed(evt);
          }
        });
    this.drivenoises.setText("Drives");
    this.drivenoises.setFocusable(false);
    this.drivenoises.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.drivenoisesActionPerformed(evt);
          }
        });
    this.keynoise.setText("Keyboard");
    this.keynoise.setFocusable(false);
    this.keynoise.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.keynoiseActionPerformed(evt);
          }
        });
    this.mute.setText("Mute");
    this.mute.setFocusable(false);
    this.mute.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.muteActionPerformed(evt);
          }
        });
    this.buffersize.setMaximum(3100);
    this.buffersize.setMinimum(2);
    this.buffersize.setValue(1600);
    this.buffersize.setFocusable(false);
    this.buffersize.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent evt) {
            Desktop.this.buffersizeStateChanged(evt);
          }
        });
    GroupLayout audiodisplayLayout = new GroupLayout(this.audiodisplay);
    this.audiodisplay.setLayout(audiodisplayLayout);
    audiodisplayLayout.setHorizontalGroup(audiodisplayLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 322, 32767));
    audiodisplayLayout.setVerticalGroup(audiodisplayLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 100, 32767));
    this.jAYGroup.add(this.jAY5);
    this.jAY5.setFont(new Font("Tahoma", 0, 9));
    this.jAY5.setText("Lion");
    this.jAY5.setFocusable(false);
    this.jAY5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jAY5ActionPerformed(evt);
          }
        });
    this.jAYGroup.add(this.jAY6);
    this.jAY6.setFont(new Font("Tahoma", 0, 8));
    this.jAY6.setText("K-II");
    this.jAY6.setFocusable(false);
    this.jAY6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jAY6ActionPerformed(evt);
          }
        });
    this.lock.setSelected(true);
    this.lock.setText("Lock");
    this.lock.setFocusable(false);
    this.lock.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.lockActionPerformed(evt);
          }
        });
    this.jComboBox2.setModel(new DefaultComboBoxModel<>(new String[] { "1", "2" }));
    this.jComboBox2.setFocusable(false);
    this.jComboBox2.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent evt) {
            Desktop.this.jComboBox2ItemStateChanged(evt);
          }
        });
    this.chipnoise.setText("Chips");
    this.chipnoise.setFocusable(false);
    this.chipnoise.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.chipnoiseActionPerformed(evt);
          }
        });
    GroupLayout jPanel5Layout = new GroupLayout(this.jPanel5);
    this.jPanel5.setLayout(jPanel5Layout);
    jPanel5Layout.setHorizontalGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel5Layout.createSequentialGroup().addContainerGap().addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel5Layout.createSequentialGroup().addComponent(this.audiodisplay, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup().addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.lock).addComponent(this.jAY6)).addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel5Layout.createSequentialGroup().addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 15, 32767).addComponent(this.mute).addGap(20, 20, 20)).addGroup(jPanel5Layout.createSequentialGroup().addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jAY4).addContainerGap(-1, 32767)))).addGroup(GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup().addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.jAY5, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.jAY3, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.jAY2, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.jAY1, GroupLayout.Alignment.LEADING, -1, -1, 32767)).addGap(0, 0, 32767)))).addGroup(jPanel5Layout.createSequentialGroup().addComponent(this.jAYE).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jAYE1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.buffersize, -2, 44, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.drivenoises).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jComboBox2, -2, 46, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.keynoise).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.chipnoise).addContainerGap(-1, 32767)))));
    jPanel5Layout.setVerticalGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel5Layout.createSequentialGroup().addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jAYE, -2, 20, -2).addComponent(this.jAYE1, -2, 20, -2).addComponent(this.keynoise, -2, 20, -2).addComponent(this.drivenoises, -2, 20, -2).addComponent(this.jComboBox2, -2, -1, -2).addComponent(this.chipnoise, -2, 20, -2)).addComponent(this.buffersize, -2, -1, -2)).addGap(7, 7, 7).addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel5Layout.createSequentialGroup().addComponent(this.jAY1, -2, 14, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jAY2, -2, 14, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jAY3, -2, 14, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jAY5, -2, 14, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jAY6, -2, 14, -2).addComponent(this.jAY4, -2, 14, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.mute, -1, -1, 32767).addComponent(this.lock, -1, -1, 32767)).addContainerGap()).addGroup(jPanel5Layout.createSequentialGroup().addComponent(this.audiodisplay, -2, -1, -2).addGap(0, 0, 32767)))));
    this.jPanel4.setBorder(BorderFactory.createTitledBorder("VU-Meter / Audioformat"));
    this.jPanel4.setFocusable(false);
    this.audioformat.setModel(new DefaultComboBoxModel<>(new String[] { "49716 Hz", "44100 Hz", "32000 Hz", "22050 Hz", "16000 Hz", "11025 Hz", "8000 Hz", "6000 Hz" }));
    this.audioformat.setFocusable(false);
    this.audioformat.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.audioformatActionPerformed(evt);
          }
        });
    this.formatlabel.setText("Rate:");
    this.formatlabel.setFocusable(false);
    this.jPanel46.setLayout(new GridLayout(1, 0));
    leftvumeter.setMaximum(85);
    leftvumeter.setOrientation(1);
    leftvumeter.setValue(40);
    leftvumeter.setFocusable(false);
    leftvumeter.setMaximumSize(new Dimension(24, 32767));
    leftvumeter.setMinimumSize(new Dimension(24, 10));
    leftvumeter.setName("A");
    leftvumeter.setPreferredSize(new Dimension(24, 150));
    this.jPanel46.add(leftvumeter);
    midvumeter.setMaximum(85);
    midvumeter.setOrientation(1);
    midvumeter.setValue(40);
    midvumeter.setFocusable(false);
    this.jPanel46.add(midvumeter);
    rightvumeter.setMaximum(85);
    rightvumeter.setOrientation(1);
    rightvumeter.setValue(40);
    rightvumeter.setFocusable(false);
    this.jPanel46.add(rightvumeter);
    this.jPanel51.setLayout(new GridLayout(1, 0));
    chanA.setText("A");
    chanA.setFocusPainted(false);
    chanA.setFocusable(false);
    this.jPanel51.add(chanA);
    chanB.setText("B");
    chanB.setFocusPainted(false);
    chanB.setFocusable(false);
    this.jPanel51.add(chanB);
    chanC.setText("C");
    chanC.setFocusPainted(false);
    chanC.setFocusable(false);
    this.jPanel51.add(chanC);
    this.jCheckBox14.setText("CPC Speaker");
    this.jCheckBox14.setFocusPainted(false);
    this.jCheckBox14.setFocusable(false);
    this.jCheckBox14.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox14ActionPerformed(evt);
          }
        });
    this.jCheckBox15.setText("Filter");
    this.jCheckBox15.setFocusPainted(false);
    this.jCheckBox15.setFocusable(false);
    this.jCheckBox15.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox15ActionPerformed(evt);
          }
        });
    this.jComboBox3.setModel(new DefaultComboBoxModel<>(new String[] { "256", "512", "1024", "2048", "4096", "6144" }));
    this.jComboBox3.setSelectedIndex(4);
    this.jComboBox3.setFocusable(false);
    this.jComboBox3.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent evt) {
            Desktop.this.jComboBox3ItemStateChanged(evt);
          }
        });
    this.jLabel92.setText("Buffer:");
    this.pufferl.setFont(new Font("Tahoma", 1, 12));
    this.pufferl.setText("Restart!");
    this.jPanel41.setLayout(new GridLayout(1, 0));
    psg1a.setMaximum(15);
    psg1a.setOrientation(1);
    psg1a.setValue(5);
    psg1a.setFocusable(false);
    psg1a.setMaximumSize(new Dimension(8, 32767));
    psg1a.setMinimumSize(new Dimension(8, 10));
    psg1a.setPreferredSize(new Dimension(8, 146));
    this.jPanel41.add(psg1a);
    psg1b.setMaximum(15);
    psg1b.setOrientation(1);
    psg1b.setValue(5);
    psg1b.setFocusable(false);
    psg1b.setMaximumSize(new Dimension(8, 32767));
    psg1b.setMinimumSize(new Dimension(8, 10));
    psg1b.setPreferredSize(new Dimension(8, 146));
    this.jPanel41.add(psg1b);
    psg1c.setMaximum(15);
    psg1c.setOrientation(1);
    psg1c.setValue(5);
    psg1c.setFocusable(false);
    psg1c.setMaximumSize(new Dimension(8, 32767));
    psg1c.setMinimumSize(new Dimension(8, 10));
    psg1c.setPreferredSize(new Dimension(8, 146));
    this.jPanel41.add(psg1c);
    psg2a.setMaximum(15);
    psg2a.setOrientation(1);
    psg2a.setValue(5);
    psg2a.setFocusable(false);
    psg2a.setMaximumSize(new Dimension(8, 32767));
    psg2a.setMinimumSize(new Dimension(8, 10));
    psg2a.setPreferredSize(new Dimension(8, 146));
    this.jPanel41.add(psg2a);
    psg2b.setMaximum(15);
    psg2b.setOrientation(1);
    psg2b.setValue(5);
    psg2b.setFocusable(false);
    psg2b.setMaximumSize(new Dimension(8, 32767));
    psg2b.setMinimumSize(new Dimension(8, 10));
    psg2b.setPreferredSize(new Dimension(8, 146));
    this.jPanel41.add(psg2b);
    psg2c.setMaximum(15);
    psg2c.setOrientation(1);
    psg2c.setValue(5);
    psg2c.setFocusable(false);
    psg2c.setMaximumSize(new Dimension(8, 32767));
    psg2c.setMinimumSize(new Dimension(8, 10));
    psg2c.setPreferredSize(new Dimension(8, 146));
    this.jPanel41.add(psg2c);
    this.jPanel42.setLayout(new GridLayout(1, 0));
    this.jLabel94.setHorizontalAlignment(0);
    this.jLabel94.setText("PlayCity");
    GroupLayout jPanel4Layout = new GroupLayout(this.jPanel4);
    this.jPanel4.setLayout(jPanel4Layout);
    jPanel4Layout.setHorizontalGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel4Layout.createSequentialGroup().addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel4Layout.createSequentialGroup().addGap(10, 10, 10).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.formatlabel).addGroup(jPanel4Layout.createSequentialGroup().addGap(31, 31, 31).addComponent(this.audioformat, -2, -1, -2)).addGroup(jPanel4Layout.createSequentialGroup().addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.jPanel46, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.jPanel51, GroupLayout.Alignment.LEADING, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jPanel41, -1, 60, 32767).addComponent(this.jLabel94, -1, -1, 32767)))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel42, -2, 24, -2)).addGroup(jPanel4Layout.createSequentialGroup().addContainerGap().addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel4Layout.createSequentialGroup().addComponent(this.jLabel92).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jComboBox3, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.pufferl)).addGroup(jPanel4Layout.createSequentialGroup().addComponent(this.jCheckBox14).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jCheckBox15))))).addContainerGap(-1, 32767)));
    jPanel4Layout.setVerticalGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel4Layout.createSequentialGroup().addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jPanel46, -2, 0, 32767).addComponent(this.jPanel41, -2, 0, 32767).addComponent(this.jPanel42, -1, 37, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel51, -2, -1, -2).addComponent(this.jLabel94)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel4Layout.createSequentialGroup().addGap(3, 3, 3).addComponent(this.formatlabel)).addComponent(this.audioformat, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel92).addComponent(this.jComboBox3, -2, -1, -2).addComponent(this.pufferl)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jCheckBox14, -2, 15, -2).addComponent(this.jCheckBox15, -2, 15, -2)).addContainerGap(-1, 32767)));
    this.Avol.setBorder(BorderFactory.createTitledBorder("AY-Volume"));
    this.Avol.setFocusable(false);
    this.Avol.setLayout(new BorderLayout());
    this.Dvol.setBorder(BorderFactory.createTitledBorder("Digital Volume"));
    this.Dvol.setFocusable(false);
    this.Dvol.setLayout(new BorderLayout());
    GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
    this.jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGap(10, 10, 10).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jPanel5, -1, -1, 32767).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.Avol, -2, 128, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.Dvol, -2, 128, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel4, -2, 205, 32767))).addGap(40, 40, 40)));
    jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jPanel4, -1, -1, 32767).addComponent(this.Dvol, -1, -1, 32767).addComponent(this.Avol, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel5, -2, -1, -2).addContainerGap(36, 32767)));
    OptionPane.addTab("Audio", new ImageIcon(getClass().getResource("/jemu/ui/ico/speaker.png")), this.jPanel1);
    this.jPanel12.setMinimumSize(new Dimension(490, 360));
    this.jPanel12.setPreferredSize(new Dimension(510, 410));
    this.jPanel13.setBorder(BorderFactory.createTitledBorder("Memory"));
    this.memGroup.add(this.mem0);
    this.mem0.setText("64k");
    this.mem0.setFocusable(false);
    this.mem0.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.mem0ActionPerformed(evt);
          }
        });
    this.memGroup.add(this.mem1);
    this.mem1.setText("128k");
    this.mem1.setFocusable(false);
    this.mem1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.mem1ActionPerformed(evt);
          }
        });
    this.memGroup.add(this.mem2);
    this.mem2.setText("64k + 256k Silicon disc");
    this.mem2.setFocusable(false);
    this.mem2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.mem2ActionPerformed(evt);
          }
        });
    this.memGroup.add(this.mem3);
    this.mem3.setText("64k + 256k Ram expansion");
    this.mem3.setFocusable(false);
    this.mem3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.mem3ActionPerformed(evt);
          }
        });
    this.memGroup.add(this.mem5);
    this.mem5.setText("64k + 4mb Ram expansion");
    this.mem5.setFocusable(false);
    this.mem5.setPreferredSize(new Dimension(184, 23));
    this.mem5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.mem5ActionPerformed(evt);
          }
        });
    this.memGroup.add(this.mem4);
    this.mem4.setText("64k + 512k Ram expansion");
    this.mem4.setFocusable(false);
    this.mem4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.mem4ActionPerformed(evt);
          }
        });
    this.jCheckBox3.setText("Ignore ,P protect.");
    this.jCheckBox3.setFocusable(false);
    this.jCheckBox3.setPreferredSize(new Dimension(129, 23));
    this.jCheckBox3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox3ActionPerformed(evt);
          }
        });
    this.jButton30.setText("Clear Config");
    this.jButton30.setFocusable(false);
    this.jButton30.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton30ActionPerformed(evt);
          }
        });
    this.keyclash.setSelected(true);
    this.keyclash.setText("Keyboard Clash");
    this.keyclash.setFocusable(false);
    this.keyclash.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.keyclashActionPerformed(evt);
          }
        });
    this.memorydisplay.setText("Show MEM in ROM");
    this.memorydisplay.setFocusable(false);
    this.memorydisplay.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.memorydisplayActionPerformed(evt);
          }
        });
    GroupLayout jPanel13Layout = new GroupLayout(this.jPanel13);
    this.jPanel13.setLayout(jPanel13Layout);
    jPanel13Layout.setHorizontalGroup(jPanel13Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel13Layout.createSequentialGroup().addContainerGap().addGroup(jPanel13Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel13Layout.createSequentialGroup().addGap(0, 0, 32767).addComponent(this.jButton30)).addGroup(jPanel13Layout.createSequentialGroup().addGroup(jPanel13Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.mem2).addComponent(this.jCheckBox3, -2, -1, -2).addComponent(this.mem3).addComponent(this.mem4).addGroup(jPanel13Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addGroup(GroupLayout.Alignment.LEADING, jPanel13Layout.createSequentialGroup().addComponent(this.mem1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.memorydisplay)).addGroup(GroupLayout.Alignment.LEADING, jPanel13Layout.createSequentialGroup().addComponent(this.mem0).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.keyclash)).addComponent(this.mem5, GroupLayout.Alignment.LEADING, -2, -1, -2))).addGap(0, 0, 32767))).addContainerGap()));
    jPanel13Layout.setVerticalGroup(jPanel13Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel13Layout.createSequentialGroup().addGroup(jPanel13Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.mem0, -2, 23, -2).addComponent(this.keyclash)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel13Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.mem1, -2, 23, -2).addComponent(this.memorydisplay)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.mem2, -2, 23, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.mem3, -2, 23, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.mem4, -2, 23, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.mem5, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jCheckBox3, -2, 20, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton30).addContainerGap(-1, 32767)));
    this.jPanel14.setBorder(BorderFactory.createTitledBorder("Brand name"));
    this.cname.add(this.jRadioButton7);
    this.jRadioButton7.setText("Isp");
    this.jRadioButton7.setFocusable(false);
    this.jRadioButton7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jRadioButton7ActionPerformed(evt);
          }
        });
    this.cname.add(this.jRadioButton8);
    this.jRadioButton8.setText("Triumph");
    this.jRadioButton8.setFocusable(false);
    this.jRadioButton8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jRadioButton8ActionPerformed(evt);
          }
        });
    this.cname.add(this.jRadioButton9);
    this.jRadioButton9.setText("Saisho");
    this.jRadioButton9.setFocusable(false);
    this.jRadioButton9.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jRadioButton9ActionPerformed(evt);
          }
        });
    this.cname.add(this.jRadioButton10);
    this.jRadioButton10.setText("Solavox");
    this.jRadioButton10.setFocusable(false);
    this.jRadioButton10.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jRadioButton10ActionPerformed(evt);
          }
        });
    this.cname.add(this.jRadioButton11);
    this.jRadioButton11.setText("Awa");
    this.jRadioButton11.setFocusable(false);
    this.jRadioButton11.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jRadioButton11ActionPerformed(evt);
          }
        });
    this.cname.add(this.jRadioButton12);
    this.jRadioButton12.setText("Schneider");
    this.jRadioButton12.setFocusable(false);
    this.jRadioButton12.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jRadioButton12ActionPerformed(evt);
          }
        });
    this.cname.add(this.jRadioButton13);
    this.jRadioButton13.setText("Orion");
    this.jRadioButton13.setFocusable(false);
    this.jRadioButton13.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jRadioButton13ActionPerformed(evt);
          }
        });
    this.cname.add(this.jRadioButton14);
    this.jRadioButton14.setText("Amstrad");
    this.jRadioButton14.setFocusable(false);
    this.jRadioButton14.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jRadioButton14ActionPerformed(evt);
          }
        });
    this.jButton4.setText("Set");
    this.jButton4.setFocusable(false);
    this.jButton4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton4ActionPerformed(evt);
          }
        });
    this.jLabel98.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/resources/z80inside.png")));
    GroupLayout jPanel14Layout = new GroupLayout(this.jPanel14);
    this.jPanel14.setLayout(jPanel14Layout);
    jPanel14Layout.setHorizontalGroup(jPanel14Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel14Layout.createSequentialGroup().addContainerGap().addGroup(jPanel14Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jButton4).addGroup(jPanel14Layout.createSequentialGroup().addGroup(jPanel14Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jRadioButton9).addComponent(this.jRadioButton7).addComponent(this.jRadioButton11).addComponent(this.jRadioButton13)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel14Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jRadioButton8).addComponent(this.jRadioButton10).addComponent(this.jRadioButton12).addComponent(this.jRadioButton14)))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel98).addContainerGap(-1, 32767)));
    jPanel14Layout.setVerticalGroup(jPanel14Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel14Layout.createSequentialGroup().addGroup(jPanel14Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel14Layout.createSequentialGroup().addGroup(jPanel14Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jRadioButton7, -2, 20, -2).addComponent(this.jRadioButton10, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel14Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jRadioButton9, -2, 20, -2).addComponent(this.jRadioButton12, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel14Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jRadioButton11, -2, 20, -2).addComponent(this.jRadioButton14, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel14Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jRadioButton13, -2, 20, -2).addComponent(this.jRadioButton8)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton4, -2, 20, -2)).addComponent(this.jLabel98)).addContainerGap(-1, 32767)));
    this.jPanel18.setBorder(BorderFactory.createTitledBorder("Settings"));
    this.jCheckBox2.setText("Realtime clock");
    this.jCheckBox2.setFocusable(false);
    this.jCheckBox2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox2ActionPerformed(evt);
          }
        });
    this.jCheckBox11.setText("Multiface 2");
    this.jCheckBox11.setFocusPainted(false);
    this.jCheckBox11.setFocusable(false);
    this.jCheckBox11.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox11ActionPerformed(evt);
          }
        });
    sync.setText("64 bit OS");
    sync.setFocusPainted(false);
    sync.setFocusable(false);
    sync.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.syncActionPerformed(evt);
          }
        });
    this.jCheckBox20.setText("SF3 Mouse");
    this.jCheckBox20.setFocusable(false);
    this.jCheckBox20.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox20ActionPerformed(evt);
          }
        });
    this.crtc.setText("CRTC Patches");
    this.crtc.setFocusPainted(false);
    this.crtc.setFocusable(false);
    this.crtc.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.crtcActionPerformed(evt);
          }
        });
    GroupLayout jPanel18Layout = new GroupLayout(this.jPanel18);
    this.jPanel18.setLayout(jPanel18Layout);
    jPanel18Layout.setHorizontalGroup(jPanel18Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel18Layout.createSequentialGroup().addContainerGap().addGroup(jPanel18Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel18Layout.createSequentialGroup().addComponent(this.jCheckBox2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.crtc)).addGroup(jPanel18Layout.createSequentialGroup().addComponent(sync).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jCheckBox11).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jCheckBox20))).addContainerGap(117, 32767)));
    jPanel18Layout.setVerticalGroup(jPanel18Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel18Layout.createSequentialGroup().addGroup(jPanel18Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jCheckBox2).addComponent(this.crtc)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel18Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(sync).addComponent(this.jCheckBox11).addComponent(this.jCheckBox20))));
    this.jPanel28.setBorder(BorderFactory.createTitledBorder("Performance"));
    this.jCheckBox6.setText("Low Performance");
    this.jCheckBox6.setFocusable(false);
    this.jCheckBox6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox6ActionPerformed(evt);
          }
        });
    this.fps.setForeground(Color.black);
    this.fps.setMaximum(50);
    this.fps.setFocusable(false);
    this.jLabel29.setText("CPU");
    this.jLabel29.setFocusable(false);
    this.jCheckBox7.setText("Observe Performance");
    this.jCheckBox7.setFocusable(false);
    this.jCheckBox7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox7ActionPerformed(evt);
          }
        });
    this.cpu.setForeground(new Color(0, 0, 255));
    this.cpu.setMaximum(20);
    this.cpu.setValue(1);
    this.cpu.setFocusable(false);
    this.jLabel30.setText("FP/s");
    this.jLabel30.setFocusable(false);
    this.jSeparator2.setOrientation(1);
    jCheckBox8.setText("Turbo");
    jCheckBox8.setFocusable(false);
    jCheckBox8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox8ActionPerformed(evt);
          }
        });
    this.memoryBar.setFont(new Font("Tahoma", 0, 10));
    this.memoryBar.setFocusable(false);
    this.memoryBar.setStringPainted(true);
    this.jLabel67.setText("Mem");
    this.jLabel67.setFocusable(false);
    this.jButton2.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/trashcan.png")));
    this.jButton2.setBorder((Border)null);
    this.jButton2.setBorderPainted(false);
    this.jButton2.setFocusable(false);
    this.jButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton2ActionPerformed(evt);
          }
        });
    jCheckBox19.setText("Z80 Turbo");
    jCheckBox19.setFocusable(false);
    jCheckBox19.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox19ActionPerformed(evt);
          }
        });
    GroupLayout jPanel28Layout = new GroupLayout(this.jPanel28);
    this.jPanel28.setLayout(jPanel28Layout);
    jPanel28Layout.setHorizontalGroup(jPanel28Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel28Layout.createSequentialGroup().addGroup(jPanel28Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel28Layout.createSequentialGroup().addContainerGap().addGroup(jPanel28Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel28Layout.createSequentialGroup().addComponent(this.jLabel30, -2, 30, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.fps, -2, 90, -2).addGap(18, 18, 18).addComponent(jCheckBox19).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jLabel67).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.memoryBar, -1, -1, 32767).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton2)).addGroup(jPanel28Layout.createSequentialGroup().addComponent(this.jLabel29, -2, 30, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.cpu, -1, -1, 32767)))).addGroup(jPanel28Layout.createSequentialGroup().addGap(61, 61, 61).addComponent(this.jSeparator2, -2, 20, -2).addGap(27, 27, 27).addComponent(jCheckBox8).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jCheckBox7).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jCheckBox6).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jSeparator1, -2, -1, -2).addGap(0, 0, 32767))).addContainerGap()));
    jPanel28Layout.setVerticalGroup(jPanel28Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel28Layout.createSequentialGroup().addGap(4, 4, 4).addGroup(jPanel28Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jSeparator1, -2, -1, -2).addComponent(this.jSeparator2, -2, 20, -2).addGroup(jPanel28Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(jCheckBox8, -2, 20, -2).addComponent(this.jCheckBox7, -2, 20, -2).addComponent(this.jCheckBox6, -2, 20, -2))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel28Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.cpu, -2, -1, -2).addComponent(this.jLabel29)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel28Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel30, -2, 20, -2).addGroup(jPanel28Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel67, -2, 20, -2).addComponent(jCheckBox19, -2, 20, -2).addComponent(this.memoryBar, -2, 20, -2)).addComponent(this.jButton2).addComponent(this.fps, -2, 20, -2)).addContainerGap(15, 32767)));
    GroupLayout jPanel12Layout = new GroupLayout(this.jPanel12);
    this.jPanel12.setLayout(jPanel12Layout);
    jPanel12Layout.setHorizontalGroup(jPanel12Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel12Layout.createSequentialGroup().addGap(10, 10, 10).addGroup(jPanel12Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel28, -1, -1, 32767).addGroup(jPanel12Layout.createSequentialGroup().addComponent(this.jPanel13, -2, 210, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel12Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel18, -1, -1, 32767).addComponent(this.jPanel14, -1, -1, 32767)))).addContainerGap()));
    jPanel12Layout.setVerticalGroup(jPanel12Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel12Layout.createSequentialGroup().addGap(10, 10, 10).addGroup(jPanel12Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(jPanel12Layout.createSequentialGroup().addComponent(this.jPanel14, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel18, -2, -1, -2)).addComponent(this.jPanel13, -2, 0, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel28, -2, -1, -2).addContainerGap()));
    OptionPane.addTab("System", new ImageIcon(getClass().getResource("/jemu/ui/ico/chip.png")), this.jPanel12);
    this.jPanel15.setMinimumSize(new Dimension(490, 360));
    this.jPanel15.setPreferredSize(new Dimension(490, 360));
    this.jPanel15.setRequestFocusEnabled(false);
    this.jPanel16.setBorder(BorderFactory.createTitledBorder("Upper ROMs"));
    this.up0.setFocusable(false);
    this.up1.setFocusable(false);
    this.up2.setFocusable(false);
    this.up3.setFocusable(false);
    this.up4.setFocusable(false);
    this.up5.setFocusable(false);
    this.up6.setFocusable(false);
    this.up7.setFocusable(false);
    this.up8.setFocusable(false);
    this.up9.setFocusable(false);
    this.up10.setFocusable(false);
    this.up11.setFocusable(false);
    this.up12.setFocusable(false);
    this.up13.setFocusable(false);
    this.up14.setFocusable(false);
    this.up15.setFocusable(false);
    this.label1.setText("01");
    this.label3.setText("03");
    this.label4.setText("02");
    this.label5.setText("05");
    this.label6.setText("04");
    this.label7.setText("07");
    this.label8.setText("06");
    this.label9.setText("08");
    this.label10.setText("09");
    this.label11.setText("0A");
    this.label12.setText("0B");
    this.label13.setText("0C");
    this.label14.setText("0D");
    this.label15.setText("0E");
    this.label16.setText("0F");
    this.label17.setText("00");
    this.jCheckBox1.setText("Disable all ROMs");
    this.jCheckBox1.setFocusable(false);
    this.jCheckBox1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox1ActionPerformed(evt);
          }
        });
    this.jCheckBox5.setText("JavaCPC  ROM");
    this.jCheckBox5.setFocusable(false);
    this.jCheckBox5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox5ActionPerformed(evt);
          }
        });
    this.jButton6.setText("Info");
    this.jButton6.setFocusable(false);
    this.jButton6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton6ActionPerformed(evt);
          }
        });
    this.selU1.setText("...");
    this.selU1.setFocusable(false);
    this.selU1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU1ActionPerformed(evt);
          }
        });
    this.selU2.setText("...");
    this.selU2.setFocusable(false);
    this.selU2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU2ActionPerformed(evt);
          }
        });
    this.selU3.setText("...");
    this.selU3.setFocusable(false);
    this.selU3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU3ActionPerformed(evt);
          }
        });
    this.selU4.setText("...");
    this.selU4.setFocusable(false);
    this.selU4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU4ActionPerformed(evt);
          }
        });
    this.selU5.setText("...");
    this.selU5.setFocusable(false);
    this.selU5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU5ActionPerformed(evt);
          }
        });
    this.selU6.setText("...");
    this.selU6.setFocusable(false);
    this.selU6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU6ActionPerformed(evt);
          }
        });
    this.selU7.setText("...");
    this.selU7.setFocusable(false);
    this.selU7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU7ActionPerformed(evt);
          }
        });
    this.selU8.setText("...");
    this.selU8.setFocusable(false);
    this.selU8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU8ActionPerformed(evt);
          }
        });
    this.selU9.setText("...");
    this.selU9.setFocusable(false);
    this.selU9.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU9ActionPerformed(evt);
          }
        });
    this.selU10.setText("...");
    this.selU10.setFocusable(false);
    this.selU10.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU10ActionPerformed(evt);
          }
        });
    this.selU11.setText("...");
    this.selU11.setFocusable(false);
    this.selU11.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU11ActionPerformed(evt);
          }
        });
    this.selU12.setText("...");
    this.selU12.setFocusable(false);
    this.selU12.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU12ActionPerformed(evt);
          }
        });
    this.selU13.setText("...");
    this.selU13.setFocusable(false);
    this.selU13.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU13ActionPerformed(evt);
          }
        });
    this.selU14.setText("...");
    this.selU14.setFocusable(false);
    this.selU14.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU14ActionPerformed(evt);
          }
        });
    this.selU15.setText("...");
    this.selU15.setFocusable(false);
    this.selU15.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU15ActionPerformed(evt);
          }
        });
    this.selU16.setText("...");
    this.selU16.setFocusable(false);
    this.selU16.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selU16ActionPerformed(evt);
          }
        });
    localize.setSelected(true);
    localize.setText("Localize system");
    localize.setFocusPainted(false);
    localize.setFocusable(false);
    localize.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.localizeActionPerformed(evt);
          }
        });
    this.pluson.setText("+");
    this.pluson.setFocusable(false);
    this.pluson.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.plusonActionPerformed(evt);
          }
        });
    cprfile.setEditable(false);
    cprfile.setFont(new Font("Tahoma", 0, 9));
    cprfile.setFocusable(false);
    cprload.setText("...");
    cprload.setFocusPainted(false);
    cprload.setFocusable(false);
    cprload.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.cprloadActionPerformed(evt);
          }
        });
    this.setRoms.setFont(new Font("Tahoma", 1, 22));
    this.setRoms.setText("Set");
    this.setRoms.setFocusable(false);
    this.setRoms.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.setRomsActionPerformed(evt);
          }
        });
    this.jButton46.setText("FutureOS Color bars");
    this.jButton46.setFocusPainted(false);
    this.jButton46.setFocusable(false);
    this.jButton46.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton46ActionPerformed(evt);
          }
        });
    this.roms32.setFont(new Font("Segoe UI", 0, 10));
    this.roms32.setText("Enable 32 ROMs");
    this.roms32.setFocusPainted(false);
    this.roms32.setFocusable(false);
    this.roms32.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.roms32ActionPerformed(evt);
          }
        });
    this.set32roms.setFont(new Font("Segoe UI", 0, 10));
    this.set32roms.setText("Set ROMs 16-31");
    this.set32roms.setEnabled(false);
    this.set32roms.setFocusPainted(false);
    this.set32roms.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.set32romsActionPerformed(evt);
          }
        });
    GroupLayout jPanel16Layout = new GroupLayout(this.jPanel16);
    this.jPanel16.setLayout(jPanel16Layout);
    jPanel16Layout.setHorizontalGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel16Layout.createSequentialGroup().addGap(12, 12, 12).addGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel16Layout.createSequentialGroup().addComponent(this.label1, -2, 20, -2).addGap(0, 0, 0).addComponent(this.up1, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU2, -2, 30, -2).addGap(40, 40, 40).addComponent(this.label10, -2, 20, -2).addGap(0, 0, 0).addComponent(this.up9, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU10, -2, 30, -2)).addGroup(jPanel16Layout.createSequentialGroup().addComponent(this.label4, -2, 20, -2).addGap(0, 0, 0).addComponent(this.up2, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU3, -2, 30, -2).addGap(40, 40, 40).addComponent(this.label11, -2, 20, -2).addGap(0, 0, 0).addComponent(this.up10, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU11, -2, 30, -2)).addGroup(jPanel16Layout.createSequentialGroup().addComponent(this.label3, -2, 20, -2).addGap(0, 0, 0).addComponent(this.up3, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU4, -2, 30, -2).addGap(40, 40, 40).addComponent(this.label12, -2, 20, -2).addGap(0, 0, 0).addComponent(this.up11, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU12, -2, 30, -2)).addGroup(jPanel16Layout.createSequentialGroup().addComponent(this.label6, -2, 20, -2).addGap(0, 0, 0).addComponent(this.up4, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU5, -2, 30, -2).addGap(40, 40, 40).addComponent(this.label13, -2, 20, -2).addGap(0, 0, 0).addComponent(this.up12, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU13, -2, 30, -2)).addGroup(jPanel16Layout.createSequentialGroup().addComponent(this.label5, -2, 20, -2).addGap(0, 0, 0).addComponent(this.up5, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU6, -2, 30, -2).addGap(40, 40, 40).addComponent(this.label14, -2, 20, -2).addGap(0, 0, 0).addComponent(this.up13, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU14, -2, 30, -2)).addGroup(jPanel16Layout.createSequentialGroup().addComponent(this.label8, -2, 20, -2).addGap(0, 0, 0).addComponent(this.up6, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU7, -2, 30, -2).addGap(40, 40, 40).addComponent(this.label15, -2, 20, -2).addGap(0, 0, 0).addComponent(this.up14, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU15, -2, 30, -2)).addGroup(jPanel16Layout.createSequentialGroup().addComponent(this.label7, -2, 20, -2).addGap(0, 0, 0).addComponent(this.up7, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU8, -2, 30, -2).addGap(40, 40, 40).addComponent(this.label16, -2, 20, -2).addGap(0, 0, 0).addComponent(this.up15, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU16, -2, 30, -2)).addGroup(jPanel16Layout.createSequentialGroup().addGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel16Layout.createSequentialGroup().addGap(110, 110, 110).addComponent(cprload, -2, 50, -2)).addGroup(jPanel16Layout.createSequentialGroup().addGap(30, 30, 30).addComponent(cprfile, -2, 70, -2)).addGroup(jPanel16Layout.createSequentialGroup().addGap(130, 130, 130).addComponent(this.jButton46)).addGroup(jPanel16Layout.createSequentialGroup().addGap(160, 160, 160).addComponent(this.pluson)).addGroup(jPanel16Layout.createSequentialGroup().addGap(260, 260, 260).addComponent(this.jButton6)).addGroup(jPanel16Layout.createSequentialGroup().addGap(130, 130, 130).addComponent(this.jCheckBox5)).addComponent(this.jCheckBox1).addComponent(localize)).addGap(7, 7, 7).addComponent(this.setRoms, -2, 120, -2)).addGroup(jPanel16Layout.createSequentialGroup().addComponent(this.label17, -2, 20, -2).addGap(0, 0, 0).addGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel16Layout.createSequentialGroup().addComponent(this.up0, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU1, -2, 30, -2).addGap(40, 40, 40).addComponent(this.label9, -2, 20, -2)).addComponent(this.roms32)).addGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel16Layout.createSequentialGroup().addComponent(this.up8, -2, 150, -2).addGap(0, 0, 0).addComponent(this.selU9, -2, 30, -2)).addComponent(this.set32roms))))));
    jPanel16Layout.setVerticalGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel16Layout.createSequentialGroup().addGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.set32roms, -2, 20, -2).addComponent(this.roms32, -2, 20, -2)).addGap(10, 10, 10).addGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.label17, -2, 20, -2).addComponent(this.up0, -2, 20, -2).addComponent(this.selU1, -2, 20, -2).addComponent(this.label9, -2, 20, -2).addComponent(this.up8, -2, 20, -2).addComponent(this.selU9, -2, 20, -2)).addGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.label1, -2, 20, -2).addComponent(this.up1, -2, 20, -2).addComponent(this.selU2, -2, 20, -2).addComponent(this.label10, -2, 20, -2).addComponent(this.up9, -2, 20, -2).addComponent(this.selU10, -2, 20, -2)).addGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.label4, -2, 20, -2).addComponent(this.up2, -2, 20, -2).addComponent(this.selU3, -2, 20, -2).addComponent(this.label11, -2, 20, -2).addComponent(this.up10, -2, 20, -2).addComponent(this.selU11, -2, 20, -2)).addGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.label3, -2, 20, -2).addComponent(this.up3, -2, 20, -2).addComponent(this.selU4, -2, 20, -2).addComponent(this.label12, -2, 20, -2).addComponent(this.up11, -2, 20, -2).addComponent(this.selU12, -2, 20, -2)).addGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.label6, -2, 20, -2).addComponent(this.up4, -2, 20, -2).addComponent(this.selU5, -2, 20, -2).addComponent(this.label13, -2, 20, -2).addComponent(this.up12, -2, 20, -2).addComponent(this.selU13, -2, 20, -2)).addGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.label5, -2, 20, -2).addComponent(this.up5, -2, 20, -2).addComponent(this.selU6, -2, 20, -2).addComponent(this.label14, -2, 20, -2).addComponent(this.up13, -2, 20, -2).addComponent(this.selU14, -2, 20, -2)).addGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.label8, -2, 20, -2).addComponent(this.up6, -2, 20, -2).addComponent(this.selU7, -2, 20, -2).addComponent(this.label15, -2, 20, -2).addComponent(this.up14, -2, 20, -2).addComponent(this.selU15, -2, 20, -2)).addGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.label7, -2, 20, -2).addComponent(this.up7, -2, 20, -2).addComponent(this.selU8, -2, 20, -2).addComponent(this.label16, -2, 20, -2).addComponent(this.up15, -2, 20, -2).addComponent(this.selU16, -2, 20, -2)).addGap(10, 10, 10).addGroup(jPanel16Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel16Layout.createSequentialGroup().addGap(40, 40, 40).addComponent(cprload, -2, 20, -2)).addGroup(jPanel16Layout.createSequentialGroup().addGap(40, 40, 40).addComponent(cprfile, -2, 20, -2)).addGroup(jPanel16Layout.createSequentialGroup().addGap(20, 20, 20).addComponent(this.jButton46, -2, 20, -2)).addGroup(jPanel16Layout.createSequentialGroup().addGap(40, 40, 40).addComponent(this.pluson, -2, 20, -2)).addComponent(this.jButton6, -2, 20, -2).addComponent(this.jCheckBox5, -2, 20, -2).addComponent(this.jCheckBox1).addGroup(jPanel16Layout.createSequentialGroup().addGap(20, 20, 20).addComponent(localize)).addComponent(this.setRoms, -2, 40, -2))));
    this.jPanel17.setBorder(BorderFactory.createTitledBorder("Lower ROM"));
    this.jPanel17.setLayout((LayoutManager)new AbsoluteLayout());
    this.loROM.setFocusable(false);
    this.jPanel17.add(this.loROM, new AbsoluteConstraints(40, 30, 150, 20));
    this.label2.setText("00");
    this.jPanel17.add(this.label2, new AbsoluteConstraints(20, 30, -1, 20));
    this.selL0.setText("...");
    this.selL0.setFocusable(false);
    this.selL0.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.selL0ActionPerformed(evt);
          }
        });
    this.jPanel17.add(this.selL0, new AbsoluteConstraints(190, 30, 30, 20));
    this.jPanel19.setBorder(BorderFactory.createTitledBorder("Preset:"));
    this.sysselect.setFont(new Font("Segoe UI", 0, 10));
    this.sysselect.setFocusable(false);
    this.jLabel21.setFont(new Font("Segoe UI", 0, 10));
    this.jLabel21.setText("System:");
    loadram.setFont(new Font("Segoe UI", 0, 8));
    loadram.setText("Load RDisk");
    loadram.setFocusPainted(false);
    loadram.setFocusable(false);
    loadram.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.loadramActionPerformed(evt);
          }
        });
    saveram.setFont(new Font("Segoe UI", 0, 8));
    saveram.setText("Save RDisk");
    saveram.setFocusPainted(false);
    saveram.setFocusable(false);
    saveram.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.saveramActionPerformed(evt);
          }
        });
    GroupLayout jPanel19Layout = new GroupLayout(this.jPanel19);
    this.jPanel19.setLayout(jPanel19Layout);
    jPanel19Layout.setHorizontalGroup(jPanel19Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel19Layout.createSequentialGroup().addGroup(jPanel19Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel19Layout.createSequentialGroup().addComponent(this.jLabel21).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.sysselect, -2, 130, -2)).addGroup(jPanel19Layout.createSequentialGroup().addComponent(loadram).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(saveram))).addGap(18, 18, 18)));
    jPanel19Layout.setVerticalGroup(jPanel19Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel19Layout.createSequentialGroup().addGroup(jPanel19Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel21, -2, 20, -2).addComponent(this.sysselect, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel19Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(loadram).addComponent(saveram)).addContainerGap(-1, 32767)));
    GroupLayout jPanel15Layout = new GroupLayout(this.jPanel15);
    this.jPanel15.setLayout(jPanel15Layout);
    jPanel15Layout.setHorizontalGroup(jPanel15Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel15Layout.createSequentialGroup().addContainerGap().addGroup(jPanel15Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel15Layout.createSequentialGroup().addComponent(this.jPanel17, -2, 240, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel19, -2, -1, -2)).addComponent(this.jPanel16, -2, -1, -2)).addGap(88, 88, 88)));
    jPanel15Layout.setVerticalGroup(jPanel15Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel15Layout.createSequentialGroup().addGap(10, 10, 10).addGroup(jPanel15Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jPanel19, -2, 74, -2).addComponent(this.jPanel17, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel16, -1, -1, 32767).addContainerGap()));
    OptionPane.addTab("ROMs", new ImageIcon(getClass().getResource("/jemu/ui/ico/memory.png")), this.jPanel15);
    this.jPanel26.setMinimumSize(new Dimension(490, 360));
    this.jPanel26.setPreferredSize(new Dimension(490, 360));
    this.jPanel26.setLayout((LayoutManager)new AbsoluteLayout());
    this.jPanel29.setBorder(BorderFactory.createTitledBorder("Floppies"));
    this.jPanel29.setFocusable(false);
    this.eject0.setText("Eject");
    this.eject0.setFocusable(false);
    this.eject0.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.eject0ActionPerformed(evt);
          }
        });
    this.load0.setText("...");
    this.load0.setFocusable(false);
    this.load0.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.load0ActionPerformed(evt);
          }
        });
    this.jLabel31.setText("DF0");
    this.jLabel31.setFocusable(false);
    this.eject1.setText("Eject");
    this.eject1.setFocusable(false);
    this.eject1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.eject1ActionPerformed(evt);
          }
        });
    this.load1.setText("...");
    this.load1.setFocusable(false);
    this.load1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.load1ActionPerformed(evt);
          }
        });
    this.jLabel32.setText("DF2");
    this.jLabel32.setFocusable(false);
    this.eject2.setText("Eject");
    this.eject2.setFocusable(false);
    this.eject2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.eject2ActionPerformed(evt);
          }
        });
    this.load2.setText("...");
    this.load2.setFocusable(false);
    this.load2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.load2ActionPerformed(evt);
          }
        });
    this.jLabel34.setText("DF3");
    this.jLabel34.setFocusable(false);
    this.eject3.setText("Eject");
    this.eject3.setFocusable(false);
    this.eject3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.eject3ActionPerformed(evt);
          }
        });
    this.load3.setText("...");
    this.load3.setFocusable(false);
    this.load3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.load3ActionPerformed(evt);
          }
        });
    this.dskcontrol.add(this.autosave);
    this.autosave.setText("Autosave");
    this.autosave.setFocusable(false);
    this.autosave.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.autosaveActionPerformed(evt);
          }
        });
    this.dskcontrol.add(this.asksave);
    this.asksave.setText("Ask on change");
    this.asksave.setFocusable(false);
    this.asksave.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.asksaveActionPerformed(evt);
          }
        });
    this.noOverwrite.setText("Avoid overwrite");
    this.noOverwrite.setFocusable(false);
    this.noOverwrite.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.noOverwriteActionPerformed(evt);
          }
        });
    this.jButton19.setText("Eject all");
    this.jButton19.setFocusable(false);
    this.jButton19.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton19ActionPerformed(evt);
          }
        });
    this.jButton20.setText("Boot DF0");
    this.jButton20.setFocusable(false);
    this.jButton20.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton20ActionPerformed(evt);
          }
        });
    this.jLabel33.setText("DF1");
    this.jLabel33.setFocusable(false);
    this.name3.setEditable(false);
    this.name3.setFont(new Font("Tahoma", 1, 8));
    name0.setEditable(false);
    name0.setFont(new Font("Tahoma", 1, 8));
    name1.setEditable(false);
    name1.setFont(new Font("Tahoma", 1, 8));
    this.name2.setEditable(false);
    this.name2.setFont(new Font("Tahoma", 1, 8));
    this.df0head.add(this.h01);
    this.h01.setText("B");
    this.h01.setFocusable(false);
    this.h01.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.h01ActionPerformed(evt);
          }
        });
    this.df0head.add(this.h00);
    this.h00.setText("A");
    this.h00.setFocusable(false);
    this.h00.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.h00ActionPerformed(evt);
          }
        });
    this.jLabel74.setText("Head:");
    this.jLabel74.setFocusable(false);
    this.jLabel75.setText("Head:");
    this.jLabel75.setFocusable(false);
    this.df1head.add(this.h10);
    this.h10.setText("A");
    this.h10.setFocusable(false);
    this.h10.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.h10ActionPerformed(evt);
          }
        });
    this.df1head.add(this.h11);
    this.h11.setText("B");
    this.h11.setFocusable(false);
    this.h11.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.h11ActionPerformed(evt);
          }
        });
    this.df2head.add(this.h21);
    this.h21.setText("B");
    this.h21.setFocusable(false);
    this.h21.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.h21ActionPerformed(evt);
          }
        });
    this.jLabel76.setText("Head:");
    this.jLabel76.setFocusable(false);
    this.df2head.add(this.h20);
    this.h20.setText("A");
    this.h20.setFocusable(false);
    this.h20.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.h20ActionPerformed(evt);
          }
        });
    this.df3head.add(this.h31);
    this.h31.setText("B");
    this.h31.setFocusable(false);
    this.h31.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.h31ActionPerformed(evt);
          }
        });
    this.df3head.add(this.h30);
    this.h30.setText("A");
    this.h30.setFocusable(false);
    this.h30.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.h30ActionPerformed(evt);
          }
        });
    this.jLabel77.setText("Head:");
    this.jLabel77.setFocusable(false);
    this.fastdisk.setText("Fast disc emulation");
    this.fastdisk.setFocusable(false);
    this.fastdisk.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.fastdiskActionPerformed(evt);
          }
        });
    this.fdcenabled.setText("FDC enabled");
    this.fdcenabled.setFocusable(false);
    this.fdcenabled.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.fdcenabledActionPerformed(evt);
          }
        });
    this.load4.setFont(new Font("Tahoma", 0, 8));
    this.load4.setText("M");
    this.load4.setToolTipText("Magic CPC Disk Image");
    this.load4.setBorder((Border)null);
    this.load4.setFocusable(false);
    this.load4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.load4ActionPerformed(evt);
          }
        });
    this.load5.setFont(new Font("Tahoma", 0, 8));
    this.load5.setText("M");
    this.load5.setToolTipText("Magic CPC Disk Image");
    this.load5.setBorder((Border)null);
    this.load5.setFocusable(false);
    this.load5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.load5ActionPerformed(evt);
          }
        });
    GroupLayout jPanel29Layout = new GroupLayout(this.jPanel29);
    this.jPanel29.setLayout(jPanel29Layout);
    jPanel29Layout.setHorizontalGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel29Layout.createSequentialGroup().addContainerGap().addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.name2, GroupLayout.Alignment.TRAILING).addGroup(jPanel29Layout.createSequentialGroup().addComponent(this.jLabel32).addGap(18, 18, 18).addComponent(this.jLabel76).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.h20).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.h21).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.eject2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.load2, -2, 30, -2)).addGroup(jPanel29Layout.createSequentialGroup().addComponent(this.jButton20).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.jButton19)).addGroup(jPanel29Layout.createSequentialGroup().addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel29Layout.createSequentialGroup().addComponent(this.autosave).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.asksave)).addGroup(jPanel29Layout.createSequentialGroup().addComponent(this.noOverwrite).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.fastdisk)).addComponent(this.fdcenabled)).addGap(0, 0, 32767)).addGroup(GroupLayout.Alignment.TRAILING, jPanel29Layout.createSequentialGroup().addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(name0, GroupLayout.Alignment.LEADING).addGroup(jPanel29Layout.createSequentialGroup().addComponent(this.jLabel31).addGap(18, 18, 18).addComponent(this.jLabel74).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.h00).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.h01).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.eject0))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.load0, -2, 30, -2).addComponent(this.load4, GroupLayout.Alignment.TRAILING, -2, 30, -2))).addGroup(GroupLayout.Alignment.TRAILING, jPanel29Layout.createSequentialGroup().addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(name1, GroupLayout.Alignment.LEADING).addGroup(jPanel29Layout.createSequentialGroup().addComponent(this.jLabel33).addGap(18, 18, 18).addComponent(this.jLabel75).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.h10).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.h11).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.eject1))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.load1, -2, 30, -2).addComponent(this.load5, -2, 30, -2))).addGroup(GroupLayout.Alignment.TRAILING, jPanel29Layout.createSequentialGroup().addComponent(this.jLabel34).addGap(18, 18, 18).addComponent(this.jLabel77).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.h30).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.h31).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.eject3).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.load3, -2, 30, -2)).addComponent(this.name3)).addContainerGap()));
    jPanel29Layout.setVerticalGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel29Layout.createSequentialGroup().addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel31).addComponent(this.jLabel74).addComponent(this.h00, -2, 20, -2).addComponent(this.h01, -2, 20, -2).addComponent(this.eject0, -2, 20, -2).addComponent(this.load0, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(name0, -2, -1, -2).addComponent(this.load4, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel33).addComponent(this.jLabel75).addComponent(this.h10, -2, 20, -2).addComponent(this.h11, -2, 20, -2).addComponent(this.eject1, -2, 20, -2).addComponent(this.load1, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(name1, -2, -1, -2).addComponent(this.load5, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel32).addComponent(this.jLabel76).addComponent(this.h20, -2, 20, -2).addComponent(this.h21, -2, 20, -2).addComponent(this.eject2, -2, 20, -2).addComponent(this.load2, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.name2, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel34).addComponent(this.jLabel77).addComponent(this.h30, -2, 20, -2).addComponent(this.h31, -2, 20, -2).addComponent(this.eject3, -2, 20, -2).addComponent(this.load3, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.name3, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.autosave, -2, 20, -2).addComponent(this.asksave, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.noOverwrite).addComponent(this.fastdisk)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.fdcenabled).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel29Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton20).addComponent(this.jButton19)).addGap(12, 12, 12)));
    this.jPanel26.add(this.jPanel29, new AbsoluteConstraints(10, 10, 280, 330));
    this.jPanel30.setBorder(BorderFactory.createTitledBorder("General"));
    this.jPanel30.setFocusable(false);
    this.jPanel30.setLayout((LayoutManager)new AbsoluteLayout());
    this.jCheckBox9.setText("Drive Turbo");
    this.jCheckBox9.setFocusable(false);
    this.jCheckBox9.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox9ActionPerformed(evt);
          }
        });
    this.jPanel30.add(this.jCheckBox9, new AbsoluteConstraints(20, 30, -1, -1));
    this.jPanel26.add(this.jPanel30, new AbsoluteConstraints(290, 10, 200, 70));
    this.jPanel31.setBorder(BorderFactory.createTitledBorder("Tapedrive"));
    this.jPanel31.setFocusable(false);
    this.jPanel31.setLayout((LayoutManager)new AbsoluteLayout());
    this.tapequality.add(this.freq11);
    this.freq11.setText("11Khz (Poor, long rec time)");
    this.freq11.setFocusable(false);
    this.freq11.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.freq11ActionPerformed(evt);
          }
        });
    this.jPanel31.add(this.freq11, new AbsoluteConstraints(10, 50, -1, -1));
    this.tapequality.add(this.freq22);
    this.freq22.setText("22Khz (medium rec time)");
    this.freq22.setFocusable(false);
    this.freq22.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.freq22ActionPerformed(evt);
          }
        });
    this.jPanel31.add(this.freq22, new AbsoluteConstraints(10, 70, -1, -1));
    this.tapequality.add(this.freq44);
    this.freq44.setText("44Khz (Best, short time)");
    this.freq44.setFocusable(false);
    this.freq44.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.freq44ActionPerformed(evt);
          }
        });
    this.jPanel31.add(this.freq44, new AbsoluteConstraints(10, 90, -1, -1));
    this.jLabel23.setText("Tape quality");
    this.jLabel23.setFocusable(false);
    this.jPanel31.add(this.jLabel23, new AbsoluteConstraints(20, 30, -1, -1));
    this.jCheckBox10.setText("Draw Stripes on Border");
    this.jCheckBox10.setFocusable(false);
    this.jCheckBox10.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox10ActionPerformed(evt);
          }
        });
    this.jPanel31.add(this.jCheckBox10, new AbsoluteConstraints(10, 110, -1, 20));
    this.jToggleButton2.setText("Show Drive");
    this.jToggleButton2.setFocusable(false);
    this.jToggleButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jToggleButton2ActionPerformed(evt);
          }
        });
    this.jPanel31.add(this.jToggleButton2, new AbsoluteConstraints(20, 160, 100, -1));
    this.jButton15.setText("Save as...");
    this.jButton15.setFocusable(false);
    this.jButton15.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton15ActionPerformed(evt);
          }
        });
    this.jPanel31.add(this.jButton15, new AbsoluteConstraints(20, 190, 90, -1));
    this.jButton17.setText("CDT²WAV");
    this.jButton17.setFocusable(false);
    this.jButton17.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton17ActionPerformed(evt);
          }
        });
    this.jPanel31.add(this.jButton17, new AbsoluteConstraints(20, 220, -1, -1));
    this.jButton18.setText("Optimize");
    this.jButton18.setFocusable(false);
    this.jButton18.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton18ActionPerformed(evt);
          }
        });
    this.jPanel31.add(this.jButton18, new AbsoluteConstraints(100, 220, 80, -1));
    this.jButton14.setText("...");
    this.jButton14.setFocusable(false);
    this.jButton14.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton14ActionPerformed(evt);
          }
        });
    this.jPanel31.add(this.jButton14, new AbsoluteConstraints(120, 160, 60, -1));
    this.tapename.setEditable(false);
    this.jPanel31.add(this.tapename, new AbsoluteConstraints(20, 130, 160, -1));
    this.jButton34.setText("Eject");
    this.jButton34.setFocusable(false);
    this.jButton34.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton34ActionPerformed(evt);
          }
        });
    this.jPanel31.add(this.jButton34, new AbsoluteConstraints(110, 190, 70, -1));
    this.jPanel26.add(this.jPanel31, new AbsoluteConstraints(290, 80, 200, 260));
    OptionPane.addTab("Drives", new ImageIcon(getClass().getResource("/jemu/ui/ico/floppy.png")), this.jPanel26);
    this.jPanel20.setFocusable(false);
    this.jPanel20.setMaximumSize(new Dimension(480, 340));
    this.jPanel20.setMinimumSize(new Dimension(490, 360));
    this.jPanel20.setPreferredSize(new Dimension(490, 360));
    this.jPanel20.setLayout((LayoutManager)new AbsoluteLayout());
    this.jPanel22.setBorder(BorderFactory.createTitledBorder("Printer port / Sound expansions / Emu-Display"));
    this.jPanel22.setFocusable(false);
    this.printer.setFont(new Font("Segoe UI", 0, 10));
    this.printer.setText("Enable Printer");
    this.printer.setFocusable(false);
    this.printer.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.printerActionPerformed(evt);
          }
        });
    this.digiblaster.setFont(new Font("Tahoma", 0, 10));
    this.digiblaster.setText("Digiblaster");
    this.digiblaster.setFocusable(false);
    this.digiblaster.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.digiblasterActionPerformed(evt);
          }
        });
    this.jButton5.setText("Show");
    this.jButton5.setFocusable(false);
    this.jButton5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton5ActionPerformed(evt);
          }
        });
    this.amdrum.setFont(new Font("Tahoma", 0, 10));
    this.amdrum.setText("Amdrum");
    this.amdrum.setFocusable(false);
    this.amdrum.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.amdrumActionPerformed(evt);
          }
        });
    this.playcity.setFont(new Font("Tahoma", 0, 10));
    this.playcity.setText("PlayCity");
    this.playcity.setFocusable(false);
    this.playcity.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.playcityActionPerformed(evt);
          }
        });
    this.buttonGroup3.add(this.jRadioButton3);
    this.jRadioButton3.setSelected(true);
    this.jRadioButton3.setText("Text");
    this.jRadioButton3.setFocusable(false);
    this.jRadioButton3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jRadioButton3ActionPerformed(evt);
          }
        });
    this.buttonGroup3.add(this.jRadioButton4);
    this.jRadioButton4.setText("DMP");
    this.jRadioButton4.setFocusable(false);
    this.jRadioButton4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jRadioButton4ActionPerformed(evt);
          }
        });
    GroupLayout jPanel22Layout = new GroupLayout(this.jPanel22);
    this.jPanel22.setLayout(jPanel22Layout);
    jPanel22Layout.setHorizontalGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel22Layout.createSequentialGroup().addGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel22Layout.createSequentialGroup().addGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel22Layout.createSequentialGroup().addComponent(this.printer).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton5)).addGroup(jPanel22Layout.createSequentialGroup().addComponent(this.digiblaster).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.amdrum))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jRadioButton3).addComponent(this.jRadioButton4))).addComponent(this.playcity)).addGap(0, 53, 32767)));
    jPanel22Layout.setVerticalGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel22Layout.createSequentialGroup().addContainerGap().addGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel22Layout.createSequentialGroup().addGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.printer, -2, 20, -2).addComponent(this.jButton5, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.digiblaster, -2, 20, -2).addComponent(this.amdrum, -2, 20, -2))).addGroup(jPanel22Layout.createSequentialGroup().addComponent(this.jRadioButton3, -2, 20, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jRadioButton4, -2, 20, -2))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.playcity, -2, 20, -2).addContainerGap(14, 32767)));
    this.jPanel20.add(this.jPanel22, new AbsoluteConstraints(230, 10, 260, 110));
    this.jPanel22.getAccessibleContext().setAccessibleName("Printer port / Sound expansions / Display");
    this.jPanel23.setBorder(BorderFactory.createTitledBorder("Internal apps"));
    this.jPanel23.setLayout((LayoutManager)new AbsoluteLayout());
    this.jButton7.setFont(new Font("Tahoma", 1, 11));
    this.jButton7.setText("JavaCPC Paint");
    this.jButton7.setFocusable(false);
    this.jButton7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton7ActionPerformed(evt);
          }
        });
    this.jPanel23.add(this.jButton7, new AbsoluteConstraints(30, 30, 130, -1));
    this.jButton8.setFont(new Font("Tahoma", 1, 11));
    this.jButton8.setText("DigiTracker");
    this.jButton8.setFocusable(false);
    this.jButton8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton8ActionPerformed(evt);
          }
        });
    this.jPanel23.add(this.jButton8, new AbsoluteConstraints(30, 60, 130, 20));
    this.jButton9.setText("MOD Converter");
    this.jButton9.setFocusable(false);
    this.jButton9.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton9ActionPerformed(evt);
          }
        });
    this.jPanel23.add(this.jButton9, new AbsoluteConstraints(30, 90, 130, 20));
    this.jButton10.setText("Player generator");
    this.jButton10.setFocusable(false);
    this.jButton10.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton10ActionPerformed(evt);
          }
        });
    this.jPanel23.add(this.jButton10, new AbsoluteConstraints(30, 120, 130, 20));
    this.jPanel20.add(this.jPanel23, new AbsoluteConstraints(10, 110, 190, 150));
    this.jPanel25.setBorder(BorderFactory.createTitledBorder("AutoType"));
    this.jPanel25.setLayout((LayoutManager)new AbsoluteLayout());
    autotype.setColumns(20);
    autotype.setFont(new Font("Courier New", 0, 10));
    autotype.setRows(5);
    this.jScrollPane1.setViewportView(autotype);
    this.jPanel25.add(this.jScrollPane1, new AbsoluteConstraints(20, 30, 260, 150));
    this.jButton11.setText("Send to CPC");
    this.jButton11.setFocusable(false);
    this.jButton11.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton11ActionPerformed(evt);
          }
        });
    this.jPanel25.add(this.jButton11, new AbsoluteConstraints(20, 180, -1, -1));
    this.jButton1.setText("Clear");
    this.jButton1.setFocusable(false);
    this.jButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton1ActionPerformed(evt);
          }
        });
    this.jPanel25.add(this.jButton1, new AbsoluteConstraints(220, 180, -1, -1));
    this.jCheckBox13.setSelected(true);
    this.jCheckBox13.setText("As BASIC");
    this.jCheckBox13.setFocusPainted(false);
    this.jCheckBox13.setFocusable(false);
    this.jCheckBox13.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox13ActionPerformed(evt);
          }
        });
    this.jPanel25.add(this.jCheckBox13, new AbsoluteConstraints(120, 180, -1, -1));
    this.jPanel20.add(this.jPanel25, new AbsoluteConstraints(200, 120, 290, 220));
    this.jPanel21.setBorder(BorderFactory.createTitledBorder("Speech Synthesizer"));
    this.jPanel21.setFocusable(false);
    this.jPanel21.setLayout((LayoutManager)new AbsoluteLayout());
    this.spenable.setText("Enable Speech synthesizer");
    this.spenable.setFocusable(false);
    this.spenable.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.spenableActionPerformed(evt);
          }
        });
    this.jPanel21.add(this.spenable, new AbsoluteConstraints(20, 30, -1, -1));
    this.speechgroup.add(this.dkt);
    this.dkt.setText("DK'tronics");
    this.dkt.setFocusable(false);
    this.dkt.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.dktActionPerformed(evt);
          }
        });
    this.jPanel21.add(this.dkt, new AbsoluteConstraints(130, 60, -1, -1));
    this.speechgroup.add(this.ssa1);
    this.ssa1.setText("Amstrad SSA-1");
    this.ssa1.setFocusable(false);
    this.ssa1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.ssa1ActionPerformed(evt);
          }
        });
    this.jPanel21.add(this.ssa1, new AbsoluteConstraints(20, 60, -1, -1));
    this.jPanel20.add(this.jPanel21, new AbsoluteConstraints(10, 10, 220, 100));
    this.jPanel24.setBorder(BorderFactory.createTitledBorder("German Keyboard"));
    this.jPanel24.setLayout((LayoutManager)new AbsoluteLayout());
    this.jCheckBox18.setText("Native Keytranslation");
    this.jCheckBox18.setFocusable(false);
    this.jCheckBox18.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox18ActionPerformed(evt);
          }
        });
    this.jPanel24.add(this.jCheckBox18, new AbsoluteConstraints(30, 20, -1, -1));
    this.keyc.setText("Last keycode:");
    this.jPanel24.add(this.keyc, new AbsoluteConstraints(20, 50, -1, -1));
    this.jPanel24.add(keycode, new AbsoluteConstraints(110, 50, -1, -1));
    this.jPanel20.add(this.jPanel24, new AbsoluteConstraints(10, 260, 190, 80));
    OptionPane.addTab("Misc", new ImageIcon(getClass().getResource("/jemu/ui/ico/connect.png")), this.jPanel20);
    this.infopanel.setMinimumSize(new Dimension(490, 360));
    this.infopanel.setPreferredSize(new Dimension(490, 360));
    this.jLabel4.setFont(new Font("Tahoma", 1, 30));
    this.jLabel4.setText("JavaCPC");
    this.jLabel4.setFocusable(false);
    this.jLabel5.setFont(new Font("Tahoma", 1, 18));
    this.jLabel5.setText("Amstrad CPC Emulator");
    this.jLabel5.setFocusable(false);
    this.jLabel6.setFont(new Font("Tahoma", 1, 11));
    this.jLabel6.setText("Version " + Main.version + Main.subversion);
    this.jLabel6.setFocusable(false);
    aboutline.setText("from - to - and so on");
    aboutline.setFocusable(false);
    this.jLabel8.setFont(new Font("Tahoma", 1, 11));
    this.jLabel8.setForeground(new Color(0, 0, 204));
    this.jLabel8.setText("<html><u>www.cpc-live.com</u></html>");
    this.jLabel8.setFocusable(false);
    this.jLabel8.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel8MouseReleased(evt);
          }
        });
    this.jPanel11.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel11.setFocusable(false);
    this.jPanel11.setPreferredSize(new Dimension(234, 4));
    GroupLayout jPanel11Layout = new GroupLayout(this.jPanel11);
    this.jPanel11.setLayout(jPanel11Layout);
    jPanel11Layout.setHorizontalGroup(jPanel11Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 226, 32767));
    jPanel11Layout.setVerticalGroup(jPanel11Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 0, 32767));
    this.jLabel9.setFont(new Font("Tahoma", 0, 10));
    this.jLabel9.setText("Based on JEMU © by R. Wilson");
    this.jLabel9.setFocusable(false);
    this.jPanel9.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel9.setLayout(new BorderLayout());
    this.jLabel1.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/about.png")));
    this.jPanel9.add(this.jLabel1, "After");
    this.jLabel18.setFont(new Font("Tahoma", 0, 10));
    this.jLabel18.setText("ROM images copyright:");
    this.jLabel18.setFocusable(false);
    this.jLabel19.setFont(new Font("Tahoma", 0, 10));
    this.jLabel19.setText("Amstrad Consumer Electronics plc");
    this.jLabel19.setFocusable(false);
    this.jLabel69.setFont(new Font("Tahoma", 0, 10));
    this.jLabel69.setText("and Locomotive Software Ltd.");
    this.jLabel69.setFocusable(false);
    this.jLabel85.setFont(new Font("Tahoma", 1, 10));
    this.jLabel85.setForeground(new Color(0, 0, 204));
    this.jLabel85.setText("<html><u>Web</u></html>");
    this.jLabel85.setFocusable(false);
    this.jLabel85.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel85MouseReleased(evt);
          }
        });
    this.scrollinfo.setBorder(BorderFactory.createEtchedBorder());
    this.scrollinfo.setLayout(new BorderLayout());
    this.jLabel11.setHorizontalAlignment(0);
    this.jLabel11.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/ico/donate_small.gif")));
    this.jLabel11.setCursor(new Cursor(12));
    this.jLabel11.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel11MouseReleased(evt);
          }
        });
    this.jButton45.setText("Update");
    this.jButton45.setFocusPainted(false);
    this.jButton45.setFocusable(false);
    this.jButton45.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton45ActionPerformed(evt);
          }
        });
    this.jLabel95.setFont(new Font("Tahoma", 0, 10));
    this.jLabel95.setText("GUI gfx ©Juan Carlos Gonzalez Amestoy");
    this.jLabel95.setFocusable(false);
    this.jLabel96.setFont(new Font("Tahoma", 1, 10));
    this.jLabel96.setForeground(new Color(0, 0, 204));
    this.jLabel96.setText("<html><u>Web</u></html>");
    this.jLabel96.setFocusable(false);
    this.jLabel96.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel96MouseReleased(evt);
          }
        });
    GroupLayout infopanelLayout = new GroupLayout(this.infopanel);
    this.infopanel.setLayout(infopanelLayout);
    infopanelLayout.setHorizontalGroup(infopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(infopanelLayout.createSequentialGroup().addGap(20, 20, 20).addComponent(this.jPanel9, -2, -1, -2).addGroup(infopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(infopanelLayout.createSequentialGroup().addGap(8, 8, 8).addGroup(infopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel5).addComponent(this.jLabel6).addComponent(this.jPanel11, -2, 230, -2).addComponent(this.scrollinfo, -2, 230, -2).addGroup(infopanelLayout.createSequentialGroup().addGroup(infopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel18).addComponent(this.jLabel19).addGroup(infopanelLayout.createSequentialGroup().addGap(20, 20, 20).addComponent(this.jLabel69))).addGap(5, 5, 5).addComponent(this.jButton45)).addGroup(infopanelLayout.createSequentialGroup().addComponent(this.jLabel4).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel11, -2, 80, -2)))).addGroup(infopanelLayout.createSequentialGroup().addGap(18, 18, 18).addComponent(aboutline)).addGroup(infopanelLayout.createSequentialGroup().addGap(18, 18, 18).addComponent(this.jLabel8)).addGroup(infopanelLayout.createSequentialGroup().addGap(18, 18, 18).addComponent(this.jLabel9).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel85)).addGroup(infopanelLayout.createSequentialGroup().addGap(18, 18, 18).addComponent(this.jLabel95).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel96)))));
    infopanelLayout.setVerticalGroup(infopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(infopanelLayout.createSequentialGroup().addGap(20, 20, 20).addGroup(infopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel9, -2, -1, -2).addGroup(infopanelLayout.createSequentialGroup().addGroup(infopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel4, -2, 27, -2).addComponent(this.jLabel11, -2, 30, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel5, -2, 20, -2).addGap(0, 0, 0).addComponent(this.jLabel6).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(aboutline, -2, 14, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel8).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel11, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(infopanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel9, -2, 10, -2).addComponent(this.jLabel85, -2, 14, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(infopanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel95, -2, 10, -2).addComponent(this.jLabel96, -2, 14, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.scrollinfo, -2, 110, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(infopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(infopanelLayout.createSequentialGroup().addGroup(infopanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel18).addGroup(infopanelLayout.createSequentialGroup().addGap(10, 10, 10).addComponent(this.jLabel19, -2, 10, -2))).addComponent(this.jLabel69, -2, 10, -2)).addGroup(infopanelLayout.createSequentialGroup().addGap(10, 10, 10).addComponent(this.jButton45)))))));
    OptionPane.addTab("About", new ImageIcon(getClass().getResource("/jemu/ui/ico/javacpc.png")), this.infopanel);
    options.getContentPane().add(OptionPane, "First");
    this.desktop.add(options);
    options.setBounds(20, 30, 510, 449);
    this.Welcome.setClosable(true);
    this.Welcome.setDefaultCloseOperation(1);
    this.Welcome.setIconifiable(true);
    this.Welcome.setTitle("Quickinfo");
    this.Welcome.setFocusable(false);
    this.Welcome.setFrameIcon((Icon)null);
    this.Welcome.setInheritsPopupMenu(true);
    try {
      this.Welcome.setSelected(true);
    } catch (PropertyVetoException e1) {
      e1.printStackTrace();
    } 
    this.jLabel25.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/info.png")));
    this.jLabel25.setFocusable(false);
    this.jButton12.setText("Close");
    this.jButton12.setFocusable(false);
    this.jButton12.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton12ActionPerformed(evt);
          }
        });
    this.jButton13.setText("Show next");
    this.jButton13.setFocusable(false);
    this.jButton13.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton13ActionPerformed(evt);
          }
        });
    this.jButton24.setText("Show previous");
    this.jButton24.setFocusable(false);
    this.jButton24.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton24ActionPerformed(evt);
          }
        });
    this.jCheckBox4.setText("Don't show again");
    this.jCheckBox4.setFocusable(false);
    this.jCheckBox4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jCheckBox4ActionPerformed(evt);
          }
        });
    this.jScrollPane2.setViewportView(this.qinfo);
    GroupLayout WelcomeLayout = new GroupLayout(this.Welcome.getContentPane());
    this.Welcome.getContentPane().setLayout(WelcomeLayout);
    WelcomeLayout.setHorizontalGroup(WelcomeLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(WelcomeLayout.createSequentialGroup().addContainerGap().addComponent(this.jLabel25).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(WelcomeLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, WelcomeLayout.createSequentialGroup().addComponent(this.jCheckBox4).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.jButton24).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton13).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton12)).addComponent(this.jScrollPane2)).addContainerGap()));
    WelcomeLayout.setVerticalGroup(WelcomeLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(WelcomeLayout.createSequentialGroup().addContainerGap().addGroup(WelcomeLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel25).addGroup(WelcomeLayout.createSequentialGroup().addComponent(this.jScrollPane2, -2, 219, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(WelcomeLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton24).addComponent(this.jButton13).addComponent(this.jButton12).addComponent(this.jCheckBox4)))).addGap(15, 15, 15)));
    this.desktop.add(this.Welcome);
    this.Welcome.setBounds(180, 80, 490, 300);
    this.clock.setClosable(true);
    this.clock.setDefaultCloseOperation(1);
    this.clock.setIconifiable(true);
    this.clock.setTitle("Clock");
    this.clock.setFocusable(false);
    this.clock.getContentPane().setLayout((LayoutManager)new AbsoluteLayout());
    this.jPanel27.setFocusable(false);
    this.jPanel27.setLayout((LayoutManager)new AbsoluteLayout());
    this.alarmhour.setText("00");
    this.alarmhour.setFocusable(false);
    this.jPanel27.add(this.alarmhour, new AbsoluteConstraints(10, 10, 30, -1));
    this.addhour.setFocusable(false);
    this.addhour.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.addhourActionPerformed(evt);
          }
        });
    this.jPanel27.add(this.addhour, new AbsoluteConstraints(40, 10, 10, 20));
    this.subhour.setFocusable(false);
    this.subhour.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.subhourActionPerformed(evt);
          }
        });
    this.jPanel27.add(this.subhour, new AbsoluteConstraints(0, 10, 10, 20));
    this.addmin.setFocusable(false);
    this.addmin.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.addminActionPerformed(evt);
          }
        });
    this.jPanel27.add(this.addmin, new AbsoluteConstraints(110, 10, 10, 20));
    this.alarmmin.setText("00");
    this.alarmmin.setFocusable(false);
    this.jPanel27.add(this.alarmmin, new AbsoluteConstraints(80, 10, 30, -1));
    this.submin.setFocusable(false);
    this.submin.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.subminActionPerformed(evt);
          }
        });
    this.jPanel27.add(this.submin, new AbsoluteConstraints(70, 10, 10, 20));
    this.clock.getContentPane().add(this.jPanel27, new AbsoluteConstraints(10, 60, 120, 30));
    this.light.setFocusable(false);
    this.light.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.lightActionPerformed(evt);
          }
        });
    this.clock.getContentPane().add(this.light, new AbsoluteConstraints(140, 70, 40, 20));
    this.alarmpanel.setBorder(new SoftBevelBorder(1));
    this.alarmpanel.setFocusable(false);
    this.alarmpanel.setLayout((LayoutManager)new AbsoluteLayout());
    this.timedisplay.setFont(new Font("Tahoma", 3, 18));
    this.timedisplay.setText("  00:00:00");
    this.timedisplay.setFocusable(false);
    this.alarmpanel.add(this.timedisplay, new AbsoluteConstraints(10, 10, 100, -1));
    this.date.setText("Retrieving date...");
    this.alarmpanel.add(this.date, new AbsoluteConstraints(10, 30, 100, -1));
    this.clock.getContentPane().add(this.alarmpanel, new AbsoluteConstraints(10, 10, 120, 50));
    this.jButton16.setFocusable(false);
    this.jButton16.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton16ActionPerformed(evt);
          }
        });
    this.clock.getContentPane().add(this.jButton16, new AbsoluteConstraints(140, 30, 10, -1));
    this.jToggleButton1.setBackground(Color.red);
    this.jToggleButton1.setFocusable(false);
    this.jToggleButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jToggleButton1ActionPerformed(evt);
          }
        });
    this.clock.getContentPane().add(this.jToggleButton1, new AbsoluteConstraints(140, 50, 10, -1));
    this.jLabel27.setFont(new Font("Tahoma", 0, 9));
    this.jLabel27.setText("Set");
    this.jLabel27.setFocusable(false);
    this.clock.getContentPane().add(this.jLabel27, new AbsoluteConstraints(160, 30, 30, 10));
    this.alarmenable.setFont(new Font("Tahoma", 0, 9));
    this.alarmenable.setText("On");
    this.alarmenable.setFocusable(false);
    this.clock.getContentPane().add(this.alarmenable, new AbsoluteConstraints(160, 50, 30, -1));
    this.jLabel26.setText("Alarm");
    this.clock.getContentPane().add(this.jLabel26, new AbsoluteConstraints(140, 10, -1, -1));
    this.desktop.add(this.clock);
    this.clock.setBounds(450, 30, 210, 140);
    this.cchooser.setClosable(true);
    this.cchooser.setDefaultCloseOperation(1);
    this.cchooser.setIconifiable(true);
    this.cchooser.setTitle("Select theme colours");
    this.cchooser.setNormalBounds(new Rectangle(30, 30, 633, 486));
    this.cchooser.setPreferredSize(new Dimension(700, 500));
    this.cchooser.setVerifyInputWhenFocusTarget(false);
    this.cchooser.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.cchooserMouseReleased(evt);
          }
        });
    this.colchoos.setFocusable(false);
    this.jButton25.setText("Set");
    this.jButton25.setFocusPainted(false);
    this.jButton25.setFocusable(false);
    this.jButton25.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton25ActionPerformed(evt);
          }
        });
    this.colo.setModel(new DefaultComboBoxModel<>(new String[] { "Active window left colour", "Active window right colour", "Selected item colour", "Black colour", "White Colour", "Secondary 1", "Secondary 2", "Secondary 3" }));
    this.colo.setFocusable(false);
    this.jButton33.setText("Close");
    this.jButton33.setFocusPainted(false);
    this.jButton33.setFocusable(false);
    this.jButton33.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton33ActionPerformed(evt);
          }
        });
    this.jLabel81.setText("Select Area");
    GroupLayout cchooserLayout = new GroupLayout(this.cchooser.getContentPane());
    this.cchooser.getContentPane().setLayout(cchooserLayout);
    cchooserLayout.setHorizontalGroup(cchooserLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(cchooserLayout.createSequentialGroup().addContainerGap().addGroup(cchooserLayout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(cchooserLayout.createSequentialGroup().addComponent(this.jButton25).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton33)).addGroup(cchooserLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.colchoos, -2, -1, -2).addGroup(cchooserLayout.createSequentialGroup().addComponent(this.jLabel81).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.colo, -2, -1, -2)))).addContainerGap(77, 32767)));
    cchooserLayout.setVerticalGroup(cchooserLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(cchooserLayout.createSequentialGroup().addContainerGap().addGroup(cchooserLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel81).addComponent(this.colo, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.colchoos, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(cchooserLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton33).addComponent(this.jButton25)).addContainerGap(-1, 32767)));
    this.desktop.add(this.cchooser);
    this.cchooser.setBounds(0, 0, 700, 500);
    dskutil.setClosable(true);
    dskutil.setDefaultCloseOperation(1);
    dskutil.setIconifiable(true);
    dskutil.setTitle("DSKutil");
    GroupLayout dskutilLayout = new GroupLayout(dskutil.getContentPane());
    dskutil.getContentPane().setLayout(dskutilLayout);
    dskutilLayout.setHorizontalGroup(dskutilLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 304, 32767));
    dskutilLayout.setVerticalGroup(dskutilLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 181, 32767));
    this.desktop.add(dskutil);
    dskutil.setBounds(130, 30, 320, 210);
    this.at800.setClosable(true);
    this.at800.setDefaultCloseOperation(1);
    this.at800.setIconifiable(true);
    this.at800.setTitle("Atari 800 Emulator");
    this.desktop.add(this.at800);
    this.at800.setBounds(20, 30, 240, 250);
    this.bddFrame.setClosable(true);
    this.bddFrame.setDefaultCloseOperation(1);
    this.bddFrame.setIconifiable(true);
    this.bddFrame.setResizable(true);
    this.bddFrame.setTitle("BDD - CPC File Databases");
    this.bddFrame.setVisible(false);
    this.desktop.add(this.bddFrame);
    this.bddFrame.setBounds(50, 40, 250, 100);
    this.tapedeck.setClosable(true);
    this.tapedeck.setDefaultCloseOperation(1);
    this.tapedeck.setIconifiable(true);
    this.tapedeck.setResizable(true);
    this.tapedeck.setTitle("TapeDeck");
    this.desktop.add(this.tapedeck);
    this.tapedeck.setBounds(170, 10, 140, 40);
    this.keyboard.setClosable(true);
    this.keyboard.setDefaultCloseOperation(1);
    this.keyboard.setIconifiable(true);
    this.keyboard.setTitle("JavaCPC - Virtual Keyboard");
    this.keypanel.setBorder(BorderFactory.createEtchedBorder());
    this.keyboard.getContentPane().add(this.keypanel, "South");
    this.desktop.add(this.keyboard);
    this.keyboard.setBounds(100, 10, 170, 50);
    this.mandel.setClosable(true);
    this.mandel.setDefaultCloseOperation(1);
    this.mandel.setIconifiable(true);
    this.mandel.setTitle("Mandelbrot");
    this.mandel.setVisible(false);
    this.jButton26.setText("Reset");
    this.jButton26.setFocusable(false);
    this.jButton26.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton26ActionPerformed(evt);
          }
        });
    this.jPanel36.add(this.jButton26);
    this.jButton27.setText("Out");
    this.jButton27.setFocusable(false);
    this.jButton27.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton27ActionPerformed(evt);
          }
        });
    this.jPanel36.add(this.jButton27);
    this.jButton49.setText("In");
    this.jButton49.setFocusable(false);
    this.jButton49.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton49ActionPerformed(evt);
          }
        });
    this.jPanel36.add(this.jButton49);
    this.jButton28.setText("+");
    this.jButton28.setFocusable(false);
    this.jButton28.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton28ActionPerformed(evt);
          }
        });
    this.jPanel36.add(this.jButton28);
    this.jButton29.setText("-");
    this.jButton29.setFocusable(false);
    this.jButton29.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jButton29ActionPerformed(evt);
          }
        });
    this.jPanel36.add(this.jButton29);
    this.jToggleButton5.setText("CPC");
    this.jToggleButton5.setFocusPainted(false);
    this.jToggleButton5.setFocusable(false);
    this.jToggleButton5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.jToggleButton5ActionPerformed(evt);
          }
        });
    this.jPanel36.add(this.jToggleButton5);
    this.mandel.getContentPane().add(this.jPanel36, "South");
    this.desktop.add(this.mandel);
    this.mandel.setBounds(380, 10, 300, 210);
    this.calc.setClosable(true);
    this.calc.setDefaultCloseOperation(1);
    this.calc.setIconifiable(true);
    this.calc.setTitle("Scientific Calculator");
    this.desktop.add(this.calc);
    this.calc.setBounds(490, 30, 170, 130);
    this.rasterFrame.setClosable(true);
    this.rasterFrame.setDefaultCloseOperation(1);
    this.rasterFrame.setIconifiable(true);
    this.rasterFrame.setTitle("JavaCPC RasterPaint");
    this.rasterFrame.setVisible(false);
    this.desktop.add(this.rasterFrame);
    this.rasterFrame.setBounds(10, 20, 1090, 590);
    this.GlossyClock.setBackground(new Color(204, 204, 255));
    this.GlossyClock.setRequestFocusEnabled(false);
    this.GlossyClock.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseDragged(MouseEvent evt) {
            Desktop.this.GlossyClockMouseDragged(evt);
          }
        });
    this.GlossyClock.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.GlossyClockMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.GlossyClockMouseExited(evt);
          }
        });
    this.transparentFace.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/clockglass.png")));
    this.transparentFace.setFocusable(false);
    this.GlossyClock.add(this.transparentFace);
    this.transparentFace.setBounds(0, 0, 200, 200);
    this.clockPanel.setFocusable(false);
    this.clockPanel.setOpaque(false);
    showGlass.setSelected(true);
    showGlass.setFocusPainted(false);
    showGlass.setFocusable(false);
    showGlass.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.showGlassActionPerformed(evt);
          }
        });
    GroupLayout clockPanelLayout = new GroupLayout(this.clockPanel);
    this.clockPanel.setLayout(clockPanelLayout);
    clockPanelLayout.setHorizontalGroup(clockPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, clockPanelLayout.createSequentialGroup().addContainerGap(179, 32767).addComponent(showGlass)));
    clockPanelLayout.setVerticalGroup(clockPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, clockPanelLayout.createSequentialGroup().addContainerGap(179, 32767).addComponent(showGlass)));
    this.GlossyClock.add(this.clockPanel);
    this.clockPanel.setBounds(0, 0, 200, 200);
    this.desktop.add(this.GlossyClock);
    this.GlossyClock.setBounds(680, 10, 200, 200);
    this.deathi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/ico_deathi.png")));
    this.deathi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.deathiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.deathiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.deathiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.deathiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.deathiMouseReleased(evt);
          }
        });
    this.desktop.add(this.deathi);
    this.deathi.setBounds(270, 310, 100, 70);
    this.atarii.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/ico_atari.png")));
    this.atarii.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.atariiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.atariiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.atariiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.atariiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.atariiMouseReleased(evt);
          }
        });
    this.desktop.add(this.atarii);
    this.atarii.setBounds(450, 310, 100, 70);
    this.hexi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_hexeditor.png")));
    this.hexi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.hexiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.hexiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.hexiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.hexiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.hexiMouseReleased(evt);
          }
        });
    this.desktop.add(this.hexi);
    this.hexi.setBounds(360, 30, 100, 70);
    this.capi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_audiocapture.png")));
    this.capi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.capiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.capiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.capiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.capiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.capiMouseReleased(evt);
          }
        });
    this.desktop.add(this.capi);
    this.capi.setBounds(360, 100, 100, 70);
    this.consoli.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_console.png")));
    this.consoli.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.consoliMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.consoliMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.consoliMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.consoliMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.consoliMouseReleased(evt);
          }
        });
    this.desktop.add(this.consoli);
    this.consoli.setBounds(90, 30, 100, 70);
    this.ymi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_control.png")));
    this.ymi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.ymiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.ymiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.ymiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.ymiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.ymiMouseReleased(evt);
          }
        });
    this.desktop.add(this.ymi);
    this.ymi.setBounds(180, 100, 100, 70);
    this.clocki.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_clock.png")));
    this.clocki.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.clockiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.clockiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.clockiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.clockiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.clockiMouseReleased(evt);
          }
        });
    this.desktop.add(this.clocki);
    this.clocki.setBounds(90, 100, 100, 70);
    this.infoi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_info.png")));
    this.infoi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.infoiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.infoiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.infoiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.infoiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.infoiMouseReleased(evt);
          }
        });
    this.desktop.add(this.infoi);
    this.infoi.setBounds(0, 240, 100, 70);
    this.minii.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_mini.png")));
    this.minii.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.miniiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.miniiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.miniiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.miniiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.miniiMouseReleased(evt);
          }
        });
    this.desktop.add(this.minii);
    this.minii.setBounds(0, 100, 100, 70);
    this.chati.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_chat.png")));
    this.chati.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.chatiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.chatiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.chatiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.chatiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.chatiMouseReleased(evt);
          }
        });
    this.desktop.add(this.chati);
    this.chati.setBounds(450, 240, 100, 70);
    this.radioi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/ico_gfxi.png")));
    this.radioi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.radioiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.radioiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.radioiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.radioiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.radioiMouseReleased(evt);
          }
        });
    this.desktop.add(this.radioi);
    this.radioi.setBounds(360, 240, 100, 70);
    this.browsi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_browser.png")));
    this.browsi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.browsiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.browsiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.browsiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.browsiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.browsiMouseReleased(evt);
          }
        });
    this.desktop.add(this.browsi);
    this.browsi.setBounds(180, 240, 100, 70);
    this.configi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_config.png")));
    this.configi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.configiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.configiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.configiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.configiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.configiMouseReleased(evt);
          }
        });
    this.desktop.add(this.configi);
    this.configi.setBounds(0, 30, 100, 70);
    this.debugi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_debugger.png")));
    this.debugi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.debugiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.debugiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.debugiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.debugiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.debugiMouseReleased(evt);
          }
        });
    this.desktop.add(this.debugi);
    this.debugi.setBounds(270, 30, 100, 70);
    this.tapei.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_tape.png")));
    this.tapei.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.tapeiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.tapeiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.tapeiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.tapeiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.tapeiMouseReleased(evt);
          }
        });
    this.desktop.add(this.tapei);
    this.tapei.setBounds(450, 100, 100, 70);
    this.painti.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_paint.png")));
    this.painti.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.paintiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.paintiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.paintiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.paintiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.paintiMouseReleased(evt);
          }
        });
    this.desktop.add(this.painti);
    this.painti.setBounds(0, 170, 100, 70);
    this.inii.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_ini.png")));
    this.inii.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.iniiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.iniiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.iniiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.iniiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.iniiMouseReleased(evt);
          }
        });
    this.desktop.add(this.inii);
    this.inii.setBounds(270, 100, 100, 70);
    this.newii.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_keyboard.png")));
    this.newii.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.newiiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.newiiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.newiiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.newiiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.newiiMouseReleased(evt);
          }
        });
    this.desktop.add(this.newii);
    this.newii.setBounds(450, 30, 100, 70);
    this.oldii.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_mandel.png")));
    this.oldii.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.oldiiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.oldiiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.oldiiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.oldiiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.oldiiMouseReleased(evt);
          }
        });
    this.desktop.add(this.oldii);
    this.oldii.setBounds(90, 170, 100, 70);
    this.tiledi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_tiled.png")));
    this.tiledi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.tilediMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.tilediMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.tilediMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.tilediMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.tilediMouseReleased(evt);
          }
        });
    this.desktop.add(this.tiledi);
    this.tiledi.setBounds(180, 170, 100, 70);
    this.assembli.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_assembler.png")));
    this.assembli.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.assembliMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.assembliMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.assembliMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.assembliMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.assembliMouseReleased(evt);
          }
        });
    this.desktop.add(this.assembli);
    this.assembli.setBounds(180, 30, 100, 70);
    this.calci.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_calc.png")));
    this.calci.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.calciMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.calciMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.calciMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.calciMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.calciMouseReleased(evt);
          }
        });
    this.desktop.add(this.calci);
    this.calci.setBounds(360, 170, 100, 70);
    this.flopyi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_floppy.png")));
    this.flopyi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.flopyiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.flopyiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.flopyiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.flopyiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.flopyiMouseReleased(evt);
          }
        });
    this.desktop.add(this.flopyi);
    this.flopyi.setBounds(270, 240, 100, 70);
    this.paci.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_pacman.png")));
    this.paci.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.paciMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.paciMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.paciMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.paciMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.paciMouseReleased(evt);
          }
        });
    this.desktop.add(this.paci);
    this.paci.setBounds(450, 170, 100, 70);
    this.pokei.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_poke.png")));
    this.pokei.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.pokeiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.pokeiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.pokeiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.pokeiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.pokeiMouseReleased(evt);
          }
        });
    this.desktop.add(this.pokei);
    this.pokei.setBounds(270, 170, 100, 70);
    this.jLabel24.setFont(new Font("Tahoma", 1, 11));
    this.jLabel24.setForeground(new Color(255, 255, 255));
    this.jLabel24.setText("JavaCPC v." + Main.version + Main.subversion);
    this.desktop.add(this.jLabel24);
    this.jLabel24.setBounds(10, 10, 140, 14);
    this.webi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_webbrowser.png")));
    this.webi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.webiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.webiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.webiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.webiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.webiMouseReleased(evt);
          }
        });
    this.desktop.add(this.webi);
    this.webi.setBounds(90, 240, 100, 70);
    this.favi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/ico_favo.png")));
    this.favi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.faviMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.faviMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.faviMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.faviMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.faviMouseReleased(evt);
          }
        });
    this.desktop.add(this.favi);
    this.favi.setBounds(0, 310, 100, 70);
    this.dski.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ico_dsk2cdt.png")));
    this.dski.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.dskiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.dskiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.dskiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.dskiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.dskiMouseReleased(evt);
          }
        });
    this.desktop.add(this.dski);
    this.dski.setBounds(90, 310, 100, 70);
    this.gx4000i.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/ico_plus.png")));
    this.gx4000i.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.gx4000iMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.gx4000iMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.gx4000iMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.gx4000iMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.gx4000iMouseReleased(evt);
          }
        });
    this.desktop.add(this.gx4000i);
    this.gx4000i.setBounds(180, 310, 100, 70);
    this.bddi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/ico_bddi.png")));
    this.bddi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.bddiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.bddiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.bddiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.bddiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.bddiMouseReleased(evt);
          }
        });
    this.desktop.add(this.bddi);
    this.bddi.setBounds(360, 310, 100, 70);
    this.cdi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/ico_cpcgamescd.png")));
    this.cdi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.cdiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.cdiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.cdiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.cdiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.cdiMouseReleased(evt);
          }
        });
    this.desktop.add(this.cdi);
    this.cdi.setBounds(0, 380, 100, 70);
    this.rasteri.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/ico_rasterpaint.png")));
    this.rasteri.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.rasteriMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.rasteriMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.rasteriMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.rasteriMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.rasteriMouseReleased(evt);
          }
        });
    this.desktop.add(this.rasteri);
    this.rasteri.setBounds(180, 380, 100, 70);
    this.rolandi.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/ico_roland.png")));
    this.rolandi.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Desktop.this.rolandiMouseClicked(evt);
          }
          
          public void mouseEntered(MouseEvent evt) {
            Desktop.this.rolandiMouseEntered(evt);
          }
          
          public void mouseExited(MouseEvent evt) {
            Desktop.this.rolandiMouseExited(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            Desktop.this.rolandiMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.rolandiMouseReleased(evt);
          }
        });
    this.desktop.add(this.rolandi);
    this.rolandi.setBounds(90, 380, 100, 70);
    getContentPane().add(this.desktop, "Center");
    this.taskbar.setBorder(BorderFactory.createBevelBorder(1));
    this.taskbar.setFocusable(false);
    this.taskbar.setPreferredSize(new Dimension(510, 50));
    this.taskbar.setLayout(new BorderLayout());
    this.jPanel34.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel34.setMinimumSize(new Dimension(408, 46));
    this.jPanel34.setPreferredSize(new Dimension(424, 46));
    this.jPanel34.setLayout(new FlowLayout(0));
    this.jLabel72.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/amstrad.png")));
    this.jLabel72.setBorder(BorderFactory.createEtchedBorder());
    this.jLabel72.setFocusable(false);
    this.jLabel72.addMouseListener(new MouseAdapter() {
          public void mousePressed(MouseEvent evt) {
            Desktop.this.jLabel72MousePressed(evt);
          }
        });
    this.jPanel34.add(this.jLabel72);
    this.jPanel47.setBorder(BorderFactory.createEtchedBorder());
    fpsled.setBackground(new Color(51, 51, 51));
    fpsled.setBorder(BorderFactory.createEtchedBorder());
    fpsled.setPreferredSize(new Dimension(20, 10));
    GroupLayout fpsledLayout = new GroupLayout(fpsled);
    fpsled.setLayout(fpsledLayout);
    fpsledLayout.setHorizontalGroup(fpsledLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 16, 32767));
    fpsledLayout.setVerticalGroup(fpsledLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 6, 32767));
    this.jPanel47.add(fpsled);
    this.jPanel34.add(this.jPanel47);
    this.jPanel45.setBorder(BorderFactory.createEtchedBorder());
    led0.setBackground(new Color(51, 0, 0));
    led0.setBorder(BorderFactory.createEtchedBorder());
    led0.setPreferredSize(new Dimension(20, 10));
    GroupLayout led0Layout = new GroupLayout(led0);
    led0.setLayout(led0Layout);
    led0Layout.setHorizontalGroup(led0Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 16, 32767));
    led0Layout.setVerticalGroup(led0Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 6, 32767));
    this.jPanel45.add(led0);
    led1.setBackground(new Color(51, 0, 0));
    led1.setBorder(BorderFactory.createEtchedBorder());
    led1.setPreferredSize(new Dimension(20, 10));
    GroupLayout led1Layout = new GroupLayout(led1);
    led1.setLayout(led1Layout);
    led1Layout.setHorizontalGroup(led1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 16, 32767));
    led1Layout.setVerticalGroup(led1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 6, 32767));
    this.jPanel45.add(led1);
    led2.setBackground(new Color(51, 0, 0));
    led2.setBorder(BorderFactory.createEtchedBorder());
    led2.setPreferredSize(new Dimension(20, 10));
    GroupLayout led2Layout = new GroupLayout(led2);
    led2.setLayout(led2Layout);
    led2Layout.setHorizontalGroup(led2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 16, 32767));
    led2Layout.setVerticalGroup(led2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 6, 32767));
    this.jPanel45.add(led2);
    led3.setBackground(new Color(51, 0, 0));
    led3.setBorder(BorderFactory.createEtchedBorder());
    led3.setPreferredSize(new Dimension(20, 10));
    GroupLayout led3Layout = new GroupLayout(led3);
    led3.setLayout(led3Layout);
    led3Layout.setHorizontalGroup(led3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 16, 32767));
    led3Layout.setVerticalGroup(led3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 6, 32767));
    this.jPanel45.add(led3);
    this.jPanel34.add(this.jPanel45);
    this.jPanel49.setBorder(BorderFactory.createEtchedBorder());
    led5.setBackground(new Color(0, 0, 51));
    led5.setBorder(BorderFactory.createEtchedBorder());
    led5.setPreferredSize(new Dimension(20, 10));
    GroupLayout led5Layout = new GroupLayout(led5);
    led5.setLayout(led5Layout);
    led5Layout.setHorizontalGroup(led5Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 16, 32767));
    led5Layout.setVerticalGroup(led5Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 6, 32767));
    this.jPanel49.add(led5);
    this.jPanel34.add(this.jPanel49);
    this.jSeparator4.setOrientation(1);
    this.jSeparator4.setMinimumSize(new Dimension(10, 0));
    this.jSeparator4.setPreferredSize(new Dimension(16, 30));
    this.jPanel34.add(this.jSeparator4);
    this.recb.setBackground(new Color(0, 0, 0));
    this.recb.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/recb.png")));
    this.recb.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    this.recb.setBorderPainted(false);
    this.recb.setFocusPainted(false);
    this.recb.setFocusable(false);
    this.recb.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.recbActionPerformed(evt);
          }
        });
    this.jPanel34.add(this.recb);
    this.playb.setBackground(new Color(0, 0, 0));
    this.playb.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/playb.png")));
    this.playb.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    this.playb.setBorderPainted(false);
    this.playb.setFocusPainted(false);
    this.playb.setFocusable(false);
    this.playb.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.playbActionPerformed(evt);
          }
        });
    this.jPanel34.add(this.playb);
    this.rewb.setBackground(new Color(0, 0, 0));
    this.rewb.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/rewb.png")));
    this.rewb.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    this.rewb.setBorderPainted(false);
    this.rewb.setFocusPainted(false);
    this.rewb.setFocusable(false);
    this.rewb.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.rewbActionPerformed(evt);
          }
        });
    this.jPanel34.add(this.rewb);
    this.ffwb.setBackground(new Color(0, 0, 0));
    this.ffwb.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/ffwb.png")));
    this.ffwb.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    this.ffwb.setBorderPainted(false);
    this.ffwb.setFocusPainted(false);
    this.ffwb.setFocusable(false);
    this.ffwb.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.ffwbActionPerformed(evt);
          }
        });
    this.jPanel34.add(this.ffwb);
    this.stopb.setBackground(new Color(0, 0, 0));
    this.stopb.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/stopb.png")));
    this.stopb.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    this.stopb.setBorderPainted(false);
    this.stopb.setFocusPainted(false);
    this.stopb.setFocusable(false);
    this.stopb.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.stopbActionPerformed(evt);
          }
        });
    this.jPanel34.add(this.stopb);
    this.pauseb.setBackground(new Color(0, 0, 0));
    this.pauseb.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/pauseb.png")));
    this.pauseb.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    this.pauseb.setBorderPainted(false);
    this.pauseb.setFocusPainted(false);
    this.pauseb.setFocusable(false);
    this.pauseb.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.pausebActionPerformed(evt);
          }
        });
    this.jPanel34.add(this.pauseb);
    this.jSeparator7.setOrientation(1);
    this.jSeparator7.setMinimumSize(new Dimension(10, 0));
    this.jSeparator7.setPreferredSize(new Dimension(32, 30));
    this.jPanel34.add(this.jSeparator7);
    this.jLabel66.setHorizontalAlignment(0);
    this.jLabel66.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/ico/donate_small.gif")));
    this.jLabel66.setCursor(new Cursor(12));
    this.jLabel66.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.jLabel66MouseReleased(evt);
          }
        });
    this.jPanel34.add(this.jLabel66);
    this.taskbar.add(this.jPanel34, "Center");
    this.jPanel35.setBorder(BorderFactory.createEtchedBorder());
    this.setbutton3.setBackground(new Color(0, 0, 0));
    this.setbutton3.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/dock.png")));
    this.setbutton3.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    this.setbutton3.setBorderPainted(false);
    this.setbutton3.setFocusPainted(false);
    this.setbutton3.setFocusable(false);
    this.setbutton3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.setbutton3ActionPerformed(evt);
          }
        });
    this.jPanel35.add(this.setbutton3);
    this.setbutton.setBackground(new Color(0, 0, 0));
    this.setbutton.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/settingsb.png")));
    this.setbutton.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    this.setbutton.setBorderPainted(false);
    this.setbutton.setFocusPainted(false);
    this.setbutton.setFocusable(false);
    this.setbutton.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.setbuttonActionPerformed(evt);
          }
        });
    this.jPanel35.add(this.setbutton);
    this.syncbutton.setBackground(new Color(0, 0, 0));
    this.syncbutton.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/resyncb.png")));
    this.syncbutton.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    this.syncbutton.setBorderPainted(false);
    this.syncbutton.setFocusPainted(false);
    this.syncbutton.setFocusable(false);
    this.syncbutton.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.syncbuttonActionPerformed(evt);
          }
        });
    this.jPanel35.add(this.syncbutton);
    this.resbutton.setBackground(new Color(0, 0, 0));
    this.resbutton.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/resetb.png")));
    this.resbutton.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    this.resbutton.setBorderPainted(false);
    this.resbutton.setFocusPainted(false);
    this.resbutton.setFocusable(false);
    this.resbutton.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Desktop.this.resbuttonActionPerformed(evt);
          }
        });
    this.jPanel35.add(this.resbutton);
    this.quitbutton.setBackground(new Color(0, 0, 0));
    this.quitbutton.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/quitb.png")));
    this.quitbutton.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    this.quitbutton.setBorderPainted(false);
    this.quitbutton.setFocusPainted(false);
    this.quitbutton.setFocusable(false);
    this.quitbutton.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Desktop.this.quitbuttonMouseReleased(evt);
          }
        });
    this.jPanel35.add(this.quitbutton);
    this.jPanel63.setLayout(new BorderLayout());
    this.timepanel.setHorizontalAlignment(0);
    this.timepanel.setText("00:00");
    this.timepanel.setPreferredSize(new Dimension(60, 14));
    this.jPanel63.add(this.timepanel, "Center");
    this.jPanel35.add(this.jPanel63);
    this.taskbar.add(this.jPanel35, "East");
    getContentPane().add(this.taskbar, "South");
    setSize(new Dimension(1137, 600));
    setLocationRelativeTo((Component)null);
  }
  
  private void jCheckBox1ActionPerformed(ActionEvent evt) {
    boolean disable = this.jCheckBox1.isSelected();
    Settings.setBoolean("disable_roms", disable);
    Switches.disableroms = disable;
    if (disable) {
      this.up1.setEnabled(false);
      this.up2.setEnabled(false);
      this.up3.setEnabled(false);
      this.up4.setEnabled(false);
      this.up5.setEnabled(false);
      this.up6.setEnabled(false);
      this.up8.setEnabled(false);
      this.up9.setEnabled(false);
      this.up10.setEnabled(false);
      this.up11.setEnabled(false);
      this.up12.setEnabled(false);
      this.up13.setEnabled(false);
      this.up14.setEnabled(false);
      this.up15.setEnabled(false);
    } else {
      this.up1.setEnabled(true);
      this.up2.setEnabled(true);
      this.up3.setEnabled(true);
      this.up4.setEnabled(true);
      this.up5.setEnabled(true);
      this.up6.setEnabled(true);
      this.up8.setEnabled(true);
      this.up9.setEnabled(true);
      this.up10.setEnabled(true);
      this.up11.setEnabled(true);
      this.up12.setEnabled(true);
      this.up13.setEnabled(true);
      this.up14.setEnabled(true);
      this.up15.setEnabled(true);
    } 
  }
  
  private void setRomsActionPerformed(ActionEvent evt) {
    Settings.set("system", "CUSTOM");
    JEMU.setRoms = true;
  }
  
  private void mem1ActionPerformed(ActionEvent evt) {
    this.helper.mem = 1;
    setMem(this.helper.mem);
  }
  
  private void crtc0ActionPerformed(ActionEvent evt) {
    Basic6845.CRTC = 0;
    Settings.set("crtc", "0");
  }
  
  private void crtc1ActionPerformed(ActionEvent evt) {
    Basic6845.CRTC = 1;
    Settings.set("crtc", "1");
  }
  
  private void filterActionPerformed(ActionEvent evt) {
    Settings.setBoolean("bilinear", this.filter.isSelected());
    Switches.bilinear = this.filter.isSelected();
  }
  
  private void mmaskActionPerformed(ActionEvent evt) {
    Settings.setBoolean("display_effect", this.mmask.isSelected());
    Display.scaneffect = this.mmask.isSelected();
  }
  
  private void scanlActionPerformed(ActionEvent evt) {
    Settings.setBoolean("scanlines", this.scanl.isSelected());
    Switches.ScanLines = this.scanl.isSelected();
  }
  
  private void jSlider2StateChanged(ChangeEvent evt) {
    Switches.vhold = this.jSlider2.getValue();
    Settings.set("vertical_hold", Util.hex(Switches.vhold));
  }
  
  private void jSlider1StateChanged(ChangeEvent evt) {
    Display.setFade(this.jSlider1.getValue() ^ 0xFFFFFFFF);
    Settings.set("brightness", "" + this.jSlider1.getValue());
    this.bright.setText("" + (256 - this.jSlider1.getValue()));
  }
  
  private void jMon6ActionPerformed(ActionEvent evt) {
    Settings.set("monitor", "MONO");
    Switches.monitormode = 4;
    CPC.resetInk = 1;
    this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon6.gif")));
  }
  
  private void jMon5ActionPerformed(ActionEvent evt) {
    this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon5.gif")));
    Settings.set("monitor", "GRAY");
    Switches.monitormode = 3;
    CPC.resetInk = 1;
  }
  
  private void jMon4ActionPerformed(ActionEvent evt) {
    this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon4.gif")));
    Settings.set("monitor", "GREEN");
    Switches.monitormode = 2;
    CPC.resetInk = 1;
  }
  
  private void jMon3ActionPerformed(ActionEvent evt) {
    this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon3.gif")));
    Settings.set("monitor", "CPCE");
    Switches.monitormode = 5;
    CPC.resetInk = 1;
  }
  
  private void jMon2ActionPerformed(ActionEvent evt) {
    this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon2.gif")));
    Settings.set("monitor", "LINEAR");
    Switches.monitormode = 0;
    CPC.resetInk = 1;
  }
  
  private void jMon1ActionPerformed(ActionEvent evt) {
    this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon1.gif")));
    Settings.set("monitor", "COLOR");
    Switches.monitormode = 1;
    CPC.resetInk = 1;
  }
  
  private void mem0ActionPerformed(ActionEvent evt) {
    this.helper.mem = 0;
    setMem(this.helper.mem);
  }
  
  private void mem2ActionPerformed(ActionEvent evt) {
    this.helper.mem = 2;
    setMem(this.helper.mem);
  }
  
  private void mem3ActionPerformed(ActionEvent evt) {
    this.helper.mem = 3;
    setMem(this.helper.mem);
  }
  
  private void mem4ActionPerformed(ActionEvent evt) {
    this.helper.mem = 4;
    setMem(this.helper.mem);
  }
  
  private void mem5ActionPerformed(ActionEvent evt) {
    this.helper.mem = 5;
    setMem(this.helper.mem);
  }
  
  private void jButton4ActionPerformed(ActionEvent evt) {
    setCName(this.helper.coname);
  }
  
  private void jRadioButton7ActionPerformed(ActionEvent evt) {
    this.helper.coname = 0;
  }
  
  private void jRadioButton8ActionPerformed(ActionEvent evt) {
    this.helper.coname = 1;
  }
  
  private void jRadioButton9ActionPerformed(ActionEvent evt) {
    this.helper.coname = 2;
  }
  
  private void jRadioButton10ActionPerformed(ActionEvent evt) {
    this.helper.coname = 3;
  }
  
  private void jRadioButton11ActionPerformed(ActionEvent evt) {
    this.helper.coname = 4;
  }
  
  private void jRadioButton12ActionPerformed(ActionEvent evt) {
    this.helper.coname = 5;
  }
  
  private void jRadioButton13ActionPerformed(ActionEvent evt) {
    this.helper.coname = 6;
  }
  
  private void jRadioButton14ActionPerformed(ActionEvent evt) {
    this.helper.coname = 7;
  }
  
  private void jButton5ActionPerformed(ActionEvent evt) {
    if (!Printer.matrixprinter) {
      if (JEMU.iframe == null) {
        JEMU.openp = true;
      } else {
        printframe.setVisible(true);
      } 
    } else {
      GateArray.cpc.getPrinter().open();
    } 
  }
  
  private void jCheckBox2ActionPerformed(ActionEvent evt) {
    Settings.setBoolean("realtime_clock", this.jCheckBox2.isSelected());
  }
  
  private void jCheckBox5ActionPerformed(ActionEvent evt) {
    Switches.Expansion = this.jCheckBox5.isSelected();
    if (Switches.Expansion && Switches.amdrum) {
      Switches.amdrum = false;
      Settings.setBoolean("amdrum", Switches.amdrum);
      this.amdrum.setSelected(false);
      JEMU.setRoms = true;
    } 
    Settings.setBoolean("expansion", Switches.Expansion);
    this.up6.setEnabled(!Switches.Expansion);
    this.selU7.setEnabled(!Switches.Expansion);
    JEMU.setRoms = true;
  }
  
  private void jButton6ActionPerformed(ActionEvent evt) {
    JOptionPane.showMessageDialog(this, this.helper.info);
  }
  
  private void jCheckBox3ActionPerformed(ActionEvent evt) {
    Settings.setBoolean("override_p", this.jCheckBox3.isSelected());
    Switches.overrideP = this.jCheckBox3.isSelected();
  }
  
  private void printerActionPerformed(ActionEvent evt) {
    if (this.digiblaster.isSelected())
      this.digiblaster.setSelected(false); 
    Switches.Printer = this.printer.isSelected();
    Settings.setBoolean("printer", Switches.Printer);
    Settings.setBoolean("digiblaster", false);
    Switches.digiblaster = false;
  }
  
  private void digiblasterActionPerformed(ActionEvent evt) {
    if (this.printer.isSelected())
      this.printer.setSelected(false); 
    Switches.Printer = false;
    Settings.setBoolean("printer", false);
    Switches.digiblaster = this.digiblaster.isSelected();
    Settings.setBoolean("digiblaster", Switches.digiblaster);
  }
  
  private void jButton8ActionPerformed(ActionEvent evt) {
    this.digiblaster.setSelected(true);
    Switches.digi = true;
  }
  
  private void jButton7ActionPerformed(ActionEvent evt) {
    JEMU.choosePaint(true);
  }
  
  private void jButton11ActionPerformed(ActionEvent evt) {
    Autotype.autotext = autotype.getText();
    Autotype.textArea.setText(Autotype.autotext);
    Autotype.save();
    Autotype.SendToCPC(Autotype.bix.isSelected());
  }
  
  private void jButton12ActionPerformed(ActionEvent evt) {
    this.Welcome.setVisible(false);
  }
  
  private void jCheckBox4ActionPerformed(ActionEvent evt) {
    Settings.setBoolean("welcome", !this.jCheckBox4.isSelected());
    this.sinfo.setSelected(!this.jCheckBox4.isSelected());
  }
  
  private void sinfoActionPerformed(ActionEvent evt) {
    if (this.sinfo.isSelected() && !this.Welcome.isVisible())
      this.Welcome.setVisible(true); 
    this.jCheckBox4.setSelected(!this.sinfo.isSelected());
    Settings.setBoolean("welcome", !this.jCheckBox4.isSelected());
  }
  
  private void useconsoleActionPerformed(ActionEvent evt) {
    Settings.setBoolean("console", this.useconsole.isSelected());
    checkConsole();
  }
  
  private void subminActionPerformed(ActionEvent evt) {
    setAlarm(false, false);
  }
  
  private void addminActionPerformed(ActionEvent evt) {
    setAlarm(false, true);
  }
  
  private void subhourActionPerformed(ActionEvent evt) {
    setAlarm(true, false);
  }
  
  private void addhourActionPerformed(ActionEvent evt) {
    setAlarm(true, true);
  }
  
  private void jToggleButton1ActionPerformed(ActionEvent evt) {
    checkAlarm();
  }
  
  private void jButton16ActionPerformed(ActionEvent evt) {
    checkSet();
  }
  
  private void jButton9ActionPerformed(ActionEvent evt) {
    Switches.digimc = true;
  }
  
  private void jButton10ActionPerformed(ActionEvent evt) {
    Switches.digipg = true;
  }
  
  private void mask2ActionPerformed(ActionEvent evt) {
    Settings.setBoolean("mask", true);
    Switches.mask = true;
    Display.remask = true;
  }
  
  private void mask1ActionPerformed(ActionEvent evt) {
    Settings.setBoolean("mask", false);
    Switches.mask = false;
    Display.remask = true;
  }
  
  private void jCheckBox6ActionPerformed(ActionEvent evt) {
    checkPerformance(true);
  }
  
  private void jCheckBox7ActionPerformed(ActionEvent evt) {
    Switches.watch = this.jCheckBox7.isSelected();
    Settings.setBoolean("observe_performance", Switches.watch);
  }
  
  private void jCheckBox8ActionPerformed(ActionEvent evt) {
    if (jCheckBox8.isSelected()) {
      Switches.turbo = 2;
      JEMU.turbo.setState(true);
    } else {
      Switches.turbo = 1;
      JEMU.turbo.setState(false);
    } 
  }
  
  private void jCheckBox9ActionPerformed(ActionEvent evt) {
    Switches.floppyturbo = this.jCheckBox9.isSelected();
    Settings.setBoolean("floppyturbo", Switches.floppyturbo);
  }
  
  private void jButton20ActionPerformed(ActionEvent evt) {
    CPC.bootthis = true;
  }
  
  private void remBorders() {
    this.capi.setBorder((Border)null);
    this.ymi.setBorder((Border)null);
    this.hexi.setBorder((Border)null);
    this.clocki.setBorder((Border)null);
    this.infoi.setBorder((Border)null);
    this.consoli.setBorder((Border)null);
    this.minii.setBorder((Border)null);
    this.browsi.setBorder((Border)null);
    this.configi.setBorder((Border)null);
    this.debugi.setBorder((Border)null);
    this.tapei.setBorder((Border)null);
    this.painti.setBorder((Border)null);
    this.inii.setBorder((Border)null);
    this.newii.setBorder((Border)null);
    this.oldii.setBorder((Border)null);
    this.tiledi.setBorder((Border)null);
    this.assembli.setBorder((Border)null);
    this.calci.setBorder((Border)null);
    this.paci.setBorder((Border)null);
    this.flopyi.setBorder((Border)null);
    this.pokei.setBorder((Border)null);
    this.webi.setBorder((Border)null);
    this.radioi.setBorder((Border)null);
    this.chati.setBorder((Border)null);
    this.favi.setBorder((Border)null);
    this.dski.setBorder((Border)null);
    this.atarii.setBorder((Border)null);
    this.gx4000i.setBorder((Border)null);
    this.deathi.setBorder((Border)null);
    this.bddi.setBorder((Border)null);
    this.cdi.setBorder((Border)null);
    this.rolandi.setBorder((Border)null);
    this.rasteri.setBorder((Border)null);
  }
  
  private void capiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      cap.setVisible(true); 
  }
  
  private void hexiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      this.hex.setVisible(true); 
  }
  
  private void consoliMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      if (this.console != null) {
        this.console.setVisible(true);
      } else {
        this.useconsole.setSelected(true);
        Settings.setBoolean("console", this.useconsole.isSelected());
        checkConsole();
      }  
  }
  
  private void ymiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      this.ymplayer.setVisible(true); 
  }
  
  private void clockiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      this.clock.setVisible(true); 
  }
  
  private void infoiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2) {
      this.Welcome.setVisible(true);
      this.jCheckBox4.setSelected(!Settings.getBoolean("welcome", true));
    } 
  }
  
  private void jButton21ActionPerformed(ActionEvent evt) {
    reArrange();
  }
  
  private void miniiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2) {
      if (JEMU.iframe != null && !JEMU.undocked)
        JEMU.iframe.setVisible(true); 
      this.makeemu = 0;
      CPC.resync = true;
      GateArray.cpc.start();
    } 
  }
  
  private void jToggleButton3ActionPerformed(ActionEvent evt) {
    setAlwaysOnTop(this.jToggleButton3.isSelected());
  }
  
  private void browsiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2) {
      if (this.browser == null) {
        Samples.GAMEBROWSER.play();
        this.browser = new GameBrowser("http://cpc.devilmarkus.de/jgame.php", "GameBrowser");
        this.browser.setIconifiable(true);
        this.browser.setDefaultCloseOperation(1);
        this.browser.setClosable(true);
        this.browser.setMaximizable(true);
        this.browser.setResizable(true);
        this.browser.setSize(800, 600);
        this.browser.setLocation(50, 50);
        this.desktop.add(this.browser);
      } 
      this.browser.setVisible(true);
      try {
        this.browser.setSelected(true);
      } catch (Exception exception) {}
    } 
  }
  
  private void jLabel8MouseReleased(MouseEvent evt) {
    JEMU.openWebPage("http://cpc-live.com");
  }
  
  private void jButton1ActionPerformed(ActionEvent evt) {
    autotype.setText("");
  }
  
  private void configiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      options.setVisible(true); 
  }
  
  private void debugiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2) {
      debugger = true;
      debug.setVisible(true);
      JEMU.debugger.computer.stop();
    } 
  }
  
  private void eject0ActionPerformed(ActionEvent evt) {
    if (this.eject0.isSelected())
      ej0 = true; 
    this.eject0.setSelected(true);
  }
  
  private void eject1ActionPerformed(ActionEvent evt) {
    if (this.eject1.isSelected())
      ej1 = true; 
    this.eject1.setSelected(true);
  }
  
  private void eject2ActionPerformed(ActionEvent evt) {
    if (this.eject2.isSelected())
      ej2 = true; 
    this.eject2.setSelected(true);
  }
  
  private void eject3ActionPerformed(ActionEvent evt) {
    if (this.eject3.isSelected())
      ej3 = true; 
    this.eject3.setSelected(true);
  }
  
  private void load0ActionPerformed(ActionEvent evt) {
    ld0 = true;
  }
  
  private void load1ActionPerformed(ActionEvent evt) {
    ld1 = true;
  }
  
  private void load2ActionPerformed(ActionEvent evt) {
    ld2 = true;
  }
  
  private void load3ActionPerformed(ActionEvent evt) {
    ld3 = true;
  }
  
  private void jButton19ActionPerformed(ActionEvent evt) {
    JEMU.ejectall = true;
  }
  
  private void noOverwriteActionPerformed(ActionEvent evt) {
    Settings.setBoolean("never_rename", this.noOverwrite.isSelected());
    Switches.neverOverwrite = Settings.getBoolean("never_rename", false);
  }
  
  private void autosaveActionPerformed(ActionEvent evt) {
    Switches.checksave = false;
    Switches.autosave = true;
    Settings.setBoolean("checksave", false);
    Settings.setBoolean("autosave", true);
  }
  
  private void asksaveActionPerformed(ActionEvent evt) {
    Switches.checksave = true;
    Switches.autosave = false;
    Settings.setBoolean("checksave", true);
    Settings.setBoolean("autosave", false);
  }
  
  private void freq11ActionPerformed(ActionEvent evt) {
    Switches.khz11 = true;
    Switches.khz44 = false;
    Settings.setBoolean("recrate11", true);
    Settings.setBoolean("recrate44", false);
  }
  
  private void freq22ActionPerformed(ActionEvent evt) {
    Switches.khz11 = false;
    Switches.khz44 = false;
    Settings.setBoolean("recrate11", false);
    Settings.setBoolean("recrate44", false);
  }
  
  private void freq44ActionPerformed(ActionEvent evt) {
    Switches.khz11 = false;
    Switches.khz44 = true;
    Settings.setBoolean("recrate11", false);
    Settings.setBoolean("recrate44", true);
  }
  
  private void jToggleButton2ActionPerformed(ActionEvent evt) {
    this.tapedeck.setVisible(this.jToggleButton2.isSelected());
    CPC.tapedeck = this.jToggleButton2.isSelected();
  }
  
  private void jButton14ActionPerformed(ActionEvent evt) {
    loadtape = true;
  }
  
  private void jCheckBox10ActionPerformed(ActionEvent evt) {
    CPC.changeBorder = this.jCheckBox10.isSelected();
  }
  
  private void jButton15ActionPerformed(ActionEvent evt) {
    savetape = true;
  }
  
  private void jButton17ActionPerformed(ActionEvent evt) {
    convert = true;
  }
  
  private void jButton18ActionPerformed(ActionEvent evt) {
    CPC.doOptimize = true;
  }
  
  private void tapeiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2) {
      this.tapedeck.setVisible(true);
      Dimension d = new Dimension(this.desktop.getWidth(), this.desktop.getHeight());
      this.tapedeck.setLocation(d.width - this.tapedeck.getWidth(), 10);
    } 
  }
  
  private void jButton23ActionPerformed(ActionEvent evt) {
    updatePal();
    setRegisters();
  }
  
  private void jButton13ActionPerformed(ActionEvent evt) {
    if (this.infoindex < this.pages) {
      this.infoindex++;
    } else {
      this.infoindex = 1;
    } 
    info(this.infoindex);
  }
  
  private void jButton24ActionPerformed(ActionEvent evt) {
    if (this.infoindex > 1) {
      this.infoindex--;
    } else {
      this.infoindex = this.pages;
    } 
    info(this.infoindex);
  }
  
  private void paintiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      JEMU.choosePaint(true); 
  }
  
  private void iniiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      checkDSKUtil(); 
  }
  
  private void deskcheckActionPerformed(ActionEvent evt) {
    if (this.deskcheck.isSelected()) {
      DSettings.set("use_desktop", "yes");
    } else {
      DSettings.set("use_desktop", "no");
    } 
    this.expand.setEnabled(this.deskcheck.isSelected());
    this.restartj.setVisible(true);
  }
  
  private void newiiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      checkKeyboard(); 
  }
  
  private void jButton26ActionPerformed(ActionEvent evt) {
    this.mand.reset();
  }
  
  private void jButton27ActionPerformed(ActionEvent evt) {
    this.mand.zoomOut();
  }
  
  private void jButton28ActionPerformed(ActionEvent evt) {
    this.mand.addIter();
  }
  
  private void jButton29ActionPerformed(ActionEvent evt) {
    this.mand.subIter();
  }
  
  private void oldiiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      Mandel(); 
  }
  
  private void jToggleButton4ActionPerformed(ActionEvent evt) {
    Display.interlace = this.jToggleButton4.isSelected();
    Settings.setBoolean("de-interlace", Display.interlace);
  }
  
  private void wallcenterActionPerformed(ActionEvent evt) {
    DSettings.setBoolean("stretch", !this.wallcenter.isSelected());
    DSettings.setBoolean("tiled", !this.wallcenter.isSelected());
    this.stretch = !this.wallcenter.isSelected();
    this.tiled = !this.wallcenter.isSelected();
    this.desktop.repaint();
  }
  
  private void wallstretchActionPerformed(ActionEvent evt) {
    DSettings.setBoolean("stretch", this.wallstretch.isSelected());
    this.stretch = this.wallstretch.isSelected();
    if (this.stretch) {
      this.tiled = false;
      DSettings.setBoolean("tiled", false);
    } 
    this.desktop.repaint();
  }
  
  private void spenableActionPerformed(ActionEvent evt) {
    Speech.enabled = this.spenable.isSelected();
    this.dkt.setEnabled(this.spenable.isSelected());
    this.ssa1.setEnabled(this.spenable.isSelected());
    Speech.SSA = this.ssa1.isSelected();
    Settings.setBoolean("ssa1_mode", this.ssa1.isSelected());
    if (this.spenable.isSelected()) {
      SPO256 dummyspeak = new SPO256();
      if (Speech.SSA) {
        dummyspeak.sayOkSSA();
      } else {
        dummyspeak.sayOkDK();
      } 
    } 
    Settings.setBoolean("speech", this.spenable.isSelected());
  }
  
  private void jButton34ActionPerformed(ActionEvent evt) {
    JEMU.ejecttape = true;
  }
  
  private void ssa1ActionPerformed(ActionEvent evt) {
    Settings.setBoolean("ssa1_mode", this.ssa1.isSelected());
    Speech.SSA = this.ssa1.isSelected();
    SPO256 dummyspeak = new SPO256();
    if (Speech.SSA) {
      dummyspeak.sayAmstrad();
    } else {
      dummyspeak.sayDKTronics();
    } 
  }
  
  private void dktActionPerformed(ActionEvent evt) {
    Settings.setBoolean("ssa1_mode", !this.dkt.isSelected());
    Speech.SSA = !this.dkt.isSelected();
    SPO256 dummyspeak = new SPO256();
    if (Speech.SSA) {
      dummyspeak.sayAmstrad();
    } else {
      dummyspeak.sayDKTronics();
    } 
  }
  
  private void amdrumActionPerformed(ActionEvent evt) {
    Switches.amdrum = this.amdrum.isSelected();
    Settings.setBoolean("amdrum", Switches.amdrum);
    if (Switches.Expansion && Switches.amdrum) {
      Switches.Expansion = false;
      Settings.setBoolean("expansion", false);
      this.jCheckBox5.setSelected(false);
      this.up6.setEnabled(!Switches.Expansion);
      this.selU7.setEnabled(!Switches.Expansion);
      JEMU.setRoms = true;
    } 
  }
  
  private void freqActionPerformed(ActionEvent evt) {
    if (this.freq.isSelected()) {
      Switches.frequency = 0;
      Settings.set("frequency", "0");
    } else {
      Switches.frequency = 16;
      Settings.set("frequency", "16");
    } 
  }
  
  private void selU1ActionPerformed(ActionEvent evt) {
    loadRom(1);
  }
  
  private void selU2ActionPerformed(ActionEvent evt) {
    loadRom(2);
  }
  
  private void selU3ActionPerformed(ActionEvent evt) {
    loadRom(3);
  }
  
  private void selU4ActionPerformed(ActionEvent evt) {
    loadRom(4);
  }
  
  private void selU5ActionPerformed(ActionEvent evt) {
    loadRom(5);
  }
  
  private void selU6ActionPerformed(ActionEvent evt) {
    loadRom(6);
  }
  
  private void selU7ActionPerformed(ActionEvent evt) {
    loadRom(7);
  }
  
  private void selU8ActionPerformed(ActionEvent evt) {
    loadRom(8);
  }
  
  private void selU9ActionPerformed(ActionEvent evt) {
    loadRom(9);
  }
  
  private void selU10ActionPerformed(ActionEvent evt) {
    loadRom(10);
  }
  
  private void selU11ActionPerformed(ActionEvent evt) {
    loadRom(11);
  }
  
  private void selU12ActionPerformed(ActionEvent evt) {
    loadRom(12);
  }
  
  private void selU13ActionPerformed(ActionEvent evt) {
    loadRom(13);
  }
  
  private void selU14ActionPerformed(ActionEvent evt) {
    loadRom(14);
  }
  
  private void selU15ActionPerformed(ActionEvent evt) {
    loadRom(15);
  }
  
  private void selU16ActionPerformed(ActionEvent evt) {
    loadRom(16);
  }
  
  private void selL0ActionPerformed(ActionEvent evt) {
    loadRom(0);
  }
  
  public void resetSettings() {
    Settings.resetSettings();
  }
  
  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == this.lookSelector) {
      changeLook(this.lookSelector.getSelectedIndex(), false);
      this.forced.setVisible(true);
    } 
    if (e.getSource() == this.sysselect) {
      int select = this.sysselect.getSelectedIndex();
      if (select == 0)
        return; 
      switch (select) {
        case 1:
          set464(false);
          break;
        case 2:
          set464(true);
          break;
        case 3:
          set664();
          break;
        case 4:
          set6128();
          break;
        case 5:
          setKCC(false);
          break;
        case 6:
          setKCC(true);
          break;
        case 7:
          setFos(false);
          break;
        case 8:
          setFos(true);
          break;
        case 9:
          setSos(false);
          break;
        case 10:
          setSos(true);
          break;
      } 
    } 
    if (e.getSource() == this.loROM) {
      int index = this.loROM.getSelectedIndex();
      if (index < this.loroms.length - 1 && this.loROM.isShowing()) {
        RSettings.set("lower", this.loroms[index]);
        this.rom[0] = this.loroms[index];
        this.loroms[this.loroms.length - 1] = "none";
        reBuildRoms(0);
      } 
    } 
    if (e.getSource() == this.up0) {
      int index = this.up0.getSelectedIndex();
      if (index < this.upr0.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_0", this.upr0[index]);
        this.rom[1] = this.upr0[index];
        this.upr0[this.upr0.length - 1] = "none";
        reBuildRoms(1);
      } 
    } 
    if (e.getSource() == this.up1) {
      int index = this.up1.getSelectedIndex();
      if (index < this.upr1.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_1", this.upr1[index]);
        this.rom[2] = this.upr1[index];
        this.upr1[this.upr1.length - 1] = "none";
        reBuildRoms(2);
      } 
    } 
    if (e.getSource() == this.up2) {
      int index = this.up2.getSelectedIndex();
      if (index < this.upr2.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_2", this.upr2[index]);
        this.rom[3] = this.upr2[index];
        this.upr2[this.upr2.length - 1] = "none";
        reBuildRoms(3);
      } 
    } 
    if (e.getSource() == this.up3) {
      int index = this.up3.getSelectedIndex();
      if (index < this.upr3.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_3", this.upr3[index]);
        this.rom[4] = this.upr3[index];
        this.upr3[this.upr3.length - 1] = "none";
        reBuildRoms(4);
      } 
    } 
    if (e.getSource() == this.up4) {
      int index = this.up4.getSelectedIndex();
      if (index < this.upr4.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_4", this.upr4[index]);
        this.rom[5] = this.upr4[index];
        this.upr4[this.upr4.length - 1] = "none";
        reBuildRoms(5);
      } 
    } 
    if (e.getSource() == this.up5) {
      int index = this.up5.getSelectedIndex();
      if (index < this.upr5.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_5", this.upr5[index]);
        this.rom[6] = this.upr5[index];
        this.upr5[this.upr5.length - 1] = "none";
        reBuildRoms(6);
      } 
    } 
    if (e.getSource() == this.up6) {
      int index = this.up6.getSelectedIndex();
      if (index < this.upr6.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_6", this.upr6[index]);
        this.rom[7] = this.upr6[index];
        this.upr6[this.upr6.length - 1] = "none";
        reBuildRoms(7);
      } 
    } 
    if (e.getSource() == this.up7) {
      int index = this.up7.getSelectedIndex();
      if (index < this.upr7.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_7", this.upr7[index]);
        this.rom[8] = this.upr7[index];
        this.upr7[this.upr7.length - 1] = "none";
        reBuildRoms(8);
      } 
    } 
    if (e.getSource() == this.up8) {
      int index = this.up8.getSelectedIndex();
      if (index < this.upr8.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_8", this.upr8[index]);
        this.rom[9] = this.upr8[index];
        this.upr8[this.upr8.length - 1] = "none";
        reBuildRoms(9);
      } 
    } 
    if (e.getSource() == this.up9) {
      int index = this.up9.getSelectedIndex();
      if (index < this.upr9.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_9", this.upr9[index]);
        this.rom[10] = this.upr9[index];
        this.upr9[this.upr9.length - 1] = "none";
        reBuildRoms(10);
      } 
    } 
    if (e.getSource() == this.up10) {
      int index = this.up10.getSelectedIndex();
      if (index < this.upr10.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_A", this.upr10[index]);
        this.rom[11] = this.upr10[index];
        this.upr10[this.upr10.length - 1] = "none";
        reBuildRoms(11);
      } 
    } 
    if (e.getSource() == this.up11) {
      int index = this.up11.getSelectedIndex();
      if (index < this.upr11.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_B", this.upr11[index]);
        this.rom[12] = this.upr11[index];
        this.upr11[this.upr11.length - 1] = "none";
        reBuildRoms(12);
      } 
    } 
    if (e.getSource() == this.up12) {
      int index = this.up12.getSelectedIndex();
      if (index < this.upr12.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_C", this.upr12[index]);
        this.rom[13] = this.upr12[index];
        this.upr12[this.upr12.length - 1] = "none";
        reBuildRoms(13);
      } 
    } 
    if (e.getSource() == this.up13) {
      int index = this.up13.getSelectedIndex();
      if (index < this.upr13.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_D", this.upr13[index]);
        this.rom[14] = this.upr13[index];
        this.upr13[this.upr13.length - 1] = "none";
        reBuildRoms(14);
      } 
    } 
    if (e.getSource() == this.up14) {
      int index = this.up14.getSelectedIndex();
      if (index < this.upr14.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_E", this.upr14[index]);
        this.rom[15] = this.upr14[index];
        this.upr14[this.upr14.length - 1] = "none";
        reBuildRoms(15);
      } 
    } 
    if (e.getSource() == this.up15) {
      int index = this.up15.getSelectedIndex();
      if (index < this.upr15.length - 1 && this.loROM.isShowing()) {
        RSettings.set("upper_F", this.upr15[index]);
        this.rom[16] = this.upr15[index];
        this.upr15[this.upr15.length - 1] = "none";
        reBuildRoms(16);
      } 
    } 
  }
  
  private void jLabel70MouseReleased(MouseEvent evt) {
    JEMU.openWebPage("http://www.javasoft.de/jsf/public/products/synthetica/license");
  }
  
  private void jButton31ActionPerformed(ActionEvent evt) {
    loadWallpaper();
  }
  
  private void jButton32ActionPerformed(ActionEvent evt) {
    DSettings.set("wallpaper", "none");
    this.wallpaper = null;
    this.desktop.repaint();
    setWallpaper();
  }
  
  private void forcedActionPerformed(ActionEvent evt) {
    changeLook(this.lookSelector.getSelectedIndex(), true);
    JEMU.resetpanel = true;
  }
  
  private void lightActionPerformed(ActionEvent evt) {
    this.lighttimer = 1;
    if (!this.alarmenabled)
      if (this.light.isSelected()) {
        this.alarmpanel.setBackground(new Color(184, 207, 229));
        this.timedisplay.setForeground(new Color(16, 16, 16));
        this.date.setForeground(new Color(16, 16, 16));
      } else {
        this.light.setSelected(true);
      }  
  }
  
  private void tilediMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2) {
      if (this.map == null) {
        this.map = new MapEditor();
        this.maped.setJMenuBar(this.map.menuBar);
        this.maped.add(this.map.appFrame.getContentPane());
      } 
      this.maped.setVisible(true);
    } 
  }
  
  private void simpSizeItemStateChanged(ItemEvent evt) {
    if (simpSize.isSelected())
      JEMU.simp = true; 
  }
  
  private void doubSizeItemStateChanged(ItemEvent evt) {
    if (doubSize.isSelected())
      JEMU.doub = true; 
  }
  
  private void fullSizeItemStateChanged(ItemEvent evt) {
    if (fullSize.isSelected())
      JEMU.ful = true; 
  }
  
  private void recbActionPerformed(ActionEvent evt) {
    JEMU.prec = true;
  }
  
  private void playbActionPerformed(ActionEvent evt) {
    JEMU.pplay = true;
  }
  
  private void rewbActionPerformed(ActionEvent evt) {
    JEMU.prew = true;
  }
  
  private void ffwbActionPerformed(ActionEvent evt) {
    JEMU.pffw = true;
  }
  
  private void stopbActionPerformed(ActionEvent evt) {
    JEMU.pstop = true;
  }
  
  private void pausebActionPerformed(ActionEvent evt) {
    JEMU.ppause = true;
  }
  
  public void PressIcon(JLabel in, boolean hover) {
    in.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 100, hover ? this.hovered : this.pressed));
  }
  
  private void configiMousePressed(MouseEvent evt) {
    PressIcon(this.configi, false);
  }
  
  private void configiMouseReleased(MouseEvent evt) {
    PressIcon(this.configi, true);
  }
  
  private void browsiMousePressed(MouseEvent evt) {
    PressIcon(this.browsi, false);
  }
  
  private void browsiMouseReleased(MouseEvent evt) {
    PressIcon(this.browsi, true);
  }
  
  private void consoliMousePressed(MouseEvent evt) {
    PressIcon(this.consoli, false);
  }
  
  private void consoliMouseReleased(MouseEvent evt) {
    PressIcon(this.consoli, true);
  }
  
  private void debugiMousePressed(MouseEvent evt) {
    PressIcon(this.debugi, false);
  }
  
  private void debugiMouseReleased(MouseEvent evt) {
    PressIcon(this.debugi, true);
  }
  
  private void hexiMousePressed(MouseEvent evt) {
    PressIcon(this.hexi, false);
  }
  
  private void hexiMouseReleased(MouseEvent evt) {
    PressIcon(this.hexi, true);
  }
  
  private void miniiMousePressed(MouseEvent evt) {
    PressIcon(this.minii, false);
  }
  
  private void miniiMouseReleased(MouseEvent evt) {
    PressIcon(this.minii, true);
  }
  
  private void clockiMousePressed(MouseEvent evt) {
    PressIcon(this.clocki, false);
  }
  
  private void clockiMouseReleased(MouseEvent evt) {
    PressIcon(this.clocki, true);
  }
  
  private void ymiMousePressed(MouseEvent evt) {
    PressIcon(this.ymi, false);
  }
  
  private void ymiMouseReleased(MouseEvent evt) {
    PressIcon(this.ymi, true);
  }
  
  private void iniiMousePressed(MouseEvent evt) {
    PressIcon(this.inii, false);
  }
  
  private void iniiMouseReleased(MouseEvent evt) {
    PressIcon(this.inii, true);
  }
  
  private void newiiMousePressed(MouseEvent evt) {
    PressIcon(this.newii, false);
  }
  
  private void newiiMouseReleased(MouseEvent evt) {
    PressIcon(this.newii, true);
  }
  
  private void capiMousePressed(MouseEvent evt) {
    PressIcon(this.capi, false);
  }
  
  private void capiMouseReleased(MouseEvent evt) {
    PressIcon(this.capi, true);
  }
  
  private void tapeiMousePressed(MouseEvent evt) {
    PressIcon(this.tapei, false);
  }
  
  private void tapeiMouseReleased(MouseEvent evt) {
    PressIcon(this.tapei, true);
  }
  
  private void paintiMousePressed(MouseEvent evt) {
    PressIcon(this.painti, false);
  }
  
  private void paintiMouseReleased(MouseEvent evt) {
    PressIcon(this.painti, true);
  }
  
  private void oldiiMousePressed(MouseEvent evt) {
    PressIcon(this.oldii, false);
  }
  
  private void oldiiMouseReleased(MouseEvent evt) {
    PressIcon(this.oldii, true);
  }
  
  private void tilediMousePressed(MouseEvent evt) {
    PressIcon(this.tiledi, false);
  }
  
  private void tilediMouseReleased(MouseEvent evt) {
    PressIcon(this.tiledi, true);
  }
  
  private void infoiMousePressed(MouseEvent evt) {
    PressIcon(this.infoi, false);
  }
  
  private void infoiMouseReleased(MouseEvent evt) {
    PressIcon(this.infoi, true);
  }
  
  private void superPalActionPerformed(ActionEvent evt) {
    Display.superPAL = this.superPal.isSelected();
    Settings.setBoolean("superpal", Display.superPAL);
  }
  
  private void jButton2ActionPerformed(ActionEvent evt) {
    System.gc();
  }
  
  public void updatePal() {
    Color[] pl = GateArray.cpc.getPalette();
    for (int i = 0; i < 17; i++) {
      if (!this.haspan) {
        this.pan[i] = new Panel();
        this.pans[i] = new JLabel();
        this.pant[i] = new JTextField();
        this.pant[i].setBorder(new EtchedBorder());
        this.pant[i].setBackground(Color.white);
        this.pant[i].setForeground(Color.black);
        this.pant[i].setColumns(2);
        this.pant[i].setFocusable(false);
        this.pant[i].setHorizontalAlignment(0);
        this.pant[i].setMaximumSize(new Dimension(25, 26));
        this.pant[i].setMinimumSize(new Dimension(25, 26));
        this.pant[i].setPreferredSize(new Dimension(25, 26));
        this.pant[i].setSize(new Dimension(25, 26));
        this.pants[i] = new JTextField();
        this.pants[i].setFocusable(false);
        this.pants[i].setBorder(new EtchedBorder());
        this.pants[i].setBackground(Color.white);
        this.pants[i].setForeground(Color.black);
        this.pants[i].setColumns(2);
        this.pants[i].setHorizontalAlignment(0);
        this.pants[i].setMaximumSize(new Dimension(25, 26));
        this.pants[i].setMinimumSize(new Dimension(25, 26));
        this.pants[i].setPreferredSize(new Dimension(25, 26));
        this.pants[i].setSize(new Dimension(25, 26));
        this.pans[i].setMaximumSize(new Dimension(3, 32));
        this.pans[i].setMinimumSize(new Dimension(3, 32));
        this.pans[i].setPreferredSize(new Dimension(3, 32));
        this.pans[i].setSize(new Dimension(3, 32));
        this.jpan[i] = new JPanel();
        this.jpan[i].setMaximumSize(new Dimension(25, 32));
        this.jpan[i].setMinimumSize(new Dimension(25, 32));
        this.jpan[i].setPreferredSize(new Dimension(25, 32));
        this.jpan[i].setSize(new Dimension(25, 32));
        this.jpan[i].setLayout(new BorderLayout());
        GridBagConstraints gbc = new GridBagConstraints(i * 2, 0, 1, 1, 0.0D, 0.0D, 10, 0, new Insets(1, 1, 2, 1), 0, 0);
        this.jpan[i].setBorder(new EtchedBorder());
        this.jpan[i].add(this.pan[i]);
        if (i < 16) {
          if (i < 10) {
            this.palpan.add(new JLabel("0" + i), gbc);
          } else {
            this.palpan.add(new JLabel("" + i), gbc);
          } 
        } else {
          this.palpan.add(new JLabel("bo"), gbc);
        } 
        gbc = new GridBagConstraints(i * 2, 1, 1, 1, 0.0D, 0.0D, 10, 0, new Insets(1, 1, 2, 1), 0, 0);
        this.palpan.add(this.pant[i], gbc);
        gbc = new GridBagConstraints(i * 2, 2, 1, 1, 0.0D, 0.0D, 10, 0, new Insets(1, 1, 2, 1), 0, 0);
        this.palpan.add(this.pants[i], gbc);
        gbc = new GridBagConstraints(i * 2, 3, 1, 1, 0.0D, 0.0D, 10, 0, new Insets(1, 1, 2, 1), 0, 0);
        this.palpan.add(this.jpan[i], gbc);
        if (i < 16) {
          gbc = new GridBagConstraints(i * 2 + 1, 3, 1, 1, 0.0D, 0.0D, 10, 0, new Insets(1, 1, 2, 1), 0, 0);
          this.palpan.add(this.pans[i], gbc);
        } 
        this.palpan.repaint();
      } 
      this.modo.setText(" " + GateArray.getSMode());
      this.pant[i].setText(Util.hex((byte)GateArray.getInks(i)));
      this.pants[i].setText("" + GateArray.getInk(i));
      this.pan[i].setBackground(pl[i]);
    } 
    this.haspan = true;
    this.palpan.updateUI();
  }
  
  private void assembliMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      checkAssembler(); 
  }
  
  private void assembliMousePressed(MouseEvent evt) {
    PressIcon(this.assembli, false);
  }
  
  private void assembliMouseReleased(MouseEvent evt) {
    PressIcon(this.assembli, true);
  }
  
  private void h00ActionPerformed(ActionEvent evt) {
    if (this.h00.isSelected()) {
      JEMU.forcehead = 90;
      Settings.setBoolean("df0_head", false);
      JEMU.head00 = true;
    } 
  }
  
  private void h10ActionPerformed(ActionEvent evt) {
    if (this.h10.isSelected()) {
      JEMU.forcehead = 90;
      Settings.setBoolean("df1_head", false);
      JEMU.head10 = true;
    } 
  }
  
  private void h20ActionPerformed(ActionEvent evt) {
    if (this.h20.isSelected()) {
      JEMU.forcehead = 90;
      Settings.setBoolean("df2_head", false);
      JEMU.head20 = true;
    } 
  }
  
  private void h30ActionPerformed(ActionEvent evt) {
    if (this.h30.isSelected()) {
      JEMU.forcehead = 90;
      Settings.setBoolean("df3_head", false);
      JEMU.head30 = true;
    } 
  }
  
  private void h01ActionPerformed(ActionEvent evt) {
    if (this.h01.isSelected()) {
      JEMU.forcehead = 90;
      Settings.setBoolean("df0_head", true);
      JEMU.head01 = true;
    } 
  }
  
  private void h11ActionPerformed(ActionEvent evt) {
    if (this.h11.isSelected()) {
      JEMU.forcehead = 90;
      Settings.setBoolean("df1_head", true);
      JEMU.head11 = true;
    } 
  }
  
  private void h21ActionPerformed(ActionEvent evt) {
    if (this.h21.isSelected()) {
      JEMU.forcehead = 90;
      Settings.setBoolean("df2_head", true);
      JEMU.head21 = true;
    } 
  }
  
  private void h31ActionPerformed(ActionEvent evt) {
    if (this.h31.isSelected()) {
      JEMU.forcehead = 90;
      Settings.setBoolean("df3_head", true);
      JEMU.head31 = true;
    } 
  }
  
  private void jCheckBox12ActionPerformed(ActionEvent evt) {
    brenabled = this.jCheckBox12.isSelected();
  }
  
  private void fastdiskActionPerformed(ActionEvent evt) {
    Settings.setBoolean("fastdisk", this.fastdisk.isSelected());
    UPD765A.fastdisk = this.fastdisk.isSelected();
  }
  
  private void jMon7ActionPerformed(ActionEvent evt) {
    this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon7.gif")));
    Settings.set("monitor", "GRIM");
    Switches.monitormode = 6;
    CPC.resetInk = 1;
  }
  
  private void crtcActionPerformed(ActionEvent evt) {
    Settings.setBoolean("crtcpatch", this.crtc.isSelected());
    Basic6845.patch = this.crtc.isSelected();
  }
  
  private void calciMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      this.calc.setVisible(true); 
  }
  
  private void calciMousePressed(MouseEvent evt) {
    PressIcon(this.calci, false);
  }
  
  private void calciMouseReleased(MouseEvent evt) {
    PressIcon(this.calci, true);
  }
  
  private void cchooserMouseReleased(MouseEvent evt) {
    System.out.println(Util.hex(this.colchoos.getColor().getRGB()));
  }
  
  private void jButton25ActionPerformed(ActionEvent evt) {
    updateLook();
  }
  
  private void jButton33ActionPerformed(ActionEvent evt) {
    this.cchooser.setVisible(false);
  }
  
  private void lookSelectorItemStateChanged(ItemEvent evt) {
    if (this.lookSelector.getSelectedIndex() == this.helper.looks.length - 1) {
      this.cchooser.setVisible(true);
      this.cchooser.setLocation((options.getLocation()).x + options.getWidth() + 20, (options.getLocation()).y);
    } else {
      this.cchooser.setVisible(false);
    } 
  }
  
  private void jLabel85MouseReleased(MouseEvent evt) {
    JEMU.openWebPage("http://jemu.winape.net/news.html");
  }
  
  private void paciMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      launchPacMan(); 
  }
  
  private void paciMousePressed(MouseEvent evt) {
    PressIcon(this.paci, false);
  }
  
  private void paciMouseReleased(MouseEvent evt) {
    PressIcon(this.paci, true);
  }
  
  private void flopyiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      floppy.setVisible(true); 
  }
  
  private void flopyiMousePressed(MouseEvent evt) {
    PressIcon(this.flopyi, false);
  }
  
  private void flopyiMouseReleased(MouseEvent evt) {
    PressIcon(this.flopyi, true);
  }
  
  private void pokeiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      launchPokes(); 
  }
  
  private void pokeiMousePressed(MouseEvent evt) {
    PressIcon(this.pokei, false);
  }
  
  private void pokeiMouseReleased(MouseEvent evt) {
    PressIcon(this.pokei, true);
  }
  
  private void jButton35ActionPerformed(ActionEvent evt) {
    printout.setText("");
  }
  
  private void jButton36ActionPerformed(ActionEvent evt) {
    if (!printout.getText().equals("")) {
      printout.selectAll();
      printout.copy();
      printout.paste();
    } 
  }
  
  private void jButton37ActionPerformed(ActionEvent evt) {
    FileDialog filedia = new FileDialog(this, "Save ASCII...", 1);
    filedia.setFile("*.txt: *.asm; *.bas");
    filedia.setVisible(true);
    String filename = filedia.getFile();
    if (filename != null) {
      filename = filedia.getDirectory() + filedia.getFile();
      String savename = filename;
      if (!savename.toLowerCase().endsWith(".txt") && !savename.toLowerCase().endsWith(".asm") && !savename.toLowerCase().endsWith(".bas"))
        savename = savename + ".txt"; 
      File file = new File(savename);
      String gettext = printout.getText();
      try {
        FileWriter fw = new FileWriter(file);
        fw.write(gettext);
        fw.close();
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
    filedia.dispose();
  }
  
  private void jButton38ActionPerformed(ActionEvent evt) {
    Autotype.autotext = printout.getText();
    Autotype.textArea.setText(Autotype.autotext);
    Switches.getfromautotype = 1;
  }
  
  private void syncActionPerformed(ActionEvent evt) {
    Settings.setBoolean("sync_64bit", sync.isSelected());
  }
  
  private void GlossyClockMouseDragged(MouseEvent evt) {
    int x = evt.getXOnScreen() - (getLocation()).x - (getInsets()).left - 100;
    int y = evt.getYOnScreen() - (getLocation()).y - (getInsets()).top - 100;
    this.GlossyClock.setLocation(x, y);
    DSettings.set("clockx", "" + x);
    DSettings.set("clocky", "" + y);
  }
  
  private void showGlassActionPerformed(ActionEvent evt) {
    this.transparentFace.setVisible(showGlass.isSelected());
  }
  
  private void webiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      OpenBrowser(); 
  }
  
  private void webiMousePressed(MouseEvent evt) {
    PressIcon(this.webi, false);
  }
  
  private void webiMouseReleased(MouseEvent evt) {
    PressIcon(this.webi, true);
  }
  
  private void radioiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      addRadio(); 
  }
  
  private void radioiMousePressed(MouseEvent evt) {
    PressIcon(this.radioi, false);
  }
  
  private void radioiMouseReleased(MouseEvent evt) {
    PressIcon(this.radioi, true);
  }
  
  private void jButton39ActionPerformed(ActionEvent evt) {
    setupReg();
  }
  
  private void chatiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      this.addchat = 1; 
  }
  
  private void chatiMousePressed(MouseEvent evt) {
    PressIcon(this.chati, false);
  }
  
  private void chatiMouseReleased(MouseEvent evt) {
    PressIcon(this.chati, true);
  }
  
  private void jButton40ActionPerformed(ActionEvent evt) {
    downloadWallpaper();
  }
  
  private void audioformatActionPerformed(ActionEvent evt) {
    Settings.set("samplerate", "" + this.audioformat.getSelectedIndex());
    AY_3_8910.changeformat = true;
    AY_3_8910_A.changeformat = true;
    AY_3_8910_B.changeformat = true;
  }
  
  private void buffersizeStateChanged(ChangeEvent evt) {
    AY_3_8910.buffersize = this.buffersize.getValue();
    AY_3_8910.updatecount = 1;
  }
  
  private void muteActionPerformed(ActionEvent evt) {
    if (this.mute.isSelected()) {
      Switches.audioenabler = 0;
      Settings.setBoolean("audio", false);
    } else {
      Switches.audioenabler = 1;
      Settings.setBoolean("audio", true);
    } 
    if (Switches.audioenabler == 1) {
      DesktopHelper.audio.setValue((int)(this.volumeslider.getValue() * 100.0F));
      DesktopHelper.blast.setValue((int)(this.digiblastervolumeslider.getValue() * 100.0F));
    } else {
      DesktopHelper.audio.setValue(4);
      DesktopHelper.blast.setValue(4);
    } 
  }
  
  private void keynoiseActionPerformed(ActionEvent evt) {
    Switches.KeyboardSound = this.keynoise.isSelected();
    Settings.setBoolean("key_sound", Switches.KeyboardSound);
  }
  
  private void drivenoisesActionPerformed(ActionEvent evt) {
    Switches.FloppySound = this.drivenoises.isSelected();
    Settings.setBoolean("floppy_sound", Switches.FloppySound);
  }
  
  private void jAYE1ActionPerformed(ActionEvent evt) {
    Switches.dbeffect = this.jAYE1.isSelected();
    Settings.setBoolean("db_effect", Switches.dbeffect);
  }
  
  private void jAYEActionPerformed(ActionEvent evt) {
    Switches.ayeffect = this.jAYE.isSelected();
    Settings.setBoolean("ay_effect", Switches.ayeffect);
  }
  
  private void jAY3ActionPerformed(ActionEvent evt) {
    Switches.CPCE95 = true;
    Switches.KAYOut = false;
    Switches.linear = false;
    Switches.VSoftOutput = false;
    Switches.HACKER = false;
    Switches.LION = false;
    setVols();
  }
  
  private void jAY1ActionPerformed(ActionEvent evt) {
    Switches.CPCE95 = false;
    Switches.KAYOut = true;
    Switches.linear = false;
    Switches.VSoftOutput = false;
    Switches.HACKER = false;
    Switches.LION = false;
    setVols();
  }
  
  private void jAY2ActionPerformed(ActionEvent evt) {
    Switches.CPCE95 = false;
    Switches.KAYOut = false;
    Switches.linear = false;
    Switches.VSoftOutput = true;
    Switches.HACKER = false;
    Switches.LION = false;
    setVols();
  }
  
  private void jAY4ActionPerformed(ActionEvent evt) {
    Switches.CPCE95 = false;
    Switches.KAYOut = false;
    Switches.linear = true;
    Switches.VSoftOutput = false;
    Switches.HACKER = false;
    Switches.LION = false;
    setVols();
  }
  
  private void GlossyClockMouseEntered(MouseEvent evt) {
    showGlass.setVisible(true);
    this.hideglass = 0;
  }
  
  private void GlossyClockMouseExited(MouseEvent evt) {
    this.hideglass = 100;
  }
  
  private void jCheckBox11ActionPerformed(ActionEvent evt) {
    GateArray.cpc.connectMF(this.jCheckBox11.isSelected());
  }
  
  private void localizeActionPerformed(ActionEvent evt) {
    Settings.setBoolean("localize_roms", localize.isSelected());
  }
  
  private void frameskipActionPerformed(ActionEvent evt) {
    Display.skipframes = this.frameskip.isSelected();
  }
  
  private void expandActionPerformed(ActionEvent evt) {
    DSettings.setBoolean("undecorate", this.expand.isSelected());
    if (isUndecorated() == (!this.expand.isSelected())) {
      this.restartj.setVisible(true);
    } else {
      this.restartj.setVisible(false);
    } 
  }
  
  private void jLabel11MouseReleased(MouseEvent evt) {
    JEMU.openWebPage("http://cpc-live.com/donate.html");
  }
  
  private void jCheckBox13ActionPerformed(ActionEvent evt) {
    Autotype.bix.setSelected(this.jCheckBox13.isSelected());
  }
  
  private void jCheckBox14ActionPerformed(ActionEvent evt) {
    AY_3_8910.Speaker = this.jCheckBox14.isSelected();
    Settings.setBoolean("speaker", this.jCheckBox14.isSelected());
    if (this.jCheckBox14.isSelected()) {
      Settings.setBoolean("filter", false);
      AudioFilter.lowpass = false;
      this.jCheckBox15.setSelected(false);
    } 
  }
  
  private void jCheckBox15ActionPerformed(ActionEvent evt) {
    AudioFilter.lowpass = this.jCheckBox15.isSelected();
    Settings.setBoolean("filter", this.jCheckBox15.isSelected());
    if (this.jCheckBox15.isSelected()) {
      Settings.setBoolean("speaker", false);
      AY_3_8910.Speaker = false;
      this.jCheckBox14.setSelected(false);
    } 
  }
  
  private void jButton22ActionPerformed(ActionEvent evt) {
    JEMU.debugger.getDebuggerComputer().start();
  }
  
  private void jButton41ActionPerformed(ActionEvent evt) {
    JEMU.debugger.getDebuggerComputer().stop();
    JEMU.debugger.updateDisplay();
    JEMU.debugger.getDebuggerComputer().repaintDisplay();
    updatePal();
    setRegisters();
  }
  
  private void jButton42ActionPerformed(ActionEvent evt) {
    JEMU.debugger.getDebuggerComputer().step();
    JEMU.debugger.updateDisplay();
    JEMU.debugger.getDebuggerComputer().repaintDisplay();
    updatePal();
    setRegisters();
  }
  
  private void jButton43ActionPerformed(ActionEvent evt) {
    JEMU.debugger.getDebuggerComputer().stepOver();
    JEMU.debugger.updateDisplay();
    JEMU.debugger.getDebuggerComputer().repaintDisplay();
    updatePal();
    setRegisters();
  }
  
  private void jButton43KeyPressed(KeyEvent evt) {
    if (evt.getKeyCode() == 10) {
      JEMU.debugger.getDebuggerComputer().stepOver();
      JEMU.debugger.getDebuggerComputer().repaintDisplay();
      updatePal();
      setRegisters();
    } 
  }
  
  private void jButton42KeyPressed(KeyEvent evt) {
    if (evt.getKeyCode() == 10) {
      JEMU.debugger.getDebuggerComputer().step();
      JEMU.debugger.getDebuggerComputer().repaintDisplay();
      updatePal();
      setRegisters();
    } 
  }
  
  private void plusonActionPerformed(ActionEvent evt) {
    Settings.set("system", "PLUS");
    JEMU.setRoms = true;
  }
  
  private void slicActionPerformed(ActionEvent evt) {
    File syn = new File("lib/synthetica.jar");
    if (this.lic == null)
      this.lic = new SyntheticaLic(); 
    this.lic.setVisible(true);
  }
  
  private void jButton44ActionPerformed(ActionEvent evt) {
    String[] rg = new String[16];
    rg[0] = this.jTextField1.getText();
    rg[1] = this.jTextField2.getText();
    rg[2] = this.jTextField3.getText();
    rg[3] = this.jTextField4.getText();
    rg[4] = this.jTextField5.getText();
    rg[5] = this.jTextField6.getText();
    rg[6] = this.jTextField7.getText();
    rg[7] = this.jTextField8.getText();
    rg[8] = this.jTextField9.getText();
    rg[9] = this.jTextField10.getText();
    rg[10] = this.jTextField11.getText();
    rg[11] = this.jTextField12.getText();
    rg[12] = this.jTextField13.getText();
    rg[13] = this.jTextField14.getText();
    rg[14] = this.jTextField15.getText();
    rg[15] = this.jTextField16.getText();
    String result = "";
    int line = 10;
    int pos = 0;
    for (int i = 0; i < 16; i++) {
      result = result + line + " OUT &BC00," + i + ": OUT &BD00,&" + rg[i] + "\r\n";
      line += 10;
    } 
    System.out.println(result);
  }
  
  private void faviMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      addFavs(); 
  }
  
  private void faviMousePressed(MouseEvent evt) {
    PressIcon(this.favi, false);
  }
  
  private void faviMouseReleased(MouseEvent evt) {
    PressIcon(this.favi, true);
  }
  
  private void cprloadActionPerformed(ActionEvent evt) {
    GateArray.cpc.openCartridge();
  }
  
  private void dskiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      dsk2cdt(); 
  }
  
  private void dskiMousePressed(MouseEvent evt) {
    PressIcon(this.dski, false);
  }
  
  private void dskiMouseReleased(MouseEvent evt) {
    PressIcon(this.dski, true);
  }
  
  private void jButton45ActionPerformed(ActionEvent evt) {
    Main.checkUpdate(false);
  }
  
  private void jButton46ActionPerformed(ActionEvent evt) {
    if (CPC.PEEK(47615) == 0) {
      CPC.POKE(47615, 255);
    } else {
      CPC.POKE(47615, 0);
    } 
  }
  
  private void palActionPerformed(ActionEvent evt) {
    Display.PAL = this.pal.isSelected();
    Settings.setBoolean("pal", this.pal.isSelected());
  }
  
  private void palvalueStateChanged(ChangeEvent evt) {
    Display.blur = this.palvalue.getValue();
    Settings.set("pal_value", "" + Display.blur);
  }
  
  private void pal1ActionPerformed(ActionEvent evt) {
    Display.reverse = this.pal1.isSelected();
    Settings.setBoolean("pal_double", this.pal1.isSelected());
  }
  
  private void palvalue1StateChanged(ChangeEvent evt) {
    Display.snow = this.palvalue1.getValue();
    Settings.set("pal_snow", "" + Display.snow);
  }
  
  private void jAY5ActionPerformed(ActionEvent evt) {
    Switches.CPCE95 = false;
    Switches.KAYOut = false;
    Switches.linear = false;
    Switches.VSoftOutput = false;
    Switches.HACKER = false;
    Switches.LION = true;
    setVols();
  }
  
  private void jAY6ActionPerformed(ActionEvent evt) {
    Switches.CPCE95 = false;
    Switches.KAYOut = false;
    Switches.linear = false;
    Switches.VSoftOutput = false;
    Switches.HACKER = true;
    Switches.LION = false;
    setVols();
  }
  
  private void lockActionPerformed(ActionEvent evt) {
    this.vdig.lock = this.lock.isSelected();
  }
  
  private void walltileActionPerformed(ActionEvent evt) {
    DSettings.setBoolean("tiled", this.walltile.isSelected());
    this.tiled = this.walltile.isSelected();
    if (this.tiled) {
      this.stretch = false;
      DSettings.setBoolean("stretch", false);
    } 
    this.desktop.repaint();
  }
  
  private void jButton49ActionPerformed(ActionEvent evt) {
    this.mand.zoomIn();
  }
  
  private void jToggleButton5ActionPerformed(ActionEvent evt) {
    this.mand.toCPC = this.jToggleButton5.isSelected();
    this.mand.repaint();
  }
  
  private void jCheckBox16ActionPerformed(ActionEvent evt) {
    Settings.setBoolean("use_3d", this.jCheckBox16.isSelected());
    Display.use3d = this.jCheckBox16.isSelected();
    JEMU.update3d = true;
  }
  
  private void jCheckBox17ActionPerformed(ActionEvent evt) {
    Settings.setBoolean("simple_textures", this.jCheckBox17.isSelected());
  }
  
  private void jCheckBox18ActionPerformed(ActionEvent evt) {
    Settings.setBoolean("native_keyboard", this.jCheckBox18.isSelected());
    JEMU.pckeyboard = this.jCheckBox18.isSelected();
  }
  
  private void loadramActionPerformed(ActionEvent evt) {
    GateArray.cpc.loadRamDisk();
  }
  
  private void saveramActionPerformed(ActionEvent evt) {
    GateArray.cpc.saveRamDisk();
  }
  
  private void roms32ActionPerformed(ActionEvent evt) {
    Settings.setBoolean("32_roms_enabled", this.roms32.isSelected());
    Settings.set("system", "CUSTOM");
    this.set32roms.setEnabled(this.roms32.isSelected());
    JEMU.setRoms = true;
  }
  
  private void set32romsActionPerformed(ActionEvent evt) {
    if (this.romSetter32 == null)
      this.romSetter32 = new Romsetter32(); 
    this.romSetter32.setVisible(true);
  }
  
  private void atariiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      addAtari(); 
  }
  
  private void atariiMousePressed(MouseEvent evt) {
    PressIcon(this.atarii, false);
  }
  
  private void atariiMouseReleased(MouseEvent evt) {
    PressIcon(this.atarii, true);
  }
  
  private void levelStateChanged(ChangeEvent evt) {
    Settings.set("filtervalue", "" + level.getValue());
  }
  
  private void jRadioButton1ActionPerformed(ActionEvent evt) {
    setGaType();
  }
  
  private void jRadioButton2ActionPerformed(ActionEvent evt) {
    setGaType();
  }
  
  private void gx4000iMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      addPlus(); 
  }
  
  private void gx4000iMousePressed(MouseEvent evt) {
    PressIcon(this.gx4000i, false);
  }
  
  private void gx4000iMouseReleased(MouseEvent evt) {
    PressIcon(this.gx4000i, true);
  }
  
  private void jButton30ActionPerformed(ActionEvent evt) {
    resetSettings();
  }
  
  private void deathiMouseReleased(MouseEvent evt) {
    PressIcon(this.deathi, true);
  }
  
  private void deathiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      GateArray.cpc.runDeathSword(); 
  }
  
  private void deathiMousePressed(MouseEvent evt) {
    PressIcon(this.deathi, false);
  }
  
  private void playcityActionPerformed(ActionEvent evt) {
    GateArray.cpc.isPlayCity = this.playcity.isSelected();
    GateArray.cpc.mapDualYM(GateArray.cpc.isPlayCity);
    Settings.setBoolean("playcity", GateArray.cpc.isPlayCity);
  }
  
  private void jComboBox2ItemStateChanged(ItemEvent evt) {
    CPC.WinCPC = (this.jComboBox2.getSelectedIndex() == 1);
    Settings.setBoolean("wincpc_floppy_samples", CPC.WinCPC);
  }
  
  private void jLabel66MouseReleased(MouseEvent evt) {
    JEMU.openWebPage("http://cpc-live.com/donate.html");
  }
  
  private void bddiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      createBDD(); 
  }
  
  private void bddiMousePressed(MouseEvent evt) {
    PressIcon(this.bddi, false);
  }
  
  private void bddiMouseReleased(MouseEvent evt) {
    PressIcon(this.bddi, true);
  }
  
  private void configiMouseEntered(MouseEvent evt) {
    PressIcon(this.configi, true);
  }
  
  private void configiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void consoliMouseEntered(MouseEvent evt) {
    PressIcon(this.consoli, true);
  }
  
  private void consoliMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void assembliMouseEntered(MouseEvent evt) {
    PressIcon(this.assembli, true);
  }
  
  private void assembliMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void debugiMouseEntered(MouseEvent evt) {
    PressIcon(this.debugi, true);
  }
  
  private void debugiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void hexiMouseEntered(MouseEvent evt) {
    PressIcon(this.hexi, true);
  }
  
  private void hexiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void newiiMouseEntered(MouseEvent evt) {
    PressIcon(this.newii, true);
  }
  
  private void newiiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void miniiMouseEntered(MouseEvent evt) {
    PressIcon(this.minii, true);
  }
  
  private void miniiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void clockiMouseEntered(MouseEvent evt) {
    PressIcon(this.clocki, true);
  }
  
  private void clockiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void ymiMouseEntered(MouseEvent evt) {
    PressIcon(this.ymi, true);
  }
  
  private void ymiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void iniiMouseEntered(MouseEvent evt) {
    PressIcon(this.inii, true);
  }
  
  private void iniiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void capiMouseEntered(MouseEvent evt) {
    PressIcon(this.capi, true);
  }
  
  private void capiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void tapeiMouseEntered(MouseEvent evt) {
    PressIcon(this.tapei, true);
  }
  
  private void tapeiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void paintiMouseEntered(MouseEvent evt) {
    PressIcon(this.painti, true);
  }
  
  private void paintiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void oldiiMouseEntered(MouseEvent evt) {
    PressIcon(this.oldii, true);
  }
  
  private void oldiiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void tilediMouseEntered(MouseEvent evt) {
    PressIcon(this.tiledi, true);
  }
  
  private void tilediMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void pokeiMouseEntered(MouseEvent evt) {
    PressIcon(this.pokei, true);
  }
  
  private void pokeiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void calciMouseEntered(MouseEvent evt) {
    PressIcon(this.calci, true);
  }
  
  private void calciMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void paciMouseEntered(MouseEvent evt) {
    PressIcon(this.paci, true);
  }
  
  private void paciMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void infoiMouseEntered(MouseEvent evt) {
    PressIcon(this.infoi, true);
  }
  
  private void infoiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void webiMouseEntered(MouseEvent evt) {
    PressIcon(this.webi, true);
  }
  
  private void webiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void browsiMouseEntered(MouseEvent evt) {
    PressIcon(this.browsi, true);
  }
  
  private void browsiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void flopyiMouseEntered(MouseEvent evt) {
    PressIcon(this.flopyi, true);
  }
  
  private void flopyiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void radioiMouseEntered(MouseEvent evt) {
    PressIcon(this.radioi, true);
  }
  
  private void radioiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void chatiMouseEntered(MouseEvent evt) {
    PressIcon(this.chati, true);
  }
  
  private void chatiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void faviMouseEntered(MouseEvent evt) {
    PressIcon(this.favi, true);
  }
  
  private void faviMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void dskiMouseEntered(MouseEvent evt) {
    PressIcon(this.dski, true);
  }
  
  private void dskiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void gx4000iMouseEntered(MouseEvent evt) {
    PressIcon(this.gx4000i, true);
  }
  
  private void gx4000iMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void deathiMouseEntered(MouseEvent evt) {
    PressIcon(this.deathi, true);
  }
  
  private void deathiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void bddiMouseEntered(MouseEvent evt) {
    PressIcon(this.bddi, true);
  }
  
  private void bddiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void atariiMouseEntered(MouseEvent evt) {
    PressIcon(this.atarii, true);
  }
  
  private void atariiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void jCheckBox19ActionPerformed(ActionEvent evt) {
    boolean t = jCheckBox19.isSelected();
    Settings.setBoolean("z80_turbo", t);
    GateArray.cpc.setZ80Turbo(t);
    JEMU.z80turbo.setState(t);
  }
  
  private void jMenuItem1ActionPerformed(ActionEvent evt) {
    reArrange();
  }
  
  private void jMenuItem2ActionPerformed(ActionEvent evt) {
    loadWallpaper();
  }
  
  private void jLabel72MousePressed(MouseEvent evt) {
    showStartMenu();
  }
  
  private void quitbuttonMouseReleased(MouseEvent evt) {
    quit();
  }
  
  private void resbuttonActionPerformed(ActionEvent evt) {
    CPC.resetcpc = true;
  }
  
  private void syncbuttonActionPerformed(ActionEvent evt) {
    CPC.resync = true;
  }
  
  private void setbuttonActionPerformed(ActionEvent evt) {
    options.setVisible(true);
  }
  
  private void setbutton3ActionPerformed(ActionEvent evt) {
    JEMU.toggledock = true;
  }
  
  private void desktopMouseClicked(MouseEvent evt) {
    if (this.starttab.isVisible())
      showStartMenu(); 
  }
  
  private void jMenuItem3ActionPerformed(ActionEvent evt) {
    align();
  }
  
  private void iconsAlignActionPerformed(ActionEvent evt) {
    this.alignIcons = this.iconsAlign.isSelected();
    DSettings.setBoolean("align", this.alignIcons);
    if (this.alignIcons)
      align(); 
  }
  
  public void reDraw() {}
  
  private void jLabel73MouseReleased(MouseEvent evt) {
    ld0 = true;
    showStartMenu();
  }
  
  private void jLabel80MouseReleased(MouseEvent evt) {
    ld1 = true;
    showStartMenu();
  }
  
  private void jLabel82MouseReleased(MouseEvent evt) {
    JEMU.loadsnap = true;
    showStartMenu();
  }
  
  private void jLabel83MouseReleased(MouseEvent evt) {
    JEMU.savesnap = true;
    showStartMenu();
  }
  
  private void jLabel84MouseReleased(MouseEvent evt) {
    JEMU.toggledock = true;
    showStartMenu();
  }
  
  private void jLabel87MouseReleased(MouseEvent evt) {
    options.setVisible(true);
    showStartMenu();
  }
  
  private void jLabel88MouseReleased(MouseEvent evt) {
    CPC.resync = true;
    showStartMenu();
  }
  
  private void jLabel89MouseReleased(MouseEvent evt) {
    JEMU.openWebPage("http://cpc-live.com/donate.html");
    showStartMenu();
  }
  
  private void jLabel90MouseReleased(MouseEvent evt) {
    CPC.resetcpc = true;
    showStartMenu();
  }
  
  private void jLabel91MouseReleased(MouseEvent evt) {
    quit();
    showStartMenu();
  }
  
  private void desktopMouseEntered(MouseEvent evt) {
    if (this.starttab.isVisible())
      showStartMenu(); 
  }
  
  private boolean checkRobot(int i) {
    try {
      if (this.fillrobot == null)
        this.fillrobot = new Robot(); 
      this.fillimage[i] = this.fillrobot.createScreenCapture(this.fillrect[i]);
    } catch (Exception exception) {}
    return (this.fillrobot != null);
  }
  
  private void jLabel91MouseEntered(MouseEvent evt) {
    if (this.fillrect[0] == null) {
      this.fillrect[0] = new Rectangle((this.jLabel91.getLocationOnScreen()).x, (this.jLabel91.getLocationOnScreen()).y, this.jLabel91.getWidth(), this.jLabel91.getHeight());
      if (!checkRobot(0))
        return; 
      this.fillimage[0] = this.fillrobot.createScreenCapture(this.fillrect[0]);
    } 
    if (this.fillimage[0] == null)
      return; 
    this.jLabel91.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/quitb.png")));
  }
  
  private void jLabel91MouseExited(MouseEvent evt) {
    if (this.fillimage[0] == null)
      return; 
    this.jLabel91.getGraphics().drawImage(this.fillimage[0], 0, 0, null);
  }
  
  private void jLabel90MouseEntered(MouseEvent evt) {
    if (this.fillrect[1] == null) {
      this.fillrect[1] = new Rectangle((this.jLabel90.getLocationOnScreen()).x, (this.jLabel90.getLocationOnScreen()).y, this.jLabel90.getWidth(), this.jLabel90.getHeight());
      if (!checkRobot(1))
        return; 
      this.fillimage[1] = this.fillrobot.createScreenCapture(this.fillrect[1]);
    } 
    if (this.fillimage[1] == null)
      return; 
    this.jLabel90.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/resetb.png")));
  }
  
  private void jLabel90MouseExited(MouseEvent evt) {
    if (this.fillimage[1] == null)
      return; 
    this.jLabel90.getGraphics().drawImage(this.fillimage[1], 0, 0, null);
  }
  
  private void jLabel89MouseEntered(MouseEvent evt) {
    if (this.fillrect[2] == null) {
      this.fillrect[2] = new Rectangle((this.jLabel89.getLocationOnScreen()).x, (this.jLabel89.getLocationOnScreen()).y, this.jLabel89.getWidth(), this.jLabel89.getHeight());
      if (!checkRobot(2))
        return; 
      this.fillimage[2] = this.fillrobot.createScreenCapture(this.fillrect[2]);
    } 
    if (this.fillimage[2] == null)
      return; 
    this.jLabel89.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/ico/donate_small.gif")));
  }
  
  private void jLabel89MouseExited(MouseEvent evt) {
    if (this.fillimage[2] == null)
      return; 
    this.jLabel89.getGraphics().drawImage(this.fillimage[2], 0, 0, null);
  }
  
  private void jLabel88MouseEntered(MouseEvent evt) {
    if (this.fillrect[3] == null) {
      this.fillrect[3] = new Rectangle((this.jLabel88.getLocationOnScreen()).x, (this.jLabel88.getLocationOnScreen()).y, this.jLabel88.getWidth(), this.jLabel88.getHeight());
      if (!checkRobot(3))
        return; 
      this.fillimage[3] = this.fillrobot.createScreenCapture(this.fillrect[3]);
    } 
    if (this.fillimage[3] == null)
      return; 
    this.jLabel88.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/resyncb.png")));
  }
  
  private void jLabel88MouseExited(MouseEvent evt) {
    if (this.fillimage[3] == null)
      return; 
    this.jLabel88.getGraphics().drawImage(this.fillimage[3], 0, 0, null);
  }
  
  private void jLabel87MouseEntered(MouseEvent evt) {
    if (this.fillrect[4] == null) {
      this.fillrect[4] = new Rectangle((this.jLabel87.getLocationOnScreen()).x, (this.jLabel87.getLocationOnScreen()).y, this.jLabel87.getWidth(), this.jLabel87.getHeight());
      if (!checkRobot(4))
        return; 
      this.fillimage[4] = this.fillrobot.createScreenCapture(this.fillrect[4]);
    } 
    if (this.fillimage[4] == null)
      return; 
    this.jLabel87.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/settingsb.png")));
  }
  
  private void jLabel87MouseExited(MouseEvent evt) {
    if (this.fillimage[4] == null)
      return; 
    this.jLabel87.getGraphics().drawImage(this.fillimage[4], 0, 0, null);
  }
  
  private void jLabel84MouseEntered(MouseEvent evt) {
    if (this.fillrect[5] == null) {
      this.fillrect[5] = new Rectangle((this.jLabel84.getLocationOnScreen()).x, (this.jLabel84.getLocationOnScreen()).y, this.jLabel84.getWidth(), this.jLabel84.getHeight());
      if (!checkRobot(5))
        return; 
      this.fillimage[5] = this.fillrobot.createScreenCapture(this.fillrect[5]);
    } 
    if (this.fillimage[5] == null)
      return; 
    this.jLabel84.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/dock.png")));
  }
  
  private void jLabel84MouseExited(MouseEvent evt) {
    if (this.fillimage[5] == null)
      return; 
    this.jLabel84.getGraphics().drawImage(this.fillimage[5], 0, 0, null);
  }
  
  private void jLabel83MouseEntered(MouseEvent evt) {
    if (this.fillrect[6] == null) {
      this.fillrect[6] = new Rectangle((this.jLabel83.getLocationOnScreen()).x, (this.jLabel83.getLocationOnScreen()).y, this.jLabel83.getWidth(), this.jLabel83.getHeight());
      if (!checkRobot(6))
        return; 
      this.fillimage[6] = this.fillrobot.createScreenCapture(this.fillrect[6]);
    } 
    if (this.fillimage[6] == null)
      return; 
    this.jLabel83.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/sna_save.png")));
  }
  
  private void jLabel83MouseExited(MouseEvent evt) {
    if (this.fillimage[6] == null)
      return; 
    this.jLabel83.getGraphics().drawImage(this.fillimage[6], 0, 0, null);
  }
  
  private void jLabel82MouseEntered(MouseEvent evt) {
    if (this.fillrect[7] == null) {
      this.fillrect[7] = new Rectangle((this.jLabel82.getLocationOnScreen()).x, (this.jLabel82.getLocationOnScreen()).y, this.jLabel82.getWidth(), this.jLabel82.getHeight());
      if (!checkRobot(7))
        return; 
      this.fillimage[7] = this.fillrobot.createScreenCapture(this.fillrect[7]);
    } 
    if (this.fillimage[7] == null)
      return; 
    this.jLabel82.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icons/sna_load.png")));
  }
  
  private void jLabel82MouseExited(MouseEvent evt) {
    if (this.fillimage[7] == null)
      return; 
    this.jLabel82.getGraphics().drawImage(this.fillimage[7], 0, 0, null);
  }
  
  private void jLabel80MouseEntered(MouseEvent evt) {
    if (this.fillrect[8] == null) {
      this.fillrect[8] = new Rectangle((this.jLabel80.getLocationOnScreen()).x, (this.jLabel80.getLocationOnScreen()).y, this.jLabel80.getWidth(), this.jLabel80.getHeight());
      if (!checkRobot(8))
        return; 
      this.fillimage[8] = this.fillrobot.createScreenCapture(this.fillrect[8]);
    } 
    if (this.fillimage[8] == null)
      return; 
    this.jLabel80.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/df1.png")));
  }
  
  private void jLabel80MouseExited(MouseEvent evt) {
    if (this.fillimage[8] == null)
      return; 
    this.jLabel80.getGraphics().drawImage(this.fillimage[8], 0, 0, null);
  }
  
  private void jLabel73MouseEntered(MouseEvent evt) {
    if (this.fillrect[9] == null) {
      this.fillrect[9] = new Rectangle((this.jLabel73.getLocationOnScreen()).x, (this.jLabel73.getLocationOnScreen()).y, this.jLabel73.getWidth(), this.jLabel73.getHeight());
      if (!checkRobot(9))
        return; 
      this.fillimage[9] = this.fillrobot.createScreenCapture(this.fillrect[9]);
    } 
    if (this.fillimage[9] == null)
      return; 
    this.jLabel73.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/icon/df0.png")));
  }
  
  private void jLabel73MouseExited(MouseEvent evt) {
    if (this.fillimage[9] == null)
      return; 
    this.jLabel73.getGraphics().drawImage(this.fillimage[9], 0, 0, null);
  }
  
  private void jComboBox3ItemStateChanged(ItemEvent evt) {
    Settings.set("audio_puffersize", "" + this.puffer[this.jComboBox3.getSelectedIndex()]);
    this.pufferl.setVisible(true);
  }
  
  private void cdiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      setGamesCD(); 
  }
  
  private void cdiMouseEntered(MouseEvent evt) {
    PressIcon(this.cdi, true);
  }
  
  private void cdiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void cdiMousePressed(MouseEvent evt) {
    PressIcon(this.cdi, false);
  }
  
  private void cdiMouseReleased(MouseEvent evt) {
    PressIcon(this.cdi, true);
  }
  
  private void rolandiMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      openRadio(); 
  }
  
  private void rolandiMouseEntered(MouseEvent evt) {
    PressIcon(this.rolandi, true);
  }
  
  private void rolandiMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void rolandiMousePressed(MouseEvent evt) {
    PressIcon(this.rolandi, false);
  }
  
  private void rolandiMouseReleased(MouseEvent evt) {
    PressIcon(this.rolandi, true);
  }
  
  private void tripleSizeItemStateChanged(ItemEvent evt) {
    if (tripleSize.isSelected())
      JEMU.trip = true; 
  }
  
  private void quadSizeItemStateChanged(ItemEvent evt) {
    if (quadSize.isSelected())
      JEMU.quad = true; 
  }
  
  private void pan2MouseReleased(MouseEvent evt) {
    pan1.setBorder(new SoftBevelBorder(0));
    pan2.setBorder(new SoftBevelBorder(0));
    pan3.setBorder(new SoftBevelBorder(0));
    pan4.setBorder(new SoftBevelBorder(0));
    pan5.setBorder(new SoftBevelBorder(0));
    pan6.setBorder(new SoftBevelBorder(0));
    pan7.setBorder(new SoftBevelBorder(0));
    pan8.setBorder(new SoftBevelBorder(0));
    pan9.setBorder(new SoftBevelBorder(0));
    pan10.setBorder(new SoftBevelBorder(0));
    pan11.setBorder(new SoftBevelBorder(0));
    pan12.setBorder(new SoftBevelBorder(0));
    pan13.setBorder(new SoftBevelBorder(0));
    pan14.setBorder(new SoftBevelBorder(0));
    pan15.setBorder(new SoftBevelBorder(0));
    pan16.setBorder(new SoftBevelBorder(0));
    pan17.setBorder(new SoftBevelBorder(0));
    pan18.setBorder(new SoftBevelBorder(0));
    pan19.setBorder(new SoftBevelBorder(0));
    pan20.setBorder(new SoftBevelBorder(0));
    pan21.setBorder(new SoftBevelBorder(0));
    pan22.setBorder(new SoftBevelBorder(0));
    pan23.setBorder(new SoftBevelBorder(0));
    pan24.setBorder(new SoftBevelBorder(0));
    pan25.setBorder(new SoftBevelBorder(0));
    pan26.setBorder(new SoftBevelBorder(0));
    pan27.setBorder(new SoftBevelBorder(0));
    pan28.setBorder(new SoftBevelBorder(0));
    pan29.setBorder(new SoftBevelBorder(0));
    pan30.setBorder(new SoftBevelBorder(0));
    pan31.setBorder(new SoftBevelBorder(0));
    pan32.setBorder(new SoftBevelBorder(0));
    selectedInk = -1;
    if (evt.getSource() == pan1) {
      pan1.setBorder(new SoftBevelBorder(1));
      selectedInk = 0;
    } else if (evt.getSource() == pan2) {
      pan2.setBorder(new SoftBevelBorder(1));
      selectedInk = 1;
    } else if (evt.getSource() == pan3) {
      pan3.setBorder(new SoftBevelBorder(1));
      selectedInk = 2;
    } else if (evt.getSource() == pan4) {
      pan4.setBorder(new SoftBevelBorder(1));
      selectedInk = 3;
    } else if (evt.getSource() == pan5) {
      pan5.setBorder(new SoftBevelBorder(1));
      selectedInk = 4;
    } else if (evt.getSource() == pan6) {
      pan6.setBorder(new SoftBevelBorder(1));
      selectedInk = 5;
    } else if (evt.getSource() == pan7) {
      pan7.setBorder(new SoftBevelBorder(1));
      selectedInk = 6;
    } else if (evt.getSource() == pan8) {
      pan8.setBorder(new SoftBevelBorder(1));
      selectedInk = 7;
    } else if (evt.getSource() == pan9) {
      pan9.setBorder(new SoftBevelBorder(1));
      selectedInk = 8;
    } else if (evt.getSource() == pan10) {
      pan10.setBorder(new SoftBevelBorder(1));
      selectedInk = 9;
    } else if (evt.getSource() == pan11) {
      pan11.setBorder(new SoftBevelBorder(1));
      selectedInk = 10;
    } else if (evt.getSource() == pan12) {
      pan12.setBorder(new SoftBevelBorder(1));
      selectedInk = 11;
    } else if (evt.getSource() == pan13) {
      pan13.setBorder(new SoftBevelBorder(1));
      selectedInk = 12;
    } else if (evt.getSource() == pan14) {
      pan14.setBorder(new SoftBevelBorder(1));
      selectedInk = 13;
    } else if (evt.getSource() == pan15) {
      pan15.setBorder(new SoftBevelBorder(1));
      selectedInk = 14;
    } else if (evt.getSource() == pan16) {
      pan16.setBorder(new SoftBevelBorder(1));
      selectedInk = 15;
    } else if (evt.getSource() == pan17) {
      pan17.setBorder(new SoftBevelBorder(1));
      selectedInk = 16;
    } else if (evt.getSource() == pan18) {
      pan18.setBorder(new SoftBevelBorder(1));
      selectedInk = 17;
    } else if (evt.getSource() == pan19) {
      pan19.setBorder(new SoftBevelBorder(1));
      selectedInk = 18;
    } else if (evt.getSource() == pan20) {
      pan20.setBorder(new SoftBevelBorder(1));
      selectedInk = 19;
    } else if (evt.getSource() == pan21) {
      pan21.setBorder(new SoftBevelBorder(1));
      selectedInk = 20;
    } else if (evt.getSource() == pan22) {
      pan22.setBorder(new SoftBevelBorder(1));
      selectedInk = 21;
    } else if (evt.getSource() == pan23) {
      pan23.setBorder(new SoftBevelBorder(1));
      selectedInk = 22;
    } else if (evt.getSource() == pan24) {
      pan24.setBorder(new SoftBevelBorder(1));
      selectedInk = 23;
    } else if (evt.getSource() == pan25) {
      pan25.setBorder(new SoftBevelBorder(1));
      selectedInk = 24;
    } else if (evt.getSource() == pan26) {
      pan26.setBorder(new SoftBevelBorder(1));
      selectedInk = 25;
    } else if (evt.getSource() == pan27) {
      pan27.setBorder(new SoftBevelBorder(1));
      selectedInk = 26;
    } else if (evt.getSource() == pan28) {
      pan28.setBorder(new SoftBevelBorder(1));
      selectedInk = 27;
    } else if (evt.getSource() == pan29) {
      pan29.setBorder(new SoftBevelBorder(1));
      selectedInk = 28;
    } else if (evt.getSource() == pan30) {
      pan30.setBorder(new SoftBevelBorder(1));
      selectedInk = 29;
    } else if (evt.getSource() == pan31) {
      pan31.setBorder(new SoftBevelBorder(1));
      selectedInk = 30;
    } else if (evt.getSource() == pan32) {
      pan32.setBorder(new SoftBevelBorder(1));
      selectedInk = 31;
    } 
    while (selectedInk < 0) {
      try {
        Thread.sleep(10L);
      } catch (Exception exception) {}
    } 
    updatePalette(false);
  }
  
  private void jSlider3StateChanged(ChangeEvent evt) {
    fieldRed.setText("" + jSlider3.getValue());
    updateCurrent();
    updatePalette(true);
  }
  
  private void jSlider4StateChanged(ChangeEvent evt) {
    fieldGreen.setText("" + jSlider4.getValue());
    updateCurrent();
    updatePalette(true);
  }
  
  private void jSlider5StateChanged(ChangeEvent evt) {
    fieldBlue.setText("" + jSlider5.getValue());
    updateCurrent();
    updatePalette(true);
  }
  
  private void jButton48ActionPerformed(ActionEvent evt) {
    GateArray.resetCPCColours();
    GateArray.writePalette();
    updatePalette(false);
  }
  
  private void fieldRedKeyReleased(KeyEvent evt) {
    if (evt.getKeyCode() == 10)
      try {
        updatePalette(true);
      } catch (Exception exception) {} 
  }
  
  private void fieldGreenKeyReleased(KeyEvent evt) {
    if (evt.getKeyCode() == 10)
      try {
        jSlider3.setValue(Integer.parseInt(fieldRed.getText()));
        jSlider4.setValue(Integer.parseInt(fieldGreen.getText()));
        jSlider5.setValue(Integer.parseInt(fieldBlue.getText()));
        updatePalette(true);
      } catch (Exception exception) {} 
  }
  
  private void fieldBlueKeyReleased(KeyEvent evt) {
    if (evt.getKeyCode() == 10)
      try {
        jSlider3.setValue(Integer.parseInt(fieldRed.getText()));
        jSlider4.setValue(Integer.parseInt(fieldGreen.getText()));
        jSlider5.setValue(Integer.parseInt(fieldBlue.getText()));
        updatePalette(true);
      } catch (Exception exception) {} 
  }
  
  private void rgbKeyReleased(KeyEvent evt) {
    if (evt.getKeyCode() == 10)
      try {
        String c = rgb.getText();
        c = c.replace("#", "");
        if (c.length() != 6) {
          updatePalette(true);
          return;
        } 
        String ar = c.charAt(0) + "" + c.charAt(1);
        String ag = c.charAt(2) + "" + c.charAt(3);
        String ab = c.charAt(4) + "" + c.charAt(5);
        int r = Util.hexValue(ar);
        int g = Util.hexValue(ag);
        int b = Util.hexValue(ab);
        fieldRed.setText("" + r);
        fieldGreen.setText("" + g);
        fieldBlue.setText("" + b);
        jSlider3.setValue(Integer.parseInt(fieldRed.getText()));
        jSlider4.setValue(Integer.parseInt(fieldGreen.getText()));
        jSlider5.setValue(Integer.parseInt(fieldBlue.getText()));
        updatePalette(true);
      } catch (Exception exception) {} 
  }
  
  private void fdcenabledActionPerformed(ActionEvent evt) {
    Settings.setBoolean("fdc_enabled", this.fdcenabled.isSelected());
    GateArray.cpc.fdc.reset();
  }
  
  private void accelerateActionPerformed(ActionEvent evt) {
    Settings.setBoolean("3d_acceleration", !this.accelerate.isSelected());
    (GateArray.cpc.getDisplay()).usepixels = !this.accelerate.isSelected();
  }
  
  private void load4ActionPerformed(ActionEvent evt) {
    GateArray.cpc.loadMagic(0);
  }
  
  private void load5ActionPerformed(ActionEvent evt) {
    GateArray.cpc.loadMagic(1);
  }
  
  private void freeSizeItemStateChanged(ItemEvent evt) {
    if (freeSize.isSelected())
      JEMU.free = true; 
  }
  
  private void rasteriMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() == 2)
      openRasterPaint(); 
  }
  
  private void rasteriMouseEntered(MouseEvent evt) {
    PressIcon(this.rasteri, true);
  }
  
  private void rasteriMouseExited(MouseEvent evt) {
    remBorders();
  }
  
  private void rasteriMousePressed(MouseEvent evt) {
    PressIcon(this.rasteri, false);
  }
  
  private void rasteriMouseReleased(MouseEvent evt) {
    PressIcon(this.rasteri, true);
  }
  
  private void jRadioButton3ActionPerformed(ActionEvent evt) {
    Printer.matrixprinter = false;
    Settings.setBoolean("dmp_printer", false);
  }
  
  private void jRadioButton4ActionPerformed(ActionEvent evt) {
    Printer.matrixprinter = true;
    Settings.setBoolean("dmp_printer", true);
  }
  
  private void chipnoiseActionPerformed(ActionEvent evt) {
    AY_3_8910.liveNoise = this.chipnoise.isSelected();
    Settings.setBoolean("chipnoise", this.chipnoise.isSelected());
  }
  
  private void hideMouseActionPerformed(ActionEvent evt) {
    Settings.setBoolean("hidemouse", hideMouse.isSelected());
  }
  
  private void jLabel96MouseReleased(MouseEvent evt) {
    JEMU.openWebPage("http://www.retrovirtualmachine.org");
  }
  
  private void keyclashActionPerformed(ActionEvent evt) {
    boolean keyclash = !Settings.getBoolean("keyboard_clash", true);
    Settings.setBoolean("keyboard_clash", keyclash);
    GateArray.cpc.getKeyBoard().setKeyClash(keyclash);
  }
  
  private void jMon8ActionPerformed(ActionEvent evt) {
    Settings.set("monitor", "C64");
    Switches.monitormode = 8;
    CPC.resetInk = 1;
    this.MonLabel.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/image/mon6.gif")));
  }
  
  private void jMon8MouseExited(MouseEvent evt) {
    this.jMon8.setVisible(false);
  }
  
  private void jMon8MouseEntered(MouseEvent evt) {
    this.jMon8.setVisible(true);
  }
  
  private void jMon6MouseEntered(MouseEvent evt) {
    this.jMon8.setVisible(true);
  }
  
  private void jMon7MouseEntered(MouseEvent evt) {
    this.jMon8.setVisible(false);
  }
  
  private void jCheckBox20ActionPerformed(ActionEvent evt) {
    JEMU.SF2Mouse = this.jCheckBox20.isSelected();
    Settings.setBoolean("sf3_mouse", JEMU.SF2Mouse);
    GateArray.cpc.reset();
  }
  
  private void memorydisplayActionPerformed(ActionEvent evt) {
    CPCMemory.showram = this.memorydisplay.isSelected();
    Settings.setBoolean("display_mem", CPCMemory.showram);
  }
  
  protected void setGaType() {
    if (this.jRadioButton1.isSelected()) {
      GateArray.setGAType(0);
      Settings.set("ga_type", "40008");
    } 
    if (this.jRadioButton2.isSelected()) {
      GateArray.setGAType(1);
      Settings.set("ga_type", "40010");
    } 
  }
  
  public void checkvideo(int index) {
    System.out.println("Index = " + index);
    switch (index) {
      case 1:
        Settings.setBoolean("filter_dosbox", true);
        Display.filter_dosbox = true;
        Settings.setBoolean("filter_dosboxb", false);
        Display.filter_dosboxb = false;
        Settings.setBoolean("filter_eagle", false);
        Display.filter_eagle = false;
        Settings.setBoolean("filter_advmame", false);
        Display.filter_advmame = false;
        Settings.setBoolean("filter_eagle_smooth", false);
        Display.filter_eagle_smooth = false;
        Settings.setBoolean("filter_advmame_smooth", false);
        Display.filter_advmame_smooth = false;
        Settings.setBoolean("filter_embossed", false);
        Display.filter_embossed = false;
        return;
      case 2:
        Settings.setBoolean("filter_dosbox", false);
        Display.filter_dosbox = false;
        Settings.setBoolean("filter_dosboxb", true);
        Display.filter_dosboxb = true;
        Settings.setBoolean("filter_eagle", false);
        Display.filter_eagle = false;
        Settings.setBoolean("filter_advmame", false);
        Display.filter_advmame = false;
        Settings.setBoolean("filter_eagle_smooth", false);
        Display.filter_eagle_smooth = false;
        Settings.setBoolean("filter_advmame_smooth", false);
        Display.filter_advmame_smooth = false;
        Settings.setBoolean("filter_embossed", false);
        Display.filter_embossed = false;
        return;
      case 3:
        Settings.setBoolean("filter_dosbox", false);
        Display.filter_dosbox = false;
        Settings.setBoolean("filter_dosboxb", false);
        Display.filter_dosboxb = false;
        Settings.setBoolean("filter_eagle", false);
        Display.filter_eagle = false;
        Settings.setBoolean("filter_advmame", true);
        Display.filter_advmame = true;
        Settings.setBoolean("filter_eagle_smooth", false);
        Display.filter_eagle_smooth = false;
        Settings.setBoolean("filter_advmame_smooth", false);
        Display.filter_advmame_smooth = false;
        Settings.setBoolean("filter_embossed", false);
        Display.filter_embossed = false;
        return;
      case 4:
        Settings.setBoolean("filter_dosbox", false);
        Display.filter_dosbox = false;
        Settings.setBoolean("filter_dosboxb", false);
        Display.filter_dosboxb = false;
        Settings.setBoolean("filter_eagle", true);
        Display.filter_eagle = true;
        Settings.setBoolean("filter_advmame", false);
        Display.filter_advmame = false;
        Settings.setBoolean("filter_eagle_smooth", false);
        Display.filter_eagle_smooth = false;
        Settings.setBoolean("filter_advmame_smooth", false);
        Display.filter_advmame_smooth = false;
        Settings.setBoolean("filter_embossed", false);
        Display.filter_embossed = false;
        return;
      case 5:
        Settings.setBoolean("filter_dosbox", false);
        Display.filter_dosbox = false;
        Settings.setBoolean("filter_dosboxb", false);
        Display.filter_dosboxb = false;
        Settings.setBoolean("filter_eagle", false);
        Display.filter_eagle = false;
        Settings.setBoolean("filter_advmame", false);
        Display.filter_advmame = false;
        Settings.setBoolean("filter_eagle_smooth", false);
        Display.filter_eagle_smooth = false;
        Settings.setBoolean("filter_advmame_smooth", true);
        Display.filter_advmame_smooth = true;
        Settings.setBoolean("filter_embossed", false);
        Display.filter_embossed = false;
        return;
      case 6:
        Settings.setBoolean("filter_dosbox", false);
        Display.filter_dosbox = false;
        Settings.setBoolean("filter_dosboxb", false);
        Display.filter_dosboxb = false;
        Settings.setBoolean("filter_eagle", false);
        Display.filter_eagle = false;
        Settings.setBoolean("filter_advmame", false);
        Display.filter_advmame = false;
        Settings.setBoolean("filter_eagle_smooth", true);
        Display.filter_eagle_smooth = true;
        Settings.setBoolean("filter_advmame_smooth", false);
        Display.filter_advmame_smooth = false;
        Settings.setBoolean("filter_embossed", false);
        Display.filter_embossed = false;
        return;
      case 7:
        Settings.setBoolean("filter_dosbox", false);
        Display.filter_dosbox = false;
        Settings.setBoolean("filter_dosboxb", false);
        Display.filter_dosboxb = false;
        Settings.setBoolean("filter_eagle", false);
        Display.filter_eagle = false;
        Settings.setBoolean("filter_advmame", false);
        Display.filter_advmame = false;
        Settings.setBoolean("filter_eagle_smooth", false);
        Display.filter_eagle_smooth = false;
        Settings.setBoolean("filter_advmame_smooth", false);
        Display.filter_advmame_smooth = false;
        Settings.setBoolean("filter_embossed", true);
        Display.filter_embossed = true;
        return;
    } 
    Settings.setBoolean("filter_dosbox", false);
    Display.filter_dosbox = false;
    Settings.setBoolean("filter_dosboxb", false);
    Display.filter_dosboxb = false;
    Settings.setBoolean("filter_eagle", false);
    Display.filter_eagle = false;
    Settings.setBoolean("filter_advmame", false);
    Display.filter_advmame = false;
    Settings.setBoolean("filter_eagle_smooth", false);
    Display.filter_eagle_smooth = false;
    Settings.setBoolean("filter_advmame_smooth", false);
    Display.filter_advmame_smooth = false;
    Settings.setBoolean("filter_embossed", false);
    Display.filter_embossed = false;
  }
  
  private void checkPerformance(boolean set) {
    if (set) {
      Display.lowperformance = this.jCheckBox6.isSelected();
      Settings.setBoolean("lowperformance", Display.lowperformance);
    } else {
      Display.lowperformance = Settings.getBoolean("lowperformance", false);
      this.jCheckBox6.setSelected(Display.lowperformance);
    } 
    this.scanl.setEnabled(!Display.lowperformance);
    if (!Display.lowperformance) {
      this.filterChooser.setEnabled(true);
    } else {
      this.filterChooser.setEnabled(false);
    } 
    this.filter.setEnabled(!Display.lowperformance);
    this.mmask.setEnabled(!Display.lowperformance);
  }
  
  private void changeLook(int index, boolean set) {
    DSettings.set("look", "" + index);
    this.restartj.setVisible(true);
    if (set) {
      setLook(DSettings.get("look", "20"));
      setEmu();
      packed = false;
    } 
  }
  
  private void clearROMs() {
    RSettings.set("lower", "none");
    RSettings.set("upper_0", "none");
    RSettings.set("upper_1", "none");
    RSettings.set("upper_2", "none");
    RSettings.set("upper_3", "none");
    RSettings.set("upper_4", "none");
    RSettings.set("upper_5", "none");
    RSettings.set("upper_6", "none");
    RSettings.set("upper_7", "none");
    RSettings.set("upper_8", "none");
    RSettings.set("upper_9", "none");
    RSettings.set("upper_A", "none");
    RSettings.set("upper_B", "none");
    RSettings.set("upper_C", "none");
    RSettings.set("upper_D", "none");
    RSettings.set("upper_E", "none");
    RSettings.set("upper_F", "none");
  }
  
  private void reDoRoms() {
    this.rom[0] = RSettings.get("lower", "none");
    this.rom[1] = RSettings.get("upper_0", "none");
    this.rom[2] = RSettings.get("upper_1", "none");
    this.rom[3] = RSettings.get("upper_2", "none");
    this.rom[4] = RSettings.get("upper_3", "none");
    this.rom[5] = RSettings.get("upper_4", "none");
    this.rom[6] = RSettings.get("upper_5", "none");
    this.rom[7] = RSettings.get("upper_6", "none");
    this.rom[8] = RSettings.get("upper_7", "none");
    this.rom[9] = RSettings.get("upper_8", "none");
    this.rom[10] = RSettings.get("upper_9", "none");
    this.rom[11] = RSettings.get("upper_A", "none");
    this.rom[12] = RSettings.get("upper_B", "none");
    this.rom[13] = RSettings.get("upper_C", "none");
    this.rom[14] = RSettings.get("upper_D", "none");
    this.rom[15] = RSettings.get("upper_E", "none");
    this.rom[16] = RSettings.get("upper_F", "none");
    for (int i = 0; i < this.rom.length; i++)
      reBuildRoms(i); 
  }
  
  private void set464(boolean amsdos) {
    clearROMs();
    RSettings.set("lower", "OS464.ROM");
    RSettings.set("upper_0", "BASIC1-0.ROM");
    if (amsdos) {
      this.fdcenabled.setSelected(true);
      Settings.setBoolean("fdc_enabled", true);
      RSettings.set("upper_7", "AMSDOS.ROM");
    } else {
      this.fdcenabled.setSelected(false);
      Settings.setBoolean("fdc_enabled", false);
    } 
    reDoRoms();
  }
  
  private void set664() {
    this.fdcenabled.setSelected(true);
    Settings.setBoolean("fdc_enabled", true);
    clearROMs();
    RSettings.set("lower", "OS664.ROM");
    RSettings.set("upper_0", "BASIC664.ROM");
    RSettings.set("upper_7", "AMSDOS.ROM");
    reDoRoms();
  }
  
  private void set6128() {
    this.fdcenabled.setSelected(true);
    Settings.setBoolean("fdc_enabled", true);
    clearROMs();
    RSettings.set("lower", "OS6128.ROM");
    RSettings.set("upper_0", "BASIC1-1.ROM");
    RSettings.set("upper_7", "AMSDOS.ROM");
    reDoRoms();
  }
  
  private void setKCC(boolean kccdos) {
    clearROMs();
    RSettings.set("lower", "KCCOS.ROM");
    RSettings.set("upper_0", "KCCBAS.ROM");
    if (kccdos) {
      this.fdcenabled.setSelected(true);
      Settings.setBoolean("fdc_enabled", true);
      RSettings.set("upper_7", "DEPROMA.ROM");
    } else {
      this.fdcenabled.setSelected(false);
      Settings.setBoolean("fdc_enabled", false);
    } 
    reDoRoms();
  }
  
  private void setFos(boolean bootable) {
    this.fdcenabled.setSelected(true);
    Settings.setBoolean("fdc_enabled", true);
    clearROMs();
    RSettings.set("lower", "OS6128.ROM");
    if (bootable) {
      RSettings.set("upper_0", "FOSC-E-A.ROM");
    } else {
      RSettings.set("upper_0", "BASIC1-1.ROM");
    } 
    RSettings.set("upper_7", "AMSDOS.ROM");
    RSettings.set("upper_9", "Wallpaper_1.ROM");
    RSettings.set("upper_A", "FOSC-E-A.ROM");
    RSettings.set("upper_B", "FOSC-E-B.ROM");
    RSettings.set("upper_C", "FOSC-E-C.ROM");
    RSettings.set("upper_D", "FOSC-E-D.ROM");
    RSettings.set("upper_E", "ROManager.ROM");
    RSettings.set("upper_F", "TOOL-ROM-ENG.ROM");
    reDoRoms();
  }
  
  private void setSos(boolean bootable) {
    this.fdcenabled.setSelected(true);
    Settings.setBoolean("fdc_enabled", true);
    clearROMs();
    RSettings.set("lower", "OS6128.ROM");
    RSettings.set("upper_0", "BASIC1-1.ROM");
    RSettings.set("upper_7", "AMSDOS.ROM");
    RSettings.set("upper_8", "sym-romA.ROM");
    if (bootable)
      RSettings.set("upper_8", "sym-romAboot.ROM"); 
    RSettings.set("upper_9", "sym-romB.ROM");
    RSettings.set("upper_A", "sym-romC.ROM");
    RSettings.set("upper_B", "sym-romD.ROM");
    reDoRoms();
  }
  
  private void setVols() {
    Settings.setBoolean("hacker_kay_output", Switches.KAYOut);
    Settings.setBoolean("cpce95_output", Switches.CPCE95);
    Settings.setBoolean("vsoft_output", Switches.VSoftOutput);
    Settings.setBoolean("linear_sound", Switches.linear);
    Settings.setBoolean("lion_output", Switches.LION);
    Settings.setBoolean("hacker_kay_II_output", Switches.HACKER);
    this.vdig.change = true;
  }
  
  static String[] addToEmu = null;
  
  FileDialog romdialog;
  
  String[] slots;
  
  boolean causedalarm;
  
  int clockt;
  
  int checktape;
  
  int xd;
  
  int yd;
  
  boolean moved;
  
  boolean panel;
  
  int memo;
  
  boolean reg;
  
  JFileChooser chooser;
  
  public static void main(String[] args) {
    Switches.executable = true;
    Desktop desk = new Desktop();
    desk.setVisible(true);
    packed = false;
  }
  
  protected String getName(String name) {
    if (name == null)
      return "none"; 
    boolean asterisk = false;
    int cutter = 0;
    try {
      for (int i = 0; i < name.length(); i++) {
        if (name.charAt(i) == '/' || name.charAt(i) == '*' || name.charAt(i) == '\\') {
          cutter = i + 1;
          asterisk = true;
        } 
      } 
      name = name.substring(cutter);
      if (asterisk)
        name = "*" + name; 
      return name;
    } catch (Exception exception) {
      return "*ERROR*";
    } 
  }
  
  protected void addListener() {
    this.sysselect.addActionListener(this);
    this.loROM.addActionListener(this);
    this.up0.addActionListener(this);
    this.up1.addActionListener(this);
    this.up2.addActionListener(this);
    this.up3.addActionListener(this);
    this.up4.addActionListener(this);
    this.up5.addActionListener(this);
    this.up6.addActionListener(this);
    this.up7.addActionListener(this);
    this.up8.addActionListener(this);
    this.up9.addActionListener(this);
    this.up10.addActionListener(this);
    this.up11.addActionListener(this);
    this.up12.addActionListener(this);
    this.up13.addActionListener(this);
    this.up14.addActionListener(this);
    this.up15.addActionListener(this);
  }
  
  protected void removeListener() {
    this.sysselect.removeActionListener(this);
    this.loROM.removeActionListener(this);
    this.up0.removeActionListener(this);
    this.up1.removeActionListener(this);
    this.up2.removeActionListener(this);
    this.up3.removeActionListener(this);
    this.up4.removeActionListener(this);
    this.up5.removeActionListener(this);
    this.up6.removeActionListener(this);
    this.up7.removeActionListener(this);
    this.up8.removeActionListener(this);
    this.up9.removeActionListener(this);
    this.up10.removeActionListener(this);
    this.up11.removeActionListener(this);
    this.up12.removeActionListener(this);
    this.up13.removeActionListener(this);
    this.up14.removeActionListener(this);
    this.up15.removeActionListener(this);
  }
  
  protected void buildRoms() {
    int i;
    for (i = 0; i < this.helper.systems.length; i++)
      this.sysselect.addItem(this.helper.systems[i]); 
    this.rom = new String[17];
    this.loroms = new String[this.helper.LowerROMs.length];
    this.rom[0] = RSettings.get("lower", "none");
    this.loroms = this.helper.LowerROMs;
    this.upr0 = new String[this.helper.UpperROMs.length];
    this.upr1 = new String[this.helper.UpperROMs.length];
    this.upr2 = new String[this.helper.UpperROMs.length];
    this.upr3 = new String[this.helper.UpperROMs.length];
    this.upr4 = new String[this.helper.UpperROMs.length];
    this.upr5 = new String[this.helper.UpperROMs.length];
    this.upr6 = new String[this.helper.UpperROMs.length];
    this.upr7 = new String[this.helper.UpperROMs.length];
    this.upr8 = new String[this.helper.UpperROMs.length];
    this.upr9 = new String[this.helper.UpperROMs.length];
    this.upr10 = new String[this.helper.UpperROMs.length];
    this.upr11 = new String[this.helper.UpperROMs.length];
    this.upr12 = new String[this.helper.UpperROMs.length];
    this.upr13 = new String[this.helper.UpperROMs.length];
    this.upr14 = new String[this.helper.UpperROMs.length];
    this.upr15 = new String[this.helper.UpperROMs.length];
    for (i = 0; i < this.helper.UpperROMs.length; i++) {
      this.upr0[i] = this.helper.UpperROMs[i];
      this.upr1[i] = this.helper.UpperROMs[i];
      this.upr2[i] = this.helper.UpperROMs[i];
      this.upr3[i] = this.helper.UpperROMs[i];
      this.upr4[i] = this.helper.UpperROMs[i];
      this.upr5[i] = this.helper.UpperROMs[i];
      this.upr6[i] = this.helper.UpperROMs[i];
      this.upr7[i] = this.helper.UpperROMs[i];
      this.upr8[i] = this.helper.UpperROMs[i];
      this.upr9[i] = this.helper.UpperROMs[i];
      this.upr10[i] = this.helper.UpperROMs[i];
      this.upr11[i] = this.helper.UpperROMs[i];
      this.upr12[i] = this.helper.UpperROMs[i];
      this.upr13[i] = this.helper.UpperROMs[i];
      this.upr14[i] = this.helper.UpperROMs[i];
      this.upr15[i] = this.helper.UpperROMs[i];
    } 
    this.loroms[this.loroms.length - 1] = getName(this.rom[0]);
    for (i = 0; i < this.loroms.length; i++) {
      this.loROM.addItem(this.loroms[i]);
      if (this.rom[0].endsWith(this.loroms[i].substring(1)))
        this.loROM.setSelectedIndex(i); 
    } 
    this.rom[1] = RSettings.get("upper_0", "none");
    this.rom[2] = RSettings.get("upper_1", "none");
    this.rom[3] = RSettings.get("upper_2", "none");
    this.rom[4] = RSettings.get("upper_3", "none");
    this.rom[5] = RSettings.get("upper_4", "none");
    this.rom[6] = RSettings.get("upper_5", "none");
    this.rom[7] = RSettings.get("upper_6", "none");
    this.rom[8] = RSettings.get("upper_7", "none");
    this.rom[9] = RSettings.get("upper_8", "none");
    this.rom[10] = RSettings.get("upper_9", "none");
    this.rom[11] = RSettings.get("upper_A", "none");
    this.rom[12] = RSettings.get("upper_B", "none");
    this.rom[13] = RSettings.get("upper_C", "none");
    this.rom[14] = RSettings.get("upper_D", "none");
    this.rom[15] = RSettings.get("upper_E", "none");
    this.rom[16] = RSettings.get("upper_F", "none");
    this.upr0[this.upr0.length - 1] = getName(this.rom[1]);
    this.upr1[this.upr0.length - 1] = getName(this.rom[2]);
    this.upr2[this.upr0.length - 1] = getName(this.rom[3]);
    this.upr3[this.upr0.length - 1] = getName(this.rom[4]);
    this.upr4[this.upr0.length - 1] = getName(this.rom[5]);
    this.upr5[this.upr0.length - 1] = getName(this.rom[6]);
    this.upr6[this.upr0.length - 1] = getName(this.rom[7]);
    this.upr7[this.upr7.length - 1] = getName(this.rom[8]);
    this.upr8[this.upr8.length - 1] = getName(this.rom[9]);
    this.upr9[this.upr9.length - 1] = getName(this.rom[10]);
    this.upr10[this.upr10.length - 1] = getName(this.rom[11]);
    this.upr11[this.upr11.length - 1] = getName(this.rom[12]);
    this.upr12[this.upr12.length - 1] = getName(this.rom[13]);
    this.upr13[this.upr13.length - 1] = getName(this.rom[14]);
    this.upr14[this.upr14.length - 1] = getName(this.rom[15]);
    this.upr15[this.upr15.length - 1] = getName(this.rom[16]);
    for (i = 0; i < this.upr0.length; i++) {
      this.up0.addItem(this.upr0[i]);
      this.up1.addItem(this.upr1[i]);
      this.up2.addItem(this.upr2[i]);
      this.up3.addItem(this.upr3[i]);
      this.up4.addItem(this.upr4[i]);
      this.up5.addItem(this.upr5[i]);
      this.up6.addItem(this.upr6[i]);
      this.up7.addItem(this.upr7[i]);
      this.up8.addItem(this.upr8[i]);
      this.up9.addItem(this.upr9[i]);
      this.up10.addItem(this.upr10[i]);
      this.up11.addItem(this.upr11[i]);
      this.up12.addItem(this.upr12[i]);
      this.up13.addItem(this.upr13[i]);
      this.up14.addItem(this.upr14[i]);
      this.up15.addItem(this.upr15[i]);
      if (this.rom[1].endsWith(this.upr0[i].substring(1)))
        this.up0.setSelectedIndex(i); 
      if (this.rom[2].endsWith(this.upr1[i].substring(1)))
        this.up1.setSelectedIndex(i); 
      if (this.rom[3].endsWith(this.upr2[i].substring(1)))
        this.up2.setSelectedIndex(i); 
      if (this.rom[4].endsWith(this.upr3[i].substring(1)))
        this.up3.setSelectedIndex(i); 
      if (this.rom[5].endsWith(this.upr4[i].substring(1)))
        this.up4.setSelectedIndex(i); 
      if (this.rom[6].endsWith(this.upr5[i].substring(1)))
        this.up5.setSelectedIndex(i); 
      if (this.rom[7].endsWith(this.upr6[i].substring(1)))
        this.up6.setSelectedIndex(i); 
      if (this.rom[8].endsWith(this.upr7[i].substring(1)))
        this.up7.setSelectedIndex(i); 
      if (this.rom[9].endsWith(this.upr8[i].substring(1)))
        this.up8.setSelectedIndex(i); 
      if (this.rom[10].endsWith(this.upr9[i].substring(1)))
        this.up9.setSelectedIndex(i); 
      if (this.rom[11].endsWith(this.upr10[i].substring(1)))
        this.up10.setSelectedIndex(i); 
      if (this.rom[12].endsWith(this.upr11[i].substring(1)))
        this.up11.setSelectedIndex(i); 
      if (this.rom[13].endsWith(this.upr12[i].substring(1)))
        this.up12.setSelectedIndex(i); 
      if (this.rom[14].endsWith(this.upr13[i].substring(1)))
        this.up13.setSelectedIndex(i); 
      if (this.rom[15].endsWith(this.upr14[i].substring(1)))
        this.up14.setSelectedIndex(i); 
      if (this.rom[16].endsWith(this.upr15[i].substring(1)))
        this.up15.setSelectedIndex(i); 
    } 
    updateROMComboBoxes();
    addListener();
  }
  
  private void updateROMComboBoxes() {
    if (this.loROM.getSelectedIndex() == 1 && this.up0.getSelectedIndex() == 1 && this.up1.getSelectedIndex() == 0 && this.up2.getSelectedIndex() == 0 && this.up3.getSelectedIndex() == 0 && this.up4.getSelectedIndex() == 0 && this.up5.getSelectedIndex() == 0 && this.up6.getSelectedIndex() == 0 && this.up8.getSelectedIndex() == 0 && this.up9.getSelectedIndex() == 0 && this.up10.getSelectedIndex() == 0 && this.up11.getSelectedIndex() == 0 && this.up12.getSelectedIndex() == 0 && this.up13.getSelectedIndex() == 0 && this.up14.getSelectedIndex() == 0 && (this.up15.getSelectedIndex() == 0 || !this.up15.isEnabled()))
      if (this.up7.getSelectedIndex() == 5) {
        this.sysselect.setSelectedIndex(2);
      } else if (this.up7.getSelectedIndex() == 0) {
        this.sysselect.setSelectedIndex(1);
      } else {
        this.sysselect.setSelectedIndex(0);
      }  
    if (this.loROM.getSelectedIndex() == 2 && this.up0.getSelectedIndex() == 2 && this.up1.getSelectedIndex() == 0 && this.up2.getSelectedIndex() == 0 && this.up3.getSelectedIndex() == 0 && this.up4.getSelectedIndex() == 0 && this.up5.getSelectedIndex() == 0 && this.up6.getSelectedIndex() == 0 && this.up8.getSelectedIndex() == 0 && this.up9.getSelectedIndex() == 0 && this.up10.getSelectedIndex() == 0 && this.up11.getSelectedIndex() == 0 && this.up12.getSelectedIndex() == 0 && this.up13.getSelectedIndex() == 0 && this.up14.getSelectedIndex() == 0 && (this.up15.getSelectedIndex() == 0 || !this.up15.isEnabled())) {
      if (this.up7.getSelectedIndex() == 5)
        this.sysselect.setSelectedIndex(3); 
      this.sysselect.setSelectedIndex(0);
    } 
    if (this.loROM.getSelectedIndex() == 3 && this.up0.getSelectedIndex() == 3 && this.up1.getSelectedIndex() == 0 && this.up2.getSelectedIndex() == 0 && this.up3.getSelectedIndex() == 0 && this.up4.getSelectedIndex() == 0 && this.up5.getSelectedIndex() == 0 && this.up6.getSelectedIndex() == 0 && this.up8.getSelectedIndex() == 0 && this.up9.getSelectedIndex() == 0 && this.up10.getSelectedIndex() == 0 && this.up11.getSelectedIndex() == 0 && this.up12.getSelectedIndex() == 0 && this.up13.getSelectedIndex() == 0 && this.up14.getSelectedIndex() == 0 && (this.up15.getSelectedIndex() == 0 || !this.up15.isEnabled()))
      if (this.up7.getSelectedIndex() == 5) {
        this.sysselect.setSelectedIndex(4);
      } else {
        this.sysselect.setSelectedIndex(0);
      }  
    if (this.loROM.getSelectedIndex() == 4 && this.up0.getSelectedIndex() == 4 && this.up1.getSelectedIndex() == 0 && this.up2.getSelectedIndex() == 0 && this.up3.getSelectedIndex() == 0 && this.up4.getSelectedIndex() == 0 && this.up5.getSelectedIndex() == 0 && this.up6.getSelectedIndex() == 0 && this.up8.getSelectedIndex() == 0 && this.up9.getSelectedIndex() == 0 && this.up10.getSelectedIndex() == 0 && this.up11.getSelectedIndex() == 0 && this.up12.getSelectedIndex() == 0 && this.up13.getSelectedIndex() == 0 && this.up14.getSelectedIndex() == 0 && (this.up15.getSelectedIndex() == 0 || !this.up15.isEnabled()))
      if (this.up7.getSelectedIndex() == 7) {
        this.sysselect.setSelectedIndex(6);
      } else if (this.up7.getSelectedIndex() == 0) {
        this.sysselect.setSelectedIndex(5);
      } else {
        this.sysselect.setSelectedIndex(0);
      }  
    if (this.loROM.getSelectedIndex() == 3 && (this.up0.getSelectedIndex() == 3 || this.up0.getSelectedIndex() == 24) && this.up2.getSelectedIndex() == 0 && this.up3.getSelectedIndex() == 0 && this.up4.getSelectedIndex() == 0 && this.up5.getSelectedIndex() == 0 && this.up6.getSelectedIndex() == 0 && this.up8.getSelectedIndex() == 0 && this.up9.getSelectedIndex() == 0 && this.up10.getSelectedIndex() == 24 && this.up11.getSelectedIndex() == 25 && this.up12.getSelectedIndex() == 26 && this.up13.getSelectedIndex() == 27 && this.up14.getSelectedIndex() == 0 && (this.up15.getSelectedIndex() == 0 || !this.up15.isEnabled()))
      if (this.up7.getSelectedIndex() == 5) {
        if (this.up0.getSelectedIndex() == 24) {
          this.sysselect.setSelectedIndex(8);
        } else {
          this.sysselect.setSelectedIndex(7);
        } 
      } else {
        this.sysselect.setSelectedIndex(0);
      }  
    if (this.loROM.getSelectedIndex() == 3 && this.up0.getSelectedIndex() == 3 && this.up2.getSelectedIndex() == 0 && this.up3.getSelectedIndex() == 0 && this.up4.getSelectedIndex() == 0 && this.up5.getSelectedIndex() == 0 && this.up6.getSelectedIndex() == 0 && (this.up8.getSelectedIndex() == 16 || this.up8.getSelectedIndex() == 17) && this.up9.getSelectedIndex() == 18 && this.up10.getSelectedIndex() == 19 && this.up11.getSelectedIndex() == 20 && this.up12.getSelectedIndex() == 0 && this.up13.getSelectedIndex() == 0 && this.up14.getSelectedIndex() == 0 && (this.up15.getSelectedIndex() == 0 || !this.up15.isEnabled()))
      if (this.up7.getSelectedIndex() == 5) {
        if (this.up8.getSelectedIndex() == 16) {
          this.sysselect.setSelectedIndex(10);
        } else {
          this.sysselect.setSelectedIndex(9);
        } 
      } else {
        this.sysselect.setSelectedIndex(0);
      }  
  }
  
  private void loadRom(int slot) {
    if (this.romdialog == null)
      this.romdialog = new FileDialog(this, "Open ROM file...", 0); 
    this.romdialog.setVisible(true);
    String filename = this.romdialog.getFile();
    if (filename != null) {
      filename = "*" + this.romdialog.getDirectory() + this.romdialog.getFile();
      switch (slot) {
        case 0:
          RSettings.set("lower", filename);
          this.rom[0] = filename;
          this.loroms[this.loroms.length - 1] = getName(this.rom[0]);
          break;
        case 1:
          RSettings.set("upper_0", filename);
          this.rom[1] = filename;
          this.upr0[this.upr0.length - 1] = getName(this.rom[1]);
          break;
        case 2:
          RSettings.set("upper_1", filename);
          this.rom[2] = filename;
          this.upr1[this.upr1.length - 1] = getName(this.rom[2]);
          break;
        case 3:
          RSettings.set("upper_2", filename);
          this.rom[3] = filename;
          this.upr2[this.upr2.length - 1] = getName(this.rom[3]);
          break;
        case 4:
          RSettings.set("upper_3", filename);
          this.rom[4] = filename;
          this.upr3[this.upr3.length - 1] = getName(this.rom[4]);
          break;
        case 5:
          RSettings.set("upper_4", filename);
          this.rom[5] = filename;
          this.upr4[this.upr4.length - 1] = getName(this.rom[5]);
          break;
        case 6:
          RSettings.set("upper_5", filename);
          this.rom[6] = filename;
          this.upr5[this.upr5.length - 1] = getName(this.rom[6]);
          break;
        case 7:
          RSettings.set("upper_6", filename);
          this.rom[7] = filename;
          this.upr6[this.upr6.length - 1] = getName(this.rom[7]);
          break;
        case 8:
          RSettings.set("upper_7", filename);
          this.rom[8] = filename;
          this.upr7[this.upr7.length - 1] = getName(this.rom[8]);
          break;
        case 9:
          RSettings.set("upper_8", filename);
          this.rom[9] = filename;
          this.upr8[this.upr8.length - 1] = getName(this.rom[9]);
          break;
        case 10:
          RSettings.set("upper_9", filename);
          this.rom[10] = filename;
          this.upr9[this.upr9.length - 1] = getName(this.rom[10]);
          break;
        case 11:
          RSettings.set("upper_A", filename);
          this.rom[11] = filename;
          this.upr10[this.upr10.length - 1] = getName(this.rom[11]);
          break;
        case 12:
          RSettings.set("upper_B", filename);
          this.rom[12] = filename;
          this.upr11[this.upr11.length - 1] = getName(this.rom[12]);
          break;
        case 13:
          RSettings.set("upper_C", filename);
          this.rom[13] = filename;
          this.upr12[this.upr12.length - 1] = getName(this.rom[13]);
          break;
        case 14:
          RSettings.set("upper_D", filename);
          this.rom[14] = filename;
          this.upr13[this.upr13.length - 1] = getName(this.rom[14]);
          break;
        case 15:
          RSettings.set("upper_E", filename);
          this.rom[15] = filename;
          this.upr14[this.upr14.length - 1] = getName(this.rom[15]);
          break;
        case 16:
          RSettings.set("upper_F", filename);
          this.rom[16] = filename;
          this.upr15[this.upr15.length - 1] = getName(this.rom[16]);
          break;
        default:
          return;
      } 
    } else {
      switch (slot) {
        case 0:
          RSettings.set("lower", "none");
          this.rom[slot] = "none";
          break;
        default:
          RSettings.set("upper_" + this.slots[slot - 1], "none");
          this.rom[slot] = "none";
          break;
      } 
    } 
    reBuildRoms(slot);
  }
  
  protected void setCName(int name) {
    Settings.set("computername", "" + name);
    Switches.computername = name;
    JEMU.setRoms = true;
  }
  
  protected void setMem(int mem) {
    switch (mem) {
      case 0:
        Settings.set("memory", "TYPE_64K");
        Settings.setBoolean("memory_4mb", false);
        break;
      case 1:
        Settings.set("memory", "TYPE_128K");
        Settings.setBoolean("memory_4mb", false);
        break;
      case 2:
        Settings.set("memory", "TYPE_SILICON_DISC");
        Settings.setBoolean("memory_4mb", false);
        break;
      case 3:
        Settings.set("memory", "TYPE_256K");
        Settings.setBoolean("memory_4mb", false);
        break;
      case 4:
        Settings.set("memory", "TYPE_512K");
        Settings.setBoolean("memory_4mb", false);
        break;
      case 5:
        Settings.set("memory", "TYPE_512K");
        Settings.setBoolean("memory_4mb", true);
        break;
    } 
    Switches.Memory = Settings.get("memory", "TYPE_512K");
    JEMU.setRoms = true;
  }
  
  protected void reBuildRoms(int slot) {
    int i;
    removeListener();
    switch (slot) {
      case 0:
        this.loROM.removeAllItems();
        for (i = 0; i < this.loroms.length; i++) {
          this.loROM.addItem(this.loroms[i]);
          if (this.rom[0].endsWith(this.loroms[i].substring(2)))
            this.loROM.setSelectedIndex(i); 
        } 
        break;
      case 1:
        this.up0.removeAllItems();
        for (i = 0; i < this.upr0.length; i++) {
          this.up0.addItem(this.upr0[i]);
          if (this.rom[1].endsWith(this.upr0[i].substring(2)))
            this.up0.setSelectedIndex(i); 
        } 
        break;
      case 2:
        this.up1.removeAllItems();
        for (i = 0; i < this.upr1.length; i++) {
          this.up1.addItem(this.upr1[i]);
          if (this.rom[2].endsWith(this.upr1[i].substring(2)))
            this.up1.setSelectedIndex(i); 
        } 
        break;
      case 3:
        this.up2.removeAllItems();
        for (i = 0; i < this.upr2.length; i++) {
          this.up2.addItem(this.upr2[i]);
          if (this.rom[3].endsWith(this.upr2[i].substring(2)))
            this.up2.setSelectedIndex(i); 
        } 
        break;
      case 4:
        this.up3.removeAllItems();
        for (i = 0; i < this.upr3.length; i++) {
          this.up3.addItem(this.upr3[i]);
          if (this.rom[4].endsWith(this.upr3[i].substring(2)))
            this.up3.setSelectedIndex(i); 
        } 
        break;
      case 5:
        this.up4.removeAllItems();
        for (i = 0; i < this.upr4.length; i++) {
          this.up4.addItem(this.upr4[i]);
          if (this.rom[5].endsWith(this.upr4[i].substring(2)))
            this.up4.setSelectedIndex(i); 
        } 
        break;
      case 6:
        this.up5.removeAllItems();
        for (i = 0; i < this.upr5.length; i++) {
          this.up5.addItem(this.upr5[i]);
          if (this.rom[6].endsWith(this.upr5[i].substring(2)))
            this.up5.setSelectedIndex(i); 
        } 
        break;
      case 7:
        this.up6.removeAllItems();
        for (i = 0; i < this.upr6.length; i++) {
          this.up6.addItem(this.upr6[i]);
          if (this.rom[7].endsWith(this.upr6[i].substring(2)))
            this.up6.setSelectedIndex(i); 
        } 
        break;
      case 8:
        this.up7.removeAllItems();
        for (i = 0; i < this.upr7.length; i++) {
          this.up7.addItem(this.upr7[i]);
          if (this.rom[8].endsWith(this.upr7[i].substring(2)))
            this.up7.setSelectedIndex(i); 
        } 
        break;
      case 9:
        this.up8.removeAllItems();
        for (i = 0; i < this.upr8.length; i++) {
          this.up8.addItem(this.upr8[i]);
          if (this.rom[9].endsWith(this.upr8[i].substring(2)))
            this.up8.setSelectedIndex(i); 
        } 
        break;
      case 10:
        this.up9.removeAllItems();
        for (i = 0; i < this.upr9.length; i++) {
          this.up9.addItem(this.upr9[i]);
          if (this.rom[10].endsWith(this.upr9[i].substring(2)))
            this.up9.setSelectedIndex(i); 
        } 
        break;
      case 11:
        this.up10.removeAllItems();
        for (i = 0; i < this.upr10.length; i++) {
          this.up10.addItem(this.upr10[i]);
          if (this.rom[11].endsWith(this.upr10[i].substring(2)))
            this.up10.setSelectedIndex(i); 
        } 
        break;
      case 12:
        this.up11.removeAllItems();
        for (i = 0; i < this.upr11.length; i++) {
          this.up11.addItem(this.upr11[i]);
          if (this.rom[12].endsWith(this.upr11[i].substring(2)))
            this.up11.setSelectedIndex(i); 
        } 
        break;
      case 13:
        this.up12.removeAllItems();
        for (i = 0; i < this.upr12.length; i++) {
          this.up12.addItem(this.upr12[i]);
          if (this.rom[13].endsWith(this.upr12[i].substring(2)))
            this.up12.setSelectedIndex(i); 
        } 
        break;
      case 14:
        this.up13.removeAllItems();
        for (i = 0; i < this.upr13.length; i++) {
          this.up13.addItem(this.upr13[i]);
          if (this.rom[14].endsWith(this.upr13[i].substring(2)))
            this.up13.setSelectedIndex(i); 
        } 
        break;
      case 15:
        this.up14.removeAllItems();
        for (i = 0; i < this.upr14.length; i++) {
          this.up14.addItem(this.upr14[i]);
          if (this.rom[15].endsWith(this.upr14[i].substring(2)))
            this.up14.setSelectedIndex(i); 
        } 
        break;
      case 16:
        this.up15.removeAllItems();
        for (i = 0; i < this.upr15.length; i++) {
          this.up15.addItem(this.upr15[i]);
          if (this.rom[16].endsWith(this.upr15[i].substring(2)))
            this.up15.setSelectedIndex(i); 
        } 
        break;
    } 
    addListener();
  }
  
  public void setAlarm(boolean hours, boolean up) {
    if (!hours) {
      if (up && this.almin < 59) {
        this.almin++;
      } else if (up) {
        this.almin = 0;
      } 
      if (!up && this.almin > 0) {
        this.almin--;
      } else if (!up) {
        this.almin = 59;
      } 
    } else {
      if (up && this.alhour < 23) {
        this.alhour++;
      } else if (up) {
        this.alhour = 0;
      } 
      if (!up && this.alhour > 0) {
        this.alhour--;
      } else if (!up) {
        this.alhour = 23;
      } 
    } 
    this.amin = "" + this.almin;
    if (this.amin.length() < 2)
      this.amin = "0" + this.amin; 
    this.ahour = "" + this.alhour;
    if (this.ahour.length() < 2)
      this.ahour = "0" + this.ahour; 
    this.alarmmin.setText(this.amin);
    this.alarmhour.setText(this.ahour);
  }
  
  public void checkSet() {
    if (this.enable) {
      this.enable = false;
    } else {
      this.enable = true;
    } 
    if (this.enable) {
      this.jButton16.setBackground(Color.GREEN);
    } else {
      this.jButton16.setBackground((Color)null);
    } 
    this.subhour.setEnabled(this.enable);
    this.alarmhour.setEnabled(this.enable);
    this.addhour.setEnabled(this.enable);
    this.submin.setEnabled(this.enable);
    this.alarmmin.setEnabled(this.enable);
    this.addmin.setEnabled(this.enable);
  }
  
  public void setAlarmPanel() {
    if (!this.alarmenabled) {
      this.alarmpanel.setBackground(new Color(104, 127, 133));
      this.timedisplay.setForeground(new Color(80, 80, 80));
      this.date.setForeground(new Color(80, 80, 80));
    } else {
      this.alarmpanel.setBackground(new Color(184, 207, 229));
      this.timedisplay.setForeground(new Color(16, 16, 16));
      this.date.setForeground(new Color(16, 16, 16));
    } 
  }
  
  public void checkAlarm() {
    this.causedalarm = false;
    this.alarmenabled = this.jToggleButton1.isSelected();
    System.out.println("Alarm is " + this.alarmenabled);
    if (this.alarmenabled) {
      this.alarmenable.setText(this.alarmon);
      this.jToggleButton1.setBackground(Color.GREEN);
    } else {
      this.jToggleButton1.setBackground(Color.RED);
      this.alarmenable.setText(this.alarmoff);
    } 
    setAlarmPanel();
  }
  
  public void XMS() {
    int m = this.cal.get(2) + 1;
    int d = this.cal.get(5);
    String v = Settings.get("lastdayrun", "2019.0.0");
    String k = "" + this.cal.get(1) + "." + m + "." + d;
    Settings.set("lastdayrun", k);
    if (!this.xms && ((d == 24 && m == 12) || (d == 25 && m == 12) || (d == 26 && m == 12) || (d == 31 && m == 12) || (d == 1 && m == 1)) && !v.equals(k)) {
      System.out.println("XMAS!!!");
      this.xms = true;
      CPC.xms = 1;
    } 
  }
  
  public void makeAlarm() {
    if (this.hour.equals(this.ahour) && this.min.equals(this.amin) && !this.causedalarm) {
      CPC.loadalarm = true;
      this.causedalarm = true;
      this.clock.setVisible(true);
      this.ymplayer.setVisible(true);
      this.ymplayer.btnREC.setBackground(new Color(255, 0, 0));
      this.ymplayer.btnPLAY.setBackground(Color.BLACK);
      this.ymplayer.btnREC.setForeground(Color.WHITE);
      this.ymplayer.btnPLAY.setForeground(Color.LIGHT_GRAY);
    } 
  }
  
  public void setEmu() {
    if (JEMU.iframe != null)
      JEMU.iframe.pack(); 
  }
  
  public void loadWallpaper() {
    this.chooser.addChoosableFileFilter(new ImageFilter());
    this.chooser.setAcceptAllFileFilterUsed(false);
    this.chooser.setFileView(new ImageFileView());
    this.chooser.setAccessory(new ImagePreview(this.chooser));
    this.chooser.setPreferredSize(new Dimension(640, 480));
    this.chooser.setCurrentDirectory(new File(DSettings.get("wallpaper", "wallpaper/wallpaper.png")));
    this.chooser.setMultiSelectionEnabled(false);
    if (this.chooser.showOpenDialog(this) == 0) {
      DSettings.set("wallpaper", this.chooser.getSelectedFile().getPath());
      setWallpaper();
      this.desktop.repaint();
    } 
  }
  
  public void setWallpaper() {
    String wall = DSettings.get("wallpaper", "wallpaper/wallpaper.png");
    if (Main.wallpaper != null)
      wall = Main.wallpaper; 
    if (!wall.equals("none")) {
      this.wallpaper = Toolkit.getDefaultToolkit().getImage(wall);
    } else {
      this.wallpaper = null;
    } 
  }
  
  public static boolean changewallpaper = false;
  
  int lighttimer;
  
  int thisWidth;
  
  int headpos;
  
  int oldpos;
  
  public void updateSplash() {
    if (Main.splash != null)
      Main.splash.setVisible(!JEMU.hidesplash); 
  }
  
  public static boolean tofront = false;
  
  protected int hideglass;
  
  public static int gfxcount = 0;
  
  protected boolean palupdated;
  
  int oldpsg;
  
  int newpsg;
  
  public static boolean debugger;
  
  int errcount;
  
  int hasstarted;
  
  public static int localizetimer = 0;
  
  public static int openraster = 0;
  
  int chattimer;
  
  int addchat;
  
  public static int breadbin = 0;
  
  Thread splasher;
  
  public static int keytimer = 0;
  
  private JPanel Avol;
  
  private JPanel Dvol;
  
  private JLayeredPane GlossyClock;
  
  private JLabel MonLabel;
  
  public static JTabbedPane OptionPane;
  
  private JInternalFrame Welcome;
  
  public static JLabel aboutline;
  
  public JCheckBox accelerate;
  
  private JButton addhour;
  
  private JButton addmin;
  
  private JLabel alarmenable;
  
  private JTextField alarmhour;
  
  private JTextField alarmmin;
  
  private JPanel alarmpanel;
  
  private JCheckBox amdrum;
  
  private JRadioButton asksave;
  
  private JLabel assembli;
  
  private JInternalFrame at800;
  
  private JLabel atarii;
  
  private JPanel audiodisplay;
  
  private JComboBox audioformat;
  
  private JRadioButton autosave;
  
  public static JTextArea autotype;
  
  private JInternalFrame bddFrame;
  
  private JLabel bddi;
  
  public static JSlider blue;
  
  private JLabel bright;
  
  private JLabel browsi;
  
  private JSlider buffersize;
  
  private ButtonGroup buttonGroup1;
  
  private ButtonGroup buttonGroup2;
  
  private ButtonGroup buttonGroup3;
  
  private JInternalFrame calc;
  
  private JLabel calci;
  
  private JLabel capi;
  
  private JInternalFrame cchooser;
  
  private JLabel cdi;
  
  public static JToggleButton chanA;
  
  public static JToggleButton chanB;
  
  public static JToggleButton chanC;
  
  private JLabel chati;
  
  private JCheckBox chipnoise;
  
  private JInternalFrame clock;
  
  private JPanel clockPanel;
  
  private JLabel clocki;
  
  public static JTextField cmd;
  
  private ButtonGroup cname;
  
  private JColorChooser colchoos;
  
  private JComboBox colo;
  
  private JLabel configi;
  
  private JLabel consoli;
  
  public static JTextField cprfile;
  
  public static JButton cprload;
  
  private JProgressBar cpu;
  
  private JCheckBox crtc;
  
  private JRadioButton crtc0;
  
  private JRadioButton crtc1;
  
  private ButtonGroup crtcg;
  
  private JLabel date;
  
  private JLabel deathi;
  
  private JLabel debugi;
  
  private JCheckBox deskcheck;
  
  public JDesktopPane desktop;
  
  private ButtonGroup df0head;
  
  private ButtonGroup df1head;
  
  private ButtonGroup df2head;
  
  private ButtonGroup df3head;
  
  private JCheckBox digiblaster;
  
  private JRadioButton dkt;
  
  public static JRadioButton doubSize;
  
  private JCheckBox drivenoises;
  
  private ButtonGroup dskcontrol;
  
  private JLabel dski;
  
  private static JInternalFrame dskutil;
  
  public JToggleButton eject0;
  
  public JToggleButton eject1;
  
  public JToggleButton eject2;
  
  public JToggleButton eject3;
  
  private JCheckBox expand;
  
  private JCheckBox fastdisk;
  
  private JLabel favi;
  
  private JCheckBox fdcenabled;
  
  public static JCheckBox fdcm;
  
  private JButton ffwb;
  
  public static JTextField fieldBlue;
  
  public static JTextField fieldGreen;
  
  public static JTextField fieldRed;
  
  private JCheckBox filter;
  
  private JComboBox filterChooser;
  
  private static Panel fled0;
  
  private static Panel fled1;
  
  private static Panel fled2;
  
  private static Panel fled3;
  
  private static JInternalFrame floppy;
  
  private JLabel flopyi;
  
  public JButton forced;
  
  private JLabel formatlabel;
  
  private JProgressBar fps;
  
  public static JPanel fpsled;
  
  private JCheckBox frameskip;
  
  public static JRadioButton freeSize;
  
  private JCheckBox freq;
  
  private JRadioButton freq11;
  
  private JRadioButton freq22;
  
  private JRadioButton freq44;
  
  public static JRadioButton fullSize;
  
  private JInternalFrame gamescdgui;
  
  public static JSlider green;
  
  private JLabel gx4000i;
  
  private JRadioButton h00;
  
  private JRadioButton h01;
  
  private JRadioButton h10;
  
  private JRadioButton h11;
  
  private JRadioButton h20;
  
  private JRadioButton h21;
  
  private JRadioButton h30;
  
  private JRadioButton h31;
  
  private static JLabel head;
  
  private JLabel hexi;
  
  public static JCheckBox hideMouse;
  
  private JCheckBoxMenuItem iconsAlign;
  
  private JLabel infoi;
  
  private JPanel infopanel;
  
  private JLabel inii;
  
  private JToggleButton jAY1;
  
  private JToggleButton jAY2;
  
  private JToggleButton jAY3;
  
  private JToggleButton jAY4;
  
  private JToggleButton jAY5;
  
  private JToggleButton jAY6;
  
  private JCheckBox jAYE;
  
  private JCheckBox jAYE1;
  
  private ButtonGroup jAYGroup;
  
  private JButton jButton1;
  
  private JButton jButton10;
  
  private JButton jButton11;
  
  private JButton jButton12;
  
  private JButton jButton13;
  
  private JButton jButton14;
  
  private JButton jButton15;
  
  private JButton jButton16;
  
  private JButton jButton17;
  
  private JButton jButton18;
  
  private JButton jButton19;
  
  private JButton jButton2;
  
  private JButton jButton20;
  
  private JButton jButton21;
  
  private JButton jButton22;
  
  private JButton jButton23;
  
  private JButton jButton24;
  
  private JButton jButton25;
  
  private JButton jButton26;
  
  private JButton jButton27;
  
  private JButton jButton28;
  
  private JButton jButton29;
  
  private JButton jButton30;
  
  private JButton jButton31;
  
  private JButton jButton32;
  
  private JButton jButton33;
  
  private JButton jButton34;
  
  private JButton jButton35;
  
  private JButton jButton36;
  
  private JButton jButton37;
  
  private JButton jButton38;
  
  private JButton jButton39;
  
  private JButton jButton4;
  
  private JButton jButton40;
  
  private JButton jButton41;
  
  private JButton jButton42;
  
  private JButton jButton43;
  
  private JButton jButton44;
  
  private JButton jButton45;
  
  private JButton jButton46;
  
  private JButton jButton48;
  
  private JButton jButton49;
  
  private JButton jButton5;
  
  private JButton jButton6;
  
  private JButton jButton7;
  
  private JButton jButton8;
  
  private JButton jButton9;
  
  private JCheckBox jCheckBox1;
  
  private JCheckBox jCheckBox10;
  
  private JCheckBox jCheckBox11;
  
  private JCheckBox jCheckBox12;
  
  private JCheckBox jCheckBox13;
  
  private JCheckBox jCheckBox14;
  
  private JCheckBox jCheckBox15;
  
  private JCheckBox jCheckBox16;
  
  private JCheckBox jCheckBox17;
  
  private JCheckBox jCheckBox18;
  
  public static JCheckBox jCheckBox19;
  
  private JCheckBox jCheckBox2;
  
  private JCheckBox jCheckBox20;
  
  private JCheckBox jCheckBox3;
  
  private JCheckBox jCheckBox4;
  
  private JCheckBox jCheckBox5;
  
  private JCheckBox jCheckBox6;
  
  private JCheckBox jCheckBox7;
  
  public static JCheckBox jCheckBox8;
  
  private JCheckBox jCheckBox9;
  
  private JComboBox jComboBox2;
  
  private JComboBox jComboBox3;
  
  private JLabel jLabel1;
  
  private JLabel jLabel10;
  
  private JLabel jLabel11;
  
  private JLabel jLabel12;
  
  private JLabel jLabel13;
  
  private JLabel jLabel14;
  
  private JLabel jLabel15;
  
  private JLabel jLabel16;
  
  private JLabel jLabel17;
  
  private JLabel jLabel18;
  
  private JLabel jLabel19;
  
  private JLabel jLabel2;
  
  private JLabel jLabel20;
  
  private JLabel jLabel21;
  
  private JLabel jLabel22;
  
  private JLabel jLabel23;
  
  private JLabel jLabel24;
  
  private JLabel jLabel25;
  
  private JLabel jLabel26;
  
  private JLabel jLabel27;
  
  private JLabel jLabel28;
  
  private JLabel jLabel29;
  
  private JLabel jLabel3;
  
  private JLabel jLabel30;
  
  private JLabel jLabel31;
  
  private JLabel jLabel32;
  
  private JLabel jLabel33;
  
  private JLabel jLabel34;
  
  private JLabel jLabel35;
  
  private JLabel jLabel36;
  
  private JLabel jLabel37;
  
  private JLabel jLabel38;
  
  private JLabel jLabel39;
  
  private JLabel jLabel4;
  
  private JLabel jLabel40;
  
  private JLabel jLabel41;
  
  private JLabel jLabel42;
  
  private JLabel jLabel43;
  
  private JLabel jLabel44;
  
  private JLabel jLabel45;
  
  private JLabel jLabel46;
  
  private JLabel jLabel47;
  
  private JLabel jLabel48;
  
  private JLabel jLabel49;
  
  private JLabel jLabel5;
  
  private JLabel jLabel50;
  
  private JLabel jLabel51;
  
  private JLabel jLabel52;
  
  private JLabel jLabel53;
  
  private JLabel jLabel54;
  
  private JLabel jLabel55;
  
  private JLabel jLabel56;
  
  private JLabel jLabel57;
  
  private JLabel jLabel58;
  
  private JLabel jLabel59;
  
  private JLabel jLabel6;
  
  private JLabel jLabel60;
  
  private JLabel jLabel61;
  
  private JLabel jLabel62;
  
  private JLabel jLabel63;
  
  private JLabel jLabel64;
  
  private JLabel jLabel65;
  
  private JLabel jLabel66;
  
  private JLabel jLabel67;
  
  private JLabel jLabel68;
  
  private JLabel jLabel69;
  
  private JLabel jLabel7;
  
  private JLabel jLabel70;
  
  private JLabel jLabel71;
  
  private JLabel jLabel72;
  
  private JLabel jLabel73;
  
  private JLabel jLabel74;
  
  private JLabel jLabel75;
  
  private JLabel jLabel76;
  
  private JLabel jLabel77;
  
  private JLabel jLabel78;
  
  private JLabel jLabel79;
  
  private JLabel jLabel8;
  
  private JLabel jLabel80;
  
  private JLabel jLabel81;
  
  private JLabel jLabel82;
  
  private JLabel jLabel83;
  
  private JLabel jLabel84;
  
  private JLabel jLabel85;
  
  private JLabel jLabel86;
  
  private JLabel jLabel87;
  
  private JLabel jLabel88;
  
  private JLabel jLabel89;
  
  private JLabel jLabel9;
  
  private JLabel jLabel90;
  
  private JLabel jLabel91;
  
  private JLabel jLabel92;
  
  private JLabel jLabel93;
  
  private JLabel jLabel94;
  
  private JLabel jLabel95;
  
  private JLabel jLabel96;
  
  private JLabel jLabel98;
  
  private JMenu jMenu1;
  
  private JMenu jMenu2;
  
  private JMenuItem jMenuItem1;
  
  private JMenuItem jMenuItem2;
  
  private JMenuItem jMenuItem3;
  
  private JRadioButton jMon1;
  
  private JRadioButton jMon2;
  
  private JRadioButton jMon3;
  
  private JRadioButton jMon4;
  
  private JRadioButton jMon5;
  
  private JRadioButton jMon6;
  
  private JRadioButton jMon7;
  
  private JRadioButton jMon8;
  
  private JPanel jPanel1;
  
  private JPanel jPanel10;
  
  private JPanel jPanel11;
  
  private JPanel jPanel12;
  
  private JPanel jPanel13;
  
  private JPanel jPanel14;
  
  private JPanel jPanel15;
  
  private JPanel jPanel16;
  
  private JPanel jPanel17;
  
  private JPanel jPanel18;
  
  private JPanel jPanel19;
  
  private JPanel jPanel2;
  
  private JPanel jPanel20;
  
  private JPanel jPanel21;
  
  private JPanel jPanel22;
  
  private JPanel jPanel23;
  
  private JPanel jPanel24;
  
  private JPanel jPanel25;
  
  private JPanel jPanel26;
  
  private JPanel jPanel27;
  
  private JPanel jPanel28;
  
  private JPanel jPanel29;
  
  private JPanel jPanel30;
  
  private JPanel jPanel31;
  
  private JPanel jPanel32;
  
  private JPanel jPanel33;
  
  private JPanel jPanel34;
  
  private JPanel jPanel35;
  
  private JPanel jPanel36;
  
  private JPanel jPanel37;
  
  private JPanel jPanel38;
  
  private JPanel jPanel39;
  
  private JPanel jPanel4;
  
  private JPanel jPanel40;
  
  private JPanel jPanel41;
  
  private JPanel jPanel42;
  
  private JPanel jPanel45;
  
  private JPanel jPanel46;
  
  private JPanel jPanel47;
  
  private JPanel jPanel49;
  
  private JPanel jPanel5;
  
  private JPanel jPanel51;
  
  private JPanel jPanel52;
  
  private JPanel jPanel53;
  
  private JPanel jPanel54;
  
  private JPanel jPanel55;
  
  private JPanel jPanel56;
  
  private JPanel jPanel57;
  
  private JPanel jPanel58;
  
  private JPanel jPanel59;
  
  private JPanel jPanel6;
  
  private JPanel jPanel60;
  
  private JPanel jPanel61;
  
  private JPanel jPanel62;
  
  private JPanel jPanel63;
  
  private JPanel jPanel64;
  
  private JPanel jPanel65;
  
  private JPanel jPanel66;
  
  private JPanel jPanel67;
  
  private JPanel jPanel68;
  
  private JPanel jPanel7;
  
  private JPanel jPanel8;
  
  private JPanel jPanel9;
  
  private JRadioButton jRadioButton1;
  
  private JRadioButton jRadioButton10;
  
  private JRadioButton jRadioButton11;
  
  private JRadioButton jRadioButton12;
  
  private JRadioButton jRadioButton13;
  
  private JRadioButton jRadioButton14;
  
  private JRadioButton jRadioButton2;
  
  private JRadioButton jRadioButton3;
  
  private JRadioButton jRadioButton4;
  
  private JRadioButton jRadioButton7;
  
  private JRadioButton jRadioButton8;
  
  private JRadioButton jRadioButton9;
  
  private JScrollPane jScrollPane1;
  
  private JScrollPane jScrollPane2;
  
  private JScrollPane jScrollPane3;
  
  private JScrollPane jScrollPane4;
  
  private JSeparator jSeparator1;
  
  private JSeparator jSeparator2;
  
  private JSeparator jSeparator4;
  
  private JSeparator jSeparator7;
  
  private JSlider jSlider1;
  
  private JSlider jSlider2;
  
  public static JSlider jSlider3;
  
  public static JSlider jSlider4;
  
  public static JSlider jSlider5;
  
  private JTabbedPane jTabbedPane1;
  
  private JTextField jTextField1;
  
  private JTextField jTextField10;
  
  private JTextField jTextField11;
  
  private JTextField jTextField12;
  
  private JTextField jTextField13;
  
  private JTextField jTextField14;
  
  private JTextField jTextField15;
  
  private JTextField jTextField16;
  
  private JTextField jTextField17;
  
  private JTextField jTextField18;
  
  private JTextField jTextField19;
  
  private JTextField jTextField2;
  
  private JTextField jTextField20;
  
  private JTextField jTextField21;
  
  private JTextField jTextField22;
  
  private JTextField jTextField23;
  
  private JTextField jTextField24;
  
  private JTextField jTextField25;
  
  private JTextField jTextField26;
  
  private JTextField jTextField27;
  
  private JTextField jTextField28;
  
  private JTextField jTextField29;
  
  private JTextField jTextField3;
  
  private JTextField jTextField30;
  
  private JTextField jTextField31;
  
  private JTextField jTextField32;
  
  private JTextField jTextField4;
  
  private JTextField jTextField5;
  
  private JTextField jTextField6;
  
  private JTextField jTextField7;
  
  private JTextField jTextField8;
  
  private JTextField jTextField9;
  
  private JToggleButton jToggleButton1;
  
  private JToggleButton jToggleButton2;
  
  private JToggleButton jToggleButton3;
  
  private JToggleButton jToggleButton4;
  
  private JToggleButton jToggleButton5;
  
  private JInternalFrame keyboard;
  
  private JLabel keyc;
  
  private JCheckBox keyclash;
  
  public static JLabel keycode;
  
  private JCheckBox keynoise;
  
  private JPanel keypanel;
  
  private JLabel label1;
  
  private JLabel label10;
  
  private JLabel label11;
  
  private JLabel label12;
  
  private JLabel label13;
  
  private JLabel label14;
  
  private JLabel label15;
  
  private JLabel label16;
  
  private JLabel label17;
  
  private JLabel label2;
  
  private JLabel label3;
  
  private JLabel label4;
  
  private JLabel label5;
  
  private JLabel label6;
  
  private JLabel label7;
  
  private JLabel label8;
  
  private JLabel label9;
  
  public static JPanel led0;
  
  public static JPanel led1;
  
  public static JPanel led2;
  
  public static JPanel led3;
  
  public static JPanel led5;
  
  public static JProgressBar leftvumeter;
  
  public static JSlider level;
  
  private JToggleButton light;
  
  private JComboBox loROM;
  
  private JButton load0;
  
  private JButton load1;
  
  private JButton load2;
  
  private JButton load3;
  
  private JButton load4;
  
  private JButton load5;
  
  public static JButton loadram;
  
  public static JCheckBox localize;
  
  private JCheckBox lock;
  
  private JComboBox lookSelector;
  
  public static JLabel mag1;
  
  public static JLabel mag2;
  
  private JInternalFrame mandel;
  
  private JInternalFrame maped;
  
  private JRadioButton mask1;
  
  private JRadioButton mask2;
  
  private JRadioButton mem0;
  
  private JRadioButton mem1;
  
  private JRadioButton mem2;
  
  private JRadioButton mem3;
  
  private JRadioButton mem4;
  
  private JRadioButton mem5;
  
  private ButtonGroup memGroup;
  
  private JProgressBar memoryBar;
  
  private JCheckBox memorydisplay;
  
  public static JProgressBar midvumeter;
  
  private JLabel minii;
  
  private JCheckBox mmask;
  
  private JLabel modo;
  
  private ButtonGroup mongroup1;
  
  private ButtonGroup moniset;
  
  private JLabel mprev;
  
  private JCheckBox mute;
  
  public static JTextField name0;
  
  public static JTextField name1;
  
  public JTextField name2;
  
  public JTextField name3;
  
  private JLabel newii;
  
  private JCheckBox noOverwrite;
  
  private JLabel oldii;
  
  public static JInternalFrame options;
  
  private JLabel paci;
  
  private JLabel painti;
  
  private JCheckBox pal;
  
  private JCheckBox pal1;
  
  private JPanel palpan;
  
  private JSlider palvalue;
  
  private JSlider palvalue1;
  
  public static JTextField pan1;
  
  public static JTextField pan10;
  
  public static JTextField pan11;
  
  public static JTextField pan12;
  
  public static JTextField pan13;
  
  public static JTextField pan14;
  
  public static JTextField pan15;
  
  public static JTextField pan16;
  
  public static JTextField pan17;
  
  public static JTextField pan18;
  
  public static JTextField pan19;
  
  public static JTextField pan2;
  
  public static JTextField pan20;
  
  public static JTextField pan21;
  
  public static JTextField pan22;
  
  public static JTextField pan23;
  
  public static JTextField pan24;
  
  public static JTextField pan25;
  
  public static JTextField pan26;
  
  public static JTextField pan27;
  
  public static JTextField pan28;
  
  public static JTextField pan29;
  
  public static JTextField pan3;
  
  public static JTextField pan30;
  
  public static JTextField pan31;
  
  public static JTextField pan32;
  
  public static JTextField pan4;
  
  public static JTextField pan5;
  
  public static JTextField pan6;
  
  public static JTextField pan7;
  
  public static JTextField pan8;
  
  public static JTextField pan9;
  
  private JButton pauseb;
  
  public JPanel periphery;
  
  private JButton playb;
  
  private JCheckBox playcity;
  
  private JButton pluson;
  
  private JLabel pokei;
  
  private JPopupMenu pop;
  
  private JCheckBox printer;
  
  public static JInternalFrame printframe;
  
  public static JTextArea printout;
  
  public static JProgressBar psg1a;
  
  public static JProgressBar psg1b;
  
  public static JProgressBar psg1c;
  
  public static JProgressBar psg2a;
  
  public static JProgressBar psg2b;
  
  public static JProgressBar psg2c;
  
  private JLabel pufferl;
  
  private JEditorPane qinfo;
  
  public static JRadioButton quadSize;
  
  private JButton quitbutton;
  
  private JLabel radioi;
  
  private JInternalFrame rasterFrame;
  
  private JLabel rasteri;
  
  private JButton recb;
  
  public static JSlider red;
  
  private JButton resbutton;
  
  private JLabel restartj;
  
  private JButton rewb;
  
  public static JTextField rgb;
  
  public static JProgressBar rightvumeter;
  
  private JLabel rolandi;
  
  private JCheckBox roms32;
  
  public static JButton saveram;
  
  private JCheckBox scanl;
  
  private JPanel scrollinfo;
  
  private JButton selL0;
  
  private JButton selU1;
  
  private JButton selU10;
  
  private JButton selU11;
  
  private JButton selU12;
  
  private JButton selU13;
  
  private JButton selU14;
  
  private JButton selU15;
  
  private JButton selU16;
  
  private JButton selU2;
  
  private JButton selU3;
  
  private JButton selU4;
  
  private JButton selU5;
  
  private JButton selU6;
  
  private JButton selU7;
  
  private JButton selU8;
  
  private JButton selU9;
  
  public static JTextField selpan;
  
  private JButton set32roms;
  
  private JButton setRoms;
  
  private JButton setbutton;
  
  private JButton setbutton3;
  
  public static JCheckBox showGlass;
  
  public static JRadioButton simpSize;
  
  private JCheckBox sinfo;
  
  public static JButton slic;
  
  private ButtonGroup speechgroup;
  
  private JCheckBox spenable;
  
  public static JLabel sprite1;
  
  public static JLabel sprite10;
  
  public static JLabel sprite11;
  
  public static JLabel sprite12;
  
  public static JLabel sprite13;
  
  public static JLabel sprite14;
  
  public static JLabel sprite15;
  
  public static JLabel sprite16;
  
  public static JLabel sprite2;
  
  public static JLabel sprite3;
  
  public static JLabel sprite4;
  
  public static JLabel sprite5;
  
  public static JLabel sprite6;
  
  public static JLabel sprite7;
  
  public static JLabel sprite8;
  
  public static JLabel sprite9;
  
  private JRadioButton ssa1;
  
  private JLabel startlabel;
  
  private JInternalFrame starttab;
  
  public static JTextField statinf;
  
  public static JTextField statinf1;
  
  private JButton stopb;
  
  private JButton subhour;
  
  private JButton submin;
  
  private JCheckBox superPal;
  
  public static JCheckBox sync;
  
  private JButton syncbutton;
  
  private JComboBox sysselect;
  
  private JInternalFrame tapedeck;
  
  private JLabel tapei;
  
  private JTextField tapename;
  
  private ButtonGroup tapequality;
  
  private JPanel taskbar;
  
  public static JPanel textprinter;
  
  private JLabel tiledi;
  
  private JLabel timedisplay;
  
  private JLabel timepanel;
  
  private JLabel transparentFace;
  
  public static JRadioButton tripleSize;
  
  private JComboBox up0;
  
  private JComboBox up1;
  
  private JComboBox up10;
  
  private JComboBox up11;
  
  private JComboBox up12;
  
  private JComboBox up13;
  
  private JComboBox up14;
  
  private JComboBox up15;
  
  private JComboBox up2;
  
  private JComboBox up3;
  
  private JComboBox up4;
  
  private JComboBox up5;
  
  private JComboBox up6;
  
  private JComboBox up7;
  
  private JComboBox up8;
  
  private JComboBox up9;
  
  private JCheckBox useconsole;
  
  private JPanel videopanel;
  
  private ButtonGroup wallbehaviour;
  
  private JRadioButton wallcenter;
  
  public JDesktopPane wallpreview;
  
  private JRadioButton wallstretch;
  
  private JRadioButton walltile;
  
  private static JInternalFrame webbrowser;
  
  private JLabel webi;
  
  private JLabel ymi;
  
  public static int selcrtc;
  
  public static int selpsg;
  
  BufferedImage bum;
  
  boolean alignIcons;
  
  public void clock() {
    XMS();
    if (keytimer != 0) {
      keytimer++;
      if (keytimer > 3) {
        checkKeyboard();
        keytimer = 0;
      } 
    } 
    if (visTimer != 0) {
      visTimer++;
      if (visTimer > 3) {
        this;
        setVisible(setVis);
        visTimer = 0;
      } 
    } 
    if (breadbin != 0) {
      breadbin++;
      if (breadbin >= 2) {
        breadbin = 0;
        addC64();
      } 
    } 
    if (this.isPlusShowing && this.gx4000 != null && !this.gx4000.isVisible()) {
      this.isPlusShowing = false;
      GateArray.cpc.start();
    } 
    if (this.chatframe != null && !this.chatframe.isVisible() && this.chat != null)
      EventQueue.invokeLater(new Runnable() {
            public void run() {
              Desktop.this.chattimer++;
              if (Desktop.this.chattimer > 20 && !Desktop.this.chat.getLastPage().equals(Desktop.this.chat.getEmpty()))
                Desktop.this.chat.closeChat(); 
            }
          }); 
    if (openraster > 0) {
      openraster = 0;
      openRasterPaint();
    } 
    if (browsertimer > 0) {
      browsertimer++;
      if (browsertimer > 4) {
        browsertimer = 0;
        openWebPage();
      } 
    } 
    if (this.openchat > 0) {
      this.openchat++;
      if (this.openchat > 4) {
        this.openchat = 0;
        openChat();
      } 
    } 
    if (this.addchat > 0) {
      this.addchat++;
      if (this.addchat > 4) {
        this.addchat = 0;
        addChat();
      } 
    } 
    if (localizetimer != 0) {
      localize(Settings.get("language", "EN_EN"));
      localizetimer = 0;
    } 
    if (openbdd != 0) {
      openbdd++;
      if (openbdd > 10) {
        openbdd = 0;
        createBDD();
      } 
    } 
    if (this.keyc.isVisible()) {
      this.keyc.setVisible(false);
      keycode.setVisible(false);
    } 
    if (JEMU.localkeys.equals("DE_DE")) {
      this.jCheckBox18.setEnabled(true);
      this.jPanel24.setEnabled(true);
    } else {
      this.jCheckBox18.setEnabled(false);
      this.jPanel24.setEnabled(false);
    } 
    if (asmfile != null)
      openASM(); 
    if (debugger && !debug.isVisible()) {
      debugger = false;
      JEMU.debugger.Continue();
    } 
    if (this.periphery.isShowing()) {
      this.newpsg = AY_3_8910.getR13();
      if (this.newpsg != this.oldpsg) {
        setRegisters();
        this.oldpsg = this.newpsg;
      } 
    } 
    if (this.palpan.isShowing() && !this.palupdated) {
      this.palupdated = true;
      updatePal();
    } 
    if (!this.palpan.isShowing())
      this.palupdated = false; 
    if (gfxcount != 0) {
      gfxcount++;
      if (gfxcount > 2) {
        gfxcount = 0;
        makeGFXViewer();
      } 
    } 
    if (this.hideglass > 1) {
      this.hideglass -= 10;
      if (this.hideglass <= 10)
        showGlass.setVisible(false); 
    } 
    if (OptionPane.isVisible() && OptionPane.getSelectedIndex() == 7 && !this.helper.scroll.isRunning()) {
      this.helper.scroll.start();
      this.helper.scroll.setCols(this.infopanel.getBackground(), this.infopanel.getForeground());
    } 
    if ((!OptionPane.isVisible() || OptionPane.getSelectedIndex() != 7) && this.helper.scroll.isRunning())
      this.helper.scroll.stop(); 
    if (closeFormat) {
      closeFormat = false;
      if (this.ini != null)
        this.ini.setVisible(false); 
    } 
    if (this.memoryBar.isShowing()) {
      this.memo++;
      if (this.memo > 5) {
        this.memo = 0;
        updateMemorybar();
      } 
    } 
    this.fps.setValue(Display.mCurrFPS);
    this.cpu.setValue(Switches.turbo);
    int col = Display.mCurrFPS * 5;
    if (col > 255)
      col = 255; 
    fpsled.setBackground(new Color(255 - col, col, 0));
    this.fps.setForeground(new Color(255 - col, col, 0));
    if (checkdrives) {
      checkDrives();
      checkdrives = false;
    } 
    if (!isDesktop)
      return; 
    if (this.thisWidth != getWidth()) {
      this.thisWidth = getWidth();
      this.recb.setVisible((getWidth() > 850));
      this.playb.setVisible((getWidth() > 850));
      this.rewb.setVisible((getWidth() > 850));
      this.ffwb.setVisible((getWidth() > 850));
      this.stopb.setVisible((getWidth() > 850));
      this.pauseb.setVisible((getWidth() > 850));
    } 
    if (this.lighttimer != 0) {
      this.lighttimer++;
      if (this.lighttimer == 50) {
        this.lighttimer = 0;
        this.light.setSelected(false);
        if (!this.alarmenabled) {
          this.alarmpanel.setBackground(new Color(104, 127, 133));
          this.timedisplay.setForeground(new Color(80, 80, 80));
          this.date.setForeground(new Color(80, 80, 80));
        } 
      } 
    } 
    if (TapeDeck.tapepanel != null && GateArray.cpc != null && !this.panel) {
      System.out.println("Building tapedrive");
      TapeDeck.tapepanel.setPreferredSize(new Dimension(260, 350));
      this.tapedeck.setLayout(new BorderLayout());
      this.tapedeck.add(TapeDeck.tapepanel, "South");
      this.tapedeck.add(TapeDeck.tapeblocks, "North");
      this.tapedeck.pack();
      this.tapedeck.setResizable(false);
      this.panel = true;
      GateArray.cpc.TapeDrive.started = false;
    } 
    if (tofront) {
      JEMU.iframe.toFront();
      tofront = false;
      this.desktop.update(this.desktop.getGraphics());
      this.desktop.repaint();
    } 
    if (this.panel)
      if (this.tapedeck.isShowing()) {
        if (!GateArray.cpc.TapeDrive.started) {
          GateArray.cpc.TapeDrive.Updater.start();
          System.out.println("Tapedrive starting");
        } 
      } else if (GateArray.cpc.TapeDrive.started) {
        GateArray.cpc.TapeDrive.started = false;
        GateArray.cpc.TapeDrive.Updater.stop();
        System.out.println("Tapedrive stopping");
      }  
    if (this.starttimer != 0) {
      this.starttimer++;
      if (this.starttimer == 10)
        setExtendedState(6); 
      if (this.starttimer == 14);
      if (this.starttimer == 15);
      if (this.starttimer == 20) {
        setExtendedState(6);
        setVisible(true);
        JEMU.iframe.setVisible(true);
        JEMU.iframe.toFront();
        if (this.Welcome.isVisible())
          this.Welcome.toFront(); 
        if (Main.splash != null)
          Main.splash.dispose(); 
        this.starttimer = 0;
        System.gc();
        while (GateArray.cpc == null) {
          try {
            Thread.sleep(10L);
          } catch (Exception exception) {}
        } 
        GateArray.cpc.start();
        AY_3_8910.changeformat = true;
      } 
      if (this.starttimer == 15) {
        this.desktop.add(JEMU.iframe);
        CPC.resync = true;
        if (isUndecorated()) {
          System.out.println("This is undecorated!");
          try {
            setOpacity(0.0F);
            this.splasher = new Thread() {
                public void run() {
                  try {
                    Thread.sleep(1000L);
                  } catch (Exception exception) {}
                  float sweep = 0.0F;
                  while (sweep < 1.0F) {
                    sweep += 0.00125F;
                    if (sweep > 1.0F)
                      sweep = 1.0F; 
                    Desktop.this.setOpacity(sweep);
                    try {
                      Thread.sleep(2L);
                    } catch (Exception exception) {}
                  } 
                }
              };
          } catch (Exception exception) {}
          this.splasher.start();
        } 
        setVisible(true);
        setExtendedState(6);
      } 
    } 
    if (JEMU.iframe != null && !started) {
      boolean undecorate = DSettings.getBoolean("undecorate", false);
      try {
        if (undecorate) {
          setUndecorated(true);
        } else {
          setUndecorated(false);
        } 
      } catch (Exception exception) {}
      setMenuBar(JEMU.JavaCPCMenu);
      started = true;
    } 
    if (JEMU.iframe != null);
    if (this.moved && getInt(Settings.get("frame_xpos", "0")) != this.xd) {
      Settings.set("frame_xpos", "" + this.xd);
      Settings.set("frame_ypos", "" + this.yd);
    } 
    if (changewallpaper) {
      setWallpaper();
      changewallpaper = false;
    } 
    if (jCheckBox8.isSelected() && Switches.turbo < 2)
      jCheckBox8.setSelected(false); 
    if (!jCheckBox8.isSelected() && Switches.turbo > 1)
      jCheckBox8.setSelected(true); 
    this.clockt++;
    if (this.clockt == 5) {
      if (!packed && JEMU.iframe != null) {
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        try {
          JEMU.iframe.setSelected(true);
        } catch (Exception exception) {}
        setVisible(true);
        packed = true;
        setRegisters();
      } 
      this.clockt = 0;
      this.makeemu++;
      if (this.makeemu < 3 && JEMU.iframe != null)
        setEmu(); 
      if (this.makeemu > 3) {
        this.makeemu = 4;
        if (!isVisible()) {
          this.errcount++;
          if (this.errcount > 1000) {
            System.err.println("Bye bye...");
            GateArray.cpc.checkSaveOnExit();
            CPC.playSNP = false;
            CPC.StoreSNP = false;
          } 
        } 
      } 
      this.cal = Calendar.getInstance();
      this.min = "" + this.cal.get(12);
      this.hour = "" + this.cal.get(11);
      this.sec = "" + this.cal.get(13);
      this.cal.getTime();
      SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
      this.timepanel.setText("" + sdf.format(this.cal.getTime()));
      if (this.hour.length() < 2)
        this.hour = "0" + this.hour; 
      if (this.min.length() < 2)
        this.min = "0" + this.min; 
      if (this.sec.length() < 2)
        this.sec = "0" + this.sec; 
      if (this.alarmenabled)
        makeAlarm(); 
      int wday = this.cal.get(7);
      String dayw = "";
      switch (wday) {
        case 1:
          dayw = "Sun.";
          break;
        case 2:
          dayw = "Mon.";
          break;
        case 3:
          dayw = "Tue.";
          break;
        case 4:
          dayw = "Wed.";
          break;
        case 5:
          dayw = "Thu.";
          break;
        case 6:
          dayw = "Fri.";
          break;
        case 7:
          dayw = "Sat.";
          break;
      } 
      dayw = dayw + ", " + this.cal.get(5) + "/";
      dayw = dayw + (this.cal.get(2) + 1) + "/";
      dayw = dayw + this.cal.get(1);
      this.time = "  " + this.hour + ":" + this.min + ":" + this.sec;
      this.timedisplay.setText(this.time);
      this.date.setText(dayw);
    } 
  }
  
  public static void open(int page) {
    OptionPane.setSelectedIndex(page);
  }
  
  public void checkConsole() {
    if (Settings.getBoolean("console", false) && this.console == null) {
      this.console = new Console();
      System.out.println("JavaCPC [v." + Main.version + Main.subversion + "]\n\n[" + this.cal.getTime() + "]\n");
      this.console.setDefaultCloseOperation(1);
      this.desktop.add(this.console);
      this.console.setLocation(10, 10);
      this.console.setSize(540, 400);
      this.console.setIconifiable(true);
      this.console.setMaximizable(true);
      this.console.setResizable(true);
      Console.textArea.setBackground(Color.black);
      Console.textArea.setForeground(Color.lightGray);
      this.console.setClosable(true);
      this.console.setVisible(true);
    } else {
      if (this.console != null) {
        this.console.setVisible(false);
        this.console.dispose();
      } 
      this.console = null;
    } 
    this.useconsole.setSelected(Settings.getBoolean("console", false));
  }
  
  public void checkDrives() {
    name0.setEnabled(true);
    name1.setEnabled(true);
    this.name2.setEnabled(true);
    this.name3.setEnabled(true);
    name0.setText(Settings.get("file.drive" + Integer.toString(0), "empty"));
    name1.setText(Settings.get("file.drive" + Integer.toString(1), "empty"));
    this.name2.setText(Settings.get("file.drive" + Integer.toString(2), "empty"));
    this.name3.setText(Settings.get("file.drive" + Integer.toString(3), "empty"));
    String path = Settings.get("magicdisc_0", "empty");
    if (!path.equals("empty"))
      name0.setText("MAGIC: " + path); 
    path = Settings.get("magicdisc_1", "empty");
    if (!path.equals("empty"))
      name1.setText("MAGIC: " + path); 
    if (name0.getText().equals("empty"))
      name0.setEnabled(false); 
    if (name1.getText().equals("empty"))
      name1.setEnabled(false); 
    if (this.name2.getText().equals("empty"))
      this.name2.setEnabled(false); 
    if (this.name3.getText().equals("empty"))
      this.name3.setEnabled(false); 
    this.tapename.setText(Settings.get("tapelabel", "~none~"));
    this.tapename.setEnabled(true);
    if (this.tapename.getText().equals("~none~") || this.tapename.getText().equals("empty") || this.tapename.getText().equals("")) {
      this.tapename.setText("empty");
      this.tapename.setEnabled(false);
    } 
    this.jButton20.setEnabled(!name0.getText().equals("empty"));
    this.eject0.setSelected(name0.getText().equals("empty"));
    this.eject1.setSelected(name1.getText().equals("empty"));
    this.eject2.setSelected(this.name2.getText().equals("empty"));
    this.eject3.setSelected(this.name3.getText().equals("empty"));
  }
  
  public void setRegisters() {
    if (this.bum == null)
      this.bum = new BufferedImage(77, 54, 4); 
    this.bum.getGraphics().drawImage(Display.image, 0, 0, 77, 54, null);
    this.mprev.setIcon(new ImageIcon(this.bum));
    this.jTextField1.setForeground(Color.black);
    this.jTextField2.setForeground(Color.black);
    this.jTextField3.setForeground(Color.black);
    this.jTextField4.setForeground(Color.black);
    this.jTextField5.setForeground(Color.black);
    this.jTextField6.setForeground(Color.black);
    this.jTextField7.setForeground(Color.black);
    this.jTextField8.setForeground(Color.black);
    this.jTextField9.setForeground(Color.black);
    this.jTextField10.setForeground(Color.black);
    this.jTextField11.setForeground(Color.black);
    this.jTextField12.setForeground(Color.black);
    this.jTextField13.setForeground(Color.black);
    this.jTextField14.setForeground(Color.black);
    this.jTextField15.setForeground(Color.black);
    this.jTextField16.setForeground(Color.black);
    this.jTextField17.setForeground(Color.black);
    this.jTextField18.setForeground(Color.black);
    this.jTextField19.setForeground(Color.black);
    this.jTextField20.setForeground(Color.black);
    this.jTextField21.setForeground(Color.black);
    this.jTextField22.setForeground(Color.black);
    this.jTextField23.setForeground(Color.black);
    this.jTextField24.setForeground(Color.black);
    this.jTextField25.setForeground(Color.black);
    this.jTextField26.setForeground(Color.black);
    this.jTextField27.setForeground(Color.black);
    this.jTextField28.setForeground(Color.black);
    this.jTextField29.setForeground(Color.black);
    this.jTextField30.setForeground(Color.black);
    this.jTextField31.setForeground(Color.black);
    this.jTextField32.setForeground(Color.black);
    this.jTextField1.setBackground((selcrtc == 0) ? Color.cyan : Color.white);
    this.jTextField2.setBackground((selcrtc == 1) ? Color.cyan : Color.white);
    this.jTextField3.setBackground((selcrtc == 2) ? Color.cyan : Color.white);
    this.jTextField4.setBackground((selcrtc == 3) ? Color.cyan : Color.white);
    this.jTextField5.setBackground((selcrtc == 4) ? Color.cyan : Color.white);
    this.jTextField6.setBackground((selcrtc == 5) ? Color.cyan : Color.white);
    this.jTextField7.setBackground((selcrtc == 6) ? Color.cyan : Color.white);
    this.jTextField8.setBackground((selcrtc == 7) ? Color.cyan : Color.white);
    this.jTextField9.setBackground((selcrtc == 8) ? Color.cyan : Color.white);
    this.jTextField10.setBackground((selcrtc == 9) ? Color.cyan : Color.white);
    this.jTextField11.setBackground((selcrtc == 10) ? Color.cyan : Color.white);
    this.jTextField12.setBackground((selcrtc == 11) ? Color.cyan : Color.white);
    this.jTextField13.setBackground((selcrtc == 12) ? Color.cyan : Color.white);
    this.jTextField14.setBackground((selcrtc == 13) ? Color.cyan : Color.white);
    this.jTextField15.setBackground((selcrtc == 14) ? Color.cyan : Color.white);
    this.jTextField16.setBackground((selcrtc == 15) ? Color.cyan : Color.white);
    this.jTextField1.setText(Basic6845.getRegister(0));
    this.jTextField2.setText(Basic6845.getRegister(1));
    this.jTextField3.setText(Basic6845.getRegister(2));
    this.jTextField4.setText(Basic6845.getRegister(3));
    this.jTextField5.setText(Basic6845.getRegister(4));
    this.jTextField6.setText(Basic6845.getRegister(5));
    this.jTextField7.setText(Basic6845.getRegister(6));
    this.jTextField8.setText(Basic6845.getRegister(7));
    this.jTextField9.setText(Basic6845.getRegister(8));
    this.jTextField10.setText(Basic6845.getRegister(9));
    this.jTextField11.setText(Basic6845.getRegister(10));
    this.jTextField12.setText(Basic6845.getRegister(11));
    this.jTextField13.setText(Basic6845.getRegister(12));
    this.jTextField14.setText(Basic6845.getRegister(13));
    this.jTextField15.setText(Basic6845.getRegister(14));
    this.jTextField16.setText(Basic6845.getRegister(15));
    this.jTextField17.setText(AY_3_8910.getReg(0));
    this.jTextField18.setText(AY_3_8910.getReg(1));
    this.jTextField19.setText(AY_3_8910.getReg(2));
    this.jTextField20.setText(AY_3_8910.getReg(3));
    this.jTextField21.setText(AY_3_8910.getReg(4));
    this.jTextField22.setText(AY_3_8910.getReg(5));
    this.jTextField23.setText(AY_3_8910.getReg(6));
    this.jTextField24.setText(AY_3_8910.getReg(7));
    this.jTextField25.setText(AY_3_8910.getReg(8));
    this.jTextField26.setText(AY_3_8910.getReg(9));
    this.jTextField27.setText(AY_3_8910.getReg(10));
    this.jTextField28.setText(AY_3_8910.getReg(11));
    this.jTextField29.setText(AY_3_8910.getReg(12));
    this.jTextField30.setText(AY_3_8910.getReg(13));
    this.jTextField31.setText(AY_3_8910.getReg(14));
    this.jTextField32.setText(AY_3_8910.getReg(15));
    this.jTextField17.setBackground((selpsg == 0) ? Color.cyan : Color.white);
    this.jTextField18.setBackground((selpsg == 1) ? Color.cyan : Color.white);
    this.jTextField19.setBackground((selpsg == 2) ? Color.cyan : Color.white);
    this.jTextField20.setBackground((selpsg == 3) ? Color.cyan : Color.white);
    this.jTextField21.setBackground((selpsg == 4) ? Color.cyan : Color.white);
    this.jTextField22.setBackground((selpsg == 5) ? Color.cyan : Color.white);
    this.jTextField23.setBackground((selpsg == 6) ? Color.cyan : Color.white);
    this.jTextField24.setBackground((selpsg == 7) ? Color.cyan : Color.white);
    this.jTextField25.setBackground((selpsg == 8) ? Color.cyan : Color.white);
    this.jTextField26.setBackground((selpsg == 9) ? Color.cyan : Color.white);
    this.jTextField27.setBackground((selpsg == 10) ? Color.cyan : Color.white);
    this.jTextField28.setBackground((selpsg == 11) ? Color.cyan : Color.white);
    this.jTextField29.setBackground((selpsg == 12) ? Color.cyan : Color.white);
    this.jTextField30.setBackground((selpsg == 13) ? Color.cyan : Color.white);
    this.jTextField31.setBackground((selpsg == 14) ? Color.cyan : Color.white);
    this.jTextField32.setBackground((selpsg == 15) ? Color.cyan : Color.white);
    updatePSG();
  }
  
  public void updatePSG() {
    try {
      int reg13 = AY_3_8910.getR13() & 0xC;
      switch (reg13) {
        case 0:
          this.jLabel15.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/psg/psg0.gif")));
          return;
        case 4:
          this.jLabel15.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/psg/psg1.gif")));
          return;
        case 8:
          this.jLabel15.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/psg/psg2.gif")));
          return;
        case 9:
          this.jLabel15.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/psg/psg3.gif")));
          return;
        case 10:
          this.jLabel15.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/psg/psg4.gif")));
          return;
        case 11:
          this.jLabel15.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/psg/psg5.gif")));
          return;
        case 12:
          this.jLabel15.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/psg/psg6.gif")));
          return;
      } 
      System.err.println("Register 13 is :" + reg13);
    } catch (Exception exception) {}
  }
  
  public void mouseMoved(MouseEvent e) {}
  
  public void mouseDragged(MouseEvent e) {
    int x = e.getXOnScreen() - (getLocation()).x - (getInsets()).left - 50;
    int y = e.getYOnScreen() - (getLocation()).y - (getInsets()).top - 30;
    if (x > this.desktop.getWidth() - 50)
      x = this.desktop.getWidth() - 50; 
    if (x < -50)
      x = -50; 
    if (y > this.desktop.getHeight() - 20)
      y = this.desktop.getHeight() - 20; 
    if (y < -20)
      y = -20; 
    int xalign = 0;
    int yalign = 0;
    int ydiff = 0;
    if (this.alignIcons) {
      xalign = 90;
      yalign = 70;
      ydiff = 30;
      x = x / xalign * xalign;
      y = y / yalign * yalign + ydiff;
    } 
    if (e.getSource() == this.capi) {
      DSettings.set("icon1x", "" + x);
      DSettings.set("icon1y", "" + y);
      this.capi.setLocation(x, y);
    } 
    if (e.getSource() == this.ymi) {
      DSettings.set("icon2x", "" + x);
      DSettings.set("icon2y", "" + y);
      this.ymi.setLocation(x, y);
    } 
    if (e.getSource() == this.hexi) {
      DSettings.set("icon3x", "" + x);
      DSettings.set("icon3y", "" + y);
      this.hexi.setLocation(x, y);
    } 
    if (e.getSource() == this.clocki) {
      DSettings.set("icon4x", "" + x);
      DSettings.set("icon4y", "" + y);
      this.clocki.setLocation(x, y);
    } 
    if (e.getSource() == this.infoi) {
      DSettings.set("icon5x", "" + x);
      DSettings.set("icon5y", "" + y);
      this.infoi.setLocation(x, y);
    } 
    if (e.getSource() == this.consoli) {
      DSettings.set("icon6x", "" + x);
      DSettings.set("icon6y", "" + y);
      this.consoli.setLocation(x, y);
    } 
    if (e.getSource() == this.minii) {
      DSettings.set("icon7x", "" + x);
      DSettings.set("icon7y", "" + y);
      this.minii.setLocation(x, y);
    } 
    if (e.getSource() == this.browsi) {
      DSettings.set("icon8x", "" + x);
      DSettings.set("icon8y", "" + y);
      this.browsi.setLocation(x, y);
    } 
    if (e.getSource() == this.configi) {
      DSettings.set("icon9x", "" + x);
      DSettings.set("icon9y", "" + y);
      this.configi.setLocation(x, y);
    } 
    if (e.getSource() == this.debugi) {
      DSettings.set("icon10x", "" + x);
      DSettings.set("icon10y", "" + y);
      this.debugi.setLocation(x, y);
    } 
    if (e.getSource() == this.tapei) {
      DSettings.set("icon11x", "" + x);
      DSettings.set("icon11y", "" + y);
      this.tapei.setLocation(x, y);
    } 
    if (e.getSource() == this.painti) {
      DSettings.set("icon12x", "" + x);
      DSettings.set("icon12y", "" + y);
      this.painti.setLocation(x, y);
    } 
    if (e.getSource() == this.inii) {
      DSettings.set("icon13x", "" + x);
      DSettings.set("icon13y", "" + y);
      this.inii.setLocation(x, y);
    } 
    if (e.getSource() == this.newii) {
      DSettings.set("icon14x", "" + x);
      DSettings.set("icon14y", "" + y);
      this.newii.setLocation(x, y);
    } 
    if (e.getSource() == this.oldii) {
      DSettings.set("icon15x", "" + x);
      DSettings.set("icon15y", "" + y);
      this.oldii.setLocation(x, y);
    } 
    if (e.getSource() == this.tiledi) {
      DSettings.set("icon16x", "" + x);
      DSettings.set("icon16y", "" + y);
      this.tiledi.setLocation(x, y);
    } 
    if (e.getSource() == this.assembli) {
      DSettings.set("icon17x", "" + x);
      DSettings.set("icon17y", "" + y);
      this.assembli.setLocation(x, y);
    } 
    if (e.getSource() == this.calci) {
      DSettings.set("icon18x", "" + x);
      DSettings.set("icon18y", "" + y);
      this.calci.setLocation(x, y);
    } 
    if (e.getSource() == this.paci) {
      DSettings.set("icon19x", "" + x);
      DSettings.set("icon19y", "" + y);
      this.paci.setLocation(x, y);
    } 
    if (e.getSource() == this.flopyi) {
      DSettings.set("icon20x", "" + x);
      DSettings.set("icon20y", "" + y);
      this.flopyi.setLocation(x, y);
    } 
    if (e.getSource() == this.pokei) {
      DSettings.set("icon21x", "" + x);
      DSettings.set("icon21y", "" + y);
      this.pokei.setLocation(x, y);
    } 
    if (e.getSource() == this.webi) {
      DSettings.set("icon22x", "" + x);
      DSettings.set("icon22y", "" + y);
      this.webi.setLocation(x, y);
    } 
    if (e.getSource() == this.radioi) {
      DSettings.set("icon23x", "" + x);
      DSettings.set("icon23y", "" + y);
      this.radioi.setLocation(x, y);
    } 
    if (e.getSource() == this.chati) {
      DSettings.set("icon24x", "" + x);
      DSettings.set("icon24y", "" + y);
      this.chati.setLocation(x, y);
    } 
    if (e.getSource() == this.favi) {
      DSettings.set("icon25x", "" + x);
      DSettings.set("icon25y", "" + y);
      this.favi.setLocation(x, y);
    } 
    if (e.getSource() == this.dski) {
      DSettings.set("icon26x", "" + x);
      DSettings.set("icon26y", "" + y);
      this.dski.setLocation(x, y);
    } 
    if (e.getSource() == this.atarii) {
      DSettings.set("icon27x", "" + x);
      DSettings.set("icon27y", "" + y);
      this.atarii.setLocation(x, y);
    } 
    if (e.getSource() == this.gx4000i) {
      DSettings.set("icon28x", "" + x);
      DSettings.set("icon28y", "" + y);
      this.gx4000i.setLocation(x, y);
    } 
    if (e.getSource() == this.deathi) {
      DSettings.set("icon29x", "" + x);
      DSettings.set("icon29y", "" + y);
      this.deathi.setLocation(x, y);
    } 
    if (e.getSource() == this.bddi) {
      DSettings.set("icon30x", "" + x);
      DSettings.set("icon30y", "" + y);
      this.bddi.setLocation(x, y);
    } 
    if (e.getSource() == this.cdi) {
      DSettings.set("icon31x", "" + x);
      DSettings.set("icon31y", "" + y);
      this.cdi.setLocation(x, y);
    } 
    if (e.getSource() == this.rolandi) {
      DSettings.set("icon32x", "" + x);
      DSettings.set("icon32y", "" + y);
      this.rolandi.setLocation(x, y);
    } 
    if (e.getSource() == this.rasteri) {
      DSettings.set("icon33x", "" + x);
      DSettings.set("icon33y", "" + y);
      this.rasteri.setLocation(x, y);
    } 
  }
  
  public void info(int index) {
    try {
      if (index == 0) {
        this.infoindex = Util.random(this.pages - 1) + 1;
        this.qinfo.setPage(Desktop.class.getResource("info/info" + this.infoindex + ".html"));
      } else {
        this.qinfo.setPage(Desktop.class.getResource("info/info" + index + ".html"));
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public static boolean closeFormat = false;
  
  public static int selectedInk;
  
  public void launchIni() {
    if (this.ini == null) {
      this.desktop.add(this.ini = new JInternalFrame("Format disk"));
      this.ini.add((Component)new FormatPanel());
      this.ini.setVisible(true);
      this.ini.pack();
      this.ini.setClosable(true);
      this.ini.setDefaultCloseOperation(1);
      this.ini.setResizable(false);
      this.ini.setIconifiable(true);
      this.ini.setMaximizable(false);
      this.ini.toFront();
    } else {
      this.ini.setVisible(true);
    } 
  }
  
  public void checkKeyboard() {
    if (this.keyBoard == null) {
      this.keyBoard = GateArray.cpc.VirtualKeys();
      this.keyboard.add(this.keyBoard, "Center");
      this.keyboard.pack();
    } 
    this.keyboard.setVisible(true);
    this.keyboard.toFront();
  }
  
  private void Mandel() {
    if (this.mand == null) {
      this.mand = new Mandel3();
      this.mand.setPreferredSize(new Dimension(320, 200));
      this.mandel.add(this.mand);
      this.mand.init();
    } 
    this.mand.reset();
    this.mand.type();
    this.mandel.pack();
    this.mandel.setVisible(true);
    this.mandel.toFront();
  }
  
  private void updateMemorybar() {
    int total = (int)Runtime.getRuntime().totalMemory();
    int used = (int)(total - Runtime.getRuntime().freeMemory());
    this.memoryBar.setMaximum(total);
    this.memoryBar.setValue(used);
    this.memoryBar.setString((used / 1024) + " KB / " + (total / 1024) + " KB");
  }
  
  static Color offred = new Color(51, 0, 0);
  
  static Color offblue = new Color(0, 0, 51);
  
  public static void setFloppyHead(int pos) {
    if (floppy == null)
      return; 
    if (floppy.isVisible()) {
      if (UPD765A.nooftracks > 42)
        pos >>= 1; 
      head.setLocation(70, 41 + pos);
    } 
  }
  
  public static void setLed(int drive, boolean on) {
    if (floppy == null)
      return; 
    if (floppy.isVisible())
      switch (drive) {
        case 0:
          fled0.setBackground(on ? Color.RED : offred);
          break;
        case 1:
          fled1.setBackground(on ? Color.RED : offred);
          break;
        case 2:
          fled2.setBackground(on ? Color.RED : offred);
          break;
        case 3:
          fled3.setBackground(on ? Color.RED : offred);
          break;
      }  
    switch (drive) {
      case 0:
        led0.setBackground(on ? Color.RED : offred);
        break;
      case 1:
        led1.setBackground(on ? Color.RED : offred);
        break;
      case 2:
        led2.setBackground(on ? Color.RED : offred);
        break;
      case 3:
        led3.setBackground(on ? Color.RED : offred);
        break;
      case 4:
        led0.setBackground(on ? Color.BLUE : offblue);
        break;
    } 
  }
  
  public static void updateCurrent() {
    int r = jSlider3.getValue();
    int g = jSlider4.getValue();
    int b = jSlider5.getValue();
    rgb.setText(Util.hex((byte)r) + Util.hex((byte)g) + Util.hex((byte)b));
    selpan.setBackground(new Color(r, g, b));
  }
  
  public static void updatePalette(boolean save) {
    if (save) {
      jSlider3.setValue(Integer.parseInt(fieldRed.getText()));
      jSlider4.setValue(Integer.parseInt(fieldGreen.getText()));
      jSlider5.setValue(Integer.parseInt(fieldBlue.getText()));
      int r = jSlider3.getValue();
      int g = jSlider4.getValue();
      int b = jSlider5.getValue();
      String c = "" + Util.hex((byte)r) + Util.hex((byte)g) + Util.hex((byte)b);
      rgb.setText(c);
      String ink = "" + selectedInk;
      if (selectedInk < 10)
        ink = "0" + ink; 
      Palette.set("ink_" + ink, c);
      GateArray.setUserPalette(selectedInk, r, g, b);
    } 
    pan1.setBackground(new Color(Palette.getRGB(0)));
    pan2.setBackground(new Color(Palette.getRGB(1)));
    pan3.setBackground(new Color(Palette.getRGB(2)));
    pan4.setBackground(new Color(Palette.getRGB(3)));
    pan5.setBackground(new Color(Palette.getRGB(4)));
    pan6.setBackground(new Color(Palette.getRGB(5)));
    pan7.setBackground(new Color(Palette.getRGB(6)));
    pan8.setBackground(new Color(Palette.getRGB(7)));
    pan9.setBackground(new Color(Palette.getRGB(8)));
    pan10.setBackground(new Color(Palette.getRGB(9)));
    pan11.setBackground(new Color(Palette.getRGB(10)));
    pan12.setBackground(new Color(Palette.getRGB(11)));
    pan13.setBackground(new Color(Palette.getRGB(12)));
    pan14.setBackground(new Color(Palette.getRGB(13)));
    pan15.setBackground(new Color(Palette.getRGB(14)));
    pan16.setBackground(new Color(Palette.getRGB(15)));
    pan17.setBackground(new Color(Palette.getRGB(16)));
    pan18.setBackground(new Color(Palette.getRGB(17)));
    pan19.setBackground(new Color(Palette.getRGB(18)));
    pan20.setBackground(new Color(Palette.getRGB(19)));
    pan21.setBackground(new Color(Palette.getRGB(20)));
    pan22.setBackground(new Color(Palette.getRGB(21)));
    pan23.setBackground(new Color(Palette.getRGB(22)));
    pan24.setBackground(new Color(Palette.getRGB(23)));
    pan25.setBackground(new Color(Palette.getRGB(24)));
    pan26.setBackground(new Color(Palette.getRGB(25)));
    pan27.setBackground(new Color(Palette.getRGB(26)));
    pan28.setBackground(new Color(Palette.getRGB(27)));
    pan29.setBackground(new Color(Palette.getRGB(28)));
    pan30.setBackground(new Color(Palette.getRGB(29)));
    pan31.setBackground(new Color(Palette.getRGB(30)));
    pan32.setBackground(new Color(Palette.getRGB(31)));
    selpan.setBackground(new Color(Palette.getRGB(selectedInk)));
    fieldRed.setText((new Color(Palette.getRGB(selectedInk))).getRed() + "");
    fieldGreen.setText((new Color(Palette.getRGB(selectedInk))).getGreen() + "");
    fieldBlue.setText((new Color(Palette.getRGB(selectedInk))).getBlue() + "");
    jSlider3.setValue((new Color(Palette.getRGB(selectedInk))).getRed());
    jSlider4.setValue((new Color(Palette.getRGB(selectedInk))).getGreen());
    jSlider5.setValue((new Color(Palette.getRGB(selectedInk))).getBlue());
  }
  
  protected void setDriveHeads() {
    JEMU.forcehead = 1;
    boolean head = Settings.getBoolean("df0_head", false);
    if (head) {
      this.h01.setSelected(true);
      JEMU.head01 = true;
    } else {
      this.h00.setSelected(true);
      JEMU.head00 = true;
    } 
    head = Settings.getBoolean("df1_head", false);
    if (head) {
      this.h11.setSelected(true);
      JEMU.head11 = true;
    } else {
      this.h10.setSelected(true);
      JEMU.head10 = true;
    } 
    head = Settings.getBoolean("df2_head", false);
    if (head) {
      this.h21.setSelected(true);
      JEMU.head21 = true;
    } else {
      this.h20.setSelected(true);
      JEMU.head20 = true;
    } 
    head = Settings.getBoolean("df1_head", false);
    if (head) {
      this.h31.setSelected(true);
      JEMU.head31 = true;
    } else {
      this.h30.setSelected(true);
      JEMU.head30 = true;
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\Desktop.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */