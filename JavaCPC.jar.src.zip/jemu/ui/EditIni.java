package jemu.ui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.BevelBorder;

public class EditIni extends JInternalFrame implements ActionListener {
  JFileChooser saveFileChooser = new JFileChooser(System.getProperty("/"));
  
  static JFileChooser loadFileChooser = new JFileChooser(System.getProperty("/"));
  
  protected GridBagConstraints gbcConstraints = null;
  
  public static String autotext;
  
  public static JTextArea textArea;
  
  public JButton button3 = new JButton(" Copy text ");
  
  public JButton button4 = new JButton(" Paste text ");
  
  public static JButton button5 = new JButton(" Load... ");
  
  public static JButton button6 = new JButton(" Save... ");
  
  protected Font font;
  
  protected Color CPC_BLUE = new Color(0, 0, 127);
  
  protected Color CPC_GRAY = new Color(127, 127, 127);
  
  public EditIni() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = new Dimension(screenSize.width / 2, screenSize.height / 2);
    int x = frameSize.width / 2 + 110;
    int y = frameSize.height / 2 + 60;
    textArea = new JTextArea();
    textArea.setLineWrap(true);
    textArea.setEditable(true);
    textArea.setAutoscrolls(true);
    textArea.setBackground(Color.WHITE);
    textArea.setForeground(Color.BLACK);
    textArea.setCaretColor(Color.BLACK);
    textArea.setSelectedTextColor(Color.DARK_GRAY);
    textArea.setSelectionColor(Color.LIGHT_GRAY);
    textArea.setBorder(new BevelBorder(1));
    textArea.setFont(new Font("Monospaced", 1, 12));
    this.button3.setCursor(Cursor.getPredefinedCursor(12));
    this.button3.setForeground(Color.YELLOW);
    this.button3.setBackground(this.CPC_BLUE);
    this.button3.setFont(this.font);
    this.button3.setBorder(new BevelBorder(0));
    this.button4.setCursor(Cursor.getPredefinedCursor(12));
    this.button4.setForeground(Color.CYAN);
    this.button4.setBackground(this.CPC_BLUE);
    this.button4.setFont(this.font);
    this.button4.setBorder(new BevelBorder(0));
    button5.setCursor(Cursor.getPredefinedCursor(12));
    button5.setForeground(Color.LIGHT_GRAY);
    button5.setBackground(this.CPC_BLUE);
    button5.setFont(this.font);
    button5.setBorder(new BevelBorder(0));
    button6.setCursor(Cursor.getPredefinedCursor(12));
    button6.setForeground(Color.WHITE);
    button6.setBackground(this.CPC_BLUE);
    button6.setFont(this.font);
    button6.setBorder(new BevelBorder(0));
    getContentPane().setLayout(new GridBagLayout());
    add(this.button3, getGridBagConstraints(1, 2, 1.0D, 0.0D, 1, 1));
    add(this.button4, getGridBagConstraints(2, 2, 1.0D, 0.0D, 1, 1));
    add(button5, getGridBagConstraints(1, 3, 1.0D, 0.0D, 1, 1));
    add(button6, getGridBagConstraints(2, 3, 1.0D, 0.0D, 1, 1));
    add(new JScrollPane(textArea), getGridBagConstraints(1, 1, 1.0D, 1.0D, 5, 1));
    setVisible(true);
    this.button3.addActionListener(this);
    this.button3.setFocusable(false);
    this.button4.addActionListener(this);
    this.button4.setFocusable(false);
    button5.addActionListener(this);
    button5.setFocusable(false);
    button6.addActionListener(this);
    button6.setFocusable(false);
    open();
  }
  
  private GridBagConstraints getGridBagConstraints(int x, int y, double weightx, double weighty, int width, int fill) {
    if (this.gbcConstraints == null)
      this.gbcConstraints = new GridBagConstraints(); 
    this.gbcConstraints.gridx = x;
    this.gbcConstraints.gridy = y;
    this.gbcConstraints.weightx = weightx;
    this.gbcConstraints.weighty = weighty;
    this.gbcConstraints.gridwidth = width;
    this.gbcConstraints.fill = fill;
    return this.gbcConstraints;
  }
  
  public synchronized void windowClosing(WindowEvent evt) {
    dispose();
  }
  
  public synchronized void actionPerformed(ActionEvent evt) {
    if (evt.getSource() == this.button3 && 
      !textArea.getText().equals("")) {
      textArea.selectAll();
      textArea.copy();
      textArea.paste();
    } 
    if (evt.getSource() == this.button4)
      textArea.paste(); 
    if (evt.getSource() == button5)
      open(); 
    if (evt.getSource() == button6)
      save(); 
  }
  
  public static void open() {
    File file;
    if (Switches.executable) {
      file = new File(System.getProperty("/"), "javacpc.ini");
    } else {
      file = new File(System.getProperty("user.home"), "javacpc.ini");
    } 
    StringBuffer contents = new StringBuffer();
    BufferedReader reader = null;
    try {
      reader = new BufferedReader(new FileReader(file));
      String text = null;
      while ((text = reader.readLine()) != null)
        contents.append(text).append(System.getProperty("line.separator")); 
    } catch (FileNotFoundException fileNotFoundException) {
      try {
        if (reader != null)
          reader.close(); 
      } catch (IOException iOException) {}
    } catch (IOException iOException) {
      try {
        if (reader != null)
          reader.close(); 
      } catch (IOException iOException1) {}
    } finally {
      try {
        if (reader != null)
          reader.close(); 
      } catch (IOException iOException) {}
    } 
    textArea.setText(contents.toString());
  }
  
  public static void save() {
    File file;
    if (Switches.executable) {
      file = new File(System.getProperty("/"), "javacpc.ini");
    } else {
      file = new File(System.getProperty("user.home"), "javacpc.ini");
    } 
    String gettext = textArea.getText();
    try {
      FileWriter fw = new FileWriter(file);
      fw.write(gettext);
      fw.close();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\EditIni.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */