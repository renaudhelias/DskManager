package jemu.ui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.InputStream;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.LayoutStyle;

public class CMDInfo extends JFrame {
  public static String h = "JavaCPC Desktop " + Main.version + Main.subversion + " ©" + Main.year + " by Markus Hohmann\r\n" + "Commands: |    value:   |    info:\r\n" + "--cpctype      <CPC type*>         Sets emulated CPC model*\r\n" + "--df0/--drivea <path to DSK file>  loads a DSK into DF0\r\n" + "--df1/--driveb <path to DSK file>  loads a DSK into DF1\r\n" + "--tape         <path to CDT file>  loads a tape image\r\n" + "--sna          <path to SNA file>  loads a snapshot\r\n" + "--bootdrive    <df0/df1/tape>      Boot choosen drive\r\n" + "--amsdos       <yes/no>            Put AMSDOS rom?\r\n" + "--crtc         <0/1>               Sets CRTC type\r\n" + "--autotype     <content>           1 line for autotype\r\n" + "--assemble     <path to ASM file>  Assemble file into RAM\r\n" + "--desktop      <on/off>            Start as desktop or app.\r\n" + "--wallpaper    <path to wallpaper> Choose wallpaper\r\n" + "--stretch      <on/off>            Stretch or center wallpaper\r\n" + "--memory       <64/128/256/512>    Defines emulated RAM\r\n" + "--monitor      <color/green/grey/cpce>\r\n" + "--polarity     <on/off>            Toggles tape polarity\r\n" + "--help                             this info\r\n" + "--------------------------------------------------------------\r\n" + "*Possible CPC-models:\r\n" + "CPC464,CPC464T,CPC664,CPC6128,KCCOMPACT\r\n" + "CPC464PARA,PARADOS,FUTUREOS,SYMBOS\r\n";
  
  private JTextArea info;
  
  private JButton jButton1;
  
  private JScrollPane jScrollPane1;
  
  public CMDInfo() {
    initComponents();
    try {
      InputStream in = getClass().getResourceAsStream("amstrad_cpc464.ttf");
      Font font = Font.createFont(0, in).deriveFont(0, 8.0F);
      this.info.setFont(font);
    } catch (Exception exception) {}
    this.info.setText(h);
    System.out.println(h);
  }
  
  private void initComponents() {
    this.jButton1 = new JButton();
    this.jScrollPane1 = new JScrollPane();
    this.info = new JTextArea();
    setDefaultCloseOperation(3);
    setTitle("JavaCPC Info");
    this.jButton1.setText("Close");
    this.jButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            CMDInfo.this.jButton1ActionPerformed(evt);
          }
        });
    this.info.setEditable(false);
    this.info.setBackground(new Color(0, 0, 102));
    this.info.setColumns(25);
    this.info.setForeground(new Color(255, 255, 0));
    this.info.setRows(6);
    this.jScrollPane1.setViewportView(this.info);
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap(424, 32767)
          .addComponent(this.jButton1)
          .addContainerGap())
        .addComponent(this.jScrollPane1, -1, 493, 32767));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
          .addComponent(this.jScrollPane1, -1, 203, 32767)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.jButton1)
          .addContainerGap()));
    pack();
  }
  
  private void jButton1ActionPerformed(ActionEvent evt) {
    System.exit(0);
  }
  
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new CMDInfo()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\CMDInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */