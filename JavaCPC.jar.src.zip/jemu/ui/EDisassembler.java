package jemu.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.net.URL;
import javax.swing.JComponent;
import javax.swing.JScrollBar;
import javax.swing.border.BevelBorder;
import jemu.core.Util;
import jemu.core.device.Computer;
import jemu.util.diss.Disassembler;

public class EDisassembler extends JComponent implements MouseWheelListener, AdjustmentListener, TimerListener {
  public void mouseWheelMoved(MouseWheelEvent e) {
    if (e.getUnitsToScroll() > 0) {
      if (this.scrollBar.getValue() < this.scrollBar.getMaximum() - 1)
        this.scrollBar.setValue(this.scrollBar.getValue() + 1); 
    } else if (this.scrollBar.getValue() > 1) {
      this.scrollBar.setValue(this.scrollBar.getValue() - 1);
    } 
  }
  
  public boolean read = true;
  
  public boolean any = false;
  
  public int forcedbank = 192;
  
  protected static final Color selBackground = new Color(190, 190, 200);
  
  protected static final Color selBreakPoint = new Color(200, 0, 0);
  
  protected static final Color selForeground = new Color(16777215);
  
  protected static final Color pcBackground = new Color(127);
  
  protected static final Color pcBreakPoint = new Color(16744576);
  
  protected static final Color pcForeground = new Color(8421631);
  
  protected JScrollBar scrollBar = new JScrollBar(1);
  
  protected int address = 0;
  
  protected int maxAddress = 65535;
  
  protected int pc = 0;
  
  protected Computer computer;
  
  protected int lineHeight = 0;
  
  protected int[] addresses = new int[0];
  
  protected int selAnchor = 0;
  
  protected int selStart = 0;
  
  protected int selEnd = 0;
  
  protected int timerY = 0;
  
  protected Counter counter = null;
  
  protected boolean inSet = false;
  
  Font f = new Font("Monospaced", 0, 12);
  
  Font fb = new Font("Monospaced", 1, 12);
  
  Font fc = new Font("Monospaced", 2, 12);
  
  final URL PCo;
  
  final Image PCi;
  
  final URL BPo;
  
  final Image BPi;
  
  final URL SPo;
  
  final Image SPi;
  
  public int selline;
  
  public void setComputer(Computer value) {
    this.computer = value;
    this.scrollBar.setMinimum(0);
    this.scrollBar.setMaximum(65552);
    this.scrollBar.setVisibleAmount(16);
    this.maxAddress = this.computer.getMemory().getAddressSize() - 1;
    repaint();
  }
  
  public Dimension getPreferredSize() {
    return new Dimension(200, 200);
  }
  
  public EDisassembler() {
    this.PCo = getClass().getResource("ico/go.gif");
    this.PCi = getToolkit().getImage(this.PCo);
    this.BPo = getClass().getResource("ico/bp.gif");
    this.BPi = getToolkit().getImage(this.BPo);
    this.SPo = getClass().getResource("ico/sp.gif");
    this.SPi = getToolkit().getImage(this.SPo);
    enableEvents(48L);
    setBackground(Color.white);
    setForeground(new Color(0, 128, 0));
    setBorder(new BevelBorder(1));
    setFont(new Font("Monospaced", 0, 12));
    setLayout(new BorderLayout());
    this.scrollBar.addAdjustmentListener(this);
    this.scrollBar.setBlockIncrement(16);
    add(this.scrollBar, "East");
    addMouseWheelListener(this);
    setFocusable(true);
    setDoubleBuffered(false);
  }
  
  protected void paintComponent(Graphics g) {
    Insets insets = getInsets();
    Rectangle rect = new Rectangle(insets.left + 1, insets.top + 1, getWidth() - this.scrollBar.getWidth() - insets.left - insets.right - 2, getHeight() - insets.top - insets.bottom - 2);
    g.setColor(getBackground());
    g.fillRect(rect.x, rect.y, rect.width, rect.height);
    FontMetrics fm = g.getFontMetrics();
    if (this.computer != null) {
      Disassembler diss = this.computer.getDisassembler();
      if (diss != null) {
        diss.read = this.read;
        diss.any = this.any;
        diss.forcedbank = this.forcedbank;
        int a = fm.getAscent();
        int[] addr = { this.address };
        int h = this.lineHeight = fm.getHeight();
        this.addresses = new int[(rect.height + h - 1) / h];
        int n = 0;
        int y;
        for (y = rect.y; y < rect.y + rect.height; y += fm.getHeight()) {
          int st = fm.getHeight();
          this.addresses[n++] = addr[0];
          if (addr[0] >= this.selStart && addr[0] <= this.selEnd) {
            g.setColor(selBackground);
            g.fillRect(rect.x + 30, y, rect.width - 31, fm.getHeight());
            g.drawRect(rect.x + 29, y - 1, rect.width - 30, fm.getHeight() + 1);
            g.setColor((selForeground == null) ? getForeground() : selForeground);
          } 
          if (addr[0] == this.pc) {
            g.setColor(Color.yellow);
            g.fillRect(rect.x + 30, y, rect.width - 31, fm.getHeight());
            g.drawImage(this.PCi, rect.x + 20, y + 4, this);
          } 
          if (JEMU.debugger.isBreakpoint(addr[0])) {
            g.setColor(pcBreakPoint);
            g.fillRect(rect.x + 30, y, rect.width - 31, fm.getHeight());
            g.drawImage(this.BPi, 3, y + 4, this);
            g.setColor(getForeground());
          } 
          if (addr[0] == this.selline) {
            g.setColor(pcForeground);
            g.drawImage(this.SPi, rect.x + rect.width - 10, y + 8, this);
            for (int j = rect.x; j < rect.width; j += 8)
              g.drawLine(j, y + st, j + 6, y + st); 
          } 
          g.setColor(getForeground());
          String line = diss.disassemble(this.computer.getMemory(), addr, true, 30, 50);
          line = line.substring(0, line.length() - 6);
          g.setFont(getFont());
          String l1 = "";
          g.setFont(this.f);
          int i;
          for (i = 0; i < 5; i++)
            l1 = l1 + "" + line.charAt(i); 
          g.setColor(Color.gray);
          g.drawString(l1, rect.x + 30, y + a);
          l1 = "";
          for (i = 5; i < 28; i++)
            l1 = l1 + "" + line.charAt(i); 
          g.setColor(Color.blue);
          g.setFont(this.fb);
          g.drawString(l1, rect.x + 74, y + a);
          l1 = "";
          for (i = 28; i < line.length(); i++)
            l1 = l1 + "" + line.charAt(i); 
          g.setFont(this.fc);
          g.setColor(getForeground());
          if (l1.contains(";")) {
            if (Debugger.bWinape.isSelected())
              l1 = l1.substring(3); 
            String[] gg = l1.split(";");
            String b = gg[1];
            String AA = "" + b.charAt(0) + b.charAt(1);
            String BB = "" + b.charAt(3) + b.charAt(4);
            String CC = "" + b.charAt(6) + b.charAt(7);
            String DD = "" + b.charAt(9) + b.charAt(10);
            if (!AA.contains(" "))
              try {
                int aa = Util.hexValue(AA);
                if (aa > 31 && aa < 129) {
                  l1 = l1 + "  " + (char)aa;
                } else {
                  l1 = l1 + "  .";
                } 
              } catch (Exception exception) {} 
            if (!BB.contains(" "))
              try {
                int aa = Util.hexValue(BB);
                if (aa > 31 && aa < 129) {
                  l1 = l1 + "" + (char)aa;
                } else {
                  l1 = l1 + ".";
                } 
              } catch (Exception exception) {} 
            if (!CC.contains(" "))
              try {
                int aa = Util.hexValue(CC);
                if (aa > 31 && aa < 129) {
                  l1 = l1 + "" + (char)aa;
                } else {
                  l1 = l1 + ".";
                } 
              } catch (Exception exception) {} 
            if (!DD.contains(" "))
              try {
                int aa = Util.hexValue(DD);
                if (aa > 31 && aa < 129) {
                  l1 = l1 + "" + (char)aa;
                } else {
                  l1 = l1 + ".";
                } 
              } catch (Exception exception) {} 
          } 
          if (Debugger.bWinape.isSelected())
            l1 = "  ;" + l1; 
          g.drawString(l1, rect.x + 220, y + a);
        } 
        this.scrollBar.setVisibleAmount(rect.height / h);
      } 
    } 
    g.setColor(Color.black);
    g.drawRect(rect.x - 1, rect.y - 1, rect.width + 1, rect.height + 1);
  }
  
  public void setPC(int value) {
    setAddress(this.pc = value, true);
  }
  
  public void setAddress(int value, boolean scroll) {
    this.address = Math.min(65535, value);
    repaint();
    if (scroll) {
      this.inSet = true;
      this.scrollBar.setValue(this.address);
      this.inSet = false;
    } 
  }
  
  public void setAddress(int value) {
    setAddress(value, true);
  }
  
  public int getAddress(int y) {
    Insets insets = getInsets();
    y = (y - insets.top + 1) / this.lineHeight;
    return (y < 0 || y >= this.addresses.length) ? -1 : this.addresses[y];
  }
  
  public void adjustmentValueChanged(AdjustmentEvent e) {
    if (!this.inSet) {
      int i;
      switch (e.getValue() - this.address) {
        case 1:
          nextAddress();
          break;
        case -1:
          prevAddress();
          break;
        case 16:
          for (i = Math.max(1, this.addresses.length - 1); i > 0; i--)
            nextAddress(); 
          break;
        case -16:
          for (i = Math.max(1, this.addresses.length - 1); i > 0; i--)
            prevAddress(); 
          break;
        default:
          setAddress(this.scrollBar.getValue());
          break;
      } 
      this.scrollBar.setValue(this.address);
    } 
  }
  
  protected void nextAddress() {
    Disassembler diss = this.computer.getDisassembler();
    diss.disassemble(this.computer.getMemory(), this.addresses, false, 0, 0);
    setAddress(this.addresses[0], false);
  }
  
  protected void prevAddress() {
    int end = this.addresses[0];
    int addr = end - 6 & 0xFFFF;
    Disassembler diss = this.computer.getDisassembler();
    while (true) {
      int result = addr;
      this.addresses[0] = addr;
      diss.disassemble(this.computer.getMemory(), this.addresses, false, 0, 0);
      addr = this.addresses[0];
      if (addr != end)
        addr = result + 1 & 0xFFFF; 
      if (addr == end) {
        setAddress(this.addresses[0] = result, false);
        return;
      } 
    } 
  }
  
  protected void setSelection(int addr, boolean range) {
    if (!range) {
      this.selAnchor = this.selStart = this.selEnd = addr;
    } else if (addr < this.selAnchor) {
      this.selStart = addr;
      this.selEnd = this.selAnchor;
    } else {
      this.selStart = this.selAnchor;
      this.selEnd = addr;
    } 
  }
  
  protected void startTimer(int y) {
    if (this.counter == null)
      this.counter = new Counter(this, 50L, null); 
    this.timerY = y;
  }
  
  protected void stopTimer() {
    if (this.counter != null) {
      this.counter.stop();
      this.counter = null;
    } 
  }
  
  public void timerTick(Counter counter) {
    if (this.counter == counter) {
      if (this.timerY < 0) {
        prevAddress();
        setSelection(this.address, true);
      } else {
        nextAddress();
        setSelection(this.addresses[this.addresses.length - 1], true);
      } 
      this.scrollBar.setValue(this.address);
      repaint();
    } 
  }
  
  protected void processMouseEvent(MouseEvent e) {
    if (e.getButton() == 1) {
      if (e.getID() == 501) {
        setSelection(getAddress(e.getY()), ((e.getModifiers() & 0x1) != 0));
        Debugger.breakaddress = getAddress(e.getY());
        requestFocus();
        repaint();
      } else if (e.getID() == 502) {
        stopTimer();
      } 
    } else {
      Debugger.breakaddress = getAddress(e.getY());
    } 
    super.processMouseEvent(e);
  }
  
  protected void processMouseMotionEvent(MouseEvent e) {
    if (e.getID() == 506 && (e.getModifiers() & 0x10) != 0) {
      Dimension size = getSize();
      int y = e.getY();
      if (y >= size.height) {
        setSelection(this.addresses[this.addresses.length - 1], true);
        startTimer(y);
      } else if (y < 0) {
        setSelection(this.addresses[0], true);
        startTimer(y);
      } else {
        setSelection(getAddress(e.getY()), true);
        stopTimer();
      } 
      repaint();
    } 
    super.processMouseMotionEvent(e);
  }
  
  protected void processKeyEvent(KeyEvent e) {
    if (e.getID() == 401) {
      boolean shift = ((e.getModifiers() & 0x1) != 0);
      switch (e.getKeyCode()) {
        case 36:
          setSelection(0, shift);
          break;
        case 35:
          setSelection(this.maxAddress - 1, shift);
          break;
        case 38:
          setSelection(this.address - 1, shift);
          break;
        case 40:
          setSelection(this.address + 1, shift);
          break;
        case 34:
          setSelection(this.address + 10, shift);
          break;
        case 33:
          setSelection(this.address - 10, shift);
          break;
      } 
    } 
    super.processKeyEvent(e);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\EDisassembler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */