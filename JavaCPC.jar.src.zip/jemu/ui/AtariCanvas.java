package jemu.ui;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.awt.image.IndexColorModel;
import java.awt.image.MemoryImageSource;
import java.awt.image.WritableRaster;
import java.io.File;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Vector;
import javax.imageio.ImageIO;
import org.ibex.nestedvm.Runtime;

class AtariCanvas extends Canvas implements KeyListener {
  byte[] pixels;
  
  MemoryImageSource mis;
  
  IndexColorModel icm;
  
  Image image;
  
  int atari_width;
  
  int atari_height;
  
  int atari_visible_width;
  
  int atari_left_margin;
  
  int width;
  
  int height;
  
  int scalew;
  
  int scaleh;
  
  int size;
  
  boolean windowClosed = false;
  
  Vector keyqueue;
  
  Hashtable kbhits;
  
  byte[][] paletteTable;
  
  byte[] temp;
  
  BufferedImage bum;
  
  public void paint(Graphics g) {
    update(g);
  }
  
  boolean palFilter = false;
  
  int off = 0;
  
  int lastPix = 0;
  
  int[] imagepixels;
  
  public void doPALFilter() {
    for (this.off = 0; this.off < this.imagepixels.length; this.off++)
      this.lastPix = this.imagepixels[this.off] = (this.lastPix & 0xFEFEFE) + (this.imagepixels[this.off] & 0xFEFEFE) >> 1; 
    for (int x = 0; x < this.width * this.scalew; x++) {
      this.off = x;
      for (int y = 0; y < this.height * this.scaleh; y += 2) {
        this.imagepixels[this.off + this.width * this.scalew] = (this.imagepixels[this.off] & 0xFEFEFE) >> 1;
        this.off += this.width * this.scalew * 2;
      } 
    } 
  }
  
  boolean uneven = false;
  
  int o;
  
  int p;
  
  WritableRaster raster;
  
  Graphics d;
  
  int ts = 0;
  
  boolean RGB;
  
  public void update(Graphics g) {
    if (this.palFilter) {
      if (this.bum == null) {
        this.bum = new BufferedImage(this.width * this.scalew, this.height * this.scaleh, 1);
        this.imagepixels = new int[this.width * this.scalew * this.height * this.scaleh];
        this.o = this.width * this.scalew;
        this.p = this.height * this.scaleh;
        this.raster = this.bum.getRaster();
        this.d = this.bum.createGraphics();
      } 
      this.d.drawImage(this.image, 0, 0, this.o, this.p, null);
      this.raster.getDataElements(0, 0, this.o, this.p, this.imagepixels);
      if (this.RGB) {
        this.off = 0;
        this.uneven = false;
        this.ts = 0;
        for (int i = 0; i < this.imagepixels.length; i++) {
          this.off++;
          if (this.off == this.o) {
            this.ts = this.uneven ? 2 : 0;
            this.uneven = !this.uneven;
            this.off = 0;
          } 
          this.ts++;
          if (this.ts > 3)
            this.ts = 0; 
          switch (this.ts) {
            case 0:
              this.imagepixels[i] = this.imagepixels[i] & 0xFF0000;
              break;
            case 1:
              this.imagepixels[i] = this.imagepixels[i] & 0xFF00;
              break;
            case 2:
              this.imagepixels[i] = this.imagepixels[i] & 0xFF;
              break;
          } 
        } 
      } else {
        doPALFilter();
      } 
      this.raster.setDataElements(0, 0, this.o, this.p, this.imagepixels);
      this.bum.setData(this.raster);
      g.drawImage(this.bum, 0, 0, this.o, this.p, null);
    } else {
      g.drawImage(this.image, 0, 0, this.width * this.scalew, this.height * this.scaleh, null);
    } 
  }
  
  public void writeScreen() {
    this.imagepixels = new int[this.width * this.scalew * this.height * this.scaleh];
    this.o = this.width * this.scalew;
    this.p = this.height * this.scaleh;
    this.bum = new BufferedImage(this.width * this.scalew, this.height * this.scaleh, 1);
    this.raster = this.bum.getRaster();
    this.d = this.bum.createGraphics();
    this.d = this.bum.createGraphics();
    this.d.drawImage(this.image, 0, 0, this.o, this.p, null);
    if (this.palFilter) {
      this.raster.getDataElements(0, 0, this.o, this.p, this.imagepixels);
      if (this.RGB) {
        this.off = 0;
        this.uneven = false;
        this.ts = 0;
        for (int i = 0; i < this.imagepixels.length; i++) {
          this.off++;
          if (this.off == this.o) {
            this.ts = this.uneven ? 2 : 0;
            this.uneven = !this.uneven;
            this.off = 0;
          } 
          this.ts++;
          if (this.ts > 3)
            this.ts = 0; 
          switch (this.ts) {
            case 0:
              this.imagepixels[i] = this.imagepixels[i] & 0xFF0000;
              break;
            case 1:
              this.imagepixels[i] = this.imagepixels[i] & 0xFF00;
              break;
            case 2:
              this.imagepixels[i] = this.imagepixels[i] & 0xFF;
              break;
          } 
        } 
      } else {
        doPALFilter();
      } 
      this.raster.setDataElements(0, 0, this.o, this.p, this.imagepixels);
      this.bum.setData(this.raster);
    } 
    int pos = 0;
    String b = "";
    if (pos < 10)
      b = b + "0"; 
    if (pos < 100)
      b = b + "0"; 
    File fil = new File("atari" + b + pos + ".png");
    while (fil.exists()) {
      pos++;
      b = "";
      if (pos < 10)
        b = b + "0"; 
      if (pos < 100)
        b = b + "0"; 
      fil = new File("atari" + b + pos + ".png");
    } 
    try {
      ImageIO.write(this.bum, "png", fil);
    } catch (Exception e) {
      System.out.println("Error writing " + fil.getName());
    } 
    requestFocus();
  }
  
  public void init() {
    this.width = this.atari_visible_width;
    this.temp = new byte[this.width];
    this.height = this.atari_height;
    this.size = this.width * this.height;
    this.pixels = new byte[this.size];
    for (int i = 0; i < this.size; i++)
      this.pixels[i] = 0; 
    this.keyqueue = new Vector();
    addKeyListener(this);
    this.kbhits = new Hashtable<>();
  }
  
  public void initPalette(Runtime rt, int colortable) {
    this.paletteTable = new byte[3][256];
    int entry = 0;
    for (int i = 0; i < 256; i++) {
      try {
        entry = rt.memRead(colortable + i * 4);
      } catch (Exception e) {
        System.err.println(e);
      } 
      this.paletteTable[0][i] = (byte)(entry >>> 16 & 0xFF);
      this.paletteTable[1][i] = (byte)(entry >>> 8 & 0xFF);
      this.paletteTable[2][i] = (byte)(entry & 0xFF);
    } 
    this.paletteTable[0][0] = 0;
    this.paletteTable[1][0] = 0;
    this.paletteTable[2][0] = 0;
    this.icm = new IndexColorModel(8, 256, this.paletteTable[0], this.paletteTable[1], this.paletteTable[2]);
    this.mis = new MemoryImageSource(this.width, this.height, this.icm, this.pixels, 0, this.width);
    this.mis.setAnimated(true);
    this.mis.setFullBufferUpdates(true);
    this.image = createImage(this.mis);
  }
  
  public void displayScreen(Runtime rt, int atari_screen) {
    int ao = atari_screen + this.atari_left_margin;
    int po = 0;
    for (int h = 0; h < 240; h++) {
      try {
        rt.copyin(ao, this.temp, this.width);
        System.arraycopy(this.temp, 0, this.pixels, po, this.width);
      } catch (Exception exception) {}
      ao += this.atari_width;
      po += this.width;
    } 
    this.mis.newPixels();
    repaint();
  }
  
  public void setWindowClosed() {
    this.windowClosed = true;
  }
  
  public void keyPressed(KeyEvent event) {
    char chr = event.getKeyChar();
    int key = event.getKeyCode();
    int loc = event.getKeyLocation();
    if (key == 120)
      return; 
    if (key == 121)
      return; 
    this.keyqueue.addElement(event);
    Integer[] val = new Integer[2];
    val[0] = new Integer(key);
    val[1] = new Integer(loc);
    this.kbhits.put(Arrays.asList(val), new Boolean(true));
  }
  
  public void keyReleased(KeyEvent event) {
    char chr = event.getKeyChar();
    int key = event.getKeyCode();
    if (key == 120)
      try {
        System.exit(0);
        return;
      } catch (Exception e) {
        return;
      }  
    if (key == 121) {
      writeScreen();
      return;
    } 
    if (key == 123) {
      this.palFilter = false;
      repaint();
    } 
    if (key == 122) {
      this.RGB = !this.RGB;
      this.palFilter = true;
      repaint();
    } 
    int loc = event.getKeyLocation();
    this.keyqueue.addElement(event);
    Integer[] val = new Integer[2];
    val[0] = new Integer(key);
    val[1] = new Integer(loc);
    this.kbhits.remove(Arrays.asList(val));
  }
  
  public void keyTyped(KeyEvent event) {}
  
  int getKbhits(int key, int loc) {
    Integer[] val = new Integer[2];
    val[0] = new Integer(key);
    val[1] = new Integer(loc);
    if (this.kbhits.get(Arrays.asList(val)) != null)
      return 1; 
    return 0;
  }
  
  int pollKeyEvent(Runtime rt, int return_event) {
    if (this.keyqueue.isEmpty())
      return 0; 
    KeyEvent event = this.keyqueue.firstElement();
    this.keyqueue.removeElement(event);
    int type = event.getID();
    int key = event.getKeyCode();
    char uni = event.getKeyChar();
    int loc = event.getKeyLocation();
    try {
      rt.memWrite(return_event + 0, type);
      rt.memWrite(return_event + 4, key);
      rt.memWrite(return_event + 8, uni);
      rt.memWrite(return_event + 12, loc);
    } catch (Exception e) {
      System.err.println(e);
    } 
    return 1;
  }
  
  int getWindowClosed() {
    return this.windowClosed ? 1 : 0;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\AtariCanvas.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */