package jemu.ui;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class CheckResources {
  BufferedOutputStream bos;
  
  File file;
  
  public void checkResources() {
    try {
      String path = "resources/";
      try {
        boolean nowrite = false;
        byte[] data = getResource(path + "Update.jar");
        File fil = new File("./Update.jar");
        if (fil.exists()) {
          BufferedInputStream in = new BufferedInputStream(new FileInputStream(fil));
          int i = in.available();
          if (i != data.length) {
            fil.delete();
          } else {
            nowrite = true;
          } 
        } 
        if (!nowrite) {
          this.bos = new BufferedOutputStream(new FileOutputStream(fil));
          this.bos.write(data);
          this.bos.close();
          String command = "java -jar update.jar";
          Runtime.getRuntime().exec(command);
          System.exit(0);
        } 
      } catch (Exception e) {
        JOptionPane.showMessageDialog(new JFrame(), "Please restart JavaCPC with admin rights\r\nto copy the required libraries.\r\nLater you can remove the admin rights!");
        System.exit(0);
      } 
      String res = "2cdt.exe";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      File f = new File(System.getProperty("user.home"), "/JavaCPC");
      if (!f.exists())
        f.mkdir(); 
      f = new File(System.getProperty("user.home"), "/JavaCPC/tools");
      if (!f.exists())
        f.mkdir(); 
      int copied = 0;
      System.out.println("Checking resource files...");
      checkFile(this.file, path, res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      res = "cpcxfs.exe";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      checkFile(this.file, path, res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      res = "speak.exe";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      checkFile(this.file, path, res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      res = "SAMdisk.exe";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      checkFile(this.file, path, res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      res = "samp2cdt.exe";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      checkFile(this.file, path, res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      res = "JoyToKey.exe";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      checkFile(this.file, path, res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      res = "JoyToKey.ini";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      res = "JavaCPC.cfg";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      System.out.println("Transferred " + copied + " file(s)");
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void checkFileResources() {
    try {
      String path = "resources/";
      String res = "2cdt.exe";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      File f = new File(System.getProperty("user.home"), "/JavaCPC");
      if (!f.exists())
        f.mkdir(); 
      f = new File(System.getProperty("user.home"), "/JavaCPC/tools");
      if (!f.exists())
        f.mkdir(); 
      int copied = 0;
      System.out.println("Checking resource files...");
      checkFile(this.file, path, res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      res = "cpcxfs.exe";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      checkFile(this.file, path, res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      res = "SAMdisk.exe";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      checkFile(this.file, path, res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      res = "samp2cdt.exe";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      checkFile(this.file, path, res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      res = "speak.exe";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      checkFile(this.file, path, res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      res = "JoyToKey.exe";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      checkFile(this.file, path, res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      res = "JoyToKey.ini";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      res = "JavaCPC.cfg";
      this.file = new File(System.getProperty("user.home"), "/JavaCPC/tools/" + res);
      if (!this.file.exists()) {
        copied++;
        byte[] data = getResource(path + res);
        this.bos = new BufferedOutputStream(new FileOutputStream(this.file));
        this.bos.write(data);
        this.bos.close();
      } 
      System.out.println("Transferred " + copied + " file(s)");
    } catch (Exception exception) {}
  }
  
  protected void checkFile(File file, String path, String res) {
    try {
      if (file.exists()) {
        byte[] data = getResource(path + res);
        int len = data.length;
        byte[] check = new byte[(int)file.length()];
        try (BufferedInputStream bin = new BufferedInputStream(new FileInputStream(file))) {
          bin.read(check);
          bin.close();
        } catch (Exception exception) {}
        int len2 = check.length;
        if (len2 != len)
          file.delete(); 
      } 
    } catch (Exception exception) {}
  }
  
  public byte[] getResource(String name) {
    byte[] buffer = null;
    int offs = 0;
    try {
      InputStream stream = null;
      try {
        stream = getClass().getResourceAsStream(name);
        int size = stream.available();
        buffer = new byte[size];
        while (size > 0) {
          int read = stream.read(buffer, offs, size);
          if (read == -1)
            break; 
          offs += read;
          size -= read;
        } 
      } finally {
        if (stream != null)
          stream.close(); 
      } 
    } catch (Exception e) {
      System.err.println("File not found...");
    } 
    return buffer;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\CheckResources.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */