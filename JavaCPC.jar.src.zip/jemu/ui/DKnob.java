package jemu.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.Arc2D;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.EventListenerList;

public class DKnob extends JComponent {
  private static final long serialVersionUID = -3944978568068155143L;
  
  private static final float START = 225.0F;
  
  private static final float LENGTH = 270.0F;
  
  private static final float PI = 3.1415F;
  
  private static final float START_ANG = 3.926875F;
  
  private static final float LENGTH_ANG = 4.7122498F;
  
  private static final float MULTIP = 57.29747F;
  
  private static final Color DEFAULT_FOCUS_COLOR = new Color(8454016);
  
  public static final Color DARK = new Color(0, 0, 0, 224);
  
  public static final Color DARK_T = new Color(48, 48, 48, 128);
  
  public static final Color DARK_L = new Color(128, 128, 128, 160);
  
  public static final Color LIGHT_D = new Color(160, 160, 160, 160);
  
  public static final Color LIGHT = new Color(192, 192, 192, 160);
  
  public static final Color LIGHT_T = new Color(192, 192, 192, 128);
  
  private float DRAG_SPEED;
  
  private float CLICK_SPEED;
  
  private int size;
  
  private int middle;
  
  private String label = "";
  
  private String type = "";
  
  public static final int SIMPLE = 1;
  
  public static final int ROUND = 2;
  
  private int dragType = 2;
  
  private Polygon knob = new Polygon();
  
  private static final Dimension MIN_SIZE = new Dimension(30, 40);
  
  private static final Dimension PREF_SIZE = new Dimension(40, 60);
  
  private static final RenderingHints AALIAS = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
  
  private ChangeEvent changeEvent = null;
  
  private EventListenerList listenerList = new EventListenerList();
  
  private Arc2D hitArc = new Arc2D.Float(2);
  
  private float ang = 3.926875F;
  
  private float val;
  
  private int lowInt = 0;
  
  private int highInt = 100;
  
  private int medInt = 0;
  
  private int divisor = 0;
  
  private int dragpos = -1;
  
  private float startVal;
  
  private Color focusColor;
  
  private double lastAng;
  
  public DKnob(String label) {
    this(label, "");
    setDoubleBuffered(false);
  }
  
  public DKnob(String label, String type) {
    this.DRAG_SPEED = 0.01F;
    this.CLICK_SPEED = 0.01F;
    this.label = label;
    this.type = type;
    for (int i = 0, n = 120; i < n; i++) {
      int y = 20 + (int)(0.5D + (Math.sin(i * 3.141592D / 4.0D) * 1.5D + 20.0D) * Math.sin(i * 3.141592D * 2.0D / n));
      int x = 20 + (int)(0.5D + (Math.sin(i * 3.141592D / 4.0D) * 1.5D + 20.0D) * Math.cos(i * 3.141592D * 2.0D / n));
      this.knob.addPoint(x, y);
    } 
    this.focusColor = DEFAULT_FOCUS_COLOR;
    setPreferredSize(PREF_SIZE);
    setFocusable(true);
    this.hitArc.setAngleStart(235.0D);
    addMouseListener(new MouseAdapter() {
          public void mousePressed(MouseEvent me) {
            DKnob.this.dragpos = me.getX() + me.getY();
            DKnob.this.startVal = DKnob.this.val;
            int xpos = DKnob.this.middle - me.getX();
            int ypos = DKnob.this.middle - me.getY();
            DKnob.this.lastAng = Math.atan2(xpos, ypos);
            DKnob.this.requestFocus();
          }
          
          public void mouseClicked(MouseEvent me) {
            DKnob.this.hitArc.setAngleExtent(-290.0D);
            if (DKnob.this.hitArc.contains(me.getX(), me.getY())) {
              DKnob.this.hitArc.setAngleExtent((57.29747F * (DKnob.this.ang - 3.926875F) - 10.0F));
              if (DKnob.this.hitArc.contains(me.getX(), me.getY())) {
                DKnob.this.decValue();
              } else {
                DKnob.this.incValue();
              } 
            } 
          }
        });
    addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseDragged(MouseEvent me) {
            if (DKnob.this.dragType == 1) {
              float f = DKnob.this.DRAG_SPEED * (me.getX() + me.getY() - DKnob.this.dragpos);
              DKnob.this.setValue(DKnob.this.startVal + f);
            } else if (DKnob.this.dragType == 2) {
              int xpos = DKnob.this.middle - me.getX();
              int ypos = DKnob.this.middle - me.getY();
              double ang = Math.atan2(xpos, ypos);
              double diff = DKnob.this.lastAng - ang;
              DKnob.this.setValue((float)(DKnob.this.getValue() + diff / 4.712249755859375D));
              DKnob.this.lastAng = ang;
            } 
          }
          
          public void mouseMoved(MouseEvent me) {}
        });
    addKeyListener(new KeyListener() {
          public void keyTyped(KeyEvent e) {}
          
          public void keyReleased(KeyEvent e) {}
          
          public void keyPressed(KeyEvent e) {
            int k = e.getKeyCode();
            if (k == 39) {
              DKnob.this.incValue();
            } else if (k == 37) {
              DKnob.this.decValue();
            } 
          }
        });
    addFocusListener(new FocusListener() {
          public void focusGained(FocusEvent e) {
            DKnob.this.repaint();
          }
          
          public void focusLost(FocusEvent e) {
            DKnob.this.repaint();
          }
        });
  }
  
  public void setDragType(int type) {
    this.dragType = type;
  }
  
  public int getDragType() {
    return this.dragType;
  }
  
  private void incValue() {
    setValue(this.val + this.CLICK_SPEED);
  }
  
  private void decValue() {
    setValue(this.val - this.CLICK_SPEED);
  }
  
  public float getValue() {
    return this.val;
  }
  
  public int getIntValue() {
    if (this.medInt > 0) {
      if (this.val > 0.5D)
        return this.medInt + (int)(2.0D * (this.val - 0.5D) * (this.highInt - this.medInt)); 
      return this.lowInt + (int)(2.0F * this.val * (this.medInt - this.lowInt));
    } 
    return this.lowInt + (int)(this.val * (this.highInt - this.lowInt));
  }
  
  public void setIntValue(int val) {
    if (this.medInt > 0) {
      if (val > this.medInt) {
        setValue(0.5F + 0.5F * (val - this.medInt) / (this.highInt - this.medInt));
      } else {
        setValue(0.5F * (val - this.lowInt) / (this.medInt - this.lowInt));
      } 
    } else {
      setValue(1.0F * (val - this.lowInt) / (this.highInt - this.lowInt));
    } 
  }
  
  public void setValue(float val) {
    if (val < 0.0F)
      val = 0.0F; 
    if (val > 1.0F)
      val = 1.0F; 
    this.val = val;
    this.ang = 3.926875F - 4.7122498F * val;
    repaint();
    fireChangeEvent();
  }
  
  public void addChangeListener(ChangeListener cl) {
    this.listenerList.add(ChangeListener.class, cl);
  }
  
  public void removeChangeListener(ChangeListener cl) {
    this.listenerList.remove(ChangeListener.class, cl);
  }
  
  public Dimension getMinimumSize() {
    return MIN_SIZE;
  }
  
  protected void fireChangeEvent() {
    Object[] listeners = this.listenerList.getListenerList();
    for (int i = listeners.length - 2; i >= 0; i -= 2) {
      if (listeners[i] == ChangeListener.class) {
        if (this.changeEvent == null)
          this.changeEvent = new ChangeEvent(this); 
        ((ChangeListener)listeners[i + 1]).stateChanged(this.changeEvent);
      } 
    } 
  }
  
  public void paint(Graphics g) {
    if (g instanceof Graphics2D) {
      Graphics2D g2d = (Graphics2D)g;
      int width = getWidth();
      int height = getHeight() - 10;
      this.size = Math.min(width, height) - 5;
      this.middle = this.size / 2;
      g2d.setBackground(getParent().getBackground());
      g2d.addRenderingHints(AALIAS);
      this.hitArc.setFrame(1.0D, 1.0D, (this.size + 12), (this.size + 12));
      g2d.scale(this.size / 30.0D, this.size / 30.0D);
      drawKnob(g2d);
    } 
  }
  
  private void drawKnob(Graphics2D g2d) {
    g2d.scale(0.5D, 0.5D);
    g2d.scale(2.0D, 2.0D);
    g2d.translate(0, 6);
    if (hasFocus()) {
      g2d.setColor(this.focusColor);
      g2d.fill(new Arc2D.Double(0.0D, 0.0D, 27.0D, 27.0D, 90.0D, 360.0D, 0));
    } 
    g2d.setColor(DARK);
    g2d.fill(new Arc2D.Double(1.0D, 1.0D, 25.0D, 25.0D, 90.0D, 360.0D, 0));
    g2d.setColor(DARK_L);
    g2d.fill(new Arc2D.Double(2.0D, 2.0D, 22.0D, 22.0D, 90.0D, 360.0D, 0));
    g2d.setColor(LIGHT_D);
    g2d.draw(new Arc2D.Double(3.0D, 3.0D, 21.0D, 21.0D, 75.0D, 120.0D, 0));
    g2d.setColor(LIGHT);
    g2d.draw(new Arc2D.Double(4.0D, 4.0D, 20.0D, 20.0D, 122.5D, 25.0D, 0));
    g2d.setColor(DARK);
    g2d.fill(new Arc2D.Double(5.0D, 5.0D, 18.0D, 18.0D, 90.0D, 360.0D, 0));
    g2d.setColor(DARK_T);
    g2d.fill(new Arc2D.Double(9.0D, 9.0D, 18.0D, 18.0D, 90.0D, 360.0D, 0));
    g2d.setColor(DARK_L);
    g2d.fill(new Arc2D.Double(6.0D, 6.0D, 16.0D, 16.0D, 90.0D, 360.0D, 0));
    g2d.setColor(DARK_T);
    g2d.draw(new Arc2D.Double(7.0D, 7.0D, 14.0D, 14.0D, 270.0D, 90.0D, 0));
    g2d.setColor(LIGHT_D);
    g2d.draw(new Arc2D.Double(7.0D, 7.0D, 15.0D, 15.0D, 90.0D, 90.0D, 0));
    g2d.setColor(LIGHT_D);
    g2d.fill(new Arc2D.Double(7.0D, 7.0D, 14.0D, 14.0D, (180.0F * this.ang) / 3.141592D - 60.0D, 120.0D, 0));
    g2d.setColor(DARK);
    g2d.draw(new Arc2D.Double(6.0D, 6.0D, 16.0D, 16.0D, (180.0F * this.ang) / 3.141592D - 1.0D, 2.0D, 2));
    g2d.setColor(DARK);
    g2d.draw(new Arc2D.Double(5.0D, 5.0D, 18.0D, 18.0D, (180.0F * this.ang) / 3.141592D - 8.0D, 16.0D, 0));
    g2d.draw(new Arc2D.Double(4.0D, 4.0D, 20.0D, 20.0D, (180.0F * this.ang) / 3.141592D - 4.0D, 8.0D, 0));
    g2d.scale(0.4D, 0.4D);
    if (this.divisor != 0) {
      g2d.drawString("" + (
          getIntValue() * 1.0D / this.divisor) + " " + this.type, 56, 76);
    } else {
      g2d.drawString("" + getIntValue() + " " + this.type, 56, 76);
    } 
  }
  
  public void setInterval(int low, int high) {
    this.lowInt = low;
    this.highInt = high;
  }
  
  public void setInterval(int low, int med, int high) {
    this.lowInt = low;
    this.highInt = high;
    this.medInt = med;
  }
  
  public void setDivisor(int divisor) {
    this.divisor = divisor;
  }
  
  public static void main(String[] args) {
    JFrame win = new JFrame("DTest!");
    win.getContentPane().setLayout(new BorderLayout());
    win.setSize(120, 140);
    JPanel volumePanel = new JPanel(new BorderLayout());
    volumePanel.setBackground(new Color(180, 180, 195));
    win.getContentPane().add(volumePanel, "Center");
    DKnob ts;
    volumePanel.add(ts = new DKnob("Volume", ""), "Center");
    ts.setInterval(0, 15);
    win.setVisible(true);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\DKnob.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */