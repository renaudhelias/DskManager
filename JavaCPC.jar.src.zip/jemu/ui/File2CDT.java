package jemu.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

public class File2CDT {
  public String CDTname;
  
  public JLabel head = new JLabel("2CDT - GUI by Devilmarkus - Creates CDT from CPC files.                                         ");
  
  public JLabel files = new JLabel("Add files to your CDT: (minimum is 1 file)");
  
  public JTextArea output = new JTextArea("2CDT-GUI\n");
  
  public JTextField filename;
  
  public JTextField file1;
  
  public JTextField file2;
  
  public JTextField file3;
  
  public JTextField file4;
  
  public JTextField file5;
  
  public JTextField file6;
  
  public JTextField file7;
  
  public JTextField file8;
  
  public JTextField file9;
  
  public JTextField file10;
  
  public JLabel name1;
  
  public JTextField name2;
  
  public JTextField name3;
  
  public JTextField name4;
  
  public JTextField name5;
  
  public JTextField name6;
  
  public JTextField name7;
  
  public JTextField name8;
  
  public JTextField name9;
  
  public JTextField name10;
  
  public JTextField name11;
  
  public JLabel headtext = new JLabel("   Choose fileformat:   ");
  
  public JButton speedwrite = new JButton("Speed write 1");
  
  public int speed = 1;
  
  public JButton header1 = new JButton("      Header      ");
  
  public JButton header2 = new JButton("      Header      ");
  
  public JButton header3 = new JButton("      Header      ");
  
  public JButton header4 = new JButton("      Header      ");
  
  public JButton header5 = new JButton("      Header      ");
  
  public JButton header6 = new JButton("      Header      ");
  
  public JButton header7 = new JButton("      Header      ");
  
  public JButton header8 = new JButton("      Header      ");
  
  public JButton header9 = new JButton("      Header      ");
  
  public JButton turbo = new JButton("");
  
  public int m1 = 0;
  
  public int m2 = 0;
  
  public int m3 = 0;
  
  public int m4 = 0;
  
  public int m5 = 0;
  
  public int m6 = 0;
  
  public int m7 = 0;
  
  public int m8 = 0;
  
  public int m9 = 0;
  
  public JFrame dummy = new JFrame();
  
  protected static GridBagConstraints gbcConstraints = null;
  
  public GridBagConstraints getGridBagConstraints(int x, int y, double weightx, double weighty, int width, int fill) {
    if (gbcConstraints == null)
      gbcConstraints = new GridBagConstraints(); 
    gbcConstraints.gridx = x;
    gbcConstraints.gridy = y;
    gbcConstraints.weightx = weightx;
    gbcConstraints.weighty = weighty;
    gbcConstraints.gridwidth = width;
    gbcConstraints.fill = fill;
    return gbcConstraints;
  }
  
  public void makeCDT() {
    final JFrame frame = new JFrame() {
        protected void processWindowEvent(WindowEvent we) {
          if (we.getID() == 201)
            dispose(); 
        }
      };
    frame.setBackground(Color.DARK_GRAY);
    frame.setTitle("2CDT GUI");
    frame.setLayout(new GridBagLayout());
    this.filename = new JTextField("                                                                        ");
    this.file1 = new JTextField("                                                                        ");
    this.file2 = new JTextField("                                                                        ");
    this.file3 = new JTextField("                                                                        ");
    this.file4 = new JTextField("                                                                        ");
    this.file5 = new JTextField("                                                                        ");
    this.file6 = new JTextField("                                                                        ");
    this.file7 = new JTextField("                                                                        ");
    this.file8 = new JTextField("                                                                        ");
    this.file9 = new JTextField("                                                                        ");
    this.file10 = new JTextField("                                                                        ");
    this.name1 = new JLabel("Filename: (16 chars)      ");
    this.name2 = new JTextField("unnamed file");
    this.name3 = new JTextField("unnamed file");
    this.name4 = new JTextField("unnamed file");
    this.name5 = new JTextField("unnamed file");
    this.name6 = new JTextField("unnamed file");
    this.name7 = new JTextField("unnamed file");
    this.name8 = new JTextField("unnamed file");
    this.name9 = new JTextField("unnamed file");
    this.name10 = new JTextField("unnamed file");
    this.name11 = new JTextField("unnamed file");
    JButton create = new JButton("Create");
    JButton load1 = new JButton("Add");
    JButton load2 = new JButton("Add");
    JButton load3 = new JButton("Add");
    JButton load4 = new JButton("Add");
    JButton load5 = new JButton("Add");
    JButton load6 = new JButton("Add");
    JButton load7 = new JButton("Add");
    JButton load8 = new JButton("Add");
    JButton load9 = new JButton("Add");
    JButton load10 = new JButton("Add");
    JButton build = new JButton("Build");
    JButton quit = new JButton("Quit");
    this.output.setRows(10);
    this.output.setAutoscrolls(true);
    this.output.setLineWrap(true);
    this.output.setEditable(false);
    this.output.setFont(new Font("Monospaced", 1, 11));
    this.output.setBorder(new BevelBorder(1));
    JScrollPane scrollpane = new JScrollPane(this.output);
    create.setBorder(new BevelBorder(0));
    load1.setBorder(new BevelBorder(0));
    load2.setBorder(new BevelBorder(0));
    load3.setBorder(new BevelBorder(0));
    load4.setBorder(new BevelBorder(0));
    load5.setBorder(new BevelBorder(0));
    load6.setBorder(new BevelBorder(0));
    load7.setBorder(new BevelBorder(0));
    load8.setBorder(new BevelBorder(0));
    load9.setBorder(new BevelBorder(0));
    load10.setBorder(new BevelBorder(0));
    quit.setBorder(new BevelBorder(0));
    this.header1.setBorder(new BevelBorder(0));
    this.header2.setBorder(new BevelBorder(0));
    this.header3.setBorder(new BevelBorder(0));
    this.header4.setBorder(new BevelBorder(0));
    this.header5.setBorder(new BevelBorder(0));
    this.header6.setBorder(new BevelBorder(0));
    this.header7.setBorder(new BevelBorder(0));
    this.header8.setBorder(new BevelBorder(0));
    this.header9.setBorder(new BevelBorder(0));
    this.speedwrite.setBorder(new BevelBorder(0));
    this.turbo.setBorder(new BevelBorder(0));
    this.turbo.setEnabled(false);
    build.setBorder(new BevelBorder(0));
    frame.add(this.head, getGridBagConstraints(1, 0, 1.0D, 1.0D, 3, 1));
    frame.add(this.name1, getGridBagConstraints(1, 2, 0.0D, 0.0D, 1, 1));
    frame.add(this.filename, getGridBagConstraints(2, 1, 0.0D, 0.0D, 1, 1));
    frame.add(create, getGridBagConstraints(3, 1, 0.0D, 0.0D, 1, 1));
    frame.add(this.files, getGridBagConstraints(2, 2, 0.0D, 0.0D, 1, 1));
    frame.add(this.name2, getGridBagConstraints(1, 3, 0.0D, 0.0D, 1, 1));
    frame.add(this.file1, getGridBagConstraints(2, 3, 0.0D, 0.0D, 1, 1));
    frame.add(load1, getGridBagConstraints(3, 3, 0.0D, 0.0D, 1, 1));
    frame.add(this.name3, getGridBagConstraints(1, 4, 0.0D, 0.0D, 1, 1));
    frame.add(this.file2, getGridBagConstraints(2, 4, 0.0D, 0.0D, 1, 1));
    frame.add(load2, getGridBagConstraints(3, 4, 0.0D, 0.0D, 1, 1));
    frame.add(this.name4, getGridBagConstraints(1, 5, 0.0D, 0.0D, 1, 1));
    frame.add(this.file3, getGridBagConstraints(2, 5, 0.0D, 0.0D, 1, 1));
    frame.add(load3, getGridBagConstraints(3, 5, 0.0D, 0.0D, 1, 1));
    frame.add(this.name5, getGridBagConstraints(1, 6, 0.0D, 0.0D, 1, 1));
    frame.add(this.file4, getGridBagConstraints(2, 6, 0.0D, 0.0D, 1, 1));
    frame.add(load4, getGridBagConstraints(3, 6, 0.0D, 0.0D, 1, 1));
    frame.add(this.name6, getGridBagConstraints(1, 7, 0.0D, 0.0D, 1, 1));
    frame.add(this.file5, getGridBagConstraints(2, 7, 0.0D, 0.0D, 1, 1));
    frame.add(load5, getGridBagConstraints(3, 7, 0.0D, 0.0D, 1, 1));
    frame.add(this.name7, getGridBagConstraints(1, 8, 0.0D, 0.0D, 1, 1));
    frame.add(this.file6, getGridBagConstraints(2, 8, 0.0D, 0.0D, 1, 1));
    frame.add(load6, getGridBagConstraints(3, 8, 0.0D, 0.0D, 1, 1));
    frame.add(this.name8, getGridBagConstraints(1, 9, 0.0D, 0.0D, 1, 1));
    frame.add(this.file7, getGridBagConstraints(2, 9, 0.0D, 0.0D, 1, 1));
    frame.add(load7, getGridBagConstraints(3, 9, 0.0D, 0.0D, 1, 1));
    frame.add(this.name9, getGridBagConstraints(1, 10, 0.0D, 0.0D, 1, 1));
    frame.add(this.file8, getGridBagConstraints(2, 10, 0.0D, 0.0D, 1, 1));
    frame.add(load8, getGridBagConstraints(3, 10, 0.0D, 0.0D, 1, 1));
    frame.add(this.name10, getGridBagConstraints(1, 11, 0.0D, 0.0D, 1, 1));
    frame.add(this.file9, getGridBagConstraints(2, 11, 0.0D, 0.0D, 1, 1));
    frame.add(load9, getGridBagConstraints(3, 11, 0.0D, 0.0D, 1, 1));
    frame.add(this.name11, getGridBagConstraints(1, 12, 0.0D, 0.0D, 1, 1));
    frame.add(this.file10, getGridBagConstraints(2, 12, 0.0D, 0.0D, 1, 1));
    frame.add(load10, getGridBagConstraints(3, 12, 0.0D, 0.0D, 1, 1));
    frame.add(this.speedwrite, getGridBagConstraints(1, 13, 0.0D, 0.0D, 1, 1));
    frame.add(build, getGridBagConstraints(2, 13, 0.0D, 0.0D, 1, 1));
    frame.add(quit, getGridBagConstraints(4, 13, 0.0D, 0.0D, 1, 1));
    frame.add(this.headtext, getGridBagConstraints(4, 3, 0.0D, 0.0D, 1, 1));
    frame.add(this.header1, getGridBagConstraints(4, 4, 0.0D, 0.0D, 1, 1));
    frame.add(this.header2, getGridBagConstraints(4, 5, 0.0D, 0.0D, 1, 1));
    frame.add(this.header3, getGridBagConstraints(4, 6, 0.0D, 0.0D, 1, 1));
    frame.add(this.header4, getGridBagConstraints(4, 7, 0.0D, 0.0D, 1, 1));
    frame.add(this.header5, getGridBagConstraints(4, 8, 0.0D, 0.0D, 1, 1));
    frame.add(this.header6, getGridBagConstraints(4, 9, 0.0D, 0.0D, 1, 1));
    frame.add(this.header7, getGridBagConstraints(4, 10, 0.0D, 0.0D, 1, 1));
    frame.add(this.header8, getGridBagConstraints(4, 11, 0.0D, 0.0D, 1, 1));
    frame.add(this.header9, getGridBagConstraints(4, 12, 0.0D, 0.0D, 1, 1));
    frame.add(this.turbo, getGridBagConstraints(3, 13, 0.0D, 0.0D, 1, 1));
    frame.add(scrollpane, getGridBagConstraints(1, 14, 1.0D, 1.0D, 4, 1));
    frame.pack();
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    frame.setLocation((d.width - (frame.getSize()).width) / 2, (d.height - (frame.getSize()).height) / 2);
    frame.setVisible(true);
    frame.setResizable(false);
    this.speedwrite.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (File2CDT.this.speedwrite.getText().equals("Speed write 1")) {
              File2CDT.this.speedwrite.setText("Speed write 0");
              File2CDT.this.speed = 0;
            } else {
              File2CDT.this.speedwrite.setText("Speed write 1");
              File2CDT.this.speed = 1;
            } 
          }
        });
    this.header1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (File2CDT.this.header1.getText().equals("      Header      ")) {
              File2CDT.this.header1.setText("Headerless");
              File2CDT.this.m1 = 1;
            } else {
              File2CDT.this.header1.setText("      Header      ");
              File2CDT.this.m1 = 0;
            } 
          }
        });
    this.header2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (File2CDT.this.header2.getText().equals("      Header      ")) {
              File2CDT.this.header2.setText("Headerless");
              File2CDT.this.m2 = 1;
            } else {
              File2CDT.this.header2.setText("      Header      ");
              File2CDT.this.m2 = 0;
            } 
          }
        });
    this.header3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (File2CDT.this.header3.getText().equals("      Header      ")) {
              File2CDT.this.header3.setText("Headerless");
              File2CDT.this.m3 = 1;
            } else {
              File2CDT.this.header3.setText("      Header      ");
              File2CDT.this.m3 = 0;
            } 
          }
        });
    this.header4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (File2CDT.this.header4.getText().equals("      Header      ")) {
              File2CDT.this.header4.setText("Headerless");
              File2CDT.this.m4 = 1;
            } else {
              File2CDT.this.header4.setText("      Header      ");
              File2CDT.this.m4 = 0;
            } 
          }
        });
    this.header5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (File2CDT.this.header5.getText().equals("      Header      ")) {
              File2CDT.this.header5.setText("Headerless");
              File2CDT.this.m5 = 1;
            } else {
              File2CDT.this.header5.setText("      Header      ");
              File2CDT.this.m5 = 0;
            } 
          }
        });
    this.header6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (File2CDT.this.header6.getText().equals("      Header      ")) {
              File2CDT.this.header6.setText("Headerless");
              File2CDT.this.m6 = 1;
            } else {
              File2CDT.this.header6.setText("      Header      ");
              File2CDT.this.m6 = 0;
            } 
          }
        });
    this.header7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (File2CDT.this.header7.getText().equals("      Header      ")) {
              File2CDT.this.header7.setText("Headerless");
              File2CDT.this.m7 = 1;
            } else {
              File2CDT.this.header7.setText("      Header      ");
              File2CDT.this.m7 = 0;
            } 
          }
        });
    this.header8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (File2CDT.this.header8.getText().equals("      Header      ")) {
              File2CDT.this.header8.setText("Headerless");
              File2CDT.this.m8 = 1;
            } else {
              File2CDT.this.header8.setText("      Header      ");
              File2CDT.this.m8 = 0;
            } 
          }
        });
    this.header9.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (File2CDT.this.header9.getText().equals("      Header      ")) {
              File2CDT.this.header9.setText("Headerless");
              File2CDT.this.m9 = 1;
            } else {
              File2CDT.this.header9.setText("      Header      ");
              File2CDT.this.m9 = 0;
            } 
          }
        });
    create.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            FileDialog filedia = new FileDialog(File2CDT.this.dummy, "Create CDT file", 1);
            filedia.setFile("*.cdt");
            filedia.setVisible(true);
            String filenamed = filedia.getFile();
            if (filenamed != null) {
              filenamed = filedia.getDirectory() + filedia.getFile();
              if (!filenamed.toLowerCase().endsWith(".cdt"))
                filenamed = filenamed + ".cdt"; 
              String loadname = filenamed;
              File2CDT.this.filename.setText(loadname);
              File2CDT.this.CDTname = filedia.getFile();
            } 
          }
        });
    load1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            FileDialog filedia = new FileDialog(File2CDT.this.dummy, "Add CPC file", 0);
            filedia.setFile("*.*");
            filedia.setVisible(true);
            String filenamed = filedia.getFile();
            if (filenamed != null) {
              filenamed = filedia.getDirectory() + filedia.getFile();
              String loadname = filenamed;
              File2CDT.this.file1.setText(loadname);
              File2CDT.this.name2.setText(filedia.getFile());
            } 
          }
        });
    load2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            FileDialog filedia = new FileDialog(File2CDT.this.dummy, "Add CPC file", 0);
            filedia.setFile("*.*");
            filedia.setVisible(true);
            String filenamed = filedia.getFile();
            if (filenamed != null) {
              filenamed = filedia.getDirectory() + filedia.getFile();
              String loadname = filenamed;
              File2CDT.this.file2.setText(loadname);
              File2CDT.this.name3.setText(filedia.getFile());
            } 
          }
        });
    load3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            FileDialog filedia = new FileDialog(File2CDT.this.dummy, "Add CPC file", 0);
            filedia.setFile("*.*");
            filedia.setVisible(true);
            String filenamed = filedia.getFile();
            if (filenamed != null) {
              filenamed = filedia.getDirectory() + filedia.getFile();
              String loadname = filenamed;
              File2CDT.this.file3.setText(loadname);
              File2CDT.this.name4.setText(filedia.getFile());
            } 
          }
        });
    load4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            FileDialog filedia = new FileDialog(File2CDT.this.dummy, "Add CPC file", 0);
            filedia.setFile("*.*");
            filedia.setVisible(true);
            String filenamed = filedia.getFile();
            if (filenamed != null) {
              filenamed = filedia.getDirectory() + filedia.getFile();
              String loadname = filenamed;
              File2CDT.this.file4.setText(loadname);
              File2CDT.this.name5.setText(filedia.getFile());
            } 
          }
        });
    load5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            FileDialog filedia = new FileDialog(File2CDT.this.dummy, "Add CPC file", 0);
            filedia.setFile("*.*");
            filedia.setVisible(true);
            String filenamed = filedia.getFile();
            if (filenamed != null) {
              filenamed = filedia.getDirectory() + filedia.getFile();
              String loadname = filenamed;
              File2CDT.this.file5.setText(loadname);
              File2CDT.this.name6.setText(filedia.getFile());
            } 
          }
        });
    load6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            FileDialog filedia = new FileDialog(File2CDT.this.dummy, "Add CPC file", 0);
            filedia.setFile("*.*");
            filedia.setVisible(true);
            String filenamed = filedia.getFile();
            if (filenamed != null) {
              filenamed = filedia.getDirectory() + filedia.getFile();
              String loadname = filenamed;
              File2CDT.this.file6.setText(loadname);
              File2CDT.this.name7.setText(filedia.getFile());
            } 
          }
        });
    load7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            FileDialog filedia = new FileDialog(File2CDT.this.dummy, "Add CPC file", 0);
            filedia.setFile("*.*");
            filedia.setVisible(true);
            String filenamed = filedia.getFile();
            if (filenamed != null) {
              filenamed = filedia.getDirectory() + filedia.getFile();
              String loadname = filenamed;
              File2CDT.this.file7.setText(loadname);
              File2CDT.this.name8.setText(filedia.getFile());
            } 
          }
        });
    load8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            FileDialog filedia = new FileDialog(File2CDT.this.dummy, "Add CPC file", 0);
            filedia.setFile("*.*");
            filedia.setVisible(true);
            String filenamed = filedia.getFile();
            if (filenamed != null) {
              filenamed = filedia.getDirectory() + filedia.getFile();
              String loadname = filenamed;
              File2CDT.this.file8.setText(loadname);
              File2CDT.this.name9.setText(filedia.getFile());
            } 
          }
        });
    load9.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            FileDialog filedia = new FileDialog(File2CDT.this.dummy, "Add CPC file", 0);
            filedia.setFile("*.*");
            filedia.setVisible(true);
            String filenamed = filedia.getFile();
            if (filenamed != null) {
              filenamed = filedia.getDirectory() + filedia.getFile();
              String loadname = filenamed;
              File2CDT.this.file9.setText(loadname);
              File2CDT.this.name10.setText(filedia.getFile());
            } 
          }
        });
    load10.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            FileDialog filedia = new FileDialog(File2CDT.this.dummy, "Add CPC file", 0);
            filedia.setFile("*.*");
            filedia.setVisible(true);
            String filenamed = filedia.getFile();
            if (filenamed != null) {
              filenamed = filedia.getDirectory() + filedia.getFile();
              String loadname = filenamed;
              File2CDT.this.file10.setText(loadname);
              File2CDT.this.name11.setText(filedia.getFile());
            } 
          }
        });
    quit.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            frame.dispose();
          }
        });
    build.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            File2CDT.this.output.setText("processing...\n");
            File2CDT.this.output.updateUI();
            Thread runner = new Thread() {
                public void run() {
                  try {
                    File2CDT.this.buildCDT();
                  } catch (Exception e) {
                    e.printStackTrace();
                  } 
                }
              };
            runner.start();
          }
        });
  }
  
  Process process = null;
  
  public void Launch(String command) throws InterruptedException, IOException {
    command = System.getProperty("user.home") + "\\javacpc\\" + command;
    if (this.process != null)
      return; 
    this.output.append(command + "\r\n");
    this.process = Runtime.getRuntime().exec(command);
    InputStream is = this.process.getInputStream();
    InputStreamReader isr = new InputStreamReader(is);
    BufferedReader br = new BufferedReader(isr);
    String line;
    while ((line = br.readLine()) != null) {
      this.output.append(line + "\r\n");
      this.output.select(20000000, 20000000);
    } 
    br.close();
    this.output.append("Done...\r\n");
    this.process = null;
  }
  
  public void buildCDT() {
    String loadname = this.filename.getText();
    if (loadname.equalsIgnoreCase("                                                                        "))
      loadname = new String(); 
    String firstname = this.file1.getText();
    if (firstname.equalsIgnoreCase("                                                                        "))
      firstname = null; 
    if (loadname != null && firstname != null) {
      try {
        String dat1 = this.name2.getText();
        String command = "tools/2cdt.exe -s " + this.speed + " -n -r \"" + dat1 + "\" \"" + firstname + "\" \"" + loadname + "\"";
        try {
          Launch(command);
        } catch (Exception e) {
          e.printStackTrace();
        } 
        AddSecond();
      } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "An error occured");
      } 
    } else {
      JOptionPane.showMessageDialog(null, "An error occured");
    } 
  }
  
  public void AddSecond() {
    String loadname = this.filename.getText();
    String firstname = this.file2.getText();
    if (firstname.equalsIgnoreCase("                                                                        "))
      firstname = null; 
    if (loadname != null && firstname != null)
      try {
        String dat1 = this.name3.getText();
        String command = "tools/2cdt.exe -m " + this.m1 + " -s " + this.speed + " -r \"" + dat1 + "\" \"" + firstname + "\" \"" + loadname + "\"";
        try {
          Launch(command);
        } catch (Exception exception) {}
      } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "An error occured");
      }  
    AddThird();
  }
  
  public void AddThird() {
    String loadname = this.filename.getText();
    String firstname = this.file3.getText();
    if (firstname.equalsIgnoreCase("                                                                        "))
      firstname = null; 
    if (loadname != null && firstname != null)
      try {
        String dat1 = this.name4.getText();
        String command = "tools/2cdt.exe -m " + this.m2 + " -s " + this.speed + " -r \"" + dat1 + "\" \"" + firstname + "\" \"" + loadname + "\"";
        try {
          Launch(command);
        } catch (Exception exception) {}
      } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "An error occured");
      }  
    AddFourth();
  }
  
  public void AddFourth() {
    String loadname = this.filename.getText();
    String firstname = this.file4.getText();
    if (firstname.equalsIgnoreCase("                                                                        "))
      firstname = null; 
    if (loadname != null && firstname != null)
      try {
        String dat1 = this.name5.getText();
        String command = "tools/2cdt.exe -m " + this.m3 + " -s " + this.speed + " -r \"" + dat1 + "\" \"" + firstname + "\" \"" + loadname + "\"";
        try {
          Launch(command);
        } catch (Exception exception) {}
      } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "An error occured");
      }  
    AddFifth();
  }
  
  public void AddFifth() {
    String loadname = this.filename.getText();
    String firstname = this.file5.getText();
    if (firstname.equalsIgnoreCase("                                                                        "))
      firstname = null; 
    if (loadname != null && firstname != null)
      try {
        String dat1 = this.name6.getText();
        String command = "tools/2cdt.exe -m " + this.m4 + " -s " + this.speed + " -r \"" + dat1 + "\" \"" + firstname + "\" \"" + loadname + "\"";
        try {
          Launch(command);
        } catch (Exception exception) {}
      } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "An error occured");
      }  
    AddSixth();
  }
  
  public void AddSixth() {
    String loadname = this.filename.getText();
    String firstname = this.file6.getText();
    if (firstname.equalsIgnoreCase("                                                                        "))
      firstname = null; 
    if (loadname != null && firstname != null)
      try {
        String dat1 = this.name7.getText();
        String command = "tools/2cdt.exe -m " + this.m5 + " -s " + this.speed + " -r \"" + dat1 + "\" \"" + firstname + "\" \"" + loadname + "\"";
        try {
          Launch(command);
        } catch (Exception exception) {}
      } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "An error occured");
      }  
    AddSeventh();
  }
  
  public void AddSeventh() {
    String loadname = this.filename.getText();
    String firstname = this.file7.getText();
    if (firstname.equalsIgnoreCase("                                                                        "))
      firstname = null; 
    if (loadname != null && firstname != null)
      try {
        String dat1 = this.name8.getText();
        String command = "tools/2cdt.exe -m " + this.m6 + " -s " + this.speed + " -r \"" + dat1 + "\" \"" + firstname + "\" \"" + loadname + "\"";
        try {
          Launch(command);
        } catch (Exception exception) {}
      } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "An error occured");
      }  
    AddEigth();
  }
  
  public void AddEigth() {
    String loadname = this.filename.getText();
    String firstname = this.file8.getText();
    if (firstname.equalsIgnoreCase("                                                                        "))
      firstname = null; 
    if (loadname != null && firstname != null)
      try {
        String dat1 = this.name9.getText();
        String command = "tools/2cdt.exe -m " + this.m7 + " -s " + this.speed + " -r \"" + dat1 + "\" \"" + firstname + "\" \"" + loadname + "\"";
        try {
          Launch(command);
        } catch (Exception exception) {}
      } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "An error occured");
      }  
    AddNineth();
  }
  
  public void AddNineth() {
    String loadname = this.filename.getText();
    String firstname = this.file9.getText();
    if (firstname.equalsIgnoreCase("                                                                        "))
      firstname = null; 
    if (loadname != null && firstname != null)
      try {
        String dat1 = this.name10.getText();
        String command = "tools/2cdt.exe -m " + this.m8 + " -s " + this.speed + " -r \"" + dat1 + "\" \"" + firstname + "\" \"" + loadname + "\"";
        try {
          Launch(command);
        } catch (Exception exception) {}
      } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "An error occured");
      }  
    AddTenth();
  }
  
  public void AddTenth() {
    String loadname = this.filename.getText();
    String firstname = this.file10.getText();
    if (firstname.equalsIgnoreCase("                                                                        "))
      firstname = null; 
    if (loadname != null && firstname != null)
      try {
        String dat1 = this.name11.getText();
        String command = "tools/2cdt.exe -m " + this.m9 + " -s " + this.speed + " -r \"" + dat1 + "\" \"" + firstname + "\" \"" + loadname + "\"";
        try {
          Launch(command);
        } catch (Exception exception) {}
      } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "An error occured");
      }  
    JOptionPane.showMessageDialog(null, this.CDTname + "\nsuccessfully created...");
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\File2CDT.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */