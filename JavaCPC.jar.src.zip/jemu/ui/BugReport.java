package jemu.ui;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Calendar;

public class BugReport {
  static Calendar cal = Calendar.getInstance();
  
  public static void reportBug() {
    try {
      System.getProperties().put("mail.host", "cpc-live.com");
      BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
      String subject = "JavaCPC bug / contact";
      String user = "";
      String frommail = "";
      user = JEMU.username;
      frommail = JEMU.usermail;
      String line = "JavaCPC bug reported by   : " + user + "\n";
      line = line + "email address: " + frommail + "\n";
      line = line + "[JavaCPC version " + Main.version + Main.subversion + "]\n[" + cal.getTime() + "]\nUsermessage:\n------------------------------------\n\n";
      line = line + JEMU.usertext + "\n\n";
      line = line + "------------------------------------\n";
      try {
        line = line + Console.textArea.getText() + "\n";
      } catch (Exception b) {
        line = line + "Console is disabled / empty?!?\nUsing BETA?\n\n";
      } 
      Mail mail = new Mail();
      mail.SendMail(line, "webmaster@cpc-live.com", subject);
      mail.SendMail(line, frommail, subject);
      System.out.println("Bug report sent.");
      System.out.flush();
    } catch (Exception e) {
      System.err.println(e.getMessage());
      System.err.println("Mailserver does not respond");
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\BugReport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */