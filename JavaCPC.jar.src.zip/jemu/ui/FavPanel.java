package jemu.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.AbstractListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class FavPanel extends JPanel {
  public JButton handle;
  
  private JLabel jLabel1;
  
  public JList jList1;
  
  private JPanel jPanel1;
  
  private JScrollPane jScrollPane1;
  
  public FavPanel() {
    initComponents();
  }
  
  public static void main(String[] args) {
    JFrame fram = new JFrame("Test");
    fram.setLayout(new BorderLayout());
    fram.setDefaultCloseOperation(3);
    FavPanel pan = new FavPanel();
    fram.add(pan);
    fram.setVisible(true);
    fram.pack();
  }
  
  private void initComponents() {
    this.jScrollPane1 = new JScrollPane();
    this.jList1 = new JList();
    this.jPanel1 = new JPanel();
    this.handle = new JButton();
    this.jLabel1 = new JLabel();
    setMaximumSize(new Dimension(180, 2200));
    setPreferredSize(new Dimension(180, 200));
    setLayout(new BorderLayout());
    this.jScrollPane1.setMaximumSize(new Dimension(32767, 300));
    this.jScrollPane1.setPreferredSize(new Dimension(37, 300));
    this.jList1.setModel(new AbstractListModel() {
          String[] strings = new String[] { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
          
          public int getSize() {
            return this.strings.length;
          }
          
          public Object getElementAt(int i) {
            return this.strings[i];
          }
        });
    this.jList1.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            FavPanel.this.jList1MouseReleased(evt);
          }
        });
    this.jScrollPane1.setViewportView(this.jList1);
    add(this.jScrollPane1, "Center");
    this.jPanel1.setLayout(new BorderLayout());
    this.handle.setText("Add/Remove");
    this.jPanel1.add(this.handle, "Center");
    this.jLabel1.setText("Favourites");
    this.jPanel1.add(this.jLabel1, "First");
    add(this.jPanel1, "North");
  }
  
  private void jList1MouseReleased(MouseEvent evt) {
    System.out.println(this.jList1.getSelectedIndex());
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\FavPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */