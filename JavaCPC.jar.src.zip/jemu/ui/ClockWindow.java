package jemu.ui;

import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

public class ClockWindow extends JFrame {
  private JPanel clockPanel;
  
  private JLayeredPane jLayeredPane1;
  
  private JLabel transparentFace;
  
  public ClockWindow() {
    initComponents();
    Clock clock = new Clock();
    clock.setSize(250, 250);
    this.clockPanel.add(clock);
    clock.fireUpdate.start();
  }
  
  private void initComponents() {
    this.jLayeredPane1 = new JLayeredPane();
    this.transparentFace = new JLabel();
    this.clockPanel = new JPanel();
    setDefaultCloseOperation(3);
    setTitle("Java Analog Clock");
    setBackground(new Color(0, 0, 255));
    setResizable(false);
    this.jLayeredPane1.setBackground(new Color(204, 204, 255));
    this.jLayeredPane1.setOpaque(true);
    this.jLayeredPane1.setRequestFocusEnabled(false);
    this.transparentFace.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/clockglass.png")));
    this.transparentFace.setFocusable(false);
    this.transparentFace.setBounds(0, 0, 200, 200);
    this.jLayeredPane1.add(this.transparentFace, JLayeredPane.PALETTE_LAYER);
    this.clockPanel.setFocusable(false);
    this.clockPanel.setOpaque(false);
    GroupLayout clockPanelLayout = new GroupLayout(this.clockPanel);
    this.clockPanel.setLayout(clockPanelLayout);
    clockPanelLayout.setHorizontalGroup(clockPanelLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 200, 32767));
    clockPanelLayout.setVerticalGroup(clockPanelLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 200, 32767));
    this.clockPanel.setBounds(0, 0, 200, 200);
    this.jLayeredPane1.add(this.clockPanel, JLayeredPane.DEFAULT_LAYER);
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addComponent(this.jLayeredPane1, -1, 202, 32767));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addComponent(this.jLayeredPane1, -2, 202, -2));
    pack();
  }
  
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new ClockWindow()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\ClockWindow.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */