package jemu.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.BoxLayout;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.Popup;
import javax.swing.PopupFactory;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.plaf.basic.BasicArrowButton;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

public class CalendarComboBox extends JPanel {
  JPanel panel = new JPanel();
  
  public static void main(String[] args) {
    CalendarComboBox box = new CalendarComboBox();
    JFrame frame = new JFrame("Test");
    frame.setLayout(new BorderLayout());
    frame.add(box.calPanel, "Center");
    box.setDate(box.thisdate);
    frame.pack();
    frame.setDefaultCloseOperation(3);
    frame.setVisible(true);
    box.calPanel.updateUI();
  }
  
  private static final DateFormatSymbols dfs = new DateFormatSymbols();
  
  private static final String[] months = dfs.getMonths();
  
  private static final String[] dayNames = new String[7];
  
  private static final Toolkit toolkit = Toolkit.getDefaultToolkit();
  
  private static final Dimension screenSize = toolkit.getScreenSize();
  
  private static final PopupFactory factory = PopupFactory.getSharedInstance();
  
  private final JPanel inputPanel = new JPanel();
  
  private final JFormattedTextField input = new JFormattedTextField(new Date());
  
  private final BasicArrowButton comboBtn = new BasicArrowButton(5);
  
  public final JPanel calPanel = new JPanel();
  
  private final JTextField calLabel = new JTextField(11);
  
  private final Calendar current = new GregorianCalendar();
  
  private final CalendarModel display = new CalendarModel(6, 6);
  
  private final JTable table = new JTable(this.display);
  
  private final BasicArrowButton nextBtn = new BasicArrowButton(3);
  
  private final BasicArrowButton prevBtn = new BasicArrowButton(7);
  
  private final BasicArrowButton closeCalendarBtn = new BasicArrowButton(1);
  
  private Popup popup;
  
  private Date thisdate;
  
  public CalendarComboBox() {
    this(new GregorianCalendar());
  }
  
  public CalendarComboBox(Calendar cal) {
    Date date = cal.getTime();
    this.thisdate = cal.getTime();
    this.current.setTime(date);
    this.input.setValue(date);
    buildInputPanel();
    buildCalendarDisplay();
    registerListeners();
    add(this.inputPanel);
  }
  
  private void buildInputPanel() {
    this.inputPanel.setLayout(new BoxLayout(this.inputPanel, 0));
    this.input.setColumns(12);
    this.inputPanel.add(this.input);
    this.comboBtn.setActionCommand("combo");
    this.inputPanel.add(this.comboBtn);
  }
  
  private void buildCalendarDisplay() {
    this.table.setCellSelectionEnabled(true);
    this.table.setSelectionMode(0);
    this.table.setShowGrid(false);
    String[] names = dfs.getShortWeekdays();
    for (int i = 1; i < names.length; i++)
      dayNames[i - 1] = "" + names[i].charAt(0); 
    this.display.setColumnIdentifiers((Object[])dayNames);
    this.table.setModel(this.display);
    this.table.setAutoResizeMode(0);
    int count = this.table.getColumnCount();
    for (int j = 0; j < count; j++) {
      TableColumn col = this.table.getColumnModel().getColumn(j);
      col.setPreferredWidth(20);
    } 
    JTableHeader header = this.table.getTableHeader();
    header.setFont(header.getFont().deriveFont(1));
    this.panel.setLayout(new BoxLayout(this.panel, 1));
    this.panel.add(header);
    this.panel.add(this.table);
    this.calPanel.setBorder(new LineBorder(Color.BLACK));
    this.calPanel.setLayout(new BorderLayout());
    this.calPanel.add(buildCalendarNavigationPanel(), "North");
    this.calPanel.add(this.panel);
  }
  
  private JPanel buildCalendarNavigationPanel() {
    JPanel panel = new JPanel();
    panel.setLayout(new BoxLayout(panel, 0));
    this.calLabel.setEditable(false);
    int fontSize = this.calLabel.getFont().getSize();
    this.calLabel.setFont(this.calLabel.getFont().deriveFont(0, (fontSize - 2)));
    panel.add(this.calLabel);
    this.prevBtn.setActionCommand("prevBtn");
    this.nextBtn.setActionCommand("nextBtn");
    this.closeCalendarBtn.setActionCommand("close");
    panel.add(this.prevBtn);
    panel.add(this.nextBtn);
    return panel;
  }
  
  private void registerListeners() {
    ButtonActionListener btnListener = new ButtonActionListener();
    this.input.addKeyListener(new InputListener());
    this.comboBtn.addActionListener(btnListener);
    CalendarSelectionListener listener = new CalendarSelectionListener();
    this.table.getSelectionModel().addListSelectionListener(listener);
    this.table.getColumnModel().getSelectionModel()
      .addListSelectionListener(listener);
    this.prevBtn.addActionListener(btnListener);
    this.nextBtn.addActionListener(btnListener);
    this.closeCalendarBtn.addActionListener(btnListener);
  }
  
  private void updateTable(Calendar cal) {
    Calendar dayOne = new GregorianCalendar(cal.get(1), cal.get(2), 1);
    int actualDays = cal.getActualMaximum(5);
    int startIndex = dayOne.get(7) - 1;
    int day = 1;
    for (int row = 0; row < 6; row++) {
      for (int col = 0; col < 7; col++) {
        if ((col < startIndex && row == 0) || day > actualDays) {
          this.display.setValueAt("", row, col);
        } else {
          this.display.setValueAt(new Integer(day), row, col);
          day++;
        } 
      } 
    } 
    this.calLabel.setText(months[cal.get(2)] + ", " + cal
        .get(1));
    this.table.changeSelection(cal.get(4) - 1, cal
        .get(7) - 1, false, false);
  }
  
  private Popup getPopup() {
    Point p = this.input.getLocationOnScreen();
    Dimension inputSize = this.input.getPreferredSize();
    Dimension calendarSize = this.calPanel.getPreferredSize();
    if (p.y + calendarSize.height < screenSize.height) {
      this.popup = factory.getPopup(this.input, this.calPanel, p.x, p.y + inputSize.height);
    } else {
      this.popup = factory.getPopup(this.input, this.calPanel, p.x, p.y - calendarSize.height);
    } 
    return this.popup;
  }
  
  public Calendar getDate() {
    return this.current;
  }
  
  public void setDate(Date newDate) {
    this.current.setTime(newDate);
    this.input.setValue(this.current.getTime());
  }
  
  private class CalendarModel extends DefaultTableModel {
    public CalendarModel(int row, int col) {
      super(row, col);
    }
    
    public Class getColumnClass(int column) {
      return Integer.class;
    }
    
    public boolean isCellEditable(int row, int col) {
      return false;
    }
  }
  
  private class ButtonActionListener implements ActionListener {
    private ButtonActionListener() {}
    
    public void actionPerformed(ActionEvent e) {
      String cmd = e.getActionCommand();
      if (cmd.equals("prevBtn")) {
        CalendarComboBox.this.current.add(2, -1);
        CalendarComboBox.this.input.setValue(CalendarComboBox.this.current.getTime());
      } else if (cmd.equals("nextBtn")) {
        CalendarComboBox.this.current.add(2, 1);
        CalendarComboBox.this.input.setValue(CalendarComboBox.this.current.getTime());
      } else if (cmd.equals("close")) {
        CalendarComboBox.this.popup.hide();
        CalendarComboBox.this.comboBtn.setEnabled(true);
      } else {
        CalendarComboBox.this.comboBtn.setEnabled(false);
        CalendarComboBox.this.popup = CalendarComboBox.this.getPopup();
        CalendarComboBox.this.popup.show();
      } 
      CalendarComboBox.this.updateTable(CalendarComboBox.this.current);
    }
  }
  
  private class CalendarSelectionListener implements ListSelectionListener {
    private CalendarSelectionListener() {}
    
    public void valueChanged(ListSelectionEvent e) {
      if (!e.getValueIsAdjusting()) {
        int row = CalendarComboBox.this.table.getSelectedRow();
        int col = CalendarComboBox.this.table.getSelectedColumn();
        Object value = null;
        try {
          value = CalendarComboBox.this.display.getValueAt(row, col);
        } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
        if (value instanceof Integer) {
          int day = ((Integer)value).intValue();
          CalendarComboBox.this.current.set(5, day);
          CalendarComboBox.this.input.setValue(CalendarComboBox.this.current.getTime());
        } 
      } 
    }
  }
  
  private class InputListener extends KeyAdapter {
    private InputListener() {}
    
    public void keyTyped(KeyEvent e) {
      DateFormat df = DateFormat.getDateInstance();
      Date date = null;
      try {
        date = df.parse(CalendarComboBox.this.input.getText());
      } catch (ParseException parseException) {}
      char c = e.getKeyChar();
      if (date != null && (c == '\n' || c == '\t')) {
        CalendarComboBox.this.current.setTime(date);
        CalendarComboBox.this.updateTable(CalendarComboBox.this.current);
      } 
    }
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\CalendarComboBox.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */