package jemu.ui;

import java.awt.Dimension;
import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFileChooser;

public class ImagePreview extends JComponent implements PropertyChangeListener {
  ImageIcon thumbnail = null;
  
  File file = null;
  
  public ImagePreview(JFileChooser fc) {
    setPreferredSize(new Dimension(200, 100));
    fc.addPropertyChangeListener(this);
  }
  
  public void loadImage() {
    if (this.file == null) {
      this.thumbnail = null;
      return;
    } 
    ImageIcon tmpIcon = new ImageIcon(this.file.getPath());
    if (tmpIcon != null)
      if (tmpIcon.getIconWidth() > 190) {
        this
          .thumbnail = new ImageIcon(tmpIcon.getImage().getScaledInstance(190, -1, 1));
      } else {
        this.thumbnail = tmpIcon;
      }  
  }
  
  public void propertyChange(PropertyChangeEvent e) {
    boolean update = false;
    String prop = e.getPropertyName();
    if ("directoryChanged".equals(prop)) {
      this.file = null;
      update = true;
    } else if ("SelectedFileChangedProperty".equals(prop)) {
      this.file = (File)e.getNewValue();
      update = true;
    } 
    if (update) {
      this.thumbnail = null;
      if (isShowing()) {
        loadImage();
        repaint();
      } 
    } 
  }
  
  protected void paintComponent(Graphics g) {
    if (this.thumbnail == null)
      loadImage(); 
    if (this.thumbnail != null) {
      int x = getWidth() / 2 - this.thumbnail.getIconWidth() / 2;
      int y = getHeight() / 2 - this.thumbnail.getIconHeight() / 2;
      if (y < 0)
        y = 0; 
      if (x < 5)
        x = 5; 
      this.thumbnail.paintIcon(this, g, x, y);
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\ImagePreview.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */