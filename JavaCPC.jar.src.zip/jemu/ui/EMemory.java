package jemu.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import javax.swing.JComponent;
import jemu.core.Util;
import jemu.core.device.Computer;
import jemu.core.device.memory.Memory;

public class EMemory extends JComponent implements KeyListener, ActionListener, TimerListener {
  public boolean read = true;
  
  public boolean any = false;
  
  public int forcedbank = 192;
  
  protected static final int INVALID = 0;
  
  protected static final int HEX1 = 1;
  
  protected static final int HEX2 = 2;
  
  protected static final int TEXT = 3;
  
  protected Memory mem;
  
  protected Color selBackground = new Color(0, 127, 0);
  
  protected Color selForeground = Color.white;
  
  protected boolean textMode = false;
  
  protected boolean right = false;
  
  protected int selAnchor;
  
  protected int selStart;
  
  protected int selEnd;
  
  protected int selected;
  
  protected int addressDigits;
  
  protected int cw;
  
  protected int ch;
  
  protected int left;
  
  protected Counter counter;
  
  protected boolean cursor;
  
  int searchlength;
  
  int oldhexlength;
  
  int haschar;
  
  int lastaddress;
  
  boolean lasttextmode;
  
  int lastindex;
  
  Find find;
  
  public void keyPressed(KeyEvent e) {
    if (e.getKeyCode() != 10)
      keyReleased(e); 
  }
  
  public void keyTyped(KeyEvent e) {}
  
  public void keyReleased(KeyEvent e) {
    if (e.getSource() == this.find.input)
      if (e.getKeyCode() == 10) {
        if (this.find.ashex.isSelected()) {
          String t = this.find.input.getText();
          boolean replace = false;
          while (t.endsWith("  ")) {
            replace = true;
            t = t.substring(0, t.length() - 1);
          } 
          while (t.startsWith(" ")) {
            t = t.substring(1);
            replace = true;
          } 
          t = t.toUpperCase();
          if (t.contains("G")) {
            replace = true;
            t = t.replace("G", "");
          } 
          if (t.contains("H")) {
            replace = true;
            t = t.replace("H", "");
          } 
          if (t.contains("I")) {
            replace = true;
            t = t.replace("I", "");
          } 
          if (t.contains("J")) {
            replace = true;
            t = t.replace("J", "");
          } 
          if (t.contains("K")) {
            replace = true;
            t = t.replace("K", "");
          } 
          if (t.contains("L")) {
            replace = true;
            t = t.replace("L", "");
          } 
          if (t.contains("M")) {
            replace = true;
            t = t.replace("M", "");
          } 
          if (t.contains("N")) {
            replace = true;
            t = t.replace("N", "");
          } 
          if (t.contains("O")) {
            replace = true;
            t = t.replace("O", "");
          } 
          if (t.contains("P")) {
            replace = true;
            t = t.replace("P", "");
          } 
          if (t.contains("Q")) {
            replace = true;
            t = t.replace("Q", "");
          } 
          if (t.contains("R")) {
            replace = true;
            t = t.replace("R", "");
          } 
          if (t.contains("S")) {
            replace = true;
            t = t.replace("S", "");
          } 
          if (t.contains("T")) {
            replace = true;
            t = t.replace("T", "");
          } 
          if (t.contains("U")) {
            replace = true;
            t = t.replace("U", "");
          } 
          if (t.contains("V")) {
            replace = true;
            t = t.replace("V", "");
          } 
          if (t.contains("W")) {
            replace = true;
            t = t.replace("W", "");
          } 
          if (t.contains("X")) {
            replace = true;
            t = t.replace("X", "");
          } 
          if (t.contains("Y")) {
            replace = true;
            t = t.replace("Y", "");
          } 
          if (t.contains("Z")) {
            replace = true;
            t = t.replace("Z", "");
          } 
          if (t.contains(",")) {
            replace = true;
            t = t.replace(",", " ");
          } 
          if (t.contains(".")) {
            replace = true;
            t = t.replace(".", " ");
          } 
          if (replace)
            this.find.input.setText(t); 
        } 
        int value = search(this.find.input.getText(), this.find.ashex.isSelected(), this.find.wild.isSelected());
        if (value != 999999) {
          setAddress(value);
          setTextMode(!this.find.ashex.isSelected());
          setSelection(value + this.searchlength, true);
        } else {
          setTextMode(this.lasttextmode);
          setSelection(this.lastaddress, false);
        } 
      } else if (this.find.ashex.isSelected()) {
        String t = this.find.input.getText();
        boolean replace = false;
        while (t.endsWith("  ")) {
          replace = true;
          t = t.substring(0, t.length() - 1);
        } 
        while (t.startsWith(" ")) {
          t = t.substring(1);
          replace = true;
        } 
        t = t.toUpperCase();
        if (t.contains("G")) {
          replace = true;
          t = t.replace("G", "");
        } 
        if (t.contains("H")) {
          replace = true;
          t = t.replace("H", "");
        } 
        if (t.contains("I")) {
          replace = true;
          t = t.replace("I", "");
        } 
        if (t.contains("J")) {
          replace = true;
          t = t.replace("J", "");
        } 
        if (t.contains("K")) {
          replace = true;
          t = t.replace("K", "");
        } 
        if (t.contains("L")) {
          replace = true;
          t = t.replace("L", "");
        } 
        if (t.contains("M")) {
          replace = true;
          t = t.replace("M", "");
        } 
        if (t.contains("N")) {
          replace = true;
          t = t.replace("N", "");
        } 
        if (t.contains("O")) {
          replace = true;
          t = t.replace("O", "");
        } 
        if (t.contains("P")) {
          replace = true;
          t = t.replace("P", "");
        } 
        if (t.contains("Q")) {
          replace = true;
          t = t.replace("Q", "");
        } 
        if (t.contains("R")) {
          replace = true;
          t = t.replace("R", "");
        } 
        if (t.contains("S")) {
          replace = true;
          t = t.replace("S", "");
        } 
        if (t.contains("T")) {
          replace = true;
          t = t.replace("T", "");
        } 
        if (t.contains("U")) {
          replace = true;
          t = t.replace("U", "");
        } 
        if (t.contains("V")) {
          replace = true;
          t = t.replace("V", "");
        } 
        if (t.contains("W")) {
          replace = true;
          t = t.replace("W", "");
        } 
        if (t.contains("X")) {
          replace = true;
          t = t.replace("X", "");
        } 
        if (t.contains("Y")) {
          replace = true;
          t = t.replace("Y", "");
        } 
        if (t.contains("Z")) {
          replace = true;
          t = t.replace("Z", "");
        } 
        if (t.contains(",")) {
          replace = true;
          t = t.replace(",", " ");
        } 
        if (t.contains(".")) {
          replace = true;
          t = t.replace(".", " ");
        } 
        if (replace)
          this.find.input.setText(t); 
      }  
  }
  
  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == this.find.ashex) {
      String search = this.find.input.getText();
      if (this.find.ashex.isSelected()) {
        try {
          String result = "";
          byte[] con = search.getBytes("UTF-8");
          for (int i = 0; i < con.length; i++) {
            if (this.find.wild.isSelected() && (char)con[i] == '?') {
              result = result + "? ";
            } else {
              result = result + Util.hex(con[i]) + " ";
            } 
          } 
          this.find.input.setText(result);
        } catch (Exception exception) {}
      } else {
        String[] bytes = search.split(" ");
        String result = "";
        byte[] values = new byte[bytes.length];
        for (int i = 0; i < bytes.length; i++) {
          try {
            values[i] = (byte)Util.hexValue(bytes[i].toUpperCase());
            result = result + "" + (char)values[i];
            this.searchlength = values.length - 1;
          } catch (Exception f) {
            try {
              values[i] = (byte)bytes[i].charAt(0);
              result = result + "" + (char)values[i];
            } catch (Exception exception) {}
          } 
        } 
        this.find.input.setText(result);
      } 
    } 
    if (e.getSource() == this.find.search) {
      int value = search(this.find.input.getText(), this.find.ashex.isSelected(), this.find.wild.isSelected());
      if (value != 999999) {
        setAddress(value);
        setTextMode(!this.find.ashex.isSelected());
        setSelection(value + this.searchlength, true);
      } else {
        setTextMode(this.lasttextmode);
        setSelection(this.lastaddress, false);
      } 
    } 
  }
  
  public EMemory() {
    enableEvents(52L);
    setBackground(Color.white);
    setForeground(new Color(0, 0, 128));
    setLayout(new BorderLayout());
    setFont(new Font("Monospaced", 0, 12));
    setAutoscrolls(true);
    setFocusable(true);
    setDoubleBuffered(false);
  }
  
  public void setMemory(Memory value) {
    this.mem = value;
    this.addressDigits = Math.max(4, Integer.toHexString(this.mem.getAddressSize() - 1).length());
  }
  
  public void setComputer(Computer value) {
    setMemory((value == null) ? null : value.getMemory());
  }
  
  public byte[] getMem() {
    byte[] buffer = new byte[65536];
    for (int i = 0; i < 65536; i++) {
      if (this.read) {
        buffer[i] = (byte)this.mem.readByte(i, null);
      } else if (this.any) {
        buffer[i] = (byte)this.mem.readWriteByte(i, null);
      } else {
        buffer[i] = (byte)this.mem.readWriteByte(i, null, this.forcedbank, true);
      } 
    } 
    return buffer;
  }
  
  public int indexOf(byte[] pattern, boolean wild) {
    int[] failure = computeFailure(pattern, wild);
    int j = 0;
    byte[] data = getMem();
    if (wild) {
      for (int i = this.lastindex; i < data.length; i++) {
        while (j > 0 && pattern[j] != data[i] && pattern[j] != 63)
          j = failure[j - 1]; 
        if (pattern[j] == data[i] || pattern[j] == 63)
          j++; 
        if (j == pattern.length) {
          this.lastindex = i - pattern.length + 2;
          return i - pattern.length + 1;
        } 
      } 
    } else {
      for (int i = this.lastindex; i < data.length; i++) {
        while (j > 0 && pattern[j] != data[i])
          j = failure[j - 1]; 
        if (pattern[j] == data[i])
          j++; 
        if (j == pattern.length) {
          this.lastindex = i - pattern.length + 2;
          return i - pattern.length + 1;
        } 
      } 
    } 
    this.lastindex = 0;
    return 999999;
  }
  
  private static int[] computeFailure(byte[] pattern, boolean wild) {
    int[] failure = new int[pattern.length];
    int j = 0;
    if (wild) {
      for (int i = 1; i < pattern.length; i++) {
        while (j > 0 && pattern[j] != pattern[i] && pattern[j] != 63)
          j = failure[j - 1]; 
        if (pattern[j] == pattern[i] || pattern[j] == 63)
          j++; 
        failure[i] = j;
      } 
    } else {
      for (int i = 1; i < pattern.length; i++) {
        while (j > 0 && pattern[j] != pattern[i])
          j = failure[j - 1]; 
        if (pattern[j] == pattern[i])
          j++; 
        failure[i] = j;
      } 
    } 
    return failure;
  }
  
  public int search(String input, boolean ashex, boolean wild) {
    if (ashex) {
      input = input.replace(",", " ");
      while (input.startsWith(" "))
        input = input.substring(1); 
      while (input.endsWith(" "))
        input = input.substring(0, input.length() - 1); 
      String[] bytes = input.split(" ");
      byte[] values = new byte[bytes.length];
      for (int i = 0; i < bytes.length; i++) {
        try {
          values[i] = (byte)Util.hexValue(bytes[i].toUpperCase());
          this.searchlength = values.length - 1;
        } catch (Exception e) {
          try {
            values[i] = (byte)bytes[i].charAt(0);
          } catch (Exception g) {
            System.err.println("Search for hex data failed...");
            this.lastindex = 0;
            return 999999;
          } 
        } 
      } 
      return indexOf(values, wild);
    } 
    try {
      byte[] search = input.getBytes("UTF-8");
      this.searchlength = search.length - 1;
      return indexOf(search, wild);
    } catch (Exception e) {
      this.lastindex = 0;
      return 999999;
    } 
  }
  
  public void find() {
    if (this.find == null) {
      this.find = new Find();
      this.find.search.addActionListener(this);
      this.find.ashex.addActionListener(this);
      this.find.input.addKeyListener(this);
    } 
    this.find.setVisible(true);
  }
  
  protected void paintComponent(Graphics g) {
    byte[] buff = new byte[16];
    g.setColor(getBackground());
    g.fillRect(0, 0, getWidth(), getHeight());
    if (this.mem != null) {
      g.setFont(getFont());
      FontMetrics fm = g.getFontMetrics();
      g.setColor(getForeground());
      int a = fm.getAscent();
      this.ch = fm.getHeight();
      Rectangle rect = g.getClipBounds();
      Insets insets = getInsets();
      int row = (rect.y - insets.top) / this.ch;
      int y = insets.top + row * this.ch;
      int address = row * 16;
      for (; y < rect.y + rect.height; y += fm.getHeight()) {
        if (this.addressDigits > 4) {
          line = Util.hex(address);
          if (this.addressDigits < 8)
            line = line.substring(8 - this.addressDigits); 
        } else {
          line = Util.hex((short)address);
        } 
        String line = line + ": ";
        int w = fm.stringWidth(line);
        this.cw = w / line.length();
        this.left = w += insets.left;
        g.setColor(getForeground());
        int ya = y + a;
        g.drawString(line, insets.left + 4, ya);
        for (int i = 0; i < 16; i++) {
          if (this.read) {
            buff[i] = (byte)this.mem.readByte(address + i, null);
          } else if (this.any) {
            buff[i] = (byte)this.mem.readWriteByte(address + i, null);
          } else {
            buff[i] = (byte)this.mem.readWriteByte(address + i, null, this.forcedbank, true);
          } 
        } 
        line = Util.dumpBytes(buff, 0, 16, false, true, false);
        int start = 0;
        if (this.selStart < address + 16 && this.selEnd >= address)
          if (this.right) {
            int index = (this.selected - address) * 3 + 1;
            line = line.substring(0, index - 1) + line.charAt(index) + ' ' + line.substring(index + 1);
          } else {
            int end;
            if (this.textMode) {
              int textStart = line.length() - 16;
              start = Math.max(textStart, textStart + this.selStart - address);
              g.drawString(line.substring(0, start), w, ya);
              w += fm.stringWidth(line.substring(0, start));
              end = Math.min(line.length(), textStart + this.selEnd - address + 1);
            } else {
              start = Math.max(0, (this.selStart - address) * 3);
              if (start > 0) {
                g.drawString(line.substring(0, start), w, ya);
                w += fm.stringWidth(line.substring(0, start));
              } 
              end = Math.min(47, (this.selEnd - address + 1) * 3 - 1);
            } 
            int ww = fm.stringWidth(line.substring(start, end));
            g.setColor(this.selBackground);
            g.fillRect(w, y, ww, this.ch);
            g.setColor(this.selForeground);
            g.drawString(line.substring(start, end), w, ya);
            w += ww;
            start = end;
            g.setColor(getForeground());
          }  
        if (start != line.length())
          g.drawString(line.substring(start), w, ya); 
        address += 16;
        if (address >= this.mem.getAddressSize())
          break; 
      } 
      if (this.cursor) {
        Rectangle cursor = getRect(this.selected);
        if (this.right)
          cursor.x += this.cw; 
        g.setXORMode(Color.green);
        g.fillRect(cursor.x, cursor.y, cursor.width, cursor.height);
      } 
    } 
  }
  
  public Dimension getPreferredSize() {
    FontMetrics fm = Toolkit.getDefaultToolkit().getFontMetrics(getFont());
    return new Dimension(fm.charWidth('0') * (66 + this.addressDigits), fm
        .getHeight() * ((this.mem == null) ? 4096 : (this.mem.getAddressSize() >> 4)));
  }
  
  protected Point getCharacterCell(MouseEvent e) {
    Insets insets = getInsets();
    return new Point((e.getX() < this.left) ? -1 : ((e.getX() - this.left) / this.cw), (e.getY() - insets.top) / this.ch);
  }
  
  protected Rectangle getRect(int addr) {
    int y = (addr >> 4) * this.ch + (getInsets()).top;
    int x = addr & 0xF;
    x = this.textMode ? (this.left + (x + 50) * this.cw) : (this.left + x * this.cw * 3);
    return new Rectangle(x, y, this.textMode ? this.cw : (this.cw * 2), this.ch);
  }
  
  protected int getClickSection(Point ch) {
    int result = 0;
    if (ch.x >= 50) {
      ch.x -= 50;
      result = 3;
    } else if (ch.x >= 0) {
      switch (ch.x % 3) {
        case 0:
          result = 1;
          break;
        case 1:
          result = 2;
          break;
      } 
      ch.x /= 3;
    } 
    ch.x = Math.max(0, Math.min(ch.x, 15));
    return result;
  }
  
  protected void processMouseEvent(MouseEvent e) {
    if ((e.getModifiers() & 0x10) != 0 && 
      e.getID() == 501) {
      requestFocus();
      Point p = getCharacterCell(e);
      int section = getClickSection(p);
      this.lasttextmode = (section == 3);
      setTextMode((section == 3));
      this.lastaddress = this.lastindex = (p.y << 4) + p.x;
      setSelection((p.y << 4) + p.x, false);
    } 
    super.processMouseEvent(e);
  }
  
  protected void processMouseMotionEvent(MouseEvent e) {
    if ((e.getModifiers() & 0x10) != 0 && e.getID() == 506) {
      Point p = getCharacterCell(e);
      int section = getClickSection(p);
      if (this.textMode && section != 3) {
        p.x = 0;
      } else if (!this.textMode && section == 3) {
        p.x = 15;
      } 
      int addr = this.lastaddress = this.lastindex = (p.y << 4) + p.x;
      setSelection(addr, true);
    } 
    super.processMouseMotionEvent(e);
  }
  
  public void setTextMode(boolean value) {
    if (this.textMode != value) {
      this.textMode = value;
      this.right = false;
      repaint();
    } 
  }
  
  public int getPageSize() {
    return Math.max(1, (getSize()).height / this.ch);
  }
  
  protected void processKeyEvent(KeyEvent e) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getID : ()I
    //   4: sipush #401
    //   7: if_icmpne -> 344
    //   10: aload_1
    //   11: invokevirtual getModifiers : ()I
    //   14: iconst_1
    //   15: iand
    //   16: ifeq -> 23
    //   19: iconst_1
    //   20: goto -> 24
    //   23: iconst_0
    //   24: istore_2
    //   25: aload_1
    //   26: invokevirtual getKeyCode : ()I
    //   29: tableswitch default -> 341, 9 -> 316, 10 -> 341, 11 -> 341, 12 -> 341, 13 -> 341, 14 -> 341, 15 -> 341, 16 -> 341, 17 -> 341, 18 -> 341, 19 -> 341, 20 -> 341, 21 -> 341, 22 -> 341, 23 -> 341, 24 -> 341, 25 -> 341, 26 -> 341, 27 -> 341, 28 -> 341, 29 -> 341, 30 -> 341, 31 -> 341, 32 -> 341, 33 -> 299, 34 -> 282, 35 -> 181, 36 -> 172, 37 -> 198, 38 -> 226, 39 -> 212, 40 -> 250
    //   172: aload_0
    //   173: iconst_0
    //   174: iload_2
    //   175: invokevirtual setSelection : (IZ)V
    //   178: goto -> 341
    //   181: aload_0
    //   182: aload_0
    //   183: getfield mem : Ljemu/core/device/memory/Memory;
    //   186: invokevirtual getAddressSize : ()I
    //   189: iconst_1
    //   190: isub
    //   191: iload_2
    //   192: invokevirtual setSelection : (IZ)V
    //   195: goto -> 341
    //   198: aload_0
    //   199: aload_0
    //   200: getfield selected : I
    //   203: iconst_1
    //   204: isub
    //   205: iload_2
    //   206: invokevirtual setSelection : (IZ)V
    //   209: goto -> 341
    //   212: aload_0
    //   213: aload_0
    //   214: getfield selected : I
    //   217: iconst_1
    //   218: iadd
    //   219: iload_2
    //   220: invokevirtual setSelection : (IZ)V
    //   223: goto -> 341
    //   226: aload_0
    //   227: getfield selected : I
    //   230: bipush #15
    //   232: if_icmple -> 341
    //   235: aload_0
    //   236: aload_0
    //   237: getfield selected : I
    //   240: bipush #16
    //   242: isub
    //   243: iload_2
    //   244: invokevirtual setSelection : (IZ)V
    //   247: goto -> 341
    //   250: aload_0
    //   251: getfield selected : I
    //   254: aload_0
    //   255: getfield mem : Ljemu/core/device/memory/Memory;
    //   258: invokevirtual getAddressSize : ()I
    //   261: bipush #16
    //   263: isub
    //   264: if_icmpge -> 341
    //   267: aload_0
    //   268: aload_0
    //   269: getfield selected : I
    //   272: bipush #16
    //   274: iadd
    //   275: iload_2
    //   276: invokevirtual setSelection : (IZ)V
    //   279: goto -> 341
    //   282: aload_0
    //   283: aload_0
    //   284: getfield selected : I
    //   287: aload_0
    //   288: invokevirtual getPageSize : ()I
    //   291: iadd
    //   292: iload_2
    //   293: invokevirtual setSelection : (IZ)V
    //   296: goto -> 341
    //   299: aload_0
    //   300: aload_0
    //   301: getfield selected : I
    //   304: aload_0
    //   305: invokevirtual getPageSize : ()I
    //   308: isub
    //   309: iload_2
    //   310: invokevirtual setSelection : (IZ)V
    //   313: goto -> 341
    //   316: aload_1
    //   317: invokevirtual getModifiers : ()I
    //   320: iconst_2
    //   321: iand
    //   322: ifeq -> 341
    //   325: aload_0
    //   326: aload_0
    //   327: getfield textMode : Z
    //   330: ifne -> 337
    //   333: iconst_1
    //   334: goto -> 338
    //   337: iconst_0
    //   338: invokevirtual setTextMode : (Z)V
    //   341: goto -> 793
    //   344: aload_1
    //   345: invokevirtual getID : ()I
    //   348: sipush #400
    //   351: if_icmpne -> 793
    //   354: aload_1
    //   355: invokevirtual getKeyChar : ()C
    //   358: istore_2
    //   359: aload_0
    //   360: aload_0
    //   361: aload_0
    //   362: getfield selected : I
    //   365: invokevirtual getRect : (I)Ljava/awt/Rectangle;
    //   368: invokevirtual repaint : (Ljava/awt/Rectangle;)V
    //   371: aload_0
    //   372: getfield textMode : Z
    //   375: ifeq -> 507
    //   378: iload_2
    //   379: bipush #32
    //   381: if_icmplt -> 390
    //   384: iload_2
    //   385: bipush #127
    //   387: if_icmpge -> 390
    //   390: aload_0
    //   391: getfield read : Z
    //   394: ifeq -> 400
    //   397: goto -> 472
    //   400: aload_0
    //   401: getfield any : Z
    //   404: ifeq -> 423
    //   407: aload_0
    //   408: getfield mem : Ljemu/core/device/memory/Memory;
    //   411: aload_0
    //   412: getfield selected : I
    //   415: iload_2
    //   416: invokevirtual writeByte : (II)I
    //   419: pop
    //   420: goto -> 472
    //   423: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   426: new java/lang/StringBuilder
    //   429: dup
    //   430: invokespecial <init> : ()V
    //   433: ldc 'Writing to bank '
    //   435: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   438: aload_0
    //   439: getfield forcedbank : I
    //   442: invokestatic hex : (I)Ljava/lang/String;
    //   445: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   448: invokevirtual toString : ()Ljava/lang/String;
    //   451: invokevirtual println : (Ljava/lang/String;)V
    //   454: aload_0
    //   455: getfield mem : Ljemu/core/device/memory/Memory;
    //   458: aload_0
    //   459: getfield selected : I
    //   462: iload_2
    //   463: aload_0
    //   464: getfield forcedbank : I
    //   467: iconst_1
    //   468: invokevirtual writeByte : (IIIZ)I
    //   471: pop
    //   472: aload_0
    //   473: dup
    //   474: getfield selStart : I
    //   477: iconst_1
    //   478: isub
    //   479: putfield selStart : I
    //   482: aload_0
    //   483: aload_0
    //   484: getfield mem : Ljemu/core/device/memory/Memory;
    //   487: invokevirtual getAddressSize : ()I
    //   490: iconst_1
    //   491: isub
    //   492: aload_0
    //   493: getfield selected : I
    //   496: iconst_1
    //   497: iadd
    //   498: invokestatic min : (II)I
    //   501: invokevirtual setAddress : (I)V
    //   504: goto -> 781
    //   507: ldc '0123456789ABCDEFabcdef'
    //   509: iload_2
    //   510: invokevirtual indexOf : (I)I
    //   513: istore_3
    //   514: iload_3
    //   515: iconst_m1
    //   516: if_icmpeq -> 781
    //   519: iload_3
    //   520: bipush #15
    //   522: if_icmple -> 528
    //   525: iinc #3, -6
    //   528: aload_0
    //   529: aload_0
    //   530: getfield right : Z
    //   533: ifne -> 540
    //   536: iconst_1
    //   537: goto -> 541
    //   540: iconst_0
    //   541: dup_x1
    //   542: putfield right : Z
    //   545: ifeq -> 633
    //   548: aload_0
    //   549: getfield read : Z
    //   552: ifeq -> 558
    //   555: goto -> 781
    //   558: aload_0
    //   559: getfield any : Z
    //   562: ifeq -> 581
    //   565: aload_0
    //   566: getfield mem : Ljemu/core/device/memory/Memory;
    //   569: aload_0
    //   570: getfield selected : I
    //   573: iload_3
    //   574: invokevirtual writeByte : (II)I
    //   577: pop
    //   578: goto -> 781
    //   581: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   584: new java/lang/StringBuilder
    //   587: dup
    //   588: invokespecial <init> : ()V
    //   591: ldc 'Writing to bank '
    //   593: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   596: aload_0
    //   597: getfield forcedbank : I
    //   600: invokestatic hex : (I)Ljava/lang/String;
    //   603: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   606: invokevirtual toString : ()Ljava/lang/String;
    //   609: invokevirtual println : (Ljava/lang/String;)V
    //   612: aload_0
    //   613: getfield mem : Ljemu/core/device/memory/Memory;
    //   616: aload_0
    //   617: getfield selected : I
    //   620: iload_3
    //   621: aload_0
    //   622: getfield forcedbank : I
    //   625: iconst_1
    //   626: invokevirtual writeByte : (IIIZ)I
    //   629: pop
    //   630: goto -> 781
    //   633: aload_0
    //   634: getfield read : Z
    //   637: ifeq -> 643
    //   640: goto -> 749
    //   643: aload_0
    //   644: getfield any : Z
    //   647: ifeq -> 680
    //   650: aload_0
    //   651: getfield mem : Ljemu/core/device/memory/Memory;
    //   654: aload_0
    //   655: getfield selected : I
    //   658: aload_0
    //   659: getfield mem : Ljemu/core/device/memory/Memory;
    //   662: aload_0
    //   663: getfield selected : I
    //   666: invokevirtual readWriteByte : (I)I
    //   669: iconst_4
    //   670: ishl
    //   671: iload_3
    //   672: ior
    //   673: invokevirtual writeByte : (II)I
    //   676: pop
    //   677: goto -> 749
    //   680: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   683: new java/lang/StringBuilder
    //   686: dup
    //   687: invokespecial <init> : ()V
    //   690: ldc 'Writing to bank '
    //   692: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   695: aload_0
    //   696: getfield forcedbank : I
    //   699: invokestatic hex : (I)Ljava/lang/String;
    //   702: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   705: invokevirtual toString : ()Ljava/lang/String;
    //   708: invokevirtual println : (Ljava/lang/String;)V
    //   711: aload_0
    //   712: getfield mem : Ljemu/core/device/memory/Memory;
    //   715: aload_0
    //   716: getfield selected : I
    //   719: aload_0
    //   720: getfield mem : Ljemu/core/device/memory/Memory;
    //   723: aload_0
    //   724: getfield selected : I
    //   727: aconst_null
    //   728: aload_0
    //   729: getfield forcedbank : I
    //   732: iconst_1
    //   733: invokevirtual readWriteByte : (ILjava/lang/Object;IZ)I
    //   736: iconst_4
    //   737: ishl
    //   738: iload_3
    //   739: ior
    //   740: aload_0
    //   741: getfield forcedbank : I
    //   744: iconst_1
    //   745: invokevirtual writeByte : (IIIZ)I
    //   748: pop
    //   749: aload_0
    //   750: dup
    //   751: getfield selStart : I
    //   754: iconst_1
    //   755: isub
    //   756: putfield selStart : I
    //   759: aload_0
    //   760: aload_0
    //   761: getfield mem : Ljemu/core/device/memory/Memory;
    //   764: invokevirtual getAddressSize : ()I
    //   767: iconst_1
    //   768: isub
    //   769: aload_0
    //   770: getfield selected : I
    //   773: iconst_1
    //   774: iadd
    //   775: invokestatic min : (II)I
    //   778: invokevirtual setAddress : (I)V
    //   781: aload_0
    //   782: aload_0
    //   783: aload_0
    //   784: getfield selected : I
    //   787: invokevirtual getRect : (I)Ljava/awt/Rectangle;
    //   790: invokevirtual repaint : (Ljava/awt/Rectangle;)V
    //   793: aload_0
    //   794: aload_0
    //   795: getfield counter : Ljemu/ui/Counter;
    //   798: ifnull -> 805
    //   801: iconst_1
    //   802: goto -> 806
    //   805: iconst_0
    //   806: putfield cursor : Z
    //   809: aload_0
    //   810: aload_1
    //   811: invokespecial processKeyEvent : (Ljava/awt/event/KeyEvent;)V
    //   814: return
    // Line number table:
    //   Java source line number -> byte code offset
    //   #666	-> 0
    //   #667	-> 10
    //   #668	-> 25
    //   #670	-> 172
    //   #671	-> 178
    //   #673	-> 181
    //   #674	-> 195
    //   #676	-> 198
    //   #677	-> 209
    //   #679	-> 212
    //   #680	-> 223
    //   #682	-> 226
    //   #683	-> 235
    //   #687	-> 250
    //   #688	-> 267
    //   #692	-> 282
    //   #693	-> 296
    //   #695	-> 299
    //   #696	-> 313
    //   #698	-> 316
    //   #699	-> 325
    //   #703	-> 341
    //   #704	-> 354
    //   #705	-> 359
    //   #706	-> 371
    //   #707	-> 378
    //   #708	-> 390
    //   #709	-> 400
    //   #710	-> 407
    //   #712	-> 423
    //   #713	-> 454
    //   #715	-> 472
    //   #716	-> 482
    //   #718	-> 507
    //   #719	-> 514
    //   #720	-> 519
    //   #721	-> 525
    //   #723	-> 528
    //   #724	-> 548
    //   #725	-> 558
    //   #726	-> 565
    //   #728	-> 581
    //   #729	-> 612
    //   #732	-> 633
    //   #733	-> 643
    //   #734	-> 650
    //   #736	-> 680
    //   #737	-> 711
    //   #739	-> 749
    //   #740	-> 759
    //   #744	-> 781
    //   #746	-> 793
    //   #747	-> 809
    //   #748	-> 814
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   25	316	2	shift	Z
    //   514	267	3	hex	I
    //   359	434	2	ch	C
    //   0	815	0	this	Ljemu/ui/EMemory;
    //   0	815	1	e	Ljava/awt/event/KeyEvent;
  }
  
  protected void setSelection(int addr) {
    setSelection(addr, true);
  }
  
  protected void setSelection(int addr, boolean range) {
    int start, end;
    this.selected = addr = Math.max(0, Math.min(this.mem.getAddressSize() - 1, addr));
    if (!range) {
      start = end = this.selAnchor = addr;
    } else if (addr < this.selAnchor) {
      start = addr;
      end = this.selAnchor;
    } else {
      end = addr;
      start = this.selAnchor;
    } 
    if (this.right || start != this.selStart || end != this.selEnd) {
      this.right = false;
      this.selStart = start;
      this.selEnd = end;
      scrollRectToVisible(getRect(addr));
      repaint();
    } 
  }
  
  public void setAddress(int addr) {
    setSelection(addr, false);
  }
  
  protected void processFocusEvent(FocusEvent e) {
    if (e.getID() == 1004) {
      if (this.counter == null)
        this.counter = new Counter(this, 250L, null); 
      this.cursor = true;
    } else if (e.getID() == 1005 && this.counter != null) {
      if (this.right) {
        this.right = false;
        repaint(getRect(this.selected));
      } 
      this.counter.stop();
      timerTick(this.counter = null);
    } 
    super.processFocusEvent(e);
  }
  
  public void timerTick(Counter counter) {
    this.cursor = (!this.cursor && counter != null);
    repaint(getRect(this.selected));
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\EMemory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */