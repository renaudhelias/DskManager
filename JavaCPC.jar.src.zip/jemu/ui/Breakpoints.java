package jemu.ui;

import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.LayoutStyle;

public class Breakpoints extends JFrame {
  public JButton clear;
  
  public JButton clearall;
  
  public JButton cycles;
  
  private JLabel jLabel1;
  
  private JScrollPane jScrollPane1;
  
  public JList points;
  
  public Breakpoints() {
    initComponents();
  }
  
  private void initComponents() {
    this.jScrollPane1 = new JScrollPane();
    this.points = new JList();
    this.jLabel1 = new JLabel();
    this.clear = new JButton();
    this.clearall = new JButton();
    this.cycles = new JButton();
    setTitle("Breakpoints");
    this.points.setFont(new Font("Monospaced", 1, 12));
    this.jScrollPane1.setViewportView(this.points);
    this.jLabel1.setText("Address:");
    this.clear.setText("Clear");
    this.clear.setFocusPainted(false);
    this.clear.setFocusable(false);
    this.clearall.setText("Clear All");
    this.clearall.setFocusPainted(false);
    this.clearall.setFocusable(false);
    this.cycles.setText("Set cycles");
    this.cycles.setFocusPainted(false);
    this.cycles.setFocusable(false);
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jScrollPane1, -1, 227, 32767)
            .addComponent(this.jLabel1)
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.cycles)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.clear)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.clearall)))
          .addContainerGap()));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addComponent(this.jLabel1)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.jScrollPane1, -1, 86, 32767)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.clear)
            .addComponent(this.clearall)
            .addComponent(this.cycles))
          .addContainerGap()));
    pack();
  }
  
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new Breakpoints()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\Breakpoints.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */