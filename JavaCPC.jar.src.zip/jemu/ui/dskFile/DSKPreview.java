package jemu.ui.dskFile;

import java.awt.Dimension;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.border.EtchedBorder;
import jemu.system.cpc.GateArray;
import jemu.ui.Switches;

public class DSKPreview extends DPanel implements PropertyChangeListener {
  File file = null;
  
  public static int[] user;
  
  public DSKPreview(JFileChooser fc) {
    setPreferredSize(new Dimension(200, 100));
    setBorder(new EtchedBorder());
    fc.addPropertyChangeListener(this);
  }
  
  public void checkDSK(String filename) {
    int drive = GateArray.cpc.getDrive();
    GateArray.cpc.setDrive(3);
    boolean flopsound = Switches.FloppySound;
    Switches.FloppySound = false;
    try {
      GateArray.cpc.loadFile(1, filename);
      String[] files = GateArray.cpc.getDir();
      user = GateArray.cpc.getUser();
      for (int i = 0; i < files.length; i++) {
        while (files[i].length() > 12)
          files[i] = files[i].substring(0, files[i].length() - 1); 
        files[i] = files[i] + " | USR:" + user[i];
      } 
      setList(files);
      setList2(GateArray.cpc.getDir());
    } catch (Exception exception) {}
    GateArray.cpc.setDrive(drive);
    Switches.FloppySound = flopsound;
  }
  
  public void loadImage() {
    try {
      if (this.file == null) {
        setList((String[])null);
        return;
      } 
      try {
        if (this.file.getPath().toLowerCase().endsWith(".dsk")) {
          checkDSK(this.file.getPath());
        } else {
          setList((String[])null);
        } 
      } catch (Exception e) {
        setList((String[])null);
      } 
    } catch (Exception exception) {}
  }
  
  public void propertyChange(PropertyChangeEvent e) {
    boolean update = false;
    String prop = e.getPropertyName();
    if ("directoryChanged".equals(prop)) {
      this.file = null;
      update = true;
    } else if ("SelectedFileChangedProperty".equals(prop)) {
      this.file = (File)e.getNewValue();
      update = true;
    } 
    if (update && 
      isShowing()) {
      loadImage();
      repaint();
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\dskFile\DSKPreview.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */