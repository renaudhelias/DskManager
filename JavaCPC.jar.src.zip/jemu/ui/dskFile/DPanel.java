package jemu.ui.dskFile;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.AbstractListModel;
import javax.swing.GroupLayout;
import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.LayoutStyle;

public class DPanel extends JPanel {
  String[] filelist;
  
  JList jList12;
  
  public static String type;
  
  public static boolean run;
  
  public static boolean boot;
  
  private JCheckBox jCheckBox1;
  
  private JCheckBox jCheckBox2;
  
  private JList jList1;
  
  private JScrollPane jScrollPane1;
  
  public DPanel() {
    this.jList12 = new JList();
    initComponents();
  }
  
  public void setList(final String[] list) {
    if (list == null) {
      this.filelist = null;
      this.jList1.setModel(new AbstractListModel() {
            String[] strings = new String[0];
            
            public int getSize() {
              return this.strings.length;
            }
            
            public Object getElementAt(int i) {
              return this.strings[i];
            }
          });
      return;
    } 
    this.filelist = new String[list.length];
    System.arraycopy(list, 0, this.filelist, 0, list.length);
    this.jList1.setModel(new AbstractListModel() {
          public int getSize() {
            return list.length;
          }
          
          public Object getElementAt(int i) {
            return list[i];
          }
        });
  }
  
  public void setList2(final String[] list) {
    if (list == null) {
      this.filelist = null;
      for (int i = 0; i < list.length; i++) {
        while (list[i].length() > 12)
          list[i] = list[i].substring(0, list[i].length() - 1); 
      } 
      this.jList12.setModel(new AbstractListModel() {
            String[] strings = new String[0];
            
            public int getSize() {
              return this.strings.length;
            }
            
            public Object getElementAt(int i) {
              return this.strings[i];
            }
          });
      return;
    } 
    this.filelist = new String[list.length];
    System.arraycopy(list, 0, this.filelist, 0, list.length);
    this.jList12.setModel(new AbstractListModel() {
          public int getSize() {
            return list.length;
          }
          
          public Object getElementAt(int i) {
            return list[i];
          }
        });
  }
  
  private void initComponents() {
    this.jScrollPane1 = new JScrollPane();
    this.jList1 = new JList();
    this.jCheckBox1 = new JCheckBox();
    this.jCheckBox2 = new JCheckBox();
    this.jList1.setFont(new Font("Monospaced", 1, 12));
    this.jList1.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            DPanel.this.jList1MouseReleased(evt);
          }
        });
    this.jScrollPane1.setViewportView(this.jList1);
    this.jCheckBox1.setText("Boot");
    this.jCheckBox1.setFocusPainted(false);
    this.jCheckBox1.setFocusable(false);
    this.jCheckBox1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DPanel.this.jCheckBox1ActionPerformed(evt);
          }
        });
    this.jCheckBox2.setText("RUN selected");
    this.jCheckBox2.setFocusPainted(false);
    this.jCheckBox2.setFocusable(false);
    this.jCheckBox2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DPanel.this.jCheckBox2ActionPerformed(evt);
          }
        });
    GroupLayout layout = new GroupLayout(this);
    setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jScrollPane1, -1, 193, 32767)
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.jCheckBox1)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jCheckBox2)))
          .addContainerGap()));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
          .addContainerGap()
          .addComponent(this.jScrollPane1, -1, 189, 32767)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jCheckBox1)
            .addComponent(this.jCheckBox2))
          .addContainerGap()));
  }
  
  private void jCheckBox1ActionPerformed(ActionEvent evt) {
    boot = this.jCheckBox1.isSelected();
    this.jList1.setEnabled(!boot);
    if (this.jCheckBox1.isSelected()) {
      run = false;
      this.jCheckBox2.setSelected(false);
    } 
  }
  
  private void jCheckBox2ActionPerformed(ActionEvent evt) {
    if (this.jCheckBox2.isSelected()) {
      this.jCheckBox1.setSelected(false);
      boot = false;
    } 
    run = this.jCheckBox2.isSelected();
  }
  
  private void jList1MouseReleased(MouseEvent evt) {
    if (DSKPreview.user == null || this.jList1.getSelectedIndex() < 0) {
      type = null;
      return;
    } 
    this.jList12.setSelectedIndex(this.jList1.getSelectedIndex());
    String us = "|USER," + DSKPreview.user[this.jList12.getSelectedIndex()] + "\n";
    String before = "";
    type = before + us + "RUN\"" + this.filelist[this.jList12.getSelectedIndex()] + "\"";
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\dskFile\DPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */