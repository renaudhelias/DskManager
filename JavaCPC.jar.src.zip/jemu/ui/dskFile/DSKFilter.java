package jemu.ui.dskFile;

import java.io.File;
import javax.swing.filechooser.FileFilter;

public class DSKFilter extends FileFilter {
  public boolean accept(File f) {
    if (f.isDirectory())
      return true; 
    String extension = Utils.getExtension(f);
    if (extension != null) {
      if (extension.equals("dsk"))
        return true; 
      return false;
    } 
    return false;
  }
  
  public String getDescription() {
    return "DSK image files";
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\dskFile\DSKFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */