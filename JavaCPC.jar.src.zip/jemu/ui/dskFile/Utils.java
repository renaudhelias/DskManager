package jemu.ui.dskFile;

import java.io.File;
import java.net.URL;
import javax.swing.ImageIcon;

public class Utils {
  public static final String dsk = "dsk";
  
  public static final String jpeg = "jpeg";
  
  public static final String jpg = "jpg";
  
  public static final String gif = "gif";
  
  public static final String tiff = "tiff";
  
  public static final String tif = "tif";
  
  public static final String png = "png";
  
  public static final String scr = "scr";
  
  public static final String bmp = "bmp";
  
  public static final String tga = "tga";
  
  public static final String pcx = "pcx";
  
  public static String getExtension(File f) {
    String ext = null;
    String s = f.getName();
    int i = s.lastIndexOf('.');
    if (i > 0 && i < s.length() - 1)
      ext = s.substring(i + 1).toLowerCase(); 
    return ext;
  }
  
  protected static ImageIcon createImageIcon(String path) {
    URL imgURL = Utils.class.getResource(path);
    if (imgURL != null)
      return new ImageIcon(imgURL); 
    System.err.println("Couldn't find file: " + path);
    return null;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\dskFile\Utils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */