package jemu.ui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import jemu.system.cpc.GateArray;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rtextarea.RTextArea;
import org.fife.ui.rtextarea.RTextScrollPane;

public class Autotype extends WindowAdapter implements WindowListener, ActionListener {
  public RTextScrollPane ScrollField;
  
  JFileChooser saveFileChooser = new JFileChooser(System.getProperty("/"));
  
  static JFileChooser loadFileChooser = new JFileChooser(System.getProperty("/"));
  
  protected GridBagConstraints gbcConstraints = null;
  
  public static JFrame typeconsole;
  
  public static String autotext;
  
  public static RSyntaxTextArea textArea;
  
  public JButton button = new JButton(" Send text ");
  
  public static JCheckBox bix = new JCheckBox("As BASIC");
  
  public JButton button2 = new JButton(" Clear console ");
  
  public JButton button3 = new JButton(" Copy text ");
  
  public JButton button4 = new JButton(" Paste text ");
  
  public static JButton button5 = new JButton(" Load... ");
  
  public static JButton button6 = new JButton(" Save... ");
  
  public Autotype() {
    typeconsole = new JFrame("JavaCPC Autotype");
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = new Dimension(screenSize.width / 2, screenSize.height / 2);
    int x = frameSize.width / 2 + 110;
    int y = frameSize.height / 2 + 60;
    typeconsole.setBounds(x, y, 540, 480);
    textArea = new RSyntaxTextArea();
    textArea.setSyntaxEditingStyle("text/c");
    textArea.setAnimateBracketMatching(true);
    textArea.setCaretColor(Color.BLUE);
    this.ScrollField = new RTextScrollPane((RTextArea)textArea);
    this.ScrollField.getGutter().setBookmarkingEnabled(false);
    this.ScrollField.setIconRowHeaderEnabled(true);
    this.ScrollField.setLineNumbersEnabled(true);
    typeconsole.setResizable(false);
    textArea.setLineWrap(true);
    textArea.setEditable(true);
    textArea.setAutoscrolls(true);
    bix.setSelected(true);
    typeconsole.getContentPane().setLayout(new GridBagLayout());
    typeconsole.add(this.button, getGridBagConstraints(1, 2, 1.0D, 0.0D, 1, 1));
    typeconsole.add(bix, getGridBagConstraints(2, 2, 1.0D, 0.0D, 1, 1));
    typeconsole.add(this.button2, getGridBagConstraints(3, 2, 1.0D, 0.0D, 1, 1));
    typeconsole.add(this.button3, getGridBagConstraints(4, 2, 1.0D, 0.0D, 1, 1));
    typeconsole.add(button5, getGridBagConstraints(1, 3, 1.0D, 0.0D, 1, 1));
    typeconsole.add(button6, getGridBagConstraints(2, 3, 1.0D, 0.0D, 1, 1));
    typeconsole.add(this.button4, getGridBagConstraints(3, 3, 1.0D, 0.0D, 1, 1));
    typeconsole.add((Component)this.ScrollField, getGridBagConstraints(1, 1, 1.0D, 1.0D, 5, 1));
    typeconsole.setAlwaysOnTop(true);
    typeconsole.setVisible(false);
    typeconsole.addWindowListener(this);
    this.button.addActionListener(this);
    this.button.setFocusable(false);
    this.button2.addActionListener(this);
    this.button2.setFocusable(false);
    this.button3.addActionListener(this);
    this.button3.setFocusable(false);
    this.button4.addActionListener(this);
    this.button4.setFocusable(false);
    button5.addActionListener(this);
    button5.setFocusable(false);
    button6.addActionListener(this);
    button6.setFocusable(false);
    open();
  }
  
  private GridBagConstraints getGridBagConstraints(int x, int y, double weightx, double weighty, int width, int fill) {
    if (this.gbcConstraints == null)
      this.gbcConstraints = new GridBagConstraints(); 
    this.gbcConstraints.gridx = x;
    this.gbcConstraints.gridy = y;
    this.gbcConstraints.weightx = weightx;
    this.gbcConstraints.weighty = weighty;
    this.gbcConstraints.gridwidth = width;
    this.gbcConstraints.fill = fill;
    return this.gbcConstraints;
  }
  
  public synchronized void windowClosing(WindowEvent evt) {
    save();
    typeconsole.setVisible(false);
  }
  
  public synchronized void actionPerformed(ActionEvent evt) {
    if (evt.getSource() == this.button)
      SendToCPC(bix.isSelected()); 
    if (evt.getSource() == this.button2) {
      textArea.setText("");
      save();
    } 
    if (evt.getSource() == this.button3 && 
      !textArea.getText().equals("")) {
      textArea.selectAll();
      textArea.copy();
      textArea.paste();
    } 
    if (evt.getSource() == this.button4)
      textArea.paste(); 
    if (evt.getSource() == button5)
      openFile(); 
    if (evt.getSource() == button6)
      saveFile(); 
  }
  
  public static void PasteText() {
    save();
    textArea.setText("");
    textArea.paste();
    textArea.selectAll();
    autotext = textArea.getText();
    GateArray.cpc.fromautoboot = true;
    GateArray.cpc.BasicAutoType(autotext);
    autotext = "";
    textArea.selectAll();
    open();
  }
  
  public static void SendToCPC(boolean asbasic) {
    SendToCPC(asbasic, false);
  }
  
  public static void SendToCPC(boolean asbasic, boolean linejump) {
    if (asbasic) {
      String put = textArea.getText();
      GateArray.cpc.fromautoboot = true;
      GateArray.cpc.BasicAutoType(put, linejump);
      return;
    } 
    textArea.selectAll();
    autotext = textArea.getText();
    Switches.getfromautotype = 1;
    textArea.selectAll();
  }
  
  public void openFile() {
    FileDialog filedia = new FileDialog(typeconsole, "Import ASCII...", 0);
    filedia.setFile("*.txt; *.asm; *.bas");
    filedia.setVisible(true);
    String filename = filedia.getFile();
    if (filename != null) {
      filename = filedia.getDirectory() + filedia.getFile();
      String loadname = filename;
      File file = new File(loadname);
      StringBuffer contents = new StringBuffer();
      BufferedReader reader = null;
      try {
        reader = new BufferedReader(new FileReader(file));
        String text = null;
        while ((text = reader.readLine()) != null)
          contents.append(text).append(System.getProperty("line.separator")); 
      } catch (FileNotFoundException e) {
        e.printStackTrace();
      } catch (IOException e) {
        e.printStackTrace();
      } finally {
        try {
          if (reader != null)
            reader.close(); 
        } catch (IOException e) {
          e.printStackTrace();
        } 
      } 
      textArea.setText(contents.toString());
    } 
    filedia.dispose();
  }
  
  public static void loadFile() {
    save();
    FileDialog filedia = new FileDialog(typeconsole, "Import ASCII...", 0);
    filedia.setFile("*.txt; *.asm; *.bas");
    filedia.setVisible(true);
    String filename = filedia.getFile();
    if (filename != null) {
      filename = filedia.getDirectory() + filedia.getFile();
      String loadname = filename;
      File file = new File(loadname);
      StringBuffer contents = new StringBuffer();
      BufferedReader reader = null;
      try {
        reader = new BufferedReader(new FileReader(file));
        String text = null;
        while ((text = reader.readLine()) != null)
          contents.append(text).append(System.getProperty("line.separator")); 
      } catch (FileNotFoundException e) {
        e.printStackTrace();
      } catch (IOException e) {
        e.printStackTrace();
      } finally {
        try {
          if (reader != null)
            reader.close(); 
        } catch (IOException e) {
          e.printStackTrace();
        } 
      } 
      textArea.setText(contents.toString());
      SendToCPC(bix.isSelected());
    } 
    filedia.dispose();
    open();
  }
  
  public void saveFile() {
    FileDialog filedia = new FileDialog(typeconsole, "Save ASCII...", 1);
    filedia.setFile("*.txt; *.asm; *.bas");
    filedia.setVisible(true);
    String filename = filedia.getFile();
    if (filename != null) {
      filename = filedia.getDirectory() + filedia.getFile();
      String savename = filename;
      if (!savename.toLowerCase().endsWith(".txt") && 
        !savename.toLowerCase().endsWith(".asm") && 
        !savename.toLowerCase().endsWith(".bas"))
        savename = savename + ".txt"; 
      File file = new File(savename);
      String exportedText = textArea.getText();
      try {
        FileWriter fw = new FileWriter(file);
        fw.write(exportedText);
        fw.close();
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
    filedia.dispose();
  }
  
  public static void open() {
    File file = new File(System.getProperty("user.home"), "/JavaCPC/autotype.dat");
    StringBuffer importedText = new StringBuffer();
    BufferedReader reader = null;
    try {
      reader = new BufferedReader(new FileReader(file));
      String text = null;
      while ((text = reader.readLine()) != null)
        importedText.append(text).append(System.getProperty("line.separator")); 
    } catch (FileNotFoundException fileNotFoundException) {
      try {
        if (reader != null)
          reader.close(); 
      } catch (IOException iOException) {}
    } catch (IOException iOException) {
      try {
        if (reader != null)
          reader.close(); 
      } catch (IOException iOException1) {}
    } finally {
      try {
        if (reader != null)
          reader.close(); 
      } catch (IOException iOException) {}
    } 
    textArea.setText(importedText.toString());
  }
  
  public static void save() {
    String exportedText = textArea.getText();
    File file = new File(System.getProperty("user.home"), "/JavaCPC/autotype.dat");
    try {
      FileWriter fw = new FileWriter(file);
      fw.write(exportedText);
      fw.close();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\Autotype.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */