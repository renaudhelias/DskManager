package jemu.ui;

import java.io.File;
import javax.swing.filechooser.FileFilter;

public class ImageFilter extends FileFilter {
  public boolean accept(File f) {
    if (f.isDirectory())
      return true; 
    String extension = Utils.getExtension(f);
    if (extension != null) {
      if (extension.equals("gif") || extension
        .equals("jpeg") || extension
        .equals("jpg") || extension
        .equals("png"))
        return true; 
      return false;
    } 
    return false;
  }
  
  public String getDescription() {
    return "Just Images";
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\ImageFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */