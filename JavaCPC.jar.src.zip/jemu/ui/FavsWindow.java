package jemu.ui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;
import jemu.settings.FSettings;

public class FavsWindow extends JFrame {
  Vector faven;
  
  protected String[] names;
  
  protected String[] urls;
  
  protected String[] cnames;
  
  protected String[] curls;
  
  int all;
  
  public JButton add;
  
  public JComboBox fcombo;
  
  public JButton goTo;
  
  private JLabel jLabel1;
  
  private JLabel jLabel2;
  
  private JLabel jLabel3;
  
  public JTextField nfield;
  
  public JButton remove;
  
  public JTextField ufield;
  
  public FavsWindow() {
    this.all = 0;
    this.names = new String[1000];
    this.urls = new String[1000];
    this.cnames = new String[1000];
    this.curls = new String[1000];
    initComponents();
    buildFavs();
  }
  
  public void buildFavs() {
    int index = 0;
    int cindex = 0;
    boolean getting = true;
    this.fcombo.removeAllItems();
    try {
      this.all = 0;
      while (getting) {
        this.names[index] = FSettings.get("fav_name_" + Integer.toString(index), "none");
        if (this.names[index].equals("none"))
          break; 
        this.urls[index] = FSettings.get("fav_url_" + Integer.toString(index), "none");
        this.cnames[cindex] = this.names[index];
        this.curls[cindex] = this.urls[index];
        index++;
        cindex++;
      } 
    } catch (Exception e) {
      getting = false;
    } 
    this.all = cindex;
    for (int p = 0; p < this.all; p++)
      this.fcombo.addItem(this.cnames[p]); 
  }
  
  public void addFav(String name, String url) {
    int index = this.all;
    FSettings.set("fav_url_" + Integer.toString(index), url);
    FSettings.set("fav_name_" + Integer.toString(index), name);
    buildFavs();
  }
  
  public void remFav() {
    Browser.showFavs = FSettings.getBoolean("fav_show", false);
    int index = this.fcombo.getSelectedIndex();
    if (index == -1)
      return; 
    this.cnames[index] = "deleted";
    int windex = 0;
    FSettings.delete();
    String dummy = FSettings.get("fav_url_", "Dummy");
    for (int p = 0; p < this.all; p++) {
      if (!this.cnames[p].equals("deleted") && this.cnames[p] != null) {
        FSettings.set("fav_name_" + Integer.toString(windex), this.cnames[p]);
        FSettings.set("fav_url_" + Integer.toString(windex), this.curls[p]);
        windex++;
      } 
    } 
    buildFavs();
    FSettings.setBoolean("fav_show", Browser.showFavs);
  }
  
  private void initComponents() {
    this.jLabel1 = new JLabel();
    this.fcombo = new JComboBox();
    this.add = new JButton();
    this.remove = new JButton();
    this.nfield = new JTextField();
    this.jLabel2 = new JLabel();
    this.jLabel3 = new JLabel();
    this.ufield = new JTextField();
    this.goTo = new JButton();
    setTitle("Favourites");
    setAlwaysOnTop(true);
    this.jLabel1.setText("Favourites:");
    this.add.setText("Add");
    this.add.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FavsWindow.this.addActionPerformed(evt);
          }
        });
    this.remove.setText("Remove");
    this.remove.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FavsWindow.this.removeActionPerformed(evt);
          }
        });
    this.jLabel2.setText("Name:");
    this.jLabel3.setText("URL:");
    this.goTo.setText("Go to");
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.jLabel1)
              .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
              .addComponent(this.fcombo, 0, 315, 32767))
            .addGroup(layout.createSequentialGroup()
              .addGap(22, 22, 22)
              .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                .addComponent(this.jLabel2)
                .addComponent(this.jLabel3))
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(this.nfield, -1, 323, 32767)
                .addComponent(this.ufield, -1, 323, 32767)))
            .addComponent(this.add, GroupLayout.Alignment.TRAILING)
            .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
              .addComponent(this.goTo)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.remove)))
          .addContainerGap()));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jLabel1)
            .addComponent(this.fcombo, -2, -1, -2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.remove)
            .addComponent(this.goTo))
          .addGap(11, 11, 11)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.nfield, -2, -1, -2)
            .addComponent(this.jLabel2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jLabel3)
            .addComponent(this.ufield, -2, -1, -2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.add)
          .addContainerGap(-1, 32767)));
    pack();
  }
  
  private void addActionPerformed(ActionEvent evt) {
    if (this.nfield.getText().length() < 1 || this.ufield.getText().length() < 1)
      return; 
    addFav(this.nfield.getText(), this.ufield.getText());
  }
  
  private void removeActionPerformed(ActionEvent evt) {
    remFav();
  }
  
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new FavsWindow()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\FavsWindow.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */