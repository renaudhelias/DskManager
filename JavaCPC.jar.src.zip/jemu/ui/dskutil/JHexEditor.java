package jemu.ui.dskutil;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import javax.swing.JPanel;
import javax.swing.JScrollBar;

public class JHexEditor extends JPanel implements FocusListener, AdjustmentListener, MouseWheelListener {
  byte[] buff;
  
  public int cursor;
  
  protected static Font font = new Font("Monospaced", 0, 12);
  
  protected int border = 2;
  
  public boolean DEBUG = false;
  
  private JPanel panel;
  
  private JScrollBar sb;
  
  private int inicio = 0;
  
  private int lineas = 10;
  
  public JHexEditor(byte[] buff) {
    this.buff = buff;
    addMouseWheelListener(this);
    this.sb = new JScrollBar(1);
    this.sb.addAdjustmentListener(this);
    this.sb.setMinimum(0);
    this.sb.setMaximum(buff.length / getLineas());
    JPanel p1 = new JPanel(new BorderLayout(1, 1));
    p1.add(new JHexEditorHEX(this), "Center");
    p1.add(new Columnas(), "South");
    JPanel p2 = new JPanel(new BorderLayout(1, 1));
    p2.add(new Filas(), "Center");
    p2.add(new Caja(), "South");
    JPanel p3 = new JPanel(new BorderLayout(1, 1));
    p3.add(this.sb, "East");
    p3.add(new JHexEditorASCII(this), "Center");
    p3.add(new Caja(), "South");
    setLayout(new BorderLayout(8, 1));
    add(p2, "West");
    add(p1, "Center");
    add(p3, "East");
  }
  
  public void paint(Graphics g) {
    FontMetrics fn = getFontMetrics(font);
    Rectangle rec = getBounds();
    this.lineas = rec.height / fn.getHeight() - 1;
    int n = this.buff.length / 16 - 1;
    if (this.lineas > n) {
      this.lineas = n;
      this.inicio = 0;
    } 
    this.sb.setValues(getInicio(), getLineas(), 0, this.buff.length / 16);
    this.sb.setValueIsAdjusting(true);
    super.paint(g);
  }
  
  protected void actualizaCursor() {
    int n = this.cursor / 16;
    System.out.print("- " + this.inicio + "<" + n + "<" + (this.lineas + this.inicio) + "(" + this.lineas + ")");
    if (n < this.inicio) {
      this.inicio = n;
    } else if (n >= this.inicio + this.lineas) {
      this.inicio = n - this.lineas - 1;
    } 
    System.out.println(" - " + this.inicio + "<" + n + "<" + (this.lineas + this.inicio) + "(" + this.lineas + ")");
    repaint();
  }
  
  protected int getInicio() {
    return this.inicio;
  }
  
  protected int getLineas() {
    return this.lineas;
  }
  
  protected void fondo(Graphics g, int x, int y, int s) {
    FontMetrics fn = getFontMetrics(font);
    g.fillRect((fn.stringWidth(" ") + 1) * x + this.border, fn.getHeight() * y + this.border, (fn.stringWidth(" ") + 1) * s, fn.getHeight() + 1);
  }
  
  protected void cuadro(Graphics g, int x, int y, int s) {
    FontMetrics fn = getFontMetrics(font);
    g.drawRect((fn.stringWidth(" ") + 1) * x + this.border, fn.getHeight() * y + this.border, (fn.stringWidth(" ") + 1) * s, fn.getHeight() + 1);
  }
  
  protected void printString(Graphics g, String s, int x, int y) {
    FontMetrics fn = getFontMetrics(font);
    g.drawString(s, (fn.stringWidth(" ") + 1) * x + this.border, fn.getHeight() * (y + 1) - fn.getMaxDescent() + this.border);
  }
  
  public void focusGained(FocusEvent e) {
    repaint();
  }
  
  public void focusLost(FocusEvent e) {
    repaint();
  }
  
  public void adjustmentValueChanged(AdjustmentEvent e) {
    this.inicio = e.getValue();
    if (this.inicio < 0)
      this.inicio = 0; 
    repaint();
  }
  
  public void mouseWheelMoved(MouseWheelEvent e) {
    this.inicio += e.getUnitsToScroll();
    if (this.inicio + this.lineas >= this.buff.length / 16)
      this.inicio = this.buff.length / 16 - this.lineas; 
    if (this.inicio < 0)
      this.inicio = 0; 
    repaint();
  }
  
  public void keyPressed(KeyEvent e) {
    switch (e.getKeyCode()) {
      case 33:
        if (this.cursor >= 16 * this.lineas)
          this.cursor -= 16 * this.lineas; 
        actualizaCursor();
        break;
      case 34:
        if (this.cursor < this.buff.length - 16 * this.lineas)
          this.cursor += 16 * this.lineas; 
        actualizaCursor();
        break;
      case 35:
        this.cursor = this.buff.length - 1;
        actualizaCursor();
        break;
      case 36:
        this.cursor = 0;
        actualizaCursor();
        break;
      case 37:
        if (this.cursor != 0)
          this.cursor--; 
        actualizaCursor();
        break;
      case 38:
        if (this.cursor > 15)
          this.cursor -= 16; 
        actualizaCursor();
        break;
      case 39:
        if (this.cursor != this.buff.length - 1)
          this.cursor++; 
        actualizaCursor();
        break;
      case 40:
        if (this.cursor < this.buff.length - 16)
          this.cursor += 16; 
        actualizaCursor();
        break;
    } 
  }
  
  private class Columnas extends JPanel {
    public Columnas() {
      setLayout(new BorderLayout(1, 1));
    }
    
    public Dimension getPreferredSize() {
      return getMinimumSize();
    }
    
    public Dimension getMinimumSize() {
      Dimension d = new Dimension();
      FontMetrics fn = getFontMetrics(JHexEditor.font);
      int h = fn.getHeight();
      int nl = 1;
      d.setSize((fn.stringWidth(" ") + 1) * 47 + JHexEditor.this.border * 2 + 1, h * nl + JHexEditor.this.border * 2 + 1);
      return d;
    }
    
    public void paint(Graphics g) {
      Dimension d = getMinimumSize();
      g.setColor(Color.white);
      g.fillRect(0, 0, d.width, d.height);
      g.setColor(Color.black);
      g.setFont(JHexEditor.font);
      for (int n = 0; n < 16; n++) {
        if (n == JHexEditor.this.cursor % 16)
          JHexEditor.this.cuadro(g, n * 3, 0, 2); 
        String s = "00" + Integer.toHexString(n);
        s = s.substring(s.length() - 2);
        JHexEditor.this.printString(g, s, n * 3, 0);
      } 
    }
  }
  
  private class Caja extends JPanel {
    private Caja() {}
    
    public Dimension getPreferredSize() {
      return getMinimumSize();
    }
    
    public Dimension getMinimumSize() {
      Dimension d = new Dimension();
      FontMetrics fn = getFontMetrics(JHexEditor.font);
      int h = fn.getHeight();
      d.setSize(fn.stringWidth(" ") + 1 + JHexEditor.this.border * 2 + 1, h + JHexEditor.this.border * 2 + 1);
      return d;
    }
  }
  
  private class Filas extends JPanel {
    public Filas() {
      setLayout(new BorderLayout(1, 1));
    }
    
    public Dimension getPreferredSize() {
      return getMinimumSize();
    }
    
    public Dimension getMinimumSize() {
      Dimension d = new Dimension();
      FontMetrics fn = getFontMetrics(JHexEditor.font);
      int h = fn.getHeight();
      int nl = JHexEditor.this.getLineas();
      d.setSize((fn.stringWidth(" ") + 1) * 8 + JHexEditor.this.border * 2 + 1, h * nl + JHexEditor.this.border * 2 + 1);
      return d;
    }
    
    public void paint(Graphics g) {
      Dimension d = getMinimumSize();
      g.setColor(Color.white);
      g.fillRect(0, 0, d.width, d.height);
      g.setColor(Color.black);
      g.setFont(JHexEditor.font);
      int ini = JHexEditor.this.getInicio();
      int fin = ini + JHexEditor.this.getLineas();
      int y = 0;
      for (int n = ini; n < fin; n++) {
        if (n == JHexEditor.this.cursor / 16)
          JHexEditor.this.cuadro(g, 0, y, 8); 
        String s = "0000000000000" + Integer.toHexString(n);
        s = s.substring(s.length() - 8);
        JHexEditor.this.printString(g, s, 0, y++);
      } 
    }
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\dskutil\JHexEditor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */