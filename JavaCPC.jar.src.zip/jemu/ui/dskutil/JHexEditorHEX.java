package jemu.ui.dskutil;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JComponent;

public class JHexEditorHEX extends JComponent implements MouseListener, KeyListener {
  private JHexEditor he;
  
  private int cursor = 0;
  
  public JHexEditorHEX(JHexEditor he) {
    this.he = he;
    addMouseListener(this);
    addKeyListener(this);
    addFocusListener(he);
  }
  
  public Dimension getPreferredSize() {
    debug("getPreferredSize()");
    return getMinimumSize();
  }
  
  public Dimension getMaximumSize() {
    debug("getMaximumSize()");
    return getMinimumSize();
  }
  
  public Dimension getMinimumSize() {
    debug("getMinimumSize()");
    Dimension d = new Dimension();
    FontMetrics fn = getFontMetrics(JHexEditor.font);
    int h = fn.getHeight();
    int nl = this.he.getLineas();
    d.setSize((fn.stringWidth(" ") + 1) * 47 + this.he.border * 2 + 1, h * nl + this.he.border * 2 + 1);
    return d;
  }
  
  public void paint(Graphics g) {
    debug("paint(" + g + ")");
    debug("cursor=" + this.he.cursor + " buff.length=" + this.he.buff.length);
    Dimension d = getMinimumSize();
    g.setColor(Color.white);
    g.fillRect(0, 0, d.width, d.height);
    g.setColor(Color.black);
    g.setFont(JHexEditor.font);
    int ini = this.he.getInicio() * 16;
    int fin = ini + this.he.getLineas() * 16;
    if (fin > this.he.buff.length)
      fin = this.he.buff.length; 
    int x = 0;
    int y = 0;
    for (int n = ini; n < fin; n++) {
      if (n == this.he.cursor) {
        if (hasFocus()) {
          g.setColor(Color.black);
          this.he.fondo(g, x * 3, y, 2);
          g.setColor(Color.blue);
          this.he.fondo(g, x * 3 + this.cursor, y, 1);
        } else {
          g.setColor(Color.blue);
          this.he.cuadro(g, x * 3, y, 2);
        } 
        if (hasFocus()) {
          g.setColor(Color.white);
        } else {
          g.setColor(Color.black);
        } 
      } else {
        g.setColor(Color.black);
      } 
      String s = "0" + Integer.toHexString(this.he.buff[n]);
      s = s.substring(s.length() - 2);
      this.he.printString(g, s, x++ * 3, y);
      if (x == 16) {
        x = 0;
        y++;
      } 
    } 
  }
  
  private void debug(String s) {
    if (this.he.DEBUG)
      System.out.println("JHexEditorHEX ==> " + s); 
  }
  
  public int calcularPosicionRaton(int x, int y) {
    FontMetrics fn = getFontMetrics(JHexEditor.font);
    x /= (fn.stringWidth(" ") + 1) * 3;
    y /= fn.getHeight();
    debug("x=" + x + " ,y=" + y);
    return x + (y + this.he.getInicio()) * 16;
  }
  
  public void mouseClicked(MouseEvent e) {
    debug("mouseClicked(" + e + ")");
    this.he.cursor = calcularPosicionRaton(e.getX(), e.getY());
    requestFocus();
    this.he.repaint();
  }
  
  public void mousePressed(MouseEvent e) {}
  
  public void mouseReleased(MouseEvent e) {}
  
  public void mouseEntered(MouseEvent e) {}
  
  public void mouseExited(MouseEvent e) {}
  
  public void keyTyped(KeyEvent e) {
    debug("keyTyped(" + e + ")");
    char c = e.getKeyChar();
    if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f')) {
      char[] str = new char[2];
      String n = "00" + Integer.toHexString(this.he.buff[this.he.cursor]);
      if (n.length() > 2)
        n = n.substring(n.length() - 2); 
      str[1 - this.cursor] = n.charAt(1 - this.cursor);
      str[this.cursor] = e.getKeyChar();
      this.he.buff[this.he.cursor] = (byte)Integer.parseInt(new String(str), 16);
      if (this.cursor != 1) {
        this.cursor = 1;
      } else if (this.he.cursor != this.he.buff.length - 1) {
        this.he.cursor++;
        this.cursor = 0;
      } 
      this.he.actualizaCursor();
    } 
  }
  
  public void keyPressed(KeyEvent e) {
    debug("keyPressed(" + e + ")");
    this.he.keyPressed(e);
  }
  
  public void keyReleased(KeyEvent e) {
    debug("keyReleased(" + e + ")");
  }
  
  public boolean isFocusTraversable() {
    return true;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\dskutil\JHexEditorHEX.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */