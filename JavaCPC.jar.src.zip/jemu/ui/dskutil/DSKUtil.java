package jemu.ui.dskutil;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Frame;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JToggleButton;
import javax.swing.LayoutStyle;
import jemu.core.Util;
import jemu.core.device.Device;
import jemu.settings.Settings;
import jemu.system.cpc.CPC;

public final class DSKUtil extends JFrame implements KeyListener {
  protected String[] DSKImages;
  
  protected String selected;
  
  protected int index;
  
  public int seldrive;
  
  protected final String[] drive = new String[] { 
      "a:", "b:", "c:", "d:", "e:", "f:", "g:", "h:", "i:", "j:", 
      "k:", "l:", "m:", "n:", "o:", "p:", "q:", "r:", "s:", "t:", 
      "u:", "v:", "w:", "x:", "y:", "z:" };
  
  protected final String[] track = new String[] { "", " -c40", " -c43", " -c80" };
  
  protected final String[] heads = new String[] { "", "-h0", "-h1" };
  
  int prog = 0;
  
  protected boolean DEBUG = false;
  
  private ArrayList<DropTarget> dropTargetList;
  
  protected String name0;
  
  protected String name1;
  
  protected String name2;
  
  protected String name3;
  
  protected String actualdsk;
  
  protected String[] names = new String[100];
  
  protected String[] sizes = new String[100];
  
  protected String[] users = new String[100];
  
  protected String[] ronly = new String[100];
  
  protected String[] prot = new String[100];
  
  protected int[] direntries = new int[100];
  
  protected String folder = null;
  
  protected byte[] dumpdisk;
  
  protected byte[] redumpdisk;
  
  protected JHexEditor edit;
  
  protected int[] DSKSizes;
  
  protected String temp0;
  
  protected String temp1;
  
  protected String t0;
  
  protected String t1;
  
  int drives;
  
  String free;
  
  int freesize;
  
  Object[] items;
  
  Object[] sizel;
  
  Object[] userl;
  
  Object[] rdonly;
  
  Object[] hidden;
  
  String manualdisk;
  
  Process process;
  
  protected int[] selectedFiles;
  
  final JFileChooser fc;
  
  String com;
  
  boolean success;
  
  Thread successor;
  
  Process checker;
  
  JButton infclose;
  
  JFrame inf;
  
  InfoPanel pan;
  
  protected static final String HEX_CHARS = "0123456789ABCDEF";
  
  private JCheckBox also;
  
  private JCheckBox ascii;
  
  private JCheckBox bboth;
  
  private JCheckBox bfdi;
  
  private JCheckBox bhead0;
  
  private JCheckBox bhead1;
  
  private JCheckBox brescan;
  
  private JButton bstart;
  
  private JCheckBox bstep;
  
  private JButton bstop;
  
  private ButtonGroup buttonGroup1;
  
  private ButtonGroup buttonGroup2;
  
  private ButtonGroup buttonGroup3;
  
  private ButtonGroup buttonGroup4;
  
  private JComboBox cdrive;
  
  private JList console;
  
  private JList console1;
  
  private JComboBox ctracks;
  
  public JPanel disktools;
  
  private JPanel dropper;
  
  private JLabel dsk;
  
  private JLabel flop;
  
  private JCheckBox gaps;
  
  private JPanel hex;
  
  private JButton jButton1;
  
  private JButton jButton2;
  
  private JButton jButton3;
  
  private JButton jButton4;
  
  private JButton jButton5;
  
  private JButton jButton6;
  
  private JLabel jLabel1;
  
  private JLabel jLabel3;
  
  private JLabel jLabel4;
  
  private JLabel jLabel5;
  
  private JMenuItem jMenuItem1;
  
  private JMenuItem jMenuItem2;
  
  private JMenuItem jMenuItem3;
  
  private JMenuItem jMenuItem4;
  
  private JMenuItem jMenuItem5;
  
  private JPanel jPanel1;
  
  private JPanel jPanel10;
  
  private JPanel jPanel11;
  
  private JPanel jPanel2;
  
  private JPanel jPanel3;
  
  private JPanel jPanel4;
  
  private JPanel jPanel5;
  
  private JPanel jPanel6;
  
  private JPanel jPanel7;
  
  private JPanel jPanel8;
  
  private JPanel jPanel9;
  
  private JPopupMenu jPopupMenu1;
  
  private JRadioButton jRadioButton1;
  
  private JRadioButton jRadioButton10;
  
  private JRadioButton jRadioButton11;
  
  private JRadioButton jRadioButton12;
  
  private JRadioButton jRadioButton13;
  
  private JRadioButton jRadioButton14;
  
  private JRadioButton jRadioButton15;
  
  private JRadioButton jRadioButton16;
  
  private JRadioButton jRadioButton17;
  
  private JRadioButton jRadioButton18;
  
  private JRadioButton jRadioButton19;
  
  private JRadioButton jRadioButton2;
  
  private JRadioButton jRadioButton20;
  
  private JRadioButton jRadioButton21;
  
  private JRadioButton jRadioButton22;
  
  private JRadioButton jRadioButton23;
  
  private JRadioButton jRadioButton3;
  
  private JRadioButton jRadioButton4;
  
  private JRadioButton jRadioButton5;
  
  private JRadioButton jRadioButton6;
  
  private JRadioButton jRadioButton7;
  
  private JRadioButton jRadioButton8;
  
  private JRadioButton jRadioButton9;
  
  private JScrollPane jScrollPane1;
  
  private JScrollPane jScrollPane2;
  
  private JScrollPane jScrollPane3;
  
  private JScrollPane jScrollPane4;
  
  private JScrollPane jScrollPane5;
  
  private JScrollPane jScrollPane6;
  
  private JScrollPane jScrollPane7;
  
  private JSeparator jSeparator1;
  
  private JSeparator jSeparator2;
  
  private JTabbedPane jTabbedPane1;
  
  private JToggleButton jToggleButton1;
  
  private JToggleButton jToggleButton2;
  
  private JToggleButton jToggleButton3;
  
  private JToggleButton jToggleButton4;
  
  private JButton load;
  
  private JTextArea output;
  
  private JTextArea output1;
  
  private JProgressBar progress;
  
  private JList protec;
  
  private JButton seldsk;
  
  private JLabel selform;
  
  private JList sizelist;
  
  private JLabel space;
  
  private JList system;
  
  private JTextArea text;
  
  private JCheckBox txtinfo;
  
  private JComboBox user;
  
  private JList userlist;
  
  public void formatDisk(int format) {
    String discimage = this.DSKImages[format];
    int discsize = this.DSKSizes[format];
    byte[] bufferdsk = copyResource("file/" + discimage, discsize);
    System.out.println("Formatting image in drive DF" + this.drives);
    System.out.println(this.actualdsk);
    if (this.actualdsk != null && this.actualdsk.length() > 0 && !this.actualdsk.equals("empty")) {
      String writeAs = this.actualdsk;
      int ok = JOptionPane.showConfirmDialog(new Frame(), "Are you sure to format your DSK\n\"" + writeAs + "\"?\nAll data will be erased!", "Confirm format", 0);
      if (ok == 0)
        try {
          BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(writeAs));
          bos.write(bufferdsk);
          bos.close();
          Settings.set("file.drive" + Integer.toString(this.drives), writeAs);
          DIR(this.drives);
          if (this.also.isSelected() && this.also.isVisible()) {
            this.jTabbedPane1.setSelectedIndex(2);
            this.jToggleButton4.setSelected(true);
            if (this.process == null) {
              Thread runner = new Thread() {
                  public void run() {
                    try {
                      DSKUtil.this.Launch(DSKUtil.this.jToggleButton3.isSelected());
                    } catch (Exception e) {
                      e.printStackTrace();
                    } 
                  }
                };
              runner.start();
            } 
          } 
        } catch (Exception exception) {} 
    } else {
      try {
        FileDialog filedia = new FileDialog(new Frame(), "Create DSK file", 1);
        filedia.setFile("*.dsk");
        filedia.setVisible(true);
        String filename = filedia.getFile();
        if (filename != null) {
          if (!filename.toLowerCase().endsWith(".dsk"))
            filename = filename + ".dsk"; 
          BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filename));
          bos.write(bufferdsk);
          bos.close();
          Settings.set("file.drive" + Integer.toString(this.drives), filename);
          DIR(this.drives);
          if (this.also.isSelected() && this.also.isVisible()) {
            this.jTabbedPane1.setSelectedIndex(2);
            this.jToggleButton4.setSelected(true);
          } 
        } 
      } catch (Exception exception) {}
    } 
  }
  
  public void keyPressed(KeyEvent e) {
    if (e.getKeyCode() == 127)
      Delete(); 
  }
  
  public byte[] copyResource(String name, int size) {
    byte[] buffer = new byte[size];
    int offs = 0;
    try {
      InputStream stream = null;
      try {
        InputStream is = getClass().getResourceAsStream(name);
        stream = is;
        while (size > 0) {
          int read = stream.read(buffer, offs, size);
          if (read == -1)
            break; 
          offs += read;
          size -= read;
        } 
      } finally {
        if (stream != null)
          stream.close(); 
      } 
    } catch (Exception e) {
      System.err.println("File not found...");
    } 
    return buffer;
  }
  
  public DSKUtil() {
    this.temp0 = "empty";
    this.temp1 = "empty";
    this.t0 = System.getProperty("user.home") + "\\javacpc\\temp0.dsk";
    this.t1 = System.getProperty("user.home") + "\\javacpc\\temp1.dsk";
    this.drives = 0;
    this.manualdisk = "empty";
    this.fc = new JFileChooser();
    this.com = "";
    this.success = false;
    this.index = 9;
    this.DSKImages = new String[] { 
        "parados80.dsk", "parados41.dsk", "parados40D.dsk", "romdosD1.dsk", "romdosD2.dsk", "romdosD10.dsk", "romdosD20.dsk", "romdosD40.dsk", "s-dos(romdosD80).dsk", "dataSS40.dsk", 
        "dataDS40.dsk", "dataSS80.dsk", "dataDS80.dsk", "systemSS40.dsk", "systemDS40.dsk", "systemSS80.dsk", "systemDS80.dsk", "ibmSS40.dsk", "ibmDS40.dsk", "ibmSS80.dsk", 
        "ibmDS80.dsk", "ultraform.dsk", "vortex704k.dsk" };
    this.DSKSizes = new int[] { 
        430336, 220672, 430336, 778496, 778496, 860416, 860416, 860416, 860416, 194816, 
        389376, 389376, 778496, 194816, 389376, 389376, 778496, 174336, 348416, 348416, 
        696576, 220672, 778496 };
    this.selected = "Selected Format: ";
    initComponents();
    this.dsk.setVisible(this.DEBUG);
    this.text.setText("DiskUtil 1.2 (July 04 2010), by Markus Hohmann -- http://cpc-live.com/\r\n");
    this.text.append("SAMdisk 3.4 (Aug 14 2012), (c) 2012 Simon Owen -- http://simonowen.com/samdisk/\r\n");
    this.text.select(2000000, 2000000);
    this.dumpdisk = new byte[1];
    this.edit = new JHexEditor(this.dumpdisk);
    this.hex.add(this.edit);
    writeDef();
    setNames();
    if (!this.name0.equals("empty") && this.name0.length() > 3) {
      this.jToggleButton2.setSelected(true);
      this.drives = 0;
      preDIR(0);
    } else if (!this.name1.equals("empty") && this.name1.length() > 3) {
      this.jToggleButton1.setSelected(true);
      this.drives = 1;
      preDIR(1);
    } 
    this.console.addKeyListener(this);
    this.userlist.addKeyListener(this);
    this.sizelist.addKeyListener(this);
    this.system.addKeyListener(this);
    this.protec.addKeyListener(this);
    this.output.addKeyListener(this);
    addKeyListener(this);
    this.folder = Settings.get("dsktool_path", "");
    this.dropTargetList = new ArrayList<>();
    DropListener myListener = new DropListener();
    registerDropListener(this.dropTargetList, this.console, myListener);
    registerDropListener(this.dropTargetList, this.userlist, myListener);
    registerDropListener(this.dropTargetList, this.sizelist, myListener);
    registerDropListener(this.dropTargetList, this.output, myListener);
    registerDropListener(this.dropTargetList, this.system, myListener);
    registerDropListener(this.dropTargetList, this.protec, myListener);
    registerDropListener(this.dropTargetList, this, myListener);
  }
  
  public void Launch(boolean direction) throws InterruptedException, IOException {
    String file = this.actualdsk;
    if (file == null || file.length() < 1 || file.equals("empty"))
      return; 
    this.text.setText("DiskUtil 1.2 (July 04 2010), by Markus Hohmann -- http://cpc-live.com/\r\n");
    this.text.append("SAMdisk 3.4 (Aug 14 2012), (c) 2012 Simon Owen -- http://simonowen.com/samdisk/\r\n");
    String ending = "";
    if (this.bfdi.isSelected() || this.bhead0.isSelected())
      ending = "-h0"; 
    if (this.bhead1.isSelected())
      ending = "-h1"; 
    String drv = this.drive[this.cdrive.getSelectedIndex()];
    String command = "";
    if (this.gaps.isSelected())
      ending = ending + " --gaps"; 
    if (direction) {
      command = drv + " \"" + file + "\" " + ending;
    } else {
      command = "\"" + file + "\" " + drv + " " + ending;
    } 
    command = command + this.track[this.ctracks.getSelectedIndex()];
    if (this.bstep.isSelected())
      command = command + " -d"; 
    if (this.brescan.isSelected())
      command = command + " -R"; 
    this.process = Runtime.getRuntime().exec(System.getProperty("user.home") + "/JavaCPC/tools/SamDisk.exe " + command);
    this.text.append("SamDisk.exe " + command + "\r\n");
    this.text.select(20000000, 20000000);
    InputStream is = this.process.getInputStream();
    InputStreamReader isr = new InputStreamReader(is);
    BufferedReader br = new BufferedReader(isr);
    this.bstart.setEnabled(false);
    this.bstop.setEnabled(true);
    this.progress.setIndeterminate(true);
    this.jTabbedPane1.setEnabled(false);
    this.jToggleButton1.setEnabled(false);
    this.jToggleButton2.setEnabled(false);
    this.load.setEnabled(false);
    this.jButton1.setEnabled(false);
    this.seldsk.setEnabled(false);
    String line;
    while ((line = br.readLine()) != null) {
      this.text.append(line + "\r\n");
      this.text.select(20000000, 20000000);
    } 
    br.close();
    this.text.append("Done...\r\n");
    this.jTabbedPane1.setSelectedIndex(0);
    this.text.select(20000000, 20000000);
    this.progress.setIndeterminate(false);
    this.bstart.setEnabled(true);
    this.bstop.setEnabled(false);
    this.jTabbedPane1.setEnabled(true);
    this.jToggleButton1.setEnabled(true);
    this.jToggleButton2.setEnabled(true);
    this.load.setEnabled(true);
    this.jButton1.setEnabled(true);
    this.seldsk.setEnabled(true);
    this.prog = 0;
    this.process = null;
    DIR(this.drives);
  }
  
  protected String BufferDisk() {
    if (this.drives == 0) {
      this.temp0 = Settings.get("file.drive" + Integer.toString(0), "empty");
      if (this.temp0.contains(" ")) {
        try {
          BufferedInputStream stream = new BufferedInputStream(new FileInputStream(this.temp0));
          byte[] t = new byte[stream.available()];
          stream.read(t);
          stream.close();
          BufferedOutputStream streamo = new BufferedOutputStream(new FileOutputStream(new File(this.t0)));
          streamo.write(t);
          streamo.close();
        } catch (IOException re) {
          re.printStackTrace();
        } 
        return this.t0;
      } 
      return this.temp0;
    } 
    if (this.drives == 1) {
      this.temp1 = Settings.get("file.drive" + Integer.toString(1), "empty");
      if (this.temp1.contains(" ")) {
        try {
          BufferedInputStream stream = new BufferedInputStream(new FileInputStream(this.temp1));
          byte[] t = new byte[stream.available()];
          stream.read(t);
          stream.close();
          BufferedOutputStream streamo = new BufferedOutputStream(new FileOutputStream(new File(this.t1)));
          streamo.write(t);
        } catch (IOException re) {
          re.printStackTrace();
        } 
        return this.t1;
      } 
      return this.temp1;
    } 
    return "empty";
  }
  
  protected String eraseTemp() {
    if (this.drives == 0) {
      File file = new File(this.t0);
      try {
        BufferedInputStream stream = new BufferedInputStream(new FileInputStream(file));
        byte[] t = new byte[stream.available()];
        stream.read(t);
        stream.close();
        BufferedOutputStream streamo = new BufferedOutputStream(new FileOutputStream(new File(this.temp0)));
        streamo.write(t);
        streamo.close();
        file.delete();
      } catch (Exception exception) {}
      return this.temp0;
    } 
    if (this.drives == 1) {
      File file = new File(this.t1);
      try {
        BufferedInputStream stream = new BufferedInputStream(new FileInputStream(file));
        byte[] t = new byte[stream.available()];
        stream.read(t);
        stream.close();
        BufferedOutputStream streamo = new BufferedOutputStream(new FileOutputStream(new File(this.temp1)));
        streamo.write(t);
        streamo.close();
        file.delete();
      } catch (Exception exception) {}
      return this.temp1;
    } 
    return "empty";
  }
  
  public void writeDef() {
    try {
      File file = new File("cpmdisks.def");
      if (file.exists())
        return; 
      System.out.println("writing def file");
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
      bos.write(copyResource("cpmdisks.def", 15180));
      bos.close();
    } catch (Exception exception) {}
  }
  
  public void keyReleased(KeyEvent e) {}
  
  public void keyTyped(KeyEvent e) {}
  
  private static void registerDropListener(ArrayList<DropTarget> list, Container basePanel, DropListener myListener) {
    list.add(new DropTarget(basePanel, myListener));
    Component[] components = basePanel.getComponents();
    for (int i = 0; i < components.length; i++) {
      Component component = components[i];
      if (component instanceof Container) {
        registerDropListener(list, (Container)component, myListener);
      } else {
        list.add(new DropTarget(component, myListener));
      } 
    } 
  }
  
  private class DropListener extends DropTargetAdapter {
    private DropListener() {}
    
    public void drop(DropTargetDropEvent droptarget) {
      try {
        Transferable t = droptarget.getTransferable();
        if (t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
          droptarget.acceptDrop(3);
          Object userObject = t.getTransferData(DataFlavor.javaFileListFlavor);
          if (userObject instanceof List) {
            int count = 0;
            String[] names = new String[1000];
            for (int i = 0; i < names.length; i++) {
              try {
                names[i] = ((List<E>)userObject).get(i).toString();
                if (names[i].toLowerCase().endsWith(".dsk")) {
                  DSKUtil.this.loadDSK(names[i]);
                  return;
                } 
                count++;
              } catch (Exception e) {
                break;
              } 
            } 
            String[] get = new String[count];
            int j;
            for (j = 0; j < count; j++)
              get[j] = names[j]; 
            DSKUtil.this.com = "";
            for (j = 0; j < count; j++)
              DSKUtil.this.writeToDsk(get[j]); 
          } 
          droptarget.dropComplete(true);
        } 
      } catch (Exception exception) {}
    }
  }
  
  public void loadDSK(String name) {
    Settings.set("file.drive" + Integer.toString(this.drives), name);
    DIR(this.drives);
  }
  
  public void eject(int drive) {
    Settings.set("file.drive" + Integer.toString(drive), "empty");
    DIR(drive);
  }
  
  public void setNames() {
    this.name0 = Settings.get("file.drive" + Integer.toString(0), "empty");
    this.name1 = Settings.get("file.drive" + Integer.toString(1), "empty");
  }
  
  public void clear() {
    this.items = new Object[1];
    this.sizel = new Object[1];
    this.userl = new Object[1];
    this.rdonly = new Object[1];
    this.hidden = new Object[1];
    this.console.setListData(this.items);
    this.sizelist.setListData(this.sizel);
    this.userlist.setListData(this.userl);
    this.protec.setListData(this.rdonly);
    this.system.setListData(this.hidden);
  }
  
  public void DIR(int drive) {
    this.output.setText("DIR:");
    this.drives = drive;
    this.actualdsk = Settings.get("file.drive" + Integer.toString(this.drives), "empty");
    if (this.actualdsk.equals("empty") || this.actualdsk.length() < 3) {
      this.output.setText("DIR: No Disk!\r\n");
      this.space.setText("Drive is empty");
      this.output.select(200000, 200000);
      clear();
      return;
    } 
    String path = this.actualdsk;
    this.space.setText("Drive is empty or unknown format");
    this.actualdsk = BufferDisk();
    try {
      File dump = new File(this.actualdsk);
      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(dump));
      this.dumpdisk = new byte[bis.available()];
      bis.read(this.dumpdisk);
      bis.close();
      this.redumpdisk = new byte[this.dumpdisk.length];
      for (int i = 0; i < this.redumpdisk.length; i++)
        this.redumpdisk[i] = this.dumpdisk[i]; 
    } catch (Exception exception) {}
    this.hex.remove(this.edit);
    String h = Settings.get("file.drive" + Integer.toString(this.drives), "empty");
    if (!h.startsWith("empty")) {
      this.edit = new JHexEditor(this.dumpdisk);
    } else {
      this.edit = new JHexEditor(new byte[1]);
    } 
    this.hex.add(this.edit);
    this.output.append(" " + this.actualdsk + "\r\n");
    System.out.println("Reading " + this.actualdsk);
    try {
      String dir = Launch(System.getProperty("user.home") + "/JavaCPC/tools/cpcxfs.exe " + this.actualdsk);
      String[] entries = dir.split("\r");
      this.names = new String[400];
      this.sizes = new String[400];
      this.users = new String[400];
      this.ronly = new String[400];
      this.prot = new String[400];
      this.direntries = new int[400];
      int pos = 0;
      this.free = "";
      int begin = 0;
      int i;
      for (i = 0; i < entries.length; i++) {
        System.out.println(entries[i]);
        if (entries[i].startsWith("-"))
          begin = i + 1; 
        if (entries[i].startsWith("(") && entries[i].contains("Bytes free")) {
          String r = entries[i];
          entries[i] = entries[i].substring(1);
          while (!entries[i].startsWith(" ")) {
            this.free += entries[i].charAt(0);
            entries[i] = entries[i].substring(1);
          } 
          String inf = path;
          while (inf.contains("\\"))
            inf = inf.substring(1); 
          while (inf.contains("/"))
            inf = inf.substring(1); 
          this.space.setText(this.free + " bytes in " + inf);
          this.freesize = Integer.parseInt(this.free);
          entries[i] = r;
          break;
        } 
      } 
      for (i = begin; i < entries.length; i++) {
        if (entries[i].startsWith(" ")) {
          entries[i] = entries[i].substring(1);
          this.users[pos] = "Usr ";
          while (!entries[i].startsWith(" ")) {
            this.users[pos] = this.users[pos] + entries[i].charAt(0);
            entries[i] = entries[i].substring(1);
          } 
          entries[i] = entries[i].substring(1);
          String syscheck = entries[i];
          if (syscheck.length() > 50)
            syscheck = syscheck.substring(0, syscheck.length() / 2); 
          if (syscheck.contains("R/O")) {
            this.ronly[pos] = "R/O";
          } else {
            this.ronly[pos] = " ";
          } 
          if (syscheck.contains(" + ")) {
            this.prot[pos] = "SYS";
          } else {
            this.prot[pos] = " ";
          } 
          String entr = "";
          String entri = "";
          try {
            entr = entries[i].substring(29);
            entri = "";
            for (int k = 0; k < 6; k++)
              entri = entri + entr.charAt(k); 
            entri = entri.replace(" ", "");
            entri = entri.replace("+", "");
            this.direntries[pos] = Integer.parseInt(entri);
          } catch (Exception exception) {}
          this.names[pos] = "";
          this.sizes[pos] = "";
          int p;
          for (p = 0; p < 12; p++)
            this.names[pos] = this.names[pos] + "" + entries[i].charAt(p); 
          entries[i] = entries[i].substring(13);
          for (p = 0; p < 7; p++) {
            if (entries[i].charAt(p) != ' ')
              this.sizes[pos] = this.sizes[pos] + "" + entries[i].charAt(p); 
          } 
          pos++;
          this.names[pos] = "";
          this.sizes[pos] = "";
          try {
            entries[i] = entries[i].substring(25);
            this.users[pos] = "Usr ";
            while (!entries[i].startsWith(" ")) {
              this.users[pos] = this.users[pos] + entries[i].charAt(0);
              entries[i] = entries[i].substring(1);
            } 
            entries[i] = entries[i].substring(1);
            if (entries[i].contains("R/O")) {
              this.ronly[pos] = "R/O";
            } else {
              this.ronly[pos] = " ";
            } 
            if (entries[i].contains(" + ")) {
              this.prot[pos] = "SYS";
            } else {
              this.prot[pos] = " ";
            } 
            for (p = 0; p < 12; p++)
              this.names[pos] = this.names[pos] + "" + entries[i].charAt(p); 
            try {
              entri = entries[i].substring(26);
              entri = entri.replace(" ", "");
              entri = entri.replace("+", "");
              this.direntries[pos] = Integer.parseInt(entri);
            } catch (Exception exception) {}
            entries[i] = entries[i].substring(13);
            for (p = 0; p < 7; p++) {
              if (entries[i].charAt(p) != ' ')
                this.sizes[pos] = this.sizes[pos] + "" + entries[i].charAt(p); 
            } 
            pos++;
          } catch (Exception exception) {}
        } 
      } 
      int length = 0;
      int j;
      for (j = 0; j < this.names.length; j++) {
        if (this.names[j] != null) {
          this.names[j] = this.names[j].replace(".", "~");
          String[] rebuild = (new String(this.names[j])).split("~");
          if (rebuild.length > 1) {
            String a = rebuild[0];
            String b = rebuild[1];
            while (a.length() < 8)
              a = a + " "; 
            this.names[j] = a + "." + b;
          } 
          this.names[j] = this.names[j].replace("~", ".");
          if (this.names[j].length() > 1)
            length++; 
        } 
      } 
      this.items = new Object[length];
      this.sizel = new Object[length];
      this.userl = new Object[length];
      this.rdonly = new Object[length];
      this.hidden = new Object[length];
      for (j = 0; j < length; j++) {
        if (this.names[j] != null) {
          this.items[j] = this.names[j];
          while (this.sizes[j].length() < 9)
            this.sizes[j] = " " + this.sizes[j]; 
          this.sizel[j] = this.sizes[j];
          this.userl[j] = this.users[j];
          this.rdonly[j] = this.ronly[j];
          this.hidden[j] = this.prot[j];
        } 
      } 
      if (this.txtinfo.isSelected()) {
        String txtfile = Settings.get("file.drive" + Integer.toString(this.drives), "empty");
        String inf = txtfile + ":";
        txtfile = txtfile + ".txt";
        File txt = new File(txtfile);
        BufferedOutputStream outt = new BufferedOutputStream(new FileOutputStream(txt));
        outt.write("Directory of ".getBytes("UTF-8"));
        outt.write(inf.getBytes("UTF-8"));
        outt.write(new byte[] { 13, 10 });
        outt.write(new byte[] { 13, 10 });
        for (int k = 0; k < length; k++) {
          String name = this.names[k];
          while (name.endsWith(" "))
            name = name.substring(0, name.length() - 1); 
          while (name.length() < 12)
            name = name + " "; 
          String size = this.sizes[k].replace(" ", "");
          size = "" + (Integer.parseInt(size) - 128);
          while (size.length() < 8)
            size = " " + size; 
          String out = name + "  -" + size + " bytes  -  " + this.users[k];
          outt.write(out.getBytes("UTF-8"));
          outt.write(new byte[] { 13, 10 });
        } 
        outt.write(new byte[] { 13, 10 });
        String frees = "Bytes free: " + this.freesize;
        outt.write(frees.getBytes("UTF-8"));
        outt.close();
      } 
      this.console.setListData(this.items);
      this.sizelist.setListData(this.sizel);
      this.userlist.setListData(this.userl);
      this.protec.setListData(this.rdonly);
      this.system.setListData(this.hidden);
    } catch (Exception e) {
      if (this.actualdsk.contains(System.getProperty("user.home") + "\\javacpc\\temp"))
        this.actualdsk = eraseTemp(); 
      this.output.setText(this.actualdsk + ": Disk not directoryable / readable\r\n");
      clear();
      this.output.select(200000, 200000);
    } 
    if (this.actualdsk.contains(System.getProperty("user.home") + "\\javacpc\\temp"))
      this.actualdsk = eraseTemp(); 
    this.output.append("DSK EyeCatcher:" + getEyeCatcher() + "\r\n");
    this.output.select(200000, 200000);
    if (drive == 0)
      CPC.up0 = true; 
    if (drive == 1)
      CPC.up1 = true; 
  }
  
  public void preDIR(int drive) {
    this.output.setText("DIR:");
    this.drives = drive;
    this.actualdsk = Settings.get("file.drive" + Integer.toString(this.drives), "empty");
    if (this.actualdsk.equals("empty") || this.actualdsk.length() < 3) {
      this.output.setText("DIR: No Disk!\r\n");
      this.space.setText("Drive is empty");
      this.output.select(200000, 200000);
      clear();
      return;
    } 
    String path = this.actualdsk;
    this.space.setText("Drive is empty or unknown format");
    this.actualdsk = BufferDisk();
    try {
      File dump = new File(this.actualdsk);
      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(dump));
      this.dumpdisk = new byte[bis.available()];
      bis.read(this.dumpdisk);
      bis.close();
      this.redumpdisk = new byte[this.dumpdisk.length];
      for (int i = 0; i < this.redumpdisk.length; i++)
        this.redumpdisk[i] = this.dumpdisk[i]; 
    } catch (Exception exception) {}
    this.hex.remove(this.edit);
    String h = Settings.get("file.drive" + Integer.toString(this.drives), "empty");
    if (!h.startsWith("empty")) {
      this.edit = new JHexEditor(this.dumpdisk);
    } else {
      this.edit = new JHexEditor(new byte[1]);
    } 
    this.hex.add(this.edit);
    this.output.append(" " + this.actualdsk + "\r\n");
    System.out.println("Reading " + this.actualdsk);
    try {
      String dir = PreLaunch(System.getProperty("user.home") + "/JavaCPC/tools/cpcxfs.exe " + this.actualdsk);
      String[] entries = dir.split("\r");
      this.names = new String[400];
      this.sizes = new String[400];
      this.users = new String[400];
      this.ronly = new String[400];
      this.prot = new String[400];
      this.direntries = new int[400];
      int pos = 0;
      this.free = "";
      int begin = 0;
      int i;
      for (i = 0; i < entries.length; i++) {
        System.out.println(entries[i]);
        if (entries[i].startsWith("-"))
          begin = i + 1; 
        if (entries[i].startsWith("(") && entries[i].contains("Bytes free")) {
          String r = entries[i];
          entries[i] = entries[i].substring(1);
          while (!entries[i].startsWith(" ")) {
            this.free += entries[i].charAt(0);
            entries[i] = entries[i].substring(1);
          } 
          String inf = path;
          while (inf.contains("\\"))
            inf = inf.substring(1); 
          while (inf.contains("/"))
            inf = inf.substring(1); 
          this.space.setText(this.free + " bytes in " + inf);
          this.freesize = Integer.parseInt(this.free);
          entries[i] = r;
          break;
        } 
      } 
      for (i = begin; i < entries.length; i++) {
        if (entries[i].startsWith(" ")) {
          entries[i] = entries[i].substring(1);
          this.users[pos] = "Usr ";
          while (!entries[i].startsWith(" ")) {
            this.users[pos] = this.users[pos] + entries[i].charAt(0);
            entries[i] = entries[i].substring(1);
          } 
          entries[i] = entries[i].substring(1);
          String syscheck = entries[i];
          if (syscheck.length() > 50)
            syscheck = syscheck.substring(0, syscheck.length() / 2); 
          if (syscheck.contains("R/O")) {
            this.ronly[pos] = "R/O";
          } else {
            this.ronly[pos] = " ";
          } 
          if (syscheck.contains(" + ")) {
            this.prot[pos] = "SYS";
          } else {
            this.prot[pos] = " ";
          } 
          String entr = "";
          String entri = "";
          try {
            entr = entries[i].substring(29);
            entri = "";
            for (int k = 0; k < 6; k++)
              entri = entri + entr.charAt(k); 
            entri = entri.replace(" ", "");
            entri = entri.replace("+", "");
            this.direntries[pos] = Integer.parseInt(entri);
          } catch (Exception exception) {}
          this.names[pos] = "";
          this.sizes[pos] = "";
          int p;
          for (p = 0; p < 12; p++)
            this.names[pos] = this.names[pos] + "" + entries[i].charAt(p); 
          entries[i] = entries[i].substring(13);
          for (p = 0; p < 7; p++) {
            if (entries[i].charAt(p) != ' ')
              this.sizes[pos] = this.sizes[pos] + "" + entries[i].charAt(p); 
          } 
          pos++;
          this.names[pos] = "";
          this.sizes[pos] = "";
          try {
            entries[i] = entries[i].substring(25);
            this.users[pos] = "Usr ";
            while (!entries[i].startsWith(" ")) {
              this.users[pos] = this.users[pos] + entries[i].charAt(0);
              entries[i] = entries[i].substring(1);
            } 
            entries[i] = entries[i].substring(1);
            if (entries[i].contains("R/O")) {
              this.ronly[pos] = "R/O";
            } else {
              this.ronly[pos] = " ";
            } 
            if (entries[i].contains(" + ")) {
              this.prot[pos] = "SYS";
            } else {
              this.prot[pos] = " ";
            } 
            for (p = 0; p < 12; p++)
              this.names[pos] = this.names[pos] + "" + entries[i].charAt(p); 
            try {
              entri = entries[i].substring(26);
              entri = entri.replace(" ", "");
              entri = entri.replace("+", "");
              this.direntries[pos] = Integer.parseInt(entri);
            } catch (Exception exception) {}
            entries[i] = entries[i].substring(13);
            for (p = 0; p < 7; p++) {
              if (entries[i].charAt(p) != ' ')
                this.sizes[pos] = this.sizes[pos] + "" + entries[i].charAt(p); 
            } 
            pos++;
          } catch (Exception exception) {}
        } 
      } 
      int length = 0;
      int j;
      for (j = 0; j < this.names.length; j++) {
        if (this.names[j] != null) {
          this.names[j] = this.names[j].replace(".", "~");
          String[] rebuild = (new String(this.names[j])).split("~");
          if (rebuild.length > 1) {
            String a = rebuild[0];
            String b = rebuild[1];
            while (a.length() < 8)
              a = a + " "; 
            this.names[j] = a + "." + b;
          } 
          this.names[j] = this.names[j].replace("~", ".");
          if (this.names[j].length() > 1)
            length++; 
        } 
      } 
      this.items = new Object[length];
      this.sizel = new Object[length];
      this.userl = new Object[length];
      this.rdonly = new Object[length];
      this.hidden = new Object[length];
      for (j = 0; j < length; j++) {
        if (this.names[j] != null) {
          this.items[j] = this.names[j];
          while (this.sizes[j].length() < 9)
            this.sizes[j] = " " + this.sizes[j]; 
          this.sizel[j] = this.sizes[j];
          this.userl[j] = this.users[j];
          this.rdonly[j] = this.ronly[j];
          this.hidden[j] = this.prot[j];
        } 
      } 
      if (this.txtinfo.isSelected()) {
        String txtfile = Settings.get("file.drive" + Integer.toString(this.drives), "empty");
        String inf = txtfile + ":";
        txtfile = txtfile + ".txt";
        File txt = new File(txtfile);
        BufferedOutputStream outt = new BufferedOutputStream(new FileOutputStream(txt));
        outt.write("Directory of ".getBytes("UTF-8"));
        outt.write(inf.getBytes("UTF-8"));
        outt.write(new byte[] { 13, 10 });
        outt.write(new byte[] { 13, 10 });
        for (int k = 0; k < length; k++) {
          String name = this.names[k];
          while (name.endsWith(" "))
            name = name.substring(0, name.length() - 1); 
          while (name.length() < 12)
            name = name + " "; 
          String size = this.sizes[k].replace(" ", "");
          size = "" + (Integer.parseInt(size) - 128);
          while (size.length() < 8)
            size = " " + size; 
          String out = name + "  -" + size + " bytes  -  " + this.users[k];
          outt.write(out.getBytes("UTF-8"));
          outt.write(new byte[] { 13, 10 });
        } 
        outt.write(new byte[] { 13, 10 });
        String frees = "Bytes free: " + this.freesize;
        outt.write(frees.getBytes("UTF-8"));
        outt.close();
      } 
      this.console.setListData(this.items);
      this.sizelist.setListData(this.sizel);
      this.userlist.setListData(this.userl);
      this.protec.setListData(this.rdonly);
      this.system.setListData(this.hidden);
    } catch (Exception e) {
      if (this.actualdsk.contains(System.getProperty("user.home") + "\\javacpc\\temp"))
        this.actualdsk = eraseTemp(); 
      this.output.setText(this.actualdsk + ": Disk not directoryable / readable\r\n");
      clear();
      this.output.select(200000, 200000);
    } 
    if (this.actualdsk.contains(System.getProperty("user.home") + "\\javacpc\\temp"))
      this.actualdsk = eraseTemp(); 
    this.output.append("DSK EyeCatcher:" + getEyeCatcher() + "\r\n");
    this.output.select(200000, 200000);
    if (drive == 0)
      CPC.up0 = true; 
    if (drive == 1)
      CPC.up1 = true; 
  }
  
  protected void writeEyeCatcher() {
    try {
      String eyecatcher = "JAVACPC EXTDSK";
      int pos = 34;
      byte[] catcher = eyecatcher.getBytes("UTF-8");
      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(new File(this.actualdsk)));
      byte[] go = new byte[bis.available()];
      bis.read(go);
      bis.close();
      for (int i = 0; i < catcher.length; i++)
        go[i + pos] = catcher[i]; 
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File(this.actualdsk)));
      bos.write(go);
      bos.close();
    } catch (Exception exception) {}
  }
  
  protected String getEyeCatcher() {
    String eyecatcher = "";
    try {
      int pos = 34;
      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(new File(this.actualdsk)));
      byte[] go = new byte[bis.available()];
      bis.read(go);
      bis.close();
      for (int i = 0; i < 14; i++)
        eyecatcher = eyecatcher + (char)go[i + pos]; 
    } catch (Exception exception) {}
    return eyecatcher;
  }
  
  protected void checkDump() {
    if (this.redumpdisk == null)
      return; 
    for (int i = 0; i < this.redumpdisk.length; i++) {
      if (this.redumpdisk[i] != this.dumpdisk[i]) {
        overWriteDSK();
        break;
      } 
    } 
  }
  
  protected void overWriteDSK() {
    int n = JOptionPane.showConfirmDialog(this, "Your DSK has been changed. Do you want to save it?", "Confirm change", 0, 2);
    if (n != 0) {
      DIR(this.drives);
      return;
    } 
    try {
      this.actualdsk = BufferDisk();
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File(this.actualdsk)));
      bos.write(this.dumpdisk);
      bos.close();
      writeEyeCatcher();
      if (this.actualdsk.contains(System.getProperty("user.home") + "\\javacpc\\temp"))
        this.actualdsk = eraseTemp(); 
      DIR(this.drives);
    } catch (Exception exception) {}
  }
  
  public void setFolder() {
    this.fc.setCurrentDirectory(new File(Settings.get("dsktool_path", "")));
    this.fc.setFileHidingEnabled(true);
    this.fc.setFileSelectionMode(1);
    this.fc.setDialogType(0);
    int returnVal = this.fc.showSaveDialog(this);
    if (returnVal == 0) {
      File file = this.fc.getSelectedFile();
      Settings.set("dsktool_path", file.getPath() + "\\");
      this.folder = file.getPath();
    } else {
      this.folder = null;
    } 
  }
  
  public void loadDSK() {
    this.fc.setCurrentDirectory(new File(Settings.get("dsktool_path", "")));
    this.fc.setFileHidingEnabled(false);
    this.fc.setFileSelectionMode(2);
    this.fc.setDialogType(0);
    int returnVal = this.fc.showSaveDialog(this);
    if (returnVal == 0) {
      File file = this.fc.getSelectedFile();
      loadDSK(file.getPath());
      Settings.set("dsktool_path", file.getPath() + "\\");
      DIR(this.drives);
    } 
  }
  
  public void chooseDsk() {
    this.fc.setSelectedFile(new File(Settings.get("dsktool_path", "")));
    this.fc.setDialogType(0);
    this.manualdisk = "empty";
    this.fc.setFileSelectionMode(2);
    int returnVal = this.fc.showSaveDialog(this);
    if (returnVal == 0) {
      File file = this.fc.getSelectedFile();
      if (file != null) {
        this.manualdisk = file.getAbsolutePath();
      } else {
        this.manualdisk = "empty";
      } 
    } else {
      this.manualdisk = "empty";
    } 
    if (!this.manualdisk.equals("empty"))
      DIR(2); 
  }
  
  public void getFromDSK() {
    if (this.selectedFiles == null || this.folder == null)
      return; 
    String fold = this.folder;
    this.com = "";
    for (int i = 0; i < this.selectedFiles.length; i++) {
      this.folder = this.actualdsk;
      while (!this.folder.endsWith("\\"))
        this.folder = this.folder.substring(0, this.folder.length() - 1); 
      fold = this.folder;
      this.actualdsk = BufferDisk();
      try {
        String get = this.items[this.selectedFiles[i]].toString();
        String use = this.users[this.selectedFiles[i]].toString();
        get = get.replace(" ", "");
        this.folder += "\\" + get;
        String temp = this.folder;
        boolean erasetemp = false;
        if (this.folder.contains(" ")) {
          this.folder = System.getProperty("user.home") + "\\javacpc\\" + get;
          erasetemp = true;
        } 
        use = use.substring(4);
        String as = "-b";
        if (this.ascii.isSelected())
          as = "-t"; 
        this.folder = this.folder.replace("\\\\", "\\");
        String launch = System.getProperty("user.home") + "/JavaCPC/tools/cpcxfs.exe " + this.actualdsk + " -e user " + use + "; get " + as + " -f " + get + " " + this.folder;
        System.out.println(launch);
        this.com = Launch(launch) + "\r\n";
        this.com = this.com.replace("Label file \"rb\" not found!", "");
        this.com = this.com.replace("already exists! Overwrite? [y/N] _ [Forced]", "");
        this.output.append(this.com);
        this.output.select(200000, 200000);
        if (erasetemp) {
          File te = new File(System.getProperty("user.home") + "\\javacpc\\" + get);
          BufferedInputStream in = new BufferedInputStream(new FileInputStream(te));
          byte[] g = new byte[in.available()];
          in.read(g);
          in.close();
          te.delete();
          BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(new File(temp)));
          out.write(g);
          out.close();
        } 
        this.folder = fold;
      } catch (Exception exception) {}
      if (this.actualdsk.contains(System.getProperty("user.home") + "\\javacpc\\temp"))
        this.actualdsk = eraseTemp(); 
    } 
    this.folder = fold;
  }
  
  public void protect() {
    if (this.selectedFiles == null || this.folder == null)
      return; 
    this.actualdsk = BufferDisk();
    for (int i = 0; i < this.selectedFiles.length; i++) {
      try {
        String get = this.items[this.selectedFiles[i]].toString();
        String use = this.users[this.selectedFiles[i]].toString();
        String prt = this.ronly[this.selectedFiles[i]].toString();
        String sys = this.prot[this.selectedFiles[i]].toString();
        int entrienumber = this.direntries[this.selectedFiles[i]];
        use = use.substring(4);
        File in = new File(this.actualdsk);
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(in));
        byte[] tempdisk = new byte[bis.available()];
        bis.read(tempdisk);
        bis.close();
        get = get.replace(".", "");
        byte[] check = get.getBytes("UTF-8");
        byte[] replace = get.getBytes("UTF-8");
        if (prt.contains("R/O")) {
          check[8] = (byte)(check[8] | 0x80);
        } else {
          replace[8] = (byte)(replace[8] | 0x80);
        } 
        if (sys.contains("SYS")) {
          check[9] = (byte)(check[9] | 0x80);
          replace[9] = (byte)(replace[9] | 0x80);
        } 
        byte us = (byte)Integer.parseInt(use);
        int len = tempdisk.length;
        boolean cut = false;
        int checkentry = 0;
        for (int g = 0; g < len - 11; g++) {
          byte[] got = new byte[11];
          for (int k = 0; k < 11; k++)
            got[k] = tempdisk[k + g]; 
          if (got[0] == check[0] && got[1] == check[1] && got[2] == check[2] && got[3] == check[3] && got[4] == check[4] && got[5] == check[5] && got[6] == check[6] && got[7] == check[7] && got[8] == check[8] && got[9] == check[9] && got[10] == check[10]) {
            byte u = tempdisk[g - 1];
            if (u == us) {
              checkentry++;
              if (!cut)
                len = g + 255; 
              cut = true;
              for (int t = 0; t < 11; t++)
                tempdisk[g + t] = replace[t]; 
            } 
            if (checkentry >= entrienumber) {
              System.out.println("End of entries for " + this.actualdsk + ": " + entrienumber);
              break;
            } 
          } 
        } 
        File out = new File(this.actualdsk);
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(out));
        bos.write(tempdisk);
        bos.close();
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
    if (this.actualdsk.contains(System.getProperty("user.home") + "\\javacpc\\temp"))
      this.actualdsk = eraseTemp(); 
    DIR(this.drives);
    this.console.setSelectedIndices(this.selectedFiles);
    this.sizelist.setSelectedIndices(this.console.getSelectedIndices());
    this.userlist.setSelectedIndices(this.console.getSelectedIndices());
    this.system.setSelectedIndices(this.console.getSelectedIndices());
    this.protec.setSelectedIndices(this.console.getSelectedIndices());
  }
  
  public void hide() {
    if (this.selectedFiles == null || this.folder == null)
      return; 
    this.actualdsk = BufferDisk();
    for (int i = 0; i < this.selectedFiles.length; i++) {
      try {
        String get = this.items[this.selectedFiles[i]].toString();
        String use = this.users[this.selectedFiles[i]].toString();
        String prt = this.ronly[this.selectedFiles[i]].toString();
        String sys = this.prot[this.selectedFiles[i]].toString();
        int entrienumber = this.direntries[this.selectedFiles[i]];
        use = use.substring(4);
        File in = new File(this.actualdsk);
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(in));
        byte[] tempdisk = new byte[bis.available()];
        bis.read(tempdisk);
        bis.close();
        get = get.replace(".", "");
        byte[] check = get.getBytes("UTF-8");
        byte[] replace = get.getBytes("UTF-8");
        if (sys.contains("SYS")) {
          check[9] = (byte)(check[9] | 0x80);
        } else {
          replace[9] = (byte)(replace[9] | 0x80);
        } 
        if (prt.contains("R/O")) {
          check[8] = (byte)(check[8] | 0x80);
          replace[8] = (byte)(replace[8] | 0x80);
        } 
        byte us = (byte)Integer.parseInt(use);
        int checkentry = 0;
        for (int g = 0; g < tempdisk.length - 11; g++) {
          byte[] got = new byte[11];
          for (int k = 0; k < 11; k++)
            got[k] = tempdisk[k + g]; 
          if (got[0] == check[0] && got[1] == check[1] && got[2] == check[2] && got[3] == check[3] && got[4] == check[4] && got[5] == check[5] && got[6] == check[6] && got[7] == check[7] && got[8] == check[8] && got[9] == check[9] && got[10] == check[10]) {
            byte u = tempdisk[g - 1];
            if (u == us) {
              checkentry++;
              for (int t = 0; t < 11; t++)
                tempdisk[g + t] = replace[t]; 
            } 
            if (checkentry >= entrienumber) {
              System.out.println("End of entries for " + this.actualdsk + ": " + entrienumber);
              break;
            } 
          } 
        } 
        File out = new File(this.actualdsk);
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(out));
        bos.write(tempdisk);
        bos.close();
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
    if (this.actualdsk.contains(System.getProperty("user.home") + "\\javacpc\\temp"))
      this.actualdsk = eraseTemp(); 
    DIR(this.drives);
    this.console.setSelectedIndices(this.selectedFiles);
    this.sizelist.setSelectedIndices(this.console.getSelectedIndices());
    this.userlist.setSelectedIndices(this.console.getSelectedIndices());
    this.system.setSelectedIndices(this.console.getSelectedIndices());
    this.protec.setSelectedIndices(this.console.getSelectedIndices());
  }
  
  public void Delete() {
    if (this.selectedFiles == null || this.folder == null)
      return; 
    String info = "";
    for (int i = 0; i < this.selectedFiles.length; i++) {
      try {
        info = info + this.items[this.selectedFiles[i]].toString() + "\r\n";
      } catch (Exception e) {
        return;
      } 
    } 
    if (info.length() < 1)
      return; 
    int n = JOptionPane.showConfirmDialog(this, "Are you sure, you want to delete the following files?\r\n" + info, "Confirm deleting", 0, 2);
    if (n != 0)
      return; 
    this.actualdsk = BufferDisk();
    for (int j = 0; j < this.selectedFiles.length; j++) {
      try {
        String get = this.items[this.selectedFiles[j]].toString();
        String use = this.users[this.selectedFiles[j]].toString();
        use = use.substring(4);
        get = get.replace(" ", "");
        if (get.startsWith("-"))
          get = "\\" + get; 
        String launch = System.getProperty("user.home") + "/JavaCPC/tools/cpcxfs.exe " + this.actualdsk + " -e user " + use + "; era -f " + get;
        System.out.println(launch);
        this.output.append("Deleting file " + get);
        Launch(launch);
      } catch (Exception exception) {}
    } 
    if (this.actualdsk.contains(System.getProperty("user.home") + "\\javacpc\\temp"))
      this.actualdsk = eraseTemp(); 
    DIR(this.drives);
  }
  
  public void writeToDsk(String file) {
    File checkfile = new File(file);
    String dofile = file;
    if (this.output.getText().contains("DIR: empty")) {
      this.output.append("\r\nNo DSK loaded. Please load a DSK first...");
      return;
    } 
    boolean deletetemp = false;
    int hassize = 0;
    try {
      BufferedInputStream stream = new BufferedInputStream(new FileInputStream(checkfile));
      hassize = stream.available() - 128;
      if (hassize > this.freesize) {
        this.output.append("File is too large! Free: " + this.freesize + " File size:" + hassize + "\r\n");
        return;
      } 
      stream.close();
    } catch (IOException re) {
      re.printStackTrace();
    } 
    if (dofile.contains(" ")) {
      System.out.println(checkfile.getName());
      try {
        deletetemp = true;
        BufferedInputStream stream = new BufferedInputStream(new FileInputStream(checkfile));
        byte[] temp = new byte[stream.available()];
        stream.read(temp);
        stream.close();
        File tempfile = new File(System.getProperty("user.home") + "\\javacpc\\temp.tmp");
        BufferedOutputStream stream2 = new BufferedOutputStream(new FileOutputStream(tempfile));
        stream2.write(temp);
        stream2.close();
        dofile = System.getProperty("user.home") + "\\javacpc\\temp.tmp";
      } catch (IOException re) {
        re.printStackTrace();
      } 
    } 
    if (this.actualdsk == null)
      return; 
    this.actualdsk = BufferDisk();
    while (file.contains("\\"))
      file = file.substring(1); 
    String towrite = file;
    towrite = towrite.replace(" ", "");
    String before = "";
    String after = "";
    if (towrite.contains(".")) {
      towrite = towrite.replace(".", "~");
      String[] check = towrite.split("~");
      for (int i = 0; i < check.length; i++) {
        if (i == 0)
          before = check[i]; 
        if (i == 1)
          after = check[i]; 
      } 
      while (before.length() > 8)
        before = before.substring(0, before.length() - 1); 
      while (after.length() > 3)
        after = after.substring(0, after.length() - 1); 
      towrite = before + "." + after;
    } 
    try {
      String as = "-b";
      if (this.ascii.isSelected())
        as = "-t"; 
      String exec = System.getProperty("user.home") + "/JavaCPC/tools/cpcxfs.exe " + this.actualdsk + " -e user " + this.user.getSelectedIndex() + "; put " + as + " -f " + dofile + " " + towrite;
      System.out.println(exec);
      this.com += Launch(exec) + "\r\n";
      if (deletetemp) {
        File del = new File(System.getProperty("user.home") + "\\javacpc\\temp.tmp");
        del.delete();
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
    writeEyeCatcher();
    if (this.actualdsk.contains(System.getProperty("user.home") + "\\javacpc\\temp"))
      this.actualdsk = eraseTemp(); 
    DIR(this.drives);
    if (this.com != null && this.com.length() > 4) {
      this.com = this.com.replace("Label file \"rb\" not found!", "");
      this.com = this.com.replace("already exists! Overwrite? [y/N] _ [Forced]", "");
      this.output.append(this.com + "\r\n");
      if (this.ascii.isSelected()) {
        this.output.append("ASCII transferred");
      } else {
        this.output.append("BINARY transferred");
      } 
    } 
  }
  
  public String Launch(String command) throws InterruptedException, IOException {
    String result = "";
    this.process = Runtime.getRuntime().exec(command);
    InputStream is = this.process.getInputStream();
    InputStreamReader isr = new InputStreamReader(is);
    BufferedReader br = new BufferedReader(isr);
    BufferedReader br2 = new BufferedReader(isr);
    System.out.println("Executing external command: " + command);
    String line;
    while ((line = br.readLine()) != null) {
      if (!line.contains("Label file")) {
        result = result + line + "\r";
        this.output.append(line + "\r\n");
      } 
      String err;
      if ((err = br2.readLine()) != null)
        this.output.append(err + "\r\n"); 
    } 
    br.close();
    this.process = null;
    return result;
  }
  
  public String PreLaunch(String command) throws InterruptedException, IOException {
    if (this.process != null)
      return null; 
    int v = 0;
    this.success = false;
    checkLine(command);
    while (!this.success) {
      try {
        Thread.sleep(1L);
      } catch (Exception exception) {}
      v++;
      if (v > 3000) {
        this.checker.destroy();
        this.checker.waitFor();
        break;
      } 
    } 
    String ret = "";
    if (v > 3000)
      return null; 
    return Launch(command);
  }
  
  void checkLine(final String command) {
    this.successor = new Thread() {
        public void run() {
          try {
            DSKUtil.this.checker = Runtime.getRuntime().exec(command);
            InputStream is = DSKUtil.this.checker.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            InputStream is2 = DSKUtil.this.checker.getErrorStream();
            InputStreamReader isr2 = new InputStreamReader(is);
            BufferedReader br2 = new BufferedReader(isr);
            br.readLine();
            DSKUtil.this.success = true;
          } catch (Exception exception) {}
        }
      };
    this.successor.start();
  }
  
  private void initComponents() {
    this.buttonGroup1 = new ButtonGroup();
    this.buttonGroup2 = new ButtonGroup();
    this.buttonGroup3 = new ButtonGroup();
    this.buttonGroup4 = new ButtonGroup();
    this.jPopupMenu1 = new JPopupMenu();
    this.jMenuItem1 = new JMenuItem();
    this.jMenuItem2 = new JMenuItem();
    this.jMenuItem3 = new JMenuItem();
    this.jSeparator2 = new JSeparator();
    this.jMenuItem4 = new JMenuItem();
    this.jMenuItem5 = new JMenuItem();
    this.disktools = new JPanel();
    this.jLabel1 = new JLabel();
    this.space = new JLabel();
    this.seldsk = new JButton();
    this.user = new JComboBox();
    this.jLabel3 = new JLabel();
    this.jToggleButton1 = new JToggleButton();
    this.jToggleButton2 = new JToggleButton();
    this.jButton1 = new JButton();
    this.load = new JButton();
    this.jTabbedPane1 = new JTabbedPane();
    this.jPanel3 = new JPanel();
    this.dropper = new JPanel();
    this.jButton2 = new JButton();
    this.jButton5 = new JButton();
    this.jButton4 = new JButton();
    this.jPanel2 = new JPanel();
    this.jButton3 = new JButton();
    this.jPanel11 = new JPanel();
    this.jScrollPane4 = new JScrollPane();
    this.userlist = new JList();
    this.jScrollPane2 = new JScrollPane();
    this.sizelist = new JList();
    this.jScrollPane5 = new JScrollPane();
    this.system = new JList();
    this.jScrollPane1 = new JScrollPane();
    this.console = new JList();
    this.jScrollPane6 = new JScrollPane();
    this.protec = new JList();
    this.jScrollPane3 = new JScrollPane();
    this.output = new JTextArea();
    this.txtinfo = new JCheckBox();
    this.jPanel4 = new JPanel();
    this.hex = new JPanel();
    this.jPanel1 = new JPanel();
    this.jScrollPane7 = new JScrollPane();
    this.text = new JTextArea();
    this.jPanel6 = new JPanel();
    this.jToggleButton3 = new JToggleButton();
    this.jToggleButton4 = new JToggleButton();
    this.bstart = new JButton();
    this.jSeparator1 = new JSeparator();
    this.bstop = new JButton();
    this.progress = new JProgressBar();
    this.jPanel7 = new JPanel();
    this.jLabel4 = new JLabel();
    this.ctracks = new JComboBox();
    this.gaps = new JCheckBox();
    this.bstep = new JCheckBox();
    this.brescan = new JCheckBox();
    this.jPanel8 = new JPanel();
    this.jLabel5 = new JLabel();
    this.cdrive = new JComboBox();
    this.bboth = new JCheckBox();
    this.bhead0 = new JCheckBox();
    this.bhead1 = new JCheckBox();
    this.bfdi = new JCheckBox();
    this.jPanel9 = new JPanel();
    this.flop = new JLabel();
    this.jPanel5 = new JPanel();
    this.jPanel10 = new JPanel();
    this.jRadioButton2 = new JRadioButton();
    this.jRadioButton8 = new JRadioButton();
    this.jRadioButton9 = new JRadioButton();
    this.jRadioButton1 = new JRadioButton();
    this.jRadioButton7 = new JRadioButton();
    this.jRadioButton11 = new JRadioButton();
    this.jRadioButton12 = new JRadioButton();
    this.jRadioButton3 = new JRadioButton();
    this.jRadioButton6 = new JRadioButton();
    this.jRadioButton4 = new JRadioButton();
    this.jRadioButton5 = new JRadioButton();
    this.jRadioButton10 = new JRadioButton();
    this.jRadioButton13 = new JRadioButton();
    this.jRadioButton14 = new JRadioButton();
    this.jRadioButton15 = new JRadioButton();
    this.jRadioButton16 = new JRadioButton();
    this.jRadioButton18 = new JRadioButton();
    this.jRadioButton17 = new JRadioButton();
    this.jRadioButton22 = new JRadioButton();
    this.jRadioButton21 = new JRadioButton();
    this.jRadioButton19 = new JRadioButton();
    this.jRadioButton23 = new JRadioButton();
    this.jRadioButton20 = new JRadioButton();
    this.jButton6 = new JButton();
    this.selform = new JLabel();
    this.dsk = new JLabel();
    this.also = new JCheckBox();
    this.ascii = new JCheckBox();
    this.output1 = new JTextArea();
    this.console1 = new JList();
    this.jMenuItem1.setText("Get file(s)");
    this.jMenuItem1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jMenuItem1ActionPerformed(evt);
          }
        });
    this.jPopupMenu1.add(this.jMenuItem1);
    this.jMenuItem2.setText("Protect / Unprotect");
    this.jMenuItem2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jMenuItem2ActionPerformed(evt);
          }
        });
    this.jPopupMenu1.add(this.jMenuItem2);
    this.jMenuItem3.setText("System / Show");
    this.jMenuItem3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jMenuItem3ActionPerformed(evt);
          }
        });
    this.jPopupMenu1.add(this.jMenuItem3);
    this.jPopupMenu1.add(this.jSeparator2);
    this.jMenuItem4.setText("Delete");
    this.jMenuItem4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jMenuItem4ActionPerformed(evt);
          }
        });
    this.jPopupMenu1.add(this.jMenuItem4);
    this.jMenuItem5.setText("Get Info");
    this.jMenuItem5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jMenuItem5ActionPerformed(evt);
          }
        });
    this.jPopupMenu1.add(this.jMenuItem5);
    this.disktools.setBorder(BorderFactory.createEtchedBorder());
    this.disktools.setMaximumSize(new Dimension(640, 443));
    this.jLabel1.setFont(new Font("Tahoma", 1, 11));
    this.jLabel1.setText("Free:");
    this.space.setFont(new Font("Tahoma", 1, 11));
    this.space.setText("empty");
    this.seldsk.setText("Delete file(s)");
    this.seldsk.setFocusPainted(false);
    this.seldsk.setFocusable(false);
    this.seldsk.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.seldskActionPerformed(evt);
          }
        });
    this.user.setModel(new DefaultComboBoxModel<>(new String[] { 
            "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
            "10", "11", "12", "13", "14", "15" }));
    this.user.setFocusable(false);
    this.jLabel3.setFont(new Font("Tahoma", 1, 11));
    this.jLabel3.setText("Import to user:");
    this.buttonGroup1.add(this.jToggleButton1);
    this.jToggleButton1.setText("DF1");
    this.jToggleButton1.setFocusPainted(false);
    this.jToggleButton1.setFocusable(false);
    this.jToggleButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jToggleButton1ActionPerformed(evt);
          }
        });
    this.buttonGroup1.add(this.jToggleButton2);
    this.jToggleButton2.setText("DF0");
    this.jToggleButton2.setFocusPainted(false);
    this.jToggleButton2.setFocusable(false);
    this.jToggleButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jToggleButton2ActionPerformed(evt);
          }
        });
    this.jButton1.setText("Eject");
    this.jButton1.setFocusPainted(false);
    this.jButton1.setFocusable(false);
    this.jButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jButton1ActionPerformed(evt);
          }
        });
    this.load.setText("Load");
    this.load.setFocusPainted(false);
    this.load.setFocusable(false);
    this.load.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.loadActionPerformed(evt);
          }
        });
    this.jTabbedPane1.addMouseListener(new MouseAdapter() {
          public void mousePressed(MouseEvent evt) {
            DSKUtil.this.jTabbedPane1MousePressed(evt);
          }
        });
    this.dropper.setBorder(BorderFactory.createTitledBorder("Handle file(s)"));
    this.jButton2.setText("Protect");
    this.jButton2.setFocusPainted(false);
    this.jButton2.setFocusable(false);
    this.jButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jButton2ActionPerformed(evt);
          }
        });
    this.jButton5.setText("System");
    this.jButton5.setFocusPainted(false);
    this.jButton5.setFocusable(false);
    this.jButton5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jButton5ActionPerformed(evt);
          }
        });
    this.jButton4.setText("Fix EyeCatcher");
    this.jButton4.setFocusPainted(false);
    this.jButton4.setFocusable(false);
    this.jButton4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jButton4ActionPerformed(evt);
          }
        });
    GroupLayout dropperLayout = new GroupLayout(this.dropper);
    this.dropper.setLayout(dropperLayout);
    dropperLayout.setHorizontalGroup(dropperLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(dropperLayout.createSequentialGroup()
          .addContainerGap()
          .addGroup(dropperLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jButton4, -1, 172, 32767)
            .addGroup(dropperLayout.createSequentialGroup()
              .addComponent(this.jButton2, -2, 86, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
              .addComponent(this.jButton5, -1, 76, 32767)))
          .addContainerGap()));
    dropperLayout.setVerticalGroup(dropperLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(dropperLayout.createSequentialGroup()
          .addGroup(dropperLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jButton2)
            .addComponent(this.jButton5))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.jButton4)
          .addContainerGap(-1, 32767)));
    this.jPanel2.setBorder(BorderFactory.createTitledBorder("Extract from DSK"));
    this.jButton3.setText("Get");
    this.jButton3.setFocusPainted(false);
    this.jButton3.setFocusable(false);
    this.jButton3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jButton3ActionPerformed(evt);
          }
        });
    GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
    this.jPanel2.setLayout(jPanel2Layout);
    jPanel2Layout.setHorizontalGroup(jPanel2Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel2Layout.createSequentialGroup()
          .addContainerGap()
          .addComponent(this.jButton3, -1, 172, 32767)
          .addContainerGap()));
    jPanel2Layout.setVerticalGroup(jPanel2Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel2Layout.createSequentialGroup()
          .addComponent(this.jButton3, -1, -1, 32767)
          .addContainerGap()));
    this.jScrollPane4.setBorder(BorderFactory.createEtchedBorder());
    this.jScrollPane4.setHorizontalScrollBarPolicy(31);
    this.jScrollPane4.setVerticalScrollBarPolicy(21);
    this.userlist.setFont(new Font("Monospaced", 0, 12));
    this.userlist.setComponentPopupMenu(this.jPopupMenu1);
    this.userlist.setFocusable(false);
    this.userlist.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            DSKUtil.this.userlistMouseClicked(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            DSKUtil.this.userlistMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            DSKUtil.this.userlistMouseReleased(evt);
          }
        });
    this.userlist.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseDragged(MouseEvent evt) {
            DSKUtil.this.userlistMouseDragged(evt);
          }
        });
    this.jScrollPane4.setViewportView(this.userlist);
    this.jScrollPane2.setBorder(BorderFactory.createEtchedBorder());
    this.jScrollPane2.setHorizontalScrollBarPolicy(31);
    this.jScrollPane2.setVerticalScrollBarPolicy(21);
    this.sizelist.setFont(new Font("Monospaced", 0, 12));
    this.sizelist.setComponentPopupMenu(this.jPopupMenu1);
    this.sizelist.setFocusable(false);
    this.sizelist.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            DSKUtil.this.sizelistMouseClicked(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            DSKUtil.this.sizelistMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            DSKUtil.this.sizelistMouseReleased(evt);
          }
        });
    this.sizelist.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseDragged(MouseEvent evt) {
            DSKUtil.this.sizelistMouseDragged(evt);
          }
        });
    this.jScrollPane2.setViewportView(this.sizelist);
    this.jScrollPane5.setBorder(BorderFactory.createEtchedBorder());
    this.jScrollPane5.setHorizontalScrollBarPolicy(31);
    this.jScrollPane5.setVerticalScrollBarPolicy(21);
    this.system.setFont(new Font("Monospaced", 0, 12));
    this.system.setForeground(new Color(0, 0, 255));
    this.system.setComponentPopupMenu(this.jPopupMenu1);
    this.system.setFocusable(false);
    this.system.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            DSKUtil.this.systemMouseClicked(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            DSKUtil.this.systemMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            DSKUtil.this.systemMouseReleased(evt);
          }
        });
    this.system.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseDragged(MouseEvent evt) {
            DSKUtil.this.systemMouseDragged(evt);
          }
        });
    this.jScrollPane5.setViewportView(this.system);
    this.jScrollPane1.setBorder(BorderFactory.createEtchedBorder());
    this.jScrollPane1.setHorizontalScrollBarPolicy(31);
    this.jScrollPane1.setHorizontalScrollBar((JScrollBar)null);
    this.jScrollPane1.addPropertyChangeListener(new PropertyChangeListener() {
          public void propertyChange(PropertyChangeEvent evt) {
            DSKUtil.this.jScrollPane1PropertyChange(evt);
          }
        });
    this.console.setFont(new Font("Monospaced", 1, 12));
    this.console.setComponentPopupMenu(this.jPopupMenu1);
    this.console.setValueIsAdjusting(true);
    this.console.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            DSKUtil.this.consoleMouseClicked(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            DSKUtil.this.consoleMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            DSKUtil.this.consoleMouseReleased(evt);
          }
        });
    this.console.addComponentListener(new ComponentAdapter() {
          public void componentMoved(ComponentEvent evt) {
            DSKUtil.this.consoleComponentMoved(evt);
          }
        });
    this.console.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseDragged(MouseEvent evt) {
            DSKUtil.this.consoleMouseDragged(evt);
          }
        });
    this.jScrollPane1.setViewportView(this.console);
    this.jScrollPane6.setBorder(BorderFactory.createEtchedBorder());
    this.jScrollPane6.setHorizontalScrollBarPolicy(31);
    this.jScrollPane6.setVerticalScrollBarPolicy(21);
    this.protec.setFont(new Font("Monospaced", 0, 12));
    this.protec.setForeground(new Color(255, 0, 51));
    this.protec.setComponentPopupMenu(this.jPopupMenu1);
    this.protec.setFocusable(false);
    this.protec.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            DSKUtil.this.protecMouseClicked(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            DSKUtil.this.protecMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            DSKUtil.this.protecMouseReleased(evt);
          }
        });
    this.protec.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseDragged(MouseEvent evt) {
            DSKUtil.this.protecMouseDragged(evt);
          }
        });
    this.jScrollPane6.setViewportView(this.protec);
    GroupLayout jPanel11Layout = new GroupLayout(this.jPanel11);
    this.jPanel11.setLayout(jPanel11Layout);
    jPanel11Layout.setHorizontalGroup(jPanel11Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel11Layout.createSequentialGroup()
          .addComponent(this.jScrollPane4, -2, 55, -2)
          .addGap(2, 2, 2)
          .addComponent(this.jScrollPane2, -2, 76, -2)
          .addGap(2, 2, 2)
          .addComponent(this.jScrollPane6, -2, 37, -2)
          .addGap(2, 2, 2)
          .addComponent(this.jScrollPane5, -2, 37, -2)
          .addGap(2, 2, 2)
          .addComponent(this.jScrollPane1, -2, 150, -2)));
    jPanel11Layout.setVerticalGroup(jPanel11Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addComponent(this.jScrollPane4, -1, 195, 32767)
        .addComponent(this.jScrollPane2, -1, 195, 32767)
        .addComponent(this.jScrollPane6, -1, 195, 32767)
        .addComponent(this.jScrollPane5, -1, 195, 32767)
        .addComponent(this.jScrollPane1, -1, 195, 32767));
    this.output.setColumns(20);
    this.output.setEditable(false);
    this.output.setFont(new Font("Monospaced", 1, 11));
    this.output.setRows(5);
    this.jScrollPane3.setViewportView(this.output);
    this.txtinfo.setText("Create txt info");
    this.txtinfo.setFocusPainted(false);
    this.txtinfo.setFocusable(false);
    GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
    this.jPanel3.setLayout(jPanel3Layout);
    jPanel3Layout.setHorizontalGroup(jPanel3Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
            .addComponent(this.jScrollPane3, GroupLayout.Alignment.LEADING, -1, 573, 32767)
            .addGroup(jPanel3Layout.createSequentialGroup()
              .addComponent(this.jPanel11, -2, -1, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(this.jPanel2, -1, -1, 32767)
                .addComponent(this.dropper, -1, -1, 32767)
                .addComponent(this.txtinfo))))
          .addContainerGap()));
    jPanel3Layout.setVerticalGroup(jPanel3Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jPanel11, -1, -1, 32767)
            .addGroup(jPanel3Layout.createSequentialGroup()
              .addComponent(this.dropper, -2, -1, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jPanel2, -2, -1, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.txtinfo, -1, 38, 32767)))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.jScrollPane3, -2, 136, -2)
          .addContainerGap()));
    this.jTabbedPane1.addTab("Directory", this.jPanel3);
    this.jPanel4.setLayout(new BorderLayout());
    this.hex.setLayout(new BorderLayout());
    this.jPanel4.add(this.hex, "Center");
    this.jTabbedPane1.addTab("HexEditor", this.jPanel4);
    this.text.setColumns(20);
    this.text.setEditable(false);
    this.text.setFont(new Font("Monospaced", 1, 11));
    this.text.setRows(5);
    this.jScrollPane7.setViewportView(this.text);
    this.jPanel6.setBorder(BorderFactory.createTitledBorder("Read / Write"));
    this.buttonGroup2.add(this.jToggleButton3);
    this.jToggleButton3.setSelected(true);
    this.jToggleButton3.setText("Read floppy to DSK");
    this.jToggleButton3.setFocusPainted(false);
    this.jToggleButton3.setFocusable(false);
    this.buttonGroup2.add(this.jToggleButton4);
    this.jToggleButton4.setText("Write DSK to floppy");
    this.jToggleButton4.setFocusPainted(false);
    this.jToggleButton4.setFocusable(false);
    this.bstart.setText("Start transfer");
    this.bstart.setFocusPainted(false);
    this.bstart.setFocusable(false);
    this.bstart.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.bstartActionPerformed(evt);
          }
        });
    this.bstop.setText("Abort transfer");
    this.bstop.setEnabled(false);
    this.bstop.setFocusPainted(false);
    this.bstop.setFocusable(false);
    this.bstop.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.bstopActionPerformed(evt);
          }
        });
    GroupLayout jPanel6Layout = new GroupLayout(this.jPanel6);
    this.jPanel6.setLayout(jPanel6Layout);
    jPanel6Layout.setHorizontalGroup(jPanel6Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel6Layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(jPanel6Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jToggleButton4, -1, -1, 32767)
            .addComponent(this.jToggleButton3, -1, -1, 32767)
            .addComponent(this.jSeparator1, GroupLayout.Alignment.TRAILING)
            .addComponent(this.bstart, -1, -1, 32767)
            .addComponent(this.bstop, -1, -1, 32767)
            .addComponent(this.progress, -1, 154, 32767))
          .addContainerGap()));
    jPanel6Layout.setVerticalGroup(jPanel6Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel6Layout.createSequentialGroup()
          .addComponent(this.jToggleButton3)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.jToggleButton4)
          .addGap(7, 7, 7)
          .addComponent(this.jSeparator1, -2, 10, -2)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.bstart)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.bstop)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.progress, -2, -1, -2)
          .addContainerGap(22, 32767)));
    this.jPanel7.setBorder(BorderFactory.createTitledBorder("Options"));
    this.jLabel4.setText("Tracks");
    this.ctracks.setModel(new DefaultComboBoxModel<>(new String[] { "Default", "40 Tracks", "43 Tracks", "80 Tracks" }));
    this.ctracks.setFocusable(false);
    this.gaps.setText("GAPs");
    this.gaps.setFocusPainted(false);
    this.gaps.setFocusable(false);
    this.bstep.setText("Double step");
    this.bstep.setFocusPainted(false);
    this.bstep.setFocusable(false);
    this.brescan.setText("Rescan");
    this.brescan.setFocusPainted(false);
    this.brescan.setFocusable(false);
    GroupLayout jPanel7Layout = new GroupLayout(this.jPanel7);
    this.jPanel7.setLayout(jPanel7Layout);
    jPanel7Layout.setHorizontalGroup(jPanel7Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel7Layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.brescan)
            .addComponent(this.bstep)
            .addComponent(this.gaps)
            .addComponent(this.jLabel4)
            .addComponent(this.ctracks, -2, -1, -2))
          .addContainerGap(52, 32767)));
    jPanel7Layout.setVerticalGroup(jPanel7Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel7Layout.createSequentialGroup()
          .addComponent(this.jLabel4)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.ctracks, -2, -1, -2)
          .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
          .addComponent(this.gaps)
          .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
          .addComponent(this.bstep)
          .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
          .addComponent(this.brescan)
          .addContainerGap(46, 32767)));
    this.jPanel8.setBorder(BorderFactory.createTitledBorder("Drive settings"));
    this.jLabel5.setText("Transfer drive:");
    this.cdrive.setModel(new DefaultComboBoxModel<>(new String[] { 
            "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", 
            "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", 
            "U", "V", "W", "X", "Y", "Z" }));
    this.cdrive.setFocusable(false);
    this.cdrive.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.cdriveActionPerformed(evt);
          }
        });
    this.buttonGroup3.add(this.bboth);
    this.bboth.setText("Both heads");
    this.bboth.setFocusPainted(false);
    this.bboth.setFocusable(false);
    this.bboth.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.bbothActionPerformed(evt);
          }
        });
    this.buttonGroup3.add(this.bhead0);
    this.bhead0.setText("Head 0");
    this.bhead0.setFocusPainted(false);
    this.bhead0.setFocusable(false);
    this.bhead0.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.bhead0ActionPerformed(evt);
          }
        });
    this.buttonGroup3.add(this.bhead1);
    this.bhead1.setText("Head 1");
    this.bhead1.setFocusPainted(false);
    this.bhead1.setFocusable(false);
    this.bhead1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.bhead1ActionPerformed(evt);
          }
        });
    this.buttonGroup3.add(this.bfdi);
    this.bfdi.setSelected(true);
    this.bfdi.setText("3\" drive");
    this.bfdi.setFocusPainted(false);
    this.bfdi.setFocusable(false);
    this.bfdi.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.bfdiActionPerformed(evt);
          }
        });
    this.jPanel9.setBorder(BorderFactory.createEtchedBorder());
    this.flop.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/dskutil/3inch.gif")));
    GroupLayout jPanel9Layout = new GroupLayout(this.jPanel9);
    this.jPanel9.setLayout(jPanel9Layout);
    jPanel9Layout.setHorizontalGroup(jPanel9Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addComponent(this.flop, -1, -1, 32767));
    jPanel9Layout.setVerticalGroup(jPanel9Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addComponent(this.flop));
    GroupLayout jPanel8Layout = new GroupLayout(this.jPanel8);
    this.jPanel8.setLayout(jPanel8Layout);
    jPanel8Layout.setHorizontalGroup(jPanel8Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel8Layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(jPanel8Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jLabel5)
            .addGroup(jPanel8Layout.createSequentialGroup()
              .addGroup(jPanel8Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(this.bhead0)
                .addComponent(this.bhead1))
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 81, 32767)
              .addComponent(this.jPanel9, -2, -1, -2))
            .addComponent(this.bboth)
            .addComponent(this.bfdi)
            .addComponent(this.cdrive, -2, -1, -2))
          .addContainerGap()));
    jPanel8Layout.setVerticalGroup(jPanel8Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel8Layout.createSequentialGroup()
          .addGroup(jPanel8Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
            .addComponent(this.jPanel9, -2, -1, -2)
            .addGroup(jPanel8Layout.createSequentialGroup()
              .addComponent(this.jLabel5)
              .addGap(5, 5, 5)
              .addComponent(this.cdrive, -2, -1, -2)
              .addGap(18, 18, 18)
              .addComponent(this.bfdi)
              .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
              .addComponent(this.bboth)
              .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
              .addComponent(this.bhead0)
              .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
              .addComponent(this.bhead1)))
          .addContainerGap()));
    GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
    this.jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(jPanel1Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel1Layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
            .addComponent(this.jScrollPane7)
            .addGroup(jPanel1Layout.createSequentialGroup()
              .addComponent(this.jPanel6, -2, -1, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jPanel7, -2, -1, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jPanel8, -2, -1, -2)))
          .addContainerGap()));
    jPanel1Layout.setVerticalGroup(jPanel1Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel1Layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
              .addComponent(this.jPanel6, -1, -1, 32767)
              .addComponent(this.jPanel7, -1, -1, 32767))
            .addComponent(this.jPanel8, -1, -1, 32767))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.jScrollPane7, -1, 140, 32767)
          .addContainerGap()));
    this.jTabbedPane1.addTab("Transfer", this.jPanel1);
    this.jPanel10.setBorder(BorderFactory.createTitledBorder("Select format"));
    this.buttonGroup4.add(this.jRadioButton2);
    this.jRadioButton2.setText("PARADOS 80");
    this.jRadioButton2.setFocusPainted(false);
    this.jRadioButton2.setFocusable(false);
    this.jRadioButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton2ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton8);
    this.jRadioButton8.setText("PARADOS 41");
    this.jRadioButton8.setFocusPainted(false);
    this.jRadioButton8.setFocusable(false);
    this.jRadioButton8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton8ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton9);
    this.jRadioButton9.setText("PARADOS D40");
    this.jRadioButton9.setFocusPainted(false);
    this.jRadioButton9.setFocusable(false);
    this.jRadioButton9.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton9ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton1);
    this.jRadioButton1.setText("ROMDOS D1");
    this.jRadioButton1.setFocusPainted(false);
    this.jRadioButton1.setFocusable(false);
    this.jRadioButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton1ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton7);
    this.jRadioButton7.setText("ROMDOS D2");
    this.jRadioButton7.setFocusPainted(false);
    this.jRadioButton7.setFocusable(false);
    this.jRadioButton7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton7ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton11);
    this.jRadioButton11.setText("S-DOS (RDOS D80)");
    this.jRadioButton11.setFocusPainted(false);
    this.jRadioButton11.setFocusable(false);
    this.jRadioButton11.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton11ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton12);
    this.jRadioButton12.setText("ROMDOS D10");
    this.jRadioButton12.setFocusPainted(false);
    this.jRadioButton12.setFocusable(false);
    this.jRadioButton12.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton12ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton3);
    this.jRadioButton3.setText("ROMDOS D20");
    this.jRadioButton3.setFocusPainted(false);
    this.jRadioButton3.setFocusable(false);
    this.jRadioButton3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton3ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton6);
    this.jRadioButton6.setText("ROMDOS D40");
    this.jRadioButton6.setFocusPainted(false);
    this.jRadioButton6.setFocusable(false);
    this.jRadioButton6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton6ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton4);
    this.jRadioButton4.setSelected(true);
    this.jRadioButton4.setText("DATA (SS 40)");
    this.jRadioButton4.setFocusPainted(false);
    this.jRadioButton4.setFocusable(false);
    this.jRadioButton4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton4ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton5);
    this.jRadioButton5.setText("DATA (DS 40)");
    this.jRadioButton5.setFocusPainted(false);
    this.jRadioButton5.setFocusable(false);
    this.jRadioButton5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton5ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton10);
    this.jRadioButton10.setText("DATA (SS 80)");
    this.jRadioButton10.setFocusPainted(false);
    this.jRadioButton10.setFocusable(false);
    this.jRadioButton10.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton10ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton13);
    this.jRadioButton13.setText("DATA (DS 80)");
    this.jRadioButton13.setFocusPainted(false);
    this.jRadioButton13.setFocusable(false);
    this.jRadioButton13.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton13ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton14);
    this.jRadioButton14.setText("SYSTEM (SS 40)");
    this.jRadioButton14.setFocusPainted(false);
    this.jRadioButton14.setFocusable(false);
    this.jRadioButton14.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton14ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton15);
    this.jRadioButton15.setText("SYSTEM (DS 40)");
    this.jRadioButton15.setFocusPainted(false);
    this.jRadioButton15.setFocusable(false);
    this.jRadioButton15.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton15ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton16);
    this.jRadioButton16.setText("SYSTEM (SS 80)");
    this.jRadioButton16.setFocusPainted(false);
    this.jRadioButton16.setFocusable(false);
    this.jRadioButton16.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton16ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton18);
    this.jRadioButton18.setText("SYSTEM (DS 80)");
    this.jRadioButton18.setFocusPainted(false);
    this.jRadioButton18.setFocusable(false);
    this.jRadioButton18.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton18ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton17);
    this.jRadioButton17.setText("IBM (SS 40)");
    this.jRadioButton17.setFocusPainted(false);
    this.jRadioButton17.setFocusable(false);
    this.jRadioButton17.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton17ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton22);
    this.jRadioButton22.setText("IBM (DS 40)");
    this.jRadioButton22.setFocusPainted(false);
    this.jRadioButton22.setFocusable(false);
    this.jRadioButton22.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton22ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton21);
    this.jRadioButton21.setText("IBM (SS 80)");
    this.jRadioButton21.setFocusPainted(false);
    this.jRadioButton21.setFocusable(false);
    this.jRadioButton21.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton21ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton19);
    this.jRadioButton19.setText("IBM (DS 80)");
    this.jRadioButton19.setFocusPainted(false);
    this.jRadioButton19.setFocusable(false);
    this.jRadioButton19.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton19ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton23);
    this.jRadioButton23.setText("VORTEX (DS 80)");
    this.jRadioButton23.setFocusPainted(false);
    this.jRadioButton23.setFocusable(false);
    this.jRadioButton23.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton23ActionPerformed(evt);
          }
        });
    this.buttonGroup4.add(this.jRadioButton20);
    this.jRadioButton20.setText("ULTRAFORM");
    this.jRadioButton20.setFocusPainted(false);
    this.jRadioButton20.setFocusable(false);
    this.jRadioButton20.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jRadioButton20ActionPerformed(evt);
          }
        });
    this.jButton6.setText("Format");
    this.jButton6.setFocusPainted(false);
    this.jButton6.setFocusable(false);
    this.jButton6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            DSKUtil.this.jButton6ActionPerformed(evt);
          }
        });
    this.selform.setFont(new Font("Tahoma", 1, 11));
    this.selform.setForeground(new Color(255, 0, 0));
    this.selform.setText("Selected Format: DATA (SS 40)");
    this.also.setText("Also format drive A:");
    this.also.setFocusPainted(false);
    this.also.setFocusable(false);
    GroupLayout jPanel10Layout = new GroupLayout(this.jPanel10);
    this.jPanel10.setLayout(jPanel10Layout);
    jPanel10Layout.setHorizontalGroup(jPanel10Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel10Layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
              .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                .addGroup(GroupLayout.Alignment.LEADING, jPanel10Layout.createSequentialGroup()
                  .addComponent(this.jRadioButton10)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 18, 32767)
                  .addComponent(this.jRadioButton13))
                .addGroup(jPanel10Layout.createSequentialGroup()
                  .addComponent(this.jRadioButton12)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 17, 32767)
                  .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                      .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(this.jRadioButton8)
                        .addComponent(this.jRadioButton7))
                      .addGap(3, 3, 3))
                    .addComponent(this.jRadioButton3)))
                .addComponent(this.jRadioButton5))
              .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
              .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(this.jRadioButton6)
                .addComponent(this.jRadioButton11)
                .addComponent(this.jRadioButton9)
                .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
                  .addGroup(jPanel10Layout.createSequentialGroup()
                    .addComponent(this.jRadioButton14)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
                    .addComponent(this.jRadioButton15))
                  .addGroup(GroupLayout.Alignment.LEADING, jPanel10Layout.createSequentialGroup()
                    .addComponent(this.jRadioButton16)
                    .addGap(29, 29, 29)
                    .addComponent(this.jRadioButton18))))
              .addGap(122, 122, 122))
            .addGroup(jPanel10Layout.createSequentialGroup()
              .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(this.jRadioButton4)
                .addComponent(this.jRadioButton2)
                .addComponent(this.jRadioButton1))
              .addContainerGap(-1, 32767))))
        .addGroup(jPanel10Layout.createSequentialGroup()
          .addGap(10, 10, 10)
          .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
              .addComponent(this.jRadioButton17)
              .addGap(18, 18, 18)
              .addComponent(this.jRadioButton22)
              .addGap(18, 18, 18)
              .addComponent(this.jRadioButton23))
            .addGroup(jPanel10Layout.createSequentialGroup()
              .addComponent(this.jRadioButton21)
              .addGap(18, 18, 18)
              .addComponent(this.jRadioButton19)
              .addGap(18, 18, 18)
              .addComponent(this.jRadioButton20)))
          .addContainerGap(249, 32767))
        .addGroup(jPanel10Layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.selform)
            .addGroup(jPanel10Layout.createSequentialGroup()
              .addComponent(this.jButton6)
              .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
              .addComponent(this.also)))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.dsk, -1, 234, 32767)
          .addGap(122, 122, 122)));
    jPanel10Layout.setVerticalGroup(jPanel10Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel10Layout.createSequentialGroup()
          .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jRadioButton2)
            .addComponent(this.jRadioButton9)
            .addComponent(this.jRadioButton8))
          .addGap(18, 18, 18)
          .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jRadioButton1)
            .addComponent(this.jRadioButton11)
            .addComponent(this.jRadioButton7))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jRadioButton12)
            .addComponent(this.jRadioButton3)
            .addComponent(this.jRadioButton6))
          .addGap(8, 8, 8)
          .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jRadioButton4)
            .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
              .addComponent(this.jRadioButton5)
              .addComponent(this.jRadioButton14)
              .addComponent(this.jRadioButton15)))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
              .addComponent(this.jRadioButton13)
              .addComponent(this.jRadioButton16))
            .addComponent(this.jRadioButton18)
            .addComponent(this.jRadioButton10))
          .addGap(18, 18, 18)
          .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jRadioButton17)
            .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
              .addComponent(this.jRadioButton22)
              .addComponent(this.jRadioButton23)))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jRadioButton21)
            .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
              .addComponent(this.jRadioButton19)
              .addComponent(this.jRadioButton20)))
          .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
          .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
              .addComponent(this.selform)
              .addGap(3, 3, 3)
              .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(this.jButton6)
                .addComponent(this.also)))
            .addComponent(this.dsk, -2, 20, -2))
          .addContainerGap(66, 32767)));
    GroupLayout jPanel5Layout = new GroupLayout(this.jPanel5);
    this.jPanel5.setLayout(jPanel5Layout);
    jPanel5Layout.setHorizontalGroup(jPanel5Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel5Layout.createSequentialGroup()
          .addContainerGap()
          .addComponent(this.jPanel10, -1, -1, 32767)
          .addContainerGap()));
    jPanel5Layout.setVerticalGroup(jPanel5Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel5Layout.createSequentialGroup()
          .addContainerGap()
          .addComponent(this.jPanel10, -1, -1, 32767)
          .addContainerGap()));
    this.jTabbedPane1.addTab("Format / Create DSK", this.jPanel5);
    this.ascii.setText("ASCII");
    this.ascii.setFocusPainted(false);
    this.ascii.setFocusable(false);
    GroupLayout disktoolsLayout = new GroupLayout(this.disktools);
    this.disktools.setLayout(disktoolsLayout);
    disktoolsLayout.setHorizontalGroup(disktoolsLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(disktoolsLayout.createSequentialGroup()
          .addContainerGap()
          .addGroup(disktoolsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(disktoolsLayout.createSequentialGroup()
              .addComponent(this.jToggleButton2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jToggleButton1)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.load)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jButton1)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.seldsk)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jLabel3)
              .addGap(4, 4, 4)
              .addComponent(this.user, -2, -1, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
              .addComponent(this.ascii))
            .addGroup(disktoolsLayout.createSequentialGroup()
              .addGap(10, 10, 10)
              .addComponent(this.jLabel1)
              .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
              .addComponent(this.space)))
          .addContainerGap(-1, 32767))
        .addComponent(this.jTabbedPane1));
    disktoolsLayout.setVerticalGroup(disktoolsLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(disktoolsLayout.createSequentialGroup()
          .addContainerGap(-1, 32767)
          .addGroup(disktoolsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jToggleButton2)
            .addComponent(this.jToggleButton1)
            .addComponent(this.load)
            .addComponent(this.jButton1)
            .addComponent(this.seldsk)
            .addComponent(this.jLabel3)
            .addComponent(this.user, -2, -1, -2)
            .addComponent(this.ascii))
          .addGap(1, 1, 1)
          .addComponent(this.jTabbedPane1, -2, 384, -2)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(disktoolsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jLabel1)
            .addComponent(this.space))));
    this.output1.setColumns(20);
    this.output1.setEditable(false);
    this.output1.setFont(new Font("Monospaced", 1, 11));
    this.output1.setRows(5);
    this.console1.setFont(new Font("Monospaced", 1, 12));
    this.console1.setComponentPopupMenu(this.jPopupMenu1);
    this.console1.setValueIsAdjusting(true);
    this.console1.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            DSKUtil.this.consoleMouseClicked(evt);
          }
          
          public void mousePressed(MouseEvent evt) {
            DSKUtil.this.consoleMousePressed(evt);
          }
          
          public void mouseReleased(MouseEvent evt) {
            DSKUtil.this.consoleMouseReleased(evt);
          }
        });
    this.console1.addComponentListener(new ComponentAdapter() {
          public void componentMoved(ComponentEvent evt) {
            DSKUtil.this.consoleComponentMoved(evt);
          }
        });
    this.console1.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseDragged(MouseEvent evt) {
            DSKUtil.this.consoleMouseDragged(evt);
          }
        });
    setDefaultCloseOperation(3);
    setTitle("JavaCPC DSKUtil");
    setResizable(false);
    pack();
  }
  
  private void jButton3ActionPerformed(ActionEvent evt) {
    checkDump();
    getFromDSK();
  }
  
  private void seldskActionPerformed(ActionEvent evt) {
    checkDump();
    Delete();
  }
  
  private void jToggleButton2ActionPerformed(ActionEvent evt) {
    if (this.jToggleButton2.isSelected()) {
      checkDump();
      DIR(0);
    } 
  }
  
  private void jToggleButton1ActionPerformed(ActionEvent evt) {
    if (this.jToggleButton1.isSelected()) {
      checkDump();
      DIR(1);
    } 
  }
  
  private void jButton1ActionPerformed(ActionEvent evt) {
    checkDump();
    eject(this.drives);
  }
  
  private void jButton2ActionPerformed(ActionEvent evt) {
    checkDump();
    protect();
  }
  
  private void jButton5ActionPerformed(ActionEvent evt) {
    checkDump();
    hide();
  }
  
  private void loadActionPerformed(ActionEvent evt) {
    checkDump();
    loadDSK();
  }
  
  private void jTabbedPane1MousePressed(MouseEvent evt) {
    checkDump();
  }
  
  private void bfdiActionPerformed(ActionEvent evt) {
    if (this.bfdi.isSelected()) {
      this.flop.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/dskutil/3inch.gif")));
    } else {
      this.flop.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/dskutil/35inch.gif")));
    } 
  }
  
  private void bbothActionPerformed(ActionEvent evt) {
    if (this.bfdi.isSelected()) {
      this.flop.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/dskutil/3inch.gif")));
    } else {
      this.flop.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/dskutil/35inch.gif")));
    } 
  }
  
  private void bhead0ActionPerformed(ActionEvent evt) {
    if (this.bfdi.isSelected()) {
      this.flop.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/dskutil/3inch.gif")));
    } else {
      this.flop.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/dskutil/35inch.gif")));
    } 
  }
  
  private void bhead1ActionPerformed(ActionEvent evt) {
    if (this.bfdi.isSelected()) {
      this.flop.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/dskutil/3inch.gif")));
    } else {
      this.flop.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/dskutil/35inch.gif")));
    } 
  }
  
  private void bstartActionPerformed(ActionEvent evt) {
    if (this.jToggleButton3.isSelected()) {
      int ok = JOptionPane.showConfirmDialog(new Frame(), "Your DSK " + this.actualdsk + "\r\nwill be overwitten!\r\nAre you sure to proceed?", "Confirm transfer", 0);
      if (ok != 0)
        return; 
    } else {
      int ok = JOptionPane.showConfirmDialog(new Frame(), "Your Disk in drive " + this.drive[this.cdrive
            .getSelectedIndex()].toUpperCase() + "\r\nwill be overwitten!\r\nAre you sure to proceed?", "Confirm transfer", 0);
      if (ok != 0)
        return; 
    } 
    if (this.process == null) {
      Thread runner = new Thread() {
          public void run() {
            try {
              DSKUtil.this.Launch(DSKUtil.this.jToggleButton3.isSelected());
            } catch (Exception e) {
              e.printStackTrace();
            } 
          }
        };
      runner.start();
    } 
  }
  
  private void bstopActionPerformed(ActionEvent evt) {
    if (this.process != null) {
      if (this.jToggleButton3.isSelected()) {
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Your DSK " + this.actualdsk + "\r\nhas not been changed yet!\r\nAre you sure to abort?", "Confirm abort transfer", 0);
        if (ok != 0)
          return; 
      } else {
        int ok = JOptionPane.showConfirmDialog(new Frame(), "Your Disk in drive " + this.drive[this.cdrive
              .getSelectedIndex()] + "\r\nis probably damaged.\r\nAre you sure to abort?", "Confirm abort transfer", 0);
        if (ok != 0)
          return; 
      } 
      this.process.destroy();
      this.text.append("Progress aborted...\r\n");
      this.progress.setIndeterminate(false);
      this.bstart.setEnabled(true);
      this.bstop.setEnabled(false);
      this.jTabbedPane1.setEnabled(true);
      this.jToggleButton1.setEnabled(true);
      this.jToggleButton2.setEnabled(true);
      this.load.setEnabled(true);
      this.jButton1.setEnabled(true);
      this.seldsk.setEnabled(true);
      this.prog = 0;
    } 
  }
  
  private void jRadioButton2ActionPerformed(ActionEvent evt) {
    this.index = 0;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "PARADOS 80");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton8ActionPerformed(ActionEvent evt) {
    this.index = 1;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "PARADOS 41");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton9ActionPerformed(ActionEvent evt) {
    this.index = 2;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "PARADOS 40D");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton1ActionPerformed(ActionEvent evt) {
    this.index = 3;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "ROMDOS D1");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton7ActionPerformed(ActionEvent evt) {
    this.index = 4;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "ROMDOS D2");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton11ActionPerformed(ActionEvent evt) {
    this.index = 8;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "S-DOS (ROMDOS D80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton12ActionPerformed(ActionEvent evt) {
    this.index = 5;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "ROMDOS D10");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton3ActionPerformed(ActionEvent evt) {
    this.index = 6;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "ROMDOS D20");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton6ActionPerformed(ActionEvent evt) {
    this.index = 7;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "ROMDOS D40");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton4ActionPerformed(ActionEvent evt) {
    this.index = 9;
    this.also.setVisible(false);
    this.also.setVisible(true);
    this.selform.setText(this.selected + "DATA (SS 40)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton5ActionPerformed(ActionEvent evt) {
    this.index = 10;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "DATA (DS 40)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton10ActionPerformed(ActionEvent evt) {
    this.index = 11;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "DATA (SS 80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton13ActionPerformed(ActionEvent evt) {
    this.index = 12;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "DATA (DS 80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton14ActionPerformed(ActionEvent evt) {
    this.index = 13;
    this.also.setVisible(true);
    this.selform.setText(this.selected + "SYSTEM (SS 40)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton15ActionPerformed(ActionEvent evt) {
    this.index = 14;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "SYSTEM (DS 40)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton16ActionPerformed(ActionEvent evt) {
    this.index = 15;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "SYSTEM (SS 80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton18ActionPerformed(ActionEvent evt) {
    this.index = 16;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "SYSTEM (DS 80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton17ActionPerformed(ActionEvent evt) {
    this.index = 17;
    this.also.setVisible(true);
    this.selform.setText(this.selected + "IBM (SS 40)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton22ActionPerformed(ActionEvent evt) {
    this.index = 18;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "IBM (DS 40)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton21ActionPerformed(ActionEvent evt) {
    this.index = 19;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "IBM (SS 80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton19ActionPerformed(ActionEvent evt) {
    this.index = 20;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "IBM (DS 80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton23ActionPerformed(ActionEvent evt) {
    this.index = 22;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "VORTEX (DS 80)");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jRadioButton20ActionPerformed(ActionEvent evt) {
    this.index = 21;
    this.also.setVisible(false);
    this.selform.setText(this.selected + "ULTRAFORM");
    this.dsk.setText(this.DSKImages[this.index]);
  }
  
  private void jButton6ActionPerformed(ActionEvent evt) {
    formatDisk(this.index);
  }
  
  private void cdriveActionPerformed(ActionEvent evt) {
    this.also.setText("Also format drive " + this.drive[this.cdrive.getSelectedIndex()].toUpperCase());
  }
  
  private void jMenuItem1ActionPerformed(ActionEvent evt) {
    checkDump();
    getFromDSK();
  }
  
  private void jMenuItem2ActionPerformed(ActionEvent evt) {
    checkDump();
    protect();
  }
  
  private void jMenuItem3ActionPerformed(ActionEvent evt) {
    checkDump();
    hide();
  }
  
  private void jMenuItem4ActionPerformed(ActionEvent evt) {
    checkDump();
    Delete();
  }
  
  private void jMenuItem5ActionPerformed(ActionEvent evt) {
    checkDump();
    getInfo();
  }
  
  private void jScrollPane1PropertyChange(PropertyChangeEvent evt) {}
  
  private void consoleMouseDragged(MouseEvent evt) {
    this.sizelist.setSelectedIndices(this.console.getSelectedIndices());
    this.userlist.setSelectedIndices(this.console.getSelectedIndices());
    this.system.setSelectedIndices(this.console.getSelectedIndices());
    this.protec.setSelectedIndices(this.console.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void consoleComponentMoved(ComponentEvent evt) {
    this.sizelist.scrollRectToVisible(this.console.getVisibleRect());
    this.userlist.scrollRectToVisible(this.console.getVisibleRect());
    this.system.scrollRectToVisible(this.console.getVisibleRect());
    this.protec.scrollRectToVisible(this.console.getVisibleRect());
  }
  
  private void consoleMouseReleased(MouseEvent evt) {
    this.sizelist.setSelectedIndices(this.console.getSelectedIndices());
    this.userlist.setSelectedIndices(this.console.getSelectedIndices());
    this.system.setSelectedIndices(this.console.getSelectedIndices());
    this.protec.setSelectedIndices(this.console.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void consoleMousePressed(MouseEvent evt) {
    this.sizelist.setSelectedIndices(this.console.getSelectedIndices());
    this.userlist.setSelectedIndices(this.console.getSelectedIndices());
    this.system.setSelectedIndices(this.console.getSelectedIndices());
    this.protec.setSelectedIndices(this.console.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void consoleMouseClicked(MouseEvent evt) {
    this.sizelist.setSelectedIndices(this.console.getSelectedIndices());
    this.userlist.setSelectedIndices(this.console.getSelectedIndices());
    this.system.setSelectedIndices(this.console.getSelectedIndices());
    this.protec.setSelectedIndices(this.console.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void systemMouseClicked(MouseEvent evt) {
    this.sizelist.setSelectedIndices(this.system.getSelectedIndices());
    this.userlist.setSelectedIndices(this.system.getSelectedIndices());
    this.console.setSelectedIndices(this.system.getSelectedIndices());
    this.protec.setSelectedIndices(this.system.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void systemMouseDragged(MouseEvent evt) {
    this.sizelist.setSelectedIndices(this.system.getSelectedIndices());
    this.userlist.setSelectedIndices(this.system.getSelectedIndices());
    this.console.setSelectedIndices(this.system.getSelectedIndices());
    this.protec.setSelectedIndices(this.system.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void systemMousePressed(MouseEvent evt) {
    this.sizelist.setSelectedIndices(this.system.getSelectedIndices());
    this.userlist.setSelectedIndices(this.system.getSelectedIndices());
    this.console.setSelectedIndices(this.system.getSelectedIndices());
    this.protec.setSelectedIndices(this.system.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void systemMouseReleased(MouseEvent evt) {
    this.sizelist.setSelectedIndices(this.system.getSelectedIndices());
    this.userlist.setSelectedIndices(this.system.getSelectedIndices());
    this.console.setSelectedIndices(this.system.getSelectedIndices());
    this.protec.setSelectedIndices(this.system.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void protecMouseClicked(MouseEvent evt) {
    this.sizelist.setSelectedIndices(this.protec.getSelectedIndices());
    this.userlist.setSelectedIndices(this.protec.getSelectedIndices());
    this.console.setSelectedIndices(this.protec.getSelectedIndices());
    this.system.setSelectedIndices(this.protec.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void protecMouseDragged(MouseEvent evt) {
    this.sizelist.setSelectedIndices(this.protec.getSelectedIndices());
    this.userlist.setSelectedIndices(this.protec.getSelectedIndices());
    this.console.setSelectedIndices(this.protec.getSelectedIndices());
    this.system.setSelectedIndices(this.protec.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void protecMousePressed(MouseEvent evt) {
    this.sizelist.setSelectedIndices(this.protec.getSelectedIndices());
    this.userlist.setSelectedIndices(this.protec.getSelectedIndices());
    this.console.setSelectedIndices(this.protec.getSelectedIndices());
    this.system.setSelectedIndices(this.protec.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void protecMouseReleased(MouseEvent evt) {
    this.sizelist.setSelectedIndices(this.protec.getSelectedIndices());
    this.userlist.setSelectedIndices(this.protec.getSelectedIndices());
    this.console.setSelectedIndices(this.protec.getSelectedIndices());
    this.system.setSelectedIndices(this.protec.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void sizelistMouseClicked(MouseEvent evt) {
    this.protec.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.userlist.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.console.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.system.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void sizelistMouseDragged(MouseEvent evt) {
    this.protec.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.userlist.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.console.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.system.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void sizelistMousePressed(MouseEvent evt) {
    this.protec.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.userlist.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.console.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.system.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void sizelistMouseReleased(MouseEvent evt) {
    this.protec.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.userlist.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.console.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.system.setSelectedIndices(this.sizelist.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void userlistMouseClicked(MouseEvent evt) {
    this.protec.setSelectedIndices(this.userlist.getSelectedIndices());
    this.sizelist.setSelectedIndices(this.userlist.getSelectedIndices());
    this.console.setSelectedIndices(this.userlist.getSelectedIndices());
    this.system.setSelectedIndices(this.userlist.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void userlistMouseDragged(MouseEvent evt) {
    this.protec.setSelectedIndices(this.userlist.getSelectedIndices());
    this.sizelist.setSelectedIndices(this.userlist.getSelectedIndices());
    this.console.setSelectedIndices(this.userlist.getSelectedIndices());
    this.system.setSelectedIndices(this.userlist.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void userlistMousePressed(MouseEvent evt) {
    this.protec.setSelectedIndices(this.userlist.getSelectedIndices());
    this.sizelist.setSelectedIndices(this.userlist.getSelectedIndices());
    this.console.setSelectedIndices(this.userlist.getSelectedIndices());
    this.system.setSelectedIndices(this.userlist.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void userlistMouseReleased(MouseEvent evt) {
    this.protec.setSelectedIndices(this.userlist.getSelectedIndices());
    this.sizelist.setSelectedIndices(this.userlist.getSelectedIndices());
    this.console.setSelectedIndices(this.userlist.getSelectedIndices());
    this.system.setSelectedIndices(this.userlist.getSelectedIndices());
    this.selectedFiles = this.console.getSelectedIndices();
  }
  
  private void jButton4ActionPerformed(ActionEvent evt) {
    writeEyeCatcher();
    DIR(this.drives);
  }
  
  public void loadDisk(int drive) {
    if (drive == 0) {
      this.drives = 0;
      loadDSK(Settings.get("file.drive" + Integer.toString(0), "empty"));
    } 
    if (drive == 1) {
      this.drives = 1;
      loadDSK(Settings.get("file.drive" + Integer.toString(1), "empty"));
    } 
  }
  
  public void getInfo() {
    byte[] checkdata = null;
    if (this.selectedFiles == null || this.folder == null)
      return; 
    this.com = "";
    String fold = System.getProperty("user.home") + "\\javacpc\\checkfile.tmp";
    this.actualdsk = BufferDisk();
    try {
      String get = this.items[this.selectedFiles[0]].toString();
      String use = this.users[this.selectedFiles[0]].toString();
      get = get.replace(" ", "");
      use = use.substring(4);
      String as = "-b";
      String launch = System.getProperty("user.home") + "/JavaCPC/tools/cpcxfs.exe " + this.actualdsk + " -e user " + use + "; get " + as + " -f \"" + get + "\" \"" + fold + "\"";
      Launch(launch);
      File check = new File(fold);
      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(check));
      checkdata = new byte[bis.available()];
      bis.read(checkdata);
      bis.close();
      check.delete();
      if (this.actualdsk.contains(System.getProperty("user.home") + "\\javacpc\\temp"))
        this.actualdsk = eraseTemp(); 
    } catch (Exception exception) {}
    if (checkdata != null) {
      if (this.inf == null) {
        this.infclose = new JButton();
        this.infclose.setText("Close");
        this.infclose.setFocusPainted(false);
        this.infclose.setFocusable(false);
        this.infclose.addActionListener(new ActionListener() {
              public void actionPerformed(ActionEvent evt) {
                DSKUtil.this.inf.setVisible(false);
              }
            });
        this.inf = new JFrame("Fileinfo");
        this.inf.setLayout(new BorderLayout());
        this.inf.setAlwaysOnTop(true);
        this.pan = new InfoPanel();
        this.inf.add(this.pan, "North");
        this.inf.add(this.infclose, "Last");
        this.inf.pack();
        this.inf.setResizable(false);
        this.inf.setDefaultCloseOperation(1);
      } 
      this.pan.filename.setText(this.items[this.selectedFiles[0]].toString());
      if (CheckAMSDOS(checkdata)) {
        String in = "";
        int i;
        for (i = 1; i < 12; i++)
          in = in + (char)checkdata[i]; 
        this.pan.realname.setText(in);
        i = Device.getWord(checkdata, 21);
        in = "#" + Util.hex((short)i);
        this.pan.start.setText(in);
        i = Device.getWord(checkdata, 26);
        in = "#" + Util.hex((short)i);
        this.pan.exec.setText(in);
        i = checkdata.length - 128;
        in = "#" + Util.hex((short)i);
        this.pan.filesize.setText(in);
        i = checkdata[18];
        in = "UNKNOWN";
        if (i == 0)
          in = "BASIC"; 
        if (i == 1)
          in = "BASIC (protected)"; 
        if (i == 2)
          in = "BINARY"; 
        if (i == 3)
          in = "BINARY (protected)"; 
        if (i == 4)
          in = "IMAGE"; 
        if (i == 5)
          in = "IMAGE (protected)"; 
        if (i == 6)
          in = "ASCII"; 
        if (i == 7)
          in = "ASCII (protected)"; 
        this.pan.filetype.setText(in);
      } else {
        this.pan.realname.setText("");
        this.pan.start.setText("");
        this.pan.exec.setText("");
        int i = checkdata.length;
        String in = "#" + Util.hex((short)i);
        this.pan.filesize.setText(in);
        this.pan.filetype.setText("HEADERLESS");
      } 
      this.inf.setVisible(true);
    } 
  }
  
  public static int ChecksumAMSDOS(byte[] pHeader) {
    int Checksum = 0;
    for (int i = 0; i < 67; i++) {
      int CheckSumByte = pHeader[i] & 0xFF;
      Checksum += CheckSumByte;
    } 
    return Checksum;
  }
  
  public boolean CheckAMSDOS(byte[] pHeader) {
    int CalculatedChecksum = ChecksumAMSDOS(pHeader);
    int ChecksumFromHeader = pHeader[67] & 0xFF | (pHeader[68] & 0xFF) << 8;
    if (ChecksumFromHeader == CalculatedChecksum && ChecksumFromHeader != 0) {
      System.out.println("With header");
      return true;
    } 
    System.out.println("Without header");
    return false;
  }
  
  public static void main(final String[] args) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            DSKUtil util = new DSKUtil();
            util.add(util.disktools);
            util.pack();
            util.setVisible(true);
            util.setResizable(true);
            if (args != null && args.length > 0) {
              if (args[0].toLowerCase().endsWith(".dsk"))
                util.loadDSK(args[0]); 
              if (args.length > 1 && args[1].toLowerCase().endsWith(".dsk")) {
                util.drives = 1;
                util.loadDSK(args[1]);
                util.drives = 0;
                util.DIR(0);
              } 
            } 
          }
        });
  }
  
  public static String dumpBytes(byte[] buffer) {
    return dumpBytes(buffer, 0, buffer.length, true, true, true);
  }
  
  public static String dumpBytes(byte[] buffer, int start) {
    return dumpBytes(buffer, 0, buffer.length, true, true, true, start);
  }
  
  public static String dumpBytes(int[] buffer) {
    return dumpBytes(buffer, 0, buffer.length, true, true, true);
  }
  
  public static String dumpBytes(byte[] buffer, int offset, int length, boolean showAddr, boolean showChars, boolean lineFeed) {
    length += offset;
    StringBuffer buff = new StringBuffer(80 * (length + 15) / 16);
    for (int i = offset; i < length; i += 16) {
      String end = "";
      if (showAddr)
        buff.append(hex(i) + ": "); 
      int j = 0;
      for (; j < 16 && i + j < length; j++) {
        byte data = buffer[i + j];
        buff.append(hex(data) + " ");
        end = end + ((data >= 32 && data < Byte.MAX_VALUE) ? (char)data : 46);
      } 
      for (; j < 16; j++)
        buff.append("   "); 
      if (showChars)
        buff.append(end); 
      if (lineFeed)
        buff.append("\n"); 
    } 
    return buff.toString();
  }
  
  public static String dumpBytes(byte[] buffer, int offset, int length, boolean showAddr, boolean showChars, boolean lineFeed, int start) {
    length += offset;
    StringBuffer buff = new StringBuffer(80 * (length + 15) / 16);
    for (int i = offset; i < length; i += 16) {
      String end = "";
      if (showAddr)
        buff.append(hex(i + start) + ": "); 
      int j = 0;
      for (; j < 16 && i + j < length; j++) {
        byte data = buffer[i + j];
        buff.append(hex(data) + " ");
        end = end + ((data >= 32 && data < Byte.MAX_VALUE) ? (char)data : 46);
      } 
      for (; j < 16; j++)
        buff.append("   "); 
      if (showChars)
        buff.append(end); 
      if (lineFeed)
        buff.append("\n"); 
    } 
    return buff.toString();
  }
  
  public static String dumpBytes(int[] buffer, int offset, int length, boolean showAddr, boolean showChars, boolean lineFeed) {
    length += offset;
    StringBuffer buff = new StringBuffer(80 * (length + 15) / 16);
    for (int i = offset; i < length; i += 16) {
      String end = "";
      if (showAddr)
        buff.append(hex(i) + ": "); 
      int j = 0;
      for (; j < 16 && i + j < length; j++) {
        byte data = (byte)buffer[i + j];
        buff.append(hex(data) + " ");
        end = end + ((data >= 32 && data < Byte.MAX_VALUE) ? (char)data : 46);
      } 
      for (; j < 16; j++)
        buff.append("   "); 
      if (showChars)
        buff.append(end); 
      if (lineFeed)
        buff.append("\n"); 
    } 
    return buff.toString();
  }
  
  public static String hex(byte value) {
    return "" + "0123456789ABCDEF".charAt((value & 0xF0) >> 4) + "0123456789ABCDEF".charAt(value & 0xF);
  }
  
  public static String hex(short value) {
    return hex((byte)(value >> 8)) + hex((byte)value);
  }
  
  public static String hex(int value) {
    return hex((short)(value >> 16)) + hex((short)value);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\dskutil\DSKUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */