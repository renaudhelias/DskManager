package jemu.ui.dskutil;

import javax.swing.GroupLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.LayoutStyle;

public class InfoPanel extends JPanel {
  public JLabel exec;
  
  public JLabel filename;
  
  public JLabel filesize;
  
  public JLabel filetype;
  
  private JLabel jLabel1;
  
  private JLabel jLabel2;
  
  private JLabel jLabel3;
  
  private JLabel jLabel4;
  
  private JLabel jLabel5;
  
  private JLabel jLabel6;
  
  private JSeparator jSeparator1;
  
  private JSeparator jSeparator2;
  
  private JSeparator jSeparator3;
  
  public JLabel realname;
  
  public JLabel start;
  
  public InfoPanel() {
    initComponents();
  }
  
  private void initComponents() {
    this.jLabel1 = new JLabel();
    this.jLabel2 = new JLabel();
    this.jLabel3 = new JLabel();
    this.jLabel4 = new JLabel();
    this.jLabel5 = new JLabel();
    this.jLabel6 = new JLabel();
    this.filename = new JLabel();
    this.realname = new JLabel();
    this.filesize = new JLabel();
    this.filetype = new JLabel();
    this.start = new JLabel();
    this.exec = new JLabel();
    this.jSeparator1 = new JSeparator();
    this.jSeparator2 = new JSeparator();
    this.jSeparator3 = new JSeparator();
    this.jLabel1.setText("Filename:");
    this.jLabel2.setText("Internal name:");
    this.jLabel3.setText("Filesize:");
    this.jLabel4.setText("Filetype:");
    this.jLabel5.setText("Start address:");
    this.jLabel6.setText("Exec. address:");
    this.filename.setText("empty");
    this.realname.setText("empty");
    this.filesize.setText("empty");
    this.filetype.setText("empty");
    this.start.setText("empty");
    this.exec.setText("empty");
    GroupLayout layout = new GroupLayout(this);
    setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jSeparator3, -1, 208, 32767)
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.jLabel1)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 41, 32767)
              .addComponent(this.filename, -2, 121, -2))
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.jLabel2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 16, 32767)
              .addComponent(this.realname, -2, 121, -2))
            .addComponent(this.jSeparator2, -1, 208, 32767)
            .addComponent(this.jSeparator1, -1, 208, 32767)
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.jLabel4)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 45, 32767)
              .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(this.filetype, -2, 121, -2)
                .addComponent(this.filesize, -2, 121, -2)))
            .addComponent(this.jLabel3)
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.jLabel5)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 18, 32767)
              .addComponent(this.start, -2, 121, -2))
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.jLabel6)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 15, 32767)
              .addComponent(this.exec, -2, 121, -2)))
          .addContainerGap()));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap(-1, 32767)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jLabel1)
            .addComponent(this.filename))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jLabel2)
            .addComponent(this.realname))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.jSeparator3, -2, 10, -2)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
              .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                  .addComponent(this.jLabel4)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.jLabel3))
                .addGroup(layout.createSequentialGroup()
                  .addComponent(this.filetype)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.filesize)))
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jSeparator1, -2, 10, -2))
            .addGroup(layout.createSequentialGroup()
              .addGap(56, 56, 56)
              .addComponent(this.jLabel5))
            .addGroup(layout.createSequentialGroup()
              .addGap(56, 56, 56)
              .addComponent(this.start)))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jLabel6)
            .addComponent(this.exec))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.jSeparator2, -2, 10, -2)));
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\dskutil\InfoPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */