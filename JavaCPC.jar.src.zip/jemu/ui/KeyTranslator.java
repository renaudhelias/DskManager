package jemu.ui;

import java.awt.event.KeyEvent;

public class KeyTranslator {
  protected boolean DEBUG = false;
  
  public KeyEvent translate(KeyEvent g, String localkeys) {
    KeyEvent e = g;
    if (e.getKeyCode() == 18) {
      e.consume();
      e.setKeyCode(12);
      return e;
    } 
    if (e.getKeyLocation() != 1) {
      if (e.getKeyCode() == 10) {
        e.consume();
        e.setKeyCode(35);
      } 
      if (Switches.joystick != 1) {
        if (e.getKeyCode() == 96) {
          e.consume();
          e.setKeyCode(123);
        } 
        if (e.getKeyCode() == 97) {
          e.consume();
          e.setKeyCode(112);
        } 
        if (e.getKeyCode() == 98) {
          e.consume();
          e.setKeyCode(113);
        } 
        if (e.getKeyCode() == 99) {
          e.consume();
          e.setKeyCode(114);
        } 
        if (e.getKeyCode() == 100) {
          e.consume();
          e.setKeyCode(115);
        } 
        if (e.getKeyCode() == 101) {
          e.consume();
          e.setKeyCode(116);
        } 
        if (e.getKeyCode() == 102) {
          e.consume();
          e.setKeyCode(117);
        } 
        if (e.getKeyCode() == 103) {
          e.consume();
          e.setKeyCode(118);
        } 
        if (e.getKeyCode() == 104) {
          e.consume();
          e.setKeyCode(119);
        } 
        if (e.getKeyCode() == 105) {
          e.consume();
          e.setKeyCode(120);
        } 
      } 
    } 
    if (localkeys.equals("IT_IT")) {
      if (e.getKeyCode() == 521) {
        e.consume();
        e.setKeyCode(93);
        return e;
      } 
      if (e.getKeyChar() == 'ù' || e.getKeyChar() == '§') {
        e.consume();
        e.setKeyCode(65406);
        return e;
      } 
      if (e.getKeyChar() == 'é' || e.getKeyChar() == 'è') {
        e.consume();
        e.setKeyCode(91);
        return e;
      } 
      if (e.getKeyChar() == 'à' || e.getKeyChar() == '°') {
        e.consume();
        e.setKeyCode(222);
        return e;
      } 
      if (e.getKeyChar() == 'ò' || e.getKeyChar() == 'ç') {
        e.consume();
        e.setKeyCode(59);
        return e;
      } 
      if (e.getKeyCode() == 45) {
        e.consume();
        e.setKeyCode(47);
        return e;
      } 
      if (e.getKeyCode() == 222) {
        e.consume();
        e.setKeyCode(45);
        return e;
      } 
      if (e.getKeyChar() == 'ì' || e.getKeyChar() == '^') {
        e.consume();
        e.setKeyCode(61);
        return e;
      } 
    } 
    if (localkeys.equals("DE_DE")) {
      if (this.DEBUG)
        System.out.println("DE: " + e.getKeyChar()); 
      if (e.getKeyChar() == 'ü' || e.getKeyChar() == 'Ü') {
        e.consume();
        e.setKeyCode(91);
        return e;
      } 
      if (e.getKeyChar() == 'ä' || e.getKeyChar() == 'Ä') {
        e.consume();
        e.setKeyCode(222);
        return e;
      } 
      if (e.getKeyChar() == 'ö' || e.getKeyChar() == 'Ö') {
        e.consume();
        e.setKeyCode(59);
        return e;
      } 
      if (e.getKeyChar() == 'ß' || e.getKeyChar() == '?') {
        e.consume();
        e.setKeyCode(45);
        return e;
      } 
      if (e.getKeyCode() == 45) {
        e.consume();
        e.setKeyCode(47);
        return e;
      } 
      if (e.getKeyCode() == 129) {
        e.consume();
        e.setKeyCode(61);
        return e;
      } 
      if (e.getKeyCode() == 153) {
        e.consume();
        e.setKeyCode(65406);
        return e;
      } 
      if (e.getKeyCode() == 130) {
        e.consume();
        e.setKeyCode(9);
        return e;
      } 
      if (e.getKeyCode() == 520) {
        e.consume();
        e.setKeyCode(92);
        return e;
      } 
      if (e.getKeyCode() == 521) {
        e.consume();
        e.setKeyCode(93);
        return e;
      } 
      if (e.getKeyCode() == 90) {
        e.consume();
        e.setKeyCode(89);
        return e;
      } 
      if (e.getKeyCode() == 89) {
        e.consume();
        e.setKeyCode(90);
        return e;
      } 
    } 
    if (localkeys.equals("ES_ES")) {
      if (this.DEBUG)
        System.out.println("ES: " + e.getKeyChar()); 
      if (e.getKeyChar() == 'º' || e.getKeyChar() == '²') {
        e.consume();
        e.setKeyCode(9);
        return e;
      } 
      if (e.getKeyChar() == 'ç' || e.getKeyChar() == 'Ç') {
        e.consume();
        e.setKeyCode(92);
        return e;
      } 
      if (e.getKeyChar() == 'Ñ' || e.getKeyChar() == 'ñ') {
        e.consume();
        e.setKeyCode(59);
        return e;
      } 
      if (e.getKeyCode() == 222) {
        e.consume();
        e.setKeyCode(45);
        return e;
      } 
      if (e.getKeyCode() == 45) {
        e.consume();
        e.setKeyCode(47);
        return e;
      } 
      if (e.getKeyCode() == 129) {
        e.consume();
        e.setKeyCode(222);
        return e;
      } 
      if (e.getKeyCode() == 521) {
        e.consume();
        e.setKeyCode(93);
        return e;
      } 
      if (e.getKeyCode() == 518) {
        e.consume();
        e.setKeyCode(61);
        return e;
      } 
      if (e.getKeyCode() == 153) {
        e.consume();
        e.setKeyCode(65406);
        return e;
      } 
      if (e.getKeyCode() == 128) {
        e.consume();
        e.setKeyCode(91);
        return e;
      } 
    } 
    if (localkeys.equals("FR_FR")) {
      if (this.DEBUG)
        System.out.println("FR: " + e.getKeyChar()); 
      if (e.getKeyCode() == 515) {
        e.consume();
        e.setKeyCode(93);
        return e;
      } 
      if (e.getKeyCode() == 130) {
        e.consume();
        e.setKeyCode(91);
        return e;
      } 
      if (e.getKeyCode() == 57) {
        e.consume();
        e.setKeyCode(57);
        return e;
      } 
      if (e.getKeyCode() == 522) {
        e.consume();
        e.setKeyCode(45);
        return e;
      } 
      if (e.getKeyCode() == 81) {
        e.consume();
        e.setKeyCode(65);
        return e;
      } 
      if (e.getKeyCode() == 65) {
        e.consume();
        e.setKeyCode(81);
        return e;
      } 
      if (e.getKeyCode() == 90) {
        e.consume();
        e.setKeyCode(87);
        return e;
      } 
      if (e.getKeyCode() == 87) {
        e.consume();
        e.setKeyCode(90);
        return e;
      } 
      if (e.getKeyChar() == '²' || (e.getKeyCode() == 0 && e.getKeyChar() == Character.MAX_VALUE)) {
        e.consume();
        e.setKeyCode(92);
        return e;
      } 
      if (e.getKeyChar() == '%' || e.getKeyChar() == 'ù') {
        e.consume();
        e.setKeyCode(222);
        return e;
      } 
      if (e.getKeyCode() == 151) {
        e.consume();
        e.setKeyCode(65406);
        return e;
      } 
      if (e.getKeyCode() == 77) {
        e.consume();
        e.setKeyCode(59);
        return e;
      } 
      if (e.getKeyCode() == 44) {
        e.consume();
        e.setKeyCode(77);
        return e;
      } 
      if (e.getKeyCode() == 59) {
        e.consume();
        e.setKeyCode(44);
        return e;
      } 
      if (e.getKeyCode() == 517) {
        e.consume();
        e.setKeyCode(47);
        return e;
      } 
      if (e.getKeyCode() == 513) {
        e.consume();
        e.setKeyCode(46);
        return e;
      } 
    } 
    if (localkeys.equals("DA_DK")) {
      if (e.getKeyCode() == 45) {
        e.consume();
        e.setKeyCode(47);
        return e;
      } 
      if (e.getKeyCode() == 153) {
        e.consume();
        e.setKeyCode(92);
        return e;
      } 
      if (e.getKeyChar() == 'æ' || e.getKeyChar() == 'Æ') {
        e.consume();
        e.setKeyCode(59);
        return e;
      } 
      if (e.getKeyChar() == 'ø' || e.getKeyChar() == 'Ø') {
        e.consume();
        e.setKeyCode(222);
        return e;
      } 
      if (e.getKeyChar() == 'å' || e.getKeyChar() == 'Å') {
        e.consume();
        e.setKeyCode(91);
        return e;
      } 
      if (e.getKeyCode() == 222) {
        e.consume();
        e.setKeyCode(93);
        return e;
      } 
      if (e.getKeyCode() == 135) {
        e.consume();
        e.setKeyCode(65406);
        return e;
      } 
      if (e.getKeyCode() == 521) {
        e.consume();
        e.setKeyCode(45);
        return e;
      } 
      if (e.getKeyCode() == 129) {
        e.consume();
        e.setKeyCode(61);
        return e;
      } 
    } 
    if (localkeys.equals("SV_SE") || localkeys
      .equals("NB_NO") || localkeys
      .equals("NO_NO")) {
      if (e.getKeyCode() == 45) {
        e.setKeyCode(47);
        return e;
      } 
      if (e.getKeyCode() == 153) {
        e.setKeyCode(92);
        return e;
      } 
      if (e.getKeyChar() == 'æ' || e.getKeyChar() == 'Æ') {
        e.setKeyCode(222);
        return e;
      } 
      if (e.getKeyChar() == 'ø' || e.getKeyChar() == 'Ø') {
        e.setKeyCode(59);
        return e;
      } 
      if (e.getKeyChar() == 'å' || e.getKeyChar() == 'Å') {
        e.setKeyCode(91);
        return e;
      } 
      if (e.getKeyCode() == 222) {
        e.setKeyCode(93);
        return e;
      } 
      if (e.getKeyCode() == 135) {
        e.setKeyCode(65406);
        return e;
      } 
      if (e.getKeyCode() == 521) {
        e.setKeyCode(45);
        return e;
      } 
      if (e.getKeyCode() == 129) {
        e.setKeyCode(61);
        return e;
      } 
    } 
    return e;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\KeyTranslator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */