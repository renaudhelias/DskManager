package jemu.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Calendar;
import java.util.HashMap;
import javax.swing.AbstractListModel;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import jemu.core.Util;
import jemu.core.breakpoint.Breakpoint;
import jemu.core.breakpoint.StopBreakpoint;
import jemu.core.cpu.Processor;
import jemu.core.cpu.ProgramCounterObserver;
import jemu.core.device.Computer;
import jemu.core.device.Device;
import jemu.core.device.memory.Memory;
import jemu.settings.Settings;
import jemu.system.cpc.CPC;
import jemu.util.diss.Disassembler;

public class Debugger extends JFrame implements KeyListener, MouseMotionListener, MouseListener, ItemListener, ActionListener {
  boolean ctrl;
  
  boolean shift;
  
  public void keyReleased(KeyEvent e) {
    if (e.getKeyCode() == 17)
      this.ctrl = false; 
    if (e.getKeyCode() == 16)
      this.shift = false; 
  }
  
  public void keyPressed(KeyEvent e) {
    if (e.getKeyCode() == 119) {
      if (this.shift) {
        this.computer.stepOver();
      } else {
        this.computer.step();
      } 
      this.computer.repaintDisplay();
    } 
    if (e.getKeyCode() == 17)
      this.ctrl = true; 
    if (e.getKeyCode() == 16)
      this.shift = true; 
    if (e.getKeyCode() == 67 && this.ctrl)
      if (eDisassembler.hasFocus()) {
        copyDisassembly();
      } else if (eMemory.hasFocus()) {
        copyMemory();
      }  
    if (e.getKeyCode() == 70 && this.ctrl)
      eMemory.find(); 
    if (e.getKeyCode() == 114)
      eMemory.find(); 
  }
  
  public void keyTyped(KeyEvent e) {}
  
  Breakpoints testpoints = new Breakpoints();
  
  protected int[] banks = new int[] { 
      192, 196, 197, 198, 199, 204, 205, 206, 207, 212, 
      213, 214, 215, 220, 221, 222, 223, 228, 229, 230, 
      231, 236, 237, 238, 239, 244, 245, 246, 247, 252, 
      253, 254, 255 };
  
  public void mouseMoved(MouseEvent e) {
    if (!this.popupMenu.isShowing())
      if (e.getSource() == eDisassembler) {
        eDisassembler.selline = eDisassembler.getAddress(e.getY());
        eDisassembler.repaint();
        this.mBreak.setEnabled(true);
        this.mRemove.setEnabled(true);
        this.mCopyHex.setEnabled(false);
        this.mCopyBasic.setEnabled(false);
      } else {
        this.mBreak.setEnabled(false);
        this.mRemove.setEnabled(false);
        this.mCopyHex.setEnabled(true);
        this.mCopyBasic.setEnabled(true);
      }  
  }
  
  public void mouseDragged(MouseEvent e) {
    if (!this.popupMenu.isShowing())
      if (e.getSource() == eDisassembler) {
        eDisassembler.selline = eDisassembler.getAddress(e.getY());
        eDisassembler.repaint();
        this.mBreak.setEnabled(true);
        this.mRemove.setEnabled(true);
        this.mCopyHex.setEnabled(false);
        this.mCopyBasic.setEnabled(false);
      } else {
        this.mBreak.setEnabled(false);
        this.mRemove.setEnabled(false);
        this.mCopyHex.setEnabled(true);
        this.mCopyBasic.setEnabled(true);
      }  
  }
  
  public void mouseEntered(MouseEvent e) {
    if (e.getSource() == this.bGFX)
      this.bGFX.setBorder(new BevelBorder(0)); 
    if (e.getSource() == this.bBreaks)
      this.bBreaks.setBorder(new BevelBorder(0)); 
    if (e.getSource() == this.bSearch)
      this.bSearch.setBorder(new BevelBorder(0)); 
  }
  
  public void mouseExited(MouseEvent e) {
    eDisassembler.selline = -20;
    eDisassembler.repaint();
    if (e.getSource() == this.bGFX)
      this.bGFX.setBorder((Border)null); 
    if (e.getSource() == this.bBreaks)
      this.bBreaks.setBorder((Border)null); 
    if (e.getSource() == this.bSearch)
      this.bSearch.setBorder((Border)null); 
  }
  
  private HashMap<Integer, Breakpoint> breakpoints = new HashMap<>();
  
  public static final Color navy = new Color(0, 0, 127);
  
  protected Computer computer;
  
  protected long startCycles = 0L;
  
  public static int breakaddress;
  
  protected int breakindex = 0;
  
  protected JFileChooser fileDlg = new JFileChooser();
  
  int storedbank;
  
  int[] cycles;
  
  JTextArea text;
  
  int mouseY;
  
  protected JButton bRun;
  
  protected EButton bStep;
  
  protected EButton bStepOver;
  
  protected JButton bStop;
  
  protected JButton bGFX;
  
  protected JButton bBreaks;
  
  protected JButton bSearch;
  
  protected JButton bReset;
  
  public JCheckBox bPoints;
  
  protected JCheckBox bInst;
  
  protected JCheckBox bFollow;
  
  public static JCheckBox bWinape;
  
  public static EDisassembler eDisassembler;
  
  public static EStackPointer eStackpointer;
  
  public static EMemory eMemory;
  
  protected ERegisters eRegisters;
  
  protected JPanel jPanel1;
  
  protected JPanel jPanel2;
  
  protected JPanel jPanel4;
  
  protected JPanel jPanel5;
  
  protected JPanel jPanelRegisters;
  
  protected JScrollPane jScrollPane1;
  
  protected JSplitPane jSplitPane1;
  
  protected JSplitPane jSplitPane2;
  
  protected JTextField lCycleCount;
  
  protected JLabel lCycles;
  
  protected JMenuItem mGoto;
  
  protected JMenuItem mSave;
  
  protected JMenuItem mOpenMulti;
  
  protected JMenuItem mFind;
  
  protected JMenuItem mCopy;
  
  protected JMenuItem mCopyHex;
  
  protected JMenuItem mCopyBasic;
  
  protected JMenuItem mBreak;
  
  protected JMenuItem mRemove;
  
  protected JMenuItem mRemoveAll;
  
  protected JPopupMenu popupMenu;
  
  protected ButtonGroup readwritegroup;
  
  protected JRadioButton bRead;
  
  protected JRadioButton bWrite;
  
  protected JRadioButton bAny;
  
  protected JComboBox bBanks;
  
  protected ePPI ppi;
  
  public Computer getDebuggerComputer() {
    return this.computer;
  }
  
  public void setComputer(Computer value) {
    if (this.computer != null)
      this.computer.removeActionListener(this); 
    this.computer = value;
    eDisassembler.setComputer(this.computer);
    eStackpointer.setComputer(this.computer);
    eMemory.setComputer(this.computer);
    if (this.computer != null) {
      this.computer.addActionListener(this);
      this.eRegisters.setDevice((Device)this.computer.getProcessor());
      updateDisplay();
    } else {
      this.eRegisters.setDevice((Device)null);
    } 
  }
  
  public void updateDisplay() {
    this.ppi.ppiA.setText(Util.hex((byte)this.computer.getPPI_A()));
    this.ppi.ppiB.setText(Util.hex((byte)this.computer.getPPI_B()));
    this.ppi.ppiC.setText(Util.hex((byte)this.computer.getPPI_C()));
    this.ppi.ppiControl.setText(Util.hex((byte)this.computer.getPPI_Control()));
    eDisassembler.setPC(this.computer.getProcessor().getProgramCounter());
    eStackpointer.setSP(this.computer.getProcessor().getStackPointer());
    eMemory.setAddress(this.computer.getProcessor().getProgramCounter());
    this.lCycleCount.setText(Long.toString(this.computer.getProcessor().getCycles() - this.startCycles));
    this.eRegisters.setValues();
    repaint();
  }
  
  public boolean isBreakpoint(int address) {
    return (this.breakpoints.get(Integer.valueOf(address)) != null);
  }
  
  public String[] getBreakpoints() {
    int breakcount = 0;
    for (int addr = 0; addr <= 65535; addr++) {
      if (isBreakpoint(addr))
        breakcount++; 
    } 
    String[] breaks = new String[breakcount];
    breakcount = 0;
    for (int i = 0; i <= 65535; i++) {
      if (isBreakpoint(i)) {
        breaks[breakcount] = Util.hex((short)i);
        breaks[breakcount] = breaks[breakcount] + "         cycles: " + this.cycles[i];
        breakcount++;
      } 
    } 
    return breaks;
  }
  
  public void setBanks() {
    this.bBanks.setModel(new DefaultComboBoxModel() {
          String[] strings = new String[] { 
              "C0", "C4", "C5", "C6", "C7", "CC", "CD", "CE", "CF", "D4", 
              "D5", "D6", "D7", "DC", "DD", "DE", "DF", "E4", "E5", "E6", 
              "E7", "EC", "ED", "EE", "EF", "F4", "F5", "F6", "F7", "FC", 
              "FD", "FE", "FF" };
          
          public int getSize() {
            return this.strings.length;
          }
          
          public Object getElementAt(int i) {
            return this.strings[i];
          }
        });
    this.bBanks.setSelectedIndex(0);
  }
  
  public void updateBreakpoints() {
    this.testpoints.points.setModel(new AbstractListModel() {
          String[] strings = Debugger.this.getBreakpoints();
          
          public int getSize() {
            return this.strings.length;
          }
          
          public Object getElementAt(int i) {
            return this.strings[i];
          }
        });
  }
  
  protected long getGotoAddress() {
    String address = JOptionPane.showInputDialog("Address: ", "#");
    if (address == null)
      return -1L; 
    address = address.trim();
    if (address.length() == 0)
      return -1L; 
    switch (address.charAt(0)) {
      case '#':
      case '$':
      case '&':
        return Long.parseLong(address.substring(1), 16);
    } 
    return Long.parseLong(address);
  }
  
  public static void setDisass(int address) {
    eDisassembler.setPC(address);
  }
  
  public static void setEditor(int address) {
    eMemory.setAddress(address);
  }
  
  public Debugger() {
    this.storedbank = 0;
    this.cycles = new int[65536];
    this.text = new JTextArea();
    initComponents();
    this.bBanks.addItemListener(this);
    this.bRead.addItemListener(this);
    this.bWrite.addItemListener(this);
    this.bAny.addItemListener(this);
    this.bRead.setSelected(true);
    this.bRun.addActionListener(this);
    this.bStop.addActionListener(this);
    this.bGFX.addActionListener(this);
    this.bBreaks.addActionListener(this);
    this.testpoints.clear.addActionListener(this);
    this.testpoints.clearall.addActionListener(this);
    this.testpoints.cycles.addActionListener(this);
    this.bSearch.addActionListener(this);
    this.bGFX.addMouseListener(this);
    this.bBreaks.addMouseListener(this);
    this.bSearch.addMouseListener(this);
    this.bReset.addActionListener(this);
    this.bPoints.addActionListener(this);
    this.bPoints.setFocusable(false);
    this.bPoints.addItemListener(this);
    this.bPoints.setSelected(Settings.getBoolean("breakpoints", true));
    this.bFollow.addActionListener(this);
    this.bFollow.setFocusable(false);
    this.bFollow.addItemListener(this);
    bWinape.setFocusable(false);
    bWinape.addItemListener(this);
    this.bInst.addActionListener(this);
    this.bInst.addItemListener(this);
    this.bInst.setSelected(Settings.getBoolean("breakinstructions", false));
    this.bInst.setFocusable(false);
    this.bStepOver.addActionListener(this);
    this.bStep.addActionListener(this);
    this.mSave.addActionListener(this);
    this.mOpenMulti.addActionListener(this);
    this.mFind.addActionListener(this);
    this.mCopy.addActionListener(this);
    this.mCopyHex.addActionListener(this);
    this.mCopyBasic.addActionListener(this);
    this.mGoto.addActionListener(this);
    this.mBreak.addActionListener(this);
    this.mRemove.addActionListener(this);
    this.mRemoveAll.addActionListener(this);
    this.jScrollPane1.getVerticalScrollBar().setUnitIncrement(getFontMetrics(eMemory.getFont()).getHeight());
    this.jScrollPane1.setBorder(new BevelBorder(1));
  }
  
  public void itemStateChanged(ItemEvent e) {
    if (e.getSource() == bWinape) {
      updateDisplay();
      eDisassembler.repaint();
    } 
    if (e.getSource() == this.bRead || e.getSource() == this.bWrite || e.getSource() == this.bAny) {
      this.bBanks.setEnabled(this.bWrite.isSelected());
      eDisassembler.read = this.bRead.isSelected();
      eDisassembler.any = this.bAny.isSelected();
      eStackpointer.read = this.bRead.isSelected();
      eStackpointer.any = this.bAny.isSelected();
      eMemory.read = this.bRead.isSelected();
      eMemory.any = this.bAny.isSelected();
      eMemory.repaint();
      eDisassembler.repaint();
      eStackpointer.repaint();
    } 
    if (e.getSource() == this.bBanks && this.bAny.isSelected()) {
      if (this.computer != null)
        this.computer.stop(); 
      eDisassembler.any = true;
      eDisassembler.forcedbank = this.banks[this.bBanks.getSelectedIndex()];
      eStackpointer.any = true;
      eStackpointer.forcedbank = this.banks[this.bBanks.getSelectedIndex()];
      eMemory.forcedbank = this.banks[this.bBanks.getSelectedIndex()];
      eMemory.repaint();
      eDisassembler.repaint();
      eStackpointer.repaint();
    } 
    if (e.getSource() == this.bPoints) {
      Switches.breakpoints = this.bPoints.isSelected();
      Settings.setBoolean("breakpoints", this.bPoints.isSelected());
    } 
    if (e.getSource() == this.bFollow)
      JEMU.followCPU = this.bFollow.isSelected(); 
    if (e.getSource() == this.bInst) {
      Switches.breakinsts = this.bInst.isSelected();
      Settings.setBoolean("breakinstructions", this.bInst.isSelected());
    } 
  }
  
  public void update() {}
  
  public void Continue() {
    this.computer.start();
    CPC.resync = true;
  }
  
  public void actionPerformed(ActionEvent e) {
    this.computer.clearRunToAddress();
    if (e.getSource() == this.bRun) {
      this.computer.start();
      CPC.resync = true;
    } else if (e.getSource() == this.bStop) {
      this.computer.stop();
    } else if (e.getSource() == this.bGFX) {
      Display.initgfxviewer = 1;
    } else if (e.getSource() != this.bSearch) {
      if (e.getSource() == this.bBreaks) {
        this.testpoints.setVisible(true);
      } else if (e.getSource() == this.testpoints.clear) {
        clearBreakpoint();
      } else if (e.getSource() == this.testpoints.clearall) {
        removeAllBreakpoints();
      } else if (e.getSource() == this.testpoints.cycles) {
        setCycles();
      } else if (e.getSource() == this.bReset) {
        resetCycles();
      } else if (e.getSource() == this.bStep) {
        this.computer.step();
        this.computer.repaintDisplay();
      } else if (e.getSource() == this.bStepOver) {
        this.computer.stepOver();
        this.computer.repaintDisplay();
      } else if (e.getSource() == this.computer) {
        updateDisplay();
      } else if (e.getSource() == this.mGoto) {
        long address = getGotoAddress();
        if (address != -1L)
          if (this.popupMenu.getInvoker() == eDisassembler) {
            eDisassembler.setAddress((int)address);
          } else {
            eMemory.setAddress((int)address);
          }  
      } else if (e.getSource() == this.mBreak) {
        if (Switches.breakpoints && breakaddress > -1 && breakaddress < 65536)
          setBreakpoint(breakaddress); 
      } else if (e.getSource() == this.mRemove) {
        if (Switches.breakpoints) {
          Breakpoint bp = this.breakpoints.get(Integer.valueOf(breakaddress));
          if (bp != null) {
            this.cycles[breakaddress] = 0;
            bp.setCycles(0);
            this.computer.getProcessor().detachProgramCounterObserver((ProgramCounterObserver)bp);
            this.breakpoints.remove(Integer.valueOf(breakaddress));
            System.out.println("StopBreakpoint removed at &" + Util.hex(breakaddress));
          } 
          updateBreakpoints();
          eDisassembler.repaint();
          eStackpointer.repaint();
          repaint();
        } 
      } else if (e.getSource() == this.mRemoveAll) {
        removeAllBreakpoints();
        eDisassembler.repaint();
        eStackpointer.repaint();
        repaint();
      } else if (e.getSource() == this.mSave) {
        if (this.popupMenu.getInvoker() == eDisassembler) {
          saveDisassembly();
        } else {
          saveMemory();
        } 
      } else if (e.getSource() == this.mOpenMulti) {
        if (this.popupMenu.getInvoker() == eDisassembler) {
          showMultiMem(this.mouseY);
        } else {
          showMultiMem(this.computer.getProcessor().getProgramCounter());
        } 
      } else if (e.getSource() == this.mCopy) {
        if (this.popupMenu.getInvoker() == eDisassembler) {
          copyDisassembly();
        } else {
          copyMemory();
        } 
      } else if (e.getSource() == this.mFind) {
        eMemory.find();
      } else if (e.getSource() == this.mCopyHex) {
        if (this.popupMenu.getInvoker() == eDisassembler) {
          copyDisassembly();
        } else {
          copyMemoryAsHex();
        } 
      } else if (e.getSource() == this.mCopyBasic) {
        if (this.popupMenu.getInvoker() == eDisassembler) {
          copyDisassembly();
        } else {
          copyMemoryAsBasic();
        } 
      } 
    } 
    this.computer.setFrameSkip(0);
    this.computer.updateDisplay(false);
  }
  
  public void showMultiMem(int address) {
    MultiMem multiMem = new MultiMem(this.computer, address);
    multiMem.setDefaultCloseOperation(1);
    multiMem.setVisible(true);
  }
  
  protected File showSaveDialog(String title) {
    this.fileDlg.setDialogTitle(title);
    return (this.fileDlg.showSaveDialog(this.bRun) == 0) ? this.fileDlg.getSelectedFile() : null;
  }
  
  public void setBreakpoint(int address) {
    StopBreakpoint stopBreakpoint;
    Breakpoint bp = this.breakpoints.get(Integer.valueOf(address));
    if (bp == null) {
      stopBreakpoint = new StopBreakpoint(this.computer.getProcessor(), address);
      setCycles(address);
      this.computer.getProcessor().attachProgramCounterObserver((ProgramCounterObserver)stopBreakpoint);
      this.breakpoints.put(Integer.valueOf(address), stopBreakpoint);
      System.out.println("StopBreakpoint added at &" + Util.hex(address));
    } 
    setCycles(address);
    stopBreakpoint.setCycles(this.cycles[address]);
    updateBreakpoints();
    eDisassembler.repaint();
    eStackpointer.repaint();
    repaint();
  }
  
  public void setBreakpoint(int address, int cyc) {
    StopBreakpoint stopBreakpoint;
    Breakpoint bp = this.breakpoints.get(Integer.valueOf(address));
    if (bp == null) {
      stopBreakpoint = new StopBreakpoint(this.computer.getProcessor(), address);
      stopBreakpoint.setCycles(cyc);
      this.computer.getProcessor().attachProgramCounterObserver((ProgramCounterObserver)stopBreakpoint);
      this.breakpoints.put(Integer.valueOf(address), stopBreakpoint);
      System.out.println("StopBreakpoint added at &" + Util.hex(address));
    } 
    stopBreakpoint.setCycles(cyc);
    updateBreakpoints();
    eDisassembler.repaint();
    eStackpointer.repaint();
    repaint();
  }
  
  public void saveMemory() {
    saveMemory(eMemory.selStart, eMemory.selEnd);
  }
  
  public void copyMemory() {
    copyMemory(eMemory.selStart, eMemory.selEnd);
  }
  
  public void copyMemoryAsHex() {
    copyMemoryAsHex(eMemory.selStart, eMemory.selEnd);
  }
  
  public void copyMemoryAsBasic() {
    copyMemoryAsBasic(eMemory.selStart, eMemory.selEnd);
  }
  
  public void saveMemory(int start, int end) {
    File file = showSaveDialog("Save Memory");
    if (file != null)
      try {
        FileOutputStream io = new FileOutputStream(file);
        try {
          Memory mem = this.computer.getMemory();
          for (int addr = start; addr <= end; addr++) {
            if (eDisassembler.read) {
              io.write(mem.readByte(addr));
            } else if (eDisassembler.any) {
              io.write(mem.readWriteByte(addr, eDisassembler.forcedbank, true));
            } else {
              io.write(mem.readWriteByte(addr));
            } 
          } 
        } finally {
          io.close();
        } 
      } catch (Exception e) {
        e.printStackTrace();
      }  
  }
  
  public void copyMemory(int start, int end) {
    try {
      Memory mem = this.computer.getMemory();
      byte[] data = new byte[end - start + 1];
      int pos = 0;
      for (int addr = start; addr <= end; addr++) {
        if (eDisassembler.read) {
          data[pos] = (byte)mem.readByte(addr);
        } else if (eDisassembler.any) {
          data[pos] = (byte)mem.readWriteByte(addr, eDisassembler.forcedbank, true);
        } else {
          data[pos] = (byte)mem.readWriteByte(addr);
        } 
        pos++;
      } 
      String result = Util.dumpBytes(data);
      this.text.setText(result);
      this.text.selectAll();
      this.text.copy();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void copyMemoryAsHex(int start, int end) {
    try {
      Memory mem = this.computer.getMemory();
      byte[] data = new byte[end - start + 1];
      int pos = 0;
      for (int addr = start; addr <= end; addr++) {
        if (eDisassembler.read) {
          data[pos] = (byte)mem.readByte(addr);
        } else if (eDisassembler.any) {
          data[pos] = (byte)mem.readWriteByte(addr, eDisassembler.forcedbank, true);
        } else {
          data[pos] = (byte)mem.readWriteByte(addr);
        } 
        pos++;
      } 
      String result = Util.dumpBytes(data, 0, data.length, false, true, true);
      String[] res = result.split("\n");
      result = "";
      for (int i = 0; i < res.length; i++) {
        while (res[i].contains(";"))
          res[i] = res[i].substring(0, res[i].length() - 1); 
        res[i] = res[i].substring(0, res[i].length() - 1);
        result = result + res[i] + '\r' + '\n';
      } 
      this.text.setText(result);
      this.text.selectAll();
      this.text.copy();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void copyMemoryAsBasic(int start, int end) {
    try {
      String bascode = "10 '***********************************\r\n20 '*BASIC code generated with JavaCPC*\r\n30 '***********************************\r\n40 MEMORY &" + Util.hex((short)(start - 1)) + ":adr=&" + Util.hex((short)start) + "\r\n50 READ a$:IF a$=\"END\" THEN GOTO 70\r\n60 a$=\"&\"+a$:a=VAL(a$):POKE adr,a:adr=adr+1:GOTO 20\r\n70 PRINT\"All Data generated.\"\r\n80 PRINT\"SAVE as ,b,&" + Util.hex((short)start) + ",&" + Util.hex((short)end) + "\"\r\n90 END\r\n";
      int linenumber = 90;
      Memory mem = this.computer.getMemory();
      byte[] data = new byte[end - start + 1];
      int pos = 0;
      for (int addr = start; addr <= end; addr++) {
        if (eDisassembler.read) {
          data[pos] = (byte)mem.readByte(addr);
        } else if (eDisassembler.any) {
          data[pos] = (byte)mem.readWriteByte(addr, eDisassembler.forcedbank, true);
        } else {
          data[pos] = (byte)mem.readWriteByte(addr);
        } 
        pos++;
      } 
      String result = Util.dumpBytes(data, 0, data.length, false, true, true);
      String[] res = result.split("\n");
      for (int i = 0; i < res.length; i++) {
        while (res[i].contains(";"))
          res[i] = res[i].substring(0, res[i].length() - 1); 
        while (res[i].endsWith(" "))
          res[i] = res[i].substring(0, res[i].length() - 1); 
        while (res[i].startsWith(" "))
          res[i] = res[i].substring(1); 
        res[i] = res[i].replace(" ", ",");
        linenumber += 10;
        res[i] = linenumber + " DATA " + res[i];
        bascode = bascode + res[i] + '\r' + '\n';
      } 
      linenumber += 10;
      bascode = bascode + linenumber + " DATA END";
      this.text.setText(bascode);
      this.text.selectAll();
      this.text.copy();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void saveDisassembly() {
    saveDisassembly(eDisassembler.selStart, eDisassembler.selEnd);
  }
  
  public void copyDisassembly() {
    copyDisassembly(eDisassembler.selStart, eDisassembler.selEnd);
  }
  
  public void saveDisassembly(int start, int end) {
    File file = showSaveDialog("Save Disassembly");
    if (file != null) {
      String fname = file.getPath();
      if (!fname.toLowerCase().endsWith(".asm")) {
        fname = fname + ".asm";
        file = new File(fname);
      } 
      int[] addr = { start };
      try {
        Calendar cal = Calendar.getInstance();
        FileOutputStream io = new FileOutputStream(file);
        try {
          Disassembler diss = this.computer.getDisassembler();
          Memory mem = this.computer.getMemory();
          if (bWinape.isSelected()) {
            io.write(("                ;; JavaCPC disassembled binary\r\n                ;; disassembled from #" + Util.hex((short)start) + " to #" + Util.hex((short)end) + "\r\n                ;; " + cal.getTime() + "\r\n\r\n").getBytes());
          } else {
            io.write(("                ; JavaCPC disassembled binary\r\n                ; disassembled from #" + Util.hex((short)start) + " to #" + Util.hex((short)end) + "\r\n                ; " + cal.getTime() + "\r\n\r\n").getBytes());
          } 
          io.write(("                ORG     #" + Util.hex((short)start) + "\r\n\r\n").getBytes());
          while (addr[0] <= end) {
            String content = "                " + diss.disass(mem, addr, true, 31, 50);
            io.write((content + "\r\n").getBytes());
          } 
        } finally {
          io.close();
        } 
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
  }
  
  public void copyDisassembly(int start, int end) {
    int[] addr = { start };
    try {
      Calendar cal = Calendar.getInstance();
      String result = "";
      Disassembler diss = this.computer.getDisassembler();
      Memory mem = this.computer.getMemory();
      if (bWinape.isSelected()) {
        result = result + "                ;; JavaCPC disassembled binary\r\n                ;; disassembled from #" + Util.hex((short)start) + " to #" + Util.hex((short)end) + "\r\n                ;; " + cal.getTime() + "\r\n\r\n";
      } else {
        result = result + "                ; JavaCPC disassembled binary\r\n                ; disassembled from #" + Util.hex((short)start) + " to #" + Util.hex((short)end) + "\r\n                ; " + cal.getTime() + "\r\n\r\n";
      } 
      result = result + "                ORG     #" + Util.hex((short)start) + "\r\n\r\n";
      while (addr[0] <= end) {
        String content = "                " + diss.disass(mem, addr, true, 31, 50);
        result = result + content + "\r\n";
      } 
      this.text.setText(result);
      this.text.selectAll();
      this.text.copy();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  private void initComponents() {
    this.readwritegroup = new ButtonGroup();
    this.bBanks = new JComboBox();
    this.bRead = new JRadioButton("Read");
    this.bWrite = new JRadioButton("Any");
    this.bAny = new JRadioButton("Write");
    this.readwritegroup.add(this.bRead);
    this.readwritegroup.add(this.bAny);
    this.readwritegroup.add(this.bWrite);
    this.ppi = new ePPI();
    this.popupMenu = new JPopupMenu();
    this.mGoto = new JMenuItem();
    this.mSave = new JMenuItem();
    this.mOpenMulti = new JMenuItem();
    this.mFind = new JMenuItem();
    this.mCopy = new JMenuItem();
    this.mCopyHex = new JMenuItem();
    this.mCopyBasic = new JMenuItem();
    this.mBreak = new JMenuItem();
    this.mRemove = new JMenuItem();
    this.mRemoveAll = new JMenuItem();
    this.jPanel1 = new JPanel();
    this.jPanel2 = new JPanel();
    this.jPanel4 = new JPanel();
    this.jPanel5 = new JPanel();
    this.jPanelRegisters = new JPanel();
    this.jPanel2.setBorder(new BevelBorder(1));
    this.jPanel4.setBorder(new BevelBorder(1));
    this.jPanel5.setLayout(new BorderLayout());
    this.bRun = new JButton();
    this.bStop = new JButton();
    this.bGFX = new JButton();
    this.bSearch = new JButton();
    this.bBreaks = new JButton();
    this.bReset = new JButton();
    this.bPoints = new JCheckBox();
    this.bFollow = new JCheckBox();
    bWinape = new JCheckBox();
    this.bInst = new JCheckBox();
    this.bStep = new EButton();
    this.bStepOver = new EButton();
    this.lCycles = new JLabel();
    this.lCycleCount = new JTextField();
    this.eRegisters = new ERegisters();
    this.jSplitPane1 = new JSplitPane();
    this.jSplitPane2 = new JSplitPane();
    this.jSplitPane1.setFocusable(false);
    this.jSplitPane2.setFocusable(false);
    eDisassembler = new EDisassembler();
    eStackpointer = new EStackPointer();
    this.jScrollPane1 = new JScrollPane();
    eMemory = new EMemory();
    this.mFind.setText("Find...");
    this.popupMenu.add(this.mFind);
    this.mCopy.setText("Copy");
    this.popupMenu.add(this.mCopy);
    this.mCopyHex.setText("Copy as Hex-Data only");
    this.popupMenu.add(this.mCopyHex);
    this.mCopyBasic.setText("Generate BASIC code");
    this.popupMenu.add(this.mCopyBasic);
    this.mGoto.setText("Goto...");
    this.popupMenu.add(this.mGoto);
    this.mBreak.setText("Set breakpoint...");
    this.popupMenu.add(this.mBreak);
    this.mRemove.setText("Remove breakpoint...");
    this.popupMenu.add(this.mRemove);
    this.mRemoveAll.setText("Remove all breakpoints...");
    this.popupMenu.add(this.mRemoveAll);
    this.mSave.setText("Save...");
    this.mOpenMulti.setText("Open MultiDebugger here");
    this.popupMenu.add(this.mOpenMulti);
    this.popupMenu.add(this.mSave);
    setTitle("JavaCPC Debugger");
    this.jPanel1.setLayout(new BorderLayout());
    this.jPanel2.setLayout(new FlowLayout(0));
    this.jPanel4.setLayout(new FlowLayout(0));
    setBanks();
    this.bRead.setFocusable(false);
    this.bWrite.setFocusable(false);
    this.bAny.setFocusable(false);
    this.bBanks.setFocusable(false);
    this.jPanel2.add(this.bRead);
    this.jPanel2.add(this.bAny);
    this.jPanel2.add(this.bWrite);
    this.jPanel2.add(new JLabel("Bank:"));
    this.jPanel2.add(this.bBanks);
    JSeparator seppel = new JSeparator(1);
    seppel.setPreferredSize(new Dimension(4, 20));
    this.jPanel2.add(seppel);
    this.bRun.setText("Run");
    this.jPanel2.add(this.bRun);
    this.bStop.setText("Stop");
    this.jPanel2.add(this.bStop);
    this.bStep.setText("Step");
    this.jPanel2.add(this.bStep);
    this.bStepOver.setText("Step Over");
    this.jPanel2.add(this.bStepOver);
    this.bPoints.setText("Breakpoints");
    this.jPanel4.add(this.bPoints);
    this.bInst.setText("Break Instructions");
    this.jPanel4.add(this.bInst);
    this.bFollow.setText("Follow");
    bWinape.setText("Winape compatible disassembly");
    this.jPanel4.add(this.bFollow);
    this.jPanel4.add(bWinape);
    bWinape.setSelected(true);
    this.bGFX.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/ico/gfxviewer.gif")));
    this.bGFX.setBorder((Border)null);
    this.bBreaks.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/ico/breakpoint.gif")));
    this.bBreaks.setBorder((Border)null);
    this.bSearch.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/ico/search.gif")));
    this.bSearch.setBorder((Border)null);
    this.bSearch.setFocusPainted(false);
    this.bGFX.setFocusPainted(false);
    this.bBreaks.setFocusPainted(false);
    this.bSearch.setFocusable(false);
    this.bGFX.setFocusable(false);
    this.bBreaks.setFocusable(false);
    this.jPanel4.add(this.bBreaks);
    this.jPanel4.add(this.bGFX);
    this.jPanel1.add(this.jPanel2, "Center");
    this.jPanel1.add(this.jPanel4, "South");
    this.lCycles.setText("T");
    this.lCycleCount.setText("0");
    this.lCycleCount.setColumns(12);
    this.lCycleCount.setHorizontalAlignment(2);
    this.lCycleCount.setEditable(false);
    this.lCycleCount.setFocusable(false);
    this.lCycleCount.addMouseListener(this);
    this.bReset.setIcon(new ImageIcon(getClass().getResource("/jemu/ui/ico/reset.gif")));
    this.bReset.setText("");
    this.bReset.setBorder(new BevelBorder(0));
    add(this.jPanel1, "Last");
    this.eRegisters.setLayout((LayoutManager)null);
    this.jPanelRegisters.setLayout(new BorderLayout());
    JPanel jPanelE = new JPanel();
    jPanelE.add(this.lCycles);
    jPanelE.add(this.lCycleCount);
    jPanelE.add(this.bReset);
    jPanelE.setLayout(new FlowLayout(1));
    this.jPanelRegisters.add(this.eRegisters, "North");
    this.jPanel2.add(jPanelE, "Center");
    this.jPanelRegisters.add(this.ppi, "South");
    this.ppi.setVisible(true);
    add(this.jPanelRegisters, "After");
    this.jSplitPane1.setDividerLocation(200);
    this.jSplitPane1.setOrientation(0);
    this.jSplitPane1.setContinuousLayout(true);
    this.jSplitPane1.setOneTouchExpandable(true);
    this.jSplitPane2.setDividerLocation(405);
    this.jSplitPane2.setOrientation(1);
    this.jSplitPane2.setContinuousLayout(true);
    this.jSplitPane2.setOneTouchExpandable(true);
    eDisassembler.setComponentPopupMenu(this.popupMenu);
    eDisassembler.addMouseListener(this);
    eMemory.addMouseMotionListener(this);
    eDisassembler.addMouseMotionListener(this);
    eDisassembler.addKeyListener(this);
    eMemory.addKeyListener(this);
    this.jSplitPane2.setTopComponent(eDisassembler);
    this.jPanel5.add(new JLabel("  Stack"), "North");
    this.jPanel5.add(eStackpointer, "Center");
    this.jSplitPane2.setBottomComponent(this.jPanel5);
    eMemory.setComponentPopupMenu(this.popupMenu);
    this.jScrollPane1.setViewportView(eMemory);
    this.jSplitPane1.setLeftComponent(this.jSplitPane2);
    this.jSplitPane1.setRightComponent(this.jScrollPane1);
    add(this.jSplitPane1, "Center");
    pack();
  }
  
  public void mouseClicked(MouseEvent evt) {
    if (evt.getSource() == this.lCycleCount) {
      lCycleCountMouseClicked(evt);
    } else if (evt.getSource() == eDisassembler) {
      breakaddress = eDisassembler.getAddress(evt.getY());
      this.mouseY = breakaddress;
      eDisassemblerMouseClicked(evt);
    } 
  }
  
  public void mousePressed(MouseEvent evt) {}
  
  public void mouseReleased(MouseEvent evt) {}
  
  private void eDisassemblerMouseClicked(MouseEvent e) {
    if (e.getClickCount() == 2) {
      int addr = eDisassembler.getAddress(e.getY());
      this.mouseY = addr;
      System.out.println("RUN to " + Util.hex(addr));
      if (addr != -1) {
        this.computer.setRunToAddress(addr);
        this.computer.start();
      } 
    } 
  }
  
  public void clearBreakpoint() {
    try {
      String[] breaks = getBreakpoints();
      int g = this.testpoints.points.getSelectedIndex();
      if (g < 0)
        return; 
      String adr = breaks[g];
      while (adr.contains(" "))
        adr = adr.substring(0, adr.length() - 1); 
      int address = Util.hexValue(adr);
      Breakpoint bp = this.breakpoints.get(Integer.valueOf(address));
      if (bp != null) {
        this.computer.getProcessor().detachProgramCounterObserver((ProgramCounterObserver)bp);
        this.breakpoints.remove(Integer.valueOf(address));
        System.out.println("StopBreakpoint removed at &" + Util.hex(address));
      } 
      updateBreakpoints();
      eDisassembler.repaint();
    } catch (Exception exception) {}
  }
  
  public void setCycles() {
    try {
      String[] breaks = getBreakpoints();
      int g = this.testpoints.points.getSelectedIndex();
      if (g < 0)
        return; 
      String adr = breaks[g];
      while (adr.contains(" "))
        adr = adr.substring(0, adr.length() - 1); 
      int address = Util.hexValue(adr);
      Breakpoint bp = this.breakpoints.get(Integer.valueOf(address));
      if (bp != null) {
        String str = JOptionPane.showInputDialog(null, "Cycles:", "Enter Cycles", 3);
        if (str != null) {
          int cyc = Integer.parseInt(str);
          this.cycles[address] = cyc;
          bp.setCycles(cyc);
        } 
      } 
      updateBreakpoints();
      eDisassembler.repaint();
    } catch (Exception exception) {}
  }
  
  public void setCycles(int address) {
    try {
      Breakpoint bp = this.breakpoints.get(Integer.valueOf(address));
      if (bp != null) {
        String str = JOptionPane.showInputDialog(null, "Cycles: ", "Enter Cycles", 1);
        if (str != null) {
          int cyc = Integer.parseInt(str);
          this.cycles[address] = cyc;
          bp.setCycles(cyc);
        } 
      } 
      updateBreakpoints();
      eDisassembler.repaint();
    } catch (Exception exception) {}
  }
  
  public void removeAllBreakpoints() {
    if (Switches.breakpoints && !this.breakpoints.isEmpty()) {
      Processor p = this.computer.getProcessor();
      for (Breakpoint bp : this.breakpoints.values()) {
        this.cycles[bp.getAddress()] = 0;
        bp.setCycles(0);
        p.detachProgramCounterObserver((ProgramCounterObserver)bp);
      } 
      this.breakpoints.clear();
      System.out.println("StopBreakpoint all removed");
      updateBreakpoints();
      eDisassembler.repaint();
    } 
  }
  
  public void continueAndReset() {
    while (this.computer == null) {
      try {
        Thread.sleep(10L);
      } catch (Exception exception) {}
    } 
    this.computer.start();
    this.computer.reset();
  }
  
  private void resetCycles() {
    this.startCycles = this.computer.getProcessor().getCycles();
    this.lCycleCount.setText("0");
  }
  
  private void lCycleCountMouseClicked(MouseEvent e) {
    if (e.getClickCount() == 2)
      resetCycles(); 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\Debugger.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */