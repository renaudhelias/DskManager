package jemu.ui;

import java.util.Properties;
import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Mail {
  private static final String SMTP_HOST_NAME = "cpc-live.com";
  
  private static final String FROM_MAIL = "javacpc@cpc-live.com";
  
  private static final int[] SMTP_LOC = new int[] { 100, 101, 118, 56, 57, 52, 52, 57, 54 };
  
  public static void main(String[] args) throws Exception {
    (new Mail()).SendMail("This is a test", "webmaster@cpc-live.com", "TestMail");
  }
  
  public boolean SendMail(String content, String to, String subject) {
    try {
      Properties props = new Properties();
      props.put("mail.transport.protocol", "smtp");
      props.put("mail.smtp.host", "cpc-live.com");
      props.put("mail.smtp.auth", "true");
      Authenticator auth = new SMTPAuthenticator();
      Session mailSession = Session.getDefaultInstance(props, auth);
      Transport transport = mailSession.getTransport();
      MimeMessage message = new MimeMessage(mailSession);
      message.setContent(content, "text/plain");
      message.setSubject(subject);
      message.setFrom((Address)new InternetAddress("javacpc@cpc-live.com"));
      message.addRecipient(Message.RecipientType.TO, (Address)new InternetAddress(to));
      transport.connect();
      transport.sendMessage((Message)message, message
          .getRecipients(Message.RecipientType.TO));
      transport.close();
      if (subject.equals("JavaCPC registration"))
        reportMail(content, to); 
      return true;
    } catch (Exception e) {
      return false;
    } 
  }
  
  public void reportMail(String content, String to) {
    try {
      content = to + "\n" + content;
      Properties props = new Properties();
      props.put("mail.transport.protocol", "smtp");
      props.put("mail.smtp.host", "cpc-live.com");
      props.put("mail.smtp.auth", "true");
      Authenticator auth = new SMTPAuthenticator();
      Session mailSession = Session.getDefaultInstance(props, auth);
      Transport transport = mailSession.getTransport();
      MimeMessage message = new MimeMessage(mailSession);
      message.setContent(content, "text/plain");
      message.setSubject("JavaCPC Registration");
      message.setFrom((Address)new InternetAddress("javacpc@cpc-live.com"));
      message.addRecipient(Message.RecipientType.TO, (Address)new InternetAddress("webmaster@cpc-live.com"));
      transport.connect();
      transport.sendMessage((Message)message, message
          .getRecipients(Message.RecipientType.TO));
      transport.close();
    } catch (Exception exception) {}
  }
  
  private class SMTPAuthenticator extends Authenticator {
    private SMTPAuthenticator() {}
    
    public PasswordAuthentication getPasswordAuthentication() {
      String u = "javacpc@cpc-live.com";
      String p = "";
      for (int i = 0; i < 9; i++)
        p = p + (char)Mail.SMTP_LOC[i]; 
      return new PasswordAuthentication(u, p);
    }
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\Mail.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */