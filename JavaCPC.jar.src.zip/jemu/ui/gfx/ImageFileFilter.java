package jemu.ui.gfx;

import java.io.File;
import javax.swing.filechooser.FileFilter;

public class ImageFileFilter extends FileFilter {
  public boolean accept(File file) {
    String fileName = file.getName();
    fileName = fileName.toLowerCase();
    return (file.isDirectory() || fileName
      .endsWith(".png") || fileName
      .endsWith(".gif") || fileName
      .endsWith(".jpg") || fileName
      .endsWith(".bmp"));
  }
  
  public String getDescription() {
    return "Supported graphic formats (GIF, PNG, JPG, BMP)";
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\gfx\ImageFileFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */