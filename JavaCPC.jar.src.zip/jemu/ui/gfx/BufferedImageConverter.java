package jemu.ui.gfx;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.image.BufferedImage;

public class BufferedImageConverter {
  public static BufferedImage createBufferedImage(Image imageIn, Component comp) {
    return createBufferedImage(imageIn, 2, comp);
  }
  
  public static BufferedImage createBufferedImage(Image imageIn, int imageType, Component comp) {
    MediaTracker mt = new MediaTracker(comp);
    mt.addImage(imageIn, 0);
    try {
      mt.waitForID(0);
    } catch (InterruptedException interruptedException) {}
    BufferedImage bufferedImageOut = new BufferedImage(imageIn.getWidth(null), imageIn.getHeight(null), imageType);
    Graphics g = bufferedImageOut.getGraphics();
    g.drawImage(imageIn, 0, 0, null);
    return bufferedImageOut;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\gfx\BufferedImageConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */