package jemu.ui;

import com.easycapture.recorder.Control;
import com.easycapture.recorder.Recorder;
import com.jhlabs.image.EmbossFilter;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.awt.image.MemoryImageSource;
import java.awt.image.RescaleOp;
import java.awt.image.WritableRaster;
import java.io.File;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import jemu.core.Util;
import jemu.core.device.sound.YMControl;
import jemu.settings.Settings;
import jemu.system.cpc.CPC;
import jemu.system.cpc.GateArray;
import jemu.system.cpc.GraphicsViewer;

public class Display extends JPanel {
  public void repaint() {}
  
  static FileDialog over = new FileDialog(new JFrame(), "Import Overlay graphic", 0);
  
  static String overfile;
  
  public static void LoadOverlay() {
    if (overlay != null) {
      UnloadOverlay();
      return;
    } 
    over.setVisible(true);
    String a = over.getDirectory();
    String b = over.getFile();
    if (b == null)
      return; 
    a = a + b;
    Overlay(a);
  }
  
  static Float trans = Float.valueOf(0.5F);
  
  static void Overlay(String a) {
    overfile = a;
    File f = new File(a);
    try {
      BufferedImage buf = ImageIO.read(f);
      overlay = new BufferedImage(384, 272, 2);
      Graphics2D g2 = overlay.createGraphics();
      g2.setComposite(AlphaComposite.getInstance(3, trans.floatValue()));
      System.out.println(trans);
      int xx = 0;
      int yy = 0;
      if (noover) {
        xx = 32;
        yy = 40;
      } 
      g2.drawImage(buf, xx, yy, noover ? 320 : 384, noover ? 200 : 272, null);
    } catch (Exception exception) {}
  }
  
  static void ToggleOver() {
    noover = !noover;
    Overlay(overfile);
  }
  
  static boolean noover = true;
  
  public static BufferedImage overlay;
  
  public static void IncTrans() {
    if (trans.floatValue() < 0.975F) {
      trans = Float.valueOf(trans.floatValue() + 0.025F);
      Overlay(overfile);
    } 
  }
  
  public static void DecTrans() {
    if (trans.floatValue() > 0.025F) {
      trans = Float.valueOf(trans.floatValue() - 0.025F);
      Overlay(overfile);
    } 
  }
  
  public static void UnloadOverlay() {
    overlay = null;
  }
  
  public boolean joyenabled = false;
  
  public CurvaturedScreen curvature;
  
  public static boolean PAL = false;
  
  public int showdrives = 0;
  
  public int showtape = 0;
  
  public int showsna = 0;
  
  public Recorder mov = new Recorder();
  
  public static int formaterror = 0;
  
  public static boolean doublesize = true;
  
  boolean odd;
  
  public static boolean interlace = false;
  
  public static boolean superPAL = false;
  
  public String zipinfo = "";
  
  public int zipcount = 0;
  
  public boolean showDrive = false;
  
  protected int flashkey = 0;
  
  public static int noisecount = 200;
  
  public float co;
  
  public float cn;
  
  public float cm;
  
  public float cl;
  
  public int ck;
  
  public int cj;
  
  public int ci;
  
  public int ch = 50;
  
  public int zoom = 1;
  
  public static boolean lowperformance;
  
  public int mouseX;
  
  public int mouseY;
  
  int opIndex = 4;
  
  public static boolean remask = false;
  
  public static boolean filter_dosbox = false;
  
  public static boolean filter_dosboxb = false;
  
  public static boolean filter_eagle = false;
  
  public static boolean filter_advmame = false;
  
  public static boolean filter_eagle_smooth = false;
  
  public static boolean filter_advmame_smooth = false;
  
  public static boolean filter_embossed = false;
  
  BufferedImage laceimage;
  
  public static int turbotimer;
  
  public static int audio;
  
  public static int fader;
  
  protected boolean floppyturbo = false;
  
  public static int skin = 1;
  
  protected boolean printjob = false;
  
  final URL sna = getClass().getResource("resources/camera.png");
  
  final Image snaimg = getToolkit().getImage(this.sna);
  
  final URL tap = getClass().getResource("resources/cassette.png");
  
  final Image tapeimg = getToolkit().getImage(this.tap);
  
  final URL driva = getClass().getResource("resources/driveAL.png");
  
  final Image drivea = getToolkit().getImage(this.driva);
  
  final URL driv3a = getClass().getResource("resources/driveA.png");
  
  final Image drive3a = getToolkit().getImage(this.driv3a);
  
  final URL drivb = getClass().getResource("resources/driveBL.png");
  
  final Image driveb = getToolkit().getImage(this.drivb);
  
  final URL driv3b = getClass().getResource("resources/driveB.png");
  
  final Image drive3b = getToolkit().getImage(this.driv3b);
  
  final URL drivam = getClass().getResource("resources/c-75.png");
  
  final Image driveam = getToolkit().getImage(this.drivam);
  
  final URL drivbm = getClass().getResource("resources/p-75.png");
  
  final Image drivebm = getToolkit().getImage(this.drivbm);
  
  final URL dotmat = getClass().getResource("dotmask2.png");
  
  final Image dotmatrix = getToolkit().getImage(this.dotmat);
  
  final URL mobo = getClass().getResource("monborder.png");
  
  public final Image monbord = getToolkit().getImage(this.mobo);
  
  final URL mobo2 = getClass().getResource("monborder2.png");
  
  public final Image monbord2 = getToolkit().getImage(this.mobo2);
  
  final URL cursorim = getClass().getResource("image/crosshair.gif");
  
  final Image lightGun = getToolkit().getImage(this.cursorim);
  
  final Image imagec;
  
  final boolean debug = true;
  
  final URL pauses = getClass().getResource("image/pause_small.png");
  
  final Image pauseds = getToolkit().getImage(this.pauses);
  
  final URL forma = getClass().getResource("image/formaterror.png");
  
  final Image formaterr = getToolkit().getImage(this.forma);
  
  final URL pause = getClass().getResource("image/pause.png");
  
  final Image paused = getToolkit().getImage(this.pause);
  
  final URL recym = getClass().getResource("image/mix_record.png");
  
  final Image ymrec = getToolkit().getImage(this.recym);
  
  final URL playym = getClass().getResource("image/player_play.png");
  
  final Image ymplay = getToolkit().getImage(this.playym);
  
  final URL ymmode = getClass().getResource("image/ymmode.png");
  
  final Image YMmode = getToolkit().getImage(this.ymmode);
  
  final URL ymmode2 = getClass().getResource("image/cpc.png");
  
  final Image YMmode2 = getToolkit().getImage(this.ymmode2);
  
  final URL smallball = getClass().getResource("image/ball_small.png");
  
  final Image ball = getToolkit().getImage(this.smallball);
  
  final URL bigball = getClass().getResource("image/ball.png");
  
  final Image ballb = getToolkit().getImage(this.bigball);
  
  final URL bball = getClass().getResource("image/ball3.png");
  
  final Image ballbb = getToolkit().getImage(this.bball);
  
  final URL kplayb = getClass().getResource("image/keyplay_big.png");
  
  final Image playb = getToolkit().getImage(this.kplayb);
  
  final URL krecb = getClass().getResource("image/keyrec_big.png");
  
  final Image recb = getToolkit().getImage(this.krecb);
  
  final URL kplays = getClass().getResource("image/keyplay_small.png");
  
  final Image plays = getToolkit().getImage(this.kplays);
  
  final URL krecs = getClass().getResource("image/keyrec_small.png");
  
  final Image recs = getToolkit().getImage(this.krecs);
  
  final Cursor blankCursor;
  
  final Cursor gunCursor;
  
  public static String title = "";
  
  public static String author = "";
  
  public static String creator = "";
  
  long mLastFPSTime;
  
  int mNextFPS;
  
  public static int mCurrFPS;
  
  final URL Mask1 = getClass().getResource("2.png");
  
  final Image mask1 = getToolkit().getImage(this.Mask1);
  
  final URL i3d = getClass().getResource("3d.png");
  
  final Image i3dmask = getToolkit().getImage(this.i3d);
  
  final URL Mask3 = getClass().getResource("image/FinalTele5.png");
  
  final Image mask3 = getToolkit().getImage(this.Mask3);
  
  Image mask = this.mask1;
  
  public static boolean scaneffect = false;
  
  public static boolean horizontal = true;
  
  boolean masked = false;
  
  private static final long serialVersionUID = 1L;
  
  public static int left = 0;
  
  public static int right = 0;
  
  protected boolean scanlines;
  
  protected boolean drawlines;
  
  protected boolean showeffect;
  
  public static int showpause = 0;
  
  public static Color FADE = new Color(0, 0, 0, 0);
  
  public static Color LED = new Color(255, 0, 0, 64);
  
  public static Color GREEN = new Color(0, 255, 0, 64);
  
  public static Color GREEN_BORDER = new Color(0, 144, 0, 64);
  
  public static Color LED_BORDER = new Color(144, 0, 0, 64);
  
  public static Color LED_OFF = new Color(144, 0, 0);
  
  public static Color WHITEA = new Color(255, 255, 255);
  
  public static Color BLACKA = new Color(0, 0, 0);
  
  public static Color SCAN = new Color(0, 0, 0, 96);
  
  public static Color SCAN_DARK = new Color(0, 0, 0, 144);
  
  public static Color SCAN_MED = new Color(0, 0, 0, 128);
  
  public static Color megadark = new Color(0, 0, 0, 176);
  
  public static Color TRANS = new Color(255, 255, 255, 176);
  
  public static Color TRANSBLACK = new Color(0, 0, 0, 64);
  
  public static Color[] RGB = new Color[] { new Color(255, 0, 0, 48), new Color(0, 255, 0, 48), new Color(0, 0, 255, 48) };
  
  int rgbcount = 0;
  
  public static final Dimension SCALE_1 = new Dimension(1, 1);
  
  public static final Dimension SCALE_2 = new Dimension(2, 2);
  
  public static final Dimension SCALE_1x2 = new Dimension(1, 2);
  
  public static BufferedImage image;
  
  protected WritableRaster raster;
  
  protected WritableRaster rasterb;
  
  protected WritableRaster mameraster;
  
  public static int[] pixels;
  
  protected int imageWidth;
  
  protected int imageHeight;
  
  protected int scaleWidth;
  
  protected int scaleHeight;
  
  protected int scaleW;
  
  protected int scaleH;
  
  public static Rectangle imageRect = new Rectangle();
  
  public static Rectangle sourceRect = null;
  
  protected boolean sameSize;
  
  public static boolean painted = false;
  
  public int framecount = 0;
  
  public static boolean truecap;
  
  boolean halfframe = false;
  
  public static int initgfxviewer = 0;
  
  Control MOVControl;
  
  int oldX;
  
  int oldY;
  
  public static boolean record;
  
  Kernel kernel;
  
  BufferedImageOp op;
  
  BufferedImage emboss;
  
  boolean scanl;
  
  boolean uscanl;
  
  boolean rasterChanged;
  
  boolean lowp;
  
  int pix;
  
  int cr;
  
  int cg;
  
  int cb;
  
  int cbr;
  
  boolean up;
  
  boolean old3d;
  
  public void requestFocus() {
    super.requestFocus();
    if (this.curvature != null && use3d)
      SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              Display.this.curvature.screen3D.requestFocus();
            }
          }); 
  }
  
  public void startcap() {
    Recorder.doMov();
    record = true;
  }
  
  public void stopcap() {
    record = false;
    Recorder.stopMov();
  }
  
  public void setImageSize(Dimension size, Dimension scale) {
    this.imageWidth = size.width;
    if (doublesize) {
      this.imageHeight = size.height * 2;
    } else {
      this.imageHeight = size.height;
    } 
    if (this.oldX != this.imageWidth || image == null) {
      image = new BufferedImage(this.imageWidth, this.imageHeight, 1);
      this.laceimage = new BufferedImage(this.imageWidth, this.imageHeight, 1);
      image.setAccelerationPriority(1.0F);
      this.laceimage.setAccelerationPriority(1.0F);
    } 
    this.oldX = this.imageWidth;
    this.raster = image.getRaster();
    pixels = new int[this.imageWidth * this.imageHeight];
    for (int i = 0; i < pixels.length; i++)
      pixels[i] = -16777216; 
    if (scale == null)
      scale = SCALE_1; 
    this.scaleWidth = this.imageWidth * scale.width;
    this.scaleHeight = this.imageHeight * scale.height;
    this.scaleW = this.scaleWidth;
    this.scaleH = this.scaleHeight;
    checkSize();
    Graphics g = getGraphics();
    if (g != null) {
      size = getSize();
      g.setColor(getBackground());
      g.fillRect(0, 0, size.width, size.height);
      paint(g);
      g.dispose();
    } 
  }
  
  public void setBounds(int x, int y, int width, int height) {
    super.setBounds(x, y, width, height);
    if (this.curvature != null)
      this.curvature.setBounds(x, y, width, height); 
    checkSize();
  }
  
  protected void checkDouble() {
    if (Switches.doublesize == true) {
      this.scaleWidth = this.scaleW * 2;
      if (doublesize) {
        this.scaleHeight = this.scaleH;
      } else {
        this.scaleHeight = this.scaleH * 2;
      } 
    } 
    if (Switches.triplesize == true) {
      this.scaleWidth = this.scaleW * 3;
      if (doublesize) {
        this.scaleHeight = this.scaleH * 3 / 2;
      } else {
        this.scaleHeight = this.scaleH * 3;
      } 
    } 
    if (!Switches.triplesize && 
      !Switches.doublesize) {
      this.scaleWidth = this.scaleW;
      if (doublesize) {
        this.scaleHeight = this.scaleH / 2;
      } else {
        this.scaleHeight = this.scaleH;
      } 
    } 
  }
  
  public void setCursor() {
    if (Switches.lightGun) {
      setCursor(this.gunCursor);
    } else if (Desktop.hideMouse.isSelected()) {
      setCursor(this.blankCursor);
    } else {
      setCursor(Cursor.getDefaultCursor());
    } 
  }
  
  public void changePerformance() {
    this.copimage = null;
    if (Switches.mask) {
      this.mask = this.mask3;
    } else {
      this.mask = this.mask1;
    } 
    if (lowperformance) {
      LED = new Color(255, 0, 0);
      GREEN = new Color(0, 255, 0);
      GREEN_BORDER = new Color(0, 144, 0);
      LED_BORDER = new Color(144, 0, 0);
      SCAN = new Color(0, 0, 0);
      TRANS = new Color(255, 255, 255);
      TRANSBLACK = new Color(0, 0, 0);
    } else {
      LED = new Color(255, 0, 0, 64);
      GREEN = new Color(0, 255, 0, 64);
      GREEN_BORDER = new Color(0, 144, 0, 64);
      LED_BORDER = new Color(144, 0, 0, 64);
      TRANS = new Color(255, 255, 255, 176);
      TRANSBLACK = new Color(0, 0, 0, 64);
      if (Switches.monitormode == 0 || Switches.monitormode == 1 || Switches.monitormode == 5) {
        SCAN = new Color(0, 0, 0, 80);
      } else {
        SCAN = new Color(0, 0, 0, 80);
      } 
    } 
  }
  
  protected void checkSize() {
    checkDouble();
    Dimension size = getSize();
    Insets insets = getInsets();
    int clientWidth = size.width - insets.left - insets.right;
    int clientHeight = size.height - insets.top - insets.bottom;
    if (Switches.stretch) {
      imageRect = new Rectangle(insets.left + (clientWidth - this.scaleWidth) / 2, insets.top + (clientHeight - this.scaleHeight) / 2, this.scaleWidth, this.scaleHeight);
    } else {
      imageRect = new Rectangle(insets.left, insets.top, clientWidth, clientHeight);
      this.sameSize = (imageRect.width == this.imageWidth && imageRect.height == this.imageHeight);
    } 
  }
  
  public int[] getPixels() {
    return pixels;
  }
  
  public void setSize(int x, int y) {
    super.setSize(x, y);
    if (this.curvature != null)
      this.curvature.setSize(x, y); 
    setPreferredSize(new Dimension(x, y));
  }
  
  public void setPreferredSize(Dimension d) {
    super.setPreferredSize(d);
    if (this.curvature != null)
      this.curvature.setPreferredSize(d); 
  }
  
  public Display() {
    this.kernel = new Kernel(3, 3, new float[] { -2.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 2.0F });
    this.op = new ConvolveOp(this.kernel);
    this.cr = 900;
    this.cg = 900;
    this.cb = 900;
    this.cbr = 900;
    this.up = false;
    this.hadcap = false;
    this.usepixels = false;
    this.embossFilter = new EmbossFilter();
    this.testfilter = true;
    this.pixoffset = 0;
    this.div = 5.0D;
    this.mamepixels = new int[104448];
    this.mamepixelsmode0 = new int[52224];
    this.CPCpixel = 0;
    this.lum = 30;
    this.rgb = new int[3];
    this.count = 0;
    this.rtable = new int[256];
    this.gtable = new int[256];
    this.btable = new int[256];
    this.gunImage = new BufferedImage(384, 272, 1);
    this.glowBuffer = new double[3];
    this.wait = 0;
    this.screenshot = 0;
    this.doScreening = false;
    this.showzoom = 0;
    this.zoomfactor = "";
    this.threeinch = true;
    this.disk1 = "";
    this.disk2 = "";
    this.disk3 = "";
    this.disk4 = "";
    this.disk5 = "";
    this.bi = new BufferedImage(384, 272, 2);
    this.ge = this.bi.getGraphics();
    this.scales = new float[] { 0.04F, 0.04F, 0.04F, 0.03F };
    this.offsets = new float[4];
    this.rop = new RescaleOp(this.scales, this.offsets, null);
    this.xpos = 10;
    this.update = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          Display.this.healthLine();
        }
      };
    this.healthLine = new Timer(250, this.update);
    int[] pixelsc = new int[256];
    this.usepixels = Settings.getBoolean("3d_acceleration", false);
    this.imagec = Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(16, 16, pixelsc, 0, 16));
    this.blankCursor = Toolkit.getDefaultToolkit().createCustomCursor(this.imagec, new Point(0, 0), "invisibleCursor");
    this.gunCursor = Toolkit.getDefaultToolkit().createCustomCursor(this.lightGun, new Point(15, 15), "gunCursor");
    enableEvents(4L);
    setFocusTraversalKeysEnabled(false);
    setRequestFocusEnabled(true);
    setDoubleBuffered(true);
    this.healthLine.start();
  }
  
  public void setSourceRect(Rectangle value) {
    sourceRect = value;
  }
  
  public static boolean initcap = false;
  
  boolean hadcap;
  
  public static int capX = 20;
  
  public static int capY = 20;
  
  public static int capW = 320;
  
  public static int capH = 240;
  
  boolean usepixels;
  
  int skip3d;
  
  int skippixels;
  
  public static int[] black;
  
  boolean skip;
  
  EmbossFilter embossFilter;
  
  boolean testfilter;
  
  int pixoffset;
  
  int off;
  
  boolean togglered;
  
  int splitrgb;
  
  double div;
  
  protected int[] mamepixels;
  
  protected int[] mamepixelsmode0;
  
  int CPCpixel;
  
  int CPC_X_pixel;
  
  int CPC_Y_pixel;
  
  boolean pix1;
  
  boolean pix2;
  
  boolean pix3;
  
  boolean pix4;
  
  int A;
  
  int B;
  
  int C;
  
  int D;
  
  int E;
  
  int F;
  
  int G;
  
  int H;
  
  int I;
  
  int E0;
  
  int E1;
  
  int E2;
  
  int E3;
  
  int xPixel;
  
  int yPixel;
  
  int lum;
  
  int[] rgb;
  
  int addr;
  
  int addg;
  
  int addb;
  
  int red;
  
  int green;
  
  int blue;
  
  int count;
  
  final int[] rtable;
  
  final int[] gtable;
  
  final int[] btable;
  
  int m;
  
  int offset;
  
  int lastPix;
  
  public int splud;
  
  public void updateImage(boolean wait) {
    if (CPC.YM_Play && use3d && !this.usepixels) {
      this.skip3d++;
      if (this.skip3d < 4) {
        balls(this.ge, this.driveam, this.drivebm, this.driveam);
        balls(this.ge, this.driveam, this.drivebm, this.driveam);
        balls(this.ge, this.driveam, this.drivebm, this.driveam);
        doTouchFPS();
        painted = true;
        return;
      } 
      this.skip3d = 0;
    } 
    if (this.hadcap != initcap) {
      this.hadcap = initcap;
      if (this.hadcap) {
        int[] area = GateArray.cpc.getGateArray().getField();
        capX = area[0];
        capY = area[2];
        capW = area[1] - area[0];
        capH = area[3] - area[2];
        System.out.println(capX + "," + capY + "," + capW + "," + capH);
      } 
    } 
    if (initcap) {
      if (doublesize)
        checkOutput(); 
      checkInterlace();
      this.raster.setDataElements(0, 0, this.imageWidth, this.imageHeight, pixels);
      Graphics p = image.createGraphics();
      p.setColor(new Color(Util.random(255), Util.random(255), Util.random(255), 180));
      p.drawRect(capX, capY, capW, capH);
      repaint(0L, imageRect.x, imageRect.y, imageRect.width, imageRect.height);
      return;
    } 
    if (this.old3d != use3d) {
      System.out.println("Display changed to " + (use3d ? "3d display" : "2d display"));
      this.old3d = use3d;
      painted = true;
    } 
    if (!painted)
      return; 
    if (Desktop.level.isShowing() && filter_dosboxb != Desktop.level.isEnabled())
      Desktop.level.setEnabled(filter_dosboxb); 
    if (this.cr != this.addr) {
      this.cr = this.addr;
      this.up = true;
    } 
    if (this.cg != this.addg) {
      this.cg = this.addg;
      this.up = true;
    } 
    if (this.cb != this.addb) {
      this.cb = this.addb;
      this.up = true;
    } 
    if (this.cbr != fader) {
      this.cbr = fader;
      this.up = true;
    } 
    if (this.up)
      init(); 
    this.up = false;
    this.count++;
    if (this.count == 5)
      try {
        this.count = 0;
        if (this.addr != Desktop.red.getValue())
          this.addr = Desktop.red.getValue(); 
        if (this.addg != Desktop.green.getValue())
          this.addg = Desktop.green.getValue(); 
        if (this.addb != Desktop.blue.getValue())
          this.addb = Desktop.blue.getValue(); 
      } catch (Exception exception) {} 
    if (Desktop.brenabled)
      for (int i = 0; i < pixels.length; i++)
        pixels[i] = putRGB(pixels[i]);  
    painted = false;
    if (imageRect.width != 0 && imageRect.height != 0 && (isVisible() || this.curvature.isVisible())) {
      if (doublesize)
        checkOutput(); 
      checkInterlace();
      this.raster.setDataElements(0, 0, this.imageWidth, this.imageHeight, pixels);
      if (filter_embossed)
        this.embossFilter.filter(image, image); 
      if (this.showtape > 0) {
        Graphics g = image.createGraphics();
        this.showtape--;
        g.drawImage(this.tapeimg, 128, 50, null);
        g.setFont(new Font("Monospaced", 1, 18));
        g.setColor(new Color(0, 0, 0, 200));
        g.drawString(this.disk1, 168, 212);
        g.drawString(this.disk2, 168, 235);
        g.setFont(new Font("Arial", 1, 26));
        g.drawString(this.disk5, 420, 361);
      } 
      if (this.showsna > 0) {
        Graphics g = image.createGraphics();
        this.showsna--;
        g.drawImage(this.snaimg, 128, 50, null);
      } 
      if (this.showdrives > 0) {
        Graphics g = image.createGraphics();
        this.showdrives--;
        if (JEMU.toDriveB) {
          if (this.threeinch) {
            g.drawImage(this.drive3b, 380, 40, null);
            g.setFont(new Font("Monospaced", 1, 16));
            g.setColor(new Color(0, 0, 0, 200));
            g.drawString(this.disk1, 408, 394);
            g.drawString(this.disk2, 408, 412);
            g.drawString(this.disk3, 408, 430);
          } else {
            g.drawImage(this.driveb, 380, 100, null);
            g.setFont(new Font("Monospaced", 1, 18));
            g.setColor(new Color(0, 0, 0, 200));
            int i = 272;
            i += 25;
            g.drawString(this.disk1, 424, i);
            i += 25;
            g.drawString(this.disk2, 424, i);
            i += 25;
            g.drawString(this.disk3, 424, i);
            i += 25;
            g.drawString(this.disk4, 424, i);
            i += 25;
            g.drawString(this.disk5, 424, i);
          } 
        } else if (this.threeinch) {
          g.drawImage(this.drive3a, 20, 40, null);
          g.setFont(new Font("Monospaced", 1, 16));
          g.setColor(new Color(0, 0, 0, 200));
          g.drawString(this.disk1, 48, 394);
          g.drawString(this.disk2, 48, 412);
          g.drawString(this.disk3, 48, 430);
        } else {
          g.drawImage(this.drivea, 20, 100, null);
          g.setFont(new Font("Monospaced", 1, 18));
          g.setColor(new Color(0, 0, 0, 200));
          int i = 272;
          i += 25;
          g.drawString(this.disk1, 64, i);
          i += 25;
          g.drawString(this.disk2, 64, i);
          i += 25;
          g.drawString(this.disk3, 64, i);
          i += 25;
          g.drawString(this.disk4, 64, i);
          i += 25;
          g.drawString(this.disk5, 64, i);
        } 
      } 
    } 
    if (use3d && this.curvature != null && this.usepixels) {
      if (scaneffect && !lowperformance) {
        this.showeffect = true;
        this.masked = false;
      } else {
        this.showeffect = false;
        this.masked = false;
      } 
      StatusPanel.fps.setText("" + mCurrFPS);
      if (superPAL) {
        ConvolveOp cop = new ConvolveOp(new Kernel(3, 3, BLUR3x3), 1, null);
        checkCOPimage();
        Graphics2D g3 = this.copimage.createGraphics();
        g3.drawImage(image, cop, 0, 0);
        image.getGraphics().drawImage(this.copimage, imageRect.x, imageRect.y, imageRect.width, imageRect.height, null);
      } 
      if (skipframes)
        this.skip = !this.skip; 
      if (!this.skip) {
        this.curvature.update(pixels, this.showeffect);
      } else {
        painted = true;
      } 
    } else if (use3d && this.curvature != null && !this.usepixels) {
      if (use3d && this.curvature != null && !this.usepixels) {
        repaint(0L, imageRect.x, imageRect.y, imageRect.width, imageRect.height);
        paintImage(image.getGraphics());
        this.curvature.update(image, scaneffect);
      } 
    } else {
      repaint(0L, imageRect.x, imageRect.y, imageRect.width, imageRect.height);
    } 
    try {
      if (record || CPC.playSNP || CPC.StoreSNP || (!doublesize && wait) || (ScreenCapture.record && ScreenCapture.vsync.isSelected()))
        waitPainted(); 
    } catch (Exception exception) {}
    doTouchFPS();
    if (!use3d) {
      if (black == null || black.length != pixels.length) {
        black = new int[pixels.length];
        for (int i = 0; i < black.length; i++)
          black[i] = 0; 
      } 
      System.arraycopy(black, 0, pixels, 0, black.length);
    } 
  }
  
  protected void checkOutput() {
    if (lowperformance != this.lowp) {
      for (int i = 0; i < pixels.length; i++)
        pixels[i] = 0; 
      this.lowp = lowperformance;
    } 
    if (lowperformance) {
      fullRender();
      return;
    } 
    if (JEMU.large) {
      if (filter_advmame) {
        AdvMameFilter2x(false);
        if (PAL)
          PALRender(); 
      } else if (filter_advmame_smooth) {
        AdvMameFilter2x(true);
        if (PAL)
          PALRender(); 
      } else if (filter_eagle) {
        EagleFilter2x(false);
        if (PAL)
          PALRender(); 
      } else if (filter_eagle_smooth) {
        EagleFilter2x(true);
        if (PAL)
          PALRender(); 
      } else if (filter_dosbox) {
        CRTFilter3();
        if (PAL)
          PALRender(); 
      } else if (filter_dosboxb) {
        CRTFilter2();
        if (PAL)
          PALRender(); 
      } else if (!PAL) {
        fullRender();
      } else {
        PALRender();
      } 
    } else {
      fullRender();
      if (PAL)
        PALRender(); 
    } 
    if (pixels != null && this.scanl != this.scanlines) {
      for (int i = 0; i < pixels.length; i++)
        pixels[i] = 0; 
      this.scanl = this.scanlines;
    } 
    if (pixels != null && this.uscanl != filter_dosboxb && this.uscanl != filter_dosbox) {
      for (int i = 0; i < pixels.length; i++)
        pixels[i] = 0; 
      this.uscanl = filter_dosbox;
    } 
    if (pixels != null && this.uscanl != filter_dosboxb && this.uscanl != filter_dosbox) {
      for (int i = 0; i < pixels.length; i++)
        pixels[i] = 0; 
      this.uscanl = filter_dosboxb;
    } 
    if (pixels != null && this.pix != this.zoom) {
      for (int i = 0; i < pixels.length; i++)
        pixels[i] = 0; 
      this.pix = this.zoom;
    } 
  }
  
  protected void checkInterlace() {
    if (interlace) {
      this.rasterChanged = true;
      if (this.odd) {
        this.raster = this.laceimage.getRaster();
        this.odd = false;
      } else {
        this.raster = image.getRaster();
        this.odd = true;
      } 
    } else if (this.rasterChanged) {
      this.raster = image.getRaster();
      this.rasterChanged = false;
    } 
  }
  
  protected void CRTFilter() {
    try {
      Thread.yield();
    } catch (Exception exception) {}
    for (int x = 0; x < this.imageWidth; x++) {
      this.splitrgb++;
      if (this.splitrgb > 3)
        this.splitrgb = 0; 
      this.off = x;
      for (int y = 0; y < this.imageHeight; y += 2) {
        getRGB(pixels[this.off], this.rgb);
        switch (this.splitrgb) {
          case 0:
            pixels[this.off] = putRGB(this.rgb[0], (int)(this.rgb[1] / this.div), (int)(this.rgb[2] / this.div));
            break;
          case 1:
            pixels[this.off] = putRGB((int)(this.rgb[0] / this.div), this.rgb[1], (int)(this.rgb[2] / this.div));
            break;
          case 2:
            pixels[this.off] = putRGB((int)(this.rgb[0] / this.div), (int)(this.rgb[1] / this.div), this.rgb[2]);
            break;
          case 3:
            pixels[this.off] = putRGB((int)(this.rgb[0] / this.div), (int)(this.rgb[1] / this.div), (int)(this.rgb[2] / this.div));
            break;
        } 
        pixels[this.off + this.imageWidth] = pixels[this.off];
        this.off += this.imageWidth * 2;
      } 
    } 
  }
  
  protected void CRTFilter4() {
    try {
      Thread.yield();
    } catch (Exception exception) {}
    for (int x = 0; x < this.imageWidth; x += 2) {
      this.off = x;
      for (int y = 0; y < this.imageHeight; y += 2) {
        this.togglered = !this.togglered;
        pixels[this.off + this.imageWidth + 1] = pixels[this.off + 1] & 0xFF00;
        pixels[this.off + this.imageWidth] = pixels[this.off] & 0xFF;
        if (this.togglered) {
          pixels[this.off] = pixels[this.off] & 0xFF0000;
        } else {
          pixels[this.off + 1] = pixels[this.off + 1] & 0xFF0000;
        } 
        this.off += this.imageWidth * 2;
      } 
    } 
  }
  
  protected void AdvMameFilter2x(boolean smooth) {
    scaleDown();
    for (this.yPixel = 1; this.yPixel < 271; this.yPixel++) {
      for (this.xPixel = 1; this.xPixel < 383; this.xPixel++) {
        this.A = this.mamepixels[(this.yPixel - 1) * 384 + this.xPixel - 1];
        this.B = this.mamepixels[(this.yPixel - 1) * 384 + this.xPixel];
        this.C = this.mamepixels[(this.yPixel - 1) * 384 + this.xPixel + 1];
        this.D = this.mamepixels[this.yPixel * 384 + this.xPixel - 1];
        this.E = this.mamepixels[this.yPixel * 384 + this.xPixel];
        this.F = this.mamepixels[this.yPixel * 384 + this.xPixel + 1];
        this.G = this.mamepixels[(this.yPixel + 1) * 384 + this.xPixel - 1];
        this.H = this.mamepixels[(this.yPixel + 1) * 384 + this.xPixel];
        this.I = this.mamepixels[(this.yPixel + 1) * 384 + this.xPixel + 1];
        this.E0 = this.yPixel * 1536 + (this.xPixel << 1);
        this.E1 = this.E0 + 1;
        this.E2 = this.E0 + 768;
        this.E3 = this.E2 + 1;
        if (this.B != this.H && this.D != this.F) {
          this.pix1 = (this.D == this.B);
          this.pix2 = (this.B == this.F);
          this.pix3 = (this.D == this.H);
          this.pix4 = (this.F == this.H);
          if (smooth) {
            getRGB(this.E, this.rgb);
            int r = this.rgb[0];
            int g = this.rgb[1];
            int b = this.rgb[2];
            getRGB(this.D, this.rgb);
            int ra = this.rgb[0];
            int rg = this.rgb[1];
            int rb = this.rgb[2];
            ra = (r + ra) / 2;
            rg = (g + rg) / 2;
            rb = (b + rb) / 2;
            this.D = putRGB(ra, rg, rb);
            getRGB(this.F, this.rgb);
            ra = this.rgb[0];
            rg = this.rgb[1];
            rb = this.rgb[2];
            ra = (r + ra) / 2;
            rg = (g + rg) / 2;
            rb = (b + rb) / 2;
            this.F = putRGB(ra, rg, rb);
          } 
          pixels[this.E0] = this.pix1 ? this.D : this.E;
          pixels[this.E1] = this.pix2 ? this.F : this.E;
          pixels[this.E2] = this.pix3 ? this.D : this.E;
          pixels[this.E3] = this.pix4 ? this.F : this.E;
        } else {
          pixels[this.E0] = this.E;
          pixels[this.E1] = this.E;
          pixels[this.E2] = this.E;
          pixels[this.E3] = this.E;
        } 
      } 
    } 
  }
  
  protected void AdvMameFilterMode0(boolean smooth) {
    for (this.yPixel = 1; this.yPixel < 271; this.yPixel++) {
      for (this.xPixel = 1; this.xPixel < 191; this.xPixel++) {
        this.A = this.mamepixelsmode0[(this.yPixel - 1) * 192 + this.xPixel - 1];
        this.B = this.mamepixelsmode0[(this.yPixel - 1) * 192 + this.xPixel];
        this.C = this.mamepixelsmode0[(this.yPixel - 1) * 192 + this.xPixel + 1];
        this.D = this.mamepixelsmode0[this.yPixel * 192 + this.xPixel - 1];
        this.E = this.mamepixelsmode0[this.yPixel * 192 + this.xPixel];
        this.F = this.mamepixelsmode0[this.yPixel * 192 + this.xPixel + 1];
        this.G = this.mamepixelsmode0[(this.yPixel + 1) * 192 + this.xPixel - 1];
        this.H = this.mamepixelsmode0[(this.yPixel + 1) * 192 + this.xPixel];
        this.I = this.mamepixelsmode0[(this.yPixel + 1) * 192 + this.xPixel + 1];
        this.E0 = this.yPixel * 384 + (this.xPixel << 1);
        this.E1 = this.E0 + 1;
        if (this.B != this.H && this.D != this.F) {
          this.pix1 = (this.D == this.B);
          this.pix2 = (this.B == this.F);
          this.pix3 = (this.D == this.H);
          this.pix4 = (this.F == this.H);
          if (smooth) {
            getRGB(this.E, this.rgb);
            int r = this.rgb[0];
            int g = this.rgb[1];
            int b = this.rgb[2];
            getRGB(this.D, this.rgb);
            int ra = this.rgb[0];
            int rg = this.rgb[1];
            int rb = this.rgb[2];
            ra = (r + ra) / 2;
            rg = (g + rg) / 2;
            rb = (b + rb) / 2;
            this.D = putRGB(ra, rg, rb);
            getRGB(this.F, this.rgb);
            ra = this.rgb[0];
            rg = this.rgb[1];
            rb = this.rgb[2];
            ra = (r + ra) / 2;
            rg = (g + rg) / 2;
            rb = (b + rb) / 2;
            this.F = putRGB(ra, rg, rb);
          } 
          this.mamepixels[this.E0] = this.pix1 ? this.D : this.E;
          this.mamepixels[this.E1] = this.pix2 ? this.F : this.E;
        } else {
          this.mamepixels[this.E0] = this.E;
          this.mamepixels[this.E1] = this.E;
        } 
      } 
    } 
  }
  
  protected void EagleFilter2x(boolean smooth) {
    scaleDown();
    for (this.yPixel = 1; this.yPixel < 271; this.yPixel++) {
      for (this.xPixel = 1; this.xPixel < 383; this.xPixel++) {
        this.A = this.mamepixels[(this.yPixel - 1) * 384 + this.xPixel - 1];
        this.B = this.mamepixels[(this.yPixel - 1) * 384 + this.xPixel];
        this.C = this.mamepixels[(this.yPixel - 1) * 384 + this.xPixel + 1];
        this.D = this.mamepixels[this.yPixel * 384 + this.xPixel - 1];
        this.E = this.mamepixels[this.yPixel * 384 + this.xPixel];
        this.F = this.mamepixels[this.yPixel * 384 + this.xPixel + 1];
        this.G = this.mamepixels[(this.yPixel + 1) * 384 + this.xPixel - 1];
        this.H = this.mamepixels[(this.yPixel + 1) * 384 + this.xPixel];
        this.I = this.mamepixels[(this.yPixel + 1) * 384 + this.xPixel + 1];
        this.E0 = this.yPixel * 1536 + (this.xPixel << 1);
        this.E1 = this.E0 + 1;
        this.E2 = this.E0 + 768;
        this.E3 = this.E2 + 1;
        this.pix1 = (this.D == this.A && this.A == this.B);
        this.pix2 = (this.B == this.C && this.C == this.F);
        this.pix3 = (this.D == this.G && this.G == this.H);
        this.pix4 = (this.F == this.I && this.I == this.H);
        if (smooth) {
          getRGB(this.E, this.rgb);
          int r = this.rgb[0];
          int g = this.rgb[1];
          int b = this.rgb[2];
          getRGB(this.A, this.rgb);
          int ra = this.rgb[0];
          int rg = this.rgb[1];
          int rb = this.rgb[2];
          ra = (r + ra) / 2;
          rg = (g + rg) / 2;
          rb = (b + rb) / 2;
          this.A = putRGB(ra, rg, rb);
          getRGB(this.C, this.rgb);
          ra = this.rgb[0];
          rg = this.rgb[1];
          rb = this.rgb[2];
          ra = (r + ra) / 2;
          rg = (g + rg) / 2;
          rb = (b + rb) / 2;
          this.C = putRGB(ra, rg, rb);
          getRGB(this.G, this.rgb);
          ra = this.rgb[0];
          rg = this.rgb[1];
          rb = this.rgb[2];
          ra = (r + ra) / 2;
          rg = (g + rg) / 2;
          rb = (b + rb) / 2;
          this.G = putRGB(ra, rg, rb);
          getRGB(this.I, this.rgb);
          ra = this.rgb[0];
          rg = this.rgb[1];
          rb = this.rgb[2];
          ra = (r + ra) / 2;
          rg = (g + rg) / 2;
          rb = (b + rb) / 2;
          this.I = putRGB(ra, rg, rb);
        } 
        pixels[this.E0] = this.pix1 ? this.A : this.E;
        pixels[this.E1] = this.pix2 ? this.C : this.E;
        pixels[this.E2] = this.pix3 ? this.G : this.E;
        pixels[this.E3] = this.pix4 ? this.I : this.E;
      } 
    } 
  }
  
  protected void EagleFilterMode0(boolean smooth) {
    for (this.yPixel = 1; this.yPixel < 271; this.yPixel++) {
      for (this.xPixel = 1; this.xPixel < 191; this.xPixel++) {
        this.A = this.mamepixelsmode0[(this.yPixel - 1) * 192 + this.xPixel - 1];
        this.B = this.mamepixelsmode0[(this.yPixel - 1) * 192 + this.xPixel];
        this.C = this.mamepixelsmode0[(this.yPixel - 1) * 192 + this.xPixel + 1];
        this.D = this.mamepixelsmode0[this.yPixel * 192 + this.xPixel - 1];
        this.E = this.mamepixelsmode0[this.yPixel * 192 + this.xPixel];
        this.F = this.mamepixelsmode0[this.yPixel * 192 + this.xPixel + 1];
        this.G = this.mamepixelsmode0[(this.yPixel + 1) * 192 + this.xPixel - 1];
        this.H = this.mamepixelsmode0[(this.yPixel + 1) * 192 + this.xPixel];
        this.I = this.mamepixelsmode0[(this.yPixel + 1) * 192 + this.xPixel + 1];
        this.E0 = this.yPixel * 384 + (this.xPixel << 1);
        this.E1 = this.E0 + 1;
        this.pix1 = (this.D == this.A && this.A == this.B);
        this.pix2 = (this.B == this.C && this.C == this.F);
        this.pix3 = (this.D == this.G && this.G == this.H);
        this.pix4 = (this.F == this.I && this.I == this.H);
        if (smooth) {
          getRGB(this.E, this.rgb);
          int r = this.rgb[0];
          int g = this.rgb[1];
          int b = this.rgb[2];
          getRGB(this.A, this.rgb);
          int ra = this.rgb[0];
          int rg = this.rgb[1];
          int rb = this.rgb[2];
          ra = (r + ra) / 2;
          rg = (g + rg) / 2;
          rb = (b + rb) / 2;
          this.A = putRGB(ra, rg, rb);
          getRGB(this.C, this.rgb);
          ra = this.rgb[0];
          rg = this.rgb[1];
          rb = this.rgb[2];
          ra = (r + ra) / 2;
          rg = (g + rg) / 2;
          rb = (b + rb) / 2;
          this.C = putRGB(ra, rg, rb);
          getRGB(this.G, this.rgb);
          ra = this.rgb[0];
          rg = this.rgb[1];
          rb = this.rgb[2];
          ra = (r + ra) / 2;
          rg = (g + rg) / 2;
          rb = (b + rb) / 2;
          this.G = putRGB(ra, rg, rb);
          getRGB(this.I, this.rgb);
          ra = this.rgb[0];
          rg = this.rgb[1];
          rb = this.rgb[2];
          ra = (r + ra) / 2;
          rg = (g + rg) / 2;
          rb = (b + rb) / 2;
          this.I = putRGB(ra, rg, rb);
        } 
        this.mamepixels[this.E0] = this.pix1 ? this.A : this.E;
        this.mamepixels[this.E1] = this.pix2 ? this.C : this.E;
      } 
    } 
  }
  
  protected void scaleDown() {
    this.CPCpixel = 0;
    for (this.CPC_Y_pixel = 0; this.CPC_Y_pixel < 544; this.CPC_Y_pixel += 2) {
      for (this.CPC_X_pixel = 0; this.CPC_X_pixel < 768; this.CPC_X_pixel += 2)
        this.mamepixels[this.CPCpixel++] = pixels[this.CPC_X_pixel + this.CPC_Y_pixel * 768]; 
    } 
  }
  
  protected void scaleDownEagle(boolean smooth) {
    this.CPCpixel = 0;
    int width = (GateArray.getSMode() == 0) ? 384 : 768;
    for (this.CPC_Y_pixel = 0; this.CPC_Y_pixel < 544; this.CPC_Y_pixel += 2) {
      for (this.CPC_X_pixel = 0; this.CPC_X_pixel < 768; this.CPC_X_pixel += (width == 384) ? 4 : 2) {
        if (width == 384) {
          this.mamepixelsmode0[this.CPCpixel++] = pixels[this.CPC_X_pixel + this.CPC_Y_pixel * 768];
        } else {
          this.mamepixels[this.CPCpixel++] = pixels[this.CPC_X_pixel + this.CPC_Y_pixel * 768];
        } 
      } 
    } 
    if (width == 384)
      EagleFilterMode0(smooth); 
  }
  
  protected void scaleDownAdvMame(boolean smooth) {
    this.CPCpixel = 0;
    int width = (GateArray.getSMode() == 0) ? 384 : 768;
    for (this.CPC_Y_pixel = 0; this.CPC_Y_pixel < 544; this.CPC_Y_pixel += 2) {
      for (this.CPC_X_pixel = 0; this.CPC_X_pixel < 768; this.CPC_X_pixel += (width == 384) ? 4 : 2) {
        if (width == 384) {
          this.mamepixelsmode0[this.CPCpixel++] = pixels[this.CPC_X_pixel + this.CPC_Y_pixel * 768];
        } else {
          this.mamepixels[this.CPCpixel++] = pixels[this.CPC_X_pixel + this.CPC_Y_pixel * 768];
        } 
      } 
    } 
    if (width == 384)
      AdvMameFilterMode0(smooth); 
  }
  
  protected void RGBFilter2x() {
    for (int x = 0; x < this.imageWidth; x += 2) {
      this.off = x;
      for (int y = 0; y < this.imageHeight; y += 2) {
        getRGB(pixels[this.off], this.rgb);
        if (this.rgb[0] == 0)
          this.rgb[0] = this.lum; 
        if (this.rgb[1] == 0)
          this.rgb[1] = this.lum; 
        if (this.rgb[2] == 0)
          this.rgb[2] = this.lum; 
        pixels[this.off + this.imageWidth + 1] = pixels[this.off + 1];
        pixels[this.off + this.imageWidth] = putRGB((int)(this.rgb[0] / this.div), (int)(this.rgb[1] / this.div), this.rgb[2]);
        pixels[this.off] = putRGB(this.rgb[0], (int)(this.rgb[1] / this.div), (int)(this.rgb[2] / this.div));
        getRGB(pixels[this.off + 1], this.rgb);
        if (this.rgb[0] == 0)
          this.rgb[0] = this.lum; 
        if (this.rgb[1] == 0)
          this.rgb[1] = this.lum; 
        if (this.rgb[2] == 0)
          this.rgb[2] = this.lum; 
        pixels[this.off + 1] = putRGB((int)(this.rgb[0] / this.div), (int)(this.rgb[1] / this.div), (int)(this.rgb[0] / this.div));
        this.off += this.imageWidth * 2;
      } 
    } 
  }
  
  protected void CRTFilter2() {
    for (int x = 0; x < this.imageWidth; x += 2) {
      this.off = x;
      this.div = Desktop.level.getValue() / 10.0D;
      for (int y = 0; y < this.imageHeight; y += 2) {
        getRGB(pixels[this.off], this.rgb);
        pixels[this.off + this.imageWidth + 1] = pixels[this.off + 1];
        pixels[this.off + this.imageWidth] = putRGB((int)(this.rgb[0] / this.div), (int)(this.rgb[1] / this.div), this.rgb[2]);
        pixels[this.off] = putRGB(this.rgb[0], (int)(this.rgb[1] / this.div), (int)(this.rgb[2] / this.div));
        pixels[this.off + 1] = putRGB((int)(this.rgb[0] / this.div), this.rgb[1], (int)(this.rgb[2] / this.div));
        this.off += this.imageWidth * 2;
      } 
    } 
  }
  
  protected void CRTFilter3() {
    for (int x = 0; x < this.imageWidth; x += 2) {
      this.off = x;
      for (int y = 0; y < this.imageHeight; y += 2) {
        pixels[this.off + this.imageWidth + 1] = pixels[this.off + 1];
        pixels[this.off + this.imageWidth] = pixels[this.off] & 0xFF;
        pixels[this.off] = pixels[this.off] & 0xFF0000;
        pixels[this.off + 1] = pixels[this.off + 1] & 0xFF00;
        this.off += this.imageWidth * 2;
      } 
    } 
  }
  
  protected void getRGB(int value, int[] rgb) {
    rgb[0] = value >> 16 & 0xFF;
    rgb[1] = value >> 8 & 0xFF;
    rgb[2] = value & 0xFF;
  }
  
  protected void getRGB(int value, double[] rgb) {
    rgb[0] = (value >> 16 & 0xFF);
    rgb[1] = (value >> 8 & 0xFF);
    rgb[2] = (value & 0xFF);
  }
  
  public void init() {
    for (int i = 0; i < 256; i++) {
      int nr = i;
      nr += this.addr + fader;
      if (nr < 0) {
        nr = 0;
      } else if (nr > 255) {
        nr = 255;
      } 
      this.rtable[i] = nr;
      nr = i;
      nr += this.addg + fader;
      if (nr < 0) {
        nr = 0;
      } else if (nr > 255) {
        nr = 255;
      } 
      this.gtable[i] = nr;
      nr = i;
      nr += this.addb + fader;
      if (nr < 0) {
        nr = 0;
      } else if (nr > 255) {
        nr = 255;
      } 
      this.btable[i] = nr;
    } 
  }
  
  public int putRGB(int red, int green, int blue) {
    return red << 16 | green << 8 | blue;
  }
  
  public int putRGB(int[] rgb) {
    return rgb[0] << 16 | rgb[1] << 8 | rgb[2];
  }
  
  public int putRGB(int input) {
    this.red = input >> 16 & 0xFF;
    this.green = input >> 8 & 0xFF;
    this.blue = input & 0xFF;
    this.red = this.rtable[this.red];
    this.green = this.gtable[this.green];
    this.blue = this.btable[this.blue];
    input = this.red << 16 | this.green << 8 | this.blue;
    return input;
  }
  
  protected void fullRender() {
    this.splud--;
    if (this.splud < 1) {
      this.splud = 0;
      if (!this.drawlines || !JEMU.large)
        for (int lines = 0; lines < this.imageHeight; lines += 2)
          System.arraycopy(pixels, lines * this.imageWidth, pixels, (lines + 1) * this.imageWidth, this.imageWidth);  
    } 
  }
  
  public static int blur = 1;
  
  public static boolean reverse;
  
  public static int snow = 124;
  
  BufferedImage gunImage;
  
  double[] glowBuffer;
  
  double glowR;
  
  double glowG;
  
  double glowB;
  
  BufferedImage copimage;
  
  public GraphicsViewer gfxView;
  
  boolean ctrl;
  
  boolean shift;
  
  protected void PALRender() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: iload_1
    //   3: getstatic jemu/ui/Display.pixels : [I
    //   6: arraylength
    //   7: if_icmpge -> 33
    //   10: getstatic jemu/ui/Display.pixels : [I
    //   13: iload_1
    //   14: aload_0
    //   15: getstatic jemu/ui/Display.pixels : [I
    //   18: iload_1
    //   19: iaload
    //   20: ldc2_w 0.75
    //   23: invokevirtual glow : (ID)I
    //   26: iastore
    //   27: iinc #1, 2
    //   30: goto -> 2
    //   33: getstatic jemu/ui/Display.snow : I
    //   36: bipush #124
    //   38: if_icmpge -> 80
    //   41: iconst_0
    //   42: istore_1
    //   43: iload_1
    //   44: getstatic jemu/ui/Display.pixels : [I
    //   47: arraylength
    //   48: if_icmpge -> 80
    //   51: getstatic jemu/ui/Display.pixels : [I
    //   54: iload_1
    //   55: aload_0
    //   56: getstatic jemu/ui/Display.pixels : [I
    //   59: iload_1
    //   60: iaload
    //   61: invokestatic random : ()D
    //   64: invokevirtual glow : (ID)I
    //   67: iastore
    //   68: iload_1
    //   69: getstatic jemu/ui/Display.snow : I
    //   72: invokestatic random : (I)I
    //   75: iadd
    //   76: istore_1
    //   77: goto -> 43
    //   80: aload_0
    //   81: pop
    //   82: getstatic jemu/ui/Display.filter_dosbox : Z
    //   85: ifne -> 128
    //   88: aload_0
    //   89: pop
    //   90: getstatic jemu/ui/Display.filter_dosboxb : Z
    //   93: ifne -> 128
    //   96: aload_0
    //   97: pop
    //   98: getstatic jemu/ui/Display.filter_advmame : Z
    //   101: ifne -> 128
    //   104: aload_0
    //   105: pop
    //   106: getstatic jemu/ui/Display.filter_eagle : Z
    //   109: ifne -> 128
    //   112: aload_0
    //   113: pop
    //   114: getstatic jemu/ui/Display.filter_advmame_smooth : Z
    //   117: ifne -> 128
    //   120: aload_0
    //   121: pop
    //   122: getstatic jemu/ui/Display.filter_eagle_smooth : Z
    //   125: ifeq -> 302
    //   128: getstatic jemu/ui/Display.reverse : Z
    //   131: ifne -> 217
    //   134: iconst_0
    //   135: istore_1
    //   136: iload_1
    //   137: getstatic jemu/ui/Display.blur : I
    //   140: if_icmpge -> 214
    //   143: aload_0
    //   144: iconst_0
    //   145: putfield off : I
    //   148: aload_0
    //   149: getfield off : I
    //   152: getstatic jemu/ui/Display.pixels : [I
    //   155: arraylength
    //   156: if_icmpge -> 208
    //   159: aload_0
    //   160: getstatic jemu/ui/Display.pixels : [I
    //   163: aload_0
    //   164: getfield off : I
    //   167: aload_0
    //   168: getfield lastPix : I
    //   171: ldc_w 16711422
    //   174: iand
    //   175: getstatic jemu/ui/Display.pixels : [I
    //   178: aload_0
    //   179: getfield off : I
    //   182: iaload
    //   183: ldc_w 16711422
    //   186: iand
    //   187: iadd
    //   188: iconst_1
    //   189: ishr
    //   190: dup_x2
    //   191: iastore
    //   192: putfield lastPix : I
    //   195: aload_0
    //   196: dup
    //   197: getfield off : I
    //   200: iconst_1
    //   201: iadd
    //   202: putfield off : I
    //   205: goto -> 148
    //   208: iinc #1, 1
    //   211: goto -> 136
    //   214: goto -> 616
    //   217: iconst_0
    //   218: istore_1
    //   219: iload_1
    //   220: getstatic jemu/ui/Display.blur : I
    //   223: if_icmpge -> 299
    //   226: aload_0
    //   227: getstatic jemu/ui/Display.pixels : [I
    //   230: arraylength
    //   231: iconst_1
    //   232: isub
    //   233: putfield off : I
    //   236: aload_0
    //   237: getfield off : I
    //   240: iconst_m1
    //   241: if_icmple -> 293
    //   244: aload_0
    //   245: getstatic jemu/ui/Display.pixels : [I
    //   248: aload_0
    //   249: getfield off : I
    //   252: aload_0
    //   253: getfield lastPix : I
    //   256: ldc_w 16711422
    //   259: iand
    //   260: getstatic jemu/ui/Display.pixels : [I
    //   263: aload_0
    //   264: getfield off : I
    //   267: iaload
    //   268: ldc_w 16711422
    //   271: iand
    //   272: iadd
    //   273: iconst_1
    //   274: ishr
    //   275: dup_x2
    //   276: iastore
    //   277: putfield lastPix : I
    //   280: aload_0
    //   281: dup
    //   282: getfield off : I
    //   285: iconst_1
    //   286: isub
    //   287: putfield off : I
    //   290: goto -> 236
    //   293: iinc #1, 1
    //   296: goto -> 219
    //   299: goto -> 616
    //   302: getstatic jemu/ui/Display.reverse : Z
    //   305: ifeq -> 427
    //   308: iconst_0
    //   309: istore_1
    //   310: iload_1
    //   311: getstatic jemu/ui/Display.blur : I
    //   314: if_icmpge -> 424
    //   317: iconst_0
    //   318: istore_2
    //   319: iload_2
    //   320: aload_0
    //   321: getfield imageHeight : I
    //   324: if_icmpge -> 418
    //   327: aload_0
    //   328: iload_2
    //   329: aload_0
    //   330: getfield imageWidth : I
    //   333: imul
    //   334: putfield off : I
    //   337: aload_0
    //   338: dup
    //   339: getfield off : I
    //   342: aload_0
    //   343: getfield imageWidth : I
    //   346: iadd
    //   347: putfield off : I
    //   350: iconst_0
    //   351: istore_3
    //   352: iload_3
    //   353: aload_0
    //   354: getfield imageWidth : I
    //   357: if_icmpge -> 412
    //   360: aload_0
    //   361: dup
    //   362: getfield off : I
    //   365: iconst_1
    //   366: isub
    //   367: putfield off : I
    //   370: aload_0
    //   371: getstatic jemu/ui/Display.pixels : [I
    //   374: aload_0
    //   375: getfield off : I
    //   378: aload_0
    //   379: getfield lastPix : I
    //   382: ldc_w 16711422
    //   385: iand
    //   386: getstatic jemu/ui/Display.pixels : [I
    //   389: aload_0
    //   390: getfield off : I
    //   393: iaload
    //   394: ldc_w 16711422
    //   397: iand
    //   398: iadd
    //   399: iconst_1
    //   400: ishr
    //   401: dup_x2
    //   402: iastore
    //   403: putfield lastPix : I
    //   406: iinc #3, 1
    //   409: goto -> 352
    //   412: iinc #2, 2
    //   415: goto -> 319
    //   418: iinc #1, 1
    //   421: goto -> 310
    //   424: goto -> 530
    //   427: iconst_0
    //   428: istore_1
    //   429: iload_1
    //   430: getstatic jemu/ui/Display.blur : I
    //   433: if_icmpge -> 530
    //   436: iconst_0
    //   437: istore_2
    //   438: iload_2
    //   439: aload_0
    //   440: getfield imageHeight : I
    //   443: if_icmpge -> 524
    //   446: aload_0
    //   447: iload_2
    //   448: aload_0
    //   449: getfield imageWidth : I
    //   452: imul
    //   453: putfield off : I
    //   456: iconst_0
    //   457: istore_3
    //   458: iload_3
    //   459: aload_0
    //   460: getfield imageWidth : I
    //   463: if_icmpge -> 518
    //   466: aload_0
    //   467: dup
    //   468: getfield off : I
    //   471: iconst_1
    //   472: iadd
    //   473: putfield off : I
    //   476: aload_0
    //   477: getstatic jemu/ui/Display.pixels : [I
    //   480: aload_0
    //   481: getfield off : I
    //   484: aload_0
    //   485: getfield lastPix : I
    //   488: ldc_w 16711422
    //   491: iand
    //   492: getstatic jemu/ui/Display.pixels : [I
    //   495: aload_0
    //   496: getfield off : I
    //   499: iaload
    //   500: ldc_w 16711422
    //   503: iand
    //   504: iadd
    //   505: iconst_1
    //   506: ishr
    //   507: dup_x2
    //   508: iastore
    //   509: putfield lastPix : I
    //   512: iinc #3, 1
    //   515: goto -> 458
    //   518: iinc #2, 2
    //   521: goto -> 438
    //   524: iinc #1, 1
    //   527: goto -> 429
    //   530: getstatic jemu/ui/JEMU.large : Z
    //   533: ifeq -> 616
    //   536: iconst_0
    //   537: istore_1
    //   538: iload_1
    //   539: aload_0
    //   540: getfield imageWidth : I
    //   543: if_icmpge -> 616
    //   546: aload_0
    //   547: iload_1
    //   548: putfield off : I
    //   551: iconst_0
    //   552: istore_2
    //   553: iload_2
    //   554: aload_0
    //   555: getfield imageHeight : I
    //   558: if_icmpge -> 610
    //   561: getstatic jemu/ui/Display.pixels : [I
    //   564: aload_0
    //   565: getfield off : I
    //   568: aload_0
    //   569: getfield imageWidth : I
    //   572: iadd
    //   573: aload_0
    //   574: getstatic jemu/ui/Display.pixels : [I
    //   577: aload_0
    //   578: getfield off : I
    //   581: iaload
    //   582: ldc2_w 0.75
    //   585: invokevirtual glow : (ID)I
    //   588: iastore
    //   589: aload_0
    //   590: dup
    //   591: getfield off : I
    //   594: aload_0
    //   595: getfield imageWidth : I
    //   598: iconst_2
    //   599: imul
    //   600: iadd
    //   601: putfield off : I
    //   604: iinc #2, 2
    //   607: goto -> 553
    //   610: iinc #1, 1
    //   613: goto -> 538
    //   616: return
    // Line number table:
    //   Java source line number -> byte code offset
    //   #1412	-> 0
    //   #1413	-> 10
    //   #1412	-> 27
    //   #1415	-> 33
    //   #1416	-> 41
    //   #1417	-> 51
    //   #1416	-> 68
    //   #1425	-> 80
    //   #1426	-> 128
    //   #1427	-> 134
    //   #1428	-> 143
    //   #1429	-> 159
    //   #1428	-> 195
    //   #1427	-> 208
    //   #1433	-> 217
    //   #1434	-> 226
    //   #1435	-> 244
    //   #1434	-> 280
    //   #1433	-> 293
    //   #1440	-> 302
    //   #1441	-> 308
    //   #1442	-> 317
    //   #1443	-> 327
    //   #1444	-> 337
    //   #1445	-> 350
    //   #1446	-> 360
    //   #1447	-> 370
    //   #1445	-> 406
    //   #1442	-> 412
    //   #1441	-> 418
    //   #1452	-> 427
    //   #1453	-> 436
    //   #1454	-> 446
    //   #1455	-> 456
    //   #1456	-> 466
    //   #1457	-> 476
    //   #1455	-> 512
    //   #1453	-> 518
    //   #1452	-> 524
    //   #1462	-> 530
    //   #1463	-> 536
    //   #1464	-> 546
    //   #1465	-> 551
    //   #1466	-> 561
    //   #1467	-> 589
    //   #1465	-> 604
    //   #1463	-> 610
    //   #1472	-> 616
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   2	31	1	i	I
    //   43	37	1	i	I
    //   136	78	1	i	I
    //   219	80	1	i	I
    //   352	60	3	x	I
    //   319	99	2	y	I
    //   310	114	1	i	I
    //   458	60	3	x	I
    //   438	86	2	y	I
    //   429	101	1	i	I
    //   553	57	2	y	I
    //   538	78	1	x	I
    //   0	617	0	this	Ljemu/ui/Display;
  }
  
  protected int glow(int value, double factor) {
    getRGB(value, this.glowBuffer);
    this.glowR = this.glowBuffer[0] * factor;
    this.glowG = this.glowBuffer[1] * factor;
    this.glowB = this.glowBuffer[2] * factor;
    return putRGB((int)this.glowR, (int)this.glowG, (int)this.glowB);
  }
  
  public int lightGun(int x, int y) {
    int xx = getWidth();
    int yy = getHeight();
    if (this.gunImage.getWidth() != xx || this.gunImage.getHeight() != yy)
      this.gunImage = new BufferedImage(xx, yy, 1); 
    this.gunImage.getGraphics().drawImage(image, 0, 0, xx, yy, this);
    Color test = new Color(this.gunImage.getRGB(x, y));
    int redg = test.getRed();
    int greeng = test.getGreen();
    int blueg = test.getBlue();
    int check = redg + blueg + greeng;
    return check;
  }
  
  public void checkCOPimage() {
    if (this.copimage == null || this.copimage.getWidth() != image.getWidth() || this.copimage.getHeight() != image.getHeight())
      this.copimage = new BufferedImage(image.getWidth(), image.getHeight(), 1); 
  }
  
  public void keyPress(int code) {
    if (initcap) {
      if (code == 17)
        this.ctrl = true; 
      if (code == 16)
        this.shift = true; 
      if (code == 38)
        if (!this.ctrl && !this.shift) {
          if (capY > 1)
            capY--; 
        } else if (this.ctrl && !this.shift) {
          if (capH > 2)
            capH--; 
        } else if (this.ctrl && this.shift) {
          if (capH > 16)
            capH -= 8; 
        } else if (!this.ctrl && this.shift && capY > 8) {
          capY -= 8;
        }  
      if (code == 37)
        if (!this.ctrl && !this.shift) {
          if (capX > 1)
            capX--; 
        } else if (this.ctrl && !this.shift) {
          if (capW > 2)
            capW--; 
        } else if (this.ctrl && this.shift) {
          if (capW > 16)
            capW -= 8; 
        } else if (!this.ctrl && this.shift && capX > 8) {
          capX -= 8;
        }  
      if (code == 40)
        if (!this.ctrl && !this.shift) {
          if (capY < image.getHeight() - 1)
            capY++; 
        } else if (this.ctrl && !this.shift) {
          if (capH < image.getHeight() - 1)
            capH++; 
        } else if (this.ctrl && this.shift) {
          if (capH < image.getHeight() - 8)
            capH += 8; 
        } else if (!this.ctrl && this.shift && capY < image.getHeight() - 8) {
          capY += 8;
        }  
      if (code == 39)
        if (!this.ctrl && !this.shift) {
          if (capW < image.getWidth() - 1)
            capW++; 
        } else if (this.ctrl && !this.shift) {
          if (capW < image.getWidth() - 1)
            capW++; 
        } else if (this.ctrl && this.shift) {
          if (capH < image.getWidth() - 8)
            capW += 8; 
        } else if (!this.ctrl && this.shift && capX < image.getWidth() - 8) {
          capX += 8;
        }  
      return;
    } 
    if (this.gfxView != null)
      this.gfxView.keyPress(code); 
    if (JEMU.mapper != null)
      JEMU.mapper.keyPress(code); 
  }
  
  public void keyRelease(int code) {
    if (initcap) {
      if (code == 17)
        this.ctrl = false; 
      if (code == 16)
        this.shift = false; 
      return;
    } 
    if (this.gfxView != null)
      this.gfxView.keyRelease(code); 
    if (JEMU.mapper != null)
      JEMU.mapper.keyRelease(code); 
  }
  
  public void initGFXViewer() {
    if (!Desktop.isDesktop) {
      if (this.gfxView == null)
        this.gfxView = new GraphicsViewer(); 
      this.gfxView.setVisible(true);
    } else {
      Desktop.gfxcount = 1;
    } 
  }
  
  protected void healthLine() {
    if (initgfxviewer != 0) {
      initgfxviewer++;
      if (initgfxviewer > 2) {
        initgfxviewer = 0;
        initGFXViewer();
      } 
    } 
    if (this.framecount != 0)
      this.framecount++; 
    if (this.framecount == 4) {
      if (this.MOVControl == null)
        this.MOVControl = new Control(); 
      this.MOVControl.setVisible(true);
      this.framecount = 0;
    } 
  }
  
  public static boolean skipframes = false;
  
  public static final float[] BLUR3x3 = new float[] { 0.15F, 0.15F, 0.15F, 0.15F, 0.2F, 0.15F, 0.15F, 0.15F, 0.15F };
  
  JFrame fram;
  
  JSlider slide1;
  
  JSlider slide2;
  
  public boolean larg;
  
  int wait;
  
  public static boolean use3d = false;
  
  int screenshot;
  
  int oldshot;
  
  int shotindex;
  
  public boolean doScreening;
  
  int paintedimage;
  
  int showzoom;
  
  String zoomfactor;
  
  public boolean threeinch;
  
  public String disk1;
  
  public String disk2;
  
  public String disk3;
  
  public String disk4;
  
  public String disk5;
  
  int checkFullScreenBorder;
  
  boolean redoBorders;
  
  int screenw;
  
  int screenh;
  
  int af;
  
  public static boolean cancap;
  
  public static boolean stopcap;
  
  public void showZoom(String factor) {
    this.showzoom = 100;
    this.zoomfactor = factor;
  }
  
  protected void paintImage(Graphics g) {
    if (this.doScreening) {
      this.screenshot = 0;
      for (int i = 49152; i < 65535; i++)
        this.screenshot += CPC.PEEK(i); 
      if (this.oldshot != this.screenshot) {
        this.oldshot = this.screenshot;
        try {
          File a = new File("C://javacpc_temp/");
          if (!a.exists())
            a.mkdir(); 
          ImageIO.write(image, "PNG", new File("C://javacpc_temp/" + this.shotindex++ + ".png"));
        } catch (Exception exception) {}
      } 
    } 
    if (scaneffect && !lowperformance) {
      if (imageRect.height >= 544) {
        this.showeffect = true;
        this.masked = false;
      } else {
        this.showeffect = false;
        this.masked = true;
      } 
    } else {
      this.showeffect = false;
      this.masked = false;
    } 
    StatusPanel.fps.setText("" + mCurrFPS);
    this.larg = (getWidth() > 700);
    if (filter_dosbox) {
      BLUR3x3[8] = 0.15F;
      BLUR3x3[7] = 0.15F;
      BLUR3x3[6] = 0.15F;
      BLUR3x3[5] = 0.15F;
      BLUR3x3[3] = 0.15F;
      BLUR3x3[2] = 0.15F;
      BLUR3x3[1] = 0.15F;
      BLUR3x3[0] = 0.15F;
      BLUR3x3[4] = 0.8F;
    } else if (filter_dosboxb) {
      BLUR3x3[8] = 0.12F;
      BLUR3x3[7] = 0.12F;
      BLUR3x3[6] = 0.12F;
      BLUR3x3[5] = 0.12F;
      BLUR3x3[3] = 0.12F;
      BLUR3x3[2] = 0.12F;
      BLUR3x3[1] = 0.12F;
      BLUR3x3[0] = 0.12F;
      BLUR3x3[4] = 0.6F;
    } else {
      BLUR3x3[8] = 0.1F;
      BLUR3x3[7] = 0.1F;
      BLUR3x3[6] = 0.1F;
      BLUR3x3[5] = 0.1F;
      BLUR3x3[3] = 0.1F;
      BLUR3x3[2] = 0.1F;
      BLUR3x3[1] = 0.1F;
      BLUR3x3[0] = 0.1F;
      BLUR3x3[4] = 0.2F;
    } 
    if (image == null)
      return; 
    Graphics2D g2 = (Graphics2D)g;
    ConvolveOp cop = new ConvolveOp(new Kernel(3, 3, BLUR3x3), 1, null);
    if (Switches.bilinear && !lowperformance) {
      g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
      g = g2;
    } 
    if (!CPC.YM_Play || CPC.playmovie) {
      if (interlace) {
        g2.setComposite(AlphaComposite.getInstance(3, 1.0F));
        if (superPAL) {
          checkCOPimage();
          Graphics2D g3 = this.copimage.createGraphics();
          g3.drawImage(image, cop, 0, 0);
          g2.drawImage(this.copimage, imageRect.x, imageRect.y, imageRect.width, imageRect.height, null);
        } else {
          g2.drawImage(image, imageRect.x, imageRect.y, imageRect.width, imageRect.height, null);
        } 
        g2.setComposite(AlphaComposite.getInstance(3, 0.5F));
        if (superPAL) {
          checkCOPimage();
          Graphics2D g3 = this.copimage.createGraphics();
          g3.drawImage(this.laceimage, cop, 0, 0);
          g2.drawImage(this.copimage, imageRect.x, imageRect.y, imageRect.width, imageRect.height, null);
        } else {
          g2.drawImage(this.laceimage, imageRect.x, imageRect.y, imageRect.width, imageRect.height, null);
        } 
        g2.setComposite(AlphaComposite.getInstance(3, 1.0F));
      } else if (superPAL) {
        checkCOPimage();
        Graphics2D g3 = this.copimage.createGraphics();
        g3.drawImage(image, cop, 0, 0);
        g2.drawImage(this.copimage, imageRect.x, imageRect.y, imageRect.width, imageRect.height, null);
      } else {
        g2.drawImage(image, imageRect.x, imageRect.y, imageRect.width, imageRect.height, null);
      } 
    } else {
      if (skin == 1) {
        g2.drawImage(this.YMmode, imageRect.x, imageRect.y, imageRect.width, imageRect.height, null);
      } else {
        g2.drawImage(this.YMmode2, imageRect.x, imageRect.y, imageRect.width, imageRect.height, null);
      } 
      if (!lowperformance)
        paintBalls(g); 
    } 
    if (overlay != null)
      g.drawImage(overlay, imageRect.x, imageRect.y, imageRect.width, imageRect.height, this); 
    if (Main.isrickrolling)
      g.drawString("Rick Rolling is downloading...", 100, 20); 
    if (imageRect.height >= 640) {
      this.zoom = 3;
    } else if (imageRect.height >= 540) {
      this.zoom = 2;
    } else {
      this.zoom = 1;
    } 
    if (cancap) {
      startcap();
      cancap = false;
    } 
    if (stopcap) {
      stopcap();
      stopcap = false;
    } 
    if (record) {
      if (this.MOVControl.pause.isSelected())
        return; 
      if (truecap) {
        this.mov.step(quality);
      } else {
        this.halfframe = !this.halfframe;
        if (this.halfframe)
          this.mov.step(quality); 
      } 
    } 
    if (formaterror > 0) {
      formaterror++;
      g2.drawImage(this.formaterr, 0, 0, imageRect.width, imageRect.height, null);
      if (formaterror > 300)
        formaterror = 0; 
    } 
    this.scanlines = Switches.ScanLines;
    this.drawlines = false;
    if (this.scanlines && !lowperformance)
      if (imageRect.height >= 544) {
        this.drawlines = true;
      } else {
        this.drawlines = false;
      }  
    g.setColor(Color.BLACK);
    if (turbotimer == 5 && !this.floppyturbo) {
      Switches.turbo = 3;
      this.floppyturbo = true;
    } 
    if (this.floppyturbo && Switches.turbo == 1)
      Switches.turbo = 3; 
    if (turbotimer >= 2)
      turbotimer--; 
    if (turbotimer == 1) {
      Switches.turbo = 1;
      JEMU.turbo.setState(false);
      this.floppyturbo = false;
      turbotimer--;
    } 
    if (showpause >= 0) {
      if (imageRect.height >= 540) {
        g.drawImage(this.paused, imageRect.width - 80, 12, this);
      } else {
        g.drawImage(this.pauseds, imageRect.width - 40, 6, this);
      } 
      showpause--;
    } 
    if (this.showzoom != 0) {
      g.setColor(Color.red);
      g.setFont(new Font("Tahoma", 2, 18));
      g.drawString("Zoom: " + this.zoomfactor, 10, 20);
      this.showzoom--;
    } 
    if (this.joyenabled) {
      if (JEMU.setJoy1 || JEMU.setJoy2) {
        g.setColor(Color.red);
        g.setFont(new Font("Tahoma", 2, (getWidth() > 700) ? 34 : 18));
        g.drawString("Joystick found!", 10, (getWidth() > 700) ? 40 : 20);
      } 
      if (JEMU.setJoy1) {
        g.setColor(Color.red);
        g.setFont(new Font("Tahoma", 2, (getWidth() > 700) ? 34 : 18));
        g.drawString("Press Joystick button for Fire 1", 10, (getWidth() > 700) ? 90 : 45);
      } else if (JEMU.setJoy2) {
        g.setColor(Color.red);
        g.setFont(new Font("Tahoma", 2, (getWidth() > 700) ? 34 : 18));
        g.drawString("Press Joystick button for Fire 2 (ESC to skip)", 10, (getWidth() > 700) ? 90 : 45);
      } 
    } 
    if (CPC.YM_Play && !CPC.playmovie) {
      g.setFont(new Font("Tahoma", 1, 16));
      g.setColor(TRANSBLACK);
      g.drawImage(this.ymplay, 10, 12, this);
      if (title.length() != 1 && !CPC.oldYM) {
        if (!lowperformance) {
          g.drawString("Title: " + title, 36, 30);
          g.drawString("Autor: " + author, 36, 48);
          g.drawString("Creator: " + creator, 36, 66);
        } 
        g.setColor(TRANS);
        g.drawString("Title: " + title, 34, 28);
        g.drawString("Autor: " + author, 34, 46);
        g.drawString("Creator: " + creator, 34, 64);
      } 
      g.setColor(TRANSBLACK);
      if (CPC.atari_st_mode) {
        if (!lowperformance)
          g.drawString("playing 2 MHz Atari ST file...", 36, 88); 
        g.setColor(TRANS);
        g.drawString("playing 2 MHz Atari ST file...", 34, 86);
      } else if (CPC.spectrum_mode) {
        if (!lowperformance)
          g.drawString("playing 1,77 MHz ZX Spectrum file...", 36, 88); 
        g.setColor(TRANS);
        g.drawString("playing 1,77 MHz ZX Spectrum file...", 34, 86);
      } else {
        if (!lowperformance)
          g.drawString("playing 1 MHz Amstrad CPC file...", 36, 88); 
        g.setColor(TRANS);
        g.drawString("playing 1 MHz Amstrad CPC file...", 34, 86);
      } 
      g.setColor(TRANSBLACK);
      if (CPC.oldYM) {
        if (!lowperformance)
          g.drawString("Old YM2/3 file", 36, 34); 
        g.setColor(TRANS);
        g.drawString("Old YM2/3 file", 34, 32);
      } 
      g.setFont(new Font("Tahoma", 3, 22));
      if (!lowperformance) {
        g.setColor(TRANSBLACK);
        g.drawString(YMControl.Monitor, 36, 114);
      } 
      g.setColor(TRANS);
      g.drawString(YMControl.Monitor, 34, 112);
      if (left != 0)
        for (int i = 0; i < left / 2; i++) {
          if (!lowperformance) {
            g.setColor(LED_BORDER);
            g.fillRect(2 + i * 13, 121, 16, 16);
          } 
          g.setColor(LED);
          g.fillRect(4 + i * 13, 123, 12, 12);
        }  
      if (right != 0)
        for (int i = 0; i < right / 2; i++) {
          if (!lowperformance) {
            g.setColor(GREEN_BORDER);
            g.fillRect(2 + i * 13, 138, 16, 16);
          } 
          g.setColor(GREEN);
          g.fillRect(4 + i * 13, 140, 12, 12);
        }  
    } 
    if (CPC.YM_Rec && !lowperformance)
      g.drawImage(this.ymrec, 10, 12, this); 
    if (CPC.recordKeys) {
      this.flashkey++;
      if (this.flashkey > 25)
        if (imageRect.height >= 540) {
          g.drawImage(this.recb, 10, 12, this);
        } else {
          g.drawImage(this.recs, 10, 12, this);
        }  
      if (this.flashkey == 50)
        this.flashkey = 0; 
    } 
    if (CPC.playKeys) {
      this.flashkey++;
      if (this.flashkey > 25)
        if (imageRect.height >= 540) {
          g.drawImage(this.playb, 10, 12, this);
        } else {
          g.drawImage(this.plays, 10, 12, this);
        }  
      if (this.flashkey == 50)
        this.flashkey = 0; 
    } 
    if ((filter_dosbox || filter_dosboxb) && this.showeffect) {
      if (this.screenw != (getSize()).width) {
        this.screenw = (getSize()).width;
        this.screenh = (getSize()).height;
      } 
      for (int xx = 0; xx < this.screenw; xx += 768) {
        for (int yy = 0; yy < this.screenh; yy += 544)
          g.drawImage(this.dotmatrix, xx, yy, 768, 544, this); 
      } 
    } 
    if (this.redoBorders != Switches.mask) {
      this.redoBorders = Switches.mask;
      this.checkFullScreenBorder = 0;
    } 
    if (this.checkFullScreenBorder < 15)
      this.checkFullScreenBorder++; 
    if (this.checkFullScreenBorder < 10) {
      if (!Switches.mask) {
        JEMU.leftdistance.getGraphics().drawImage(this.monbord, 0, 0, JEMU.leftdistance.getWidth(), JEMU.leftdistance.getHeight(), this);
        JEMU.topdistance.getGraphics().drawImage(this.monbord, 0, 0, JEMU.topdistance.getWidth(), JEMU.topdistance.getHeight(), this);
      } else {
        Graphics l = JEMU.leftdistance.createGraphics();
        l.setColor(new Color(789774));
        l.fillRect(0, 0, JEMU.leftdistance.getWidth(), JEMU.leftdistance.getHeight());
        l = JEMU.topdistance.createGraphics();
        l.setColor(new Color(789774));
        l.fillRect(0, 0, JEMU.topdistance.getWidth(), JEMU.topdistance.getHeight());
      } 
      JEMU.toplabel.repaint();
      JEMU.downlabel.repaint();
      JEMU.leftlabel.repaint();
      JEMU.rightlabel.repaint();
    } 
    if (!CPC.YM_Play && !use3d) {
      if (this.showeffect)
        g.drawImage(this.mask, imageRect.x, imageRect.y, imageRect.width, imageRect.height + 1, this); 
      if (this.masked)
        g.drawImage(this.mask, imageRect.x, imageRect.y, imageRect.width, imageRect.height + 1, this); 
    } else if (!use3d) {
      g.drawImage(this.mask1, imageRect.x, imageRect.y, imageRect.width, imageRect.height + 1, this);
    } 
  }
  
  public void doTouchFPS() {
    long time = System.currentTimeMillis();
    this.mNextFPS++;
    if (time - this.mLastFPSTime >= 1000L) {
      mCurrFPS = this.mNextFPS;
      this.mNextFPS = 0;
      this.mLastFPSTime = time;
    } 
  }
  
  protected void drawScreenCoords(Graphics g) {
    g.setColor(Color.white);
    g.drawLine(GateArray.cpc.getBorderL(), 0, GateArray.cpc.getBorderL(), 544);
    g.drawLine(GateArray.cpc.getBorderR(), 0, GateArray.cpc.getBorderR(), 544);
    g.drawLine(0, GateArray.cpc.getBorderH(), 768, GateArray.cpc.getBorderH());
    g.drawLine(0, 560 - GateArray.cpc.getBorderH(), 768, 560 - GateArray.cpc.getBorderH());
    int x = GateArray.cpc.getHPOS();
    int y = GateArray.cpc.getVPOS();
    for (int xx = 0; xx < getWidth(); xx += 6)
      g.drawLine(xx, y, xx + 2, y); 
    for (int yy = 0; yy < getHeight(); yy += 6)
      g.drawLine(x, yy, x, yy + 2); 
  }
  
  public void paintBalls(Graphics g) {
    balls(g, this.driveam, this.drivebm, this.driveam);
    for (this.ck = 0; this.ck < this.ch; this.ck++) {
      this.cj = ((int)(Math.cos(this.co + (this.ck / 50.0F) * 12.566370964050293D) * Math.sin(this.cl) * 20.0D + Math.cos((2.0F * this.cn) / 2.0D - (this.ck / 50.0F * 6.28F)) * 40.0D - Math.sin((this.cn / 2.0F + this.cm) + (this.ck / 50.0F) * 6.283185005187988D) * 60.0D) + 160 - 7 + 40) * this.zoom;
      this.ci = ((int)(Math.cos((this.cn * 1.5F) + (this.ck / 50.0F) * 6.283185005187988D) * Math.sin(this.cm) * 20.0D - Math.sin((4.0F * this.co) / 3.0D + (this.ck / 50.0F * 6.28F * 2.0F)) * 40.0D + Math.sin((this.co / 2.0F + this.cl) + (this.ck / 50.0F) * 6.283185005187988D) * 30.0D) + 100 - 7) * this.zoom;
      if (this.zoom >= 3) {
        g.drawImage(this.ballbb, this.cj, this.ci, null);
      } else if (this.zoom >= 2) {
        g.drawImage(this.ballb, this.cj, this.ci, null);
      } else {
        g.drawImage(this.ball, this.cj, this.ci, null);
      } 
    } 
    this.co = (float)(this.co + 0.029999999329447746D);
    this.cn = (float)(this.cn + 0.021900000050663948D);
    this.cm = (float)(this.cm + 0.027300000190734863D);
    this.cl = (float)(this.cl + 0.030899999663233757D);
  }
  
  public void setBackground(Color bg) {}
  
  public void paintComponent(Graphics g) {
    if (remask) {
      remask = false;
      changePerformance();
    } 
    if (image == null)
      return; 
    this.af++;
    if (this.af > 4)
      this.af = 1; 
    paintImage(g);
    if (!lowperformance && CPC.YM_Play)
      paintBalls(g); 
    if (!GateArray.cpc.isRunning() || showpause != -1)
      drawScreenCoords(g); 
    painted = true;
  }
  
  public static float quality = 0.7F;
  
  BufferedImage bi;
  
  Graphics ge;
  
  float[] scales;
  
  float[] offsets;
  
  RescaleOp rop;
  
  int xpos;
  
  int xstep;
  
  boolean cG;
  
  public float cf;
  
  public float ce;
  
  public float cd;
  
  public float cc;
  
  public float ca;
  
  public float b9;
  
  public float b8;
  
  ActionListener update;
  
  Timer healthLine;
  
  public BufferedImage getImag() {
    return image;
  }
  
  public BufferedImage getImage() {
    BufferedImage off_Image = new BufferedImage(imageRect.width, imageRect.height, 1);
    Graphics g = off_Image.createGraphics();
    g.setColor(Color.black);
    g.fillRect(0, 0, imageRect.width, imageRect.height);
    if (Switches.bilinear) {
      Graphics2D g2 = (Graphics2D)g;
      g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
      g = g2;
    } 
    if (!CPC.YM_Play || CPC.playmovie) {
      if (sourceRect != null) {
        g.drawImage(image, imageRect.x, imageRect.y, imageRect.x + imageRect.width, imageRect.y + imageRect.height, sourceRect.x, sourceRect.y, sourceRect.x + sourceRect.width, sourceRect.y + sourceRect.height, null);
      } else if (this.sameSize) {
        g.drawImage(image, imageRect.x, imageRect.y, null);
      } else {
        g.drawImage(image, imageRect.x, imageRect.y, imageRect.width, imageRect.height, null);
      } 
    } else {
      if (skin == 1) {
        g.drawImage(this.YMmode, imageRect.x, imageRect.y, imageRect.width, imageRect.height, null);
      } else {
        g.drawImage(this.YMmode2, imageRect.x, imageRect.y, imageRect.width, imageRect.height, null);
      } 
      if (!lowperformance)
        paintBalls(g); 
    } 
    if (this.scanlines)
      if (Switches.monitormode == 0 || Switches.monitormode == 1 || Switches.monitormode == 5) {
        if (filter_dosbox || filter_dosboxb) {
          this.rgbcount = 0;
          int i;
          for (i = 0; i < imageRect.width * 2; i++) {
            g.setColor(RGB[this.rgbcount]);
            this.rgbcount++;
            if (this.rgbcount > 2)
              this.rgbcount = 0; 
            g.drawLine(imageRect.x + i, imageRect.y, imageRect.x, imageRect.y + i);
          } 
          g.setColor(SCAN_DARK);
          for (i = 0; i < imageRect.height; i += 2)
            g.drawLine(imageRect.x, imageRect.y + i, imageRect.width, imageRect.y + i); 
        } else {
          g.setColor(SCAN);
          for (int i = 0; i < imageRect.width; i += 2)
            g.drawLine(imageRect.x + i, imageRect.y, imageRect.x + i, imageRect.height); 
        } 
      } else {
        for (int i = 0; i < imageRect.height; i += 2)
          g.drawLine(imageRect.x, imageRect.y + i, imageRect.width, imageRect.y + i); 
      }  
    if (CPC.YM_Play && !CPC.playmovie) {
      g.drawImage(this.ymplay, 10, 12, this);
      if (title.length() != 1) {
        g.setColor(TRANSBLACK);
        g.drawString("Title: " + title, 36, 20);
        g.drawString("Autor: " + author, 36, 34);
        g.drawString("Creator: " + creator, 36, 48);
        g.setColor(TRANS);
        g.drawString("Title: " + title, 34, 18);
        g.drawString("Autor: " + author, 34, 32);
        g.drawString("Creator: " + creator, 34, 46);
      } 
      g.setColor(TRANSBLACK);
      if (CPC.atari_st_mode && !CPC.oldYM) {
        g.drawString("playing 2 MHz Atari ST file...", 36, 62);
        g.setColor(TRANS);
        g.drawString("playing 2 MHz Atari ST file...", 34, 60);
      } else if (CPC.spectrum_mode && !CPC.oldYM) {
        g.drawString("playing 1,77 MHz ZX Spectrum file...", 36, 62);
        g.setColor(TRANS);
        g.drawString("playing 1,77 MHz ZX Spectrum file...", 34, 60);
      } else if (CPC.atari_st_mode && CPC.oldYM) {
        g.drawString("playing old YM3 file...", 36, 62);
        g.setColor(TRANS);
        g.drawString("playing old YM3 file...", 34, 60);
      } else {
        g.drawString("playing 1 MHz Amstrad CPC file...", 36, 62);
        g.setColor(TRANS);
        g.drawString("playing 1 MHz Amstrad CPC file...", 34, 60);
      } 
      g.setColor(TRANSBLACK);
      g.drawString(YMControl.Monitor, 18, 114);
      g.setColor(TRANS);
      g.drawString(YMControl.Monitor, 14, 110);
      if (left != 0)
        for (int i = 0; i < left / 2; i++) {
          g.setColor(LED_BORDER);
          g.fillRect(2 + i * 13, 121, 16, 16);
          g.setColor(LED);
          g.fillRect(4 + i * 13, 123, 12, 12);
        }  
      if (right != 0)
        for (int i = 0; i < right / 2; i++) {
          g.setColor(GREEN_BORDER);
          g.fillRect(2 + i * 13, 138, 16, 16);
          g.setColor(GREEN);
          g.fillRect(4 + i * 13, 140, 12, 12);
        }  
    } 
    if (CPC.YM_Rec)
      g.drawImage(this.ymrec, 10, 12, this); 
    if (this.showeffect)
      g.drawImage(this.mask, imageRect.x, imageRect.y, imageRect.width, imageRect.height, this); 
    return off_Image;
  }
  
  public static void setFade(int fade) {
    fader = fade;
  }
  
  public Dimension getPreferredSize() {
    Insets insets = getInsets();
    return new Dimension(imageRect.width + insets.left + insets.right, imageRect.height + insets.top + insets.bottom);
  }
  
  public int getImageWidth() {
    return this.imageWidth;
  }
  
  public int getImageHeight() {
    return this.imageHeight;
  }
  
  public boolean isPainted() {
    return painted;
  }
  
  public void setPainted(boolean value) {
    painted = value;
  }
  
  public void waitPainted() {
    while (!painted)
      Thread.yield(); 
  }
  
  protected void processFocusEvent(FocusEvent e) {
    super.processFocusEvent(e);
    if (e.getID() == 1004) {
      Desktop.tofront = true;
      System.out.println("Display Focused");
      if (Desktop.hideMouse.isSelected()) {
        setCursor(this.blankCursor);
      } else {
        setCursor(Cursor.getDefaultCursor());
      } 
    } else {
      System.out.println("Display Lost Focus");
      setCursor(Cursor.getDefaultCursor());
    } 
  }
  
  public final void balls(Graphics g, Image image1, Image image2, Image image3) {
    if ((this.cd + 0.4000000059604645D) * 100.0D % 628.0D < 157.0D || (this.cd + 0.4000000059604645D) * 100.0D % 628.0D > 471.0D) {
      this.cG = true;
    } else {
      this.cG = false;
    } 
    this.ge.drawImage(image, 0, 0, 384, 272, null);
    Graphics2D g2d = (Graphics2D)g;
    this.ca = (float)(Math.cos(this.ce + 0.800000011920929D) + 1.5D);
    this.b9 = (float)(Math.cos(this.cd + 0.4000000059604645D) + 1.5D);
    this.b8 = (float)(Math.cos(this.cc) + 1.5D);
    if (this.cG && !use3d) {
      this.ck = 0;
      while (this.ck < 15) {
        this.ci = (int)(Math.sin(this.cf + this.ck * 0.1599999964237213D * 1.5D) * 39.0D + 98.0D - 8.0D + 5.0D);
        g2d.drawImage(this.bi, this.rop, this.xpos, (int)(this.ci * 1.5D));
        g2d.drawImage(this.bi, this.rop, 384 - this.xpos, (int)(this.ci * 1.5D));
        this.ck++;
      } 
    } 
    double d;
    g.drawImage(image3, (int)(164.0F + (float)Math.cos(d = (this.cc / 2.0F)) * 80.0F + (float)Math.sin(d = this.cc) * 30.0F * (float)Math.cos(d = -this.cc)) * 2, 202 + (int)((float)Math.sin(d = this.cc) * 100.0F - (float)Math.cos(d = this.cc - 0.4000000059604645D) * 25.0F * (float)Math.sin(d = this.cc - 0.4000000059604645D)) * 2, (int)(30.0F * this.b8) * 4, (int)(30.0F * this.b8 * 4.0F), null);
    g.drawImage(image2, (int)(164.0F + (float)Math.cos(d = (this.cd / 2.0F) + 0.800000011920929D) * 80.0F + (float)Math.sin(d = this.cd + 0.4000000059604645D) * 30.0F * (float)Math.cos(d = -this.cd + 0.4000000059604645D)) * 2, 202 + (int)((float)Math.sin(d = this.cd + 0.4000000059604645D) * 100.0F - (float)Math.cos(d = this.cd) * 25.0F * (float)Math.sin(d = this.cd)) * 2, (int)(30.0F * this.b9) * 4, (int)(30.0F * this.b9 * 4.0F), null);
    g.drawImage(image1, (int)(164.0F + (float)Math.cos(d = (this.ce / 2.0F) + 1.600000023841858D) * 80.0F + (float)Math.sin(d = this.ce + 0.800000011920929D) * 30.0F * (float)Math.cos(d = -this.ce + 0.800000011920929D)) * 2, 202 + (int)((float)Math.sin(d = this.ce + 0.800000011920929D) * 100.0F - (float)Math.cos(d = this.ce + 0.4000000059604645D) * 25.0F * (float)Math.sin(d = this.ce + 0.4000000059604645D)) * 2, (int)(30.0F * this.ca) * 4, (int)(30.0F * this.ca * 4.0F), null);
    if (!this.cG && !use3d)
      for (this.ck = 0; this.ck < 15; this.ck++) {
        this.ci = (int)(Math.sin(this.cf + this.ck * 0.1599999964237213D * 1.5D) * 39.0D + 98.0D - 8.0D + 5.0D);
        g2d.drawImage(this.bi, this.rop, this.xpos, (int)(this.ci * 1.5D));
        g2d.drawImage(this.bi, this.rop, 384 - this.xpos, (int)(this.ci * 1.5D));
      }  
    this.xpos += this.xstep;
    if (this.xpos > 192)
      this.xstep--; 
    if (this.xpos < 192)
      this.xstep++; 
    this.ce += 0.03F;
    this.cd = this.ce - 0.1F;
    this.cc = this.ce - 0.2F;
    this.cf = (float)(this.cf + 0.029999999329447746D);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\Display.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */