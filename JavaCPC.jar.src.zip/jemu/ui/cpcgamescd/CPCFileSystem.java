package jemu.ui.cpcgamescd;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Arrays;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import jemu.core.Util;

public class CPCFileSystem {
  protected final int DSK_HEADER_LENGTH = 256;
  
  protected final int TRACK_INFO_LENGTH = 256;
  
  protected final int[] NUMBER_OF_TRACKS = new int[] { 40, 40, 40, 160, 80 };
  
  protected final int[] MULTIPLIER = new int[] { 1, 1, 1, 4, 2 };
  
  protected final int[] START_TRACK = new int[] { 0, 2, 1, 2, 0 };
  
  protected final int[] SECTORADD = new int[] { 192, 64, 0, 0, 16 };
  
  protected final int[] SECTOR_SIZE = new int[] { 512, 512, 512, 512, 512 };
  
  protected final int[] TRACK_SIZE = new int[] { 4608, 4608, 4096, 4608, 5120 };
  
  protected final int[] MAX_BLOCKS = new int[] { 178, 169, 154, 704, 796 };
  
  protected final int[] MAX_ENTRIES = new int[] { 64, 64, 64, 128, 128 };
  
  boolean linear = false;
  
  protected int FORMAT;
  
  public int[] users;
  
  public String[] files;
  
  public byte[] buffer;
  
  public int[][] blocks;
  
  public boolean[] readOnly;
  
  public boolean[] system;
  
  public int[] ext;
  
  public int[] rec;
  
  public int[] fileentries;
  
  public int[] diroffset;
  
  public int[] skew;
  
  protected static int entries;
  
  byte[] HEADER;
  
  byte[] RESULT;
  
  public void writeFile(String file, String diskname) {
    if (this.buffer == null)
      return; 
    String[] filess = null;
    if (file.contains("*")) {
      file = file.replace("*", "");
      File check = new File(file);
      filess = check.list();
    } 
    if (filess != null) {
      for (int i = 0; i < filess.length; i++)
        copyToDSK(file, filess[i], diskname); 
    } else {
      copyToDSK("", file, diskname);
    } 
  }
  
  public void cleanUp() {
    try {
      setSkew();
    } catch (Exception e) {
      return;
    } 
    DIR();
    byte[] dir = getDIR();
    byte[][] direntry = new byte[500][32];
    for (int g = 0; g < 500; g++) {
      for (int k = 0; k < 32; k++)
        direntry[g][k] = -27; 
    } 
    int pos = 0;
    for (int j = 0; j < dir.length - 32; j += 32) {
      if ((dir[j] & 0xFF) != 229) {
        System.arraycopy(dir, j, direntry[pos], 0, 32);
        pos++;
      } 
    } 
    dir = new byte[dir.length];
    for (int p = 0; p < dir.length; p++)
      dir[p] = -27; 
    pos = 0;
    for (int i = 0; i < dir.length - 32; i += 32) {
      if (direntry[pos] != null) {
        System.arraycopy(direntry[pos], 0, dir, i, 32);
        pos++;
      } 
    } 
    setDir(dir);
  }
  
  public void cleanUp(String name) {
    String checkname = name.substring(0, name.length() - 3);
    checkname = checkname + ".";
    checkname = checkname + name.substring(8);
    setSkew();
    DIR();
    byte[] dir = getDIR();
    byte[][] direntry = new byte[500][32];
    for (int g = 0; g < 500; g++) {
      for (int p = 0; p < 32; p++)
        direntry[g][p] = -27; 
    } 
    int pos = 0;
    int i;
    for (i = 0; i < dir.length - 32; i += 32) {
      if ((dir[i] & 0xFF) == 229 && checkname.equals(new String(dir, i + 1, checkname.length()))) {
        System.arraycopy(new byte[32], 0, direntry[pos], 0, 32);
        pos++;
      } 
    } 
    dir = new byte[dir.length];
    pos = 0;
    for (i = 0; i < dir.length - 32; i += 32) {
      if (direntry[pos] != null) {
        System.arraycopy(direntry[pos], 0, dir, i, 32);
        pos++;
      } 
    } 
    setDir(dir);
  }
  
  protected void delete(int pos) {
    if (pos < 0)
      return; 
    int deluser = this.users[this.fileentries[pos]];
    setSkew();
    DIR();
    try {
      if (this.files[this.fileentries[pos]] != null) {
        String checkname = this.files[this.fileentries[pos]];
        for (int it = 0; it < this.files.length; it++) {
          if (this.files[it] != null && 
            this.files[it].equals(checkname) && this.users[it] == deluser) {
            this.users[it] = 229;
            this.buffer[this.diroffset[it]] = (byte)this.users[it];
            System.out.println(this.files[it] + " deleted");
          } 
        } 
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  protected void rename(int pos, String newname) {
    while (newname.length() < 11)
      newname = newname + " "; 
    if (pos < 0)
      return; 
    setSkew();
    DIR();
    if (this.files[this.fileentries[pos]] != null) {
      String checkname = this.files[this.fileentries[pos]];
      for (int it = 0; it < this.files.length; it++) {
        if (this.files[it] != null && 
          this.files[it].equals(checkname))
          if (this.users[it] == this.users[this.fileentries[pos]])
            for (int i = 0; i < this.files.length; i++) {
              if (this.files[i] != null && 
                this.files[i].equals(checkname))
                try {
                  byte[] name = newname.getBytes("UTF-8");
                  for (int ir = 0; ir < name.length; ir++)
                    this.buffer[this.diroffset[it] + ir + 1] = name[ir]; 
                  byte[] head = new byte[32];
                  System.arraycopy(this.buffer, this.diroffset[it], head, 0, 32);
                } catch (Exception e) {
                  e.printStackTrace();
                }  
            }   
      } 
    } 
  }
  
  protected void readOnly(int pos) {
    if (pos < 0)
      return; 
    setSkew();
    DIR();
    if (this.files[this.fileentries[pos]] != null) {
      String checkname = this.files[this.fileentries[pos]];
      for (int it = 0; it < this.files.length; it++) {
        if (this.files[it] != null && 
          this.files[it].equals(checkname))
          if (this.users[it] == this.users[this.fileentries[pos]])
            for (int i = 0; i < this.files.length; i++) {
              if (this.files[i] != null && 
                this.files[i].equals(checkname)) {
                int cha = this.buffer[this.diroffset[it] + 9] & 0xFF;
                if (cha < 128) {
                  cha |= 0x80;
                } else {
                  cha &= 0x7F;
                } 
                this.buffer[this.diroffset[it] + 9] = (byte)cha;
                it++;
              } 
            }   
      } 
    } 
  }
  
  protected void system(int pos) {
    if (pos < 0)
      return; 
    setSkew();
    DIR();
    if (this.files[this.fileentries[pos]] != null) {
      String checkname = this.files[this.fileentries[pos]];
      for (int it = 0; it < this.files.length; it++) {
        if (this.files[it] != null && 
          this.files[it].equals(checkname))
          if (this.users[it] == this.users[this.fileentries[pos]])
            for (int i = 0; i < this.files.length; i++) {
              if (this.files[i] != null && 
                this.files[i].equals(checkname)) {
                int cha = this.buffer[this.diroffset[it] + 10] & 0xFF;
                System.err.println(cha);
                if (cha < 128) {
                  cha |= 0x80;
                } else {
                  cha &= 0x7F;
                } 
                this.buffer[this.diroffset[it] + 10] = (byte)cha;
                it++;
              } 
            }   
      } 
    } 
  }
  
  protected void saveDisk(String diskname) {
    try {
      BufferedOutputStream bis = new BufferedOutputStream(new FileOutputStream(new File(diskname)));
      bis.write(this.buffer);
      bis.close();
    } catch (Exception exception) {}
  }
  
  protected byte[] getDIR() {
    byte[] dir = new byte[this.SECTOR_SIZE[this.FORMAT] * 4 * this.disksides];
    if (!this.linear) {
      System.arraycopy(this.buffer, 512 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]), dir, 0, this.SECTOR_SIZE[this.FORMAT]);
      System.arraycopy(this.buffer, 512 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + this.SECTOR_SIZE[this.FORMAT] * 2, dir, this.SECTOR_SIZE[this.FORMAT], this.SECTOR_SIZE[this.FORMAT]);
      System.arraycopy(this.buffer, 512 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + this.SECTOR_SIZE[this.FORMAT] * 4, dir, this.SECTOR_SIZE[this.FORMAT] * 2, this.SECTOR_SIZE[this.FORMAT]);
      System.arraycopy(this.buffer, 512 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + this.SECTOR_SIZE[this.FORMAT] * 6, dir, this.SECTOR_SIZE[this.FORMAT] * 3, this.SECTOR_SIZE[this.FORMAT]);
      if (this.disksides == 2) {
        System.arraycopy(this.buffer, 512 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + this.SECTOR_SIZE[this.FORMAT] * 8, dir, this.SECTOR_SIZE[this.FORMAT] * 4, this.SECTOR_SIZE[this.FORMAT]);
        System.arraycopy(this.buffer, 512 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + this.SECTOR_SIZE[this.FORMAT] * 1, dir, this.SECTOR_SIZE[this.FORMAT] * 5, this.SECTOR_SIZE[this.FORMAT]);
        System.arraycopy(this.buffer, 512 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + this.SECTOR_SIZE[this.FORMAT] * 3, dir, this.SECTOR_SIZE[this.FORMAT] * 6, this.SECTOR_SIZE[this.FORMAT]);
        System.arraycopy(this.buffer, 512 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + this.SECTOR_SIZE[this.FORMAT] * 5, dir, this.SECTOR_SIZE[this.FORMAT] * 7, this.SECTOR_SIZE[this.FORMAT]);
      } 
    } else {
      System.arraycopy(this.buffer, 512 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]), dir, 0, this.SECTOR_SIZE[this.FORMAT] * 4 * this.disksides);
    } 
    return dir;
  }
  
  protected void setDir(byte[] dir) {
    if (!this.linear) {
      System.arraycopy(dir, 0, this.buffer, 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + 256, this.SECTOR_SIZE[this.FORMAT]);
      System.arraycopy(dir, this.SECTOR_SIZE[this.FORMAT], this.buffer, 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + 256 + this.SECTOR_SIZE[this.FORMAT] * 2, this.SECTOR_SIZE[this.FORMAT]);
      System.arraycopy(dir, this.SECTOR_SIZE[this.FORMAT] * 2, this.buffer, 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + 256 + this.SECTOR_SIZE[this.FORMAT] * 4, this.SECTOR_SIZE[this.FORMAT]);
      System.arraycopy(dir, this.SECTOR_SIZE[this.FORMAT] * 3, this.buffer, 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + 256 + this.SECTOR_SIZE[this.FORMAT] * 6, this.SECTOR_SIZE[this.FORMAT]);
      if (this.disksides == 2) {
        System.arraycopy(dir, this.SECTOR_SIZE[this.FORMAT] * 4, this.buffer, 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + 256 + this.SECTOR_SIZE[this.FORMAT] * 8, this.SECTOR_SIZE[this.FORMAT]);
        System.arraycopy(dir, this.SECTOR_SIZE[this.FORMAT] * 5, this.buffer, 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + 256 + this.SECTOR_SIZE[this.FORMAT] * 1, this.SECTOR_SIZE[this.FORMAT]);
        System.arraycopy(dir, this.SECTOR_SIZE[this.FORMAT] * 6, this.buffer, 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + 256 + this.SECTOR_SIZE[this.FORMAT] * 3, this.SECTOR_SIZE[this.FORMAT]);
        System.arraycopy(dir, this.SECTOR_SIZE[this.FORMAT] * 7, this.buffer, 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + 256 + this.SECTOR_SIZE[this.FORMAT] * 5, this.SECTOR_SIZE[this.FORMAT]);
      } 
    } else {
      System.arraycopy(dir, 0, this.buffer, 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + 256, this.SECTOR_SIZE[this.FORMAT] * 4 * this.disksides);
    } 
  }
  
  public int getSpace() {
    int space = this.MAX_BLOCKS[this.FORMAT];
    System.out.println("Disk has " + space + "K");
    int[] reserved = new int[this.TRACK_SIZE[this.FORMAT]];
    int pos = 0;
    int i;
    for (i = 0; i < this.files.length; i++) {
      try {
        for (int g = 0; g < (this.blocks[i]).length; g++) {
          if (this.users[i] != 229) {
            reserved[pos] = this.blocks[i][g];
            pos++;
          } 
        } 
      } catch (Exception ex) {
        return 0;
      } 
    } 
    for (i = 0; i < pos; i++) {
      if (reserved[i] != 0)
        space--; 
    } 
    return space;
  }
  
  public int getDataSpace() {
    int space = 178;
    System.out.println("Disk has " + space + "K");
    int[] reserved = new int[this.TRACK_SIZE[this.FORMAT]];
    int pos = 0;
    int i;
    for (i = 0; i < this.files.length; i++) {
      try {
        for (int g = 0; g < (this.blocks[i]).length; g++) {
          if (this.users[i] != 229) {
            reserved[pos] = this.blocks[i][g];
            pos++;
          } 
        } 
      } catch (Exception ex) {
        return 0;
      } 
    } 
    for (i = 0; i < pos; i++) {
      if (reserved[i] != 0)
        space--; 
    } 
    return space;
  }
  
  public void Delete(String checkname) {
    for (int it = 0; it < this.files.length; it++) {
      if (this.files[it] != null && 
        this.files[it].equals(checkname)) {
        this.users[it] = 229;
        this.buffer[this.diroffset[it]] = (byte)this.users[it];
      } 
    } 
    cleanUp();
  }
  
  public void copyToDSK(String path, String file, String diskname) {
    setSkew();
    DIR();
    if (this.numberfiles >= this.MAX_ENTRIES[this.FORMAT]) {
      JOptionPane.showMessageDialog(new JFrame(), "Error! Directory is full!\r\nPlease clean it up first!", "Error!", 2);
      return;
    } 
    String dskname = file.toUpperCase().replace(".", "\"");
    while (dskname.contains("\\"))
      dskname = dskname.substring(1); 
    while (dskname.contains("/"))
      dskname = dskname.substring(1); 
    String[] n = dskname.split("\"");
    while (n[0].length() > 8)
      n[0] = n[0].substring(0, n[0].length() - 1); 
    while (n[0].length() < 8)
      n[0] = n[0] + " "; 
    try {
      while (n[1].length() > 3)
        n[1] = n[1].substring(0, n[1].length() - 1); 
      while (n[1].length() < 3)
        n[1] = n[1] + " "; 
      dskname = n[0] + n[1];
    } catch (Exception r) {
      dskname = n[0] + "   ";
    } 
    String checkname = dskname.substring(0, dskname.length() - 3);
    checkname = checkname + ".";
    checkname = checkname + dskname.substring(8);
    for (int i = 0; i < this.files.length; i++) {
      if (this.files[i] != null)
        if (this.files[i].equals(checkname)) {
          Object[] options = { "Yes, please", "No way!" };
          int nd = JOptionPane.showOptionDialog(new JFrame(), checkname + " already exists.\r\nAre you sure you want to overwrite it?", "Please confirm", 0, 3, null, options, options[0]);
          if (nd == 0) {
            for (int it = 0; it < this.files.length; it++) {
              if (this.files[it] != null && 
                this.files[it].equals(checkname)) {
                this.users[it] = 229;
                this.buffer[this.diroffset[it]] = (byte)this.users[it];
              } 
            } 
            cleanUp();
            break;
          } 
          return;
        }  
    } 
    byte[] dir = getDIR();
    try {
      int[] reserved = new int[this.TRACK_SIZE[this.FORMAT]];
      int pos = 0;
      for (int j = 0; j < this.files.length; j++) {
        try {
          int i1 = 0;
          for (int g = 0; g < (this.blocks[j]).length; g++) {
            reserved[pos] = this.blocks[j][g];
            pos++;
          } 
        } catch (Exception ex) {
          ex.printStackTrace();
          reserved = new int[this.TRACK_SIZE[this.FORMAT]];
          reserved[0] = 1;
          System.exit(0);
          break;
        } 
      } 
      int pp = 0;
      Arrays.sort(reserved);
      for (int t = 0; t < reserved.length; t++) {
        if (reserved[t] != 0 && reserved[t] <= this.MAX_BLOCKS[this.FORMAT]) {
          if (pp == 0);
          pp++;
          if (pp > 15)
            pp = 0; 
        } 
      } 
      int[] unreserved = new int[reserved.length];
      for (int k = 0; k < reserved.length; k++)
        unreserved[k] = reserved[reserved.length - 1 - k]; 
      System.arraycopy(unreserved, 0, reserved, 0, reserved.length);
      File fil = new File(path + file);
      BufferedInputStream in = new BufferedInputStream(new FileInputStream(fil));
      byte[] data = new byte[in.available()];
      in.read(data);
      in.close();
      if (CheckAMSDOS(data)) {
        this.filesize = getWord(data, 24) + 128;
        if (this.addrem) {
          data = removeHeader(data);
          this.filesize = data.length;
        } 
      } else if (this.addrem) {
        data = makeHeader(2, 0, data.length, 0, "", data);
        this.filesize = getWord(data, 24) + 128;
      } else {
        if ((data[data.length - 1] & 0xFF) != 26) {
          byte[] ddata = new byte[data.length + 1];
          System.arraycopy(data, 0, ddata, 0, data.length);
          ddata[ddata.length - 1] = 26;
          data = new byte[ddata.length];
          System.arraycopy(ddata, 0, data, 0, ddata.length);
        } 
        this.filesize = data.length;
      } 
      int exts = (int)Math.ceil(this.filesize / 16384.0D);
      int pieces = exts * 32 - 1;
      byte[][] sectordata = new byte[pieces][];
      int size = this.filesize;
      int off = 0;
      for (int m = 0; m < pieces; m++) {
        int rsize = 512;
        if (size < 512)
          rsize = size; 
        sectordata[m] = new byte[rsize];
        System.arraycopy(data, off, sectordata[m], 0, rsize);
        off += rsize;
        size -= rsize;
      } 
      int fsize = this.filesize;
      int pr = 0;
      for (int p = 0; p < exts; p++) {
        byte[] direntry = new byte[32];
        direntry[0] = 0;
        System.arraycopy(dskname.getBytes("UTF-8"), 0, direntry, 1, (dskname.getBytes("UTF-8")).length);
        direntry[12] = (byte)p;
        int recsize = 128;
        if (fsize < 16384)
          recsize = (int)Math.ceil(fsize / 128.0D); 
        direntry[15] = (byte)recsize;
        int i1;
        for (i1 = 0; i1 < 16; i1++) {
          int ppos = 2;
          int g;
          for (g = 0; g < reserved.length; g++) {
            if (ppos == reserved[g]) {
              ppos = reserved[g] + 1;
              g = -1;
            } 
          } 
          for (g = reserved.length - 1; g > -1; g--) {
            if (reserved[g] != 0) {
              reserved[g + 1] = ppos;
              break;
            } 
          } 
          if (fsize < 0)
            ppos = 0; 
          fsize -= 1024;
          if (ppos >= this.MAX_BLOCKS[this.FORMAT] + 2) {
            JOptionPane.showMessageDialog(new JFrame(), "Error! Disk " + diskname + " is full!\r\nPlease clean it up first!", "Error!", 2);
            return;
          } 
          direntry[16 + i1] = (byte)ppos;
        } 
        for (i1 = 0; i1 < dir.length; i1 += 32) {
          if (dir[i1 + 1] == 0 || dir[i1] == -27) {
            System.arraycopy(direntry, 0, dir, i1, direntry.length);
            break;
          } 
        } 
        for (i1 = 16; i1 < direntry.length; i1++) {
          for (int interleaved = 0; interleaved < 2; interleaved++) {
            int block = direntry[i1] & 0xFF;
            int track = (block * 2 * this.MULTIPLIER[this.FORMAT] + interleaved) / this.discsectors;
            int sector = (block * 2 * this.MULTIPLIER[this.FORMAT] + interleaved) % this.discsectors;
            off = 256;
            off += this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]);
            off += 256 * (track + 1);
            off += this.TRACK_SIZE[this.FORMAT] * track;
            off += this.SECTOR_SIZE[this.FORMAT] * (this.skew[sector] - 1);
            if (block != 0)
              try {
                System.arraycopy(sectordata[pr], 0, this.buffer, off, (sectordata[pr++]).length);
              } catch (Exception exception) {} 
          } 
        } 
      } 
      setDir(dir);
      saveDisk(diskname);
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public byte[] get(String file) {
    File f = new File(file);
    if (f.exists())
      f.delete(); 
    this.buffer = getRom("empty.dsk", 204544);
    try {
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(f));
      bos.write(this.buffer);
      bos.close();
    } catch (Exception exception) {}
    return this.buffer;
  }
  
  public byte[] getEmptyDSK() {
    this.buffer = getRom("empty.dsk", 204544);
    return this.buffer;
  }
  
  public byte[] getRom(String name, int size) {
    byte[] buffer = new byte[size];
    int offs = 0;
    try {
      InputStream stream = null;
      try {
        InputStream is = getClass().getResourceAsStream(name);
        stream = is;
        while (size > 0) {
          int read = stream.read(buffer, offs, size);
          if (read == -1)
            break; 
          offs += read;
          size -= read;
        } 
      } finally {
        if (stream != null)
          stream.close(); 
      } 
    } catch (Exception exception) {}
    return buffer;
  }
  
  public void setFormat(int format) {
    this.FORMAT = format;
  }
  
  public static void main(String[] args) {
    CPCFileSystem sys = new CPCFileSystem();
    sys.get("testblank.dsk");
    sys.DIR();
    sys.writeFile("extracted/*", "TEST.DSK");
    System.exit(0);
    for (int i = 0; i < sys.fileentries.length; i++)
      sys.getFile(sys.fileentries[i]); 
  }
  
  public void getFile(int pos) {
    if (this.users[pos] == 229)
      return; 
    if (this.ext[pos] != 0)
      return; 
    try {
      int foff = 0;
      checkFile(pos, false);
      int[] realpos = new int[100];
      realpos[0] = pos;
      int rpos = 1;
      String name = this.files[pos].replace(" ", "");
      int fsize = this.rec[pos] * 128;
      for (int i = 0; i < this.files.length; i++) {
        if (this.files[pos].equals(this.files[i]) && 
          this.ext[i] != 0 && 
          this.users[i] != 229) {
          fsize += this.rec[i] * 128;
          realpos[rpos] = i;
        } 
      } 
      this.filesize = fsize;
      int exts = (int)Math.ceil(this.filesize / 16384.0D);
      byte[] Final = new byte[this.filesize];
      String folder = "extracted/";
      File f = new File(folder);
      if (!f.exists())
        f.mkdir(); 
      for (int pr = 0; pr <= exts; pr++) {
        for (int b = 0; b < 16; b++) {
          for (int interleaved = 0; interleaved < 2; interleaved++) {
            int block = this.blocks[realpos[pr]][b];
            int track = (block * 2 * this.MULTIPLIER[this.FORMAT] + interleaved) / this.discsectors;
            int sector = (block * 2 * this.MULTIPLIER[this.FORMAT] + interleaved) % this.discsectors;
            int off = 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]);
            off += 256 * (track + 1);
            off += this.TRACK_SIZE[this.FORMAT] * track;
            off += this.SECTOR_SIZE[this.FORMAT] * (this.skew[sector] - 1);
            for (int j = off; j < off + 512; j++) {
              try {
                Final[foff++] = this.buffer[j];
              } catch (Exception r) {
                break;
              } 
            } 
          } 
        } 
      } 
      if (!CheckAMSDOS(Final)) {
        int cut = 0;
        for (int j = Final.length - 2; j > Final.length - 20; j--) {
          if (Final[j] == 26 && Final[j] + 1 == 0) {
            cut++;
            break;
          } 
          cut++;
        } 
        if (cut < Final.length - 1) {
          byte[] buff = new byte[Final.length - cut];
          System.arraycopy(Final, 0, buff, 0, buff.length);
          Final = new byte[buff.length];
          System.arraycopy(buff, 0, Final, 0, buff.length);
        } 
        if (this.addrem)
          Final = makeHeader(2, 0, Final.length, 0, "", Final); 
      } else if (CheckAMSDOS(Final) && this.addrem) {
        Final = removeHeader(Final);
      } 
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File(folder + name)));
      bos.write(Final);
      bos.close();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public int deepCheck(int pos) {
    if (this.ext[pos] != 0)
      return 0; 
    try {
      int foff = 0;
      checkFile(pos, false);
      int[] realpos = new int[100];
      realpos[0] = pos;
      int rpos = 1;
      boolean hasheader = (this.filesize != 0);
      String name = this.files[pos].replace(" ", "");
      int fsize = this.rec[pos] * 128;
      for (int i = 0; i < this.files.length; i++) {
        if (this.files[pos].equals(this.files[i]) && 
          this.ext[i] != 0 && 
          this.users[i] != 229) {
          fsize += this.rec[i] * 128;
          realpos[rpos++] = i;
        } 
      } 
      this.filesize = fsize;
      int exts = (int)Math.ceil(this.filesize / 16384.0D);
      byte[] Final = new byte[this.filesize];
      String folder = "extracted/";
      File f = new File(folder);
      if (!f.exists())
        f.mkdir(); 
      for (int pr = 0; pr <= exts; pr++) {
        for (int b = 0; b < 16; b++) {
          for (int interleaved = 0; interleaved < 2; interleaved++) {
            int block = this.blocks[realpos[pr]][b];
            int track = (block * 2 * this.MULTIPLIER[this.FORMAT] + interleaved) / this.discsectors;
            int sector = (block * 2 * this.MULTIPLIER[this.FORMAT] + interleaved) % this.discsectors;
            int off = 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]);
            off += 256 * (track + 1);
            off += this.TRACK_SIZE[this.FORMAT] * track;
            off += this.SECTOR_SIZE[this.FORMAT] * (this.skew[sector] - 1);
            for (int j = off; j < off + 512; j++) {
              try {
                Final[foff++] = this.buffer[j];
              } catch (Exception r) {
                break;
              } 
            } 
          } 
        } 
      } 
      if (!CheckAMSDOS(Final)) {
        int cut = 0;
        if (this.addrem)
          Final = makeHeader(2, 0, Final.length, 0, "", Final); 
      } else if (CheckAMSDOS(Final) && this.addrem) {
        Final = removeHeader(Final);
      } 
      return Final.length;
    } catch (Exception e) {
      e.printStackTrace();
      return 0;
    } 
  }
  
  protected String internalname = "           ";
  
  protected int namepos = 1;
  
  protected int filetypepos = 18;
  
  protected int datalengthpos = 19;
  
  protected int datalocationpos = 21;
  
  protected int firstblockpos = 23;
  
  protected int filelengthpos = 24;
  
  protected int execaddresspos = 26;
  
  protected int lengthpos = 64;
  
  protected int checksumpos = 67;
  
  String content;
  
  public byte[] makeHeader(int type, int start, int length, int exec, String intname, byte[] SOURCEFILE) {
    if (SOURCEFILE == null)
      return SOURCEFILE; 
    this.HEADER = new byte[128];
    intname = intname.replace(".", "");
    while (intname.length() > 11)
      intname = intname.substring(0, intname.length() - 1); 
    intname = intname.toUpperCase();
    try {
      System.arraycopy("           ".getBytes("UTF-8"), 0, this.HEADER, this.namepos, 11);
      System.arraycopy(intname.getBytes("UTF-8"), 0, this.HEADER, this.namepos, intname.length());
    } catch (Exception e) {
      System.err.println("Something went wrong with " + intname);
    } 
    this.HEADER[this.filetypepos] = (byte)type;
    putWord(this.HEADER, this.datalengthpos, length);
    putWord(this.HEADER, this.datalocationpos, start);
    this.HEADER[this.firstblockpos] = -1;
    putWord(this.HEADER, this.filelengthpos, length);
    putWord(this.HEADER, this.execaddresspos, exec);
    put24Bit(this.HEADER, this.lengthpos, length);
    put24Bit(this.HEADER, this.checksumpos, ChecksumAMSDOS(this.HEADER));
    SOURCEFILE = addHeader(SOURCEFILE);
    return SOURCEFILE;
  }
  
  public byte[] addHeader(byte[] SOURCEFILE) {
    if (SOURCEFILE == null)
      return SOURCEFILE; 
    if (CheckAMSDOS(SOURCEFILE))
      removeHeader(SOURCEFILE); 
    this.RESULT = new byte[SOURCEFILE.length + 128];
    System.arraycopy(this.HEADER, 0, this.RESULT, 0, 128);
    System.arraycopy(SOURCEFILE, 0, this.RESULT, 128, SOURCEFILE.length);
    SOURCEFILE = new byte[this.RESULT.length];
    System.arraycopy(this.RESULT, 0, SOURCEFILE, 0, SOURCEFILE.length);
    this.content = Util.dumpBytes(SOURCEFILE);
    return SOURCEFILE;
  }
  
  public byte[] removeHeader(byte[] SOURCEFILE) {
    if (SOURCEFILE == null)
      return SOURCEFILE; 
    if (!CheckAMSDOS(SOURCEFILE))
      return SOURCEFILE; 
    this.RESULT = new byte[SOURCEFILE.length - 128];
    System.arraycopy(SOURCEFILE, 128, this.RESULT, 0, this.RESULT.length);
    SOURCEFILE = new byte[this.RESULT.length];
    System.arraycopy(this.RESULT, 0, SOURCEFILE, 0, SOURCEFILE.length);
    this.content = Util.dumpBytes(SOURCEFILE);
    return SOURCEFILE;
  }
  
  public boolean addrem = false;
  
  protected int filesize;
  
  public static int ChecksumAMSDOS(byte[] pHeader) {
    int Checksum = 0;
    for (int i = 0; i < 67; i++) {
      int CheckSumByte = pHeader[i] & 0xFF;
      Checksum += CheckSumByte;
    } 
    return Checksum;
  }
  
  public static boolean CheckAMSDOS(byte[] pHeader) {
    int CalculatedChecksum;
    try {
      CalculatedChecksum = ChecksumAMSDOS(pHeader);
    } catch (Exception e) {
      return false;
    } 
    int ChecksumFromHeader = pHeader[67] & 0xFF | (pHeader[68] & 0xFF) << 8;
    if (ChecksumFromHeader == CalculatedChecksum && ChecksumFromHeader != 0)
      return true; 
    return false;
  }
  
  int[][] sectors = new int[8][];
  
  public int filetype;
  
  public String mediatype;
  
  public int filestart;
  
  public int fileentry;
  
  public void setSkew() {
    this.skew = new int[this.discsectors];
    (new int[9])[0] = 26;
    (new int[9])[1] = 58;
    (new int[9])[2] = 90;
    (new int[9])[3] = 50;
    (new int[9])[4] = 82;
    (new int[9])[5] = 42;
    (new int[9])[6] = 74;
    (new int[9])[7] = 34;
    (new int[9])[8] = 66;
    this.sectors[0] = new int[9];
    (new int[9])[0] = 26;
    (new int[9])[1] = 58;
    (new int[9])[2] = 90;
    (new int[9])[3] = 50;
    (new int[9])[4] = 82;
    (new int[9])[5] = 42;
    (new int[9])[6] = 74;
    (new int[9])[7] = 34;
    (new int[9])[8] = 66;
    this.sectors[1] = new int[9];
    (new int[8])[0] = 26;
    (new int[8])[1] = 34;
    (new int[8])[2] = 42;
    (new int[8])[3] = 50;
    (new int[8])[4] = 58;
    (new int[8])[5] = 66;
    (new int[8])[6] = 74;
    (new int[8])[7] = 82;
    this.sectors[2] = new int[8];
    (new int[9])[0] = 26;
    (new int[9])[1] = 58;
    (new int[9])[2] = 90;
    (new int[9])[3] = 50;
    (new int[9])[4] = 82;
    (new int[9])[5] = 42;
    (new int[9])[6] = 74;
    (new int[9])[7] = 34;
    (new int[9])[8] = 66;
    this.sectors[3] = new int[9];
    (new int[10])[0] = 26;
    (new int[10])[1] = 58;
    (new int[10])[2] = 90;
    (new int[10])[3] = 50;
    (new int[10])[4] = 82;
    (new int[10])[5] = 42;
    (new int[10])[6] = 74;
    (new int[10])[7] = 34;
    (new int[10])[8] = 66;
    (new int[10])[9] = 98;
    this.sectors[4] = new int[10];
    byte[] trackinfo = new byte[256];
    System.arraycopy(this.buffer, 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]), trackinfo, 0, 256);
    int i;
    for (i = 0; i < this.discsectors; i++)
      this.skew[i] = (trackinfo[this.sectors[this.FORMAT][i]] & 0xFF) - this.SECTORADD[this.FORMAT]; 
    for (i = 0; i < this.skew.length; i++);
  }
  
  public int checkFile(int pos, boolean deep) {
    if (this.FORMAT == -1)
      getFormat(); 
    int size = 0;
    this.fileentry = 0;
    this.filesize = 0;
    this.mediatype = "ASCII";
    this.filestart = 0;
    try {
      byte[] data = new byte[this.SECTOR_SIZE[this.FORMAT]];
      int block = this.blocks[pos][0];
      int track = block * 2 * this.MULTIPLIER[this.FORMAT] / this.discsectors;
      int sector = block * 2 * this.MULTIPLIER[this.FORMAT] % this.discsectors;
      int off = 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]);
      off += 256 * (track + 1);
      off += this.TRACK_SIZE[this.FORMAT] * track;
      off += this.SECTOR_SIZE[this.FORMAT] * (this.skew[sector] - 1);
      try {
        System.arraycopy(this.buffer, off, data, 0, data.length);
      } catch (Exception e) {
        this.FORMAT = 0;
        return 0;
      } 
      if (CheckAMSDOS(data)) {
        this.filesize = size = getWord(data, 24) + 128;
        this.filestart = getWord(data, 21);
        this.fileentry = getWord(data, 26);
        this.filetype = data[18] & 0xFF;
        try {
          this.mediatype = this.types[this.filetype];
        } catch (Exception e) {
          this.mediatype = "UNKNOWN!";
        } 
      } else {
        size = deep ? deepCheck(pos) : 0;
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
    return size;
  }
  
  protected String[] types = new String[] { "BASIC", "BASIC  [P]", "BINARY", "BINARY [P]", "IMAGE", "IMAGE  [P]", "ASCII", "ASCII  [P]" };
  
  protected int numberfiles;
  
  protected int disksides;
  
  protected int disktracks;
  
  protected int discsectors;
  
  public static int DATA_FORMAT = 0;
  
  public static int SYSTEM_FORMAT = 1;
  
  public static int IBM_FORMAT = 2;
  
  public static int VORTEX_FORMAT = 3;
  
  public static int ROMDOS_FORMAT = 4;
  
  public void getFormat() {
    int bufformat = this.FORMAT;
    this.FORMAT = 0;
    int format = -1;
    byte[] trackinfo = new byte[256];
    System.arraycopy(this.buffer, 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]), trackinfo, 0, 256);
    this.FORMAT = bufformat;
    int result = trackinfo[26] & 0xFF;
    this.disktracks = this.buffer[48] & 0xFF;
    this.disksides = this.buffer[49] & 0xFF;
    this.discsectors = trackinfo[21] & 0xFF;
    if (this.disktracks < 43) {
      if (this.disksides <= 1)
        switch (result) {
          case 1:
            format = IBM_FORMAT;
            break;
          case 65:
            format = SYSTEM_FORMAT;
            break;
          case 193:
            format = DATA_FORMAT;
            break;
        }  
    } else if (this.disksides > 1) {
      switch (result) {
        case 1:
          format = VORTEX_FORMAT;
          format = -1;
          break;
        case 17:
          format = ROMDOS_FORMAT;
          format = -1;
          break;
      } 
    } 
    if (this.FORMAT != format) {
      this.FORMAT = format;
      if (this.FORMAT != -1)
        getFormat(); 
    } 
    if (this.FORMAT != -1) {
      this.MAX_BLOCKS[this.FORMAT] = this.disktracks * this.discsectors / 2 - 2 - this.START_TRACK[this.FORMAT] * this.disksides;
      this.MAX_BLOCKS[this.FORMAT] = this.MAX_BLOCKS[this.FORMAT] * this.disksides;
    } 
  }
  
  public String[] DIR() {
    if (this.buffer == null || this.buffer.length < 8192)
      return null; 
    this.numberfiles = 0;
    getFormat();
    if (this.FORMAT == -1) {
      this.buffer = null;
      this.FORMAT = 0;
      JOptionPane.showMessageDialog(new JFrame(), "Error! Unknown DSK format!", "Error!", 2);
      return null;
    } 
    this.linear = false;
    switch (this.FORMAT) {
    
    } 
    setSkew();
    byte[] dir = getDIR();
    this.files = new String[this.MAX_ENTRIES[this.FORMAT]];
    this.users = new int[this.MAX_ENTRIES[this.FORMAT]];
    this.blocks = new int[this.MAX_ENTRIES[this.FORMAT]][];
    this.ext = new int[this.MAX_ENTRIES[this.FORMAT]];
    this.readOnly = new boolean[this.MAX_ENTRIES[this.FORMAT]];
    this.system = new boolean[this.MAX_ENTRIES[this.FORMAT]];
    this.rec = new int[this.MAX_ENTRIES[this.FORMAT]];
    this.fileentries = new int[this.MAX_ENTRIES[this.FORMAT]];
    this.diroffset = new int[this.MAX_ENTRIES[this.FORMAT]];
    int fpos = 0;
    int pos = 0;
    boolean err = false;
    entries = 0;
    for (int i = 0; i < this.MAX_ENTRIES[this.FORMAT]; i++) {
      if (!this.linear) {
        if (pos < this.SECTOR_SIZE[this.FORMAT]) {
          this.diroffset[i] = pos + 256 + 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]);
        } else if (pos < this.SECTOR_SIZE[this.FORMAT] * 2) {
          this.diroffset[i] = pos + 256 + 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + this.SECTOR_SIZE[this.FORMAT];
        } else if (pos < this.SECTOR_SIZE[this.FORMAT] * 3) {
          this.diroffset[i] = pos + 256 + 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + this.SECTOR_SIZE[this.FORMAT] * 2;
        } else if (pos < this.SECTOR_SIZE[this.FORMAT] * 4) {
          this.diroffset[i] = pos + 256 + 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]) + this.SECTOR_SIZE[this.FORMAT] * 3;
        } 
      } else {
        this.diroffset[i] = pos + 256 + 256 + this.START_TRACK[this.FORMAT] * (256 + this.TRACK_SIZE[this.FORMAT]);
      } 
      this.users[i] = dir[pos++] & 0xFF;
      this.files[i] = null;
      this.blocks[i] = new int[16];
      this.readOnly[i] = false;
      this.system[i] = false;
      if (!err)
        for (int f = 0; f < 11; f++) {
          if (f == 8) {
            int gg = dir[pos] & 0xFF;
            if (gg > 127)
              this.readOnly[i] = true; 
          } 
          if (f == 9) {
            int gg = dir[pos] & 0xFF;
            if (gg > 127)
              this.system[i] = true; 
          } 
          int bt = dir[pos] & Byte.MAX_VALUE;
          if ((bt < 32 || bt > 95) && 
            bt != 0)
            err = true; 
          if (this.files[i] == null)
            this.files[i] = ""; 
          this.files[i] = this.files[i] + (char)bt;
          if (f == 7)
            this.files[i] = this.files[i] + "."; 
          pos++;
        }  
      this.ext[i] = dir[pos++] & 0xFF;
      pos += 2;
      this.rec[i] = dir[pos++] & 0xFF;
      if (err) {
        this.files[i] = null;
      } else {
        this.blocks[i] = new int[16];
      } 
      if (this.blocks[i] != null) {
        for (int f = 0; f < 16; f++)
          this.blocks[i][f] = dir[pos++] & 0xFF; 
      } else {
        pos += 16;
      } 
      if (this.files[i] != null) {
        if (this.readOnly[i]);
        if (this.system[i]);
        if (this.ext[i] == 0) {
          this.fileentries[fpos++] = i;
          if (this.users[i] != 229)
            this.numberfiles++; 
        } else if (this.users[i] != 229) {
          this.numberfiles++;
        } 
        entries++;
      } 
    } 
    int[] g = new int[fpos];
    System.arraycopy(this.fileentries, 0, g, 0, fpos);
    this.fileentries = new int[fpos];
    System.arraycopy(g, 0, this.fileentries, 0, fpos);
    return this.files;
  }
  
  public static int getWord(byte[] buffer, int offs) {
    return buffer[offs] & 0xFF | buffer[offs + 1] << 8 & 0xFF00;
  }
  
  public static void putWord(byte[] buffer, int offs, int data) {
    buffer[offs] = (byte)(data & 0xFF);
    buffer[offs + 1] = (byte)(data >> 8 & 0xFF);
  }
  
  public static void put24Bit(byte[] buffer, int offs, int data) {
    buffer[offs] = (byte)(data & 0xFF);
    buffer[offs + 1] = (byte)(data >> 8 & 0xFF);
    buffer[offs + 2] = (byte)(data >> 16 & 0xFF);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\cpcgamescd\CPCFileSystem.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */