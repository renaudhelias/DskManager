package jemu.ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class Browser_jAddressTextField_actionAdapter implements ActionListener {
  Browser adaptee;
  
  Browser_jAddressTextField_actionAdapter(Browser adaptee) {
    this.adaptee = adaptee;
  }
  
  public void actionPerformed(ActionEvent e) {
    this.adaptee.jAddressTextField_actionPerformed(e);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\Browser_jAddressTextField_actionAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */