package jemu.ui;

import com.itextpdf.text.DocListener;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.html.simpleparser.HTMLWorker;
import com.itextpdf.text.pdf.PdfWriter;
import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.CheckboxMenuItem;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.Point;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.BufferedImage;
import java.awt.image.MemoryImageSource;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import jemu.core.Util;
import jemu.core.device.Computer;
import jemu.core.device.FileDescriptor;
import jemu.core.device.crtc.Basic6845;
import jemu.core.device.floppy.Drive;
import jemu.core.device.floppy.DriveListener;
import jemu.core.device.floppy.UPD765A;
import jemu.core.device.printer.TextPrinter;
import jemu.core.device.sound.YMControl;
import jemu.core.device.tape.TapeCounter;
import jemu.core.samples.Samples;
import jemu.settings.Settings;
import jemu.system.cpc.CPC;
import jemu.system.cpc.CPCDiscImageMerger;
import jemu.system.cpc.GameMapper;
import jemu.system.cpc.GateArray;
import jemu.ui.dskFile.DSKFilter;
import jemu.ui.dskFile.DSKPreview;
import jemu.ui.dskutil.DSKUtil;
import jemu.ui.gfx.AnimatedGifEncoder;
import jemu.ui.paint.FOSPaint;
import jemu.ui.paint.MODEXPaint;
import jemu.ui.paint.RasterPaint;
import jemu.util.ass.Interface;
import jemu.util.hexeditor.HexEditor;

public class JEMU extends Applet implements ComponentListener, PropertyChangeListener, KeyListener, MouseListener, ItemListener, ActionListener, FocusListener, Runnable, DriveListener, MouseMotionListener {
  final boolean DEBUG_KEYS = false;
  
  public static Desktop desktop;
  
  GamePadController joyControl;
  
  public void propertyChange(PropertyChangeEvent e) {}
  
  public static void centerFrame(JFrame frame) {
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    frame.setLocation((d.width - (frame.getSize()).width) / 2, (d.height - (frame.getSize()).height) / 2);
  }
  
  public static JCheckBox runComputer = new JCheckBox();
  
  protected JComboBox langselect = new JComboBox();
  
  protected final String[] langs = new String[] { "EN", "DE", "ES", "FR", "IT", "DK", "S", "N" };
  
  protected int sel = 0;
  
  public static String tapepolarity = null;
  
  boolean beta = false;
  
  boolean selector = false;
  
  public static boolean loadsnap;
  
  public static boolean savesnap;
  
  String lastopen;
  
  public static boolean ejectall = false;
  
  public static boolean ejecttape = false;
  
  static int doodlecount;
  
  static String importscreen = null;
  
  public static boolean openp = false;
  
  public JPanel status;
  
  public JPanel statpan;
  
  public JPanel taped;
  
  protected JComboBox cbZipChooser = new JComboBox();
  
  protected JComboBox chooser = new JComboBox();
  
  protected JLabel ziplab = new JLabel("File:");
  
  public JButton recb = new JButton(createIcon("icons/player_rec.png"));
  
  public JButton playb = new JButton(createIcon("icons/player_play.png"));
  
  public JButton rewb = new JButton(createIcon("icons/player_rev.png"));
  
  public JButton fwdb = new JButton(createIcon("icons/player_fwd.png"));
  
  public JButton stopb = new JButton(createIcon("icons/player_stop.png"));
  
  public JButton pauseb = new JButton(createIcon("icons/player_pause.png"));
  
  public JButton tabb = new JButton(createIcon("icons/player_tabs.png"));
  
  public static TapeCounter counterb = new TapeCounter();
  
  JComponent intern = new JPanel();
  
  public static JCheckBox debugthis = new JCheckBox("update");
  
  protected boolean showStatus;
  
  protected int hidemenu = 0;
  
  protected boolean isbackground;
  
  protected static int screenXstored;
  
  protected static int screenYstored;
  
  protected int flasher;
  
  protected String captureName = "output.gif";
  
  protected boolean doRec;
  
  protected boolean startR;
  
  protected boolean doingRec;
  
  protected boolean initRec;
  
  protected AnimatedGifEncoder encoder = new AnimatedGifEncoder();
  
  protected String titleA;
  
  protected String keepA;
  
  protected String titleB;
  
  protected String keepB;
  
  protected String titleC;
  
  protected String keepC;
  
  protected String titleD;
  
  protected String keepD;
  
  protected String titleE;
  
  protected String keepE;
  
  protected String titleF;
  
  protected String keepF;
  
  protected JButton KeepA;
  
  protected JButton KeepB;
  
  protected JButton KeepC;
  
  protected JButton KeepD;
  
  protected JButton KeepE;
  
  protected JButton KeepF;
  
  protected boolean showabout = false;
  
  public static boolean setRoms = false;
  
  protected int CPUspeed;
  
  private File2CDT makeCDT = new File2CDT();
  
  private samp2cdt samp2cdt = new samp2cdt();
  
  public boolean useURL = false;
  
  protected static String Autoopen = "none";
  
  protected static int doAutoopen = 0;
  
  protected boolean KeyRec;
  
  public static boolean followCPU = false;
  
  Locale loc;
  
  public static String localkeys = "";
  
  boolean checkupdate;
  
  public static boolean isTape = false;
  
  public static YMControl ymControl = new YMControl();
  
  int displaywidth;
  
  int displayheight;
  
  protected boolean keepDimension = false;
  
  protected int colorcheck;
  
  public static JLabel toplabel;
  
  public static JLabel leftlabel;
  
  public static JLabel downlabel;
  
  public static JLabel rightlabel;
  
  String keys = "";
  
  final URL discimageA = getClass().getResource("image/discA.gif");
  
  final URL discimageB = getClass().getResource("image/discB.gif");
  
  final ImageIcon discA = new ImageIcon(this.discimageA);
  
  final ImageIcon discB = new ImageIcon(this.discimageB);
  
  final ImageIcon discAc = new ImageIcon(this.discimageA);
  
  final ImageIcon discBc = new ImageIcon(this.discimageB);
  
  private ArrayList<DropTarget> dropTargetList;
  
  public boolean tapeload = false;
  
  String update = "";
  
  HexEditor hexi;
  
  protected int QuitTimer = 0;
  
  public boolean runner = false;
  
  protected String loadtitle = "Load emulator file";
  
  SNAChooser snaChooser;
  
  JButton s64 = new JButton("64k");
  
  JButton s128 = new JButton("128k");
  
  JButton s256 = new JButton("256k");
  
  JButton s512 = new JButton("512k");
  
  JButton cancel = new JButton("Cancel");
  
  JLabel Sn = new JLabel("Choose Snapshot-format:");
  
  JLabel Moniup = new JLabel(new ImageIcon(getClass().getResource("image/moniup.jpg")));
  
  JLabel Monidown = new JLabel(new ImageIcon(getClass().getResource("image/monidown.jpg")));
  
  JLabel Monileft = new JLabel(new ImageIcon(getClass().getResource("image/monileft.jpg")));
  
  JLabel Moniright = new JLabel(new ImageIcon(getClass().getResource("image/moniright.jpg")));
  
  JPanel Monitoruppanel = null;
  
  JPanel Monitordownpanel = null;
  
  JPanel Monitorleftpanel = null;
  
  JPanel Monitorrightpanel = null;
  
  JFrame screenpreview;
  
  JLabel sprev = new JLabel();
  
  JFrame prevframe;
  
  ScreenCapture capthis;
  
  BufferedImage images;
  
  int xpos;
  
  int ypos;
  
  int xoldpos;
  
  int yoldpos;
  
  protected boolean ctrl;
  
  protected boolean shift;
  
  protected boolean alt = false;
  
  public static int screenshottimer = 0;
  
  public static int screentimer = 0;
  
  public static int dsksavetimer = 0;
  
  public static int dskmaketimer = 0;
  
  protected boolean Vhold = false;
  
  protected String server;
  
  public String MachineMemory = "";
  
  public boolean audiooutput = true;
  
  public boolean floppyoutput = true;
  
  public boolean altjoystick = false;
  
  private int loadtimer = 0;
  
  public boolean mousejoy = false;
  
  protected int sizecounter = 0;
  
  private boolean stretcher = true;
  
  public int flopsound;
  
  private String autoloadprog;
  
  private String autoloadprogram = "~none~";
  
  private String autotypetext = "~none~";
  
  private int loadprogtimer = 0;
  
  private int simpletimer = 0;
  
  private int stopsimple = 0;
  
  private String DSKfile;
  
  private String autostartProg = null;
  
  private String autostartDisk = null;
  
  private String setComputers = null;
  
  private String discb = null;
  
  private String discc = null;
  
  private String discd = null;
  
  private String Monitor = null;
  
  private String compsys = null;
  
  protected static int unpausetimer = 0;
  
  protected static int pausetimer = 0;
  
  protected static int paused = 0;
  
  private int autoload = 0;
  
  public static int autoloader = 0;
  
  protected Computer computer = null;
  
  private static int winx1 = 532;
  
  private static int winy1 = 402;
  
  protected Display display = new Display();
  
  protected int dtimer = 1;
  
  protected JLabel jlComputer = new JLabel("System  ");
  
  protected JLabel jlDrive = new JLabel("Disc drive ");
  
  protected JLabel jlImage = new JLabel("Media");
  
  protected JLabel jmMerge = new JLabel("Merges 2 single-sided DSK to 1 double sided");
  
  protected JLabel jmSavec = new JLabel("Save canceled");
  
  protected String jmSavefile = "Select name for your dsk file (Ends with '.dsk')";
  
  protected GridBagConstraints gbcConstraints = null;
  
  protected boolean isStandalone = false;
  
  public static Debugger debugger = null;
  
  public static JFrame debugframe = null;
  
  protected boolean started = false;
  
  public static boolean large;
  
  protected boolean joystick;
  
  protected boolean executable = false;
  
  public boolean autosave;
  
  public boolean autoboot;
  
  public int autobooter;
  
  public boolean showmessage;
  
  protected Thread focusThread = null;
  
  protected boolean gotGames = false;
  
  protected String Language = null;
  
  protected String cname = null;
  
  protected String loadName = null;
  
  protected Color background;
  
  public static boolean onTop;
  
  protected boolean fsound;
  
  protected boolean notebook;
  
  protected boolean hideframe;
  
  protected boolean skinned;
  
  public String optionp;
  
  public static boolean togglesize = true;
  
  public static boolean fullscreen;
  
  public static Frame frame = new Frame();
  
  public static JInternalFrame iframe;
  
  public String getParameter(String key, String def) {
    return this.isStandalone ? System.getProperty(key, def) : ((getParameter(key) != null) ? getParameter(key) : def);
  }
  
  private GridBagConstraints getGridBagConstraints(int x, int y, double weightx, double weighty, int width, int fill) {
    if (this.gbcConstraints == null)
      this.gbcConstraints = new GridBagConstraints(); 
    this.gbcConstraints.gridx = x;
    this.gbcConstraints.gridy = y;
    this.gbcConstraints.weightx = weightx;
    this.gbcConstraints.weighty = weighty;
    this.gbcConstraints.gridwidth = width;
    this.gbcConstraints.fill = fill;
    return this.gbcConstraints;
  }
  
  final JFrame keyFrame = new JFrame("JavaCPC - Virtual Keyboard");
  
  JPanel key;
  
  JFrame options;
  
  StatusPanel stpanel;
  
  JLabel slomo;
  
  MODEXPaint mp;
  
  Interface internalasm;
  
  private void checkKeyboard() {
    if (this.key == null) {
      this.keyFrame.setLayout(new BorderLayout());
      this.key = GateArray.cpc.VirtualKeys();
      this.keyFrame.add(this.key, "Center");
      this.keyFrame.pack();
      this.keyFrame.setResizable(false);
      this.keyFrame.setDefaultCloseOperation(1);
    } 
    Thread v = new Thread() {
        public void run() {
          try {
            Thread.sleep(2000L);
          } catch (Exception exception) {}
          JEMU.this.keyFrame.pack();
          JEMU.this.keyFrame.setVisible(true);
        }
      };
    v.start();
  }
  
  private JPanel getControlPanel() {
    JPanel panel = new JPanel();
    panel.setLayout(new GridBagLayout());
    return panel;
  }
  
  public JEMU() {
    this.stpanel = new StatusPanel();
    this.slomo = new JLabel("SloMo:");
    this.rickroller = 0;
    this.updated = true;
    this.updater = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          try {
            SwingUtilities.invokeLater(new Runnable() {
                  public void run() {
                    JEMU.this.update();
                  }
                });
          } catch (Exception exception) {}
        }
      };
    this.updateascii = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (JEMU.this.writer == null) {
            JEMU.this.writer = new Thread() {
                public void run() {
                  if (JEMU.this.ishtml) {
                    JEMU.this.captureHTML();
                  } else {
                    JEMU.this.captureTXT();
                  } 
                  JEMU.this.writer = null;
                }
              };
            JEMU.this.writer.start();
          } 
        }
      };
    this.doUpdate = new Timer(25, this.updater);
    this.doAscii = new Timer(50, this.updateascii);
    this.joyDir = new boolean[9];
    this.joyButton1 = 0;
    this.joyButton2 = 1;
    this.has3dlisteners = false;
    this.haslistener = false;
    this.joyenabler = 0;
    this.skipbutton = false;
    this.dood = 0;
    this.opts = new JPanel();
    this.dumpHTML = new JButton("Dump HTML");
    this.dumpTXT = new JButton("Dump TXT");
    this.saveDump = new JButton("Save...");
    this.autoDump = new JButton("Auto");
    this.pdf = new JCheckBox("PDF");
    this.copyDump = new JButton("Copy");
    this.cv = new CharViewer();
    this.fosp = new FOSPaint();
    this.zoom = 1;
    this.rec = false;
    this.ocr = new CPCOCR();
    this.oc = new JFrame("CPC-Screen-To-ASCII Dump");
    this.ar = new JEditorPane();
    this.hastext = false;
    this.checkgun = 0;
    this.guncolour = 0;
    this.releasegun = 0;
    this.tabss = new JTabbedPane();
    this.undockedPeriphery = false;
    this.Peri = null;
    this.samdisk = new SamDisk();
    this.bascreen = 0;
    this.onlinemenu = new Frame() {
        protected void processWindowEvent(WindowEvent e) {
          super.processWindowEvent(e);
          if (e.getID() == 201)
            JEMU.this.onlinemenu.dispose(); 
        }
        
        public synchronized void setTitle(String title) {
          super.setTitle(title);
          enableEvents(64L);
        }
      };
    this.menue1 = new Menu("File");
    this.bdd = "BDD - CPC File Databases";
    this.cpcgamescd = "CPCGamesCD Browser";
    this.reco = "Record Session";
    this.stoprec = "Stop Session";
    this.favo = "Favourite-Browser";
    this.asciicap = "CPC-Screen-to-ASCII    Shift + F11";
    this.menue2 = new Menu("Emulation");
    this.menue3 = new Menu("Settings");
    this.menue4 = new Menu("Monitor");
    this.menue5 = new Menu("Help");
    this.menue6 = new Menu("Edit");
    this.extra = new Menu("Extras");
    this.notpad = "Little Notepad";
    this.dsk2cdt = "Copy files from DF0 as CDT";
    this.drives = new Menu("Drives");
    this.df0 = new Menu("DF0:");
    this.df1 = new Menu("DF1:");
    this.df2 = new Menu("DF2:");
    this.df3 = new Menu("DF3:");
    this.joymenu = new Menu("Joystick");
    this.keyboard = new Menu("Keyboard");
    this.tape = new Menu("Tape");
    this.statusbar = new CheckboxMenuItem("Show Statusbar");
    this.changePolarity = new CheckboxMenuItem("Change tape-polarity");
    this.keepprop = new CheckboxMenuItem("Keep display proportions");
    this.mousewheel = new CheckboxMenuItem("Mouse wheel zooms display");
    this.lightgun = new CheckboxMenuItem("Enable Lightgun");
    this.autofire = new CheckboxMenuItem("Autofire");
    this.watchsys = new CheckboxMenuItem("Observe performance");
    this.shouldBoot = new CheckboxMenuItem("Try to boot game");
    this.UseGzip = new CheckboxMenuItem("Use GZip compression DSK, SNA, WAV");
    this.runds = "Play DeathSword";
    this.reportBug = "Report a bug";
    this.virtualkeys = "Open virtual keyboard";
    this.startrecord = "Start recording";
    this.stoprecord = "Stop recording";
    this.desktopsettings = "Desktop settings";
    this.videosettings = "Video settings";
    this.audiosettings = "Audio settings";
    this.miscsettings = "Misc. settings";
    this.systemsettings = "System settings";
    this.drivesettings = "Drive settings";
    this.romsettings = "Rom settings";
    this.resjoy = "Reset Joystickbuttons";
    this.Keys = new Menu(this.keys);
    this.RecKey = new CheckboxMenuItem("Enable keyboard recording");
    this.recordkeys = "Keyboard recording info";
    this.tapeopen = "Show TapeDeck";
    this.tapeLoad = "Insert Tape";
    this.ejectTape = "Eject Tape";
    this.tapeLaunch = "Launch Tape";
    this.tapeSave = "Save Tape";
    this.tapeOptimize = "Optimize Tape";
    this.tapeConvert = "Convert CDT to WAV";
    this.format0 = "Format Disk";
    this.format1 = "Format Disk ";
    this.format2 = "Format Disk  ";
    this.format3 = "Format Disk   ";
    this.recrateA = new CheckboxMenuItem("Use 44.1 khz rate (~13 min.) (best, works with CPCTapeXP!)");
    this.recrateB = new CheckboxMenuItem("Use 22.0 khz rate (~25 min.) (Standard quality)");
    this.recrateC = new CheckboxMenuItem("Use 11.5 khz rate (~50 min.) (Poor quality, bad results)");
    this.df0insert = "Insert";
    this.df1insert = "Insert ";
    this.df2insert = "Insert  ";
    this.df3insert = "Insert    ";
    this.df0sav = "Save";
    this.df1sav = "Save ";
    this.df2sav = "Save  ";
    this.df3sav = "Save   ";
    this.df0eject = "Eject";
    this.df1eject = "Eject ";
    this.df2eject = "Eject  ";
    this.df3eject = "Eject   ";
    this.df0create = "Create DSK";
    this.df1create = "Create DSK ";
    this.df2create = "Create DSK  ";
    this.df3create = "Create DSK   ";
    this.df0boot = "Try to boot";
    this.df1boot = "Try to boot ";
    this.df0save = "Save DSK as...";
    this.df1save = "Save DSK as... ";
    this.df2save = "Save DSK as...  ";
    this.df3save = "Save DSK as...   ";
    this.screenShot = "Save Screenshot     Ctrl + F11";
    this.catchSCR = "Catch CPC Screen (16k)";
    this.Oprinter = "Open printer console";
    this.loadTXT = "Import ASCII file";
    this.HexEdit = "Open Hex Editor";
    this.FontEdit = "Open Font Editor";
    this.snapshot = "Save snapshot file";
    this.binary = "Import CPC file";
    this.poke = "Poke Memory";
    this.inspaint = "Launch JavaCPC Paint";
    this.fospaint = "FutureOS Wallpaper Tool";
    this.insraster = "JavaCPC RasterPaint";
    this.insmx = "JavaCPC MXPaint";
    this.lostPaint = "Restore JavaCPC Paint DSK";
    this.export = "Export binary";
    this.cpcpalette = "Show actual palette";
    this.digi = "Launch Prodatron's Digitracker";
    this.digimc = "Launch DigiTracker MOD converter";
    this.digipg = "Launch Digitracker Player-Generator";
    this.checkjavacpc = "Check JavaCPC";
    this.checkup = "Check for update";
    this.checkfos = "Check for FutureOS ROM update";
    this.CPUfollow = "Let disassembler follow CPU";
    this.downl = "Visit download-page";
    this.homepage = "Visit homepage";
    this.sourceforge = "Sourceforge project page";
    this.showYM = "Show YM-Control";
    this.showRec = "Record audio";
    this.showCap = "Record GIF-Sequence";
    this.showMov = "Record Quicktime MOV";
    this.inspectA = "File inspector";
    this.inspectB = "File inspector ";
    this.autocheck = new CheckboxMenuItem("Automatically check for updates");
    this.inspector = new CheckboxMenuItem("Open file inspector on DSK load");
    this.checkFull = new CheckboxMenuItem("Fullscreen            Alt + Enter");
    this.cpc464t = new CheckboxMenuItem("CPC 464");
    this.cpc464 = new CheckboxMenuItem("CPC 464 (Amsdos)");
    this.cpc664 = new CheckboxMenuItem("CPC 664");
    this.cpc6128 = new CheckboxMenuItem("CPC 6128");
    this.symbos = new CheckboxMenuItem("SymbOS");
    this.futureos = new CheckboxMenuItem("FutureOS");
    this.kccompact = new CheckboxMenuItem("KC compact");
    this.customcpc = new CheckboxMenuItem("Custom CPC");
    this.joyemu = new CheckboxMenuItem("Joystick");
    this.qaop = new CheckboxMenuItem("Alternative control");
    this.joymouse = new CheckboxMenuItem("Mousejoystick");
    this.Expansioninfo = "Expansion Info";
    this.makCDT = "Create a CDT";
    this.wav2cdt = "Samp2CDT";
    this.copyfloppy = "SamDisk";
    this.gfxviewer = "GFXViewer";
    this.screenmapper = "GameMapper (Screen)";
    this.mload = "Load...";
    this.mcpm = "Boot CP/M";
    this.mejectall = "Eject all";
    this.mmerge = "Merge DSK's...";
    this.mquit = "Quit";
    this.mforce = "Force quit";
    this.mpaste = "Paste      F11";
    this.mabout = "About";
    this.makeshot = new JButton("Save");
    this.cancelshot = new JButton("Cancel");
    this.startRec = new JButton("Capture");
    this.pauseRec = new JButton("Pause");
    this.stopRec = new JButton("Stop");
    this.pauserec = false;
    this.dialogsnap = false;
    this.mousezoom = 2.0D;
    this.oldX = -1;
    this.oldY = -1;
    this.asktimer = new JLabel("3");
    this.askupdate = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          JEMU.this.asktime--;
          JEMU.this.asktimer.setText("" + JEMU.this.asktime);
          JEMU.this.ask.setTitle("Select drive (" + JEMU.this.asktime + ")");
          if (JEMU.this.asktime < 1) {
            JEMU.this.askUpdate.stop();
            JEMU.this.asktime = 3;
            JEMU.this.computer.setCurrentDrive(0);
            JEMU.this.ask.dispose();
            try {
              JEMU.this.loadFile(0, JEMU.this.askname, false);
            } catch (Exception er) {
              System.out.println("Error while loading");
            } 
          } 
        }
      };
    this.askUpdate = new Timer(1000, this.askupdate);
    this.panelListener = new MouseListener() {
        public void mouseExited(MouseEvent g) {
          if (Display.use3d)
            return; 
          JEMU.this.hideTape = 1;
        }
        
        public void mouseEntered(MouseEvent g) {
          if (Display.use3d)
            return; 
          JEMU.this.hideTape = 0;
          if (JEMU.this.tabb.isVisible()) {
            JEMU.this.tabb.setVisible(false);
            JEMU.this.recb.setVisible(true);
            JEMU.this.playb.setVisible(true);
            JEMU.this.rewb.setVisible(true);
            JEMU.this.fwdb.setVisible(true);
            JEMU.this.stopb.setVisible(true);
            JEMU.this.pauseb.setVisible(true);
            JEMU.this.stpanel.setVisible(false);
            if (JEMU.this.display.getWidth() < 700) {
              JEMU.this.cbZipChooser.setVisible(false);
              JEMU.this.ziplab.setVisible(false);
            } 
          } 
        }
        
        int mouseButtonByte = 0;
        
        public void mouseReleased(MouseEvent g) {}
        
        public void mousePressed(MouseEvent g) {}
        
        public void mouseClicked(MouseEvent g) {}
      };
    this.full = new JFrame();
    enableEvents(8L);
  }
  
  public static void preInit() {
    desktop = new Desktop();
    desktop.setLook();
    desktop.forced.setEnabled(false);
    System.out.println("Desktop look set!");
  }
  
  public void init() {
    this.joyControl = new GamePadController();
    if (this.joyControl.haveJoystick) {
      System.out.println("Joy found!");
      this.joyButton1 = Settings.getInt("joystick_button_1", 200);
      this.joyButton2 = Settings.getInt("joystick_button_2", 200);
      if (this.joyButton1 == 200)
        setJoy1 = true; 
      if (this.joyButton2 == 200)
        setJoy2 = true; 
      System.out.println(this.joyButton1);
      System.out.println(this.joyButton2);
    } 
    this.loc = getLocale();
    this.sel = 0;
    localkeys = this.loc.toString().toUpperCase();
    localkeys = Settings.get("language", localkeys);
    if (localkeys.equals("NO_NO"))
      localkeys = "NB_NO"; 
    localize();
    switch (localkeys) {
      case "DE_DE":
        this.sel = 1;
        this.keys = "German keyboard  ";
        CPC.language = "de";
        break;
      case "ES_ES":
        this.sel = 2;
        this.keys = "Spanish keyboard  ";
        CPC.language = "es";
        break;
      case "FR_FR":
        this.sel = 3;
        this.keys = "French keyboard  ";
        CPC.language = "fr";
        break;
      case "IT_IT":
        this.sel = 4;
        this.keys = "Italian keyboard  ";
        CPC.language = "en";
        break;
      case "DA_DK":
        this.sel = 5;
        this.keys = "Danish keyboard  ";
        CPC.language = "dk";
        break;
      case "SV_SE":
        this.sel = 6;
        this.keys = "Swedish keyboard  ";
        CPC.language = "en";
        break;
      case "NB_NO":
        this.sel = 7;
        this.keys = "Norwegian keyboard  ";
        CPC.language = "dk";
        break;
      default:
        this.sel = 0;
        this.keys = "English keyboard  ";
        CPC.language = "en";
        break;
    } 
    Settings.set("language", localkeys);
    this.langselect.setModel(new DefaultComboBoxModel<>(this.langs));
    this.langselect.setSelectedIndex(this.sel);
    this.langselect.setFocusable(false);
    if (iframe == null) {
      Switches.executable = false;
      try {
        this.server = getCodeBase().toString();
      } catch (Exception e) {
        Switches.executable = true;
        this.executable = true;
      } 
      desktop.localize(localkeys);
      this.options = new JFrame("Options");
      this.options.setLayout(new BorderLayout());
      this.options.add(Desktop.OptionPane, "Center");
      Desktop.OptionPane.setVisible(true);
      Desktop.OptionPane.setPreferredSize(new Dimension(540, 470));
      this.options.pack();
      this.options.setVisible(false);
    } else {
      Switches.executable = true;
    } 
    this.executable = true;
    this.cbZipChooser.setFocusable(false);
    this.chooser.setFocusable(false);
    runComputer.addItemListener(this);
    this.cbZipChooser.setFont(new Font("", 1, 11));
    this.cbZipChooser.setFocusable(false);
    this.cbZipChooser.setVisible(false);
    this.ziplab.setVisible(false);
    this.status = new JPanel();
    this.statpan = new JPanel();
    this.taped = new JPanel();
    this.status.setDoubleBuffered(true);
    this.statpan.setDoubleBuffered(true);
    this.taped.setDoubleBuffered(true);
    this.status.setLayout(new FlowLayout(2, 0, 1));
    this.taped.setLayout(new FlowLayout(1, 1, 1));
    this.status.add(this.ziplab);
    this.status.add(this.cbZipChooser);
    this.status.add(this.langselect);
    this.status.add(this.slomo);
    this.status.add(this.stpanel.slomo);
    this.status.add(this.stpanel);
    this.status.add(this.taped);
    this.showStatus = Settings.getBoolean("status_bar", true);
    this.statpan.setVisible(this.showStatus);
    this.statusbar.setState(this.showStatus);
    this.recb.setBorder((Border)null);
    this.playb.setBorder((Border)null);
    this.rewb.setBorder((Border)null);
    this.fwdb.setBorder((Border)null);
    this.stopb.setBorder((Border)null);
    this.pauseb.setBorder((Border)null);
    this.tabb.setBorder((Border)null);
    this.recb.addActionListener(this);
    this.playb.addActionListener(this);
    this.rewb.addActionListener(this);
    this.fwdb.addActionListener(this);
    this.stopb.addActionListener(this);
    this.pauseb.addActionListener(this);
    this.recb.setFocusable(false);
    this.playb.setFocusable(false);
    this.rewb.setFocusable(false);
    this.fwdb.setFocusable(false);
    this.stopb.setFocusable(false);
    this.pauseb.setFocusable(false);
    counterb.setBackground(Color.black);
    counterb.setBorder(new EtchedBorder(1));
    counterb.setFont(new Font("Monospaced", 1, 14));
    this.taped.setBorder((Border)null);
    counterb.setFocusable(false);
    counterb.setEnabled(false);
    this.taped.add((Component)counterb);
    this.taped.add(this.tabb);
    this.taped.add(this.recb);
    this.taped.add(this.playb);
    this.taped.add(this.rewb);
    this.taped.add(this.fwdb);
    this.taped.add(this.stopb);
    this.taped.add(this.pauseb);
    this.tabb.setCursor(new Cursor(12));
    this.playb.setCursor(new Cursor(12));
    this.recb.setCursor(new Cursor(12));
    this.rewb.setCursor(new Cursor(12));
    this.fwdb.setCursor(new Cursor(12));
    this.stopb.setCursor(new Cursor(12));
    this.pauseb.setCursor(new Cursor(12));
    this.tabb.addMouseListener(this.panelListener);
    this.playb.addMouseListener(this.panelListener);
    this.recb.addMouseListener(this.panelListener);
    this.rewb.addMouseListener(this.panelListener);
    this.fwdb.addMouseListener(this.panelListener);
    this.stopb.addMouseListener(this.panelListener);
    this.pauseb.addMouseListener(this.panelListener);
    this.pauseb.setVisible(false);
    counterb.setVisible(true);
    this.recb.setVisible(false);
    this.playb.setVisible(false);
    this.rewb.setVisible(false);
    this.fwdb.setVisible(false);
    this.stopb.setVisible(false);
    this.tabb.setVisible(true);
    this.pauseRec.setFocusable(false);
    this.startRec.setFocusable(false);
    this.stopRec.setFocusable(false);
    this.startRec.setBackground(Color.DARK_GRAY);
    this.pauseRec.setBackground(Color.DARK_GRAY);
    this.stopRec.setBackground(Color.DARK_GRAY);
    this.startRec.setForeground(Color.LIGHT_GRAY);
    this.pauseRec.setForeground(Color.LIGHT_GRAY);
    this.stopRec.setForeground(Color.LIGHT_GRAY);
    this.startRec.setBorder(new BevelBorder(0));
    this.pauseRec.setBorder(new BevelBorder(0));
    this.stopRec.setBorder(new BevelBorder(0));
    this.Keys.setLabel(this.keys);
    this.keepDimension = Settings.getBoolean("keep_display_propertions", true);
    this.mousewheel.setState(Settings.getBoolean("mousewheel_zoom", true));
    this.KeyRec = Settings.getBoolean("keyboard_recording", false);
    this.RecKey.setState(this.KeyRec);
    this.keepA = getParameter("CHANGEA", (String)null);
    this.titleA = getParameter("TITLEA", (String)null);
    this.keepB = getParameter("CHANGEB", (String)null);
    this.titleB = getParameter("TITLEB", (String)null);
    this.keepC = getParameter("CHANGEC", (String)null);
    this.titleC = getParameter("TITLEC", (String)null);
    this.keepD = getParameter("CHANGED", (String)null);
    this.titleD = getParameter("TITLED", (String)null);
    this.keepE = getParameter("CHANGEE", (String)null);
    this.titleE = getParameter("TITLEE", (String)null);
    this.keepF = getParameter("CHANGEF", (String)null);
    this.titleF = getParameter("TITLEF", (String)null);
    this.KeepA = new JButton(this.titleA);
    this.KeepB = new JButton(this.titleB);
    this.KeepC = new JButton(this.titleC);
    this.KeepD = new JButton(this.titleD);
    this.KeepE = new JButton(this.titleE);
    this.KeepF = new JButton(this.titleF);
    if (this.keepA != null)
      selectDialog(); 
    String frequency = getParameter("SAMPLERATE", "notset").toLowerCase();
    Switches.khz44 = Settings.getBoolean("recrate44", true);
    Switches.khz11 = Settings.getBoolean("recrate11", false);
    if (frequency.startsWith("44")) {
      Switches.khz44 = true;
      Switches.khz11 = false;
    } 
    if (frequency.startsWith("22")) {
      Switches.khz44 = false;
      Switches.khz11 = false;
    } 
    if (frequency.startsWith("11")) {
      Switches.khz44 = false;
      Switches.khz11 = true;
    } 
    if (Switches.khz44)
      this.recrateA.setState(true); 
    if (Switches.khz11)
      this.recrateC.setState(true); 
    if (!Switches.khz44 && !Switches.khz11)
      this.recrateB.setState(true); 
    boolean usegzip = Settings.getBoolean("gzip_compression", false);
    this.UseGzip.setState(usegzip);
    if (usegzip) {
      Switches.uncompressed = false;
    } else {
      Switches.uncompressed = true;
    } 
    boolean firstrun = Settings.getBoolean("firstrun", true);
    if (firstrun) {
      int selectedValue = 0;
      if (selectedValue == 1) {
        Display.lowperformance = true;
        this.display.changePerformance();
        Settings.setBoolean("lowperformance", true);
      } 
      if (selectedValue == 0) {
        Display.lowperformance = false;
        this.display.changePerformance();
        Settings.setBoolean("lowperformance", false);
      } 
      Settings.setBoolean("firstrun", false);
    } 
    this.checkupdate = Settings.getBoolean("autocheck", false);
    this.autocheck.setState(this.checkupdate);
    Switches.inspector = Settings.getBoolean("fileinspector", false);
    this.inspector.setState(Switches.inspector);
    Switches.doublesize = Settings.getBoolean("double_size", false);
    Switches.triplesize = Settings.getBoolean("triple_size", false);
    Switches.quadsize = Settings.getBoolean("quadro_size", false);
    Switches.freesize = Settings.getBoolean("free_size", false);
    this.mousezoom = 2.0D;
    String zoomf = Settings.get("zoomfactor", "2.0");
    this.mousezoom = Double.parseDouble(zoomf);
    Display.lowperformance = Settings.getBoolean("lowperformance", true);
    Switches.watch = Settings.getBoolean("observe_performance", false);
    this.watchsys.setState(Switches.watch);
    this.display.changePerformance();
    if (!this.executable) {
      Switches.doublesize = Util.getBoolean(getParameter("DOUBLE", "false"));
      Switches.triplesize = Util.getBoolean(getParameter("TRIPLE", "false"));
      Switches.quadsize = Util.getBoolean(getParameter("QUADRO", "false"));
      Switches.freesize = Util.getBoolean(getParameter("FREE", "false"));
    } 
    this.checkFull.setState(fullscreen);
    this.showmenu = Settings.getBoolean("show_menu", this.showmenu);
    if (this.showmenu && !Desktop.started && frame != null)
      frame.setMenuBar(JavaCPCMenu); 
    autorun();
    simpleBoot();
    this.display.requestFocus();
    if (this.executable) {
      screenXstored = Integer.parseInt(Settings.get("frame_xpos", "0"));
      screenYstored = Integer.parseInt(Settings.get("frame_ypos", "0"));
      if (frame != null)
        frame.setLocation(screenXstored, screenYstored); 
      if (iframe != null)
        iframe.setLocation(screenXstored, screenYstored); 
    } 
    if (this.keylist == null);
  }
  
  public void startMXPaint() {
    if (this.mp == null) {
      if (this.internalasm == null)
        this.internalasm = new Interface(); 
      this.mp = new MODEXPaint();
    } 
    this.mp.setVisible(true);
  }
  
  public static boolean resetpanel = false;
  
  Favourites test;
  
  JFrame tframe;
  
  int rickroller;
  
  AmstradEUBDD bddb;
  
  public static String username;
  
  public static String usermail;
  
  public static String usertext;
  
  public void resetTapePanel() {
    resetpanel = false;
    this.stpanel.resetPanel();
    counterb.setBorder(new EtchedBorder(1));
    this.tabb.setBorder((Border)null);
    this.recb.setBorder((Border)null);
    this.playb.setBorder((Border)null);
    this.rewb.setBorder((Border)null);
    this.fwdb.setBorder((Border)null);
    this.stopb.setBorder((Border)null);
    this.pauseb.setBorder((Border)null);
  }
  
  public void autorun() {
    this.autoloadprog = Settings.get("autoload", null);
    this.autoloadprog = getParameter("AUTOLOAD", this.autoloadprog);
    this.autoloadprogram = this.autoloadprog;
    this.stopsimple = 0;
    if (this.autoloadprog != null && !this.autoloadprog.equals("~none~"))
      if (this.autoloadprog.equals("launchtape")) {
        this.runner = true;
        this.stopsimple = 1;
        CPC.tapestarttimer = 1;
      } else {
        this.runner = true;
        this.stopsimple = 1;
        if (this.autoloadprog.startsWith("|")) {
          this.loadprogtimer = 1;
          Switches.loadauto = this.autoloadprog + "\n";
          Settings.set("autoload", "~none~");
        } else {
          this.loadprogtimer = 1;
          Switches.loadauto = "RUN\"" + this.autoloadprog + "\"\n";
          Settings.set("autoload", "~none~");
        } 
      }  
    this.autoloadprog = Settings.get("autotype", null);
    this.autoloadprog = getParameter("AUTOTYPE", this.autoloadprog);
    this.autotypetext = this.autoloadprog;
    this.stopsimple = 0;
    if (this.autoloadprog != null && !this.autoloadprog.equals("~none~")) {
      this.runner = false;
      this.stopsimple = 1;
      this.loadprogtimer = 1;
      Switches.loadauto = this.autoloadprog + "\n";
      Settings.set("autotype", "~none~");
    } 
  }
  
  public void reBoot() {
    this.computer.reset();
    Display.showpause = 0;
    this.computer.start();
    this.stopsimple = 0;
    if (this.runner) {
      if (this.autoloadprogram != null && !this.autoloadprogram.equals("~none~"))
        if (this.autoloadprogram.equals("launchtape")) {
          this.runner = true;
          this.stopsimple = 1;
          CPC.tapestarttimer = 1;
          CPC.tapeBandPosition = 0;
        } else {
          this.stopsimple = 1;
          if (this.autoloadprogram.startsWith("|")) {
            this.loadprogtimer = 1;
            Switches.loadauto = this.autoloadprogram + "\n";
          } else {
            this.loadprogtimer = 1;
            Switches.loadauto = "RUN\"" + this.autoloadprogram + '"' + "\n";
          } 
        }  
    } else if (this.autotypetext != null && !this.autotypetext.equals("~none~")) {
      this.stopsimple = 1;
      this.loadprogtimer = 1;
      Switches.loadauto = this.autotypetext + "\n";
    } 
  }
  
  public void Favourites() {
    if (iframe != null) {
      this;
      desktop.addFavs();
      return;
    } 
    if (this.test == null) {
      this.test = new Favourites();
      this.test.setPreferredSize(new Dimension(500, 400));
      this.tframe = new JFrame("Favourite-Browser");
      this.tframe.setDefaultCloseOperation(1);
      this.tframe.setLayout(new BorderLayout());
      this.tframe.add(this.test, "Center");
      this.tframe.pack();
    } 
    this.tframe.setVisible(true);
  }
  
  public void simpleBoot() {
    if (this.stopsimple != 1) {
      this.DSKfile = getParameter("SIMPLEBOOT", (String)null);
      if (this.DSKfile != null) {
        Settings.set("autoload", this.DSKfile);
        this.simpletimer = 1;
        autorun();
      } 
    } 
  }
  
  public void RickRollMe() {
    Thread f = new Thread() {
        public void run() {
          String path = "./IHaveBeenRickRolled/";
          File a = new File(path);
          File b = new File(path + "RickAstley.mp3");
          File c = new File(path + "RickAstley.anz");
          if (!a.exists() || !b.exists() || !c.exists()) {
            Main.RickRollMe();
            while (!Main.rickrolled) {
              try {
                Thread.sleep(100L);
              } catch (Exception exception) {}
            } 
          } 
          JEMU.this.computer.reset();
          JEMU.this.rickroller = 1;
        }
      };
    f.start();
  }
  
  public void loaddata() {
    if (this.executable && frame != null)
      frame.setAlwaysOnTop(false); 
    String loadname = getFile("JavaCPC file", false, 0);
    if (loadname != null)
      loadFile(1, loadname, false); 
    if (this.executable && frame != null)
      frame.setAlwaysOnTop(onTop); 
  }
  
  public void buildBDD() {
    if (Desktop.isDesktop) {
      Desktop.openbdd = 1;
    } else {
      if (this.bddb == null) {
        if (GateArray.cpc == null) {
          JOptionPane.showMessageDialog(this, "Please let JavaCPC startup first!\r\nDon't be too impatient...");
          return;
        } 
        this.bddb = new AmstradEUBDD(GateArray.cpc);
      } 
      this.bddb.buildBDD();
    } 
  }
  
  public void loadTape(final boolean launch) {
    try {
      SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              try {
                String loadname = JEMU.this.getFile("Tape file", false, 0);
                if (loadname != null) {
                  JEMU.this.loadFile(1, loadname, false);
                  if (launch) {
                    JEMU.this.computer.reset();
                    CPC.tapestarttimer = 1;
                  } 
                } 
                if (JEMU.this.executable && JEMU.frame != null)
                  JEMU.frame.setAlwaysOnTop(JEMU.onTop); 
                JEMU.this.display.requestFocus();
              } catch (Exception exception) {}
            }
          });
    } catch (Exception e) {
      e.printStackTrace();
    } 
    CPC.tapeloaded = false;
    if (this.executable && frame != null)
      frame.setAlwaysOnTop(false); 
  }
  
  public void reportBug() {
    if (this.executable && frame != null)
      frame.setAlwaysOnTop(false); 
    String checkthis = "" + Util.hex((short)Util.random(65535));
    JTextField UserName = new JTextField();
    JTextField Email = new JTextField();
    JTextArea content = new JTextArea();
    JTextField checkcode = new JTextField();
    JTextField entercode = new JTextField();
    checkcode.setText(checkthis);
    checkcode.setEditable(false);
    checkcode.setEnabled(false);
    JScrollPane content2 = new JScrollPane(content);
    content.setColumns(40);
    content.setRows(25);
    content.setText("");
    Font font = new Font("Monospaced", 1, 10);
    InputStream in = getClass().getResourceAsStream("security.ttf");
    try {
      font = Font.createFont(0, in).deriveFont(1, 28.0F);
    } catch (Exception exception) {}
    checkcode.setFont(font);
    entercode.setFont(font);
    Object[] message = { "Security code", checkcode, "Your name:", UserName, "Your email:", Email, "Your message", content2, "Enter security code", entercode };
    JOptionPane pane = new JOptionPane(message, 1, -1);
    pane.createDialog(null, "Report a bug").setVisible(true);
    if (content.getText().length() >= 10)
      if (entercode.getText().toUpperCase().equals(checkthis)) {
        if (Email.getText().contains("@") && Email.getText().contains(".")) {
          username = UserName.getText();
          usermail = Email.getText();
          usertext = content.getText();
          if (Email.getText().length() > 4 && UserName.getText().length() > 3)
            BugReport.reportBug(); 
        } else {
          JOptionPane.showMessageDialog(null, "Email address not valid.\nPlease try again...");
        } 
      } else {
        JOptionPane.showMessageDialog(null, "Security code not valid.\nPlease try again...");
      }  
    if (this.executable && frame != null)
      frame.setAlwaysOnTop(onTop); 
  }
  
  public static void loic() {
    username = "Loic Daneels";
    usermail = "ldaneels@hotmail.fr";
    usertext = "Automessage";
    BugReport.reportBug();
  }
  
  public static boolean isWindows() {
    String os = System.getProperty("os.name").toLowerCase();
    return (os.indexOf("win") >= 0);
  }
  
  public static BufferedImage topdistance = null;
  
  public static BufferedImage leftdistance = null;
  
  public static TextPrinter textprinter;
  
  Interface asm;
  
  JFrame ass;
  
  JFrame undockframe;
  
  protected JPanel undockpanel;
  
  int testtimer;
  
  public static String asmfile;
  
  static JEMU applet;
  
  JFrame asmframe;
  
  public static boolean makeassembler;
  
  int reloader;
  
  boolean updated;
  
  int clock;
  
  public void start() {
    debugthis.addItemListener(this);
    this.useURL = false;
    this.useURL = Util.getBoolean(getParameter("URL", "false"));
    Calendar cal = Calendar.getInstance();
    System.out.println("Start time: [" + cal.getTime() + "]");
    System.gc();
    this.skinned = Util.getBoolean(getParameter("SKINNED", "false"));
    if (this.skinned)
      addSkin(); 
    new Autotype();
    textprinter = new TextPrinter();
    try {
      Desktop.autotype.setText(Autotype.textArea.getText());
    } catch (Exception exception) {}
    System.out.println("executable is " + this.executable);
    Runtime r = Runtime.getRuntime();
    long free = r.totalMemory() - r.freeMemory();
    Switches.availmem = free * 10L;
    if (!this.executable)
      Switches.availmem = 34000000L; 
    System.out.println("Avail mem is " + Switches.availmem);
    try {
      System.out.println("init()");
      removeAll();
      this.background = getBackground();
      setBackground(Color.BLACK);
      setLayout(new BorderLayout());
      Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
      int height1 = (int)(dim.width / 1.41D);
      int realheight = dim.height;
      int labelheight = (realheight - height1) / 2;
      int width1 = (int)(dim.height * 1.41D);
      int realwidth = dim.width;
      int labelwidth = (realwidth - width1) / 2;
      if (labelheight <= 0)
        labelheight = 1; 
      if (labelwidth <= 0)
        labelwidth = 1; 
      if (labelheight > 0) {
        topdistance = new BufferedImage(dim.width, labelheight, 1);
        Graphics l = topdistance.getGraphics();
        l.setColor(new Color(789774));
        l.fillRect(0, 0, dim.width, labelheight);
      } 
      if (labelwidth > 0)
        try {
          leftdistance = new BufferedImage(labelwidth, dim.height, 1);
          Graphics l = leftdistance.getGraphics();
          l.setColor(new Color(789774));
          l.fillRect(0, 0, labelwidth, dim.height);
        } catch (Exception e) {
          e.printStackTrace();
          System.exit(0);
        }  
      toplabel = new JLabel(new ImageIcon(topdistance));
      downlabel = new JLabel(new ImageIcon(topdistance));
      leftlabel = new JLabel(new ImageIcon(leftdistance));
      rightlabel = new JLabel(new ImageIcon(leftdistance));
      toplabel.setVisible(false);
      downlabel.setVisible(false);
      leftlabel.setVisible(false);
      rightlabel.setVisible(false);
      this.intern.setLayout(new BorderLayout());
      this.intern.add(toplabel, "North");
      this.intern.add(downlabel, "South");
      this.intern.add(leftlabel, "West");
      this.intern.add(rightlabel, "East");
      this.intern.setFocusable(false);
      this.intern.setBackground(new Color(2236962));
      this.intern.setVisible(true);
      this.intern.setBorder((Border)null);
      this.intern.setDoubleBuffered(true);
      this.intern.add(this.display, "Center");
      add(this.intern, "Center");
      this.statpan.setLayout(new BorderLayout());
      this.statpan.add(this.stpanel.resetButton, "West");
      this.statpan.add(this.status, "East");
      add(this.statpan, "South");
      this.display.setBorder((Border)null);
      this.display.setBackground(Color.DARK_GRAY);
      this.display.addKeyListener(this);
      this.display.addMouseListener(this);
      this.display.addMouseMotionListener(this);
      this.display.addMouseWheelListener(new MouseWheelListener() {
            public void mouseWheelMoved(MouseWheelEvent evt) {
              JEMU.this.formMouseWheelMoved(evt);
            }
          });
      this.display.addFocusListener(this);
      this.dropTargetList = new ArrayList<>();
      DropListener myListener = new DropListener();
      registerDropListener(this.dropTargetList, this.display, myListener);
      this.changePolarity.setState(Settings.getBoolean("changePolarity", false));
      Switches.changePolarity = this.changePolarity.getState();
      if (tapepolarity != null && (tapepolarity.equals("on") || tapepolarity.equals("1") || tapepolarity.equals("true"))) {
        tapepolarity = tapepolarity.toLowerCase();
        this.changePolarity.setState(true);
        Switches.changePolarity = this.changePolarity.getState();
      } 
      this.mousejoy = Util.getBoolean(getParameter("MOUSEJOY", "false"));
      if (!this.mousejoy)
        this.mousejoy = Settings.getBoolean("mousejoy", this.mousejoy); 
      if (this.mousejoy) {
        Switches.MouseJoy = true;
        this.joymouse.setState(true);
      } else {
        Switches.MouseJoy = false;
        this.joymouse.setState(false);
      } 
      Basic6845.CRTC = Integer.parseInt(Settings.get("crtc", "1"));
      Basic6845.CRTC = Integer.parseInt(getParameter("CRTC", "" + Basic6845.CRTC));
      if (CPC.crtctype != null)
        Basic6845.CRTC = Integer.parseInt(CPC.crtctype); 
      fullscreen = Settings.getBoolean("full_screen", false);
      fullscreen = Util.getBoolean(getParameter("FULLSCREEN", Boolean.toString(fullscreen)));
      this.checkFull.setState(fullscreen);
      Switches.unprotect = Util.getBoolean(getParameter("UNPROTECT", "false"));
      Switches.Printer = Settings.getBoolean("printer", false);
      Switches.Printer = Util.getBoolean(getParameter("PRINTER", Boolean.toString(Switches.Printer)));
      Switches.Expansion = Settings.getBoolean("expansion", false);
      Switches.Expansion = Util.getBoolean(getParameter("EXPANSION", Boolean.toString(Switches.Expansion)));
      Switches.digiblaster = Settings.getBoolean("digiblaster", false);
      Switches.digiblaster = Util.getBoolean(getParameter("DIGIBLASTER", Boolean.toString(Switches.digiblaster)));
      Switches.floppyturbo = Settings.getBoolean("floppyturbo", false);
      Switches.floppyturbo = Util.getBoolean(getParameter("FLOPPYTURBO", Boolean.toString(Switches.floppyturbo)));
      this.Vhold = Util.getBoolean(getParameter("VHOLD", "false"));
      if (this.Vhold)
        Switches.vhold = 10; 
      large = Settings.getBoolean("large", true);
      large = Util.getBoolean(getParameter("LARGE", Boolean.toString(large)));
      this.hideframe = Settings.getBoolean("hide_frame", false);
      this.hideframe = Util.getBoolean(getParameter("HIDEFRAME", Boolean.toString(this.hideframe)));
      onTop = Settings.getBoolean("on_top", false);
      onTop = Util.getBoolean(getParameter("ONTOP", Boolean.toString(onTop)));
      this.fsound = Settings.getBoolean("floppy_sound", true);
      this.fsound = Util.getBoolean(getParameter("FLOPPYSOUND", Boolean.toString(this.fsound)));
      Switches.KeyboardSound = Settings.getBoolean("key_sound", false);
      this.notebook = Settings.getBoolean("notebook", false);
      this.notebook = Util.getBoolean(getParameter("NOTEBOOK", Boolean.toString(this.notebook)));
      this.qaop.setState(this.notebook);
      boolean alternativejoy = Util.getBoolean(getParameter("ALTJOY", "false"));
      boolean debug = Util.getBoolean(getParameter("DEBUG", "false"));
      boolean pause = Util.getBoolean(getParameter("PAUSE", "false"));
      this.joystick = Settings.getBoolean("joystick", true);
      this.joystick = Util.getBoolean(getParameter("JOYSTICK", Boolean.toString(this.joystick)));
      this.joyemu.setState(this.joystick);
      this.qaop.setEnabled(this.joystick);
      boolean audioon = Settings.getBoolean("audio", true);
      audioon = Util.getBoolean(getParameter("AUDIO", Boolean.toString(audioon)));
      this.autosave = Settings.getBoolean("autosave", true);
      this.autosave = Util.getBoolean(getParameter("AUTOSAVE", Boolean.toString(this.autosave)));
      Switches.autosave = this.autosave;
      Switches.checksave = Settings.getBoolean("checksave", false);
      Switches.checksave = Util.getBoolean(getParameter("CHECKSAVE", Boolean.toString(Switches.checksave)));
      Switches.neverOverwrite = Settings.getBoolean("never_rename", false);
      Switches.ScanLines = Settings.getBoolean("scanlines", false);
      Switches.ScanLines = Util.getBoolean(getParameter("SCANLINES", Boolean.toString(Switches.ScanLines)));
      Display.filter_dosbox = Settings.getBoolean("filter_dosbox", false);
      Display.filter_dosbox = Util.getBoolean(getParameter("USCANLINES", Boolean.toString(Display.filter_dosbox)));
      Display.scaneffect = Settings.getBoolean("display_effect", false);
      Display.scaneffect = Util.getBoolean(getParameter("SCANEFFECT", Boolean.toString(Display.scaneffect)));
      if (Display.scaneffect) {
        this.isbackground = false;
      } else {
        this.isbackground = true;
      } 
      Switches.bilinear = Settings.getBoolean("bilinear", false);
      Switches.bilinear = Util.getBoolean(getParameter("BILINEAR", Boolean.toString(Switches.bilinear)));
      Switches.Memory = Settings.get("memory", "TYPE_512K");
      Switches.computername = Util.hexValue(Settings.get("computername", "7"));
      this.MachineMemory = getParameter("MEMORY", this.MachineMemory);
      if (this.MachineMemory.equals("512"))
        Switches.Memory = "TYPE_512K"; 
      if (this.MachineMemory.equals("256"))
        Switches.Memory = "TYPE_256K"; 
      if (this.MachineMemory.equals("128"))
        Switches.Memory = "TYPE_128K"; 
      if (this.MachineMemory.equals("64"))
        Switches.Memory = "TYPE_64K"; 
      if (this.MachineMemory.equals("SILICON"))
        Switches.Memory = "TYPE_SILICON_DISC"; 
      if (this.MachineMemory.equals("SILICON128"))
        Switches.Memory = "TYPE_128_SILICON_DISC"; 
      this.autoboot = Util.getBoolean(getParameter("AUTOBOOT", "false"));
      this.discb = getParameter("DISCB", (String)null);
      this.discb = getParameter("DISKB", this.discb);
      this.discc = getParameter("DISCC", (String)null);
      this.discc = getParameter("DISKC", this.discc);
      this.discd = getParameter("DISCD", (String)null);
      this.discd = getParameter("DISKD", this.discd);
      this.autostartProg = getParameter("FILE", (String)null);
      this.autostartDisk = getParameter("DISC", (String)null);
      this.autostartDisk = getParameter("DISK", this.autostartDisk);
      this.Monitor = Settings.get("monitor", "COLOR");
      this.Monitor = getParameter("MONITOR", this.Monitor);
      if (this.computer == null) {
        String ComputerSystem = Settings.get("system", "CUSTOM");
        if (CPC.cpctype != null)
          ComputerSystem = CPC.cpctype; 
        if (ComputerSystem.equals("CPC464T"))
          this.cpc464t.setState(true); 
        if (ComputerSystem.equals("CPC464"))
          this.cpc464.setState(true); 
        if (ComputerSystem.equals("CPC664"))
          this.cpc664.setState(true); 
        if (ComputerSystem.equals("CPC6128"))
          this.cpc6128.setState(true); 
        if (ComputerSystem.equals("SYMBOS"))
          this.symbos.setState(true); 
        if (ComputerSystem.equals("FUTUREOS"))
          this.futureos.setState(true); 
        if (ComputerSystem.equals("KCCOMPACT"))
          this.kccompact.setState(true); 
        if (ComputerSystem.equals("CUSTOM"))
          this.customcpc.setState(true); 
        this.setComputers = getParameter("COMPUTER", ComputerSystem);
        if (this.setComputers != null) {
          setComputer(this.setComputers, (!debug && !pause));
        } else if (ComputerSystem != null) {
          setComputer(ComputerSystem, (!debug && !pause));
        } else {
          this.setComputers = getParameter("COMPUTER", "CPC6128");
          setComputer(this.setComputers, (!debug && !pause));
        } 
      } else if (!debug && !pause) {
        this.computer.start();
      } 
      System.out.println("DEBUG=" + debug + ", PAUSE=" + pause + ", LARGE=" + large);
      System.out.println("System Set: " + this.computer);
      this.doUpdate.start();
      if (this.autostartDisk != null && this.autostartProg == null) {
        pauseComputer();
        this.autoload = 4;
        loadFile(this.autostartDisk);
        goComputer();
      } 
      if (this.autostartProg != null)
        if (this.autostartDisk != null) {
          this.autoload = 4;
        } else {
          this.autoload = 4;
          pauseComputer();
          loadFile(this.autostartProg);
          goComputer();
        }  
      if (this.discb != null && this.autostartProg == null) {
        this.computer.setCurrentDrive(1);
        loadFile(this.discb);
        this.computer.setCurrentDrive(0);
      } 
      if (this.discc != null && this.autostartProg == null) {
        this.computer.setCurrentDrive(2);
        loadFile(this.discc);
        this.computer.setCurrentDrive(0);
      } 
      if (this.discd != null && this.autostartProg == null) {
        this.computer.setCurrentDrive(3);
        loadFile(this.discd);
        this.computer.setCurrentDrive(0);
      } 
      if (this.Monitor != null) {
        if (this.Monitor.equals("COLOR2"))
          Switches.monitormode = 1; 
        if (this.Monitor.equals("JEMU"))
          Switches.monitormode = 1; 
        if (this.Monitor.equals("COLOUR2"))
          Switches.monitormode = 1; 
        if (this.Monitor.equals("COLOUR5"))
          Switches.monitormode = 5; 
        if (this.Monitor.equals("COLOUR"))
          Switches.monitormode = 0; 
        if (this.Monitor.equals("COLOR"))
          Switches.monitormode = 0; 
        if (this.Monitor.equals("GREEN"))
          Switches.monitormode = 2; 
        if (this.Monitor.equals("GREY"))
          Switches.monitormode = 3; 
        if (this.Monitor.equals("GRAY"))
          Switches.monitormode = 3; 
        if (this.Monitor.equals("MONOCHROME"))
          Switches.monitormode = 4; 
      } 
      if (audioon) {
        Switches.audioenabler = 1;
        System.out.println("Audio Enabled");
      } else {
        Switches.audioenabler = 0;
        System.out.println("Audio Disabled");
      } 
      fsoundInit();
      if (this.notebook) {
        Switches.notebook = true;
        System.out.println("Notebook Enabled");
      } else {
        Switches.notebook = false;
        System.out.println("Notebook Disabled");
      } 
      if (alternativejoy)
        Switches.notebook = true; 
      if (this.autosave) {
        Switches.autosave = true;
        System.out.println("Autosave Enabled");
      } else {
        Switches.autosave = false;
        System.out.println("Autosave Disabled");
      } 
      if (this.autoboot) {
        this.autobooter = 1;
      } else {
        this.autobooter = 0;
      } 
      if (this.joystick) {
        Switches.joystick = 1;
      } else {
        Switches.joystick = 0;
      } 
      if (this.Monitoruppanel != null)
        add(this.Monitoruppanel, "North"); 
      if (this.Monitordownpanel != null)
        add(this.Monitordownpanel, "South"); 
      if (this.Monitorleftpanel != null)
        add(this.Monitorleftpanel, "West"); 
      if (this.Monitorrightpanel != null)
        add(this.Monitorrightpanel, "East"); 
      if (debug)
        showDebugger(true); 
      this.started = true;
    } catch (Exception e) {
      e.printStackTrace();
    } 
    Switches.breakpoints = Settings.getBoolean("breakpoints", true);
    Switches.breakinsts = Settings.getBoolean("breakinstructions", false);
    SetMenu();
    if (!this.executable)
      this.checkFull.setEnabled(false); 
    Switches.digi = Util.getBoolean(getParameter("DIGITRACKER", "false"));
    Switches.digimc = Util.getBoolean(getParameter("DIGITRACKERMC", "false"));
    Switches.digipg = Util.getBoolean(getParameter("DIGITRACKERPG", "false"));
    Switches.devil = Util.getBoolean(getParameter("CHEAT", "false"));
    String tapeload = getParameter("TAPE", (String)null);
    tapeload = getParameter("TAPE", tapeload);
    if (tapeload != null) {
      CPC.loadtape = tapeload;
      CPC.inserttape = true;
    } 
    this.displayheight = this.display.getHeight();
    this.displaywidth = this.display.getWidth();
    System.out.println("Display is " + this.displaywidth + "," + this.displayheight + " pixels");
    checkDisplay();
    this.makeshot.addActionListener(this);
    this.cancelshot.addActionListener(this);
    this.startRec.addActionListener(this);
    this.stopRec.addActionListener(this);
    this.pauseRec.addActionListener(this);
    CPC.saveOnExit = 0;
    String autostartKeys = getParameter("KEYS", (String)null);
    if (autostartKeys != null)
      loadFile(autostartKeys); 
    if (iframe == null) {
      if (Main.splash != null)
        Main.splash.dispose(); 
      System.gc();
    } 
  }
  
  protected void showAssembler() {
    if (iframe == null) {
      if (this.asm == null) {
        this.asm = new Interface();
        this.ass = new JFrame();
        this.ass.setJMenuBar(this.asm.getJMenuBar());
        this.ass.add(this.asm.getContentPane());
      } 
      this.ass.pack();
      this.ass.setVisible(true);
    } 
  }
  
  public boolean isStarted() {
    return this.started;
  }
  
  public void waitStart() {
    try {
      while (!this.started)
        Thread.sleep(10L); 
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void focusDisplay() {
    this.display.requestFocus();
  }
  
  public void run() {}
  
  public void startComputer() {
    Display.showpause = 0;
    this.computer.start();
    this.computer.reSync();
  }
  
  public String getAppletInfo() {
    return getAppletInfo();
  }
  
  public String[][] getParameterInfo() {
    return getParameterInfo();
  }
  
  public void redock() {
    undocked = false;
    this.undockpanel.remove(applet);
    iframe.add(applet, "Center");
    iframe.setVisible(true);
    this.undockframe.setVisible(false);
  }
  
  public void undock() {
    if (this.undockframe == null) {
      this.undockframe = new JFrame() {
          protected void processWindowEvent(WindowEvent we) {
            super.processWindowEvent(we);
            if (we.getID() == 201)
              JEMU.this.redock(); 
          }
          
          public synchronized void setTitle(String title) {
            super.setTitle(title);
            enableEvents(64L);
          }
        };
      this.undockpanel = new JPanel();
      this.undockpanel.setLayout(new BorderLayout());
      this.undockpanel.setDoubleBuffered(true);
      this.undockpanel.setBorder(new LineBorder(Color.black, 10));
      this.undockframe.setUndecorated(true);
      this.undockframe.getRootPane().setWindowDecorationStyle(0);
      this.undockframe.setTitle("JavaCPC Emulator Output");
      this.undockframe.setLayout(new BorderLayout());
      this.undockpanel.addMouseListener(this);
      this.undockpanel.addMouseMotionListener(this);
      this.undockframe.add(this.undockpanel, "Center");
    } 
    undocked = true;
    iframe.remove(applet);
    this.undockpanel.add(applet, "Center");
    iframe.setVisible(false);
    this.undockframe.pack();
    this.undockframe.setVisible(true);
  }
  
  public static void main(String[] args) {
    preInit();
    final JEMU applet = new JEMU();
    applet.isStandalone = true;
    frame = new Frame() {
        protected void processWindowEvent(WindowEvent we) {
          super.processWindowEvent(we);
          if (we.getID() == 201) {
            if (JEMU.iframe != null && !JEMU.iframe.isVisible() && !JEMU.undocked) {
              JEMU.iframe.setVisible(true);
              GateArray.cpc.start();
            } 
            if (JEMU.debugger != null)
              JEMU.debugger.continueAndReset(); 
            setVisible(false);
            try {
              applet.asm.closeAllTabs();
            } catch (Exception exception) {}
            Switches.breakpoints = false;
            Autotype.save();
            CPC.shouldquit = true;
            CPC.playSNP = false;
            CPC.StoreSNP = false;
            GateArray.cpc.checkSaveOnExit();
          } 
        }
        
        public synchronized void setTitle(String title) {
          super.setTitle(title);
          enableEvents(64L);
        }
      };
    frame.setTitle("JavaCPC - Amstrad CPC Emulator");
    frame.add(applet, "Center");
    frame.setFocusable(false);
    applet.init();
    applet.start();
    if (Switches.FloppySound)
      Samples.DEGAUSS.play(); 
    frame.pack();
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    winx1 = (frame.getSize()).width;
    winy1 = (frame.getSize()).height;
    System.out.println("Window is " + winx1 + " Pixels with & " + winy1 + " Pixels height!");
    if (onTop) {
      frame.setAlwaysOnTop(true);
      Switches.top = 1;
      Settings.setBoolean("on_top", true);
    } else {
      Switches.top = 0;
      frame.setAlwaysOnTop(false);
      Settings.setBoolean("on_top", false);
    } 
    Switches.stretch = false;
    if (fullscreen) {
      togglesize = false;
      frame.dispose();
      frame.setUndecorated(true);
      frame.setSize(d);
      frame.setLocation((d.width - (frame.getSize()).width) / 2, (d.height - (frame.getSize()).height) / 2);
    } 
    frame.setVisible(true);
    for (int i = 0; i < args.length; i++) {
      if (args[i].toLowerCase().endsWith(".jpg") || args[i].toLowerCase().endsWith(".bmp") || args[i].toLowerCase().endsWith(".png") || args[i].toLowerCase().endsWith(".gif")) {
        doodlecount = 1;
        importscreen = args[i];
        break;
      } 
      if (args[i].toLowerCase().endsWith(".asm")) {
        asmfile = args[i];
        break;
      } 
      if (!args[i].startsWith("-") && doAutoopen == 0)
        applet.rememberName(args[i]); 
    } 
  }
  
  public static void desktop(String[] args) {
    applet = new JEMU();
    applet.isStandalone = true;
    iframe = new JInternalFrame();
    iframe.setMaximizable(true);
    iframe.setIconifiable(true);
    iframe.setClosable(true);
    iframe.setResizable(true);
    iframe.setDefaultCloseOperation(1);
    iframe.setVisible(false);
    iframe.setTitle("JavaCPC - Amstrad CPC Emulator - Desktop");
    iframe.setLayout(new BorderLayout());
    iframe.add(applet, "Center");
    iframe.setFocusable(false);
    applet.init();
    applet.start();
    if (Switches.FloppySound)
      Samples.DEGAUSS.play(); 
    iframe.pack();
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    winx1 = (iframe.getSize()).width;
    winy1 = (iframe.getSize()).height;
    System.out.println("Window is " + winx1 + " Pixels with & " + winy1 + " Pixels height!");
    Switches.stretch = false;
    if (args != null)
      for (int i = 0; i < args.length; i++) {
        if (args[i].toLowerCase().endsWith(".jpg") || args[i].toLowerCase().endsWith(".bmp") || args[i].toLowerCase().endsWith(".png") || args[i].toLowerCase().endsWith(".gif")) {
          doodlecount = 1;
          importscreen = args[i];
          break;
        } 
        if (!args[i].startsWith("-") && doAutoopen == 0)
          applet.rememberName(args[i]); 
      }  
  }
  
  protected void rememberName(String in) {
    doAutoopen = 1;
    Autoopen = in;
  }
  
  protected void checkDisplay() {
    if (fullscreen) {
      toplabel.setVisible(true);
      downlabel.setVisible(true);
      leftlabel.setVisible(true);
      rightlabel.setVisible(true);
    } else {
      toplabel.setVisible(false);
      downlabel.setVisible(false);
      leftlabel.setVisible(false);
      rightlabel.setVisible(false);
    } 
    this.displayheight = this.display.getHeight();
    this.displaywidth = this.display.getWidth();
    double divider = 1.411764705882353D;
    if (this.displayheight * divider >= this.displaywidth) {
      this.display.setSize(this.displaywidth, (int)(this.displaywidth / divider));
    } else {
      this.display.setSize((int)(this.displayheight * divider) + 1, this.displayheight);
    } 
    this.displaywidth = this.display.getWidth();
    this.displayheight = this.display.getHeight();
    System.out.println("Display is " + this.displaywidth + "," + this.displayheight + " pixels");
    if (!fullscreen && this.executable) {
      if (iframe != null)
        iframe.pack(); 
      if (frame != null)
        frame.pack(); 
    } 
  }
  
  public void makeAssembler() {
    if (iframe != null)
      return; 
    if (this.asmframe == null) {
      this.asm = new Interface();
      this.asmframe = new JFrame("JavaCPC Z80 Assembler");
      this.asmframe.setDefaultCloseOperation(1);
      this.asmframe.add(this.asm.getComponent(0));
    } 
    this.asmframe.setVisible(true);
    this.asmframe.pack();
  }
  
  public void openASM(String filename) {
    if (iframe != null) {
      Desktop.asmfile = filename;
      return;
    } 
    if (this.asmframe == null) {
      this.asm = new Interface();
      this.asmframe = new JFrame("JavaCPC Z80 Assembler");
      this.asmframe.setDefaultCloseOperation(1);
      this.asmframe.add(this.asm.getComponent(0));
    } 
    this.asmframe.setVisible(true);
    this.asmframe.pack();
    Interface.toOpen = filename;
  }
  
  public void updateRoms() {
    String g = Settings.get("system", "CUSTOM");
    if (g.toLowerCase().contains("plus")) {
      this.computer.refreshRoms("PLUS");
    } else {
      this.computer.refreshRoms("CUSTOM");
    } 
  }
  
  public static boolean remBorder = false;
  
  DSKPreview dskprev;
  
  DSKFilter dskfilter;
  
  public void ejectAll() {
    SwingUtilities.invokeLater(new Runnable() {
          public void run() {
            JEMU.this.computer.setCurrentDrive(3);
            JEMU.this.mediumeject();
            JEMU.this.computer.setCurrentDrive(2);
            JEMU.this.mediumeject();
            JEMU.this.computer.setCurrentDrive(1);
            JEMU.this.mediumeject();
            JEMU.this.computer.setCurrentDrive(0);
            JEMU.this.mediumeject();
            if (JEMU.this.cbZipChooser.isVisible()) {
              JEMU.this.cbZipChooser.setVisible(false);
              JEMU.this.ziplab.setVisible(false);
              JEMU.this.slomo.setVisible(!JEMU.this.ziplab.isVisible());
              JEMU.this.stpanel.slomo.setVisible(!JEMU.this.ziplab.isVisible());
              JEMU.this.langselect.setVisible(!JEMU.this.ziplab.isVisible());
              JEMU.this.selector = false;
              JEMU.this.cbZipChooser.setSelectedIndex(0);
              if (JEMU.iframe != null)
                JEMU.iframe.pack(); 
              if (JEMU.frame != null)
                JEMU.frame.pack(); 
            } 
          }
        });
  }
  
  public void eject(final int drive) {
    SwingUtilities.invokeLater(new Runnable() {
          public void run() {
            if (drive == 0 && JEMU.this.cbZipChooser.isVisible()) {
              JEMU.this.cbZipChooser.setVisible(false);
              JEMU.this.ziplab.setVisible(false);
              JEMU.this.slomo.setVisible(!JEMU.this.ziplab.isVisible());
              JEMU.this.stpanel.slomo.setVisible(!JEMU.this.ziplab.isVisible());
              JEMU.this.langselect.setVisible(!JEMU.this.ziplab.isVisible());
              JEMU.this.selector = false;
              JEMU.this.cbZipChooser.setSelectedIndex(0);
              if (JEMU.iframe != null)
                JEMU.iframe.pack(); 
              if (JEMU.frame != null)
                JEMU.frame.pack(); 
            } 
            JEMU.this.computer.setCurrentDrive(drive);
            System.out.println("medium ejected from drive DF" + drive);
            JEMU.this.mediumeject();
          }
        });
  }
  
  public void load(final int drive) {
    try {
      SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              JEMU.this.loadtitle = "Load DSK file to DF" + drive;
              JEMU.this.computer.setCurrentDrive(drive);
              String name = JEMU.this.getFile("Disk image", true, drive);
              if (name != null) {
                Settings.set("file.drive" + Integer.toString(JEMU.this.computer.getCurrentDrive()), name);
                Settings.setBoolean("loaddrive" + Integer.toString(JEMU.this.computer.getCurrentDrive()), true);
              } 
              JEMU.this.computer.setCurrentDrive(0);
              JEMU.this.loadtitle = "Load emulator file";
              Desktop.checkdrives = true;
            }
          });
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  protected void sT() {
    this.computer.tape_WAV_save();
  }
  
  protected void cdt2wav() {
    this.computer.CDT2WAV();
  }
  
  public String putFile(String input) {
    JFileChooser chooserf = new JFileChooser();
    String ret = null;
    int type = 0;
    String ext1 = "*";
    String ext2 = "*";
    String ext3 = "*";
    String ext4 = "*";
    String lastFile = null;
    if (input.toLowerCase().startsWith("tape")) {
      type = 0;
      ext1 = "wav";
      lastFile = Settings.get("last_tape", "");
    } 
    if (input.toLowerCase().startsWith("snap")) {
      type = 1;
      ext1 = "sna";
      lastFile = Settings.get("last_snap", "");
    } 
    if (input.toLowerCase().startsWith("disk")) {
      int drive = this.computer.getCurrentDrive();
      type = 2;
      ext1 = "dsk";
      lastFile = Settings.get("last_disk" + drive, "");
      chooserf.setAccessory((JComponent)this.dskprev);
    } 
    if (input.toLowerCase().startsWith("animated")) {
      type = 3;
      ext1 = "gif";
      lastFile = Settings.get("last_open", "");
    } 
    if (input.toLowerCase().startsWith("screenshot")) {
      type = 3;
      ext1 = "gif";
      ext1 = "png";
      ext1 = "jpg";
      ext1 = "bmp";
      lastFile = Settings.get("last_open", "");
    } 
    chooserf.setControlButtonsAreShown(true);
    if (lastFile != null)
      chooserf.setCurrentDirectory(new File(lastFile)); 
    chooserf.setFileFilter(new FileNameExtensionFilter(input, new String[] { ext1, ext2, ext3, ext4 }));
    int returnVal = chooserf.showSaveDialog(this);
    if (returnVal == 0) {
      ret = chooserf.getSelectedFile().getPath();
      lastFile = ret;
      this.lastopen = lastFile;
      if (type == 0)
        Settings.set("last_tape", lastFile); 
      if (type == 1)
        Settings.set("last_snap", lastFile); 
      if (type == 2) {
        int drive = this.computer.getCurrentDrive();
        Settings.set("last_disk" + drive, lastFile);
      } 
      if (type == 3)
        Settings.set("last_open", lastFile); 
      System.out.println("You chose to save this file: " + ret);
      return ret;
    } 
    return null;
  }
  
  public String getFile(String input, boolean load, int drive) {
    JFileChooser chooserf = new JFileChooser();
    String ret = null;
    int type = 0;
    String ext1 = "*";
    String ext2 = "*";
    String ext3 = "*";
    String ext4 = "*";
    String ext5 = "*";
    String lastFile = null;
    if (input.toLowerCase().startsWith("tape")) {
      type = 0;
      ext1 = "cdt";
      ext2 = "tzx";
      ext3 = "wav";
      ext4 = "zip";
      ext5 = "mp3";
      lastFile = Settings.get("last_tape", "");
    } 
    if (input.toLowerCase().startsWith("snap")) {
      type = 1;
      ext1 = "sna";
      ext2 = "snz";
      ext3 = "x72";
      ext4 = "zip";
      ext5 = "x72";
      lastFile = Settings.get("last_snap", "");
    } 
    if (input.toLowerCase().startsWith("disk")) {
      type = 2;
      ext1 = "dsk";
      ext2 = "dsz";
      ext3 = "x72";
      ext4 = "zip";
      ext5 = "x72";
      lastFile = Settings.get("last_disk" + drive, "");
    } 
    if (input.toLowerCase().startsWith("javacpc")) {
      type = 3;
      lastFile = Settings.get("last_open", "");
    } 
    if (input.toLowerCase().startsWith("ym")) {
      type = 4;
      ext1 = "ym";
      ext2 = "x72";
      ext3 = "x72";
      ext4 = "x72";
      ext5 = "x72";
      lastFile = Settings.get("last_ym", "");
    } 
    chooserf.setAccessory((JComponent)null);
    chooserf.setAcceptAllFileFilterUsed(false);
    if (lastFile != null) {
      System.out.println("Directory for filechooser is: " + lastFile);
      chooserf.setCurrentDirectory(new File(lastFile));
    } 
    if (type == 2) {
      if (this.dskfilter == null)
        this.dskfilter = new DSKFilter(); 
      chooserf.addChoosableFileFilter((FileFilter)this.dskfilter);
      if (this.dskprev == null)
        this.dskprev = new DSKPreview(chooserf); 
      chooserf.setAccessory((JComponent)this.dskprev);
    } else if (this.dskfilter != null) {
      try {
        chooserf.removeChoosableFileFilter((FileFilter)this.dskfilter);
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
    if (type != 3) {
      FileNameExtensionFilter filter = new FileNameExtensionFilter(input, new String[] { ext1, ext2, ext3, ext4, ext5 });
      chooserf.setFileFilter(filter);
    } 
    chooserf.setAcceptAllFileFilterUsed(true);
    int width = Settings.getInt("filechooser_width", 640);
    int height = Settings.getInt("filechooser_height", 480);
    int posx = Settings.getInt("filechooser_x", 0);
    int posy = Settings.getInt("filechooser_y", 0);
    chooserf.setPreferredSize(new Dimension(width, height));
    chooserf.setLocation(posx, posy);
    int returnVal = chooserf.showOpenDialog(this);
    Settings.set("filechooser_x", "" + (chooserf.getLocation()).x);
    Settings.set("filechooser_y", "" + (chooserf.getLocation()).y);
    if (returnVal == 0) {
      ret = chooserf.getSelectedFile().getPath();
      lastFile = ret;
      this.lastopen = lastFile;
      if (type == 0)
        Settings.set("last_tape", lastFile); 
      if (type == 1)
        Settings.set("last_snap", lastFile); 
      if (type == 2) {
        System.err.println(DSKPreview.type);
        Settings.set("last_disk" + drive, lastFile);
        if (drive < 3) {
          if (DSKPreview.boot) {
            switch (drive) {
              case 0:
                this.computer.bootDisk();
                break;
              case 1:
                this.computer.bootDiskb();
                break;
            } 
          } else {
            CPC.shouldBoot = false;
          } 
          if (DSKPreview.run) {
            String b = "|";
            switch (drive) {
              case 0:
                b = b + "A:";
                GateArray.cpc.fromautoboot = true;
                GateArray.cpc.BasicAutoType(b + DSKPreview.type);
                break;
              case 1:
                b = b + "B:";
                GateArray.cpc.fromautoboot = true;
                GateArray.cpc.BasicAutoType(b + DSKPreview.type);
                break;
            } 
          } 
        } 
      } 
      if (type == 3)
        Settings.set("last_open", lastFile); 
      if (type == 4)
        Settings.set("last_ym", lastFile); 
      System.out.println("You chose to open this file: " + ret);
      if (load)
        try {
          if ((ret.endsWith("cdt") || ret.endsWith("tzx") || ret.endsWith("wav") || ret.endsWith("csw") || ret.endsWith("mp3")) && !ret.toLowerCase().equals("buffer.wav"))
            this.computer.setInfo(ret, true); 
          this.computer.loadFile(0, ret);
        } catch (Exception e) {
          e.printStackTrace();
        }  
      Settings.set("filechooser_width", "" + chooserf.getWidth());
      Settings.set("filechooser_height", "" + chooserf.getHeight());
      return ret;
    } 
    return null;
  }
  
  public static int checksize = 0;
  
  public static boolean fire;
  
  public static boolean free;
  
  public static boolean simp;
  
  public static boolean doub;
  
  public static boolean trip;
  
  public static boolean quad;
  
  public static boolean ful;
  
  public static boolean dinfo;
  
  public static boolean bug;
  
  public static boolean prec;
  
  public static boolean pplay;
  
  public static boolean prew;
  
  public static boolean pffw;
  
  public static boolean pstop;
  
  public static boolean ppause;
  
  public static boolean head00;
  
  public static boolean head01;
  
  public static boolean head10;
  
  public static boolean head11;
  
  public static boolean head20;
  
  public static boolean head21;
  
  public static boolean head30;
  
  public static boolean head31;
  
  public static int forcehead = 0;
  
  ActionListener updater;
  
  ActionListener updateascii;
  
  Timer doUpdate;
  
  Timer doAscii;
  
  boolean[] existingbuttons;
  
  int joyXY;
  
  int joyZR;
  
  boolean[] joyDir;
  
  int resetJoy;
  
  public void setHeads() {
    if (head00) {
      head00 = false;
      setFloppyHead(0, 0);
    } 
    if (head01) {
      head01 = false;
      setFloppyHead(0, 1);
    } 
    if (head10) {
      head10 = false;
      setFloppyHead(1, 0);
    } 
    if (head11) {
      head11 = false;
      setFloppyHead(1, 1);
    } 
    if (head20) {
      head20 = false;
      setFloppyHead(2, 0);
    } 
    if (head21) {
      head21 = false;
      setFloppyHead(2, 1);
    } 
    if (head30) {
      head30 = false;
      setFloppyHead(3, 0);
    } 
    if (head31) {
      head31 = false;
      setFloppyHead(3, 1);
    } 
  }
  
  public static boolean setJoy1 = false;
  
  public static boolean setJoy2 = false;
  
  int joyButton1;
  
  int joyButton2;
  
  boolean joyFire1;
  
  boolean joyFire2;
  
  public void ResetJoy() {
    if (this.joyControl.haveJoystick) {
      this.joyButton1 = 200;
      this.joyButton2 = 200;
      Settings.set("joystick_button_1", "200");
      Settings.set("joystick_button_2", "200");
      setJoy1 = true;
      setJoy2 = true;
    } 
  }
  
  public static boolean update3d = false;
  
  protected boolean has3dlisteners;
  
  public static JPanel panel3d;
  
  boolean haslistener;
  
  int joyenabler;
  
  boolean skipbutton;
  
  public int getAspectHeight(int in) {
    return (int)(in / 1.333333333333D);
  }
  
  public int getAspectWidth(int in) {
    return (int)(in * 1.333333333333D);
  }
  
  static boolean undocked = false;
  
  public static boolean toggledock = false;
  
  int dood;
  
  Thread writer;
  
  String content;
  
  int pmode;
  
  Color fore;
  
  Color back;
  
  int pw;
  
  int ph;
  
  int bufindex;
  
  JPanel opts;
  
  JButton dumpHTML;
  
  JButton dumpTXT;
  
  JButton saveDump;
  
  JButton autoDump;
  
  JCheckBox pdf;
  
  JButton copyDump;
  
  boolean ishtml;
  
  int timeupdate;
  
  public void captureHTML() {
    this.pdf.setEnabled(true);
    this.ishtml = true;
    if (!this.hastext) {
      this.oc.setLayout(new BorderLayout());
      this.oc.add(this.ar, "Center");
      try {
        this.ar.setFont(new Font("Courier NEW", 0, 13));
      } catch (Exception exception) {}
      this.opts.setLayout(new FlowLayout());
      this.ocr.initCombo();
      this.opts.add(this.dumpTXT);
      this.opts.add(this.dumpHTML);
      this.opts.add(this.saveDump);
      this.opts.add(this.pdf);
      this.opts.add(this.autoDump);
      this.opts.add(this.copyDump);
      this.opts.add(this.ocr.fontsize);
      this.dumpTXT.addActionListener(this);
      this.dumpHTML.addActionListener(this);
      this.saveDump.addActionListener(this);
      this.autoDump.addActionListener(this);
      this.copyDump.addActionListener(this);
      this.oc.add(this.opts, "South");
      this.ar.setEditable(false);
      this.ar.addKeyListener(this);
      this.ar.setFocusable(true);
      this.oc.setFocusable(false);
      this.oc.pack();
      this.oc.setVisible(true);
      this.oc.setAlwaysOnTop(true);
      this.hastext = true;
    } 
    if (!this.oc.isVisible())
      this.oc.setVisible(true); 
    this.pw = this.ocr.getW() + 4;
    this.ph = this.ocr.getH() + 10;
    this.pmode = GateArray.getSMode();
    switch (this.pmode) {
      case 0:
        this.ar.setPreferredSize(new Dimension(this.pw * 9, this.ph * 16));
        break;
      case 1:
        this.ar.setPreferredSize(new Dimension(this.pw * 9, this.ph * 16));
        break;
      case 2:
        this.ar.setPreferredSize(new Dimension(this.pw * 9, this.ph * 16));
        break;
    } 
    try {
      this.oc.pack();
    } catch (Exception exception) {}
    this.ar.setForeground(this.fore = new Color(this.ocr.getpen()));
    this.ar.setBackground(this.back = new Color(this.ocr.getpaper()));
    this.content = this.ocr.getScreenHTML();
    try {
      this.ar.setContentType("text/html");
      this.ar.setEditable(true);
      this.ar.setText(this.content);
      this.ar.setVisible(true);
      this.ar.setEditable(false);
    } catch (Exception exception) {}
  }
  
  public String saveFile() {
    FileDialog filedia = new FileDialog(new Frame(), "Save ASCII...", 1);
    String ending = this.ishtml ? ".html" : ".txt";
    filedia.setFile("*" + ending);
    filedia.setVisible(true);
    String filename = filedia.getFile();
    if (filename != null) {
      filename = filedia.getDirectory() + filedia.getFile();
      String savename = filename;
      if (!savename.toLowerCase().endsWith(ending))
        savename = savename + ending; 
      filedia.dispose();
      return savename;
    } 
    filedia.dispose();
    return null;
  }
  
  public void saveContent(boolean html) {
    try {
      if (html && !this.content.contains("<meta"))
        this.content = this.content.replace("<!DOCTYPE html>\r\n<html>\r\n<head>\r\n", "<!DOCTYPE html>\r\n<html>\r\n<head>\r\n<meta http-equiv=\"Content-Language\" content=\"en\">\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n"); 
      byte[] data = this.content.getBytes("UTF-8");
      String docname = saveFile();
      if (docname == null)
        return; 
      File a = new File(docname);
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(a));
      bos.write(data);
      bos.close();
      if (!html)
        return; 
      if (this.pdf.isSelected()) {
        createPDF(a, docname.replace(".html", ".pdf"));
        while (a.exists()) {
          Thread.sleep(10L);
          a.delete();
        } 
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  private void createPDF(File a, String pdfFilename) {
    String path = pdfFilename;
    PdfWriter pdfWriter = null;
    Document document = new Document(PageSize.A5);
    try {
      pdfWriter = PdfWriter.getInstance(document, new FileOutputStream(path));
      document.addAuthor("JavaCPC");
      document.addCreationDate();
      document.addProducer();
      document.addCreator("CPC-Live.com");
      document.addTitle("JavaCPC generated PDF File");
      document.setPageSize(PageSize.LETTER);
      document.setHtmlStyleClass(this.ocr.getStyle());
      document.open();
      URL myWebPage = a.toURI().toURL();
      InputStreamReader fis = new InputStreamReader(myWebPage.openStream());
      HTMLWorker worker = new HTMLWorker((DocListener)document);
      worker.parse(fis);
      document.close();
      pdfWriter.close();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    } catch (DocumentException e) {
      e.printStackTrace();
    } 
  }
  
  public void captureTXT() {
    this.pdf.setEnabled(false);
    this.ishtml = false;
    if (!this.hastext) {
      this.oc.setLayout(new BorderLayout());
      this.oc.add(this.ar, "Center");
      try {
        this.ar.setFont(new Font("Courier NEW", 0, 13));
      } catch (Exception exception) {}
      this.ocr.initCombo();
      this.opts.setLayout(new FlowLayout());
      this.opts.add(this.dumpTXT);
      this.opts.add(this.dumpHTML);
      this.opts.add(this.saveDump);
      this.opts.add(this.pdf);
      this.opts.add(this.autoDump);
      this.opts.add(this.copyDump);
      this.opts.add(this.ocr.fontsize);
      this.dumpTXT.addActionListener(this);
      this.dumpHTML.addActionListener(this);
      this.saveDump.addActionListener(this);
      this.autoDump.addActionListener(this);
      this.copyDump.addActionListener(this);
      this.oc.add(this.opts, "South");
      this.ar.setEditable(false);
      this.ar.addKeyListener(this);
      this.ar.setFocusable(true);
      this.oc.setFocusable(false);
      this.oc.pack();
      this.oc.setVisible(true);
      this.oc.setAlwaysOnTop(true);
      this.hastext = true;
    } 
    if (!this.oc.isVisible())
      this.oc.setVisible(true); 
    this.pw = this.ocr.getW();
    this.ph = this.ocr.getH();
    this.pmode = GateArray.getSMode();
    switch (this.pmode) {
      case 0:
        this.ar.setPreferredSize(new Dimension(this.pw * 9, this.ph * 15));
        break;
      case 1:
        this.ar.setPreferredSize(new Dimension(this.pw * 9, this.ph * 15));
        break;
      case 2:
        this.ar.setPreferredSize(new Dimension(this.pw * 9, this.ph * 15));
        break;
    } 
    this.oc.pack();
    this.ar.setForeground(Color.black);
    this.ar.setBackground(Color.white);
    this.content = this.ocr.getScreen();
    this.ar.setContentType("text/plain");
    this.ar.setText(this.content);
  }
  
  public void stopMotor() {
    this.computer.stop();
  }
  
  public void startMotor() {
    this.computer.start();
  }
  
  public static boolean wantsna = false;
  
  public static String openAsASM = null;
  
  protected boolean loaddrive;
  
  protected static String fileName;
  
  selectDSK selDSK;
  
  boolean resetcpc;
  
  protected KeyTranslator translator;
  
  public void update() {
    if (openAsASM != null) {
      openASM(openAsASM);
      openAsASM = null;
    } 
    if (this.snaChooser != null) {
      if (this.snaChooser.isVisible() && this.computer.isRunning() && wantsna)
        stopComputer(); 
      if (!this.snaChooser.isVisible() && !this.computer.isRunning() && wantsna) {
        goComputer();
        this.computer.reSync();
        wantsna = false;
      } 
    } 
    if (this.checkupdate) {
      this.timeupdate++;
      if (this.timeupdate > 100) {
        this.checkupdate = false;
        try {
          UpdateCheck(true);
        } catch (Exception et) {
          et.printStackTrace();
        } 
      } 
    } 
    if (this.rickroller != 0) {
      this.rickroller++;
      if (this.rickroller > 30) {
        System.out.println("Someone wants a Rick Roll");
        this.rickroller = 0;
        try {
          GateArray.cpc.loadFile(1, "./IHaveBeenRickRolled/RickAstley.anz");
        } catch (Exception exception) {}
      } 
    } 
    if (iframe != null && !iframe.isVisible()) {
      this;
      if (!undocked)
        stopMotor(); 
    } 
    if (this.undocktick != 0) {
      this.undocktick--;
      if (this.undocktick == 1)
        this.undockpanel.setBorder(new LineBorder(Color.black, 10)); 
    } 
    if (toggledock) {
      toggledock = false;
      if (undocked) {
        redock();
      } else {
        undock();
      } 
    } 
    if (this.joyenabler < 50) {
      this.display.joyenabled = false;
      this.joyenabler++;
    } else if (this.joyenabler != 100) {
      this.joyenabler = 100;
      this.display.joyenabled = true;
    } 
    if (this.display.curvature != null && !this.haslistener) {
      DropListener myListener = new DropListener();
      registerDropListener(this.dropTargetList, this.display.curvature, myListener);
      this.haslistener = true;
    } 
    if (update3d) {
      if (this.display.curvature == null) {
        panel3d = new JPanel();
        panel3d.setLayout(new FlowLayout(1));
        panel3d.setBackground(Color.BLACK);
        panel3d.setDoubleBuffered(true);
        this.display.curvature = new CurvaturedScreen(this.display);
        System.out.println("curvature has " + this.display.curvature.getComponentCount() + " components");
        panel3d.add(this.display.curvature);
      } 
      EventQueue.invokeLater(new Runnable() {
            public void run() {
              if (Display.use3d) {
                JEMU.this.display.setVisible(false);
                JEMU.this.display.curvature.setVisible(true);
                JEMU.this.intern.remove(JEMU.this.display);
                JEMU.this.intern.add(JEMU.panel3d, "Center");
              } else {
                JEMU.this.display.setVisible(true);
                JEMU.this.display.curvature.setVisible(false);
                JEMU.this.intern.remove(JEMU.panel3d);
                JEMU.this.intern.add(JEMU.this.display, "Center");
              } 
            }
          });
      update3d = false;
    } 
    if (Display.use3d)
      EventQueue.invokeLater(new Runnable() {
            public void run() {
              try {
                if (!CurvaturedScreen.FullScreen) {
                  if ((JEMU.panel3d.getHeight() / JEMU.panel3d.getWidth()) < 1.33333333333D) {
                    if (JEMU.this.display.curvature.getHeight() != JEMU.panel3d.getHeight()) {
                      System.out.println("Resizing 3d screen to " + JEMU.this.getAspectWidth(JEMU.panel3d.getHeight()) + "," + JEMU.panel3d.getHeight());
                      JEMU.this.display.curvature.setPreferredSize(new Dimension(JEMU.this.getAspectWidth(JEMU.panel3d.getHeight()), JEMU.panel3d.getHeight()));
                      JEMU.this.display.curvature.setSize(new Dimension(JEMU.this.getAspectWidth(JEMU.panel3d.getHeight()), JEMU.panel3d.getHeight()));
                      JEMU.panel3d.repaint();
                    } 
                  } else if (JEMU.this.display.curvature.getWidth() != JEMU.panel3d.getWidth()) {
                    System.out.println("Resizing 3d screen to " + JEMU.panel3d.getWidth() + "," + JEMU.this.getAspectHeight(JEMU.panel3d.getWidth()));
                    JEMU.this.display.curvature.setPreferredSize(new Dimension(JEMU.panel3d.getWidth(), JEMU.this.getAspectHeight(JEMU.panel3d.getWidth())));
                    JEMU.this.display.curvature.setSize(new Dimension(JEMU.panel3d.getWidth(), JEMU.this.getAspectHeight(JEMU.panel3d.getWidth())));
                    JEMU.panel3d.repaint();
                  } 
                } else {
                  JEMU.this.display.curvature.resizeCanvas();
                } 
              } catch (Exception exception) {}
            }
          }); 
    if (Display.use3d && !this.has3dlisteners && this.display.curvature != null && this.display.curvature.isShowing()) {
      this.display.curvature.screen3D.addKeyListener(this);
      this.display.curvature.screen3D.addMouseListener(this);
      this.display.curvature.screen3D.addMouseMotionListener(this);
      this.display.curvature.screen3D.addFocusListener(this.display.curvature);
      System.out.println("*** added listeners to 3d panel");
      this.has3dlisteners = true;
    } 
    if (asmfile != null) {
      if (iframe != null) {
        Desktop.asmfile = asmfile;
      } else {
        openASM(asmfile);
      } 
      asmfile = null;
    } 
    if (makeassembler) {
      makeassembler = false;
      makeAssembler();
    } 
    if (this.joyControl.haveJoystick && this.display.joyenabled) {
      if (this.skipbutton && !setJoy1) {
        this.skipbutton = false;
        this.joyButton2 = 199;
        Settings.set("joystick_button_2", "199");
      } 
      if (this.joyButton1 == 100)
        this.joyButton1 = Settings.getInt("joystick_button_1", 200); 
      if (this.joyButton2 == 100)
        this.joyButton2 = Settings.getInt("joystick_button_1", 200); 
      if (this.joyButton1 != 200)
        setJoy1 = false; 
      if (this.joyButton2 != 200)
        setJoy2 = false; 
      if (setJoy1) {
        this.joyControl.poll();
        boolean[] buttons = this.joyControl.getButtons();
        for (int i = 0; i < buttons.length; i++) {
          if (buttons[i]) {
            this.joyButton1 = i;
            Settings.set("joystick_button_1", "" + i);
            setJoy1 = false;
            break;
          } 
        } 
      } else if (setJoy2) {
        this.joyControl.poll();
        boolean[] buttons = this.joyControl.getButtons();
        for (int i = 0; i < buttons.length; i++) {
          if (buttons[i] && i != this.joyButton1) {
            this.joyButton2 = i;
            Settings.set("joystick_button_2", "" + i);
            setJoy2 = false;
            return;
          } 
        } 
      } else {
        this.resetJoy++;
        if (this.resetJoy == 2) {
          this.resetJoy = 0;
          if (this.joyFire1) {
            this.joyFire1 = false;
            this.computer.keyReleased(101);
          } 
          if (this.joyFire2) {
            this.joyFire2 = false;
            this.computer.keyReleased(96);
          } 
          for (int j = 0; j < this.joyDir.length; j++) {
            if (this.joyDir[j])
              switch (j) {
                case 1:
                  this.computer.keyReleased(104);
                  this.joyDir[1] = false;
                  break;
                case 5:
                  this.computer.keyReleased(102);
                  this.joyDir[5] = false;
                  break;
                case 7:
                  this.computer.keyReleased(98);
                  this.joyDir[7] = false;
                  break;
                case 3:
                  this.computer.keyReleased(100);
                  this.joyDir[3] = false;
                  break;
                case 2:
                  this.computer.keyReleased(104);
                  this.computer.keyReleased(102);
                  this.joyDir[2] = false;
                  break;
                case 8:
                  this.computer.keyReleased(102);
                  this.computer.keyReleased(98);
                  this.joyDir[8] = false;
                  break;
                case 6:
                  this.computer.keyReleased(98);
                  this.computer.keyReleased(100);
                  this.joyDir[6] = false;
                  break;
                case 0:
                  this.computer.keyReleased(100);
                  this.computer.keyReleased(104);
                  this.joyDir[0] = false;
                  break;
              }  
          } 
        } 
        this.joyControl.poll();
        this.joyXY = this.joyControl.getXYStickDir();
        switch (this.joyXY) {
          case 1:
            if (!this.joyDir[1])
              this.computer.keyPressed(104); 
            this.joyDir[1] = true;
            break;
          case 5:
            if (!this.joyDir[5])
              this.computer.keyPressed(102); 
            this.joyDir[5] = true;
            break;
          case 7:
            if (!this.joyDir[7])
              this.computer.keyPressed(98); 
            this.joyDir[7] = true;
            break;
          case 3:
            if (!this.joyDir[3])
              this.computer.keyPressed(100); 
            this.joyDir[3] = true;
            break;
          case 2:
            if (!this.joyDir[2]) {
              this.computer.keyPressed(104);
              this.computer.keyPressed(102);
            } 
            this.joyDir[2] = true;
            break;
          case 8:
            if (!this.joyDir[8]) {
              this.computer.keyPressed(102);
              this.computer.keyPressed(98);
            } 
            this.joyDir[8] = true;
            break;
          case 6:
            if (!this.joyDir[6]) {
              this.computer.keyPressed(98);
              this.computer.keyPressed(100);
            } 
            this.joyDir[6] = true;
            break;
          case 0:
            if (!this.joyDir[0]) {
              this.computer.keyPressed(100);
              this.computer.keyPressed(104);
            } 
            this.joyDir[0] = true;
            break;
        } 
        boolean[] buttons = this.joyControl.getButtons();
        for (int i = 0; i < buttons.length; i++) {
          if (i == this.joyButton1 && buttons[i]) {
            if (!this.joyFire1)
              this.computer.keyPressed(101); 
            this.joyFire1 = true;
          } 
          if (i == this.joyButton2 && buttons[i]) {
            if (!this.joyFire2)
              this.computer.keyPressed(96); 
            this.joyFire2 = true;
          } 
        } 
      } 
    } 
    if (this.bascreen != 0) {
      this.bascreen++;
      if (this.bascreen > 2) {
        this.bascreen = 0;
        defaultSize();
      } 
    } 
    if (this.showStatus && this.display.getWidth() < 500 && this.stpanel.isVisible()) {
      this.stpanel.setVisible(false);
      checkDisplay();
    } else if (this.display.getWidth() >= 500 && this.showStatus && !this.stpanel.isVisible()) {
      this.stpanel.setVisible(this.showStatus);
      checkDisplay();
    } 
    if (iframe != null && this.taped.isVisible())
      this.taped.setVisible(false); 
    if (this.hideTape != 0) {
      this.hideTape++;
      if (this.hideTape == 60) {
        this.hideTape = 0;
        if (!this.tabb.isVisible()) {
          this.tabb.setVisible(true);
          this.recb.setVisible(false);
          this.playb.setVisible(false);
          this.rewb.setVisible(false);
          this.fwdb.setVisible(false);
          this.stopb.setVisible(false);
          this.pauseb.setVisible(false);
          this.stpanel.setVisible(true);
          this.cbZipChooser.setVisible(this.selector);
          this.ziplab.setVisible(this.selector);
          this.slomo.setVisible(!this.ziplab.isVisible());
          this.stpanel.slomo.setVisible(!this.ziplab.isVisible());
          this.langselect.setVisible(!this.ziplab.isVisible());
        } 
      } 
    } 
    if (this.langselect.getSelectedIndex() != this.sel) {
      switch (this.langselect.getSelectedIndex()) {
        case 0:
          localkeys = "EN_EN";
          if (!this.keys.equals("English keyboard  ")) {
            this.keys = "English keyboard  ";
            this.Keys.setLabel(this.keys);
            CPC.language = "en";
          } 
          break;
        case 1:
          localkeys = "DE_DE";
          if (!this.keys.equals("German keyboard  ")) {
            this.keys = "German keyboard  ";
            this.Keys.setLabel(this.keys);
            CPC.language = "de";
          } 
          break;
        case 2:
          localkeys = "ES_ES";
          if (!this.keys.equals("Spanish keyboard  ")) {
            this.keys = "Spanish keyboard  ";
            this.Keys.setLabel(this.keys);
            CPC.language = "es";
          } 
          break;
        case 3:
          localkeys = "FR_FR";
          if (!this.keys.equals("French keyboard  ")) {
            this.keys = "French keyboard  ";
            this.Keys.setLabel(this.keys);
            CPC.language = "fr";
          } 
          break;
        case 4:
          localkeys = "IT_IT";
          if (!this.keys.equals("Italian keyboard  ")) {
            this.keys = "Italian keyboard  ";
            this.Keys.setLabel(this.keys);
            CPC.language = "en";
          } 
          break;
        case 5:
          localkeys = "DA_DK";
          if (!this.keys.equals("Danish keyboard  ")) {
            this.keys = "Danish keyboard  ";
            this.Keys.setLabel(this.keys);
            CPC.language = "dk";
          } 
          break;
        case 6:
          localkeys = "SV_SE";
          if (!this.keys.equals("Swedish keyboard  ")) {
            this.keys = "Swedish keyboard  ";
            this.Keys.setLabel(this.keys);
            CPC.language = "en";
          } 
          break;
        case 7:
          localkeys = "NB_NO";
          if (!this.keys.equals("Norwegian keyboard  ")) {
            this.keys = "Norwegian keyboard  ";
            this.Keys.setLabel(this.keys);
            CPC.language = "dk";
          } 
          break;
      } 
      this.sel = this.langselect.getSelectedIndex();
      Settings.set("language", localkeys);
      localize();
    } 
    if (showdebug) {
      showdebug = false;
      showDebugger(false);
    } 
    if (resetpanel)
      resetTapePanel(); 
    if (CPC.download) {
      CPC.download = false;
      try {
        Switches.loaded = false;
        loadFile(0, CPC.downstring, false);
        GameBrowser.pane.setPage(CPC.Oldpage);
        this.display.requestFocus();
      } catch (Exception exception) {}
    } 
    if (forcehead != 0) {
      forcehead++;
      if (forcehead == 100) {
        setHeads();
        forcehead = 0;
      } 
    } 
    if (fire) {
      fire = false;
      this.computer.MouseFire1();
    } 
    if (prec) {
      this.computer.pressRec();
      prec = false;
    } 
    if (pplay) {
      this.computer.pressPlay();
      pplay = false;
    } 
    if (prew) {
      this.computer.pressRew();
      prew = false;
    } 
    if (pffw) {
      this.computer.pressFwd();
      pffw = false;
    } 
    if (pstop) {
      this.computer.pressStop();
      pstop = false;
    } 
    if (ppause) {
      this.computer.pressPause();
      ppause = false;
    } 
    if (bug) {
      bug = false;
      Thread BUG = new Thread() {
          public void run() {
            JEMU.this.reportBug();
          }
        };
      BUG.start();
    } 
    if (dinfo) {
      dinfo = false;
      showDevices();
    } 
    if (free) {
      simp = false;
      doub = false;
      trip = false;
      quad = false;
      free = false;
      setFreeSized(true);
    } else {
      if (simp) {
        simp = false;
        this.mousezoom = 1.0D;
        setSimpleSized();
      } 
      if (doub) {
        doub = false;
        this.mousezoom = 2.0D;
        setDoubleSized(true);
      } 
      if (trip) {
        trip = false;
        this.mousezoom = 3.0D;
        setTripleSized(true);
      } 
      if (quad) {
        quad = false;
        this.mousezoom = 4.0D;
        setQuadSized(true);
      } 
    } 
    if (ful) {
      ful = false;
      this.mousezoom = 2.0D;
      setFullSized(true);
    } 
    if (checksize != 0) {
      checksize++;
      if (checksize == 20) {
        setOutputSize();
        checksize = 0;
      } 
    } 
    if (ejecttape) {
      tapeEject();
      ejecttape = false;
    } 
    if (this.capthis != null)
      this.capthis.repaint(); 
    if (savesnap) {
      saveSNA();
      savesnap = false;
    } 
    if (loadsnap) {
      loadSNA();
      loadsnap = false;
    } 
    if (Desktop.loadtape) {
      loadTape(false);
      Desktop.loadtape = false;
    } 
    if (Desktop.savetape) {
      sT();
      Desktop.savetape = false;
    } 
    if (Desktop.convert) {
      cdt2wav();
      Desktop.convert = false;
    } 
    if (remBorder)
      remBorder = false; 
    if (ejectall) {
      ejectAll();
      ejectall = false;
    } 
    if (Desktop.ej0) {
      eject(0);
      Desktop.ej0 = false;
    } 
    if (Desktop.ej1) {
      eject(1);
      Desktop.ej1 = false;
    } 
    if (Desktop.ej2) {
      eject(2);
      Desktop.ej2 = false;
    } 
    if (Desktop.ej3) {
      eject(3);
      Desktop.ej3 = false;
    } 
    if (Desktop.ld0) {
      load(0);
      Desktop.ld0 = false;
    } 
    if (Desktop.ld1) {
      load(1);
      Desktop.ld1 = false;
    } 
    if (Desktop.ld2) {
      load(2);
      Desktop.ld2 = false;
    } 
    if (Desktop.ld3) {
      load(3);
      Desktop.ld3 = false;
    } 
    if (openp) {
      TextPrinter.MakeVisible();
      openp = false;
    } 
    if (doodlecount > 0) {
      doodlecount++;
      if (doodlecount == 160) {
        choosePaint(importscreen);
        doodlecount = 0;
      } 
    } 
    if (this.hidemenu > 0) {
      this.hidemenu++;
      if (this.hidemenu == 50) {
        this.showmenu = false;
        if (!Desktop.started && frame != null)
          frame.remove(JavaCPCMenu); 
        this.hidemenu = 0;
      } 
    } 
    if (this.isbackground != Display.scaneffect) {
      if (Display.scaneffect) {
        this.intern.setBackground(new Color(2236962));
      } else {
        this.intern.setBackground(new Color(0));
      } 
      this.isbackground = Display.scaneffect;
    } 
    if (this.executable && !fullscreen) {
      if (frame != null && (frame.getX() != screenXstored || frame.getY() != screenYstored)) {
        screenXstored = frame.getX();
        Settings.set("frame_xpos", "" + screenXstored);
        screenYstored = frame.getY();
        Settings.set("frame_ypos", "" + screenYstored);
      } 
      if (iframe != null && (iframe.getX() != screenXstored || iframe.getY() != screenYstored)) {
        screenXstored = iframe.getX();
        Settings.set("frame_xpos", "" + screenXstored);
        screenYstored = iframe.getY();
        Settings.set("frame_ypos", "" + screenYstored);
      } 
    } 
    if (this.executable && this.CPUspeed != Switches.turbo * 100 / GateArray.cpc.slomo) {
      this.CPUspeed = Switches.turbo * 100 / GateArray.cpc.slomo;
      StatusPanel.cpu.setText(this.CPUspeed + "%");
    } 
    if (doAutoopen > 0) {
      doAutoopen++;
      if (doAutoopen >= 3) {
        try {
          askDrive(Autoopen);
        } catch (Exception r) {
          r.printStackTrace();
        } 
        doAutoopen = 0;
      } 
    } 
    if (setRoms) {
      setRoms = false;
      updateRoms();
    } 
    if (!Desktop.started && this.keepDimension && this.executable && (this.display.getHeight() != this.displayheight || this.display.getWidth() != this.displaywidth))
      if (!Display.use3d)
        checkDisplay();  
    if (followCPU)
      try {
        debugger.updateDisplay();
      } catch (Exception exception) {} 
    if (this.tapeload) {
      this.tapeload = false;
      loadTape(false);
    } 
    if (this.QuitTimer >= 1)
      System.exit(0); 
    if (screenshottimer != 0) {
      screenshottimer++;
      if (screenshottimer == 150) {
        screenshot();
        screenshottimer = 0;
      } 
    } 
    if (screentimer != 0) {
      screentimer++;
      if (screentimer == 10) {
        screenshot();
        screentimer = 0;
      } 
    } 
    if (dsksavetimer != 0) {
      dsksavetimer++;
      if (dsksavetimer == 12)
        saveDsk(); 
    } 
    if (dskmaketimer != 0) {
      dskmaketimer++;
      if (dskmaketimer == 12)
        CreateDsk(0); 
    } 
    if (this.loadtimer != 0) {
      this.loadtimer++;
      if (this.loadtimer == 20) {
        loaddata();
        this.loadtimer = 0;
      } 
    } 
    if (this.loadprogtimer != 0) {
      this.loadprogtimer++;
      if (this.loadprogtimer == 200) {
        this.loadprogtimer = 0;
        this.computer.AutoType();
      } 
    } 
    if (this.simpletimer != 0) {
      this.simpletimer++;
      if (this.simpletimer == 2) {
        System.out.println("SimpleBoot active. Trying to boot " + this.DSKfile);
        loadFile(this.DSKfile + ".dsk");
        loadFile(this.DSKfile + ".zip");
        this.simpletimer = 0;
      } 
    } 
    autoLoad();
    if (pausetimer != 0) {
      pausetimer = 0;
      pauseComputer();
    } 
    if (unpausetimer != 0) {
      unpausetimer = 0;
      Display.showpause = 0;
      startComputer();
    } 
    if (this.autobooter != 0) {
      this.autobooter++;
      if (this.autobooter == 100)
        reset(); 
      if (this.autobooter >= 320) {
        this.autobooter = 0;
        Switches.booter = 1;
        autoBoot();
      } 
    } 
    if (this.dtimer == 1) {
      this.display.requestFocus();
      this.dtimer = 0;
    } 
  }
  
  public void autoBoot() {
    System.out.print("Trying to autoboot " + this.compsys);
    CPC.bootthis = true;
    Switches.booter = 0;
  }
  
  private void autoLoad() {
    if (autoloader == 1) {
      autoloader = 0;
      pauseComputer();
      loadFile(this.autostartProg);
      this.autostartProg = null;
      this.autoload = 4;
      goComputer();
    } else if (autoloader == 2) {
      autoloader = 0;
      pauseComputer();
      loadFile(this.autostartDisk);
      this.autostartDisk = null;
      this.autoload = 4;
      if (this.discb != null) {
        this.computer.setCurrentDrive(1);
        loadFile(this.discb);
        this.computer.setCurrentDrive(0);
      } 
      goComputer();
    } else if (this.autoload == 0) {
      this.autoload = 5;
      pauseComputer();
      LoadFiles();
      goComputer();
    } 
  }
  
  public void LoadFiles() {
    int numOfDrives = (this.computer.getFloppyDrives() == null) ? 0 : (this.computer.getFloppyDrives()).length;
    for (int i = 0; i < numOfDrives; i++) {
      fileName = Settings.get("file.drive" + Integer.toString(i), null);
      this.loaddrive = Settings.getBoolean("loaddrive" + Integer.toString(i), false);
      if (this.loaddrive == true && fileName != null) {
        System.out.println("auto load drive " + i + ": *" + fileName + "*");
        this.computer.setCurrentDrive(i);
        loadFile(1, fileName, false);
      } 
      this.computer.setCurrentDrive(0);
    } 
    fileName = Settings.get("file.tape", null);
    this.loaddrive = Settings.getBoolean("loadtape", false);
    if (this.loaddrive == true && fileName != null) {
      if (fileName.toLowerCase().endsWith("mp3"))
        fileName = "buffer.wav"; 
      System.out.println("auto load tape: *" + fileName + "*");
      loadFile(1, fileName, false);
    } 
  }
  
  public void CreateDsk(int drive) {
    if (this.executable && frame != null)
      frame.setAlwaysOnTop(false); 
    if (this.executable && frame != null)
      frame.setAlwaysOnTop(onTop); 
    if (Switches.FloppySound)
      this.flopsound = 1; 
    Switches.FloppySound = false;
    selectDSK(drive);
  }
  
  public void selectDSK(final int drive) {
    Thread vr = new Thread() {
        public void run() {
          if (JEMU.this.selDSK == null)
            JEMU.this.selDSK = new selectDSK(); 
          JEMU.this.selDSK.init();
          JEMU.this.selDSK.setAlwaysOnTop(true);
          JEMU.this.selDSK.setVisible(true);
          while (JEMU.this.selDSK.button == 0) {
            try {
              Thread.sleep(10L);
            } catch (Exception exception) {}
          } 
          if (JEMU.this.flopsound == 1)
            Switches.FloppySound = true; 
          JEMU.this.flopsound = 0;
          if (JEMU.this.selDSK.button == 1) {
            JEMU.this.eject(drive);
            byte[] buff = JEMU.this.selDSK.formatDSK();
            JEMU.this.saveDisk(buff, drive);
          } 
          if (JEMU.this.executable && JEMU.frame != null)
            JEMU.frame.setAlwaysOnTop(JEMU.onTop); 
        }
      };
    vr.start();
  }
  
  public void keyTyped(KeyEvent e) {}
  
  protected static boolean pckeyboard = false;
  
  CharViewer cv;
  
  JFrame cf;
  
  FOSPaint fosp;
  
  int zoom;
  
  boolean rec;
  
  CPCOCR ocr;
  
  JFrame oc;
  
  JEditorPane ar;
  
  boolean hastext;
  
  RasterPaint rpaint;
  
  Keys keylist;
  
  int checkgun;
  
  int guncolour;
  
  int gunX;
  
  int gunY;
  
  int releasegun;
  
  public void showFontEditor() {
    if (this.cf == null) {
      this.cf = new JFrame();
      this.cf.setLayout(new BorderLayout());
      this.cf.add(this.cv, "South");
      this.cv.update();
      this.cf.pack();
      this.cf.setResizable(false);
      Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
      this.cf.setLocation((d.width - (this.cf.getSize()).width) / 2, (d.height - (this.cf.getSize()).height) / 2);
    } 
    this.cf.setVisible(true);
  }
  
  public void startFOSPaint() {
    if (!this.fosp.isVisible())
      this.fosp.setVisible(true); 
    this.fosp.addWindowListener(new WindowListener() {
          public void windowDeactivated(WindowEvent e) {}
          
          public void windowActivated(WindowEvent e) {}
          
          public void windowDeiconified(WindowEvent e) {}
          
          public void windowIconified(WindowEvent e) {}
          
          public void windowClosed(WindowEvent e) {}
          
          public void windowClosing(WindowEvent e) {
            JEMU.this.computer.reset();
          }
          
          public void windowOpened(WindowEvent e) {}
        });
    this.fosp.init();
  }
  
  public void keyPressed(KeyEvent e) {
    if (e.getKeyCode() == 32 && this.ctrl && this.alt) {
      e.consume();
      return;
    } 
    if (e.getKeyCode() == 35 && !this.ctrl && !this.alt && this.shift) {
      e.consume();
      return;
    } 
    if (Display.overlay != null) {
      if (e.getKeyCode() == 105) {
        e.consume();
        return;
      } 
      if (e.getKeyCode() == 99) {
        e.consume();
        return;
      } 
      if (e.getKeyCode() == 106) {
        e.consume();
        return;
      } 
    } 
    if (e.getKeyCode() == 122 && this.alt) {
      showFontEditor();
      this.alt = false;
      return;
    } 
    if (Desktop.keycode != null)
      Desktop.keycode.setText("" + e.getKeyCode()); 
    if (this.translator == null)
      this.translator = new KeyTranslator(); 
    if (!Switches.blockKeyboard) {
      switch (localkeys) {
        case "FR_FR":
          if (!this.keys.equals("French keyboard  ")) {
            this.keys = "French keyboard  ";
            this.Keys.setLabel(this.keys);
          } 
          break;
        case "ES_ES":
          if (!this.keys.equals("Spanish keyboard  ")) {
            this.keys = "Spanish keyboard  ";
            this.Keys.setLabel(this.keys);
          } 
          break;
        case "DE_DE":
          if (!this.keys.equals("German keyboard  ")) {
            this.keys = "German keyboard  ";
            this.Keys.setLabel(this.keys);
          } 
          break;
        case "DA_DK":
          if (!this.keys.equals("Danish keyboard  ")) {
            this.keys = "Danish keyboard  ";
            this.Keys.setLabel(this.keys);
          } 
          break;
        case "SV_SE":
          if (!this.keys.equals("Swedish keyboard  ")) {
            this.keys = "Swedish keyboard  ";
            this.Keys.setLabel(this.keys);
          } 
          break;
        case "NB_NO":
          if (!this.keys.equals("Norwegian keyboard  ")) {
            this.keys = "Norwegian keyboard  ";
            this.Keys.setLabel(this.keys);
          } 
          break;
        default:
          if (!this.keys.equals("English keyboard  ")) {
            this.keys = "English keyboard  ";
            this.Keys.setLabel(this.keys);
          } 
          break;
      } 
      if (e.getKeyCode() == 155) {
        e.consume();
        e.setKeyCode(12);
      } 
      if (e.getKeyCode() == 17)
        this.ctrl = true; 
      if (e.getKeyCode() == 16)
        this.shift = true; 
      if (e.getKeyCode() == 18)
        this.alt = true; 
      if (e.getKeyCode() == 77 && this.ctrl && this.shift) {
        if (this.mousejoy) {
          Switches.MouseJoy = false;
          Settings.setBoolean("mousejoy", false);
          this.mousejoy = false;
        } else {
          Switches.MouseJoy = true;
          Settings.setBoolean("mousejoy", true);
          this.mousejoy = true;
        } 
        this.joymouse.setState(this.mousejoy);
        System.out.println("Mouse joystick is " + this.mousejoy);
        return;
      } 
      if (e.getKeyCode() == 34) {
        for (int i = 0; i < 4; i++) {
          this.computer.setCurrentDrive(i);
          mediumeject();
        } 
        this.computer.setCurrentDrive(0);
        if (CPC.tapeloaded)
          this.computer.tapeEject(); 
      } 
      if (e.getKeyCode() == 33)
        askDrive(); 
      if (e.getKeyCode() == 145)
        autosavecheck(); 
      if (e.getKeyCode() == 19)
        pausecheck(); 
      if (e.getKeyCode() == 120 && this.ctrl) {
        this.ctrl = false;
        if (this.shift) {
          this.shift = false;
          reset();
        } else {
          this.resetcpc = true;
          e.setKeyCode(17);
          this.computer.processKeyEvent(e);
          e.setKeyCode(16);
          this.computer.processKeyEvent(e);
          e.setKeyCode(27);
          this.computer.processKeyEvent(e);
        } 
        return;
      } 
      if (e.getKeyCode() == 112) {
        if (this.ctrl && !this.shift) {
          SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                  JEMU.this.load(0);
                }
              });
          return;
        } 
        if (this.shift) {
          this.shift = false;
          CPC.inspectA = true;
          return;
        } 
      } 
      if (e.getKeyCode() == 113) {
        if (this.ctrl && !this.shift) {
          this.ctrl = false;
          SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                  JEMU.this.load(1);
                }
              });
          return;
        } 
        if (this.shift) {
          this.shift = false;
          CPC.inspectB = true;
          return;
        } 
      } 
      if (e.getKeyCode() == 114 && this.ctrl) {
        this.ctrl = false;
        SwingUtilities.invokeLater(new Runnable() {
              public void run() {
                JEMU.this.loadTape(false);
              }
            });
        return;
      } 
      if (e.getKeyCode() == 117 && this.shift) {
        SwingUtilities.invokeLater(new Runnable() {
              public void run() {
                JEMU.this.saveSNA();
              }
            });
        return;
      } 
      if (e.getKeyCode() == 27 && this.dialogsnap) {
        this.snaChooser.dispose();
        this.computer.start();
        this.computer.reSync();
        this.dialogsnap = false;
        return;
      } 
      if (e.getKeyCode() == 122) {
        if (this.ctrl) {
          this.ctrl = false;
          SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                  JEMU.this.screenshot();
                }
              });
          return;
        } 
        if (this.shift) {
          this.shift = false;
          captureTXT();
        } else {
          Autotype.PasteText();
          return;
        } 
      } 
      if (e.getKeyCode() == 107) {
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(false); 
        GateArray.cpc.savePNGDisk();
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(onTop); 
      } 
      if (e.getKeyCode() == 121 && this.ctrl) {
        this.ctrl = false;
        open(Desktop._VIDEO);
        return;
      } 
      if (e.getKeyCode() == 118 && this.ctrl) {
        this.ctrl = false;
        this.computer.storeState();
        return;
      } 
      if (e.getKeyCode() == 119 && this.ctrl) {
        this.ctrl = false;
        this.computer.restoreState();
        return;
      } 
      if (e.getKeyCode() == 99 && this.KeyRec && this.ctrl) {
        this.ctrl = false;
        System.out.println("keyboard input playing...");
        this.computer.stopKeys();
        this.computer.playKeys();
        return;
      } 
      if (e.getKeyCode() == 115) {
        if (this.ctrl && this.shift) {
          this.ctrl = false;
          this.shift = false;
          turboCheck();
          return;
        } 
        if (this.ctrl && !this.shift) {
          this.ctrl = false;
          loadTape(true);
          return;
        } 
      } 
      if (e.getKeyCode() == 116 && this.ctrl && !this.shift) {
        if (!CPC.tapedeck) {
          GateArray.cpc.TapeDrive.setVisible(true);
          CPC.tapedeck = true;
        } else {
          GateArray.cpc.TapeDrive.setVisible(false);
          CPC.tapedeck = false;
        } 
        this.ctrl = false;
        return;
      } 
      if (e.getKeyCode() == 123) {
        if (this.ctrl && this.shift) {
          this.ctrl = false;
          this.shift = false;
          this.statusbar.setState(!this.statusbar.getState());
          this.showStatus = this.statusbar.getState();
          Settings.setBoolean("status_bar", this.showStatus);
          this.statpan.setVisible(this.showStatus);
          if (this.executable) {
            if (iframe != null)
              iframe.pack(); 
            if (frame != null)
              frame.pack(); 
          } 
          return;
        } 
        if (this.ctrl) {
          this.ctrl = false;
          MenuCheck();
          return;
        } 
      } 
      if (e.getKeyCode() == 35 && this.alt) {
        this.alt = false;
        this.computer.bootDisk();
        return;
      } 
      if (this.executable) {
        if (iframe == null && e.getKeyCode() == 10 && this.alt) {
          this.alt = false;
          if (!Display.use3d) {
            FullSize();
          } else {
            this.display.curvature.toggleFullScreen();
          } 
          this.computer.processKeyEvent(e);
          return;
        } 
        if (iframe != null && e.getKeyCode() == 10 && this.alt) {
          this.alt = false;
          if (!Display.use3d) {
            if (this.fulldesktop) {
              setWindowed();
            } else {
              setFullScreen();
            } 
          } else {
            this.display.curvature.toggleFullScreen();
          } 
          this.computer.processKeyEvent(e);
          return;
        } 
        if (e.getKeyCode() == 10 && this.ctrl)
          if (CurvaturedScreen.FullScreen) {
            this.display.curvature.toggleZoom();
            this.ctrl = false;
            this.computer.processKeyEvent(e);
            return;
          }  
      } 
      if (localkeys.equals("DE_DE") && pckeyboard) {
        PCKeyBoard.keyHandle(e, this.computer, true);
        return;
      } 
      e = this.translator.translate(e, localkeys);
      this.computer.processKeyEvent(e);
    } 
  }
  
  protected void openRasterPaint() {
    if (Desktop.isDesktop) {
      Desktop.openraster = 1;
    } else {
      if (this.rpaint == null)
        this.rpaint = new RasterPaint(); 
      this.rpaint.setVisible(true);
      this.rpaint.init();
    } 
  }
  
  public void keyReleased(KeyEvent e) {
    if (e.getKeyCode() == 32 && this.ctrl && this.alt) {
      String disk = GateArray.cpc.getDrive0Name();
      if (disk == null) {
        disk = "./";
      } else {
        if (disk.contains("\\"))
          disk = disk.replace("\\", "/"); 
        if (disk.contains("/"))
          while (!disk.endsWith("/"))
            disk = disk.substring(0, disk.length() - 1);  
        Calendar cal = Calendar.getInstance();
        String fil = cal.getTimeInMillis() + "";
        disk = disk + fil;
      } 
      GateArray.cpc.SNA_Save(4096, disk);
      this.shift = false;
      this.ctrl = false;
      this.alt = false;
      e.consume();
      return;
    } 
    if (e.getKeyCode() == 35 && !this.ctrl && !this.alt && this.shift) {
      Display.LoadOverlay();
      this.shift = false;
      e.consume();
      return;
    } 
    if (Display.overlay != null) {
      if (e.getKeyCode() == 105) {
        Display.IncTrans();
        e.consume();
        return;
      } 
      if (e.getKeyCode() == 99) {
        Display.DecTrans();
        e.consume();
        return;
      } 
      if (e.getKeyCode() == 106) {
        Display.ToggleOver();
        e.consume();
        return;
      } 
    } 
    if (e.getKeyCode() == 122)
      return; 
    if (setJoy2 && e.getKeyCode() == 27 && !setJoy1)
      this.skipbutton = true; 
    if (e.getKeyCode() == 77 && this.ctrl && this.shift)
      return; 
    if (this.resetcpc) {
      e.setKeyCode(17);
      this.computer.processKeyEvent(e);
      e.setKeyCode(16);
      this.computer.processKeyEvent(e);
      e.setKeyCode(27);
      this.computer.processKeyEvent(e);
      this.resetcpc = false;
      return;
    } 
    if (this.executable) {
      if (e.getKeyCode() == 106)
        this.computer.DSK2MFM(); 
      if (e.getKeyCode() == 109);
    } 
    if (e.getKeyCode() == 155) {
      e.consume();
      e.setKeyCode(12);
    } 
    if (this.translator == null)
      this.translator = new KeyTranslator(); 
    if (e.getKeyCode() == 17)
      this.ctrl = false; 
    if (e.getKeyCode() == 18)
      this.alt = false; 
    if (e.getKeyCode() == 16)
      this.shift = false; 
    if (localkeys.equals("DE_DE") && pckeyboard) {
      PCKeyBoard.keyHandle(e, this.computer, false);
      return;
    } 
    e = this.translator.translate(e, localkeys);
    this.computer.processKeyEvent(e);
  }
  
  public void MenuCheck() {
    if (this.executable) {
      if (this.showmenu) {
        this.showmenu = false;
        if (!Desktop.started && frame != null)
          frame.remove(JavaCPCMenu); 
        Settings.setBoolean("show_menu", false);
      } else {
        this.showmenu = true;
        if (!Desktop.started && frame != null)
          frame.setMenuBar(JavaCPCMenu); 
        Settings.setBoolean("show_menu", true);
      } 
      if (iframe != null)
        iframe.pack(); 
      if (frame != null)
        frame.pack(); 
      this.display.requestFocus();
    } 
  }
  
  public void mouseClicked(MouseEvent e) {
    if (SF2Mouse) {
      int i = e.getButton();
      GateArray.cpc.writeMouseButton(i);
    } 
    if (!Switches.lightGun) {
      Desktop.tofront = true;
      if (e.getClickCount() == 2)
        if (this.undockframe != null && this.undockframe.isVisible())
          redock();  
    } 
  }
  
  public void mousePressed(MouseEvent e) {
    if (this.undockframe != null && this.undockframe.isVisible()) {
      if (e.getX() > this.undockframe.getWidth() - 20 && e.getY() < 10)
        redock(); 
      point.x = e.getX();
      point.y = e.getY();
      this.dwidth = this.undockframe.getWidth();
      this.dheight = this.undockframe.getHeight();
    } 
    if (this.mousejoy) {
      if ((e.getModifiers() & 0x10) != 0) {
        this.computer.MouseFire1();
      } else {
        this.computer.MouseFire2();
      } 
      return;
    } 
    if (Switches.lightGun && this.checkgun == 0) {
      if ((e.getModifiers() & 0x10) != 0)
        this.computer.lightShot(e.getX(), e.getY()); 
      return;
    } 
    this.display.requestFocus();
    Desktop.tofront = true;
  }
  
  public void pressGun() {
    this.releasegun = 1;
    this.computer.lightgunShot();
  }
  
  public void releaseGun() {
    this.computer.lightgunRelease();
  }
  
  public void mouseReleased(MouseEvent e) {
    if (SF2Mouse) {
      int i = e.getButton();
      GateArray.cpc.releaseMouseButton(i);
    } 
    if (this.mousejoy) {
      if ((e.getModifiers() & 0x10) != 0) {
        this.computer.MouseReleaseFire1();
      } else {
        this.computer.MouseReleaseFire2();
      } 
      return;
    } 
    if (Switches.lightGun)
      return; 
    Desktop.tofront = true;
  }
  
  public void mouseEntered(MouseEvent e) {}
  
  public void mouseExited(MouseEvent e) {}
  
  public static boolean showdebug = true;
  
  JTabbedPane tabss;
  
  boolean undockedPeriphery;
  
  JFrame Peri;
  
  protected JFrame dskut;
  
  DSKUtil dsku;
  
  SamDisk samdisk;
  
  JFrame capframe;
  
  JFrame ymframe;
  
  public static GameMapper mapper;
  
  public static boolean ledOn;
  
  int bascreen;
  
  Frame onlinemenu;
  
  protected boolean showmenu;
  
  public void componentHidden(ComponentEvent evt) {
    this.computer.start();
  }
  
  public void componentShown(ComponentEvent evt) {}
  
  public void componentMoved(ComponentEvent evt) {}
  
  public void componentResized(ComponentEvent evt) {}
  
  public void showMultiMem(int address) {
    MultiMem multiMem = new MultiMem(this.computer, address);
    multiMem.setDefaultCloseOperation(1);
    multiMem.setVisible(true);
  }
  
  public void undockPeriphery() {
    if (this.Peri == null) {
      this.Peri = new JFrame("Periphery");
      this.Peri.setLayout(new BorderLayout());
      this.Peri.setDefaultCloseOperation(1);
    } 
    if (this.undockedPeriphery);
  }
  
  public void showDebugger(boolean stop) {
    if (iframe == null) {
      try {
        if (debugger == null) {
          debugger = (Debugger)Util.secureConstructor(Debugger.class, new Class[0], new Object[0]);
          debugger.setBounds(0, 0, 750, 480);
          debugger.setPreferredSize(new Dimension(750, 480));
          debugger.setComputer(this.computer);
        } 
        if (debugframe == null) {
          debugframe = new JFrame("Debugger");
          debugframe.setLayout(new BorderLayout());
          this.tabss.setFocusable(false);
          this.tabss.addTab("Debugger", debugger.getContentPane());
          GateArray.cpc.bas = new Basic();
          this.tabss.addTab("Basic Debugger", GateArray.cpc.bas.getContentPane());
          this.tabss.addTab("Periphery", desktop.periphery);
          this.tabss.setBounds(0, 0, 750, 520);
          this.tabss.setPreferredSize(new Dimension(750, 520));
          this.tabss.setTabPlacement(3);
          debugframe.add(this.tabss, "Center");
          debugframe.pack();
          debugframe.addComponentListener(this);
          debugger.setFocusable(false);
        } 
      } catch (Exception e) {
        e.printStackTrace();
      } 
      System.out.println("Starting debugger " + (stop ? "visible" : "hidden"));
      desktop.setRegisters();
      debugframe.setVisible(stop);
      debugframe.toFront();
      if (stop)
        this.computer.stop(); 
    } else if (stop) {
      Desktop.debugger = true;
      Desktop.debug.setVisible(true);
      debugger.computer.stop();
    } 
  }
  
  public Computer getComputer() {
    return this.computer;
  }
  
  public String loadFile(String name) {
    Switches.loaded = false;
    return loadFile(1, name, true);
  }
  
  public String loadFile(int type, String name, boolean usePath) {
    if ((name.toLowerCase().endsWith("mp3") || name.toLowerCase().endsWith("csw") || name.toLowerCase().endsWith("cdt") || name.toLowerCase().endsWith("tzx") || name.toLowerCase().endsWith("wav")) && !name.toLowerCase().equals("buffer.wav"))
      this.computer.setInfo(name, true); 
    if (name.startsWith("http") && this.useURL)
      usePath = false; 
    Switches.loaded = false;
    String result = null;
    try {
      boolean running = this.computer.isRunning();
      isTape = false;
      this.computer.stop();
      try {
        fileName = (usePath ? this.computer.getFilePath() : "") + name;
        if (name.toString().toUpperCase().endsWith(".WAV") || name.toString().toUpperCase().endsWith(".JTP") || name.toString().toUpperCase().endsWith(".TAP")) {
          isTape = true;
        } else {
          isTape = false;
        } 
        if (name.toString().toUpperCase().endsWith(".YM"))
          fileName = "" + name; 
        try {
          this.computer.loadFile(type, fileName);
        } catch (Exception exception) {}
        result = this.computer.getFileInfo(name);
        Switches.loadname = name;
        if (Switches.booter == 0)
          if (!isTape) {
            Settings.set("file.drive" + Integer.toString(this.computer.getCurrentDrive()), fileName);
            Settings.setBoolean("loaddrive" + Integer.toString(this.computer.getCurrentDrive()), true);
            Desktop.checkdrives = true;
          } else {
            Settings.set("file.tape", fileName);
            Settings.setBoolean("loadtape", true);
          }  
      } finally {
        this.display.requestFocus();
        this.computer.start();
      } 
    } catch (Exception exception) {}
    if (name.toLowerCase().endsWith(".zip") || name.toLowerCase().endsWith(".dskz") || name.toLowerCase().endsWith(".cdtz") || name.toLowerCase().endsWith(".cswz") || name.toLowerCase().endsWith(".snaz"))
      buildSelector(name); 
    return result;
  }
  
  public void resetComputer() {
    this.computer.reset();
    Display.showpause = 0;
    this.computer.start();
    this.computer.reset();
    Display.showpause = 0;
    this.computer.start();
  }
  
  public void rebootComputer() {
    this.computer.reset();
    Display.showpause = 0;
    this.computer.start();
    reBoot();
  }
  
  public void ejectComputer() {
    this.computer.eject();
  }
  
  public void goComputer() {
    Display.showpause = 0;
    this.computer.start();
  }
  
  public void stopComputer() {
    Display.showpause = 4;
    pausetimer = 1;
  }
  
  public static void sComputer() {
    Display.showpause = 4;
    pausetimer = 1;
  }
  
  public void pauseComputer() {
    this.computer.stop();
  }
  
  public void fsoundcheck() {
    if (!this.fsound) {
      Switches.FloppySound = true;
      Settings.setBoolean("floppy_sound", true);
      System.out.println("Drive mechanic noise enabled");
      this.fsound = true;
    } else {
      Switches.FloppySound = false;
      Settings.setBoolean("floppy_sound", false);
      System.out.println("Drive mechanic noise disabled");
      this.fsound = false;
    } 
  }
  
  public void nbcheck() {
    if (!this.notebook) {
      Switches.notebook = true;
      Settings.setBoolean("notebook", true);
      System.out.println("Notebook Enabled");
      System.out.println("Q, A, O, P = Direction-control, SPACE, CTRL = Firebutton 1,2");
      this.notebook = true;
    } else {
      Switches.notebook = false;
      Settings.setBoolean("notebook", false);
      System.out.println("Notebook Disabled");
      this.notebook = false;
    } 
  }
  
  public void pausecheck() {
    if (paused == 0) {
      paused = 1;
      stopComputer();
      if (this.display != null)
        try {
          this.display.update(this.display.getGraphics());
        } catch (Exception exception) {} 
      System.out.println("System halted");
    } else {
      paused = 0;
      goComputer();
      System.out.println("System started");
    } 
  }
  
  public void joycheck() {
    if (Switches.joystick == 1) {
      Switches.joystick = 0;
      Settings.setBoolean("joystick", false);
      System.out.println("Joystick emulation disabled");
    } else {
      Switches.joystick = 1;
      Settings.setBoolean("joystick", true);
      System.out.println("Joystick emulation enabled\nuse seperate number-block with NUM-Lock on\n4, 8, 6, 2 - directions, 5, 0 - fire-buttons");
    } 
  }
  
  public void audiocheck() {
    if (Switches.audioenabler == 0) {
      Switches.audioenabler = 1;
      System.out.println("Audio Enabled");
      Settings.setBoolean("audio", true);
      this.display.requestFocus();
    } else if (Switches.audioenabler == 1) {
      Switches.audioenabler = 0;
      System.out.println("Audio Disabled");
      Settings.setBoolean("audio", false);
      this.display.requestFocus();
    } 
  }
  
  public void dskmerge() {
    CPCDiscImageMerger.merge();
  }
  
  public void autosavecheck() {
    if (this.autosave) {
      System.out.println("Autosave Disabled");
      Settings.setBoolean("autosave", false);
      this.autosave = false;
      Switches.autosave = false;
    } else {
      System.out.println("Autosave Enabled");
      Settings.setBoolean("autosave", true);
      this.autosave = true;
      Switches.autosave = true;
    } 
  }
  
  public void alwaysOnTopCheck() {
    if (Switches.top == 0) {
      Switches.top = 1;
      Settings.setBoolean("on_top", true);
      if (this.executable && frame != null)
        frame.setAlwaysOnTop(true); 
    } else {
      Switches.top = 0;
      if (this.executable && frame != null)
        frame.setAlwaysOnTop(false); 
    } 
  }
  
  public void autobootcheck() {
    this.autobooter = 1;
  }
  
  public void reset() {
    this.computer.reset();
    this.display.requestFocus();
  }
  
  public void mediumeject() {
    this.computer.eject();
    this.display.requestFocus();
    Settings.set("file.drive" + Integer.toString(this.computer.getCurrentDrive()), "empty");
    Settings.setBoolean("loaddrive" + Integer.toString(this.computer.getCurrentDrive()), false);
    Desktop.checkdrives = true;
  }
  
  public void tapeEject() {
    this.computer.tapeEject();
    Desktop.checkdrives = true;
    CPC.tapeloaded = false;
    Settings.set("file.tape", "~none~");
    Settings.setBoolean("loadtape", false);
  }
  
  public void setComputer(String name) throws Exception {
    if (name.toLowerCase().equals("kccompact")) {
      Switches.computername = Util.hexValue("7");
    } else {
      Switches.computername = Util.hexValue(Settings.get("computername", "7"));
    } 
    GateArray.cpc.checkSave();
    for (int i = 0; i < 500; i++) {
      try {
        Thread.activeCount();
      } catch (Exception exception) {}
    } 
    if (Switches.FloppySound)
      Samples.DEGAUSS.play(); 
    Switches.loaddrivea = "Drive is empty.";
    Switches.loaddriveb = "Drive is empty.";
    Switches.loaddrivec = "Drive is empty.";
    Switches.loaddrived = "Drive is empty.";
    System.out.println(name + " choosen.");
    setComputer(name, true);
    this.compsys = name;
  }
  
  public void setComputer(String name, boolean start) throws Exception {
    try {
      this.compsys = name;
      if (this.computer != null) {
        Drive[] arrayOfDrive = this.computer.getFloppyDrives();
        if (arrayOfDrive != null)
          for (int i = 0; i < arrayOfDrive.length; i++) {
            if (arrayOfDrive[i] != null)
              arrayOfDrive[i].setActiveListener(null); 
          }  
        this.computer.dispose();
        this.computer = null;
        Runtime runtime = Runtime.getRuntime();
        runtime.gc();
        runtime.runFinalization();
        runtime.gc();
        System.out.println("Computer Disposed");
      } 
      this.computer = Computer.createComputer(this, name);
      Settings.set("system", name);
      setFullSize(large);
      this.computer.initialise();
      Drive[] floppies = this.computer.getFloppyDrives();
      if (floppies != null)
        for (int i = 0; i < floppies.length; i++) {
          if (floppies[i] != null)
            floppies[i].setActiveListener(this); 
        }  
      this.gotGames = false;
      if (debugger != null)
        debugger.setComputer(this.computer); 
      if (start)
        this.computer.start(); 
      showDevices();
    } catch (Exception p) {
      p.printStackTrace();
    } 
  }
  
  public void setAudio(boolean value) {
    this.audiooutput = value;
    if (this.audiooutput) {
      Switches.audioenabler = 1;
    } else {
      Switches.audioenabler = 0;
    } 
    this.display.requestFocus();
  }
  
  public void turboCheck() {
    if (Switches.turbo == 1) {
      Switches.turbo = 4;
      turbo.setState(true);
      Desktop.jCheckBox8.setSelected(true);
    } else {
      Switches.turbo = 1;
      Desktop.jCheckBox8.setSelected(false);
      turbo.setState(false);
    } 
    this.computer.reSync();
  }
  
  public void setTurbo(boolean value) {
    boolean turbocheck = value;
    if (turbocheck) {
      Switches.turbo = 4;
      turbo.setState(true);
      Desktop.jCheckBox8.setSelected(true);
    } else {
      Switches.turbo = 1;
      turbo.setState(false);
      Desktop.jCheckBox8.setSelected(false);
    } 
    this.display.requestFocus();
    this.computer.reSync();
  }
  
  public void setFloppy(boolean value) {
    this.floppyoutput = value;
    if (this.floppyoutput) {
      Switches.FloppySound = true;
    } else {
      Switches.FloppySound = false;
    } 
    this.display.requestFocus();
  }
  
  public void setJoy(boolean value) {
    this.altjoystick = value;
    if (this.altjoystick) {
      Switches.notebook = true;
    } else {
      Switches.notebook = false;
    } 
    this.display.requestFocus();
  }
  
  public void showAutotype() {
    Autotype.typeconsole.setVisible(true);
  }
  
  public void setFullSize(boolean value) {
    large = value;
    if (large) {
      if (this.skinned) {
        this.Moniup.setVisible(false);
        this.Monidown.setVisible(false);
        this.Monileft.setVisible(false);
        this.Moniright.setVisible(false);
      } 
    } else if (this.skinned) {
      this.Moniup.setVisible(true);
      this.Monidown.setVisible(true);
      this.Monileft.setVisible(true);
      this.Moniright.setVisible(true);
    } 
    boolean running = this.computer.isRunning();
    this.computer.stop();
    this.computer.setLarge(large);
    this.display.setImageSize(this.computer.getDisplaySize(large), this.computer.getDisplayScale(large));
    this.computer.setDisplay(this.display);
    this.computer.start();
    this.display.requestFocus();
    setOutputSize();
    this.computer.reSync();
  }
  
  public void insertDisk() {
    this.loadtimer = 1;
  }
  
  public void checkDSKUtil() {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            if (Desktop.isDesktop) {
              Desktop.checkDSKUtil();
            } else {
              if (JEMU.this.dsku == null) {
                JEMU.this.dsku = new DSKUtil();
                JEMU.this.dskut = new JFrame("DSKUtil");
                JEMU.this.dskut.setLayout(new BorderLayout());
                JEMU.this.dskut.add(JEMU.this.dsku.disktools);
                JEMU.this.dskut.pack();
                JEMU.this.dskut.setDefaultCloseOperation(1);
              } 
              JEMU.this.dskut.setVisible(true);
            } 
          }
        });
  }
  
  public Window findWindow(Component comp) {
    while (comp != null) {
      if (comp instanceof Window)
        return (Window)comp; 
      comp = comp.getParent();
    } 
    return null;
  }
  
  public Vector getFiles() {
    Vector<FileDescriptor> files = (this.computer == null) ? new Vector() : this.computer.getFiles();
    Vector<String> result = (files.size() == 0) ? files : new Vector(files.size() * 2);
    for (int i = 0; i < files.size(); i++) {
      FileDescriptor file = files.elementAt(i);
      result.addElement(file.description);
      result.addElement(file.filename);
    } 
    return result;
  }
  
  public Vector getDrives() {
    int floppydrives = (this.computer == null || this.computer.getFloppyDrives() == null) ? 0 : (this.computer.getFloppyDrives()).length;
    Vector<String> result = (floppydrives == 0) ? new Vector() : new Vector(floppydrives);
    for (int i = 0; i < floppydrives; i++)
      result.addElement(new String("DF" + i + ":")); 
    return result;
  }
  
  public void focusLost(FocusEvent e) {
    this.computer.displayLostFocus();
  }
  
  public void focusGained(FocusEvent e) {}
  
  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == this.dumpHTML)
      captureHTML(); 
    if (e.getSource() == this.dumpTXT)
      captureTXT(); 
    if (e.getSource() == this.saveDump)
      saveContent(this.ishtml); 
    if (e.getSource() == this.copyDump) {
      System.out.println("Copying dump...");
      this.ar.selectAll();
      this.ar.copy();
    } 
    if (e.getSource() == this.autoDump)
      if (this.doAscii.isRunning()) {
        this.doAscii.stop();
        this.autoDump.setText("Auto");
      } else {
        this.doAscii.start();
        this.autoDump.setText("Stop");
      }  
    if (e.getSource() == this.cbZipChooser)
      try {
        System.out.println("Loading file:" + this.computer.disknames[this.cbZipChooser.getSelectedIndex()]);
        this.display.zipinfo = this.computer.disknames[this.cbZipChooser.getSelectedIndex()];
        this.display.zipcount = 200;
        this.computer.loadEntry(this.cbZipChooser.getSelectedIndex(), getDrive());
      } catch (Exception exception) {} 
    if (e.getSource() == this.recb)
      this.computer.pressRec(); 
    if (e.getSource() == this.playb)
      this.computer.pressPlay(); 
    if (e.getSource() == this.rewb)
      this.computer.pressRew(); 
    if (e.getSource() == this.fwdb)
      this.computer.pressFwd(); 
    if (e.getSource() == this.stopb)
      this.computer.pressStop(); 
    if (e.getSource() == this.pauseb)
      this.computer.pressPause(); 
    if (e.getSource() == this.KeepA) {
      this.KeepA.setBackground(Color.GREEN);
      this.KeepB.setBackground(Color.LIGHT_GRAY);
      this.KeepC.setBackground(Color.LIGHT_GRAY);
      this.KeepD.setBackground(Color.LIGHT_GRAY);
      this.KeepE.setBackground(Color.LIGHT_GRAY);
      this.KeepF.setBackground(Color.LIGHT_GRAY);
      this.computer.setCurrentDrive(0);
      mediumeject();
      loadFile(this.keepA);
    } 
    if (e.getSource() == this.KeepB) {
      this.KeepA.setBackground(Color.LIGHT_GRAY);
      this.KeepB.setBackground(Color.GREEN);
      this.KeepC.setBackground(Color.LIGHT_GRAY);
      this.KeepD.setBackground(Color.LIGHT_GRAY);
      this.KeepE.setBackground(Color.LIGHT_GRAY);
      this.KeepF.setBackground(Color.LIGHT_GRAY);
      this.computer.setCurrentDrive(0);
      mediumeject();
      loadFile(this.keepB);
    } 
    if (e.getSource() == this.KeepC) {
      this.KeepA.setBackground(Color.LIGHT_GRAY);
      this.KeepB.setBackground(Color.LIGHT_GRAY);
      this.KeepC.setBackground(Color.GREEN);
      this.KeepD.setBackground(Color.LIGHT_GRAY);
      this.KeepE.setBackground(Color.LIGHT_GRAY);
      this.KeepF.setBackground(Color.LIGHT_GRAY);
      this.computer.setCurrentDrive(0);
      mediumeject();
      loadFile(this.keepC);
    } 
    if (e.getSource() == this.KeepD) {
      this.KeepA.setBackground(Color.LIGHT_GRAY);
      this.KeepB.setBackground(Color.LIGHT_GRAY);
      this.KeepC.setBackground(Color.LIGHT_GRAY);
      this.KeepD.setBackground(Color.GREEN);
      this.KeepE.setBackground(Color.LIGHT_GRAY);
      this.KeepF.setBackground(Color.LIGHT_GRAY);
      this.computer.setCurrentDrive(0);
      mediumeject();
      loadFile(this.keepD);
    } 
    if (e.getSource() == this.KeepE) {
      this.KeepA.setBackground(Color.LIGHT_GRAY);
      this.KeepB.setBackground(Color.LIGHT_GRAY);
      this.KeepC.setBackground(Color.LIGHT_GRAY);
      this.KeepD.setBackground(Color.LIGHT_GRAY);
      this.KeepE.setBackground(Color.GREEN);
      this.KeepF.setBackground(Color.LIGHT_GRAY);
      this.computer.setCurrentDrive(0);
      mediumeject();
      loadFile(this.keepE);
    } 
    if (e.getSource() == this.KeepF) {
      this.KeepA.setBackground(Color.LIGHT_GRAY);
      this.KeepB.setBackground(Color.LIGHT_GRAY);
      this.KeepC.setBackground(Color.LIGHT_GRAY);
      this.KeepD.setBackground(Color.LIGHT_GRAY);
      this.KeepE.setBackground(Color.LIGHT_GRAY);
      this.KeepF.setBackground(Color.GREEN);
      this.computer.setCurrentDrive(0);
      mediumeject();
      loadFile(this.keepF);
    } 
    if (e.getSource() == this.makeshot) {
      this.screenpreview.dispose();
      saveShot();
    } 
    if (e.getSource() == this.startRec) {
      this.doRec = true;
      this.startR = true;
    } 
    if (e.getSource() == this.pauseRec) {
      if (this.pauserec) {
        this.pauserec = false;
      } else {
        this.pauserec = true;
      } 
      this.flasher = 0;
    } 
    if (e.getSource() == this.stopRec)
      this.startR = false; 
    if (e.getSource() == this.cancelshot)
      this.screenpreview.dispose(); 
    if (e.getSource() == this.s64) {
      this.computer.start();
      this.snaChooser.dispose();
      this.dialogsnap = false;
      Switches.save64 = true;
    } 
    if (e.getSource() == this.s128) {
      this.computer.start();
      this.snaChooser.dispose();
      this.dialogsnap = false;
      Switches.save128 = true;
    } 
    if (e.getSource() == this.s256) {
      this.computer.start();
      this.snaChooser.dispose();
      this.dialogsnap = false;
      Switches.save256 = true;
    } 
    if (e.getSource() == this.s512) {
      this.computer.start();
      this.snaChooser.dispose();
      this.dialogsnap = false;
      Switches.save512 = true;
    } 
    if (e.getSource() == this.cancel) {
      this.computer.start();
      this.dialogsnap = false;
      this.snaChooser.dispose();
    } else if (e.getSource() instanceof java.awt.MenuItem) {
      String menuAdd = e.getActionCommand();
      if (menuAdd.equals(this.mquit)) {
        if (iframe != null && !iframe.isVisible() && !undocked) {
          iframe.setVisible(true);
          GateArray.cpc.start();
        } 
        if (debugger != null) {
          debugger.removeAllBreakpoints();
          debugger.continueAndReset();
        } 
        this.computer.start();
        Autotype.save();
        GateArray.cpc.checkSaveOnExit();
      } else if (menuAdd.equals("Reset            Ctrl + F9")) {
        reset();
      } else if (menuAdd.equals("Reboot")) {
        reBoot();
      } else if (menuAdd.equals(this.mforce)) {
        reportBug();
        System.exit(0);
      } else if (menuAdd.equals(this.mabout)) {
        open(Desktop._ABOUT);
      } else if (menuAdd.equals("Create new DSK")) {
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(false); 
        CreateDsk(0);
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(onTop); 
      } else if (menuAdd.equals(this.mload)) {
        askDrive();
      } else if (menuAdd.equals("Debugger")) {
        showDebugger(true);
      } else if (menuAdd.equals("MultiDebugger")) {
        showMultiMem(this.computer.getProcessor().getProgramCounter());
      } else if (menuAdd.equals("Please RickRoll me")) {
        RickRollMe();
      } else if (menuAdd.equals(this.CPUfollow)) {
        if (followCPU) {
          followCPU = false;
        } else {
          followCPU = true;
        } 
      } else if (menuAdd.equals(this.gfxviewer)) {
        showDebugger(true);
        Display.initgfxviewer = 1;
      } else if (menuAdd.equals(this.screenmapper)) {
        if (mapper == null)
          mapper = new GameMapper(this); 
        mapper.setVisible(true);
      } else if (menuAdd.equals(this.mcpm)) {
        this.computer.bootCPM();
      } else if (menuAdd.equals(this.recordkeys)) {
        RecInfo();
      } else if (menuAdd.equals(this.virtualkeys)) {
        if (desktop != null) {
          checkKeyboard();
        } else if (Desktop.isDesktop) {
          Desktop.keytimer = 1;
        } 
      } else if (menuAdd.equals(this.asciicap)) {
        captureTXT();
      } else if (menuAdd.equals(this.startrecord)) {
        this.display.startcap();
      } else if (menuAdd.equals(this.stoprecord)) {
        this.display.stopcap();
      } else if (menuAdd.equals("Pause")) {
        pausecheck();
      } else if (menuAdd.equals(this.mejectall)) {
        ejectAll();
      } else if (menuAdd.equals(this.checkjavacpc)) {
        try {
          Main.verifyJavaCPC();
        } catch (Exception exception) {}
      } else if (menuAdd.equals(this.checkup)) {
        try {
          UpdateCheck(false);
        } catch (Exception exception) {}
      } else if (menuAdd.equals(this.checkfos)) {
        try {
          Main.checkFOSUpdate();
        } catch (Exception exception) {}
      } else if (menuAdd.equals(this.reportBug)) {
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(false); 
        reportBug();
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(onTop); 
      } else if (menuAdd.equals(this.downl)) {
        openWebPage("http://cpc-live.com/download.php?view.2");
      } else if (menuAdd.equals(this.favo)) {
        Favourites();
      } else if (menuAdd.equals(this.homepage)) {
        openWebPage("http://cpc-live.com");
      } else if (menuAdd.equals(this.sourceforge)) {
        openWebPage("https://sourceforge.net/projects/javacpc");
      } else if (menuAdd.equals(this.showYM)) {
        if (iframe == null) {
          if (this.ymframe == null) {
            this.ymframe = new JFrame("YM Recorder");
            JPanel ympanel = new JPanel();
            ympanel.setLayout(new BorderLayout());
            this.ymframe.setDefaultCloseOperation(1);
            this.ymframe.setLayout(new BorderLayout());
            ympanel.add(ymControl.controls, "Center");
            ympanel.add(YMControl.display, "North");
            ympanel.add(YMControl.ympos, "South");
            this.ymframe.add(ympanel, "First");
            this.ymframe.pack();
            this.ymframe.setResizable(true);
          } 
          Thread r = new Thread() {
              public void run() {
                while (!JEMU.this.ymframe.isVisible()) {
                  JEMU.this.ymframe.setVisible(true);
                  try {
                    this;
                    sleep(100L);
                  } catch (Exception exception) {}
                  JEMU.this.ymframe.pack();
                  JEMU.this.ymframe.setResizable(false);
                  try {
                    this;
                    sleep(100L);
                  } catch (Exception exception) {}
                  JEMU.this.ymframe.pack();
                  JEMU.this.ymframe.setResizable(false);
                  YMControl.UpdateLCD("*YM PLAYER*");
                  JEMU.this.ymframe.setAlwaysOnTop(true);
                } 
              }
            };
          r.start();
        } 
      } else if (menuAdd.equals(this.showRec)) {
        if (iframe == null) {
          if (this.capframe == null) {
            this.capframe = new JFrame("Audio Recorder");
            this.capframe.setDefaultCloseOperation(1);
            this.capframe.setLayout(new BorderLayout());
            JPanel pan = new JPanel();
            pan.setLayout(new BorderLayout());
            pan.add(Desktop.cap.getComponent(0));
            pan.setPreferredSize(new Dimension(460, 200));
            this.capframe.add(pan);
            this.capframe.setResizable(false);
          } 
          this.capframe.pack();
          this.capframe.setVisible(true);
        } 
        CPC.showAudioCapture = true;
      } else if (menuAdd.equals(this.inspectA)) {
        CPC.inspectA = true;
      } else if (menuAdd.equals(this.inspectB)) {
        CPC.inspectB = true;
      } else if (menuAdd.equals(this.showCap)) {
        if (this.capthis == null)
          this.capthis = new ScreenCapture(); 
        if (this.prevframe == null) {
          this.prevframe = new JFrame("Screen capture");
          this.prevframe.add(this.capthis);
          this.prevframe.pack();
          this.prevframe.setResizable(false);
        } 
        this.prevframe.setVisible(true);
      } else if (menuAdd.equals(this.showMov)) {
        this.display.framecount = 1;
      } else if (menuAdd.equals(this.df0sav)) {
        this.computer.setCurrentDrive(0);
        Switches.dskcheck = true;
      } else if (menuAdd.equals(this.df1sav)) {
        this.computer.setCurrentDrive(1);
        Switches.dskcheck = true;
      } else if (menuAdd.equals(this.df2sav)) {
        this.computer.setCurrentDrive(2);
        Switches.dskcheck = true;
      } else if (menuAdd.equals(this.df3sav)) {
        this.computer.setCurrentDrive(3);
        Switches.dskcheck = true;
      } else if (menuAdd.equals(this.df0save)) {
        this.computer.setCurrentDrive(0);
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(false); 
        saveDsk();
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(onTop); 
        this.computer.setCurrentDrive(0);
      } else if (menuAdd.equals(this.df1save)) {
        this.computer.setCurrentDrive(1);
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(false); 
        saveDsk();
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(onTop); 
        this.computer.setCurrentDrive(0);
      } else if (menuAdd.equals(this.df2save)) {
        this.computer.setCurrentDrive(2);
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(false); 
        saveDsk();
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(onTop); 
        this.computer.setCurrentDrive(0);
      } else if (menuAdd.equals(this.screenShot)) {
        screentimer = 1;
      } else if (menuAdd.equals(this.digi)) {
        Switches.digi = true;
        Switches.digiblaster = true;
        Settings.setBoolean("digiblaster", Switches.digiblaster);
        Switches.Printer = false;
        Settings.setBoolean("printer", false);
      } else if (menuAdd.equals(this.digimc)) {
        Switches.digimc = true;
      } else if (menuAdd.equals(this.digipg)) {
        Switches.digipg = true;
      } else if (menuAdd.equals(this.runds)) {
        this.computer.runDeathSword();
      } else if (menuAdd.equals(this.bdd)) {
        buildBDD();
      } else if (menuAdd.equals(this.cpcgamescd)) {
        desktop.setGamesCD();
      } else if (menuAdd.equals(this.catchSCR)) {
        Switches.saveScr = true;
      } 
      if (menuAdd.equals(this.df3save)) {
        this.computer.setCurrentDrive(3);
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(false); 
        saveDsk();
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(onTop); 
        this.computer.setCurrentDrive(0);
      } else if (menuAdd.equals(this.mmerge)) {
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(false); 
        dskmerge();
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(onTop); 
      } else if (menuAdd.equals("Autotype")) {
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(false); 
        Autotype.typeconsole.setVisible(true);
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(onTop); 
      } else if (menuAdd.equals("Z80 Assembler")) {
        makeAssembler();
      } else if (menuAdd.equals("DSKUtil")) {
        checkDSKUtil();
      } else if (menuAdd.equals(this.mpaste)) {
        Autotype.PasteText();
      } else if (menuAdd.equals(this.tapeopen)) {
        GateArray.cpc.TapeDrive.setVisible(true);
        CPC.tapedeck = true;
      } else if (menuAdd.equals(this.tapeLoad)) {
        loadTape(false);
      } else if (menuAdd.equals(this.ejectTape)) {
        tapeEject();
      } else if (menuAdd.equals(this.tapeLaunch)) {
        loadTape(true);
      } else if (menuAdd.equals(this.tapeSave)) {
        this.computer.tape_WAV_save();
      } else if (menuAdd.equals(this.tapeOptimize)) {
        CPC.doOptimize = true;
      } else if (menuAdd.equals(this.tapeConvert)) {
        this.computer.CDT2WAV();
      } else if (menuAdd.equals(this.makCDT)) {
        this.makeCDT.makeCDT();
      } else if (menuAdd.equals(this.copyfloppy)) {
        this.samdisk.setVisible(true);
      } else if (menuAdd.equals("Joy2Key")) {
        try {
          Runtime.getRuntime().exec(System.getProperty("user.home") + "/JavaCPC/tools/JoyToKey.exe");
        } catch (Exception exception) {}
      } else if (menuAdd.equals(this.reco)) {
        this.computer.SNP_Save();
      } else if (menuAdd.equals(this.stoprec)) {
        this.computer.SNP_Stop();
      } else if (menuAdd.equals(this.wav2cdt)) {
        this.samp2cdt.samp2CDT();
      } else if (menuAdd.equals(this.format0)) {
        this.computer.formatDisk(0);
      } else if (menuAdd.equals(this.format1)) {
        this.computer.formatDisk(1);
      } else if (menuAdd.equals(this.format2)) {
        this.computer.formatDisk(2);
      } else if (menuAdd.equals(this.format3)) {
        this.computer.formatDisk(3);
      } else if (menuAdd.equals(this.notpad)) {
        (new Notepad()).setVisible(true);
      } else if (menuAdd.equals(this.dsk2cdt)) {
        DSK2CDT();
      } else if (menuAdd.equals(this.desktopsettings)) {
        open(Desktop._DESKTOP);
      } else if (menuAdd.equals(this.audiosettings)) {
        open(Desktop._AUDIO);
      } else if (menuAdd.equals(this.videosettings)) {
        open(Desktop._VIDEO);
      } else if (menuAdd.equals(this.romsettings)) {
        open(Desktop._ROMS);
      } else if (menuAdd.equals(this.resjoy)) {
        ResetJoy();
      } else if (menuAdd.equals(this.miscsettings)) {
        open(Desktop._MISC);
      } else if (menuAdd.equals(this.systemsettings)) {
        open(Desktop._SYSTEM);
      } else if (menuAdd.equals(this.drivesettings)) {
        open(Desktop._DRIVES);
      } else if (menuAdd.equals(this.df0insert)) {
        load(0);
      } else if (menuAdd.equals(this.df1insert)) {
        load(1);
      } else if (menuAdd.equals(this.df2insert)) {
        load(2);
      } else if (menuAdd.equals(this.df3insert)) {
        load(3);
      } else if (menuAdd.equals(this.df0eject)) {
        this.computer.setCurrentDrive(0);
        mediumeject();
        this.computer.setCurrentDrive(0);
      } else if (menuAdd.equals(this.df1eject)) {
        this.computer.setCurrentDrive(1);
        mediumeject();
        this.computer.setCurrentDrive(0);
      } else if (menuAdd.equals(this.df2eject)) {
        this.computer.setCurrentDrive(2);
        mediumeject();
        this.computer.setCurrentDrive(0);
      } else if (menuAdd.equals(this.df3eject)) {
        this.computer.setCurrentDrive(3);
        mediumeject();
        this.computer.setCurrentDrive(0);
      } else if (menuAdd.equals(this.df0create)) {
        this.computer.setCurrentDrive(0);
        CreateDsk(0);
        this.computer.setCurrentDrive(0);
      } else if (menuAdd.equals(this.df1create)) {
        this.computer.setCurrentDrive(1);
        CreateDsk(1);
        this.computer.setCurrentDrive(0);
      } else if (menuAdd.equals(this.df2create)) {
        this.computer.setCurrentDrive(2);
        CreateDsk(2);
        this.computer.setCurrentDrive(0);
      } else if (menuAdd.equals(this.df3create)) {
        this.computer.setCurrentDrive(3);
        CreateDsk(3);
        this.computer.setCurrentDrive(0);
      } else if (menuAdd.equals(this.df0boot)) {
        this.computer.bootDisk();
      } else if (menuAdd.equals(this.df1boot)) {
        this.computer.bootDiskb();
      } else if (menuAdd.equals(this.Oprinter)) {
        TextPrinter.MakeVisible();
      } else if (menuAdd.equals(this.loadTXT)) {
        Autotype.loadFile();
      } else if (menuAdd.equals(this.Expansioninfo)) {
        ExpansionInfo();
      } else if (menuAdd.equals(this.HexEdit)) {
        this.hexi = new HexEditor();
      } else if (menuAdd.equals(this.FontEdit)) {
        showFontEditor();
      } else if (menuAdd.equals(this.snapshot)) {
        saveSNA();
      } else if (menuAdd.equals(this.binary)) {
        Switches.BINImport = true;
      } else if (menuAdd.equals(this.lostPaint)) {
        CPC.restorePaint = true;
      } else if (menuAdd.equals(this.export)) {
        Switches.export = true;
      } else if (menuAdd.equals(this.cpcpalette)) {
        Switches.showPalette = true;
      } else if (menuAdd.equals(this.poke)) {
        Switches.poke = true;
      } else if (menuAdd.equals(this.inspaint)) {
        choosePaint(true);
      } else if (menuAdd.equals(this.insraster)) {
        openRasterPaint();
      } else if (menuAdd.equals(this.insmx)) {
        startMXPaint();
      } else if (menuAdd.equals(this.fospaint)) {
        startFOSPaint();
      } 
    } 
  }
  
  public static void choosePaint(final boolean disk) {
    try {
      SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              boolean overscan = true;
              Object[] options = { "Normal", "Overscan", "Cancel" };
              int n = JOptionPane.showOptionDialog(new JFrame(), "Which screen format do you want?", "Please choose...", 1, 3, null, options, options[0]);
              if (n == 0)
                overscan = false; 
              if (n == 2)
                return; 
              if (disk) {
                if (overscan) {
                  CPC.insertOverscanPaintDisk = true;
                } else {
                  CPC.insertNormalPaintDisk = true;
                } 
              } else if (overscan) {
                GateArray.cpc.StartOverscanPaint();
                System.out.println("Starting overscan paint");
              } else {
                GateArray.cpc.StartNormalPaint();
                System.out.println("Starting normal paint");
              } 
            }
          });
    } catch (Exception e) {
      e.printStackTrace();
    } 
    System.gc();
  }
  
  public static void choosePaint(final String name) {
    try {
      SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              boolean overscan = true;
              Object[] options = { "Normal", "Overscan", "Cancel" };
              int n = JOptionPane.showOptionDialog(JEMU.frame, "Which screen format do you want?", "Please choose...", 1, 3, null, options, options[0]);
              if (n == 0)
                overscan = false; 
              if (n == 2)
                return; 
              if (overscan) {
                GateArray.cpc.StartOverscanPaint(name);
                CPC.importoverscanscr = 1;
              } else {
                GateArray.cpc.StartNormalPaint(name);
                CPC.importnormalscr = 1;
              } 
            }
          });
    } catch (Exception e) {
      e.printStackTrace();
    } 
    System.gc();
  }
  
  public void changeMem() {
    Switches.Memory = Settings.get("memory", Switches.Memory);
    String oldSys = getComputer().getName();
    try {
      setComputer(oldSys);
    } catch (Exception ex) {
      ex.printStackTrace();
    } 
    LoadFiles();
  }
  
  public void itemStateChanged(ItemEvent e) {
    if (e.getSource() == runComputer && debugger != null) {
      debugger.removeAllBreakpoints();
      debugger.continueAndReset();
    } 
    if (e.getSource() == debugthis) {
      debugthis.setSelected(false);
      showDebugger(true);
    } 
    if (e.getSource() == this.autocheck) {
      Settings.setBoolean("autocheck", this.autocheck.getState());
      this.checkupdate = this.autocheck.getState();
    } 
    if (e.getSource() == this.inspector) {
      this.shouldBoot.setState(false);
      CPC.shouldBoot = false;
      Settings.setBoolean("fileinspector", this.inspector.getState());
      Switches.inspector = this.inspector.getState();
    } 
    if (e.getSource() == z80turbo) {
      Desktop.jCheckBox19.setSelected(z80turbo.getState());
      boolean t = Desktop.jCheckBox19.isSelected();
      Settings.setBoolean("z80_turbo", t);
      GateArray.cpc.setZ80Turbo(t);
    } 
    if (e.getSource() == turbo) {
      Desktop.jCheckBox8.setSelected(turbo.getState());
      if (Desktop.jCheckBox8.isSelected()) {
        Switches.turbo = 2;
        turbo.setState(true);
      } else {
        Switches.turbo = 1;
        turbo.setState(false);
      } 
    } 
    if (e.getSource() == this.autofire)
      Switches.autofire = this.autofire.getState(); 
    if (e.getSource() == this.lightgun) {
      Switches.lightGun = this.lightgun.getState();
      this.display.setCursor();
    } 
    if (e.getSource() == this.keepprop) {
      this.keepDimension = this.keepprop.getState();
      Settings.setBoolean("keep_display_propertions", this.keepDimension);
    } 
    if (e.getSource() == this.mousewheel)
      Settings.setBoolean("mousewheel_zoom", this.mousewheel.getState()); 
    if (e.getSource() == this.RecKey) {
      this.KeyRec = this.RecKey.getState();
      Settings.setBoolean("keyboard_recording", this.KeyRec);
    } 
    if (e.getSource() == this.statusbar) {
      this.showStatus = this.statusbar.getState();
      Settings.setBoolean("status_bar", this.showStatus);
      this.statpan.setVisible(this.showStatus);
      if (this.executable) {
        if (iframe != null)
          iframe.pack(); 
        if (frame != null)
          frame.pack(); 
      } 
    } 
    if (e.getSource() == this.changePolarity) {
      Switches.changePolarity = this.changePolarity.getState();
      Settings.setBoolean("changePolarity", Switches.changePolarity);
    } 
    if (e.getSource() == this.watchsys) {
      Settings.setBoolean("observe_performance", this.watchsys.getState());
      Switches.watch = this.watchsys.getState();
    } else if (e.getSource() == this.shouldBoot) {
      this.inspector.setState(false);
      Switches.inspector = false;
      CPC.shouldBoot = this.shouldBoot.getState();
    } else if (e.getSource() == this.UseGzip) {
      if (this.UseGzip.getState()) {
        Switches.uncompressed = false;
      } else {
        Switches.uncompressed = true;
      } 
      Settings.setBoolean("gzip_compression", this.UseGzip.getState());
    } else if (e.getSource() == this.recrateA) {
      Settings.setBoolean("recrate44", true);
      Settings.setBoolean("recrate11", false);
      Switches.khz44 = true;
      Switches.khz11 = false;
      this.recrateA.setState(true);
      this.recrateB.setState(false);
      this.recrateC.setState(false);
    } else if (e.getSource() == this.recrateB) {
      Settings.setBoolean("recrate44", false);
      Settings.setBoolean("recrate11", false);
      Switches.khz44 = false;
      Switches.khz11 = false;
      this.recrateA.setState(false);
      this.recrateB.setState(true);
      this.recrateC.setState(false);
    } else if (e.getSource() == this.recrateC) {
      Settings.setBoolean("recrate44", false);
      Settings.setBoolean("recrate11", true);
      Switches.khz44 = false;
      Switches.khz11 = true;
      this.recrateA.setState(false);
      this.recrateB.setState(false);
      this.recrateC.setState(true);
    } else if (e.getSource() == this.joyemu) {
      Settings.setBoolean("joystick", this.joyemu.getState());
      this.qaop.setEnabled(this.joyemu.getState());
      if (this.joyemu.getState()) {
        Switches.joystick = 1;
      } else {
        Switches.joystick = 0;
      } 
    } else if (e.getSource() == this.qaop) {
      Settings.setBoolean("notebook", this.qaop.getState());
      Switches.notebook = this.qaop.getState();
    } else if (e.getSource() == this.cpc464t) {
      this.cpc464t.setState(true);
      this.cpc464.setState(false);
      this.cpc664.setState(false);
      this.cpc6128.setState(false);
      this.symbos.setState(false);
      this.futureos.setState(false);
      this.kccompact.setState(false);
      this.customcpc.setState(false);
      try {
        setComputer("CPC464T");
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
      LoadFiles();
    } else if (e.getSource() == this.cpc464) {
      this.cpc464t.setState(false);
      this.cpc464.setState(true);
      this.cpc664.setState(false);
      this.cpc6128.setState(false);
      this.symbos.setState(false);
      this.futureos.setState(false);
      this.kccompact.setState(false);
      this.customcpc.setState(false);
      try {
        setComputer("CPC464");
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
      LoadFiles();
    } else if (e.getSource() == this.cpc664) {
      this.cpc464t.setState(false);
      this.cpc464.setState(false);
      this.cpc664.setState(true);
      this.cpc6128.setState(false);
      this.symbos.setState(false);
      this.futureos.setState(false);
      this.kccompact.setState(false);
      this.customcpc.setState(false);
      try {
        setComputer("CPC664");
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
      LoadFiles();
    } else if (e.getSource() == this.symbos) {
      this.cpc464t.setState(false);
      this.cpc464.setState(false);
      this.cpc664.setState(false);
      this.cpc6128.setState(false);
      this.symbos.setState(true);
      this.futureos.setState(false);
      this.kccompact.setState(false);
      this.customcpc.setState(false);
      try {
        setComputer("SymbOS");
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
      LoadFiles();
    } else if (e.getSource() == this.futureos) {
      this.cpc464t.setState(false);
      this.cpc464.setState(false);
      this.cpc664.setState(false);
      this.cpc6128.setState(false);
      this.symbos.setState(false);
      this.futureos.setState(true);
      this.kccompact.setState(false);
      this.customcpc.setState(false);
      try {
        setComputer("FutureOS");
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
      LoadFiles();
    } else if (e.getSource() == this.kccompact) {
      this.cpc464t.setState(false);
      this.cpc464.setState(false);
      this.cpc664.setState(false);
      this.cpc6128.setState(false);
      this.symbos.setState(false);
      this.futureos.setState(false);
      this.kccompact.setState(true);
      this.customcpc.setState(false);
      try {
        setComputer("KCCOMPACT");
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
      LoadFiles();
    } else if (e.getSource() == this.cpc6128) {
      this.cpc464t.setState(false);
      this.cpc464.setState(false);
      this.cpc664.setState(false);
      this.cpc6128.setState(true);
      this.symbos.setState(false);
      this.futureos.setState(false);
      this.kccompact.setState(false);
      this.customcpc.setState(false);
      try {
        setComputer("CPC6128");
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
      LoadFiles();
    } else if (e.getSource() == this.customcpc) {
      this.cpc464t.setState(false);
      this.cpc464.setState(false);
      this.cpc664.setState(false);
      this.cpc6128.setState(false);
      this.customcpc.setState(true);
      this.symbos.setState(false);
      this.futureos.setState(false);
      this.kccompact.setState(false);
      try {
        setComputer("CUSTOM");
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
      LoadFiles();
    } else if (e.getSource() == this.checkFull) {
      if (!Display.use3d) {
        togglesize = this.checkFull.getState();
        FullSize();
      } 
    } else if (e.getSource() == this.joymouse) {
      if (this.mousejoy) {
        Switches.MouseJoy = false;
        Settings.setBoolean("mousejoy", false);
        this.mousejoy = false;
      } else {
        Switches.MouseJoy = true;
        Settings.setBoolean("mousejoy", true);
        this.mousejoy = true;
      } 
    } 
  }
  
  public void saveDsk() {
    if (this.executable && frame != null)
      frame.setAlwaysOnTop(false); 
    String filename = putFile("Disk image");
    if (filename != null) {
      String savename = filename;
      if (!savename.toLowerCase().endsWith(".dsk"))
        savename = savename + ".dsk"; 
      File savefile = new File(savename);
      int drive = this.computer.getCurrentDrive();
      byte[] data = this.computer.getDSKImage(drive);
      if (data == null) {
        System.err.println("Something went wrong storing " + savename);
        return;
      } 
      try {
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(savefile));
        bos.write(data);
        bos.close();
      } catch (Exception e) {
        System.err.println("Something went wrong storing " + savename);
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(onTop); 
        return;
      } 
      loadFile(1, savename, false);
      JOptionPane.showMessageDialog(null, "Sucessfully saved as " + savefile);
      if (this.executable && frame != null)
        frame.setAlwaysOnTop(onTop); 
    } 
  }
  
  public void saveDisk(byte[] data, int drive) {
    if (this.executable && frame != null)
      frame.setAlwaysOnTop(false); 
    String filename = putFile("Disk image");
    if (filename != null) {
      String savename = filename;
      if (!savename.toLowerCase().endsWith(".dsk"))
        savename = savename + ".dsk"; 
      File savefile = new File(savename);
      this.computer.setCurrentDrive(drive);
      if (data == null) {
        System.err.println("Something went wrong storing " + savename);
        return;
      } 
      try {
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(savefile));
        bos.write(data);
        bos.close();
      } catch (Exception e) {
        System.err.println("Something went wrong storing " + savename);
        if (this.executable && frame != null)
          frame.setAlwaysOnTop(onTop); 
        return;
      } 
      loadFile(2, savename, false);
      JOptionPane.showMessageDialog(null, "Sucessfully saved as " + savefile);
      if (this.executable && frame != null)
        frame.setAlwaysOnTop(onTop); 
    } 
  }
  
  public void driveActiveChanged(Drive drive, boolean active) {
    Drive[] floppies = this.computer.getFloppyDrives();
    int i = this.computer.getCurrentDrive();
    if (!active && floppies != null && floppies[i] != null && floppies[i].isActive())
      active = true; 
    ledOn = active;
  }
  
  public void Size() {
    if (frame != null)
      frame.dispose(); 
    if (frame != null)
      frame.setUndecorated(false); 
    Switches.stretch = false;
    System.out.println("Resizing Window...");
    if (large == true) {
      large = false;
      setFullSize(large);
      Settings.setBoolean("large", false);
    } else if (!large) {
      large = true;
      setFullSize(large);
      Settings.setBoolean("large", true);
    } 
    if (large) {
      System.out.println("Double size - Gare Array is double");
    } else {
      System.out.println("Simple size - Gare Array is half");
    } 
    if (iframe != null)
      iframe.pack(); 
    if (frame != null)
      frame.pack(); 
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    if (frame != null)
      frame.setLocation(screenXstored, screenYstored); 
    if (iframe != null)
      iframe.setLocation(screenXstored, screenYstored); 
    if (frame != null)
      winx1 = (frame.getSize()).width; 
    if (frame != null)
      winy1 = (frame.getSize()).height; 
    System.out.println("Window is " + winx1 + " Pixels width & " + winy1 + " Pixels height!");
    this.computer.start();
    System.out.println("You can stretch the window now.");
    togglesize = true;
    this.stretcher = false;
    defaultSize();
    if (frame != null)
      frame.setVisible(true); 
    this.display.requestFocus();
  }
  
  public void Turbocheck() {
    if (Switches.turbo == 1) {
      Switches.turbo = 4;
      turbo.setState(true);
      Desktop.jCheckBox8.setSelected(true);
    } else {
      Switches.turbo = 1;
      turbo.setState(false);
      Desktop.jCheckBox8.setSelected(false);
    } 
  }
  
  public void FullSize() {
    if (Display.use3d)
      return; 
    Switches.stretch = false;
    if (togglesize) {
      if (this.skinned) {
        this.Moniup.setVisible(false);
        this.Monidown.setVisible(false);
        this.Monileft.setVisible(false);
        this.Moniright.setVisible(false);
      } 
      if (frame != null)
        frame.dispose(); 
      if (!Desktop.started && frame != null)
        frame.remove(JavaCPCMenu); 
      if (frame != null)
        frame.setUndecorated(true); 
      togglesize = false;
      fullscreen = true;
      Settings.setBoolean("full_screen", true);
    } else {
      if (this.skinned && !large) {
        this.Moniup.setVisible(true);
        this.Monidown.setVisible(true);
        this.Monileft.setVisible(true);
        this.Moniright.setVisible(true);
      } 
      if (frame != null)
        frame.dispose(); 
      if (frame != null)
        frame.setUndecorated(false); 
      togglesize = true;
      fullscreen = false;
      Settings.setBoolean("full_screen", false);
    } 
    if (frame != null)
      frame.setVisible(true); 
    if (!fullscreen) {
      System.err.println("closing fullscreen...");
      this.bascreen = 1;
    } 
    setOutputSize();
    this.checkFull.setState(fullscreen);
    this.display.requestFocus();
    this.computer.reSync();
  }
  
  public void defaultSize() {
    if (this.stretcher)
      Switches.stretch = true; 
    this.stretcher = true;
    if (frame != null)
      frame.dispose(); 
    if (frame != null)
      frame.setUndecorated(false); 
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    if (frame != null)
      frame.setSize(winx1, winy1); 
    togglesize = true;
    Settings.setBoolean("full_screen", false);
    if (iframe != null)
      iframe.pack(); 
    if (frame != null)
      frame.pack(); 
    if (frame != null)
      frame.setVisible(true); 
    this.computer.start();
    this.display.requestFocus();
    Switches.stretch = false;
    if (frame != null)
      frame.dispose(); 
    if (iframe != null)
      iframe.pack(); 
    if (frame != null)
      frame.pack(); 
    if (frame != null)
      frame.setLocation(screenXstored, screenYstored); 
    if (frame != null)
      frame.setVisible(true); 
    this.computer.reSync();
  }
  
  protected void localize() {
    localizeMenu();
    if (desktop != null) {
      desktop.localize(localkeys);
    } else if (Desktop.isDesktop) {
      Desktop.localizetimer = 1;
    } 
  }
  
  protected void localizeMenu() {
    if (localkeys.toLowerCase().equals("de_de")) {
      this.menue1.setLabel("Datei");
      this.reco = "Session aufnehmen";
      this.stoprec = "Session beenden";
      this.favo = "Favoritenbrowser";
      this.asciicap = "CPC-Bild zu ASCII    Shift + F11";
      this.menue3.setLabel("Einstellungen");
      this.menue5.setLabel("Hilfe");
      this.menue6.setLabel("Bearbeiten");
      this.notpad = "Kleiner Texteditor";
      this.dsk2cdt = "Kopiere Dateien von DF0 als CDT";
      this.drives.setLabel("Laufwerke");
      this.keyboard.setLabel("Tastatur");
      this.tape.setLabel("Kassette");
      this.statusbar.setLabel("Zeige Statuspanel");
      this.changePolarity.setLabel("Ändere Kassettenpolarität");
      this.keepprop.setLabel("Behalte BildschirmProportionen");
      this.mousewheel.setLabel("Mausrad zoomt Bildschirm");
      this.lightgun.setLabel("Lichtpistole aktivieren");
      this.autofire.setLabel("Autofeuer");
      this.watchsys.setLabel("Performance überwachen");
      this.shouldBoot.setLabel("Versuche, Disk zu booten");
      this.UseGzip.setLabel("Verwende GZIP Komprimierung (DSK, SNA, WAV)");
      this.runds = "DeathSword spielen";
      this.reportBug = "Fehler-Report";
      this.virtualkeys = "Virtuelle Tastatur";
      this.startrecord = "Beginne Aufzeichnung";
      this.stoprecord = "Beende Aufzeichnung";
      this.desktopsettings = "Desktop-Einstellungen";
      this.videosettings = "Video-Einstellungen";
      this.audiosettings = "Audio-Einstellungen";
      this.miscsettings = "Weitere Einstellungen";
      this.systemsettings = "System-Einstellungen";
      this.drivesettings = "Laufwerks-Parameter";
      this.romsettings = "ROM Auswahl";
      this.resjoy = "Feuerknöpfe zurücksetzen";
      this.RecKey.setLabel("Starte Tastatur-Aufzeichnung");
      this.autocheck.setLabel("Automatisch nach Updates prüfen");
      this.inspector.setLabel("Öffne Dateiinspektor, wenn DSK geladen wird");
      this.checkFull.setLabel("Vollbild            Alt + Enter");
      this.recrateA.setLabel("Verwende 44.1 khz (~13 min.) (Beste, funktioniert mit CPCTapeXP!)");
      this.recrateB.setLabel("Verwende 22.0 khz (~25 min.) (Standardqualität)");
      this.recrateC.setLabel("Verwende 11.5 khz (~50 min.) (Schlechte Qualität, miserable Resultate)");
      this.customcpc.setLabel("Benutzerdefinierter CPC");
      this.joyemu.setLabel("Joystick");
      this.qaop.setLabel("Alternative Kontrolle");
      this.joymouse.setLabel("Mausjoystick");
      this.Expansioninfo = "Expansion Info";
      this.recordkeys = "Zeige Tastatur-Aufzeichnung";
      this.tapeopen = "Zeige Kassettendeck";
      this.tapeLoad = "Kassette einsetzen";
      this.ejectTape = "Kassette auswerfen";
      this.tapeLaunch = "Kassette starten";
      this.tapeSave = "Kassette speichern";
      this.tapeOptimize = "Kassette optimieren";
      this.tapeConvert = "Wandle CDT in WAV";
      this.format0 = "Formatiere Disk";
      this.format1 = "Formatiere Disk ";
      this.format2 = "Formatiere Disk  ";
      this.format3 = "Formatiere Disk   ";
      this.df0insert = "Einlegen";
      this.df1insert = "Einlegen ";
      this.df2insert = "Einlegen  ";
      this.df3insert = "Einlegen    ";
      this.df0sav = "Speichern";
      this.df1sav = "Speichern ";
      this.df2sav = "Speichern  ";
      this.df3sav = "Speichern   ";
      this.df0eject = "Auswerfen";
      this.df1eject = "Auswerfen ";
      this.df2eject = "Auswerfen  ";
      this.df3eject = "Auswerfen   ";
      this.df0create = "Mache DSK";
      this.df1create = "Mache DSK ";
      this.df2create = "Mache DSK  ";
      this.df3create = "Mache DSK   ";
      this.df0boot = "Booten";
      this.df1boot = "Booten ";
      this.df0save = "Speichere DSK als...";
      this.df1save = "Speichere DSK als... ";
      this.df2save = "Speichere DSK als...  ";
      this.df3save = "Speichere DSK als...   ";
      this.screenShot = "Speichere Screenshot     Ctrl + F11";
      this.catchSCR = "Fange CPC Screen (16k)";
      this.Oprinter = "Öffne Drucker-Konsole";
      this.loadTXT = "Importiere ASCII Datei";
      this.HexEdit = "Öffne Hex Editor";
      this.FontEdit = "Öffne Zeichen Editor";
      this.snapshot = "Speichere Snapshot";
      this.binary = "Importiere CPC Datei";
      this.poke = "POKE Speicher";
      this.inspaint = "Starte JavaCPC Paint";
      this.lostPaint = "Restauriere JavaCPC Paint DSK";
      this.export = "Exportiere Binär";
      this.cpcpalette = "Zeige Farb-Palette";
      this.digi = "Starte Prodatron's Digitracker";
      this.digimc = "Starte DigiTracker MOD converter";
      this.digipg = "Starte Digitracker Player-Generator";
      this.checkjavacpc = "Prüfe JavaCPC";
      this.checkup = "Suche nach Update";
      this.checkfos = "Suche nach FutureOS ROM Update";
      Main.fos_update = "FutureOS wurde erfolgreich auf Version %s1 aktualisiert";
      Main.fos_uptodate = "FutureOS ist auf dem aktuellsten Stand";
      this.CPUfollow = "Disassembler folgt CPU";
      this.downl = "Besuche Download-Seite";
      this.homepage = "Besuche Homepage";
      this.sourceforge = "Sourceforge Projekt Seite";
      this.showYM = "Zeige YM-Kontrolle";
      this.showRec = "Audio aufzeichnen";
      this.showCap = "GIF-Sequenz aufzeichnen";
      this.showMov = "Quicktime MOV aufzeichnen";
      this.inspectA = "Datei-Inspector";
      this.inspectB = "Datei-Inspector ";
      this.Expansioninfo = "Info zu Erweiterungen";
      this.makCDT = "Mache ein CDT";
      this.wav2cdt = "Samp2CDT";
      this.copyfloppy = "SamDisk";
      this.gfxviewer = "GFXViewer";
      this.screenmapper = "GameMapper (Bildschirm)";
      this.mload = "Lade...";
      this.mcpm = "Boote CP/M";
      this.mejectall = "Alle Auswerfen";
      this.mmerge = "Mische Zwei DSK...";
      this.mquit = "Beenden";
      this.mforce = "Erzwinge Beenden";
      this.mpaste = "Einfügen      F11";
      this.mabout = "Über";
    } else if (localkeys.toLowerCase().equals("es_es")) {
      this.menue1.setLabel("File");
      this.reco = "Grabar Sesión";
      this.stoprec = "Detener Sesión";
      this.favo = "Navegador-Favorito";
      this.asciicap = "CPC-Pantalla-A-ASCII    Shift + F11";
      this.menue2.setLabel("Emulación");
      this.menue3.setLabel("Ajustes");
      this.menue4.setLabel("Pantalla");
      this.menue5.setLabel("Ayuda");
      this.menue6.setLabel("Editar");
      this.extra.setLabel("Extras");
      this.notpad = "Mini bloc de notas";
      this.dsk2cdt = "Copiar ficheros desde DF0 como CDT";
      this.drives.setLabel("Unidades");
      this.df0.setLabel("DF0:");
      this.df1.setLabel("DF1:");
      this.df2.setLabel("DF2:");
      this.df3.setLabel("DF3:");
      this.joymenu.setLabel("Joystick");
      this.keyboard.setLabel("Teclado");
      this.tape.setLabel("Cinta");
      this.statusbar.setLabel("Mostrar barra de estado");
      this.changePolarity.setLabel("Cambiar polaridad cinta");
      this.keepprop.setLabel("Mantener proporciones pantalla");
      this.mousewheel.setLabel("La rueda del ratón acerca y aleja la pantalla");
      this.lightgun.setLabel("Activar Lightgun");
      this.autofire.setLabel("Autodisparo");
      this.watchsys.setLabel("Observar rendimiento");
      this.shouldBoot.setLabel("Autoarrancar el juego");
      this.UseGzip.setLabel("Usar compresión GZip DSK, SNA, WAV");
      this.runds = "Jugar a DeathSword";
      this.reportBug = "Informar de un error";
      this.virtualkeys = "Abrir teclado virtual";
      this.startrecord = "Iniciar grabación";
      this.stoprecord = "Parar grabación";
      this.desktopsettings = "Ajustes de escritorio";
      this.videosettings = "Ajustes de vídeo";
      this.audiosettings = "Ajustes de audio";
      this.miscsettings = "Otros ajustes";
      this.systemsettings = "Ajustes de sistema";
      this.drivesettings = "Ajustes de unidad";
      this.romsettings = "Ajustes de ROM";
      this.resjoy = "Reiniciar BotonesJoystick";
      this.Keys.setLabel(this.keys);
      this.RecKey.setLabel("Activar grabación de teclado");
      this.recordkeys = "Información grabación de teclado";
      this.tapeopen = "Mostrar unidad de cinta";
      this.tapeLoad = "Insertar cinta";
      this.ejectTape = "Expulsar cinta";
      this.tapeLaunch = "Iniciar cinta";
      this.tapeSave = "Grabar cinta";
      this.tapeOptimize = "Optimizar Cinta";
      this.tapeConvert = "Convertir CDT a WAV";
      this.format0 = "Formatear Disk";
      this.format1 = "Formatear Disk ";
      this.format2 = "Formatear Disk  ";
      this.format3 = "Formatear Disk   ";
      this.recrateA.setLabel("Usar frecuencia de 44.1 khz (~13 min.) (la mejor, funciona con CPCTapeXP!)");
      this.recrateB.setLabel("Usar frecuencia de 22.0 khz (~25 min.) (Calidad standard)");
      this.recrateC.setLabel("Usar frecuencia de 11.5 khz (~50 min.) (Calidad baja, malos resultados)");
      this.df0insert = "Insertar";
      this.df1insert = "Insertar ";
      this.df2insert = "Insertar  ";
      this.df3insert = "Insertar    ";
      this.df0sav = "Guardar";
      this.df1sav = "Guardar ";
      this.df2sav = "Guardar  ";
      this.df3sav = "Guardar   ";
      this.df0eject = "Expulsar";
      this.df1eject = "Expulsar ";
      this.df2eject = "Expulsar  ";
      this.df3eject = "Expulsar   ";
      this.df0create = "Crear DSK";
      this.df1create = "Crear DSK ";
      this.df2create = "Crear DSK  ";
      this.df3create = "Crear DSK   ";
      this.df0boot = "Probar a arrancar";
      this.df1boot = "Probar a arrancar ";
      this.df0save = "Guardar DSK como...";
      this.df1save = "Guardar DSK como... ";
      this.df2save = "Guardar DSK como...  ";
      this.df3save = "Guardar DSK como...   ";
      this.screenShot = "Guardar captura de pantalla     Ctrl + F11";
      this.catchSCR = "Capturar imagen CPC (16k)";
      this.Oprinter = "Abrir consola de la impresora";
      this.loadTXT = "Importar fichero ASCII";
      this.HexEdit = "Abrir editor Hexadecimal";
      this.FontEdit = "Abrir Editor de Fuentes";
      this.snapshot = "Guardar snapshot";
      this.binary = "Importar fichero CPC";
      this.poke = "Poke Memoria";
      this.inspaint = "Lanzar JavaCPC Paint";
      this.lostPaint = "Restaurar JavaCPC Paint DSK";
      this.export = "Exportar binario";
      this.cpcpalette = "Mostrar paleta actual";
      this.digi = "Lanzar Digitracker de Prodatron";
      this.digimc = "Lanzar DigiTracker MOD converter";
      this.digipg = "Lanzar Digitracker Player-Generator";
      this.checkjavacpc = "Compruebe  JavaCPC";
      this.checkup = "Buscar actualizaciones";
      this.checkfos = "Buscar actualizaciones de las ROMs de FutureOS";
      Main.fos_uptodate = "Las ROMs de FutureOS están actualizadas";
      Main.fos_update = "Las ROMs de FutureOS se han actualizado a la Versión %s1";
      this.CPUfollow = "Permitir que el desensamblador observe la CPU";
      this.downl = "Visitar página de descargas";
      this.homepage = "Visitar homepage";
      this.sourceforge = "Página del proyecto en Sourceforge";
      this.showYM = "Mostrar YM-Control";
      this.showRec = "Grabar audio";
      this.showCap = "Grabar Secuencia-GIF";
      this.showMov = "Grabar Quicktime MOV";
      this.inspectA = "Monitor de ficheros";
      this.inspectB = "Monitor de ficheros ";
      this.autocheck.setLabel("Buscar automáticamente actualizaciones");
      this.inspector.setLabel("Abrir el monitor de ficheros al cargar DSK");
      this.checkFull.setLabel("Pantalla completa            Alt + Enter");
      this.cpc464t.setLabel("CPC 464");
      this.cpc464.setLabel("CPC 464 (Amsdos)");
      this.cpc664.setLabel("CPC 664");
      this.cpc6128.setLabel("CPC 6128");
      this.symbos.setLabel("SymbOS");
      this.futureos.setLabel("FutureOS");
      this.kccompact.setLabel("KC compact");
      this.customcpc.setLabel("Custom CPC");
      this.joyemu.setLabel("Joystick");
      this.qaop.setLabel("Control alternativo");
      this.joymouse.setLabel("Ratónjoystick");
      this.Expansioninfo = "Info expansion";
      this.makCDT = "Crear CDT";
      this.wav2cdt = "Samp2CDT";
      this.copyfloppy = "SamDisk";
      this.gfxviewer = "GFXViewer";
      this.screenmapper = "GameMapper (Pantalla)";
      this.mload = "Cargar...";
      this.mcpm = "Iniciar CP/M";
      this.mejectall = "Expulsar todo";
      this.mmerge = "Combinar DSK's...";
      this.mpaste = "Pegar      F11";
      this.mquit = "Salir";
      this.mforce = "Forzar salir";
      this.mabout = "Acerca de";
    } else if (localkeys.toLowerCase().equals("fr_fr")) {
      this.menue1.setLabel("Ficher");
      this.reco = "Enregistrer Session";
      this.stoprec = "Stopper Session";
      this.favo = "Navigateur favori";
      this.asciicap = "Capturer l'Ecran CPC en ASCII    Shift + F11";
      this.menue2.setLabel("Emulation");
      this.menue3.setLabel("Paramètres");
      this.menue4.setLabel("Moniteur");
      this.menue5.setLabel("Aide");
      this.menue6.setLabel("Editer");
      this.extra.setLabel("Extras");
      this.notpad = "Petit Bloc-notes";
      this.dsk2cdt = "Copier fichiers DF0 en CDT";
      this.drives.setLabel("Lecteurs");
      this.df0.setLabel("DF0:");
      this.df1.setLabel("DF1:");
      this.df2.setLabel("DF2:");
      this.df3.setLabel("DF3:");
      this.joymenu.setLabel("Joystick");
      this.keyboard.setLabel("Clavier");
      this.tape.setLabel("Cassette");
      this.statusbar.setLabel("Montrer Barre de statut");
      this.changePolarity.setLabel("Changer la polarité de la cassette");
      this.keepprop.setLabel("Garder le ratio d'affichage");
      this.mousewheel.setLabel("Redimensionner l'écran avec la molette de la souris");
      this.lightgun.setLabel("Activer Lightgun");
      this.autofire.setLabel("Autofire");
      this.watchsys.setLabel("Observer les performances");
      this.shouldBoot.setLabel("Essayer de démarrer le jeu");
      this.UseGzip.setLabel("Utiliser la compression Gzip pour les DSK, SNA, WAV");
      this.runds = "Jouez DeathSword";
      this.reportBug = "Signaler un bug";
      this.virtualkeys = "Lancer Clavier virtuel";
      this.startrecord = "*Démarrer Enregistrement";
      this.stoprecord = "Stopper Enregistrement";
      this.desktopsettings = "Réglages du Bureau";
      this.videosettings = "Réglages Vidéo";
      this.audiosettings = "Réglages Audio";
      this.miscsettings = "Réglages Divers";
      this.systemsettings = "Réglages Système";
      this.drivesettings = "Réglages Lecteur";
      this.romsettings = "Paramètres Roms";
      this.resjoy = "Reset des Boutons du Joystick";
      this.Keys.setLabel(this.keys);
      this.RecKey.setLabel("Activer l'enregistrement du clavier");
      this.recordkeys = "Informations d'enregistrement du clavier";
      this.tapeopen = "Montrer Platine Cassette";
      this.tapeLoad = "Insérer Cassette";
      this.ejectTape = "Ejecter Cassette";
      this.tapeLaunch = "Lancer Cassette";
      this.tapeSave = "Sauvegarder Cassette";
      this.tapeOptimize = "Optimiser Cassette";
      this.tapeConvert = "Convertir CDT en WAV";
      this.format0 = "Formater Disque";
      this.format1 = "Formater Disque ";
      this.format2 = "Formater Disque  ";
      this.format3 = "Formater Disque   ";
      this.recrateA.setLabel("Utiliser le taux à 44.1 khz (~13 min.) (Meilleur, fonctionne avec CPCTapeXP!)");
      this.recrateB.setLabel("Utiliser le taux à 22.0 khz (~25 min.) (Qualité Standard)");
      this.recrateC.setLabel("Utiliser le taux à 11.5 khz (~50 min.) (Basse Qualité, Mauvais résultat)");
      this.df0insert = "Insérer";
      this.df1insert = "Insérer ";
      this.df2insert = "Insérer  ";
      this.df3insert = "Insérer    ";
      this.df0sav = "Sauvegarder";
      this.df1sav = "Sauvegarder ";
      this.df2sav = "Sauvegarder  ";
      this.df3sav = "Sauvegarder   ";
      this.df0eject = "Ejecter";
      this.df1eject = "Ejecter ";
      this.df2eject = "Ejecter  ";
      this.df3eject = "Ejecter   ";
      this.df0create = "Créer DSK";
      this.df1create = "Créer DSK ";
      this.df2create = "Créer DSK  ";
      this.df3create = "Créer DSK   ";
      this.df0boot = "Essayer de démarrer";
      this.df1boot = "Essayer de démarrer ";
      this.df0save = "Sauvegarder DSK en tant que...";
      this.df1save = "Sauvegarder DSK en tant que... ";
      this.df2save = "Sauvegarder DSK en tant que...  ";
      this.df3save = "Sauvegarder DSK en tant que...   ";
      this.screenShot = "Sauvegarder Screenshot     Ctrl + F11";
      this.catchSCR = "Capturer Ecran CPC (16k)";
      this.Oprinter = "Ouvrir Console Imprimante";
      this.loadTXT = "Importer fichier ASCII";
      this.HexEdit = "Ouvrir Editeur Hex";
      this.FontEdit = "Ouvrir Editeur de polices";
      this.snapshot = "Sauvegarder Snapshot";
      this.binary = "Importer fichier CPC";
      this.poke = "Poke Memory";
      this.inspaint = "Lancer JavaCPC Paint";
      this.lostPaint = "Restaurer JavaCPC Paint DSK";
      this.export = "Exporter Binaire";
      this.cpcpalette = "Montrer Palette actuelle";
      this.digi = "Lancer Prodatron's Digitracker";
      this.digimc = "Lancer DigiTracker MOD converter";
      this.digipg = "Lancer Digitracker Player-Generator";
      this.checkjavacpc = "Vérifiez JavaCPC";
      this.checkup = "Vérifier Mise à jour";
      this.checkfos = "Rechercher une mise à jour de la ROM FutureOS";
      Main.fos_update = "Les Roms FutureOS ont été mises à jour en version %s1";
      Main.fos_uptodate = "Les ROMS FutureOS sont à jour";
      this.CPUfollow = "Laisser le désassembleur suivre le CPU";
      this.downl = "Visiter Page de téléchargements";
      this.homepage = "Visiter Page d'accueil";
      this.sourceforge = "Page Sourceforge Project";
      this.showYM = "Montrer Contrôles YM";
      this.showRec = "Enregistrer Audio";
      this.showCap = "Enregistrer Séquence GIF";
      this.showMov = "Enregistrer au format Quicktime MOV";
      this.inspectA = "Explorateur de fichiers";
      this.inspectB = "Explorateur de fichiers ";
      this.autocheck.setLabel("Vérifier automatiquement la mise à jour");
      this.inspector.setLabel("Ouvrir Explorateur de fichiers au chargement du DSK");
      this.checkFull.setLabel("Plein écran            Alt + Enter");
      this.cpc464t.setLabel("CPC 464");
      this.cpc464.setLabel("CPC 464 (Amsdos)");
      this.cpc664.setLabel("CPC 664");
      this.cpc6128.setLabel("CPC 6128");
      this.symbos.setLabel("SymbOS");
      this.futureos.setLabel("FutureOS");
      this.kccompact.setLabel("KC compact");
      this.customcpc.setLabel("Custom CPC");
      this.joyemu.setLabel("Joystick");
      this.qaop.setLabel("Contrôle Alternatif");
      this.joymouse.setLabel("Sourisjoystick");
      this.Expansioninfo = "Informations sur les commandes étendues";
      this.makCDT = "Créer un CDT";
      this.wav2cdt = "Samp2CDT";
      this.copyfloppy = "SamDisk";
      this.gfxviewer = "GFXViewer";
      this.screenmapper = "GameMapper (Screen)";
      this.mload = "Charger...";
      this.mcpm = "Démarrer CP/M";
      this.mejectall = "Tout éjecter";
      this.mmerge = "Fusionner DSK's...";
      this.mpaste = "Coller      F11";
      this.mquit = "Quitter";
      this.mforce = "Quitter de force";
      this.mabout = "A propos";
    } else {
      this.menue1.setLabel("File");
      this.reco = "Record Session";
      this.stoprec = "Stop Session";
      this.favo = "Favourite-Browser";
      this.asciicap = "CPC-Screen-to-ASCII    Shift + F11";
      this.menue2.setLabel("Emulation");
      this.menue3.setLabel("Settings");
      this.menue4.setLabel("Monitor");
      this.menue5.setLabel("Help");
      this.menue6.setLabel("Edit");
      this.extra.setLabel("Extras");
      this.notpad = "Little Notepad";
      this.dsk2cdt = "Copy files from DF0 as CDT";
      this.drives.setLabel("Drives");
      this.df0.setLabel("DF0:");
      this.df1.setLabel("DF1:");
      this.df2.setLabel("DF2:");
      this.df3.setLabel("DF3:");
      this.joymenu.setLabel("Joystick");
      this.keyboard.setLabel("Keyboard");
      this.tape.setLabel("Tape");
      this.statusbar.setLabel("Show Statusbar");
      this.changePolarity.setLabel("Change tape-polarity");
      this.keepprop.setLabel("Keep display proportions");
      this.mousewheel.setLabel("Mouse wheel zooms display");
      this.lightgun.setLabel("Enable Lightgun");
      this.autofire.setLabel("Autofire");
      this.watchsys.setLabel("Observe performance");
      this.shouldBoot.setLabel("Try to boot game");
      this.UseGzip.setLabel("Use GZip compression DSK, SNA, WAV");
      this.runds = "Play DeathSword";
      this.reportBug = "Report a bug";
      this.virtualkeys = "Open virtual keyboard";
      this.startrecord = "Start recording";
      this.stoprecord = "Stop recording";
      this.desktopsettings = "Desktop settings";
      this.videosettings = "Video settings";
      this.audiosettings = "Audio settings";
      this.miscsettings = "Misc. settings";
      this.systemsettings = "System settings";
      this.drivesettings = "Drive settings";
      this.romsettings = "Rom settings";
      this.resjoy = "Reset Joystickbuttons";
      this.Keys.setLabel(this.keys);
      this.RecKey.setLabel("Enable keyboard recording");
      this.recordkeys = "Keyboard recording info";
      this.tapeopen = "Show TapeDeck";
      this.tapeLoad = "Insert Tape";
      this.ejectTape = "Eject Tape";
      this.tapeLaunch = "Launch Tape";
      this.tapeSave = "Save Tape";
      this.tapeOptimize = "Optimize Tape";
      this.tapeConvert = "Convert CDT to WAV";
      this.format0 = "Format Disk";
      this.format1 = "Format Disk ";
      this.format2 = "Format Disk  ";
      this.format3 = "Format Disk   ";
      this.recrateA.setLabel("Use 44.1 khz rate (~13 min.) (best, works with CPCTapeXP!)");
      this.recrateB.setLabel("Use 22.0 khz rate (~25 min.) (Standard quality)");
      this.recrateC.setLabel("Use 11.5 khz rate (~50 min.) (Poor quality, bad results)");
      this.df0insert = "Insert";
      this.df1insert = "Insert ";
      this.df2insert = "Insert  ";
      this.df3insert = "Insert    ";
      this.df0sav = "Save";
      this.df1sav = "Save ";
      this.df2sav = "Save  ";
      this.df3sav = "Save   ";
      this.df0eject = "Eject";
      this.df1eject = "Eject ";
      this.df2eject = "Eject  ";
      this.df3eject = "Eject   ";
      this.df0create = "Create DSK";
      this.df1create = "Create DSK ";
      this.df2create = "Create DSK  ";
      this.df3create = "Create DSK   ";
      this.df0boot = "Try to boot";
      this.df1boot = "Try to boot ";
      this.df0save = "Save DSK as...";
      this.df1save = "Save DSK as... ";
      this.df2save = "Save DSK as...  ";
      this.df3save = "Save DSK as...   ";
      this.screenShot = "Save Screenshot     Ctrl + F11";
      this.catchSCR = "Catch CPC Screen (16k)";
      this.Oprinter = "Open printer console";
      this.loadTXT = "Import ASCII file";
      this.HexEdit = "Open Hex Editor";
      this.FontEdit = "Open Font Editor";
      this.snapshot = "Save snapshot file";
      this.binary = "Import CPC file";
      this.poke = "Poke Memory";
      this.inspaint = "Launch JavaCPC Paint";
      this.lostPaint = "Restore JavaCPC Paint DSK";
      this.export = "Export binary";
      this.cpcpalette = "Show actual palette";
      this.digi = "Launch Prodatron's Digitracker";
      this.digimc = "Launch DigiTracker MOD converter";
      this.digipg = "Launch Digitracker Player-Generator";
      this.checkjavacpc = "Check JavaCPC";
      this.checkup = "Check for update";
      this.checkfos = "Check for FutureOS ROM update";
      Main.fos_uptodate = "FutureOS ROMs are up to date";
      Main.fos_update = "FutureOS Roms updated to Version %s1";
      this.CPUfollow = "Let disassembler follow CPU";
      this.downl = "Visit download-page";
      this.homepage = "Visit homepage";
      this.sourceforge = "Sourceforge project page";
      this.showYM = "Show YM-Control";
      this.showRec = "Record audio";
      this.showCap = "Record GIF-Sequence";
      this.showMov = "Record Quicktime MOV";
      this.inspectA = "File inspector";
      this.inspectB = "File inspector ";
      this.autocheck.setLabel("Automatically check for updates");
      this.inspector.setLabel("Open file inspector on DSK load");
      this.checkFull.setLabel("Fullscreen            Alt + Enter");
      this.cpc464t.setLabel("CPC 464");
      this.cpc464.setLabel("CPC 464 (Amsdos)");
      this.cpc664.setLabel("CPC 664");
      this.cpc6128.setLabel("CPC 6128");
      this.symbos.setLabel("SymbOS");
      this.futureos.setLabel("FutureOS");
      this.kccompact.setLabel("KC compact");
      this.customcpc.setLabel("Custom CPC");
      this.joyemu.setLabel("Joystick");
      this.qaop.setLabel("Alternative control");
      this.joymouse.setLabel("Mousejoystick");
      this.Expansioninfo = "Expansion Info";
      this.makCDT = "Create a CDT";
      this.wav2cdt = "Samp2CDT";
      this.copyfloppy = "SamDisk";
      this.gfxviewer = "GFXViewer";
      this.screenmapper = "GameMapper (Screen)";
      this.mload = "Load...";
      this.mcpm = "Boot CP/M";
      this.mejectall = "Eject all";
      this.mmerge = "Merge DSK's...";
      this.mpaste = "Paste      F11";
      this.mquit = "Quit";
      this.mforce = "Force quit";
      this.mabout = "About";
    } 
    refreshMenu();
  }
  
  public static MenuBar JavaCPCMenu = new MenuBar();
  
  Menu menue1;
  
  String bdd;
  
  String cpcgamescd;
  
  String reco;
  
  String stoprec;
  
  String favo;
  
  String asciicap;
  
  Menu menue2;
  
  Menu menue3;
  
  Menu menue4;
  
  Menu menue5;
  
  Menu menue6;
  
  Menu extra;
  
  String notpad;
  
  String dsk2cdt;
  
  Menu drives;
  
  Menu df0;
  
  Menu df1;
  
  Menu df2;
  
  Menu df3;
  
  Menu joymenu;
  
  Menu keyboard;
  
  Menu tape;
  
  CheckboxMenuItem statusbar;
  
  CheckboxMenuItem changePolarity;
  
  CheckboxMenuItem keepprop;
  
  CheckboxMenuItem mousewheel;
  
  CheckboxMenuItem lightgun;
  
  CheckboxMenuItem autofire;
  
  CheckboxMenuItem watchsys;
  
  CheckboxMenuItem shouldBoot;
  
  CheckboxMenuItem UseGzip;
  
  String runds;
  
  String reportBug;
  
  String virtualkeys;
  
  String startrecord;
  
  String stoprecord;
  
  String desktopsettings;
  
  String videosettings;
  
  String audiosettings;
  
  String miscsettings;
  
  String systemsettings;
  
  String drivesettings;
  
  String romsettings;
  
  String resjoy;
  
  Menu Keys;
  
  CheckboxMenuItem RecKey;
  
  String recordkeys;
  
  String tapeopen;
  
  String tapeLoad;
  
  String ejectTape;
  
  String tapeLaunch;
  
  String tapeSave;
  
  String tapeOptimize;
  
  String tapeConvert;
  
  String format0;
  
  String format1;
  
  String format2;
  
  String format3;
  
  CheckboxMenuItem recrateA;
  
  CheckboxMenuItem recrateB;
  
  CheckboxMenuItem recrateC;
  
  String df0insert;
  
  String df1insert;
  
  String df2insert;
  
  String df3insert;
  
  String df0sav;
  
  String df1sav;
  
  String df2sav;
  
  String df3sav;
  
  String df0eject;
  
  String df1eject;
  
  String df2eject;
  
  String df3eject;
  
  String df0create;
  
  String df1create;
  
  String df2create;
  
  String df3create;
  
  String df0boot;
  
  String df1boot;
  
  String df0save;
  
  String df1save;
  
  String df2save;
  
  String df3save;
  
  String screenShot;
  
  String catchSCR;
  
  String Oprinter;
  
  String loadTXT;
  
  String HexEdit;
  
  String FontEdit;
  
  String snapshot;
  
  String binary;
  
  String poke;
  
  String inspaint;
  
  String fospaint;
  
  String insraster;
  
  String insmx;
  
  String lostPaint;
  
  String export;
  
  String cpcpalette;
  
  String digi;
  
  String digimc;
  
  String digipg;
  
  String checkjavacpc;
  
  String checkup;
  
  String checkfos;
  
  String CPUfollow;
  
  String downl;
  
  String homepage;
  
  String sourceforge;
  
  String showYM;
  
  String showRec;
  
  String showCap;
  
  String showMov;
  
  String inspectA;
  
  String inspectB;
  
  public static CheckboxMenuItem turbo = new CheckboxMenuItem("Turbo");
  
  public static CheckboxMenuItem z80turbo = new CheckboxMenuItem("Z80 Turbo");
  
  CheckboxMenuItem autocheck;
  
  CheckboxMenuItem inspector;
  
  CheckboxMenuItem checkFull;
  
  CheckboxMenuItem cpc464t;
  
  CheckboxMenuItem cpc464;
  
  CheckboxMenuItem cpc664;
  
  CheckboxMenuItem cpc6128;
  
  CheckboxMenuItem symbos;
  
  CheckboxMenuItem futureos;
  
  CheckboxMenuItem kccompact;
  
  CheckboxMenuItem customcpc;
  
  CheckboxMenuItem joyemu;
  
  CheckboxMenuItem qaop;
  
  CheckboxMenuItem joymouse;
  
  String Expansioninfo;
  
  String makCDT;
  
  String wav2cdt;
  
  String copyfloppy;
  
  String gfxviewer;
  
  String screenmapper;
  
  String mload;
  
  String mcpm;
  
  String mejectall;
  
  String mmerge;
  
  String mquit;
  
  String mforce;
  
  String mpaste;
  
  String mabout;
  
  int undocktick;
  
  boolean snapmouse;
  
  Robot robot;
  
  public void open(int index) {
    try {
      this.options.setVisible(true);
    } catch (Exception e) {
      Desktop.options.setVisible(true);
      Desktop.options.toFront();
    } 
    Desktop.open(index);
  }
  
  public void refreshMenu() {
    this.menue1.removeAll();
    this.menue2.removeAll();
    this.menue3.removeAll();
    this.menue4.removeAll();
    this.menue5.removeAll();
    this.menue6.removeAll();
    this.drives.removeAll();
    this.df0.removeAll();
    this.df1.removeAll();
    this.df2.removeAll();
    this.df3.removeAll();
    this.tape.removeAll();
    this.joymenu.removeAll();
    this.keyboard.removeAll();
    this.extra.removeAll();
    if (isWindows()) {
      this.extra.add("Joy2Key");
      this.extra.add(this.makCDT);
      this.extra.add(this.wav2cdt);
      this.extra.add(this.copyfloppy);
      this.extra.addSeparator();
    } 
    JavaCPCMenu.setFont(new Font("", 0, 11));
    this.menue1.add(this.mload);
    this.menue1.add(this.mcpm);
    this.menue1.add(this.drives);
    this.drives.add(this.df0);
    this.df0.add(this.df0insert);
    this.df0.add(this.df0boot);
    this.df0.add(this.inspectA);
    this.df0.add(this.format0);
    this.df0.add(this.df0eject);
    this.df0.addSeparator();
    this.df0.add(this.df0create);
    this.df0.add(this.df0sav);
    this.df0.add(this.df0save);
    this.drives.add(this.df1);
    this.df1.add(this.df1insert);
    this.df1.add(this.df1boot);
    this.df1.add(this.inspectB);
    this.df1.add(this.format1);
    this.df1.add(this.df1eject);
    this.df1.addSeparator();
    this.df1.add(this.df1create);
    this.df1.add(this.df1sav);
    this.df1.add(this.df1save);
    this.drives.addSeparator();
    this.drives.add(this.df2);
    this.df2.add(this.df2insert);
    this.df2.add(this.format2);
    this.df2.add(this.df2eject);
    this.df2.addSeparator();
    this.df2.add(this.df2create);
    this.df2.add(this.df2sav);
    this.df2.add(this.df2save);
    this.drives.add(this.df3);
    this.df3.add(this.df3insert);
    this.df3.add(this.format3);
    this.df3.add(this.df3eject);
    this.df3.addSeparator();
    this.df3.add(this.df3create);
    this.df3.add(this.df3sav);
    this.df3.add(this.df3save);
    this.drives.addSeparator();
    this.drives.add(this.mejectall);
    this.menue1.addSeparator();
    this.menue1.add(this.favo);
    this.menue1.addSeparator();
    this.menue1.add(this.mmerge);
    this.menue1.addSeparator();
    this.menue1.add(this.UseGzip);
    this.menue1.addSeparator();
    this.menue1.add(this.tape);
    this.tape.add(this.tapeLoad);
    this.tape.add(this.tapeLaunch);
    this.tape.add(this.tapeSave);
    this.tape.add(this.ejectTape);
    this.tape.add(this.tapeOptimize);
    this.tape.add(this.tapeConvert);
    this.tape.add(this.tapeopen);
    this.tape.addSeparator();
    this.tape.add(this.recrateA);
    this.tape.add(this.recrateB);
    this.tape.add(this.recrateC);
    this.menue1.addSeparator();
    this.menue1.add(this.loadTXT);
    this.menue1.add(this.binary);
    this.menue1.add(this.export);
    this.menue1.addSeparator();
    this.menue1.add(this.snapshot);
    this.menue1.add(this.showRec);
    this.menue1.add(this.showCap);
    this.menue1.add(this.showMov);
    this.menue1.addSeparator();
    this.menue1.add(this.mforce);
    this.menue1.add(this.mquit);
    this.menue2.add("Pause");
    this.menue2.add("Reset            Ctrl + F9");
    this.menue2.add("Reboot");
    this.menue2.addSeparator();
    this.menue2.add(turbo);
    this.menue2.add(z80turbo);
    this.menue2.addSeparator();
    this.menue2.add(this.Expansioninfo);
    this.menue3.add(this.desktopsettings);
    this.menue3.add(this.videosettings);
    this.menue3.add(this.audiosettings);
    this.menue3.add(this.miscsettings);
    this.menue3.add(this.systemsettings);
    this.menue3.add(this.drivesettings);
    this.menue3.add(this.romsettings);
    this.menue3.addSeparator();
    this.menue3.add(this.resjoy);
    this.menue3.addSeparator();
    this.menue3.add(this.inspector);
    this.menue3.add(this.shouldBoot);
    this.menue3.addSeparator();
    this.menue3.add(this.changePolarity);
    this.menue3.addSeparator();
    this.menue3.add(this.joymenu);
    this.joymenu.add(this.lightgun);
    this.joymenu.add(this.joyemu);
    this.joymenu.add(this.qaop);
    this.joymenu.addSeparator();
    this.joymenu.add(this.joymouse);
    this.joymenu.add(this.autofire);
    this.menue3.addSeparator();
    this.menue3.add(this.keyboard);
    this.keyboard.add(this.Keys);
    this.menue3.addSeparator();
    this.menue3.add(this.watchsys);
    this.menue3.addSeparator();
    this.menue3.add(this.statusbar);
    this.menue4.addSeparator();
    this.menue4.add(this.checkFull);
    this.menue4.addSeparator();
    this.menue4.addSeparator();
    this.menue4.add(this.keepprop);
    this.menue4.add(this.mousewheel);
    this.menue5.add("Debugger");
    this.menue5.add("MultiDebugger");
    this.menue5.add(this.CPUfollow);
    this.menue5.addSeparator();
    this.menue5.add(this.gfxviewer);
    this.menue5.add(this.screenmapper);
    this.menue5.addSeparator();
    this.menue5.add("Please RickRoll me");
    this.menue5.addSeparator();
    this.menue5.add(this.checkjavacpc);
    this.menue5.add(this.checkup);
    this.menue5.add(this.checkfos);
    this.menue5.add(this.autocheck);
    this.menue5.addSeparator();
    this.menue5.add(this.lostPaint);
    this.menue5.add(this.downl);
    this.menue5.add(this.homepage);
    this.menue5.add(this.sourceforge);
    this.menue5.addSeparator();
    this.menue5.add(this.reportBug);
    this.menue5.add(this.mabout);
    this.menue6.add("Autotype");
    this.menue6.add(this.mpaste);
    this.menue6.add("Z80 Assembler");
    this.menue6.addSeparator();
    this.menue6.add(this.asciicap);
    this.menue6.add(this.virtualkeys);
    this.menue6.addSeparator();
    this.menue6.add(this.poke);
    this.menue6.addSeparator();
    this.menue6.add(this.inspaint);
    this.menue6.add(this.insraster);
    this.menue6.add(this.insmx);
    this.menue6.add(this.fospaint);
    this.menue6.addSeparator();
    this.menue6.add(this.catchSCR);
    this.menue6.add(this.screenShot);
    this.menue6.addSeparator();
    this.menue6.add(this.showYM);
    this.menue6.addSeparator();
    this.menue6.add(this.Oprinter);
    this.menue6.add(this.HexEdit);
    this.menue6.add(this.FontEdit);
    this.menue6.addSeparator();
    this.menue6.add(this.cpcpalette);
    this.menue6.add(this.notpad);
    this.menue6.add(this.dsk2cdt);
    this.menue6.add("DSKUtil");
    this.extra.add(this.digi);
    this.extra.add(this.digimc);
    this.extra.add(this.digipg);
    this.extra.addSeparator();
    this.extra.add(this.bdd);
    this.extra.add(this.cpcgamescd);
    this.extra.addSeparator();
    this.extra.add(this.runds);
    JavaCPCMenu.add(this.menue1);
    JavaCPCMenu.add(this.menue6);
    JavaCPCMenu.add(this.menue2);
    JavaCPCMenu.add(this.menue3);
    JavaCPCMenu.add(this.menue4);
    JavaCPCMenu.add(this.extra);
    JavaCPCMenu.add(this.menue5);
  }
  
  public void SetMenu() {
    turbo.addItemListener(this);
    z80turbo.addItemListener(this);
    this.extra.addActionListener(this);
    this.menue1.addActionListener(this);
    this.menue2.addActionListener(this);
    this.menue3.addActionListener(this);
    this.menue4.addActionListener(this);
    this.menue5.addActionListener(this);
    this.menue6.addActionListener(this);
    this.tape.addActionListener(this);
    this.autocheck.addItemListener(this);
    this.inspector.addItemListener(this);
    this.df0.addActionListener(this);
    this.df1.addActionListener(this);
    this.df2.addActionListener(this);
    this.df3.addActionListener(this);
    this.joymenu.addActionListener(this);
    this.drives.addActionListener(this);
    this.keyboard.addActionListener(this);
    this.Keys.addActionListener(this);
    this.statusbar.addItemListener(this);
    this.changePolarity.addItemListener(this);
    this.keepprop.addItemListener(this);
    this.mousewheel.addItemListener(this);
    this.lightgun.addItemListener(this);
    this.autofire.addItemListener(this);
    this.watchsys.addItemListener(this);
    this.RecKey.addItemListener(this);
    this.shouldBoot.addItemListener(this);
    this.UseGzip.addItemListener(this);
    this.recrateA.addItemListener(this);
    this.recrateB.addItemListener(this);
    this.recrateC.addItemListener(this);
    this.checkFull.addItemListener(this);
    this.cpc464t.addItemListener(this);
    this.cpc464.addItemListener(this);
    this.cpc664.addItemListener(this);
    this.cpc6128.addItemListener(this);
    this.symbos.addItemListener(this);
    this.futureos.addItemListener(this);
    this.kccompact.addItemListener(this);
    this.customcpc.addItemListener(this);
    this.joyemu.addItemListener(this);
    this.qaop.addItemListener(this);
    this.joymouse.addItemListener(this);
  }
  
  public void mouseMoved(MouseEvent me) {
    if (SF2Mouse) {
      mouseMove(me);
      return;
    } 
    if (undocked) {
      this.undockpanel.setBorder(new LineBorder(Color.blue, 10));
      this.undocktick = 40;
    } 
    if (fullscreen) {
      this.ypos = me.getYOnScreen();
      if (this.ypos <= 10 && !this.showmenu) {
        this.hidemenu = 0;
        this.showmenu = true;
        if (!Desktop.started && frame != null)
          frame.setMenuBar(JavaCPCMenu); 
      } else if (this.ypos >= 20 && this.showmenu) {
        this.hidemenu = 1;
      } 
    } 
    if (!Switches.blockKeyboard) {
      this.xpos = me.getXOnScreen();
      this.ypos = me.getYOnScreen();
      this.snapmouse = this.mousejoy;
      if (this.mousejoy) {
        if (this.xoldpos < this.xpos) {
          Switches.directR = 0;
          Switches.directxR = "Right";
          Switches.directxL = "Stop";
        } 
        if (this.xoldpos > this.xpos) {
          Switches.directL = 0;
          Switches.directxR = "Stop";
          Switches.directxL = "Left";
        } 
        if (this.yoldpos > this.ypos) {
          Switches.directU = 0;
          Switches.directyU = "Up";
          Switches.directyD = "Stop";
        } 
        if (this.yoldpos < this.ypos) {
          Switches.directD = 0;
          Switches.directyU = "Stop";
          Switches.directyD = "Down";
        } 
      } 
      this.xoldpos = this.xpos;
      this.yoldpos = this.ypos;
    } 
    if (this.snapmouse) {
      this.resetmouse++;
      if (this.resetmouse > 30) {
        this.resetmouse = 0;
        if (this.robot != null) {
          robotCenter(this.display.getLocationOnScreen());
          this.xpos = me.getXOnScreen();
          this.ypos = me.getYOnScreen();
          this.xoldpos = this.xpos;
          this.yoldpos = this.ypos;
        } else {
          try {
            this.robot = new Robot();
          } catch (Throwable e) {
            System.out.println("Applet is not signed, mouse capture will not work");
          } 
        } 
      } 
    } 
  }
  
  public void robotCenter(Point rel) {
    this.robot.mouseMove(rel.x + this.display.getWidth() / 2, rel.y + this.display.getHeight() / 2);
  }
  
  private static Point point = new Point();
  
  int dwidth;
  
  int dheight;
  
  int resetmouse;
  
  JButton makeshot;
  
  JButton cancelshot;
  
  JButton startRec;
  
  JButton pauseRec;
  
  JButton stopRec;
  
  protected boolean pauserec;
  
  protected JCheckBox compress;
  
  boolean dialogsnap;
  
  double mousezoom;
  
  public void mouseDragged(MouseEvent me) {
    if (SF2Mouse) {
      mouseMove(me);
      return;
    } 
    if (this.undockframe != null && this.undockframe.isVisible()) {
      System.out.println(me.getX() + "," + me.getY() + " - " + me.getSource().getClass().getName());
      if (me.getY() > this.undockframe.getHeight() - 40 && me.getX() > this.undockframe.getWidth() - 40) {
        Point p = this.undockframe.getLocation();
        this.undockframe.setSize(this.dwidth + me.getX() - point.x, this.dheight + me.getY() - point.y);
        return;
      } 
      if (point.y < 20 && point.x > 6 && point.x < this.undockframe.getWidth() - 6) {
        Point p = this.undockframe.getLocation();
        this.undockframe.setLocation(p.x + me.getX() - point.x, p.y + me.getY() - point.y);
        return;
      } 
      if (point.y >= 6 || point.x > 6 || point.x >= this.undockframe.getWidth() - 6);
    } 
    if (!Switches.blockKeyboard) {
      this.xpos = me.getXOnScreen();
      this.ypos = me.getYOnScreen();
      if (this.mousejoy) {
        if (this.xoldpos < this.xpos) {
          Switches.directR = 0;
          Switches.directxR = "Right";
          Switches.directxL = "Stop";
        } 
        if (this.xoldpos > this.xpos) {
          Switches.directL = 0;
          Switches.directxR = "Stop";
          Switches.directxL = "Left";
        } 
        if (this.yoldpos > this.ypos) {
          Switches.directU = 0;
          Switches.directyU = "Up";
          Switches.directyD = "Stop";
        } 
        if (this.yoldpos < this.ypos) {
          Switches.directD = 0;
          Switches.directyU = "Stop";
          Switches.directyD = "Down";
        } 
        if ((me.getModifiers() & 0x10) != 0) {
          this.computer.MouseFire1();
        } else {
          this.computer.MouseFire2();
        } 
      } 
    } 
    this.xoldpos = this.xpos;
    this.yoldpos = this.ypos;
    if (this.snapmouse) {
      this.resetmouse++;
      if (this.resetmouse > 30) {
        this.resetmouse = 0;
        if (this.robot != null) {
          robotCenter(this.display.getLocationOnScreen());
          this.xpos = me.getXOnScreen();
          this.ypos = me.getYOnScreen();
          this.xoldpos = this.xpos;
          this.yoldpos = this.ypos;
        } else {
          try {
            this.robot = new Robot();
          } catch (Throwable e) {
            System.out.println("Applet is not signed, mouse capture will not work");
          } 
        } 
      } 
    } 
  }
  
  protected void fsoundInit() {
    if (this.fsound) {
      Switches.FloppySound = true;
      System.out.println("Floppysound Enabled");
    } else {
      Switches.FloppySound = false;
      System.out.println("Audio Disabled");
    } 
  }
  
  public void screenshot() {
    if (this.executable && frame != null)
      frame.setAlwaysOnTop(false); 
    this.images = new BufferedImage(this.display.getImage().getWidth(this.sprev), this.display.getImage().getHeight(this.sprev), 4);
    this.images.getGraphics().drawImage(this.display.getImage(), 0, 0, this.display.getImage().getWidth(this.sprev), this.display.getImage().getHeight(this.sprev), null);
    screenPreview();
    screenshottimer = 0;
    screentimer = 0;
    this.computer.reSync();
    if (this.executable && frame != null)
      frame.setAlwaysOnTop(onTop); 
  }
  
  protected void screenPreview() {
    if (this.screenpreview == null) {
      this.screenpreview = new JFrame() {
          protected void processWindowEvent(WindowEvent e) {
            super.processWindowEvent(e);
            if (e.getID() == 201) {
              JEMU.this.screenpreview.dispose();
              JEMU.this.initRec = false;
            } 
          }
          
          public synchronized void setTitle(String title) {
            super.setTitle(title);
            enableEvents(64L);
          }
        };
      this.screenpreview.addKeyListener(this);
    } 
    this.screenpreview.remove(this.sprev);
    this.screenpreview.remove(this.startRec);
    this.screenpreview.remove(this.pauseRec);
    this.screenpreview.remove(this.stopRec);
    this.screenpreview.remove(this.sprev);
    this.screenpreview.remove(this.makeshot);
    this.screenpreview.remove(this.cancelshot);
    if (!this.screenpreview.isVisible())
      this.screenpreview.setVisible(true); 
    this.makeshot.setFocusable(false);
    this.cancelshot.setFocusable(false);
    this.screenpreview.setLayout(new GridBagLayout());
    this.screenpreview.setTitle("Screenshot");
    ImageIcon spr = null;
    spr = new ImageIcon(this.images);
    this.sprev = new JLabel(spr);
    this.screenpreview.add(this.sprev, getGridBagConstraints(1, 1, 0.0D, 0.0D, 2, 1));
    this.screenpreview.add(this.makeshot, getGridBagConstraints(1, 2, 1.0D, 1.0D, 1, 1));
    this.screenpreview.add(this.cancelshot, getGridBagConstraints(2, 2, 1.0D, 1.0D, 1, 1));
    this.screenpreview.pack();
    this.screenpreview.setResizable(false);
  }
  
  public void saveShot() {
    String savename = putFile("Screenshot image");
    if (savename != null)
      try {
        if (savename.toLowerCase().endsWith(".png")) {
          File file = new File(savename);
          ImageIO.write(this.images, "png", file);
        } else if (savename.toLowerCase().endsWith(".gif")) {
          File file = new File(savename);
          ImageIO.write(this.images, "gif", file);
        } else if (savename.toLowerCase().endsWith(".bmp")) {
          File file = new File(savename);
          ImageIO.write(this.images, "bmp", file);
        } else if (savename.toLowerCase().endsWith(".jpg")) {
          File file = new File(savename);
          ImageIO.write(this.images, "jpg", file);
        } else {
          savename = savename + ".png";
          File file = new File(savename);
          ImageIO.write(this.images, "png", file);
        } 
      } catch (Exception e) {
        e.printStackTrace();
      }  
  }
  
  public void UpdateCheck(boolean autocheck) throws Exception {
    Main.checkUpdate(autocheck);
  }
  
  public void RecInfo() {
    JOptionPane.showMessageDialog(null, "Use CRTL + Numpad-1 to start recording\nUse CRTL + Numpad-2 to stop & save recording\nUse CRTL + Numpad-1 to start playback\n");
  }
  
  public void ShowInfo() throws Exception {
    URL url = new URL("http://cpc-live.com/updateinfo.txt");
    this.update = "";
    URLConnection uc = url.openConnection();
    InputStreamReader input = new InputStreamReader(uc.getInputStream());
    BufferedReader in = new BufferedReader(input);
    String inputLine;
    while ((inputLine = in.readLine()) != null)
      this.update += inputLine + "\n"; 
    System.out.println(this.update);
    JOptionPane.showMessageDialog(null, this.update);
  }
  
  public static void openWebPage(String weburl) {
    try {
      URL url = new URL(weburl);
      if (isWindows()) {
        Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + url);
      } else {
        Runtime.getRuntime().exec("firefox " + url);
      } 
    } catch (IOException ioe) {
      ioe.printStackTrace();
    } 
  }
  
  public void ExpansionRom() {
    String oldSys = getComputer().getName();
    System.out.println("Oldsys is:" + oldSys);
    try {
      setComputer(oldSys);
    } catch (Exception exception) {}
    LoadFiles();
  }
  
  public void ExpansionInfo() {
    String info = "|SHOW - open printer console\n|HIDE - hide printer console\n|ONLINE - sets printer online\n|OFFLINE - sets printer offline\n|CLEAR - clears printer console content\n|BIGGER - increases fontsize of printer\n|SMALLER - decreases fontsize\n|SIZE,[size] - sets fontsize in pt\n|FONT1 - |FONT9 - sets printerfont\n|QUIT - quits JavaCPC emulator\n|GREEN - emulates greenmonitor\n|GRAY / |GREY - emulates graymonitor\n|COLOR / |COLOUR - colourmonitor\n|32INKS - emulates JavaCPC specialinks\n|SCREENSHOT - Saves a screenshot\n|SAVEDSK - Lets the user save actual DSK in DF0\n|MAKEDSK - creates a DATA formatted DSK\n|SCANLINES - enables scanlines\n|SCANLINESOFF - disables scanlines\n|INFO / |HELP - this info";
    JOptionPane.showMessageDialog(this, info);
  }
  
  public void addSkin() {
    if (this.Monitoruppanel == null) {
      this.Monitoruppanel = getControlPanel();
      this.Monitoruppanel.setBackground(Color.DARK_GRAY);
      this.Monitordownpanel = getControlPanel();
      this.Monitordownpanel.setBackground(Color.DARK_GRAY);
      this.Monitorleftpanel = getControlPanel();
      this.Monitorleftpanel.setBackground(Color.DARK_GRAY);
      this.Monitorrightpanel = getControlPanel();
      this.Monitorrightpanel.setBackground(Color.DARK_GRAY);
    } 
    int[] pixelsc = new int[256];
    Image imagec = Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(16, 16, pixelsc, 0, 16));
    Cursor blankCursor = Toolkit.getDefaultToolkit().createCustomCursor(imagec, new Point(0, 0), "invisibleCursor");
    this.Monitoruppanel.setCursor(blankCursor);
    this.Monitordownpanel.setCursor(blankCursor);
    this.Monitorleftpanel.setCursor(blankCursor);
    this.Monitorrightpanel.setCursor(blankCursor);
    this.Moniup.addMouseListener(this);
    this.Moniup.addMouseMotionListener(this);
    this.Monidown.addMouseListener(this);
    this.Monidown.addMouseMotionListener(this);
    this.Monileft.addMouseListener(this);
    this.Monileft.addMouseMotionListener(this);
    this.Moniright.addMouseListener(this);
    this.Moniright.addMouseMotionListener(this);
    this.Moniup.addKeyListener(this);
    this.Monidown.addKeyListener(this);
    this.Monileft.addKeyListener(this);
    this.Moniright.addKeyListener(this);
    this.Monitoruppanel.add(this.Moniup, getGridBagConstraints(0, 0, 0.0D, 0.0D, 1, 1));
    this.Monitordownpanel.add(this.Monidown, getGridBagConstraints(0, 0, 0.0D, 0.0D, 1, 1));
    this.Monitorleftpanel.add(this.Monileft, getGridBagConstraints(0, 0, 0.0D, 0.0D, 1, 1));
    this.Monitorrightpanel.add(this.Moniright, getGridBagConstraints(0, 0, 0.0D, 0.0D, 1, 1));
  }
  
  public void saveSNA() {
    try {
      SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              JEMU.this.chooseSNA();
            }
          });
    } catch (Exception e) {
      e.printStackTrace();
    } 
    System.gc();
  }
  
  public void loadSNA() {
    try {
      SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              JEMU.this.getFile("Snapshot file", true, 0);
            }
          });
    } catch (Exception e) {
      e.printStackTrace();
    } 
    System.gc();
  }
  
  public void chooseSNA() {
    if (this.snaChooser == null)
      this.snaChooser = new SNAChooser(); 
    BufferedImage snap = new BufferedImage(384, 272, 1);
    snap.getGraphics().drawImage(Display.image, 0, 0, 384, 272, null);
    this.snaChooser.disp.setIcon(new ImageIcon(snap));
    wantsna = true;
    this.snaChooser.setVisible(true);
  }
  
  public void Quit() {
    this.QuitTimer = 1;
  }
  
  public void setFreeSized(boolean value) {
    if (!large) {
      this.computer.stop();
      this.computer.setLarge(true);
      this.display.setImageSize(this.computer.getDisplaySize(true), this.computer.getDisplayScale(true));
      this.computer.setDisplay(this.display);
      this.computer.start();
      large = true;
    } 
    Switches.doublesize = false;
    Switches.triplesize = false;
    Switches.quadsize = false;
    Switches.freesize = value;
    if (value) {
      if (this.skinned) {
        this.Moniup.setVisible(false);
        this.Monidown.setVisible(false);
        this.Monileft.setVisible(false);
        this.Moniright.setVisible(false);
      } 
    } else if (this.skinned && large != true) {
      this.Moniup.setVisible(true);
      this.Monidown.setVisible(true);
      this.Monileft.setVisible(true);
      this.Moniright.setVisible(true);
    } 
    boolean running = this.computer.isRunning();
    this.computer.setLarge(large);
    this.display.setImageSize(this.computer.getDisplaySize(large), this.computer.getDisplayScale(large));
    this.computer.setDisplay(this.display);
    if (running)
      this.computer.start(); 
    Settings.setBoolean("large", value ? false : large);
    Settings.setBoolean("double_size", Switches.doublesize);
    Settings.setBoolean("triple_size", Switches.triplesize);
    Settings.setBoolean("quadro_size", Switches.quadsize);
    Settings.setBoolean("free_size", Switches.freesize);
    setOutputSize();
    this.display.requestFocus();
  }
  
  public void setSimpleSized() {
    setFullSized(true);
    if (this.skinned) {
      this.Moniup.setVisible(false);
      this.Monidown.setVisible(false);
      this.Monileft.setVisible(false);
      this.Moniright.setVisible(false);
    } 
    if (large)
      setFullSize(false); 
    Switches.quadsize = false;
    Switches.triplesize = false;
    Switches.doublesize = false;
    Switches.freesize = false;
    boolean running = this.computer.isRunning();
    this.computer.setLarge(large);
    this.display.setImageSize(this.computer.getDisplaySize(large), this.computer.getDisplayScale(large));
    this.computer.setDisplay(this.display);
    if (running)
      this.computer.start(); 
    Settings.setBoolean("large", large);
    Settings.setBoolean("double_size", Switches.doublesize);
    Settings.setBoolean("triple_size", Switches.triplesize);
    Settings.setBoolean("quadro_size", Switches.quadsize);
    Settings.setBoolean("free_size", Switches.freesize);
    if (this.skinned) {
      this.Moniup.setVisible(true);
      this.Monidown.setVisible(true);
      this.Monileft.setVisible(true);
      this.Moniright.setVisible(true);
    } 
    setOutputSize();
    this.display.requestFocus();
    repaint();
  }
  
  public void setDoubleSized(boolean value) {
    if (!large)
      setFullSize(true); 
    Switches.triplesize = false;
    Switches.quadsize = false;
    Switches.doublesize = value;
    Switches.freesize = false;
    if (Switches.doublesize) {
      if (this.skinned) {
        this.Moniup.setVisible(false);
        this.Monidown.setVisible(false);
        this.Monileft.setVisible(false);
        this.Moniright.setVisible(false);
      } 
    } else if (this.skinned && !large) {
      this.Moniup.setVisible(true);
      this.Monidown.setVisible(true);
      this.Monileft.setVisible(true);
      this.Moniright.setVisible(true);
    } 
    boolean running = this.computer.isRunning();
    this.computer.setLarge(large);
    this.display.setImageSize(this.computer.getDisplaySize(large), this.computer.getDisplayScale(large));
    this.computer.setDisplay(this.display);
    if (running)
      this.computer.start(); 
    Settings.setBoolean("large", large);
    Settings.setBoolean("double_size", Switches.doublesize);
    Settings.setBoolean("triple_size", Switches.triplesize);
    Settings.setBoolean("quadro_size", Switches.quadsize);
    Settings.setBoolean("free_size", Switches.freesize);
    setOutputSize();
    this.display.requestFocus();
  }
  
  public void setTripleSized(boolean value) {
    if (!large) {
      this.computer.stop();
      this.computer.setLarge(true);
      this.display.setImageSize(this.computer.getDisplaySize(true), this.computer.getDisplayScale(true));
      this.computer.setDisplay(this.display);
      this.computer.start();
      large = true;
    } 
    Switches.doublesize = false;
    Switches.quadsize = false;
    Switches.triplesize = value;
    Switches.freesize = false;
    if (Switches.triplesize) {
      if (this.skinned) {
        this.Moniup.setVisible(false);
        this.Monidown.setVisible(false);
        this.Monileft.setVisible(false);
        this.Moniright.setVisible(false);
      } 
    } else if (this.skinned && large != true) {
      this.Moniup.setVisible(true);
      this.Monidown.setVisible(true);
      this.Monileft.setVisible(true);
      this.Moniright.setVisible(true);
    } 
    boolean running = this.computer.isRunning();
    this.computer.setLarge(large);
    this.display.setImageSize(this.computer.getDisplaySize(large), this.computer.getDisplayScale(large));
    this.computer.setDisplay(this.display);
    if (running)
      this.computer.start(); 
    Settings.setBoolean("large", value ? false : large);
    Settings.setBoolean("double_size", Switches.doublesize);
    Settings.setBoolean("triple_size", Switches.triplesize);
    Settings.setBoolean("quadro_size", Switches.quadsize);
    Settings.setBoolean("free_size", Switches.freesize);
    setOutputSize();
    this.display.requestFocus();
  }
  
  public void setQuadSized(boolean value) {
    if (!large) {
      this.computer.stop();
      this.computer.setLarge(true);
      this.display.setImageSize(this.computer.getDisplaySize(true), this.computer.getDisplayScale(true));
      this.computer.setDisplay(this.display);
      this.computer.start();
      large = true;
    } 
    Switches.doublesize = false;
    Switches.triplesize = false;
    Switches.quadsize = value;
    Switches.freesize = false;
    if (value) {
      if (this.skinned) {
        this.Moniup.setVisible(false);
        this.Monidown.setVisible(false);
        this.Monileft.setVisible(false);
        this.Moniright.setVisible(false);
      } 
    } else if (this.skinned && large != true) {
      this.Moniup.setVisible(true);
      this.Monidown.setVisible(true);
      this.Monileft.setVisible(true);
      this.Moniright.setVisible(true);
    } 
    boolean running = this.computer.isRunning();
    this.computer.setLarge(large);
    this.display.setImageSize(this.computer.getDisplaySize(large), this.computer.getDisplayScale(large));
    this.computer.setDisplay(this.display);
    if (running)
      this.computer.start(); 
    Settings.setBoolean("large", value ? false : large);
    Settings.setBoolean("double_size", Switches.doublesize);
    Settings.setBoolean("triple_size", Switches.triplesize);
    Settings.setBoolean("quadro_size", Switches.quadsize);
    Settings.setBoolean("free_size", Switches.freesize);
    setOutputSize();
    this.display.requestFocus();
  }
  
  public void setFullSized(boolean value) {
    Switches.triplesize = false;
    Switches.doublesize = false;
    Switches.quadsize = false;
    Switches.freesize = false;
    large = value;
    if (large) {
      if (this.skinned) {
        this.Moniup.setVisible(false);
        this.Monidown.setVisible(false);
        this.Monileft.setVisible(false);
        this.Moniright.setVisible(false);
      } 
    } else if (this.skinned) {
      this.Moniup.setVisible(true);
      this.Monidown.setVisible(true);
      this.Monileft.setVisible(true);
      this.Moniright.setVisible(true);
    } 
    boolean running = this.computer.isRunning();
    this.computer.setLarge(large);
    this.display.setImageSize(this.computer.getDisplaySize(large), this.computer.getDisplayScale(large));
    this.computer.setDisplay(this.display);
    if (running)
      this.computer.start(); 
    Settings.setBoolean("large", value);
    Settings.setBoolean("double_size", Switches.doublesize);
    Settings.setBoolean("triple_size", Switches.triplesize);
    Settings.setBoolean("quadro_size", Switches.quadsize);
    Settings.setBoolean("free_size", Switches.freesize);
    setOutputSize();
    this.display.requestFocus();
  }
  
  public static boolean SF2Mouse = false;
  
  int oldX;
  
  int oldY;
  
  int distX;
  
  int distY;
  
  public void mouseMove(MouseEvent me) {
    int newX = me.getX();
    int newY = me.getY();
    if (this.oldX == -1) {
      this.oldX = newX;
      this.oldY = newY;
      return;
    } 
    this.distX = this.oldX - newX;
    this.distY = this.oldY - newY;
    if (this.distX < -100)
      this.distX = -100; 
    if (this.distY < -100)
      this.distY = -100; 
    if (this.distX > 100)
      this.distX = 100; 
    if (this.distY > 100)
      this.distY = 100; 
    this.oldX = newX;
    this.oldY = newY;
    GateArray.cpc.writeMouseMove(-((int)(this.distX * 1.5D)), -((int)this.distY));
  }
  
  private void formMouseWheelMoved(MouseWheelEvent evt) {
    if (fullscreen)
      return; 
    if (SF2Mouse) {
      int i = evt.getWheelRotation();
      GateArray.cpc.writeMouseWheel(i);
      return;
    } 
    if (this.mousewheel.getState())
      try {
        if (evt.getUnitsToScroll() > 0) {
          if (this.mousezoom > 0.5D) {
            this.mousezoom -= 0.125D;
            Settings.set("zoomfactor", Double.toString(this.mousezoom));
            setOutputSize();
            if (!Desktop.freeSize.isSelected())
              Desktop.freeSize.setSelected(true); 
          } 
        } else if (evt.getUnitsToScroll() < 0 && this.mousezoom < 10.0D) {
          this.mousezoom += 0.125D;
          Settings.set("zoomfactor", Double.toString(this.mousezoom));
          setOutputSize();
          if (!Desktop.freeSize.isSelected())
            Desktop.freeSize.setSelected(true); 
        } 
      } catch (Exception exception) {} 
  }
  
  public void setOutputSize() {
    if (this.executable) {
      if (!Desktop.started && frame != null)
        frame.remove(JavaCPCMenu); 
      if (fullscreen) {
        this.statpan.setVisible(false);
      } else {
        this.statpan.setVisible((this.mousezoom > 1.8D) ? this.showStatus : false);
        this.statusbar.setState((this.mousezoom > 1.8D) ? this.showStatus : false);
      } 
      Dimension p = Toolkit.getDefaultToolkit().getScreenSize();
      int w = 384;
      int h = 272;
      w = (int)(w * this.mousezoom);
      h = (int)(h * this.mousezoom);
      if (fullscreen) {
        w = p.width;
        h = p.height;
      } 
      this.display.setSize(w, h);
      if (!fullscreen && !Desktop.started && frame != null)
        frame.setMenuBar(JavaCPCMenu); 
      if (iframe != null) {
        iframe.pack();
        iframe.setLocation(screenXstored, screenYstored);
      } 
      if (frame != null) {
        frame.pack();
        frame.setLocation(screenXstored, screenYstored);
      } 
      if (fullscreen && frame != null)
        frame.setLocation((p.width - (frame.getSize()).width) / 2, (p.height - (frame.getSize()).height) / 2); 
      this.computer.start();
      this.computer.reSync();
      this.display.requestFocus();
      this.display.showZoom(Double.toString(this.mousezoom));
    } 
    if (!Switches.doublesize && !large) {
      if (this.ziplab.isVisible())
        this.stpanel.setVisible(false); 
    } else {
      this.stpanel.setVisible(true);
    } 
  }
  
  public void showDevices() {
    Vector<String> devices = this.computer.getDevices();
    int n = devices.size();
    for (int i = 0; i < n; i++)
      System.out.println("Device connected: " + devices.get(i)); 
  }
  
  public static boolean toDriveB = false;
  
  JLabel asktimer;
  
  ActionListener askupdate;
  
  int asktime;
  
  Timer askUpdate;
  
  JFrame ask;
  
  String askname;
  
  private class DropListener extends DropTargetAdapter {
    private DropListener() {}
    
    public void dragExit(DropTargetEvent dtde) {
      JEMU.this.display.showtape = 0;
      JEMU.this.display.showdrives = 0;
    }
    
    public void dragOver(DropTargetDragEvent dtde) {
      int x = (dtde.getLocation()).x;
      int y = (dtde.getLocation()).y;
      if (x > JEMU.this.display.getWidth() >> 1) {
        JEMU.toDriveB = true;
      } else {
        JEMU.toDriveB = false;
      } 
      try {
        Transferable t = dtde.getTransferable();
        if (t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
          Object userObject = t.getTransferData(DataFlavor.javaFileListFlavor);
          if (userObject instanceof List) {
            String fileName = ((List<E>)userObject).get(0).toString();
            if (fileName.toLowerCase().endsWith(".dsk.png") || fileName.toLowerCase().endsWith(".mfm") || fileName.toLowerCase().endsWith(".dsk") || fileName.toLowerCase().endsWith(".dsz")) {
              JEMU.this.display.threeinch = ((int)(new File(fileName)).length() < 230000);
              int maxlen = JEMU.this.display.threeinch ? 29 : 23;
              JEMU.this.display.showdrives = 20;
              String disk1 = fileName;
              while (disk1.contains("\\") || disk1.contains("/"))
                disk1 = disk1.substring(1); 
              disk1 = disk1.substring(0, disk1.length() - 4);
              disk1 = disk1.toUpperCase().replace("_", " ");
              String disk2 = "";
              String disk3 = "";
              String disk4 = "";
              String disk5 = "";
              if (disk1.length() > maxlen) {
                StringBuilder b1 = new StringBuilder();
                StringBuilder b2 = new StringBuilder();
                int k = disk1.length();
                int i;
                for (i = 0; i < k; i++) {
                  if (i < maxlen) {
                    b1.append(disk1.charAt(i));
                  } else {
                    b2.append(disk1.charAt(i));
                  } 
                } 
                disk1 = b1.toString();
                disk2 = b2.toString();
                while (disk2.startsWith(" "))
                  disk2 = disk2.substring(1); 
                if (disk2.length() > maxlen) {
                  b1 = new StringBuilder();
                  b2 = new StringBuilder();
                  k = disk2.length();
                  for (i = 0; i < k; i++) {
                    if (i < maxlen) {
                      b1.append(disk2.charAt(i));
                    } else {
                      b2.append(disk2.charAt(i));
                    } 
                  } 
                  disk2 = b1.toString();
                  disk3 = b2.toString();
                  while (disk3.startsWith(" "))
                    disk3 = disk3.substring(1); 
                } 
                if (disk3.length() > maxlen) {
                  b1 = new StringBuilder();
                  b2 = new StringBuilder();
                  k = disk3.length();
                  for (i = 0; i < k; i++) {
                    if (i < maxlen) {
                      b1.append(disk3.charAt(i));
                    } else {
                      b2.append(disk3.charAt(i));
                    } 
                  } 
                  disk3 = b1.toString();
                  disk4 = b2.toString();
                  while (disk4.startsWith(" "))
                    disk4 = disk4.substring(1); 
                } 
                if (disk4.length() > maxlen) {
                  b1 = new StringBuilder();
                  b2 = new StringBuilder();
                  k = disk4.length();
                  for (i = 0; i < k; i++) {
                    if (i < maxlen) {
                      b1.append(disk4.charAt(i));
                    } else {
                      b2.append(disk4.charAt(i));
                    } 
                  } 
                  disk4 = b1.toString();
                  disk5 = b2.toString();
                  while (disk5.startsWith(" "))
                    disk5 = disk5.substring(1); 
                } 
              } 
              JEMU.this.display.disk1 = disk1;
              JEMU.this.display.disk2 = disk2;
              JEMU.this.display.disk3 = disk3;
              JEMU.this.display.disk4 = disk4;
              JEMU.this.display.disk5 = disk5;
            } else if (fileName.toLowerCase().endsWith(".tzx") || fileName.toLowerCase().endsWith(".cdt") || fileName.toLowerCase().endsWith(".wav") || fileName.toLowerCase().endsWith(".csw") || fileName.toLowerCase().endsWith(".mp3") || fileName.toLowerCase().endsWith(".tap")) {
              JEMU.this.display.showtape = 20;
              String disk1 = fileName;
              int maxlen = 39;
              while (disk1.contains("\\") || disk1.contains("/"))
                disk1 = disk1.substring(1); 
              disk1 = disk1.substring(0, disk1.length() - 4);
              disk1 = disk1.toUpperCase().replace("_", " ");
              String disk2 = "";
              String disk3 = "";
              String disk4 = "";
              String disk5 = "";
              if (disk1.length() > maxlen) {
                StringBuilder b1 = new StringBuilder();
                StringBuilder b2 = new StringBuilder();
                int k = disk1.length();
                int j;
                for (j = 0; j < k; j++) {
                  if (j < maxlen) {
                    b1.append(disk1.charAt(j));
                  } else {
                    b2.append(disk1.charAt(j));
                  } 
                } 
                disk1 = b1.toString();
                disk2 = b2.toString();
                while (disk2.startsWith(" "))
                  disk2 = disk2.substring(1); 
                if (disk2.length() > maxlen) {
                  b1 = new StringBuilder();
                  b2 = new StringBuilder();
                  k = disk2.length();
                  for (j = 0; j < k; j++) {
                    if (j < maxlen) {
                      b1.append(disk2.charAt(j));
                    } else {
                      b2.append(disk2.charAt(j));
                    } 
                  } 
                  disk2 = b1.toString();
                  disk3 = b2.toString();
                  while (disk3.startsWith(" "))
                    disk3 = disk3.substring(1); 
                } 
                if (disk3.length() > maxlen) {
                  b1 = new StringBuilder();
                  b2 = new StringBuilder();
                  k = disk3.length();
                  for (j = 0; j < k; j++) {
                    if (j < maxlen) {
                      b1.append(disk3.charAt(j));
                    } else {
                      b2.append(disk3.charAt(j));
                    } 
                  } 
                  disk3 = b1.toString();
                  disk4 = b2.toString();
                  while (disk4.startsWith(" "))
                    disk4 = disk4.substring(1); 
                } 
                if (disk4.length() > maxlen) {
                  b1 = new StringBuilder();
                  b2 = new StringBuilder();
                  k = disk4.length();
                  for (j = 0; j < k; j++) {
                    if (j < maxlen) {
                      b1.append(disk4.charAt(j));
                    } else {
                      b2.append(disk4.charAt(j));
                    } 
                  } 
                  disk4 = b1.toString();
                  disk5 = b2.toString();
                  while (disk5.startsWith(" "))
                    disk5 = disk5.substring(1); 
                } 
              } 
              int i = fileName.lastIndexOf('.');
              if (i > 0)
                disk5 = fileName.substring(i + 1).toUpperCase(); 
              JEMU.this.display.disk1 = disk1;
              JEMU.this.display.disk2 = disk2;
              JEMU.this.display.disk3 = disk3;
              JEMU.this.display.disk4 = disk4;
              JEMU.this.display.disk5 = disk5;
            } else if (fileName.toLowerCase().endsWith(".sna")) {
              JEMU.this.display.showsna = 20;
            } else {
              JEMU.this.display.showtape = 0;
              JEMU.this.display.showdrives = 0;
              JEMU.this.display.showsna = 0;
            } 
          } 
        } 
      } catch (Exception ex) {
        System.out.println("[MainForm::DropListener]" + ex);
      } 
    }
    
    public void drop(DropTargetDropEvent dtde) {
      try {
        Transferable t = dtde.getTransferable();
        if (t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
          dtde.acceptDrop(3);
          Object userObject = t.getTransferData(DataFlavor.javaFileListFlavor);
          if (userObject instanceof List) {
            String fileName = ((List<E>)userObject).get(0).toString();
            if ((fileName.toLowerCase().endsWith(".jpg") || fileName.toLowerCase().endsWith(".bmp") || fileName.toLowerCase().endsWith(".png") || fileName.toLowerCase().endsWith(".gif")) && !fileName.toLowerCase().endsWith(".dsk.png")) {
              JEMU.this.computer.reset();
              JEMU.doodlecount = 1;
              JEMU.importscreen = fileName;
              return;
            } 
            if (fileName.toLowerCase().endsWith(".asm")) {
              System.out.println("Opening ASM file..." + fileName);
              JEMU.this.openASM(fileName);
              return;
            } 
            JEMU.this.display.showtape = 0;
            JEMU.this.display.showdrives = 0;
            if (fileName.toLowerCase().endsWith(".dsk.png") || fileName.toLowerCase().endsWith(".mfm") || fileName.toLowerCase().endsWith(".dsk") || fileName.toLowerCase().endsWith(".dsz")) {
              int d = JEMU.this.computer.getCurrentDrive();
              JEMU.this.computer.setCurrentDrive(JEMU.toDriveB ? 1 : 0);
              JEMU.this.loadFile(0, fileName, false);
              JEMU.this.computer.setCurrentDrive(d);
              if (JEMU.this.cbZipChooser.isVisible()) {
                JEMU.this.cbZipChooser.setVisible(false);
                JEMU.this.ziplab.setVisible(false);
                JEMU.this.slomo.setVisible(!JEMU.this.ziplab.isVisible());
                JEMU.this.stpanel.slomo.setVisible(!JEMU.this.ziplab.isVisible());
                JEMU.this.langselect.setVisible(!JEMU.this.ziplab.isVisible());
                JEMU.this.selector = false;
                JEMU.this.cbZipChooser.setSelectedIndex(0);
                if (JEMU.iframe != null)
                  JEMU.iframe.pack(); 
                if (JEMU.frame != null)
                  JEMU.frame.pack(); 
              } 
            } else {
              JEMU.this.loadFile(0, fileName, false);
            } 
          } 
          dtde.dropComplete(true);
        } 
      } catch (Exception ex) {
        System.out.println("[MainForm::DropListener]" + ex);
        ex.printStackTrace();
      } 
    }
  }
  
  private static void registerDropListener(ArrayList<DropTarget> list, Container basePanel, DropListener myListener) {
    list.add(new DropTarget(basePanel, myListener));
    Component[] components = basePanel.getComponents();
    for (int i = 0; i < components.length; i++) {
      Component component = components[i];
      if (component instanceof Container) {
        registerDropListener(list, (Container)component, myListener);
      } else {
        list.add(new DropTarget(component, myListener));
      } 
    } 
  }
  
  protected void askDrive() {
    if (this.executable && frame != null)
      frame.setAlwaysOnTop(false); 
    try {
      SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              try {
                String loadname = JEMU.this.getFile("JavaCPC media", false, 5);
                if (loadname != null && (loadname.toLowerCase().endsWith(".dsk") || loadname.toLowerCase().endsWith(".dsz"))) {
                  JEMU.this.askDrive(loadname);
                } else if (loadname != null) {
                  JEMU.this.loadFile(0, loadname, false);
                } 
                if (JEMU.this.executable && JEMU.frame != null)
                  JEMU.frame.setAlwaysOnTop(JEMU.onTop); 
                JEMU.this.display.requestFocus();
              } catch (Exception exception) {}
            }
          });
    } catch (Exception e) {
      e.printStackTrace();
    } 
    if (this.executable && frame != null)
      frame.setAlwaysOnTop(onTop); 
  }
  
  protected void askDrive(final String filename) throws Exception {
    if ((filename == null || (!filename.toLowerCase().endsWith(".dsk") && !filename.toLowerCase().endsWith(".dsz"))) && filename != null) {
      loadFile(0, filename, false);
      return;
    } 
    try {
      SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              JEMU.this.askname = filename;
              if (JEMU.this.ask == null) {
                JEMU.this.ask = new JFrame("Select drive (3)");
                JEMU.this.ask.setDefaultCloseOperation(0);
                JButton driveA = new JButton(JEMU.this.discA);
                JButton driveB = new JButton(JEMU.this.discB);
                driveA.setFocusable(false);
                driveB.setFocusable(false);
                driveA.addMouseListener(new MouseListener() {
                      public void mouseExited(MouseEvent e) {}
                      
                      public void mouseEntered(MouseEvent e) {
                        JEMU.this.askUpdate.stop();
                      }
                      
                      public void mouseReleased(MouseEvent e) {}
                      
                      public void mousePressed(MouseEvent e) {}
                      
                      public void mouseClicked(MouseEvent e) {}
                    });
                driveB.addMouseListener(new MouseListener() {
                      public void mouseExited(MouseEvent e) {}
                      
                      public void mouseEntered(MouseEvent e) {
                        JEMU.this.askUpdate.stop();
                      }
                      
                      public void mouseReleased(MouseEvent e) {}
                      
                      public void mousePressed(MouseEvent e) {}
                      
                      public void mouseClicked(MouseEvent e) {}
                    });
                JEMU.this.asktimer.addMouseListener(new MouseListener() {
                      public void mouseExited(MouseEvent e) {}
                      
                      public void mouseEntered(MouseEvent e) {
                        JEMU.this.askUpdate.stop();
                      }
                      
                      public void mouseReleased(MouseEvent e) {}
                      
                      public void mousePressed(MouseEvent e) {}
                      
                      public void mouseClicked(MouseEvent e) {}
                    });
                JEMU.this.asktimer.setFocusable(false);
                JEMU.this.ask.setLayout(new FlowLayout(1, 12, 12));
                JEMU.this.ask.addMouseListener(new MouseListener() {
                      public void mouseExited(MouseEvent e) {
                        if (JEMU.this.ask.isShowing())
                          JEMU.this.askUpdate.start(); 
                      }
                      
                      public void mouseEntered(MouseEvent e) {
                        if (JEMU.this.ask.isShowing())
                          JEMU.this.askUpdate.stop(); 
                      }
                      
                      public void mouseReleased(MouseEvent e) {}
                      
                      public void mousePressed(MouseEvent e) {}
                      
                      public void mouseClicked(MouseEvent e) {}
                    });
                driveA.addActionListener(new ActionListener() {
                      public void actionPerformed(ActionEvent e) {
                        JEMU.this.computer.setCurrentDrive(0);
                        JEMU.this.ask.dispose();
                        JEMU.this.askUpdate.stop();
                        JEMU.this.asktime = 3;
                        try {
                          JEMU.this.loadFile(0, filename, false);
                        } catch (Exception er) {
                          System.out.println("Error while loading");
                        } 
                      }
                    });
                driveB.addActionListener(new ActionListener() {
                      public void actionPerformed(ActionEvent e) {
                        JEMU.this.computer.setCurrentDrive(1);
                        JEMU.this.ask.dispose();
                        JEMU.this.askUpdate.stop();
                        JEMU.this.asktime = 3;
                        try {
                          JEMU.this.loadFile(0, filename, false);
                        } catch (Exception er) {
                          System.out.println("Error while loading");
                        } 
                      }
                    });
                JEMU.this.ask.add(driveA);
                JEMU.this.ask.add(driveB);
              } 
              JEMU.this.asktime = 3;
              JEMU.this.askUpdate.start();
              JEMU.this.ask.setResizable(false);
              JEMU.this.ask.pack();
              Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
              JEMU.this.ask.setLocation((d.width - (JEMU.this.ask.getSize()).width) / 2, (d.height - (JEMU.this.ask.getSize()).height) / 2);
              JEMU.this.ask.setAlwaysOnTop(true);
              JEMU.this.ask.setVisible(true);
            }
          });
    } catch (Exception e) {
      e.printStackTrace();
    } 
    System.gc();
  }
  
  protected void selectDialog() {
    Frame frame = new Frame("Choose Disk");
    frame.setLayout(new GridBagLayout());
    if (this.keepA != null) {
      this.KeepA = new JButton(this.titleA);
      this.KeepA.setBackground(Color.GREEN);
      this.KeepA.addActionListener(this);
      frame.add(this.KeepA, getGridBagConstraints(1, 1, 1.0D, 1.0D, 2, 10));
    } 
    if (this.keepB != null) {
      this.KeepB = new JButton(this.titleB);
      this.KeepB.setBackground(Color.LIGHT_GRAY);
      this.KeepB.addActionListener(this);
      frame.add(this.KeepB, getGridBagConstraints(1, 2, 1.0D, 1.0D, 2, 10));
    } 
    if (this.keepC != null) {
      this.KeepC = new JButton(this.titleC);
      this.KeepC.addActionListener(this);
      this.KeepC.setBackground(Color.LIGHT_GRAY);
      frame.add(this.KeepC, getGridBagConstraints(1, 3, 1.0D, 1.0D, 2, 10));
    } 
    if (this.keepD != null) {
      this.KeepD = new JButton(this.titleD);
      this.KeepD.addActionListener(this);
      this.KeepD.setBackground(Color.LIGHT_GRAY);
      frame.add(this.KeepD, getGridBagConstraints(1, 4, 1.0D, 1.0D, 2, 10));
    } 
    if (this.keepE != null) {
      this.KeepE = new JButton(this.titleE);
      this.KeepE.addActionListener(this);
      this.KeepE.setBackground(Color.LIGHT_GRAY);
      frame.add(this.KeepE, getGridBagConstraints(1, 5, 1.0D, 1.0D, 2, 10));
    } 
    if (this.keepF != null) {
      this.KeepF = new JButton(this.titleF);
      this.KeepF.addActionListener(this);
      this.KeepF.setBackground(Color.LIGHT_GRAY);
      frame.add(this.KeepF, getGridBagConstraints(1, 6, 1.0D, 1.0D, 2, 10));
    } 
    frame.pack();
    frame.setAlwaysOnTop(true);
    frame.setResizable(false);
    frame.setVisible(true);
  }
  
  public void setFloppyHead(int drive, int head) {
    Vector devices = this.computer.getDevices();
    int n = devices.size();
    for (int i = 0; i < n; i++) {
      Object device = devices.get(i);
      if (device instanceof UPD765A) {
        UPD765A FDC = (UPD765A)device;
        FDC.setForcedHead(head, drive);
        System.out.println("Floppy head choosen: Drive " + drive + " - Head " + head);
      } 
    } 
  }
  
  public void buildSelector(String filename) {
    System.out.println("Building selector");
    int entries = this.computer.getIndex();
    int i;
    for (i = 0; i < 10; i++) {
      this.cbZipChooser.removeAllItems();
      this.cbZipChooser.removeActionListener(this);
      this.chooser.removeActionListener(this);
      this.chooser.removeItemListener(this);
      this.chooser.removeAllItems();
    } 
    for (i = 0; i < entries; i++) {
      String sname = this.computer.disknames[i];
      sname = i + ":" + sname;
      if (sname.length() > 36)
        sname = sname.substring(0, 36); 
      this.cbZipChooser.addItem(sname);
      this.chooser.addItem(this.computer.disknames[i]);
    } 
    try {
      if (entries < 1)
        return; 
      if (entries < 2) {
        this.cbZipChooser.setVisible(false);
        this.ziplab.setVisible(false);
        this.slomo.setVisible(!this.ziplab.isVisible());
        this.stpanel.slomo.setVisible(!this.ziplab.isVisible());
        this.langselect.setVisible(!this.ziplab.isVisible());
        this.selector = false;
        this.cbZipChooser.setSelectedIndex(0);
        if (iframe != null)
          iframe.pack(); 
        if (frame != null)
          frame.pack(); 
      } else {
        this.cbZipChooser.setSelectedIndex(0);
        this.chooser.setSelectedIndex(0);
        this.cbZipChooser.addActionListener(this);
        this.cbZipChooser.repaint();
        this.chooser.repaint();
        this.cbZipChooser.setVisible(true);
        this.ziplab.setVisible(true);
        this.slomo.setVisible(!this.ziplab.isVisible());
        this.stpanel.slomo.setVisible(!this.ziplab.isVisible());
        this.langselect.setVisible(!this.ziplab.isVisible());
        this.selector = true;
        askFile();
        if (iframe != null)
          iframe.pack(); 
        if (frame != null)
          frame.pack(); 
      } 
      System.gc();
    } catch (Exception exception) {}
  }
  
  public static boolean hidesplash = false;
  
  int hideTape;
  
  public MouseListener panelListener;
  
  protected JFrame full;
  
  protected boolean fulldesktop;
  
  DSK2CDT d2c;
  
  JFrame fram;
  
  public void askFile() {
    try {
      SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              boolean hassplash = false;
              if (Main.splash != null) {
                hassplash = Main.splash.isVisible();
                if (hassplash) {
                  Main.splash.setVisible(false);
                  JEMU.hidesplash = true;
                } 
              } 
              Object[] message = { JEMU.this.chooser, "Ok", "Cancel" };
              Frame dummy = new Frame();
              dummy.setAlwaysOnTop(true);
              try {
                Thread.yield();
                int choice = JOptionPane.showOptionDialog(dummy, "Please choose", "Zipped archive", 1, 3, null, message, null);
                if (choice == 1) {
                  JEMU.this.cbZipChooser.setSelectedIndex(JEMU.this.chooser.getSelectedIndex());
                  JEMU.this.display.zipinfo = JEMU.this.computer.disknames[JEMU.this.cbZipChooser.getSelectedIndex()];
                  JEMU.this.display.zipcount = 200;
                } 
              } catch (Exception exception) {}
              if (hassplash)
                JEMU.hidesplash = false; 
            }
          });
    } catch (Exception e) {
      e.printStackTrace();
    } 
    System.gc();
  }
  
  protected int getDrive() {
    int b = this.cbZipChooser.getSelectedIndex();
    if (this.computer.disknames[b].toLowerCase().endsWith("dsk")) {
      Object[] options = { "DF0", "DF1", "DF2", "DF3" };
      int n = JOptionPane.showOptionDialog(frame, "Please select the drive", "Choose drive:", 1, 3, null, options, options[0]);
      System.out.println("Loading entry into drive DF" + n);
      return n;
    } 
    return 0;
  }
  
  protected ImageIcon createIcon(String path) {
    URL imgURL = getClass().getResource(path);
    if (imgURL != null)
      return new ImageIcon(imgURL); 
    System.err.println("Couldn't find file: " + path);
    return null;
  }
  
  public void setFullScreen() {
    if (Display.use3d)
      return; 
    toplabel.setVisible(true);
    downlabel.setVisible(true);
    leftlabel.setVisible(true);
    rightlabel.setVisible(true);
    this.full.add(this.intern);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    this.full.setLocation(0, 0);
    this.full.setSize(d);
    this.full.setUndecorated(true);
    this.full.setVisible(true);
    this.display.requestFocus();
    this.fulldesktop = true;
    this.computer.reSync();
  }
  
  public void setWindowed() {
    toplabel.setVisible(false);
    downlabel.setVisible(false);
    leftlabel.setVisible(false);
    rightlabel.setVisible(false);
    add(this.intern, "Center");
    run();
    this.full.dispose();
    repaint();
    if (Desktop.fullSize.isSelected())
      ful = true; 
    if (Desktop.simpSize.isSelected())
      simp = true; 
    if (Desktop.doubSize.isSelected())
      doub = true; 
    this.computer.start();
    this.display.requestFocus();
    this.fulldesktop = false;
    this.computer.reSync();
  }
  
  protected void DSK2CDT() {
    if (this.d2c == null) {
      this.d2c = new DSK2CDT();
      this.fram = new JFrame("DSK2CDT");
      this.fram.setLayout(new BorderLayout());
      this.fram.add(this.d2c, "Center");
      this.fram.pack();
      this.fram.setResizable(false);
    } 
    this.fram.setVisible(true);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\JEMU.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */