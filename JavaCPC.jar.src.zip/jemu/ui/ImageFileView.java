package jemu.ui;

import java.io.File;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.filechooser.FileView;

public class ImageFileView extends FileView {
  ImageIcon jpgIcon = Utils.createImageIcon("images/JPG.png");
  
  ImageIcon gifIcon = Utils.createImageIcon("images/GIF.png");
  
  ImageIcon pngIcon = Utils.createImageIcon("images/PNG.png");
  
  ImageIcon scrIcon = Utils.createImageIcon("images/SCR.png");
  
  ImageIcon bmpIcon = Utils.createImageIcon("images/BMP.png");
  
  ImageIcon tgaIcon = Utils.createImageIcon("images/TGA.png");
  
  ImageIcon pcxIcon = Utils.createImageIcon("images/PCX.png");
  
  public String getName(File f) {
    return null;
  }
  
  public String getDescription(File f) {
    return null;
  }
  
  public Boolean isTraversable(File f) {
    return null;
  }
  
  public String getTypeDescription(File f) {
    String extension = Utils.getExtension(f);
    String type = null;
    if (extension != null)
      if (extension.equals("jpeg") || extension
        .equals("jpg")) {
        type = "JPEG Image";
      } else if (extension.equals("gif")) {
        type = "GIF Image";
      } else if (extension.equals("png")) {
        type = "PNG Image";
      }  
    return type;
  }
  
  public Icon getIcon(File f) {
    String extension = Utils.getExtension(f);
    Icon icon = null;
    if (extension != null)
      if (extension.equals("jpeg") || extension
        .equals("jpg")) {
        icon = this.jpgIcon;
      } else if (extension.equals("gif")) {
        icon = this.gifIcon;
      } else if (extension.equals("png")) {
        icon = this.pngIcon;
      }  
    return icon;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\ImageFileView.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */