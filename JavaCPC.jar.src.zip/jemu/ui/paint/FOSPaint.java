package jemu.ui.paint;

import com.jhlabs.image.ContrastFilter;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import jemu.system.cpc.CPC;
import jemu.system.cpc.GateArray;

public class FOSPaint extends JFrame {
  final URL icons = getClass().getResource("FOSIcon.png");
  
  final Image Icons = getToolkit().getImage(this.icons);
  
  BufferedImage renderBuffer = new BufferedImage(512, 256, 1);
  
  BufferedImage displayBuffer = new BufferedImage(512, 512, 1);
  
  int[] fixedPalette = new int[] { 0, 16777215 };
  
  FileDialog loadDiag;
  
  FileDialog saveDiag;
  
  String filepath;
  
  String filename;
  
  Image test;
  
  public void init() {
    GateArray.cpc.SetFOS();
  }
  
  void Save() {
    String name = this.jTextField1.getText();
    while (name.length() < 8)
      name = name + " "; 
    name = name + ".HGB";
    try {
      byte[] namebytes = name.getBytes("UTF-8");
      int addr = 36956;
      for (int i = 0; i < namebytes.length; i++)
        CPC.POKE(addr + i, namebytes[i]); 
      CPC.POKE(16383, 1);
    } catch (Exception exception) {}
  }
  
  public void Import() {
    if (this.loadDiag == null)
      this.loadDiag = new FileDialog(this, "Import Picture", 0); 
    this.loadDiag.setVisible(true);
    String path = this.loadDiag.getDirectory();
    String file = this.loadDiag.getFile();
    if (file == null || path == null)
      return; 
    Import(path, file);
  }
  
  void reImport() {
    if (this.test == null)
      return; 
    Import(this.test);
  }
  
  ContrastFilter contrastfilter = new ContrastFilter();
  
  float[] gain = new float[] { 
      0.0F, 0.01F, 0.02F, 0.03F, 0.04F, 0.05F, 0.06F, 0.07F, 0.08F, 0.09F, 
      0.1F, 0.11F, 0.12F, 0.13F, 0.14F, 0.15F, 0.16F, 0.17F, 0.18F, 0.19F, 
      0.2F, 0.21F, 0.22F, 0.23F, 0.24F, 0.25F, 0.26F, 0.27F, 0.28F, 0.29F, 
      0.3F, 0.31F, 0.32F, 0.33F, 0.34F, 0.35F, 0.36F, 0.37F, 0.38F, 0.39F, 
      0.4F, 0.41F, 0.42F, 0.43F, 0.44F, 0.45F, 0.46F, 0.47F, 0.48F, 0.49F, 
      0.5F, 0.51F, 0.52F, 0.53F, 0.54F, 0.55F, 0.56F, 0.57F, 0.58F, 0.59F, 
      0.6F, 0.61F, 0.62F, 0.63F, 0.64F, 0.65F, 0.66F, 0.67F, 0.68F, 0.69F, 
      0.7F, 0.71F, 0.72F, 0.73F, 0.74F, 0.75F, 0.76F, 0.77F, 0.78F, 0.79F, 
      0.8F, 0.81F, 0.82F, 0.83F, 0.84F, 0.85F, 0.86F, 0.87F, 0.88F, 0.89F, 
      0.9F, 0.91F, 0.92F, 0.93F, 0.94F, 0.95F, 0.96F, 0.97F, 0.98F, 0.99F, 
      1.0F };
  
  boolean dlevel;
  
  int ditherval;
  
  private JSlider bright;
  
  private JSlider contrast;
  
  private JButton jButton1;
  
  private JButton jButton2;
  
  private JLabel jLabel1;
  
  private JLabel jLabel2;
  
  private JLabel jLabel3;
  
  private JLabel jLabel4;
  
  private JPanel jPanel1;
  
  private JPanel jPanel2;
  
  private JSlider jSlider1;
  
  private JTextField jTextField1;
  
  void Import(Image test) {
    this.displayBuffer.getGraphics().drawImage(test, 0, 0, this);
    this.contrastfilter.setBrightness(this.gain[this.bright.getValue()] * 2.0F);
    this.contrastfilter.setContrast(this.gain[this.contrast.getValue()] * 2.0F);
    this.contrastfilter.filter(this.displayBuffer, this.displayBuffer);
    this.renderBuffer.getGraphics().drawImage(this.displayBuffer, 0, 0, 512, 256, this);
    buildCPCScreen(this.renderBuffer);
    this.displayBuffer.getGraphics().drawImage(this.renderBuffer, 0, 0, 512, 512, this);
    this.displayBuffer.getGraphics().drawImage(this.Icons, 0, 0, this);
    this.jLabel1.setIcon(new ImageIcon(this.displayBuffer));
    for (int x = 0; x < 512; x++) {
      for (int y = 0; y < 256; y++) {
        int color = this.renderBuffer.getRGB(x, y);
        if (color == -1) {
          CPC.PLOTFOS(x, y, 1, 2);
        } else {
          CPC.PLOTFOS(x, y, 0, 2);
        } 
      } 
    } 
  }
  
  void Import(String path, String file) {
    this.filepath = path;
    this.filename = file;
    try {
      BufferedImage imp = ImageIO.read(new File(path + file));
      this.test = imp.getScaledInstance(512, -1, 4);
      if (this.test.getHeight(this) < 512)
        this.test = imp.getScaledInstance(-1, 512, 4); 
      Import(this.test);
    } catch (Exception exception) {}
  }
  
  public FOSPaint() {
    this.dlevel = true;
    this.ditherval = 20;
    initComponents();
    this.displayBuffer.getGraphics().drawImage(this.Icons, 0, 0, this);
    this.displayBuffer.getGraphics().drawImage(this.Icons, 0, 0, this);
  }
  
  public void buildCPCScreen(BufferedImage image) {
    boolean dither = true;
    if (this.ditherval > 118)
      dither = false; 
    int[][] cpComp = new int[this.fixedPalette.length][3];
    for (int k = 0; k < this.fixedPalette.length; k++) {
      cpComp[k][0] = red(this.fixedPalette[k]);
      cpComp[k][1] = green(this.fixedPalette[k]);
      cpComp[k][2] = blue(this.fixedPalette[k]);
    } 
    int y = 0;
    for (; y < image.getHeight(); y++) {
      int x = 0;
      for (; x < image.getWidth(); x++) {
        int pixel = image.getRGB(x, y);
        int pixelR = red(pixel);
        int pixelG = green(pixel);
        int pixelB = blue(pixel);
        int minimumDistance = 195076;
        int ncIndex = -1;
        for (int j = 0; j < this.fixedPalette.length; j++) {
          int rDiff = pixelR - cpComp[j][0];
          int gDiff = pixelG - cpComp[j][1];
          int bDiff = pixelB - cpComp[j][2];
          int distance = (int)((rDiff * rDiff) * 0.299D + (gDiff * gDiff) * 0.587D + (bDiff * bDiff) * 0.114D);
          if (distance < minimumDistance) {
            minimumDistance = distance;
            ncIndex = j;
          } 
        } 
        image.setRGB(x, y, this.fixedPalette[ncIndex]);
        if (dither) {
          int i = 0;
          for (; i < 4; i++) {
            int xCoor = (i == 0) ? (x + 1) : ((i == 1) ? (x - 1) : ((i == 2) ? x : (x + 1)));
            int yCoor = (i == 0) ? y : (y + 1);
            if (xCoor >= 0 && xCoor < image.getWidth() && yCoor < image.getHeight()) {
              double factor = (i == 0) ? (7.0D / this.ditherval) : ((i == 1) ? (3.0D / this.ditherval) : ((i == 2) ? (5.0D / this.ditherval) : (1.0D / this.ditherval)));
              int p = image.getRGB(xCoor, yCoor);
              int newRed = (int)Math.round(red(p) + factor * (pixelR - cpComp[ncIndex][0]));
              int newGreen = (int)Math.round(green(p) + factor * (pixelG - cpComp[ncIndex][1]));
              int newBlue = (int)Math.round(blue(p) + factor * (pixelB - cpComp[ncIndex][2]));
              if (newRed < 0)
                newRed = 0; 
              if (newRed > 255)
                newRed = 255; 
              if (newGreen < 0)
                newGreen = 0; 
              if (newGreen > 255)
                newGreen = 255; 
              if (newBlue < 0)
                newBlue = 0; 
              if (newBlue > 255)
                newBlue = 255; 
              image.setRGB(xCoor, yCoor, -16777216 + (newRed << 16) + (newGreen << 8) + newBlue);
            } 
          } 
        } 
      } 
    } 
  }
  
  public static int red(int argb) {
    return argb >> 16 & 0xFF;
  }
  
  public static int green(int argb) {
    return argb >> 8 & 0xFF;
  }
  
  public static int blue(int argb) {
    return argb & 0xFF;
  }
  
  private void initComponents() {
    this.jPanel1 = new JPanel();
    this.jLabel1 = new JLabel();
    this.jPanel2 = new JPanel();
    this.jButton1 = new JButton();
    this.jLabel2 = new JLabel();
    this.jSlider1 = new JSlider();
    this.jLabel3 = new JLabel();
    this.bright = new JSlider();
    this.contrast = new JSlider();
    this.jLabel4 = new JLabel();
    this.jTextField1 = new JTextField();
    this.jButton2 = new JButton();
    setTitle("FutureOS Wallpaper Tool");
    this.jPanel1.setPreferredSize(new Dimension(512, 600));
    this.jPanel1.setLayout(new BorderLayout());
    this.jLabel1.setPreferredSize(new Dimension(512, 512));
    this.jPanel1.add(this.jLabel1, "First");
    this.jPanel2.setPreferredSize(new Dimension(512, 180));
    this.jButton1.setText("Import");
    this.jButton1.setFocusable(false);
    this.jButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FOSPaint.this.jButton1ActionPerformed(evt);
          }
        });
    this.jLabel2.setText("Dither:");
    this.jSlider1.setMaximum(120);
    this.jSlider1.setMinimum(10);
    this.jSlider1.setValue(20);
    this.jSlider1.setInverted(true);
    this.jSlider1.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent evt) {
            FOSPaint.this.jSlider1StateChanged(evt);
          }
        });
    this.jLabel3.setText("Brightness:");
    this.bright.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent evt) {
            FOSPaint.this.brightStateChanged(evt);
          }
        });
    this.contrast.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent evt) {
            FOSPaint.this.brightStateChanged(evt);
          }
        });
    this.jLabel4.setText("Contrast:");
    this.jTextField1.setFont(new Font("Monospaced", 1, 11));
    this.jTextField1.setText("BACKGRND");
    this.jTextField1.addKeyListener(new KeyAdapter() {
          public void keyReleased(KeyEvent evt) {
            FOSPaint.this.jTextField1KeyReleased(evt);
          }
        });
    this.jButton2.setText("Save");
    this.jButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            FOSPaint.this.jButton2ActionPerformed(evt);
          }
        });
    GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
    this.jPanel2.setLayout(jPanel2Layout);
    jPanel2Layout.setHorizontalGroup(jPanel2Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel2Layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(this.jButton1, -1, -1, 32767)
            .addComponent(this.jTextField1)
            .addComponent(this.jButton2, -1, -1, 32767))
          .addGap(18, 18, 18)
          .addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
            .addComponent(this.jLabel4, GroupLayout.Alignment.LEADING, -1, -1, 32767)
            .addComponent(this.jLabel3, GroupLayout.Alignment.LEADING, -1, -1, 32767)
            .addComponent(this.jLabel2, -1, -1, 32767))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jSlider1, -1, -1, 32767)
            .addComponent(this.bright, -1, 351, 32767)
            .addComponent(this.contrast, -1, -1, 32767))
          .addContainerGap()));
    jPanel2Layout.setVerticalGroup(jPanel2Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(jPanel2Layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
              .addComponent(this.jButton1)
              .addComponent(this.jLabel2))
            .addComponent(this.jSlider1, -2, -1, -2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.bright, -2, 0, 32767)
            .addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
              .addComponent(this.jLabel3)
              .addComponent(this.jTextField1, -2, -1, -2)))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.contrast, -2, 0, 32767)
            .addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
              .addComponent(this.jLabel4)
              .addComponent(this.jButton2)))
          .addGap(76, 76, 76)));
    this.jPanel1.add(this.jPanel2, "Center");
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addComponent(this.jPanel1, -2, -1, -2)
          .addGap(0, 0, 32767)));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addComponent(this.jPanel1, -1, 616, 32767));
    pack();
  }
  
  private void jButton1ActionPerformed(ActionEvent evt) {
    Import();
  }
  
  private void jSlider1StateChanged(ChangeEvent evt) {
    this.ditherval = this.jSlider1.getValue();
    reImport();
  }
  
  private void brightStateChanged(ChangeEvent evt) {
    reImport();
  }
  
  private void jTextField1KeyReleased(KeyEvent evt) {
    String g = this.jTextField1.getText();
    while (g.length() > 8)
      g = g.substring(0, g.length() - 1); 
    g = g.toUpperCase();
    this.jTextField1.setText(g);
  }
  
  private void jButton2ActionPerformed(ActionEvent evt) {
    Save();
  }
  
  public static void main(String[] args) {
    try {
      for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
          UIManager.setLookAndFeel(info.getClassName());
          break;
        } 
      } 
    } catch (ClassNotFoundException ex) {
      Logger.getLogger(FOSPaint.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (InstantiationException ex) {
      Logger.getLogger(FOSPaint.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (IllegalAccessException ex) {
      Logger.getLogger(FOSPaint.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (UnsupportedLookAndFeelException ex) {
      Logger.getLogger(FOSPaint.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new FOSPaint()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\paint\FOSPaint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */