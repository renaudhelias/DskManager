package jemu.ui.paint;

public class CPCize {
  private int[] value;
  
  private double a = 1.0D;
  
  private double b = 0.0D;
  
  public CPCize() {
    this.value = new int[256];
    create();
  }
  
  public int getCPCValue(int x) {
    return this.value[x];
  }
  
  public void setA(double a) {
    this.a = a;
    create();
  }
  
  public void setB(double b) {
    this.b = b;
    create();
  }
  
  private void create() {
    for (int x = 0; x <= 255; x++) {
      this.value[x] = (int)(this.a * x + this.b);
      if (this.value[x] > 255)
        this.value[x] = 255; 
      if (this.value[x] < 0)
        this.value[x] = 0; 
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\paint\CPCize.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */