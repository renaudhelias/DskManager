package jemu.ui.paint;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.LayoutStyle;
import jemu.system.cpc.CPC;
import jemu.ui.Switches;

public class InkSelector extends JFrame {
  protected int[] GateArrayINKs = new int[] { 
      20, 4, 21, 28, 24, 29, 12, 5, 13, 22, 
      6, 23, 30, 0, 31, 14, 7, 15, 18, 2, 
      19, 26, 25, 27, 10, 3, 11 };
  
  protected int PEN = 0;
  
  protected int INK = 0;
  
  PaintCanvas canvas;
  
  private Panel choosen;
  
  private JPanel frame;
  
  private JLabel ink;
  
  private JButton jButton1;
  
  private JButton jButton2;
  
  private JLabel jLabel1;
  
  private JPanel jPanel2;
  
  private Button p0;
  
  private Button p1;
  
  private Button p10;
  
  private Button p11;
  
  private Button p12;
  
  private Button p13;
  
  private Button p14;
  
  private Button p15;
  
  private Button p16;
  
  private Button p17;
  
  private Button p18;
  
  private Button p19;
  
  private Button p2;
  
  private Button p20;
  
  private Button p21;
  
  private Button p22;
  
  private Button p23;
  
  private Button p24;
  
  private Button p25;
  
  private Button p26;
  
  private Button p3;
  
  private Button p4;
  
  private Button p5;
  
  private Button p6;
  
  private Button p7;
  
  private Button p8;
  
  private Button p9;
  
  public InkSelector(PaintCanvas canvas) {
    this.canvas = canvas;
    initComponents();
  }
  
  public void PEN(int pen, int ink) {
    this.PEN = pen;
    this.frame.setBorder(BorderFactory.createTitledBorder("Select INK for PEN " + pen));
    switch (ink) {
      case 0:
        this.choosen.setBackground(this.p0.getBackground());
        break;
      case 1:
        this.choosen.setBackground(this.p1.getBackground());
        break;
      case 2:
        this.choosen.setBackground(this.p2.getBackground());
        break;
      case 3:
        this.choosen.setBackground(this.p3.getBackground());
        break;
      case 4:
        this.choosen.setBackground(this.p4.getBackground());
        break;
      case 5:
        this.choosen.setBackground(this.p5.getBackground());
        break;
      case 6:
        this.choosen.setBackground(this.p6.getBackground());
        break;
      case 7:
        this.choosen.setBackground(this.p7.getBackground());
        break;
      case 8:
        this.choosen.setBackground(this.p8.getBackground());
        break;
      case 9:
        this.choosen.setBackground(this.p9.getBackground());
        break;
      case 10:
        this.choosen.setBackground(this.p10.getBackground());
        break;
      case 11:
        this.choosen.setBackground(this.p11.getBackground());
        break;
      case 12:
        this.choosen.setBackground(this.p12.getBackground());
        break;
      case 13:
        this.choosen.setBackground(this.p13.getBackground());
        break;
      case 14:
        this.choosen.setBackground(this.p14.getBackground());
        break;
      case 15:
        this.choosen.setBackground(this.p15.getBackground());
        break;
      case 16:
        this.choosen.setBackground(this.p16.getBackground());
        break;
      case 17:
        this.choosen.setBackground(this.p17.getBackground());
        break;
      case 18:
        this.choosen.setBackground(this.p18.getBackground());
        break;
      case 19:
        this.choosen.setBackground(this.p19.getBackground());
        break;
      case 20:
        this.choosen.setBackground(this.p20.getBackground());
        break;
      case 21:
        this.choosen.setBackground(this.p21.getBackground());
        break;
      case 22:
        this.choosen.setBackground(this.p22.getBackground());
        break;
      case 23:
        this.choosen.setBackground(this.p23.getBackground());
        break;
      case 24:
        this.choosen.setBackground(this.p24.getBackground());
        break;
      case 25:
        this.choosen.setBackground(this.p25.getBackground());
        break;
      case 26:
        this.choosen.setBackground(this.p26.getBackground());
        break;
    } 
  }
  
  private void initComponents() {
    this.jButton1 = new JButton();
    this.jButton2 = new JButton();
    this.jPanel2 = new JPanel();
    this.choosen = new Panel();
    this.frame = new JPanel();
    this.p0 = new Button();
    this.p1 = new Button();
    this.p3 = new Button();
    this.p2 = new Button();
    this.p5 = new Button();
    this.p4 = new Button();
    this.p6 = new Button();
    this.p7 = new Button();
    this.p8 = new Button();
    this.p9 = new Button();
    this.p10 = new Button();
    this.p11 = new Button();
    this.p12 = new Button();
    this.p16 = new Button();
    this.p15 = new Button();
    this.p13 = new Button();
    this.p14 = new Button();
    this.p17 = new Button();
    this.p22 = new Button();
    this.p18 = new Button();
    this.p21 = new Button();
    this.p20 = new Button();
    this.p23 = new Button();
    this.p19 = new Button();
    this.p26 = new Button();
    this.p25 = new Button();
    this.p24 = new Button();
    this.jLabel1 = new JLabel();
    this.ink = new JLabel();
    setTitle("INK Chooser");
    setAlwaysOnTop(true);
    setResizable(false);
    this.jButton1.setText("Cancel");
    this.jButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.jButton1ActionPerformed(evt);
          }
        });
    this.jButton2.setText("Ok");
    this.jButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.jButton2ActionPerformed(evt);
          }
        });
    this.jPanel2.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel2.setLayout(new BorderLayout());
    this.choosen.setBackground(new Color(0, 0, 0));
    GroupLayout choosenLayout = new GroupLayout(this.choosen);
    this.choosen.setLayout(choosenLayout);
    choosenLayout.setHorizontalGroup(choosenLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 46, 32767));
    choosenLayout.setVerticalGroup(choosenLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 19, 32767));
    this.jPanel2.add(this.choosen, "Center");
    this.frame.setBorder(BorderFactory.createTitledBorder("Select INK"));
    this.p0.setBackground(new Color(0, 0, 0));
    this.p0.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p0ActionPerformed(evt);
          }
        });
    this.p1.setBackground(new Color(0, 0, 127));
    this.p1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p1ActionPerformed(evt);
          }
        });
    this.p3.setBackground(new Color(127, 0, 0));
    this.p3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p3ActionPerformed(evt);
          }
        });
    this.p2.setBackground(new Color(0, 0, 255));
    this.p2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p2ActionPerformed(evt);
          }
        });
    this.p5.setBackground(new Color(127, 0, 255));
    this.p5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p5ActionPerformed(evt);
          }
        });
    this.p4.setBackground(new Color(127, 0, 127));
    this.p4.setCursor(new Cursor(0));
    this.p4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p4ActionPerformed(evt);
          }
        });
    this.p6.setBackground(new Color(255, 0, 0));
    this.p6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p6ActionPerformed(evt);
          }
        });
    this.p7.setBackground(new Color(255, 0, 127));
    this.p7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p7ActionPerformed(evt);
          }
        });
    this.p8.setBackground(new Color(255, 0, 255));
    this.p8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p8ActionPerformed(evt);
          }
        });
    this.p9.setBackground(new Color(0, 127, 0));
    this.p9.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p9ActionPerformed(evt);
          }
        });
    this.p10.setBackground(new Color(0, 127, 127));
    this.p10.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p10ActionPerformed(evt);
          }
        });
    this.p11.setBackground(new Color(0, 127, 255));
    this.p11.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p11ActionPerformed(evt);
          }
        });
    this.p12.setBackground(new Color(127, 127, 0));
    this.p12.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p12ActionPerformed(evt);
          }
        });
    this.p16.setBackground(new Color(255, 127, 127));
    this.p16.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p16ActionPerformed(evt);
          }
        });
    this.p15.setBackground(new Color(255, 127, 0));
    this.p15.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p15ActionPerformed(evt);
          }
        });
    this.p13.setBackground(new Color(127, 127, 127));
    this.p13.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p13ActionPerformed(evt);
          }
        });
    this.p14.setBackground(new Color(127, 127, 255));
    this.p14.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p14ActionPerformed(evt);
          }
        });
    this.p17.setBackground(new Color(255, 127, 255));
    this.p17.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p17ActionPerformed(evt);
          }
        });
    this.p22.setBackground(new Color(127, 255, 127));
    this.p22.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p22ActionPerformed(evt);
          }
        });
    this.p18.setBackground(new Color(0, 255, 0));
    this.p18.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p18ActionPerformed(evt);
          }
        });
    this.p21.setBackground(new Color(127, 255, 0));
    this.p21.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p21ActionPerformed(evt);
          }
        });
    this.p20.setBackground(new Color(0, 255, 255));
    this.p20.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p20ActionPerformed(evt);
          }
        });
    this.p23.setBackground(new Color(127, 255, 255));
    this.p23.setCursor(new Cursor(0));
    this.p23.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p23ActionPerformed(evt);
          }
        });
    this.p19.setBackground(new Color(0, 255, 127));
    this.p19.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p19ActionPerformed(evt);
          }
        });
    this.p26.setBackground(new Color(255, 255, 255));
    this.p26.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p26ActionPerformed(evt);
          }
        });
    this.p25.setBackground(new Color(255, 255, 127));
    this.p25.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p25ActionPerformed(evt);
          }
        });
    this.p24.setBackground(new Color(255, 255, 0));
    this.p24.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            InkSelector.this.p24ActionPerformed(evt);
          }
        });
    GroupLayout frameLayout = new GroupLayout(this.frame);
    this.frame.setLayout(frameLayout);
    frameLayout.setHorizontalGroup(frameLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(frameLayout.createSequentialGroup()
          .addContainerGap()
          .addGroup(frameLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(frameLayout.createSequentialGroup()
              .addComponent(this.p0, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p1, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p2, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p3, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p4, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p5, -2, 42, -2))
            .addGroup(frameLayout.createSequentialGroup()
              .addComponent(this.p6, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p7, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p8, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p9, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p10, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p11, -2, 42, -2))
            .addGroup(frameLayout.createSequentialGroup()
              .addComponent(this.p12, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p13, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p14, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p15, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p16, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p17, -2, 42, -2))
            .addGroup(frameLayout.createSequentialGroup()
              .addComponent(this.p18, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p19, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p20, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p21, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p22, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p23, -2, 42, -2))
            .addGroup(frameLayout.createSequentialGroup()
              .addComponent(this.p24, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p25, -2, 42, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.p26, -2, 42, -2)))
          .addContainerGap(10, 32767)));
    frameLayout.setVerticalGroup(frameLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(frameLayout.createSequentialGroup()
          .addGroup(frameLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.p0, -2, -1, -2)
            .addComponent(this.p3, -2, -1, -2)
            .addComponent(this.p1, -2, -1, -2)
            .addComponent(this.p2, -2, -1, -2)
            .addComponent(this.p5, -2, -1, -2)
            .addComponent(this.p4, -2, -1, -2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(frameLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.p6, -2, -1, -2)
            .addComponent(this.p9, -2, -1, -2)
            .addComponent(this.p7, -2, -1, -2)
            .addComponent(this.p8, -2, -1, -2)
            .addComponent(this.p11, -2, -1, -2)
            .addComponent(this.p10, -2, -1, -2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(frameLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.p12, -2, -1, -2)
            .addComponent(this.p15, -2, -1, -2)
            .addComponent(this.p13, -2, -1, -2)
            .addComponent(this.p14, -2, -1, -2)
            .addComponent(this.p17, -2, -1, -2)
            .addComponent(this.p16, -2, -1, -2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(frameLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.p18, -2, -1, -2)
            .addComponent(this.p21, -2, -1, -2)
            .addComponent(this.p19, -2, -1, -2)
            .addComponent(this.p20, -2, -1, -2)
            .addComponent(this.p23, -2, -1, -2)
            .addComponent(this.p22, -2, -1, -2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(frameLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.p24, -2, -1, -2)
            .addComponent(this.p25, -2, -1, -2)
            .addComponent(this.p26, -2, -1, -2))
          .addContainerGap(-1, 32767)));
    this.jLabel1.setText("Chosen INK:");
    this.ink.setText("0");
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.jLabel1)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jPanel2, -2, 50, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
              .addComponent(this.ink, -2, 31, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
              .addComponent(this.jButton2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jButton1))
            .addComponent(this.frame, GroupLayout.Alignment.LEADING, -2, -1, -2))
          .addContainerGap(-1, 32767)));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addComponent(this.frame, -2, -1, -2)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jPanel2, -1, 23, 32767)
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
              .addComponent(this.jButton1, -1, -1, 32767)
              .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(this.jButton2, -1, -1, 32767)
                .addComponent(this.ink))
              .addComponent(this.jLabel1, -1, -1, 32767)))
          .addContainerGap(12, 32767)));
    pack();
  }
  
  private void p0ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p0.getBackground());
    this.INK = 0;
    this.ink.setText("0");
  }
  
  private void p1ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p1.getBackground());
    this.INK = 1;
    this.ink.setText("1");
  }
  
  private void p2ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p2.getBackground());
    this.INK = 2;
    this.ink.setText("2");
  }
  
  private void p3ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p3.getBackground());
    this.INK = 3;
    this.ink.setText("3");
  }
  
  private void p4ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p4.getBackground());
    this.INK = 4;
    this.ink.setText("4");
  }
  
  private void p5ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p5.getBackground());
    this.INK = 5;
    this.ink.setText("5");
  }
  
  private void p6ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p6.getBackground());
    this.INK = 6;
    this.ink.setText("6");
  }
  
  private void p7ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p7.getBackground());
    this.INK = 7;
    this.ink.setText("7");
  }
  
  private void p8ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p8.getBackground());
    this.INK = 8;
    this.ink.setText("8");
  }
  
  private void p9ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p9.getBackground());
    this.INK = 9;
    this.ink.setText("9");
  }
  
  private void p10ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p10.getBackground());
    this.INK = 10;
    this.ink.setText("10");
  }
  
  private void p11ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p11.getBackground());
    this.INK = 11;
    this.ink.setText("11");
  }
  
  private void p12ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p12.getBackground());
    this.INK = 12;
    this.ink.setText("12");
  }
  
  private void p13ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p13.getBackground());
    this.INK = 13;
    this.ink.setText("13");
  }
  
  private void p14ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p14.getBackground());
    this.INK = 14;
    this.ink.setText("14");
  }
  
  private void p15ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p15.getBackground());
    this.INK = 15;
    this.ink.setText("15");
  }
  
  private void p16ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p16.getBackground());
    this.INK = 16;
    this.ink.setText("16");
  }
  
  private void p17ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p17.getBackground());
    this.INK = 17;
    this.ink.setText("17");
  }
  
  private void p18ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p18.getBackground());
    this.INK = 18;
    this.ink.setText("18");
  }
  
  private void p19ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p19.getBackground());
    this.INK = 19;
    this.ink.setText("19");
  }
  
  private void p20ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p20.getBackground());
    this.INK = 20;
    this.ink.setText("20");
  }
  
  private void p21ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p21.getBackground());
    this.INK = 21;
    this.ink.setText("21");
  }
  
  private void p22ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p22.getBackground());
    this.INK = 22;
    this.ink.setText("22");
  }
  
  private void p23ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p23.getBackground());
    this.INK = 23;
    this.ink.setText("23");
  }
  
  private void p24ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p24.getBackground());
    this.INK = 24;
    this.ink.setText("24");
  }
  
  private void p25ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p25.getBackground());
    this.INK = 25;
    this.ink.setText("25");
  }
  
  private void p26ActionPerformed(ActionEvent evt) {
    this.choosen.setBackground(this.p26.getBackground());
    this.INK = 26;
    this.ink.setText("26");
  }
  
  private void jButton2ActionPerformed(ActionEvent evt) {
    INK(this.PEN, this.INK);
    setVisible(false);
  }
  
  private void jButton1ActionPerformed(ActionEvent evt) {
    setVisible(false);
  }
  
  public void INK(int pen, int ink) {
    int addressA = 45529;
    int addressB = 45546;
    if (Switches.ROM.equals("CPC6128") || Switches.ROM.equals("CPC664")) {
      addressA = 47060;
      addressB = 47077;
    } 
    CPC.POKE(addressA + 1 + pen, this.GateArrayINKs[ink]);
    CPC.POKE(addressB + 1 + pen, this.GateArrayINKs[ink]);
    this.canvas.putScreen();
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\paint\InkSelector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */