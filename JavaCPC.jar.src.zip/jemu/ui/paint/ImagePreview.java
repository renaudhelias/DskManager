package jemu.ui.paint;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.border.EtchedBorder;
import jemu.core.device.Computer;
import jemu.settings.Settings;
import jemu.system.cpc.GraphicsDecoder;

public class ImagePreview extends JComponent implements PropertyChangeListener {
  final URL cpcicon = getClass().getResource("cpc.gif");
  
  ImageIcon thumbnail = null;
  
  File file = null;
  
  JLabel label = new JLabel() {
      public void setText(String text) {
        super.setText("  " + text);
      }
    };
  
  JCheckBox box = new JCheckBox("Larger");
  
  PaintCanvas canv;
  
  ImageImporter imageImporter;
  
  GraphicsDecoder decoder;
  
  protected int thumbWidth;
  
  public ImagePreview(final JFileChooser fc) {
    this.canv = new PaintCanvas();
    this.imageImporter = new ImageImporter();
    this.decoder = new GraphicsDecoder();
    this.thumbWidth = 200;
    this.box.setSelected(Settings.getBoolean("thumbsize", false));
    this.thumbWidth = this.box.isSelected() ? 320 : 190;
    setPreferredSize(new Dimension(this.thumbWidth + 20, 200));
    setBorder(new EtchedBorder());
    setLayout(new BorderLayout());
    add(this.box, "North");
    add(this.label, "South");
    this.box.setFocusable(false);
    this.box.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent ev) {
            ImagePreview.this.loadImage();
            ImagePreview.this.repaint();
            fc.updateUI();
            Settings.setBoolean("thumbsize", ImagePreview.this.box.isSelected());
          }
        });
    fc.addPropertyChangeListener(this);
  }
  
  public static boolean CheckAMSDOS(byte[] pHeader) {
    int CalculatedChecksum;
    try {
      CalculatedChecksum = Computer.ChecksumAMSDOS(pHeader);
    } catch (Exception e) {
      return false;
    } 
    int ChecksumFromHeader = pHeader[67] & 0xFF | (pHeader[68] & 0xFF) << 8;
    if (ChecksumFromHeader == CalculatedChecksum && ChecksumFromHeader != 0) {
      System.out.println("Has AMSDOS header");
      return true;
    } 
    System.out.println("Without header");
    return false;
  }
  
  public void loadImage() {
    try {
      if (this.file == null) {
        this.thumbnail = null;
        return;
      } 
      this.thumbWidth = this.box.isSelected() ? 320 : 190;
      setPreferredSize(new Dimension(this.thumbWidth + 20, 200));
      Image buffer = null;
      try {
        if (this.file.getPath().toLowerCase().endsWith(".scr") || this.file.getPath().toLowerCase().endsWith(".sna")) {
          if (this.file.getPath().toLowerCase().endsWith(".sna")) {
            this.label.setText("CPC - SNA");
          } else if (this.file.length() < 18000L) {
            this.label.setText("CPC - SCR 16k");
          } else {
            this.label.setText("CPC - SCR 32k");
          } 
          buffer = getToolkit().getImage(this.cpcicon);
        } else if (this.file.getPath().toLowerCase().endsWith(".drw")) {
          this.label.setText("CPC - DRW - 320x200px");
          try {
            byte[] buff = new byte[(int)this.file.length()];
            BufferedInputStream bin = new BufferedInputStream(new FileInputStream(this.file));
            bin.read(buff);
            bin.close();
            BufferedImage doodle = this.canv.importDoodle(buff, false);
            buffer = doodle.getScaledInstance(this.thumbWidth, -1, 4);
          } catch (Exception exception) {}
        } else {
          buffer = this.imageImporter.readImage(this.file.getPath());
          this.label.setText(this.imageImporter.getFileType() + " - " + buffer.getWidth(null) + "x" + buffer.getHeight(null) + "px");
        } 
      } catch (Exception e) {
        buffer = getToolkit().getImage(this.cpcicon);
        this.label.setText("Unknown format");
      } 
      ImageIcon tmpIcon = new ImageIcon(buffer);
      if (tmpIcon.getIconWidth() > this.thumbWidth) {
        this.thumbnail = new ImageIcon(tmpIcon.getImage().getScaledInstance(this.thumbWidth, -1, 4));
      } else {
        this.thumbnail = tmpIcon;
      } 
    } catch (Exception exception) {}
  }
  
  public void propertyChange(PropertyChangeEvent e) {
    boolean update = false;
    String prop = e.getPropertyName();
    if ("directoryChanged".equals(prop)) {
      this.file = null;
      update = true;
    } else if ("SelectedFileChangedProperty".equals(prop)) {
      this.file = (File)e.getNewValue();
      update = true;
    } 
    if (update) {
      this.thumbnail = null;
      if (isShowing()) {
        loadImage();
        repaint();
      } 
    } 
  }
  
  protected void paintComponent(Graphics g) {
    if (this.thumbnail == null)
      loadImage(); 
    if (this.thumbnail != null) {
      int x = getWidth() / 2 - this.thumbnail.getIconWidth() / 2;
      int y = getHeight() / 2 - this.thumbnail.getIconHeight() / 2;
      if (y < 0)
        y = 0; 
      if (x < 5)
        x = 5; 
      this.thumbnail.paintIcon(this, g, x, y);
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\paint\ImagePreview.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */