package jemu.ui.paint;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.LayoutStyle;
import jemu.system.cpc.CPC;

public class ImageProcessor extends JPanel {
  final URL cursorim = getClass().getResource("colpick.gif");
  
  final Image pick = getToolkit().getImage(this.cursorim);
  
  Cursor picker;
  
  public ImageProcessor() {
    this.picker = Toolkit.getDefaultToolkit().createCustomCursor(this.pick, new Point(0, 14), "Colorpicker");
    initComponents();
    this.jPanel2.setVisible(false);
    this.image.setCursor(this.picker);
    dlabel.setEnabled(false);
    divider.setEnabled(false);
    this.tlabel.setEnabled(false);
    tolerance.setEnabled(false);
    this.dividerSetter.plus.setEnabled(false);
    this.dividerSetter.minus.setEnabled(false);
    this.toleranceSetter.plus.setEnabled(false);
    this.toleranceSetter.minus.setEnabled(false);
  }
  
  private void initComponents() {
    this.image = new JLabel();
    this.buttons = new JPanel();
    this.but1 = new JPanel();
    this.but2 = new JPanel();
    this.but3 = new JPanel();
    this.but4 = new JPanel();
    this.Presets = new JComboBox();
    this.jLabel1 = new JLabel();
    plus = new JCheckBox();
    tolerance = new JSlider();
    this.tlabel = new JLabel();
    divider = new JSlider();
    dlabel = new JLabel();
    this.jPanel1 = new JPanel();
    this.jPanel2 = new JPanel();
    method1 = new JCheckBox();
    method = new JCheckBox();
    col = new JPanel();
    method2 = new JSlider();
    this.toleranceSetter = new PlusMinus();
    this.dividerSetter = new PlusMinus();
    ordered = new JCheckBox();
    preorder = new JCheckBox();
    precalculate = new JCheckBox();
    this.sliders = new JPanel();
    this.image.setMaximumSize(new Dimension(384, 272));
    this.image.setMinimumSize(new Dimension(384, 272));
    this.image.setPreferredSize(new Dimension(384, 272));
    this.buttons.setPreferredSize(new Dimension(200, 100));
    this.but1.setBorder(BorderFactory.createEtchedBorder());
    this.but1.setMinimumSize(new Dimension(90, 30));
    this.but1.setPreferredSize(new Dimension(90, 30));
    this.but1.setRequestFocusEnabled(false);
    this.but1.setLayout(new BorderLayout());
    this.but2.setBorder(BorderFactory.createEtchedBorder());
    this.but2.setMinimumSize(new Dimension(90, 30));
    this.but2.setPreferredSize(new Dimension(90, 30));
    this.but2.setLayout(new BorderLayout());
    this.but3.setBorder(BorderFactory.createEtchedBorder());
    this.but3.setMinimumSize(new Dimension(90, 30));
    this.but3.setPreferredSize(new Dimension(90, 30));
    this.but3.setLayout(new BorderLayout());
    this.but4.setBorder(BorderFactory.createEtchedBorder());
    this.but4.setMinimumSize(new Dimension(90, 30));
    this.but4.setPreferredSize(new Dimension(90, 30));
    this.but4.setLayout(new BorderLayout());
    this.Presets.setFont(new Font("Tahoma", 1, 10));
    this.Presets.setModel(new DefaultComboBoxModel<>(new String[] { "Default", "Improve Photo", "Improve Painting", "Pop-Art", "Martian Faces", "High Contrast", "Stretch Detail", "Natural Adaption", "Overpixel" }));
    this.jLabel1.setText(" ");
    plus.setText("PLUS");
    plus.setFocusPainted(false);
    plus.setFocusable(false);
    plus.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            ImageProcessor.this.plusActionPerformed(evt);
          }
        });
    tolerance.setMajorTickSpacing(20);
    tolerance.setMinorTickSpacing(5);
    tolerance.setPaintTicks(true);
    tolerance.setSnapToTicks(true);
    tolerance.setValue(60);
    this.tlabel.setText("Tolerance");
    divider.setMajorTickSpacing(20);
    divider.setMinorTickSpacing(5);
    divider.setPaintTicks(true);
    divider.setSnapToTicks(true);
    divider.setValue(70);
    dlabel.setText("Balancing");
    this.jPanel1.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel1.setMinimumSize(new Dimension(4, 60));
    this.jPanel1.setPreferredSize(new Dimension(200, 200));
    this.jPanel1.setLayout(new BorderLayout());
    method1.setText("Method B");
    method1.setFocusPainted(false);
    method1.setFocusable(false);
    method1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            ImageProcessor.this.method1ActionPerformed(evt);
          }
        });
    this.jPanel2.add(method1);
    method.setText("Method C");
    method.setFocusPainted(false);
    method.setFocusable(false);
    method.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            ImageProcessor.this.methodActionPerformed(evt);
          }
        });
    this.jPanel2.add(method);
    this.jPanel1.add(this.jPanel2, "North");
    GroupLayout colLayout = new GroupLayout(col);
    col.setLayout(colLayout);
    colLayout.setHorizontalGroup(colLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 176, 32767));
    colLayout.setVerticalGroup(colLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 24, 32767));
    this.jPanel1.add(col, "Center");
    method2.setMajorTickSpacing(16);
    method2.setMaximum(64);
    method2.setMinorTickSpacing(2);
    method2.setPaintTicks(true);
    method2.setSnapToTicks(true);
    method2.setValue(0);
    method2.setInverted(true);
    method2.setPreferredSize(new Dimension(100, 23));
    ordered.setText("Ord.");
    ordered.setFocusPainted(false);
    ordered.setFocusable(false);
    preorder.setText("<>");
    precalculate.setText("PreCalc");
    precalculate.setFocusPainted(false);
    precalculate.setFocusable(false);
    GroupLayout buttonsLayout = new GroupLayout(this.buttons);
    this.buttons.setLayout(buttonsLayout);
    buttonsLayout.setHorizontalGroup(buttonsLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(buttonsLayout.createSequentialGroup()
          .addGap(10, 10, 10)
          .addGroup(buttonsLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addGroup(buttonsLayout.createSequentialGroup()
              .addComponent(this.but1, -2, -1, -2)
              .addGap(0, 0, 0)
              .addComponent(this.but2, -2, -1, -2))
            .addComponent(this.jPanel1, -2, 180, -2)
            .addComponent(method2, -2, 180, -2)
            .addGroup(buttonsLayout.createSequentialGroup()
              .addComponent(this.but3, -2, -1, -2)
              .addGap(0, 0, 0)
              .addComponent(this.but4, -2, -1, -2))
            .addGroup(buttonsLayout.createSequentialGroup()
              .addComponent(this.Presets, -2, 100, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(plus, -1, -1, 32767))
            .addGroup(buttonsLayout.createSequentialGroup()
              .addGroup(buttonsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(buttonsLayout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
                  .addComponent(dlabel, GroupLayout.Alignment.LEADING, -1, -1, 32767)
                  .addComponent(this.tlabel, GroupLayout.Alignment.LEADING, -1, -1, 32767))
                .addComponent(ordered))
              .addGroup(buttonsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(buttonsLayout.createSequentialGroup()
                  .addGap(10, 10, 10)
                  .addGroup(buttonsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(buttonsLayout.createSequentialGroup()
                      .addComponent(this.dividerSetter, -2, -1, -2)
                      .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                      .addComponent(divider, -2, 105, -2))
                    .addGroup(buttonsLayout.createSequentialGroup()
                      .addComponent(this.toleranceSetter, -2, -1, -2)
                      .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                      .addComponent(tolerance, -2, 105, -2))))
                .addGroup(buttonsLayout.createSequentialGroup()
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(precalculate)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(preorder)
                  .addGap(25, 25, 25)
                  .addComponent(this.jLabel1)))))
          .addContainerGap(-1, 32767)));
    buttonsLayout.setVerticalGroup(buttonsLayout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(buttonsLayout.createSequentialGroup()
          .addContainerGap()
          .addGroup(buttonsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.Presets, -2, -1, -2)
            .addComponent(plus))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(buttonsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.but1, -2, -1, -2)
            .addComponent(this.but2, -2, -1, -2))
          .addGroup(buttonsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.but3, -2, -1, -2)
            .addComponent(this.but4, -2, -1, -2))
          .addGroup(buttonsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(buttonsLayout.createSequentialGroup()
              .addGap(8, 8, 8)
              .addComponent(this.jLabel1))
            .addGroup(buttonsLayout.createSequentialGroup()
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addGroup(buttonsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(ordered)
                .addComponent(precalculate, -2, 26, -2)
                .addComponent(preorder))))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(buttonsLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(tolerance, -2, 26, -2)
            .addComponent(this.tlabel, -1, -1, 32767)
            .addComponent(this.toleranceSetter, -1, -1, 32767))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(buttonsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(dlabel, -2, 27, -2)
            .addGroup(buttonsLayout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
              .addComponent(this.dividerSetter, GroupLayout.Alignment.LEADING, -1, -1, 32767)
              .addComponent(divider, -2, 26, -2)))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.jPanel1, -2, 60, -2)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, 32767)
          .addComponent(method2, -2, -1, -2)
          .addGap(19, 19, 19)));
    this.sliders.setBorder(BorderFactory.createEtchedBorder());
    GroupLayout layout = new GroupLayout(this);
    setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
              .addContainerGap(-1, 32767)
              .addComponent(this.image, -2, 384, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.buttons, -2, -1, -2))
            .addComponent(this.sliders, -1, -1, 32767))
          .addContainerGap()));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
          .addComponent(this.sliders, -2, 159, -2)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.buttons, -2, 303, -2)
            .addComponent(this.image, -2, 272, -2))
          .addContainerGap(-1, 32767)));
    this.image.getAccessibleContext().setAccessibleName("image");
  }
  
  public static boolean OVERRIDE = false;
  
  public JComboBox Presets;
  
  public JPanel but1;
  
  public JPanel but2;
  
  public JPanel but3;
  
  public JPanel but4;
  
  public JPanel buttons;
  
  public static JPanel col;
  
  public static JSlider divider;
  
  public PlusMinus dividerSetter;
  
  public static JLabel dlabel;
  
  public JLabel image;
  
  private JLabel jLabel1;
  
  private JPanel jPanel1;
  
  private JPanel jPanel2;
  
  public static JCheckBox method;
  
  public static JCheckBox method1;
  
  public static JSlider method2;
  
  public static JCheckBox ordered;
  
  public static JCheckBox plus;
  
  public static JCheckBox precalculate;
  
  public static JCheckBox preorder;
  
  public JPanel sliders;
  
  private JLabel tlabel;
  
  public static JSlider tolerance;
  
  public PlusMinus toleranceSetter;
  
  private void plusActionPerformed(ActionEvent evt) {
    if (!OVERRIDE) {
      if (CPC.normalPaintBox != null && CPC.normalPaintBox.isVisible()) {
        PaintCanvas.plusmode = plus.isSelected();
        if (!PaintCanvas.plusmode)
          PaintCanvas.resetCPCColours(); 
      } else {
        OverscanCanvas.plusmode = plus.isSelected();
        if (!OverscanCanvas.plusmode)
          OverscanCanvas.resetCPCColours(); 
      } 
      dlabel.setEnabled(plus.isSelected());
      divider.setEnabled(plus.isSelected());
      this.tlabel.setEnabled(plus.isSelected());
      tolerance.setEnabled(plus.isSelected());
      this.dividerSetter.plus.setEnabled(plus.isSelected());
      this.dividerSetter.minus.setEnabled(plus.isSelected());
      this.toleranceSetter.plus.setEnabled(plus.isSelected());
      this.toleranceSetter.minus.setEnabled(plus.isSelected());
    } 
  }
  
  private void method1ActionPerformed(ActionEvent evt) {
    if (method1.isSelected())
      method.setSelected(false); 
  }
  
  private void methodActionPerformed(ActionEvent evt) {
    if (method.isSelected())
      method1.setSelected(false); 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\paint\ImageProcessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */