package jemu.ui.paint;

import com.sun.j3d.utils.applet.MainFrame;
import com.sun.j3d.utils.geometry.Sphere;
import com.sun.j3d.utils.universe.SimpleUniverse;
import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Component;
import java.awt.GraphicsConfiguration;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.media.j3d.AmbientLight;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.Bounds;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.DirectionalLight;
import javax.media.j3d.Node;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.swing.Timer;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;

public class BouncingBall extends Applet implements ActionListener, KeyListener {
  private Button go = new Button("Go");
  
  private TransformGroup objTrans;
  
  private Transform3D trans = new Transform3D();
  
  private float height = 0.0F;
  
  private float sign = 1.0F;
  
  private Timer timer;
  
  private float xloc = 0.0F;
  
  public BranchGroup createSceneGraph() {
    BranchGroup objRoot = new BranchGroup();
    this.objTrans = new TransformGroup();
    this.objTrans.setCapability(18);
    objRoot.addChild((Node)this.objTrans);
    Sphere sphere = new Sphere(0.25F, 3, 256);
    this.objTrans = new TransformGroup();
    this.objTrans.setCapability(18);
    Transform3D pos1 = new Transform3D();
    pos1.setTranslation(new Vector3f(0.0F, 0.0F, 0.0F));
    this.objTrans.setTransform(pos1);
    this.objTrans.addChild((Node)sphere);
    objRoot.addChild((Node)this.objTrans);
    BoundingSphere bounds = new BoundingSphere(new Point3d(0.0D, 0.0D, 0.0D), 100.0D);
    Color3f light1Color = new Color3f(1.0F, 0.0F, 0.2F);
    Vector3f light1Direction = new Vector3f(4.0F, -7.0F, -12.0F);
    DirectionalLight light1 = new DirectionalLight(light1Color, light1Direction);
    light1.setInfluencingBounds((Bounds)bounds);
    objRoot.addChild((Node)light1);
    Color3f ambientColor = new Color3f(1.0F, 1.0F, 1.0F);
    AmbientLight ambientLightNode = new AmbientLight(ambientColor);
    ambientLightNode.setInfluencingBounds((Bounds)bounds);
    objRoot.addChild((Node)ambientLightNode);
    return objRoot;
  }
  
  public BouncingBall() {
    setLayout(new BorderLayout());
    GraphicsConfiguration config = SimpleUniverse.getPreferredConfiguration();
    Canvas3D c = new Canvas3D(config);
    add("Center", (Component)c);
    c.addKeyListener(this);
    this.timer = new Timer(25, this);
    Panel p = new Panel();
    p.add(this.go);
    add("North", p);
    this.go.addActionListener(this);
    this.go.addKeyListener(this);
    BranchGroup scene = createSceneGraph();
    SimpleUniverse u = new SimpleUniverse(c);
    u.getViewingPlatform().setNominalViewingTransform();
    u.addBranchGraph(scene);
  }
  
  public void keyPressed(KeyEvent e) {
    if (e.getKeyChar() == 's')
      this.xloc += 0.1F; 
    if (e.getKeyChar() == 'a')
      this.xloc -= 0.1F; 
  }
  
  public void keyReleased(KeyEvent e) {}
  
  public void keyTyped(KeyEvent e) {}
  
  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == this.go) {
      if (!this.timer.isRunning())
        this.timer.start(); 
    } else {
      this.height = (float)(this.height + 0.1D * this.sign);
      if (Math.abs(this.height * 2.0F) >= 1.0F)
        this.sign = -1.0F * this.sign; 
      if (this.height < -0.4F) {
        this.trans.setScale(new Vector3d(1.0D, 0.8D, 1.0D));
      } else {
        this.trans.setScale(new Vector3d(1.0D, 1.0D, 1.0D));
      } 
      this.trans.setTranslation(new Vector3f(this.xloc, this.height, 0.0F));
      this.objTrans.setTransform(this.trans);
    } 
  }
  
  public static void main(String[] args) {
    System.out.println("Program Started");
    BouncingBall bb = new BouncingBall();
    bb.addKeyListener(bb);
    MainFrame mf = new MainFrame(bb, 800, 800);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\paint\BouncingBall.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */