package jemu.ui.paint;

import com.jhlabs.image.BumpFilter;
import com.jhlabs.image.ContrastFilter;
import com.jhlabs.image.GainFilter;
import com.jhlabs.image.HSBAdjustFilter;
import com.jhlabs.image.QuantizeFilter;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Arrays;
import java.util.Collections;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import jemu.core.Util;
import jemu.core.samples.Samples;
import jemu.settings.DSettings;
import jemu.system.cpc.CPC;
import jemu.system.cpc.GateArray;
import jemu.ui.Display;
import jemu.ui.JEMU;
import jemu.ui.Switches;

public class PaintCanvas extends JLabel implements MouseListener, MouseMotionListener {
  public static String dragname = null;
  
  MovieMaker maker;
  
  public static byte[] flipscreenA;
  
  public static byte[] flipscreenB;
  
  protected int[] paletteA;
  
  protected int[] paletteB;
  
  Color crossfade1;
  
  Color crossfade2;
  
  public boolean stretch = false;
  
  JFrame zoomframe;
  
  JLabel zoomarea;
  
  BufferedImage zoompic;
  
  CPCize lut = new CPCize();
  
  RGBColor color = new RGBColor();
  
  public static boolean green = false;
  
  public static int ditherval = 120;
  
  int[] CPCpalette = new int[] { 111, 111 };
  
  public static boolean blur = false;
  
  public static boolean sharp = false;
  
  float ninth = 0.25F;
  
  public static final float[] SHARPEN3x3 = new float[] { 0.0F, -1.0F, 0.0F, -1.0F, 5.0F, -1.0F, 0.0F, -1.0F, 0.0F };
  
  public static final float[] BLUR3x3 = new float[] { 0.1F, 0.1F, 0.1F, 0.1F, 0.2F, 0.1F, 0.1F, 0.1F, 0.1F };
  
  int[] c64 = new int[] { 
      0, 16711422, 12148224, 5723991, 15722084, 13027014, 7591094, 10263708, 9435279, 2302371, 
      5944607, 6136794, 14455686, 12014766, 5646336, 9973248 };
  
  int[] C64ToCPC = new int[] { 
      0, 26, 15, 12, 24, 25, 14, 10, 20, 1, 
      2, 4, 16, 7, 3, 6 };
  
  int[] greenscreen = new int[] { 
      0, 2, 3, 5, 7, 9, 10, 12, 14, 15, 
      17, 19, 20, 22, 24, 26 };
  
  BufferedImageOp blurOp = new ConvolveOp(new Kernel(3, 3, BLUR3x3));
  
  BufferedImageOp sharpOp = new ConvolveOp(new Kernel(3, 3, SHARPEN3x3));
  
  public String importname = null;
  
  protected int importscr = 0;
  
  String[] output = new String[] { "" };
  
  String minitext = "";
  
  int textpen = 1;
  
  int smoothpen = 16;
  
  int minisize = 0;
  
  int transback = 16;
  
  boolean debug = false;
  
  public static int filled;
  
  boolean resPal = false;
  
  int RedPixel;
  
  int GreenPixel;
  
  int BluePixel;
  
  int startup = 1;
  
  miniFont minifont = new miniFont();
  
  JCheckBox restorePal = new JCheckBox("Restore palette");
  
  public Color random = new Color(20, 60, 90);
  
  public int[] realInks = new int[27];
  
  public int checkPal = 0;
  
  boolean flip;
  
  public int transpen = 17;
  
  int shapeX;
  
  int shapeY;
  
  int shapeW;
  
  int shapeH;
  
  public int bold = 0;
  
  public int italic = 0;
  
  byte[] input;
  
  public boolean gray = false;
  
  String loadname = "";
  
  public String showname = "JavaCPC Paint 1.0";
  
  BufferedImage posterizedImage = null;
  
  BufferedImage scrollImage = null;
  
  BufferedImage sourceImage = null;
  
  BufferedImage loadedImage = null;
  
  BufferedImage shapeBrush = null;
  
  BufferedImage CPCImage = null;
  
  BufferedImage CPCScreen = null;
  
  boolean doCycle = true;
  
  public static int recalculate = 0;
  
  int[] counted;
  
  protected String[] cpccolors = new String[] { 
      "Black", "Blue", "Bright Blue", "Red", "Magenta", "Mauve", "Bright Red", "Purple", "Bright Magenta", "Green", 
      "Cyan", "Sky Blue", "Yellow", "White", "Pastel Blue", "Orange", "Pink", "Pastel Magenta", "Bright Green", "Sea Green", 
      "Bright Cyan", "Lime", "Pastel Green", "Pastel Cyan", "Bright Yellow", "Pastel Yellow", "Bright White" };
  
  protected static int[] GateArrayINKs = new int[] { 
      20, 4, 21, 28, 24, 29, 12, 5, 13, 22, 
      6, 23, 30, 0, 31, 14, 7, 15, 18, 2, 
      19, 26, 25, 27, 10, 3, 11 };
  
  protected static int[] GateArrayColors = new int[] { 
      0, 125, 255, 8192000, 8192125, 8192255, 16711680, 16711805, 16711935, 32000, 
      32125, 32255, 8224000, 8224125, 8224255, 16743680, 16743805, 16743935, 65280, 65405, 
      65535, 8257280, 8257405, 8257535, 16776960, 16777085, 16777215 };
  
  protected static final int[] GateArrayOrg = new int[] { 
      0, 125, 255, 8192000, 8192125, 8192255, 16711680, 16711805, 16711935, 32000, 
      32125, 32255, 8224000, 8224125, 8224255, 16743680, 16743805, 16743935, 65280, 65405, 
      65535, 8257280, 8257405, 8257535, 16776960, 16777085, 16777215 };
  
  public static final int[] CPC_ALT = new int[] { 
      0, 2105440, 4145087, 6299680, 6299743, 8339391, 12533567, 12533631, 12533695, 2121760, 
      2121824, 4161471, 6316064, 8421504, 10461151, 12549951, 14655391, 14655455, 4177727, 4177791, 
      4177855, 8372031, 10477471, 10477535, 12566335, 14671775, 16777215 };
  
  protected static final int[] GateArrayGreens = new int[] { 
      0, 657930, 1250067, 1907997, 2500134, 3158064, 3750201, 4408131, 5000268, 5723991, 
      6316128, 6974058, 7566195, 8224125, 8816262, 9474192, 10066329, 10724259, 11316396, 11908533, 
      12566463, 13224393, 13816530, 14474460, 15066597, 15724527, 16316664 };
  
  protected Color[] Col = new Color[27];
  
  private final int CANVAS_WIDTH = 640;
  
  private final int CANVAS_HEIGHT = 400;
  
  public int bright = 100;
  
  public int contrast = 100;
  
  public boolean keep = false;
  
  public boolean keepinks = false;
  
  public static boolean horizontal = false;
  
  public int scroll = 0;
  
  public int scrollb = 0;
  
  int cycled = 0;
  
  protected boolean paintscreen = false;
  
  public int CPCRed;
  
  public int CPCBlue;
  
  public int CPCGreen;
  
  int[] palcount;
  
  int[] outcount = new int[27];
  
  public String fontname = "Verdana";
  
  public int[] undo = new int[16384];
  
  final URL cursor1 = getClass().getResource("icons/cursor2.gif");
  
  final Image Cursor1 = getToolkit().getImage(this.cursor1);
  
  final Cursor cursor = Toolkit.getDefaultToolkit().createCustomCursor(this.Cursor1, new Point(15, 15), "Cursor");
  
  public static int MODE_PAINT = 1;
  
  public static int MODE_TEXT = 2;
  
  public static int MODE_LINE = 3;
  
  public static int MODE_RECTANGLE = 4;
  
  public static int MODE_CIRCLE = 5;
  
  public static int MODE_FRECT = 6;
  
  public static int MODE_FCIRCLE = 7;
  
  public static int MODE_IMPORT = 8;
  
  public static int MODE_COPY = 9;
  
  public static int MODE_PASTE = 10;
  
  public static int MODE_MINITEXT = 11;
  
  public static int MODE_FILL = 12;
  
  public static int MODE = MODE_PAINT;
  
  public int textX;
  
  public int textY;
  
  public String text = "";
  
  public int textsize = 30;
  
  boolean draw = false;
  
  private int lineX;
  
  private int lineY;
  
  private int toX;
  
  private int toY;
  
  protected boolean paint;
  
  private int lastX;
  
  private int lastY;
  
  public int pen = 1;
  
  public int mode = GateArray.getSMode();
  
  protected boolean painted = true;
  
  protected int zoomx;
  
  protected int zoomy;
  
  int sw = 40;
  
  int sh = 240;
  
  public void importDoodle() {
    FileDialog filedia = new FileDialog(new Frame(), "Import Doodle", 0);
    filedia.setFile("*.drw");
    filedia.setVisible(true);
    String a = filedia.getFile();
    if (a != null && a.toLowerCase().endsWith(".drw"))
      importDoodle(filedia.getDirectory(), filedia.getFile(), true); 
  }
  
  int[] doodleX = new int[3000];
  
  int[] doodleY = new int[3000];
  
  int[] doodlePEN = new int[3000];
  
  int[] doodleCMD = new int[3000];
  
  public void importDoodle(String path, String file, boolean put) {
    File f = new File(path + file);
    byte[] buff = new byte[(int)f.length()];
    try {
      BufferedInputStream bin = new BufferedInputStream(new FileInputStream(f));
      bin.read(buff);
      bin.close();
      importDoodle(buff, put);
    } catch (Exception e) {
      return;
    } 
  }
  
  BufferedImage doodlePreview = null;
  
  BufferedImage doodleImage;
  
  public BufferedImage importDoodle(byte[] buff, final boolean put) {
    this.doodlePreview = null;
    StringBuilder b = new StringBuilder();
    for (int i = 0; i < buff.length && (
      i <= 3 || (buff[i - 2] & 0xFF) != 13 || (buff[i - 1] & 0xFF) != 10 || (buff[i] & 0xFF) != 26); i++)
      b.append((char)(buff[i] & 0xFF)); 
    String result = b.toString().substring(0, b.toString().length() - 2);
    result = result.replace(" ", "");
    result = result.replace("\r", "");
    result = result.replace("\n", ",");
    String[] doodle = result.split(",");
    int off = 0;
    int pos = 0;
    int j;
    for (j = 0; j < 3000; j++) {
      this.doodleCMD[j] = 0;
      this.doodlePEN[j] = 0;
      this.doodleY[j] = 0;
      this.doodleX[j] = 0;
    } 
    for (String doodle1 : doodle) {
      switch (off) {
        case 0:
          this.doodleX[pos] = Integer.parseInt(doodle1);
          break;
        case 1:
          this.doodleY[pos] = Integer.parseInt(doodle1);
          break;
        case 2:
          this.doodlePEN[pos] = Integer.parseInt(doodle1);
          break;
        case 3:
          this.doodleCMD[pos] = Integer.parseInt(doodle1);
          break;
      } 
      off++;
      if (off > 3) {
        off = 0;
        pos++;
      } 
    } 
    this.inks[0] = GateArray.getInk(0);
    this.inks[1] = GateArray.getInk(1);
    this.inks[2] = GateArray.getInk(2);
    this.inks[3] = GateArray.getInk(3);
    for (j = 0; j < pos; j++) {
      int cmd = this.doodleCMD[j];
      if (cmd > 9 && cmd < 100) {
        cmd -= 10;
        INK(0, this.doodleX[j]);
        INK(1, this.doodleY[j]);
        INK(2, this.doodlePEN[j]);
        INK(3, cmd);
        this.dPaper = this.doodleX[j];
      } 
    } 
    final int size = pos;
    Thread v = new Thread() {
        public void run() {
          try {
            if (!put)
              Thread.sleep(250L); 
          } catch (Exception exception) {}
          PaintCanvas.this.doodlePreview = PaintCanvas.this.drawDoodle(size, put);
        }
      };
    v.start();
    if (!put)
      while (this.doodlePreview == null) {
        try {
          Thread.sleep(1L);
        } catch (Exception exception) {}
      }  
    return this.doodlePreview;
  }
  
  BufferedImage doodleBufferImage = new BufferedImage(320, 200, 1);
  
  int dither1;
  
  int dither2;
  
  int[] ditherMatrix = new int[2000000];
  
  int ditherpos = 0;
  
  int dPaper = 0;
  
  int[] inks = new int[4];
  
  final int line_bresenham = 1;
  
  final int line_dda = 2;
  
  final int line_trivial = 3;
  
  boolean moviedoubler;
  
  int mcounter;
  
  int[] fps;
  
  String moviename;
  
  boolean makemovie;
  
  public void drawLine(Graphics g, int x1, int y1, int x2, int y2, int method) {
    int dxx;
    double k;
    int dyy, rozdil;
    double q;
    int posun_x;
    double x;
    int posun_y, i, y;
    double dx = x2 - x1;
    double dy = y2 - y1;
    switch (method) {
      case 1:
        if (x1 == x2 && y1 == y2) {
          g.fillRect(x1, y1, 1, 1);
          break;
        } 
        dxx = Math.abs(x2 - x1);
        dyy = Math.abs(y2 - y1);
        rozdil = dxx - dyy;
        if (x1 < x2) {
          posun_x = 1;
        } else {
          posun_x = -1;
        } 
        if (y1 < y2) {
          posun_y = 1;
        } else {
          posun_y = -1;
        } 
        while (x1 != x2 || y1 != y2) {
          int p = 2 * rozdil;
          if (p > -dy) {
            rozdil -= dyy;
            x1 += posun_x;
          } 
          if (p < dx) {
            rozdil += dxx;
            y1 += posun_y;
          } 
          g.fillRect(x1, y1, 1, 1);
        } 
        break;
      case 2:
        if (Math.abs(y2 - y1) <= Math.abs(x2 - x1)) {
          if (x1 == x2 && y1 == y2) {
            g.fillRect(x1, y1, 1, 1);
            break;
          } 
          if (x2 < x1) {
            int tmp = x2;
            x2 = x1;
            x1 = tmp;
            tmp = y2;
            y2 = y1;
            y1 = tmp;
          } 
          double d1 = dy / dx;
          double d2 = y1;
          for (int j = x1; j <= x2; j++) {
            int cele_y = (int)Math.round(d2);
            g.fillRect(j, cele_y, 1, 1);
            d2 += d1;
          } 
          break;
        } 
        if (y2 < y1) {
          int tmp = x2;
          x2 = x1;
          x1 = tmp;
          tmp = y2;
          y2 = y1;
          y1 = tmp;
        } 
        k = dx / dy;
        x = x1;
        for (y = y1; y <= y2; y++) {
          int cele_x = (int)Math.round(x);
          g.fillRect(cele_x, y, 1, 1);
          x += k;
        } 
        break;
      case 3:
        if (Math.abs(y2 - y1) >= Math.abs(x2 - x1)) {
          if (x1 == x2 && y1 == y2) {
            g.fillRect(x1, y1, 1, 1);
            break;
          } 
          if (y2 < y1) {
            int tmp = x2;
            x2 = x1;
            x1 = tmp;
            tmp = y2;
            y2 = y1;
            y1 = tmp;
          } 
          k = dx / dy;
          double d = x1 - k * y1;
          for (int j = y1; j < y2; j++) {
            int m = (int)(k * j + d);
            g.fillRect(m, j, 1, 1);
          } 
          break;
        } 
        if (x2 < x1) {
          int tmp = x2;
          x2 = x1;
          x1 = tmp;
          tmp = y2;
          y2 = y1;
          y1 = tmp;
        } 
        k = dy / dx;
        q = y1 - k * x1;
        for (i = x1; i < x2; i++) {
          y = (int)(k * i + q);
          g.fillRect(i, y, 1, 1);
        } 
        break;
    } 
  }
  
  private BufferedImage drawDoodle(int size, boolean put) {
    for (int i = 0; i < size; i++) {
      int cmd = this.doodleCMD[i];
      if (cmd > 9 && cmd < 100) {
        cmd -= 10;
        INK(0, this.doodleX[i]);
        INK(1, this.doodleY[i]);
        INK(2, this.doodlePEN[i]);
        INK(3, cmd);
        this.dPaper = this.doodleX[i];
      } 
    } 
    Graphics p = this.doodleBufferImage.getGraphics();
    p.setColor(CPC.Palcols[this.dPaper]);
    p.fillRect(0, 0, 320, 200);
    BufferedImage off_Image = new BufferedImage(320, 200, 1);
    Graphics page = off_Image.getGraphics();
    page.drawImage(this.doodleBufferImage, 0, 0, null);
    int posX = 0, posY = 0, X = 0, Y = 0;
    for (int j = 0; j < size; j++) {
      int xp = this.doodleX[j] >> 1;
      int yp = (int)(199.0D - Math.floor(this.doodleY[j] * 0.5D));
      int cmd = this.doodleCMD[j];
      if (cmd > 3 && cmd < 10) {
        X = xp;
        Y = yp;
        switch (cmd) {
          case 4:
            this.dither1 = 0;
            this.dither2 = 1;
            break;
          case 5:
            this.dither1 = 0;
            this.dither2 = 2;
            break;
          case 6:
            this.dither1 = 0;
            this.dither2 = 3;
            break;
          case 7:
            this.dither1 = 1;
            this.dither2 = 2;
            break;
          case 8:
            this.dither1 = 1;
            this.dither2 = 3;
            break;
          default:
            this.dither1 = 2;
            this.dither2 = 3;
            break;
        } 
        for (int d = 0; d < this.ditherMatrix.length; d++)
          this.ditherMatrix[d] = -1; 
        this.ditherpos = 0;
        if (getCOL(test(X, Y, off_Image)) == getCOL(CPC.getCol(this.dither1))) {
          int dither3 = this.dither1;
          this.dither1 = this.dither2;
          this.dither2 = dither3;
        } 
        this.pen = this.dither1;
        Fill(X, Y, off_Image, true);
        posX = X;
        posY = Y;
        int ap = 0;
        for (int k = 0; k < this.ditherMatrix.length; k += 2) {
          if (this.ditherMatrix[k] >= 0) {
            int plot, x = this.ditherMatrix[k];
            int y = this.ditherMatrix[k + 1];
            if (x % 2 == 1) {
              ap = 1;
            } else {
              ap = 0;
            } 
            if (y % 2 == 1)
              if (ap == 0) {
                ap = 1;
              } else {
                ap = 0;
              }  
            if (ap == 1) {
              plot = this.dither1;
            } else {
              plot = this.dither2;
            } 
            page.setColor(CPC.getCol(plot));
            page.fillRect(x, y, 1, 1);
          } 
        } 
      } else {
        switch (cmd) {
          case 0:
            posX = xp;
            posY = yp;
            page.setColor(CPC.getCol(this.doodlePEN[j]));
            this.pen = this.doodlePEN[j];
            break;
          case 1:
          case 2:
            X = xp;
            Y = yp;
            page.setColor(CPC.getCol(this.doodlePEN[j]));
            this.pen = this.doodlePEN[j];
            switch (cmd) {
              case 1:
                if (X > posX) {
                  page.drawLine(posX, posY, X, Y);
                  break;
                } 
                page.drawLine(X, Y, posX, posY);
                break;
              case 2:
                page.fillRect(X, Y, 1, 1);
                break;
            } 
            posX = X;
            posY = Y;
            break;
          case 3:
            posX = X = xp;
            posY = Y = yp;
            this.pen = this.doodlePEN[j];
            Fill(X, Y, off_Image, false);
            break;
        } 
      } 
      if (j % 10 == 0 && put)
        buildDoodleScreen(off_Image); 
    } 
    if (put) {
      buildDoodleScreen(off_Image);
    } else {
      INK(0, this.inks[0]);
      INK(1, this.inks[1]);
      INK(2, this.inks[2]);
      INK(3, this.inks[3]);
    } 
    return off_Image;
  }
  
  double getDist(int posX, int posY, int X, int Y) {
    double DT = Math.sqrt(Math.pow((posX - X), 2.0D) + Math.pow((posY - Y), 2.0D));
    return DT;
  }
  
  int[] getPos(double DT, double D, int a, int b, int c, int d) {
    double T = D / DT;
    int[] result = { (int)Math.round((1.0D - T) * a + T * c), (int)Math.round((1.0D - T) * b + T * d) };
    return result;
  }
  
  public void buildDoodleScreen(BufferedImage image) {
    for (int y = 0; y < 200; y++) {
      for (int x = 0; x < 320; x++) {
        for (int i = 0; i < 4; i++) {
          Color test = new Color(image.getRGB(x, y));
          Color testb = CPC.getCol(i);
          if (green)
            testb = CPC.getGCol(i); 
          if (getCOL(test) == getCOL(testb))
            plot(x, y, i); 
        } 
      } 
    } 
    putScreen();
  }
  
  public void putFlipA() {
    System.arraycopy(GateArray.screenmemory, 49152, flipscreenA, 0, 16384);
    for (int i = 0; i < 16; i++)
      this.paletteA[i] = GateArray.getInk(i); 
  }
  
  public void putFlipB() {
    System.arraycopy(GateArray.screenmemory, 49152, flipscreenB, 0, 16384);
    for (int i = 0; i < 16; i++)
      this.paletteB[i] = GateArray.getInk(i); 
  }
  
  public void getFlipA() {
    System.arraycopy(flipscreenA, 0, GateArray.screenmemory, 49152, 16384);
    for (int i = 0; i < 16; i++)
      INK(i, this.paletteA[i]); 
  }
  
  public void getFlipB() {
    System.arraycopy(flipscreenB, 0, GateArray.screenmemory, 49152, 16384);
    for (int i = 0; i < 16; i++)
      INK(i, this.paletteB[i]); 
  }
  
  public void update(int count) {
    System.arraycopy(CPC.movie[count], 0, GateArray.screenmemory, 49152, 16384);
    this.maker.moviepos.setValue(count);
    this.processing = false;
    putScreen();
  }
  
  public PaintCanvas() {
    this.moviedoubler = false;
    this.mcounter = 0;
    this.fps = new int[] { 8, 10, 15, 20, 25, 30, 50 };
    this.makemovie = false;
    this.toggleRaster = false;
    this.buffer = new byte[20][16401];
    this.choosenImage = 0;
    this.screenChanged = true;
    this.count = 0;
    this.pluspalette = new byte[32];
    this.gain = new float[] { 
        -1.0F, -0.99F, -0.98F, -0.97F, -0.96F, -0.95F, -0.94F, -0.93F, -0.92F, -0.91F, 
        -0.9F, -0.89F, -0.88F, -0.87F, -0.86F, -0.85F, -0.84F, -0.83F, -0.82F, -0.81F, 
        -0.8F, -0.79F, -0.78F, -0.77F, -0.76F, -0.75F, -0.74F, -0.73F, -0.72F, -0.71F, 
        -0.7F, -0.69F, -0.68F, -0.67F, -0.66F, -0.65F, -0.64F, -0.63F, -0.62F, -0.61F, 
        -0.6F, -0.59F, -0.58F, -0.57F, -0.56F, -0.55F, -0.54F, -0.53F, -0.52F, -0.51F, 
        -0.5F, -0.49F, -0.48F, -0.47F, -0.46F, -0.45F, -0.44F, -0.43F, -0.42F, -0.41F, 
        -0.4F, -0.39F, -0.38F, -0.37F, -0.36F, -0.35F, -0.34F, -0.33F, -0.32F, -0.31F, 
        -0.3F, -0.29F, -0.28F, -0.27F, -0.26F, -0.25F, -0.24F, -0.23F, -0.22F, -0.21F, 
        -0.2F, -0.19F, -0.18F, -0.17F, -0.16F, -0.15F, -0.14F, -0.13F, -0.12F, -0.11F, 
        -0.1F, -0.09F, -0.08F, -0.07F, -0.06F, -0.05F, -0.04F, -0.03F, -0.02F, -0.01F, 
        0.0F, 0.01F, 0.02F, 0.03F, 0.04F, 0.05F, 0.06F, 0.07F, 0.08F, 0.09F, 
        0.1F, 0.11F, 0.12F, 0.13F, 0.14F, 0.15F, 0.16F, 0.17F, 0.18F, 0.19F, 
        0.2F, 0.21F, 0.22F, 0.23F, 0.24F, 0.25F, 0.26F, 0.27F, 0.28F, 0.29F, 
        0.3F, 0.31F, 0.32F, 0.33F, 0.34F, 0.35F, 0.36F, 0.37F, 0.38F, 0.39F, 
        0.4F, 0.41F, 0.42F, 0.43F, 0.44F, 0.45F, 0.46F, 0.47F, 0.48F, 0.49F, 
        0.5F, 0.51F, 0.52F, 0.53F, 0.54F, 0.55F, 0.56F, 0.57F, 0.58F, 0.59F, 
        0.6F, 0.61F, 0.62F, 0.63F, 0.64F, 0.65F, 0.66F, 0.67F, 0.68F, 0.69F, 
        0.7F, 0.71F, 0.72F, 0.73F, 0.74F, 0.75F, 0.76F, 0.77F, 0.78F, 0.79F, 
        0.8F, 0.81F, 0.82F, 0.83F, 0.84F, 0.85F, 0.86F, 0.87F, 0.88F, 0.89F, 
        0.9F, 0.91F, 0.92F, 0.93F, 0.94F, 0.95F, 0.96F, 0.97F, 0.98F, 0.99F, 
        1.0F };
    this.contrastfilter = new ContrastFilter();
    this.gfilt = new GainFilter();
    this.hsb = new HSBAdjustFilter();
    this.gainvalue = 150;
    this.sat = 100;
    this.hue = 100;
    this.paletteMethod = true;
    this.DEBUG_RENDER = false;
    this.prerender = false;
    this.imageImporter = new ImageImporter();
    this.palette = new int[16];
    this.greypal = new int[] { 
        3, 25, 16, 7, 6, 5, 10, 11, 13, 15, 
        0, 18, 20, 22, 23, 1 };
    this.zoomfactor = 1.0D;
    this.oldscroll = 0;
    this.oldscroll2 = 0;
    this.dlevel = false;
    this.bump = new BumpFilter();
    this.ctr = new ContrastFilter();
    this.lockPEN = new boolean[16];
    this.colours = new int[4096];
    this.used = new int[4096];
    this.pseudo = new BufferedImage(640, 400, 1);
    this.pals = new int[] { 
        0, 15, 8, 4, 1, 2, 3, 5, 6, 7, 
        9, 10, 11, 12, 13, 14 };
    this.autoIndex = 0;
    this.counter = 1;
    this.dark = 85;
    this.medium = 170;
    this.processing = false;
    this.cols = 0;
    this.reset = 0;
    this.waitA = 10;
    this.waitB = 30;
    this.showImage = new BufferedImage(384, 272, 4);
    this.bzm = new BufferedImage(384, 272, 1);
    this.bufferTimer = 0;
    this.undopos = 0;
    this.undo1 = new byte[16384];
    this.undo2 = new byte[16384];
    this.undo3 = new byte[16384];
    this.undo4 = new byte[16384];
    this.undo5 = new byte[16384];
    this.undo6 = new byte[16384];
    this.undo7 = new byte[16384];
    this.undo8 = new byte[16384];
    this.undo9 = new byte[16384];
    this.undo10 = new byte[16384];
    this.undo11 = new byte[16384];
    this.undo12 = new byte[16384];
    this.undo13 = new byte[16384];
    this.undo14 = new byte[16384];
    this.undo15 = new byte[16384];
    this.undo16 = new byte[16384];
    this.undo17 = new byte[16384];
    this.undo18 = new byte[16384];
    this.undo19 = new byte[16384];
    this.undo20 = new byte[16384];
    this.restoreListener = new ItemListener() {
        public void itemStateChanged(ItemEvent itemEvent) {
          int state = itemEvent.getStateChange();
          if (state == 1)
            PaintCanvas.this.resPal = true; 
          if (state == 2)
            PaintCanvas.this.resPal = false; 
        }
      };
    this.mask = 16777215;
    this.xx = new int[800];
    this.yy = new int[800];
    this.showFill = true;
    this.filling = false;
    this.MATRIX_4x4_BAYER = 1;
    this.MATRIX_8x8_BAYER = 2;
    this.MATRIX_4x4_SQUARE = 3;
    this.MATRIX_4x4_ORDERED = 4;
    this.MATRIX_4x4_LINES = 5;
    this.MATRIX_6x6_HALFTONE = 6;
    this.MATRIX_6x6_ORDERED = 7;
    this.MATRIX_8x8_ORDERED = 8;
    this.MATRIX_CLUSTER3 = 9;
    this.MATRIX_CLUSTER4 = 10;
    this.MATRIX_CLUSTER8 = 11;
    this.ditherlevel = 20;
    this.oldditherlevel = -2;
    this.dithermethod = 3;
    this.monochrome = new int[][] { { 
          0, 1118481, 2236962, 3355443, 4473924, 5592405, 6710886, 7829367, 8947848, 10066329, 
          11184810, 12303291, 13421772, 14540253, 15658734, 16777215 }, { 
          0, 5592405, 11184810, 16777215, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0 }, { 
          0, 16777215, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0 } };
    this.useMonochrome = false;
    this.makeMono = false;
    int offset = 0;
    for (int r = 0; r < 16; r++) {
      for (int g = 0; g < 16; g++) {
        for (int b = 0; b < 16; b++)
          this.colours[offset++] = GateArray.putRGB(GateArray.LUM(r), GateArray.LUM(g), GateArray.LUM(b)); 
      } 
    } 
    if (Display.doublesize) {
      this.sw = 80;
      this.sh = 480;
    } else {
      this.sw = 40;
      this.sh = 240;
    } 
    for (int pf = 0; pf < 27; pf++) {
      if (green) {
        this.Col[pf] = new Color(GateArrayGreens[pf]);
      } else {
        this.Col[pf] = new Color(GateArrayColors[pf]);
      } 
    } 
    this.maker = new MovieMaker();
    this.maker.setVisible(false);
    this.maker.setDefaultCloseOperation(1);
    flipscreenA = new byte[16384];
    flipscreenB = new byte[16384];
    this.paletteA = new int[16];
    this.paletteB = new int[16];
    this.crossfade1 = new Color(255, 80, 128);
    this.crossfade2 = new Color(128, 80, 255);
    addMouseListener(this);
    addMouseMotionListener(this);
    setCursor(this.cursor);
    setBackground(Color.white);
    setSize(640, 400);
    this.restorePal.addItemListener(this.restoreListener);
    loadScreens();
    this.zoomframe = new JFrame("Zoom area") {
        protected void processWindowEvent(WindowEvent we) {
          super.processWindowEvent(we);
          if (we.getID() == 201)
            normalPaint.zoom.setSelected(false); 
        }
      };
    this.zoomarea = new JLabel();
    this.zoomarea.setBackground(Color.black);
    this.zoomarea.setSize(400, 400);
    this.zoomarea.setPreferredSize(new Dimension(400, 400));
    this.zoomframe.add(this.zoomarea);
    this.zoomframe.pack();
    this.zoomframe.setAlwaysOnTop(true);
    this.zoomframe.setResizable(false);
    this.zoomframe.setVisible(false);
    this.zoompic = new BufferedImage(400, 400, 2);
    setPreferredSize(new Dimension(640, 400));
  }
  
  public void makeMovie() {
    System.arraycopy(GateArray.screenmemory, 49152, CPC.movie[this.mcounter++], 0, 16384);
    if (this.fps[this.maker.speed.getSelectedIndex()] == 50) {
      if (this.moviedoubler)
        CPC.moviecount++; 
      this.moviedoubler = !this.moviedoubler;
    } else {
      CPC.moviecount++;
    } 
    if (CPC.moviecount > 24999)
      CPC.moviecount = 0; 
    this.processing = false;
    putScreen();
  }
  
  public void storeMovie() {
    FileDialog filedia = new FileDialog(new Frame(), "Export animation", 1);
    filedia.setFile("*.ani");
    filedia.setVisible(true);
    String filename = filedia.getDirectory() + filedia.getFile();
    if (filename != null) {
      if (!filename.toLowerCase().endsWith(".ani"))
        filename = filename + ".ani"; 
      storeMovie(filename);
    } 
  }
  
  public void storeMovie(String filename) {
    try {
      byte[] dat = new byte[18];
      dat[0] = (byte)this.fps[this.maker.speed.getSelectedIndex()];
      dat[1] = (byte)this.mode;
      for (int i = 0; i < 16; i++)
        dat[i + 2] = (byte)GateArray.getInk(i); 
      BufferedOutputStream bis = new BufferedOutputStream(new FileOutputStream(new File(filename)));
      bis.write(dat);
      for (int j = 0; j < CPC.maxcount; j++)
        bis.write(CPC.movie[j]); 
      bis.close();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void restoreMovie() {
    FileDialog filedia = new FileDialog(new Frame(), "Import animation", 0);
    filedia.setFile("*.ani; *.anz");
    filedia.setVisible(true);
    String filename = filedia.getDirectory() + filedia.getFile();
    if (filedia.getFile() != null)
      restoreMovie(filename); 
  }
  
  public void restoreMovie(String filename) {
    if (filename.contains("nullnull"))
      return; 
    if (filename.toLowerCase().endsWith(".anz")) {
      UnzipANI(filename);
      return;
    } 
    try {
      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(new File(filename)));
      byte[] data = new byte[bis.available()];
      bis.read(data);
      bis.close();
      ANIImport(data);
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void UnzipANI(String filename) {
    try {
      InputStream in = new BufferedInputStream(new FileInputStream(filename));
      ZipInputStream zin = new ZipInputStream(in);
      ZipEntry e = zin.getNextEntry();
      unzip(zin);
      zin.close();
    } catch (Exception exception) {}
  }
  
  public void unzip(ZipInputStream zin) throws IOException {
    FileOutputStream out = new FileOutputStream("buffer.ani");
    byte[] b = new byte[512];
    int len = 0;
    while ((len = zin.read(b)) != -1)
      out.write(b, 0, len); 
    out.close();
    FileInputStream fin = new FileInputStream("buffer.ani");
    byte[] data = new byte[fin.available()];
    fin.read(data);
    fin.close();
    File fil = new File("buffer.ani");
    while (fil.exists())
      fil.delete(); 
    ANIImport(data);
  }
  
  public void ANIImport(byte[] data) {
    int off = 0;
    CPC.movieFPS = 20;
    if ((data[0] & 0xFF) > 3) {
      CPC.movieFPS = data[0] & 0xFF;
      off = 1;
    } 
    int i;
    for (i = 0; i < this.fps.length; i++) {
      if (this.fps[i] == CPC.movieFPS) {
        this.maker.speed.setSelectedIndex(i);
        break;
      } 
    } 
    this.mode = data[0 + off];
    MODE(this.mode);
    for (i = 0; i < 16; i++)
      INK(i, data[i + 1 + off]); 
    CPC.movie = new byte[(data.length - 17) / 16384][16384];
    int mcount = 0;
    int mlen = 0;
    for (int j = 17 + off; j < data.length; j++) {
      CPC.movie[mcount][mlen] = data[j];
      mlen++;
      if (mlen == 16384) {
        mlen = 0;
        mcount++;
      } 
    } 
    CPC.maxcount = mcount - 1;
    this.maker.moviepos.setMaximum(CPC.maxcount);
    this.maker.moviepos.setValue(0);
    CPC.moviecount = 0;
    CPC.playmovie = true;
  }
  
  static int moviemake = 0;
  
  boolean toggleRaster;
  
  String[] movienames;
  
  BufferedImage zoomimg;
  
  BufferedImage Cursor2;
  
  public byte[][] buffer;
  
  public int choosenImage;
  
  boolean screenChanged;
  
  int count;
  
  JFileChooser chooser;
  
  protected byte[] pluspalette;
  
  float[] gain;
  
  ContrastFilter contrastfilter;
  
  GainFilter gfilt;
  
  HSBAdjustFilter hsb;
  
  public int gainvalue;
  
  public int sat;
  
  public int hue;
  
  BufferedImage outimage;
  
  public boolean paletteMethod;
  
  boolean DEBUG_RENDER;
  
  public boolean prerender;
  
  boolean rasterToggle;
  
  ImageImporter imageImporter;
  
  int[] palette;
  
  int[] greypal;
  
  public double zoomfactor;
  
  int oldscroll;
  
  int oldscroll2;
  
  public boolean dlevel;
  
  BumpFilter bump;
  
  public void initRecord() {
    this.toggleRaster = ImageProcessor.preorder.isSelected();
    this.mcounter = 0;
    this.moviename = this.loadname;
    while (!this.moviename.endsWith("\\"))
      this.moviename = this.moviename.substring(0, this.moviename.length() - 1); 
    File a = new File(this.moviename);
    String[] buffer = a.list();
    int pos = 0;
    String ext = this.loadname;
    ext = ext.substring(ext.length() - 4);
    int i;
    for (i = 0; i < buffer.length; i++) {
      if (buffer[i].endsWith(ext))
        pos++; 
    } 
    this.movienames = new String[pos];
    pos = 0;
    for (i = 0; i < buffer.length; i++) {
      if (buffer[i].endsWith(ext))
        this.movienames[pos++] = this.moviename + buffer[i]; 
    } 
    CPC.maxcount = this.movienames.length;
    if (this.fps[this.maker.speed.getSelectedIndex()] == 50)
      CPC.maxcount = this.movienames.length * 2; 
    CPC.moviecount = 0;
    System.out.println("Frames found:" + CPC.maxcount);
    this.maker.moviepos.setMaximum(CPC.maxcount);
    moviemake = 0;
    if (!this.maker.inklock.isSelected())
      this.maker.inklock.setSelected(true); 
    CPC.moviecount = 0;
    moviemake = 0;
    CPC.movie = new byte[CPC.maxcount + 1][16384];
  }
  
  public void renderMovie() {
    try {
      String nextname = this.movienames[CPC.moviecount];
      convertScreen(nextname);
      recalculate();
      convert(false);
    } catch (Exception e) {
      this.makemovie = false;
      Samples.FINISHED.play();
      ImageProcessor.precalculate.setSelected(this.toggleRaster);
      this.toggleRaster = false;
      this.mcounter = 0;
    } 
    normalPaint.output.append("Accessed frame " + CPC.moviecount + "\r\n");
    this.maker.moviepos.setValue(CPC.moviecount);
  }
  
  public void deFlip() {
    int p = 0;
    for (int i = 0; i < 16384; i++) {
      p++;
      if (p == 2048) {
        p = 0;
        i += 2048;
      } 
      byte a = flipscreenA[i];
      byte b = flipscreenB[i];
      flipscreenA[i] = b;
      flipscreenB[i] = a;
    } 
  }
  
  public void Zoom() {
    if (!this.zoomframe.isVisible())
      return; 
    if (this.zoomimg == null)
      this.zoomimg = new BufferedImage(400, 400, 1); 
    Graphics g = this.zoomimg.getGraphics();
    int x = 200 - this.zoomx * 4;
    int y = 200 - this.zoomy * 4;
    g.setColor(Color.GRAY);
    g.fillRect(0, 0, 410, 410);
    if (Display.doublesize) {
      this.sw = 80;
      this.sh = 480;
    } else {
      this.sw = 40;
      this.sh = 240;
    } 
    if (JEMU.large) {
      g.drawImage(Display.image, x, y, x + 2560, y + 1600, 64, this.sw, 704, this.sh, this);
    } else {
      g.drawImage(Display.image, x, y, x + 2560, y + 1600, 32, this.sw, 352, this.sh, this);
    } 
    if (this.Cursor2 == null)
      try {
        this.Cursor2 = ImageIO.read(getClass().getResource("icons/crossfade.gif"));
      } catch (Exception exception) {} 
    g.drawImage(this.Cursor2, 136, 136, 128, 128, this);
    g.setColor(getColor(this.pen));
    g.fillRect(196, 196, 8, 8);
    this.zoomarea.setIcon(new ImageIcon(this.zoomimg));
  }
  
  public void mousePressed(MouseEvent event) {
    Point current;
    makeUndo();
    Point first = event.getPoint();
    this.lastX = first.x;
    this.lastY = first.y;
    int x = this.lastX;
    int y = this.lastY / 2;
    if (this.mode == 0)
      x /= 4; 
    if (this.mode == 1)
      x /= 2; 
    switch (MODE) {
      case 1:
        if (this.paint)
          plot(x, y, this.pen); 
        this.painted = true;
        putScreen();
        break;
      case 3:
        current = event.getPoint();
        this.lineX = current.x;
        this.lineY = current.y;
        break;
      case 4:
        current = event.getPoint();
        this.lineX = current.x;
        this.lineY = current.y;
        break;
      case 5:
        current = event.getPoint();
        this.lineX = current.x;
        this.lineY = current.y;
        break;
      case 6:
        current = event.getPoint();
        this.lineX = current.x;
        this.lineY = current.y;
        break;
      case 7:
        current = event.getPoint();
        this.lineX = current.x;
        this.lineY = current.y;
        break;
      case 9:
        current = event.getPoint();
        this.lineX = current.x;
        this.lineY = current.y;
        break;
    } 
  }
  
  public void mouseDragged(MouseEvent event) {
    this.bufferTimer = 0;
    Point current = event.getPoint();
    Graphics page = getGraphics();
    this.zoomx = event.getX();
    this.zoomy = event.getY();
    filled = 0;
    int xn = current.x;
    int xs = 1;
    int ys = 2;
    if (this.mode == 0)
      xs = 4; 
    if (this.mode == 1)
      xs = 2; 
    int xc = current.x / xs * xs;
    int yc = current.y / ys * ys;
    this.lineX = this.lineX / xs * xs;
    this.lineY = this.lineY / ys * ys;
    int yn = current.y / 2;
    if (this.mode == 0)
      xn /= 4; 
    if (this.mode == 1)
      xn /= 2; 
    int fromx = this.lineX;
    int fromy = this.lineY;
    int tox = this.toX - this.lineX;
    int toy = this.toY - this.lineY;
    if (this.toX < this.lineX) {
      fromx = this.toX;
      tox = this.lineX - this.toX;
    } else {
      fromx = this.lineX;
      tox = this.toX - this.lineX;
    } 
    if (this.toY < this.lineY) {
      fromy = this.toY;
      toy = this.lineY - this.toY;
    } else {
      fromy = this.lineY;
      toy = this.toY - this.lineY;
    } 
    tox = tox / xs * xs;
    toy = toy / ys * ys;
    switch (MODE) {
      case 1:
        if (this.paint)
          plot(xn, yn, this.pen); 
        this.lastX = current.x;
        this.lastY = current.y;
        putScreen();
        this.painted = true;
        break;
      case 3:
        putScreen();
        this.toX = current.x;
        this.toY = current.y;
        if (green) {
          page.setColor(CPC.getGCol(this.pen));
        } else {
          page.setColor(CPC.getCol(this.pen));
        } 
        page.setColor(this.random);
        page.drawLine(this.lineX, this.lineY, this.toX, this.toY);
        page.drawLine(this.lineX, this.lineY + 1, this.toX, this.toY + 1);
        if (this.mode == 1 || this.mode == 0) {
          page.drawLine(this.lineX + 1, this.lineY, this.toX + 1, this.toY);
          page.drawLine(this.lineX + 1, this.lineY + 1, this.toX + 1, this.toY + 1);
        } 
        if (this.mode == 0) {
          page.drawLine(this.lineX + 2, this.lineY, this.toX + 2, this.toY);
          page.drawLine(this.lineX + 2, this.lineY + 1, this.toX + 2, this.toY + 1);
          page.drawLine(this.lineX + 3, this.lineY, this.toX + 3, this.toY);
          page.drawLine(this.lineX + 3, this.lineY + 1, this.toX + 3, this.toY + 1);
        } 
        break;
      case 4:
        putScreen();
        this.toX = current.x;
        this.toY = current.y;
        if (green) {
          page.setColor(CPC.getGCol(this.pen));
        } else {
          page.setColor(CPC.getCol(this.pen));
        } 
        page.setColor(this.random);
        page.drawRect(fromx, fromy, tox, toy);
        page.drawRect(fromx, fromy + 1, tox, toy);
        if (this.mode == 1 || this.mode == 0) {
          page.drawRect(fromx + 1, fromy, tox, toy);
          page.drawRect(fromx + 1, fromy + 1, tox, toy);
        } 
        if (this.mode == 0) {
          page.drawRect(fromx + 2, fromy, tox, toy);
          page.drawRect(fromx + 2, fromy + 1, tox, toy);
          page.drawRect(fromx + 3, fromy, tox, toy);
          page.drawRect(fromx + 3, fromy + 1, tox, toy);
        } 
        break;
      case 5:
        putScreen();
        this.toX = current.x;
        this.toY = current.y;
        if (green) {
          page.setColor(CPC.getGCol(this.pen));
        } else {
          page.setColor(CPC.getCol(this.pen));
        } 
        cross(xc, yc);
        page.drawOval(fromx, fromy, tox, toy);
        break;
      case 6:
        putScreen();
        this.toX = current.x;
        this.toY = current.y;
        if (green) {
          page.setColor(CPC.getGCol(this.pen));
        } else {
          page.setColor(CPC.getCol(this.pen));
        } 
        page.setColor(this.random);
        page.fillRect(fromx, fromy, tox + xs, toy + ys);
        break;
      case 7:
        putScreen();
        this.toX = current.x;
        this.toY = current.y;
        if (green) {
          page.setColor(CPC.getGCol(this.pen));
        } else {
          page.setColor(CPC.getCol(this.pen));
        } 
        cross(xc, yc);
        page.fillOval(fromx, fromy, tox + xs, toy + ys);
        break;
      case 9:
        putScreen();
        this.toX = current.x;
        this.toY = current.y;
        if (green) {
          page.setColor(CPC.getGCol(this.pen));
        } else {
          page.setColor(CPC.getCol(this.pen));
        } 
        page.setColor(this.random);
        page.drawRect(fromx, fromy, tox, toy);
        page.drawRect(fromx, fromy + 1, tox, toy);
        this.shapeX = fromx;
        this.shapeY = fromy;
        this.shapeW = tox;
        this.shapeH = toy;
        if (this.mode == 1 || this.mode == 0) {
          page.drawRect(fromx + 1, fromy, tox, toy);
          page.drawRect(fromx + 1, fromy + 1, tox + 1, toy);
        } 
        if (this.mode == 0) {
          page.drawRect(fromx + 2, fromy, tox, toy);
          page.drawRect(fromx + 2, fromy + 1, tox, toy);
          page.drawRect(fromx + 3, fromy, tox, toy);
          page.drawRect(fromx + 3, fromy + 1, tox, toy);
        } 
        break;
      default:
        putScreen();
        break;
    } 
    page.setColor(this.crossfade2);
    page.fillRect(xc, yc + 6, xs, 10);
    page.fillRect(xc, yc - 14, xs, 10);
    page.fillRect(xc + 6, yc, xs + 10, ys);
    page.fillRect(xc - 16, yc, xs + 10, ys);
  }
  
  public void plot(int x, int y, int p) {
    CPC.PLOT(x, y, p, this.mode, false);
  }
  
  public void writeOutput() {}
  
  public void storeScreen() {
    normalPaint.output.append("Storing screen to " + this.choosenImage + "\n");
    byte[] palette = getPlusPalette();
    int i;
    for (i = 0; i < palette.length; i++)
      GateArray.screenmemory[55249 + i] = palette[i]; 
    for (i = 0; i < 16384; i++)
      this.buffer[this.choosenImage][i] = GateArray.screenmemory[49152 + i]; 
    for (i = 0; i < 16; i++)
      this.buffer[this.choosenImage][16384 + i] = (byte)GateArray.getInk(i); 
    this.buffer[this.choosenImage][16400] = (byte)this.mode;
    try {
      FileOutputStream out = new FileOutputStream(System.getProperty("user.home") + "/JavaCPC/images_normal.dat.gz");
      GZIPOutputStream gbos = new GZIPOutputStream(new BufferedOutputStream(out));
      for (int j = 0; j < 20; j++)
        gbos.write(this.buffer[j]); 
      gbos.close();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void loadScreens() {
    if (this.screenChanged)
      try {
        FileInputStream bos = new FileInputStream(System.getProperty("user.home") + "/JavaCPC/images_normal.dat.gz");
        GZIPInputStream gbos = new GZIPInputStream(new BufferedInputStream(bos));
        this.input = new byte[328021];
        this.count = 0;
        while (gbos.available() != 0) {
          this.input[this.count] = (byte)gbos.read();
          this.count++;
        } 
        gbos.close();
        int offset = 0;
        int i = 0;
        for (; i < 20; i++) {
          int d = 0;
          for (; d < 16401; d++)
            this.buffer[i][d] = this.input[offset + d]; 
          offset += 16401;
        } 
      } catch (Exception exception) {} 
    this.screenChanged = false;
  }
  
  public void restoreScreen() {
    resetCPCColours();
    normalPaint.output.append("Re-storing screen from " + this.choosenImage + "\n");
    for (int i = 0; i < 16384; i++)
      GateArray.screenmemory[49152 + i] = this.buffer[this.choosenImage][i]; 
    int ad = 55249;
    plusmode = false;
    int j;
    for (j = ad; j < ad + 32; j++) {
      if (GateArray.screenmemory[j] != 0) {
        plusmode = true;
        break;
      } 
    } 
    ImageProcessor.plus.setSelected(plusmode);
    for (j = 0; j < 16; j++)
      INK(j, this.buffer[this.choosenImage][16384 + j]); 
    if (plusmode)
      makePlus(GateArray.screenmemory, 49152); 
    this.mode = this.buffer[this.choosenImage][16400];
    MODE(this.mode);
    filled = 1;
    this.doCycle = true;
  }
  
  public void convertScreen() {
    GateArray.cpc.endFlip();
    if (this.chooser == null) {
      this.chooser = new JFileChooser();
      this.chooser.addChoosableFileFilter(new ImageWithDRWFilter());
      this.chooser.setAcceptAllFileFilterUsed(true);
      this.chooser.setFileView(new ImageFileView());
      this.chooser.setAccessory(new ImagePreview(this.chooser));
      this.chooser.setPreferredSize(new Dimension(800, 600));
      this.chooser.setMultiSelectionEnabled(false);
    } 
    this.chooser.setCurrentDirectory(new File(DSettings.get("paint_path", "")));
    filled = 0;
    recalculate = 0;
    MODE = MODE_IMPORT;
    if (this.chooser.showOpenDialog(this) == 0) {
      DSettings.set("paint_path", this.chooser.getSelectedFile().getPath());
      this.doCycle = false;
      String filename = this.chooser.getSelectedFile().getAbsolutePath();
      this.loadname = filename;
      this.showname = this.chooser.getSelectedFile().getName();
      normalPaint.output.append("Reading " + this.loadname + " in progress...\n");
      if (this.loadname.length() > 2)
        convertScreen(this.loadname); 
    } 
  }
  
  public void SCRimport(String loadname) {
    this.scr = true;
    resetCPCColours();
    System.arraycopy(CPC.pale, 0, CPC.Palcols, 0, 16);
    plusmode = false;
    filled = 0;
    try {
      BufferedInputStream bos = new BufferedInputStream(new FileInputStream(loadname));
      this.input = new byte[bos.available()];
      this.count = 0;
      while (bos.available() > 0) {
        this.input[this.count] = (byte)bos.read();
        this.count++;
      } 
      bos.close();
      boolean plus = false;
      int start = 0;
      if (this.input.length > 16384)
        start = 128; 
      if (this.input[2000 + start] == -13 && this.input[2001 + start] == 1) {
        plus = true;
      } else {
        plus = false;
      } 
      int address = 49152;
      byte mod = this.input[6096 + start];
      System.out.println("Found: " + Util.hex(mod));
      int smode = 0;
      if (mod == -116 || mod == 0)
        smode = 0; 
      if (mod == -115 || mod == 1)
        smode = 1; 
      if (mod == -114 || mod == 2)
        smode = 2; 
      MODE(smode);
      int pal = 6097 + start;
      if (!plus)
        for (int j = 0; j < 16; j++)
          INK(j, this.input[pal + j]);  
      for (int i = start; i < this.input.length; i++)
        GateArray.screenmemory[address++] = this.input[i]; 
      if (plus) {
        plusmode = true;
        ImageProcessor.plus.setSelected(true);
        ImageProcessor.divider.setEnabled(true);
        ImageProcessor.dlabel.setEnabled(true);
        makePlus(this.input, start);
      } else {
        ImageProcessor.plus.setSelected(false);
        ImageProcessor.divider.setEnabled(false);
        ImageProcessor.dlabel.setEnabled(false);
      } 
      plus = false;
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  public void SNAimport(String loadname) {
    System.out.println("Importing SNA: " + loadname);
    this.scr = true;
    resetCPCColours();
    System.arraycopy(CPC.pale, 0, CPC.Palcols, 0, 16);
    plusmode = false;
    filled = 0;
    try {
      BufferedInputStream bos = new BufferedInputStream(new FileInputStream(loadname));
      this.input = new byte[65792];
      this.count = 0;
      while (bos.available() > 0 && this.count < this.input.length) {
        this.input[this.count] = (byte)bos.read();
        this.count++;
      } 
      bos.close();
      int mod = this.input[64] & 0x3;
      MODE(mod);
      for (int i = 0; i < 17; i++)
        INK(i, GateArray.palette[this.input[47 + i]]); 
      int scroff = 49152;
      for (int j = scroff; j < scroff + 16384; j++)
        GateArray.screenmemory[j] = this.input[j + 256]; 
      ImageProcessor.plus.setSelected(false);
      ImageProcessor.divider.setEnabled(false);
      ImageProcessor.dlabel.setEnabled(false);
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  public void MODE(int mod) {
    System.out.println("Mode: " + mod);
    if (mod == 0) {
      CPC.POKE(36863, 3);
    } else {
      CPC.POKE(36863, mod);
    } 
  }
  
  public static void resetCPCColours() {
    System.arraycopy(GateArrayOrg, 0, GateArrayColors, 0, GateArrayColors.length);
    GateArray.resetCPCColours();
    for (int i = 0; i < 27; i++)
      CPC.Palcols[i] = new Color(GateArrayColors[i]); 
  }
  
  public void makePlus(byte[] in, int start) {
    int ad = 6097 + start;
    byte mod = in[6096 + start];
    System.out.println("Found: " + Util.hex(mod));
    int smode = 0;
    if (mod == -116)
      smode = 0; 
    if (mod == -115)
      smode = 1; 
    if (mod == -114)
      smode = 2; 
    System.out.println("Mode: " + smode);
    MODE(smode);
    try {
      int pos = 0;
      this.pluspalette = new byte[32];
      for (int i = 0; i < 16; i++) {
        byte p = in[ad];
        this.pluspalette[pos] = p;
        String b1 = Util.hex(p);
        p = in[ad + 1];
        this.pluspalette[pos + 1] = p;
        ad += 2;
        pos += 2;
        String b2 = Util.hex(p);
        b2 = b2.substring(1);
        String result = b1 + b2;
        String r = "" + result.charAt(0);
        String b = "" + result.charAt(1);
        String g = "" + result.charAt(2);
        result = r + r + g + g + b + b;
        System.out.print(result + ",");
        CPC.Palcols[i] = new Color(Util.hexValue(result));
        GateArrayColors[i] = Util.hexValue(result);
        GateArray.setPalette(i, Util.hexValue(result));
        CPC.inksEdited = false;
        INK(i, i);
      } 
      System.out.println();
      System.out.println(Util.dumpBytes(this.pluspalette));
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void setPENs() {
    int coloursToSet = 0;
    this.CPCImage = null;
    if (this.mode == 0)
      coloursToSet = 16; 
    if (this.mode == 1)
      coloursToSet = 4; 
    if (this.mode == 2)
      coloursToSet = 2; 
    this.CPCpalette = new int[coloursToSet];
    for (int i = 0; i < coloursToSet; i++) {
      if (green) {
        this.CPCpalette[i] = getCOL(CPC.getGCol(i));
      } else {
        this.CPCpalette[i] = getCOL(CPC.getCol(i));
      } 
    } 
  }
  
  public void refactorImage(boolean build) {
    filled = 0;
    int colours = 0;
    this.CPCImage = null;
    if (this.mode == 0) {
      this.CPCImage = new BufferedImage(160, 200, 1);
      colours = 16;
    } 
    if (this.mode == 1) {
      this.CPCImage = new BufferedImage(320, 200, 1);
      colours = 4;
    } 
    if (this.mode == 2) {
      this.CPCImage = new BufferedImage(640, 200, 1);
      colours = 2;
    } 
    if (blur) {
      Graphics2D g2 = (Graphics2D)this.loadedImage.getGraphics();
      g2.drawImage(this.loadedImage, this.blurOp, 0, 0);
      this.loadedImage.getGraphics().drawImage(this.loadedImage, 0, 0, this);
    } 
    if (sharp) {
      Graphics2D g2 = (Graphics2D)this.loadedImage.getGraphics();
      g2.drawImage(this.loadedImage, this.sharpOp, 0, 0);
      this.loadedImage.getGraphics().drawImage(this.loadedImage, 0, 0, this);
    } 
    this.CPCImage.getGraphics().drawImage(this.loadedImage, 0, 0, this.CPCImage.getWidth(), 200, this);
    if (build)
      buildCPCPalette(this.paletteMethod ? this.loadedImage : this.CPCImage); 
    this.CPCpalette = new int[colours];
    for (int i = 0; i < colours; i++) {
      if (green) {
        this.CPCpalette[i] = getCOL(CPC.getGCol(i));
      } else {
        this.CPCpalette[i] = getCOL(CPC.getCol(i));
      } 
    } 
    this.gfilt.setGain(this.gain[this.gainvalue]);
    this.gfilt.filter(this.CPCImage, this.CPCImage);
    buildCPCScreen(this.CPCImage, this.CPCpalette, true);
  }
  
  public void preRender(BufferedImage CPCImage) {
    try {
      if (ImageProcessor.precalculate != null && isVisible()) {
        this.prerender = (ImageProcessor.precalculate.isSelected() && !plusmode);
      } else {
        this.prerender = RasterPaint.prerender.isSelected();
      } 
      if (RasterPaint.control != null && RasterPaint.control.isVisible() && !isVisible())
        this.prerender = RasterPaint.prerender.isSelected(); 
      if (!this.prerender)
        return; 
      boolean reverseOrder = false;
      if (ImageProcessor.precalculate != null && ImageProcessor.preorder.isSelected())
        reverseOrder = true; 
      if (RasterPaint.control != null && RasterPaint.control.isVisible())
        reverseOrder = RasterPaint.reverse.isSelected(); 
      System.out.println(reverseOrder);
      int width = CPCImage.getWidth();
      int height = CPCImage.getHeight();
      this.rasterToggle = !this.rasterToggle;
      for (int y = 0; y < height; y++) {
        boolean isEven = (y % 2 == 0);
        if (reverseOrder)
          isEven = !isEven; 
        if (this.toggleRaster && this.rasterToggle)
          isEven = !isEven; 
        for (int x = 0; x < width; x++) {
          int pixel = CPCImage.getRGB(x, y);
          isEven = !isEven;
          Color pixelColor = new Color(pixel);
          int red = pixelColor.getRed();
          int green = pixelColor.getGreen();
          int blue = pixelColor.getBlue();
          if (red > 32 && red < 96) {
            red = isEven ? 128 : 0;
          } else if (red >= 96 && red < 160) {
            red = 128;
          } else if (red >= 160 && red < 222) {
            red = isEven ? 255 : 128;
          } else if (red >= 222) {
            red = 255;
          } else {
            red = 0;
          } 
          if (green > 32 && green < 96) {
            green = isEven ? 128 : 0;
          } else if (green >= 96 && green < 160) {
            green = 128;
          } else if (green >= 160 && green < 222) {
            green = isEven ? 255 : 128;
          } else if (green >= 222) {
            green = 255;
          } else {
            green = 0;
          } 
          if (blue > 32 && blue < 96) {
            blue = isEven ? 128 : 0;
          } else if (blue >= 96 && blue < 160) {
            blue = 128;
          } else if (blue >= 160 && blue < 222) {
            blue = isEven ? 255 : 128;
          } else if (blue >= 222) {
            blue = 255;
          } else {
            blue = 0;
          } 
          pixelColor = new Color(red, green, blue);
          CPCImage.setRGB(x, y, pixelColor.getRGB());
        } 
      } 
      if (this.DEBUG_RENDER)
        try {
          BufferedImage testImage = new BufferedImage(640, 400, 1);
          testImage.createGraphics().drawImage(CPCImage, 0, 0, 640, 400, this);
          ImageIO.write(testImage, "PNG", new File("C:/JavaCPC/Rendertest/TestNormal.png"));
        } catch (Exception exception) {} 
    } catch (Exception exception) {}
  }
  
  public void preCalculate(BufferedImage CPCImage, int snap) {
    try {
      int width = CPCImage.getWidth();
      int height = CPCImage.getHeight();
      for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
          int pixel = CPCImage.getRGB(x, y);
          Color pixelColor = new Color(pixel);
          int red = pixelColor.getRed();
          int green = pixelColor.getGreen();
          int blue = pixelColor.getBlue();
          red = red / snap * snap;
          green = green / snap * snap;
          blue = blue / snap * snap;
          pixelColor = new Color(red, green, blue);
          CPCImage.setRGB(x, y, pixelColor.getRGB());
        } 
      } 
      if (this.DEBUG_RENDER)
        try {
          ImageIO.write(CPCImage, "PNG", new File("C:/JavaCPC/Rendertest/TestPrecalculate.png"));
        } catch (Exception exception) {} 
    } catch (Exception exception) {}
  }
  
  public void posterize() {
    filled = 0;
    String filename = this.loadname;
    if (filename != null)
      try {
        int n = JOptionPane.showConfirmDialog(this, "Store double sized?", "Please choose outputformat", 0);
        if (n == 0)
          n = 2; 
        BufferedImage pimage = this.imageImporter.readImage(filename);
        BufferedImage gimage = new BufferedImage(pimage.getWidth() * n, pimage.getHeight() * n, 4);
        gimage.getGraphics().drawImage(pimage, 0, 0, gimage.getWidth(), gimage.getHeight(), this);
        BufferedImage out = null;
        if (this.mode == 0)
          out = new BufferedImage(gimage.getWidth() / 4, gimage.getHeight() / 2, 4); 
        if (this.mode == 1)
          out = new BufferedImage(gimage.getWidth() / 2, gimage.getHeight() / 2, 4); 
        if (this.mode == 2)
          out = new BufferedImage(gimage.getWidth(), gimage.getHeight() / 2, 4); 
        out.getGraphics().drawImage(gimage, 0, 0, out.getWidth(), out.getHeight(), this);
        out = FilterImage2(out, true);
        int colours = 0;
        if (this.mode == 0)
          colours = 16; 
        if (this.mode == 1)
          colours = 4; 
        if (this.mode == 2)
          colours = 2; 
        for (int i = 0; i < colours; i++) {
          if (green) {
            this.CPCpalette[i] = getCOL(CPC.getGCol(i));
          } else {
            this.CPCpalette[i] = getCOL(CPC.getCol(i));
          } 
        } 
        buildCPCScreen(out, this.CPCpalette, true);
        gimage.getGraphics().drawImage(out, 0, 0, gimage.getWidth(), gimage.getHeight(), this);
        FileDialog filedia = new FileDialog(new Frame(), "Save posterized screen", 1);
        filedia.setFile("*.png");
        filedia.setVisible(true);
        filename = null;
        filename = filedia.getFile();
        if (filename != null) {
          filename = filedia.getDirectory() + filedia.getFile();
          if (!filename.toLowerCase().endsWith(".png"))
            filename = filename + ".png"; 
          savescreen(gimage, filename, "png");
        } 
      } catch (Exception e) {
        System.out.println("Load failed...");
        normalPaint.output.append("*** Error *** Import failed.\n");
        return;
      }  
  }
  
  public void buildGreenPalette() {
    if (!green) {
      int i = 0;
      for (; i < 16; i++) {
        this.palette[i] = GateArray.getInk(i);
        INK(i, this.greypal[i]);
      } 
    } else {
      int i = 0;
      for (; i < 16; i++)
        INK(i, this.palette[i]); 
    } 
    green = !green;
  }
  
  public String showname() {
    return this.showname;
  }
  
  public void convertScreen(String loadname) {
    filled = 0;
    this.mode = GateArray.getSMode();
    recalculate = 0;
    MODE = MODE_IMPORT;
    this.scr = false;
    if (loadname.toLowerCase().endsWith(".scr")) {
      SCRimport(loadname);
      return;
    } 
    if (loadname.toLowerCase().endsWith(".drw")) {
      importDoodle("", loadname, true);
      return;
    } 
    if (loadname.toLowerCase().endsWith(".sna")) {
      SNAimport(loadname);
      return;
    } 
    this.cycled = 0;
    this.scrollImage = null;
    this.posterizedImage = null;
    this.sourceImage = null;
    try {
      this.loadedImage = this.imageImporter.readImage(loadname);
    } catch (Exception e) {
      System.out.println("Load failed...");
      normalPaint.output.append("*** Error *** Import failed.\n");
      if (this.makemovie)
        Samples.FINISHED.play(); 
      this.makemovie = false;
      this.mcounter = 0;
      return;
    } 
    if (this.makemovie);
    if (this.loadedImage == null)
      return; 
    this.detected = false;
    int orig_width = this.loadedImage.getWidth();
    int orig_height = this.loadedImage.getHeight();
    int newwidth = 640;
    int newheight = 400;
    float ratio = orig_width / orig_height;
    double scale = orig_width / 640.0D;
    if (ratio > 1.6D)
      scale = orig_height / 400.0D; 
    double width = orig_width / scale;
    double height = orig_height / scale;
    normalPaint.ScrollUpDown.setValue(0);
    normalPaint.ScrollLeftRight.setValue(0);
    newwidth = (int)width;
    newheight = (int)height;
    if (this.keep) {
      newwidth = (int)(orig_width * this.zoomfactor);
      newheight = (int)(orig_height * this.zoomfactor);
    } 
    if (this.stretch) {
      newwidth = 640;
      newheight = 400;
    } 
    normalPaint.output.append("Image size: " + orig_width + "x" + orig_height + ", ratio = " + ratio + "\n");
    normalPaint.output.append("Size viewed: 640x400, ratio = 1.6 Origin : (" + this.scroll + "," + this.scrollb + "\n");
    normalPaint.output.select(2000000000, 2000000000);
    if (this.gray) {
      this.sourceImage = new BufferedImage(newwidth, newheight, 10);
    } else {
      this.sourceImage = new BufferedImage(newwidth, newheight, 1);
    } 
    this.sourceImage.getGraphics().drawImage(this.loadedImage, 0, 0, newwidth, newheight, this);
    this.loadedImage = new BufferedImage(this.sourceImage.getWidth(), this.sourceImage.getHeight(), 2);
    this.loadedImage.getGraphics().drawImage(this.sourceImage, 0, 0, newwidth, newheight, this);
    this.scrollImage = new BufferedImage(this.loadedImage.getWidth(), this.loadedImage.getHeight(), 2);
    this.scrollImage.getGraphics().drawImage(this.loadedImage, 0, 0, this.loadedImage.getWidth(), this.loadedImage.getHeight(), this);
    if (this.makemovie)
      return; 
    recalculate = 1;
    if (this.scrollImage.getHeight() - 400 > 0) {
      int value = this.scrollImage.getHeight() - 400;
      normalPaint.ScrollUpDown.setMaximum(value);
      normalPaint.ScrollUpDown.setEnabled(true);
    } else {
      normalPaint.ScrollUpDown.setMaximum(1);
      normalPaint.ScrollUpDown.setEnabled(false);
    } 
    if (this.scrollImage.getWidth() - 640 > 0) {
      int value = this.scrollImage.getWidth() - 640;
      normalPaint.ScrollLeftRight.setMaximum(value);
      normalPaint.ScrollLeftRight.setEnabled(true);
    } else {
      normalPaint.ScrollLeftRight.setMaximum(1);
      normalPaint.ScrollLeftRight.setEnabled(false);
    } 
    normalPaint.ScrollUpDown.setEnabled(true);
    normalPaint.ScrollLeftRight.setEnabled(true);
    this.posterizedImage = null;
    this.paintscreen = true;
    this.cycled = 1;
    normalPaint.output.append("Reading Ok.\n");
    normalPaint.output.select(2000000000, 2000000000);
    this.doCycle = true;
  }
  
  public void scrollImage() {
    filled = 0;
    if (this.oldscroll != this.scrollb || this.oldscroll2 != this.scroll) {
      recalculate = 1;
      this.detected = false;
      Graphics page = getGraphics();
      page.drawImage(this.scrollImage, 0 - this.scrollb, 0 - this.scroll, 640, 400, 0, 0, 640 + this.scrollb, 400 + this.scroll, this);
    } 
    this.oldscroll = this.scrollb;
    this.oldscroll2 = this.scroll;
  }
  
  public void recalculate() {
    filled = 0;
    this.loadedImage = new BufferedImage(640, 400, 4);
    this.loadedImage.getGraphics().drawImage(this.scrollImage, 0 - this.scrollb, 0 - this.scroll, 640, 400, 0, 0, 640 + this.scrollb, 400 + this.scroll, this);
    this.loadedImage = FilterImage(this.loadedImage);
  }
  
  protected BufferedImage preConvert(BufferedImage in, int type) {
    BufferedImage b = new BufferedImage(in.getWidth(), in.getHeight(), type);
    b.createGraphics().drawImage(in, 0, 0, this);
    in.createGraphics().drawImage(b, 0, 0, this);
    return in;
  }
  
  public static boolean dobump = false;
  
  ContrastFilter ctr;
  
  public boolean[] lockPEN;
  
  int[] colours;
  
  int[] used;
  
  BufferedImage pseudo;
  
  int[] pals;
  
  BufferedImage pali;
  
  protected int autoIndex;
  
  boolean scr;
  
  public boolean detected;
  
  int counter;
  
  int addr;
  
  int addg;
  
  int addb;
  
  int dark;
  
  int medium;
  
  protected BufferedImage FilterImage(BufferedImage in) {
    if (blur) {
      Graphics2D g2 = (Graphics2D)in.getGraphics();
      g2.drawImage(in, this.blurOp, 0, 0);
      in.getGraphics().drawImage(in, 0, 0, this);
    } 
    if (sharp) {
      Graphics2D g2 = (Graphics2D)in.getGraphics();
      g2.drawImage(in, this.sharpOp, 0, 0);
      in.getGraphics().drawImage(in, 0, 0, this);
    } 
    if (!plusmode && (this.addr != 0 || this.addg != 0 || this.addb != 0))
      ManipulateRGB(in); 
    this.ctr.setContrast(this.gain[this.contrast] + 1.0F);
    this.ctr.setBrightness(this.gain[this.bright] + 1.0F);
    this.ctr.filter(in, in);
    int w = (this.mode == 0) ? 160 : ((this.mode == 1) ? 320 : 640);
    int h = 200;
    BufferedImage out = new BufferedImage(w, h, 1);
    Graphics g = out.createGraphics();
    g.drawImage(in, 0, 0, w, h, this);
    BufferedImage bum = new BufferedImage(320, 200, 1);
    if (this.mode == 0)
      bum = new BufferedImage(160, 200, 1); 
    if (this.mode == 2)
      bum = new BufferedImage(640, 200, 1); 
    bum.createGraphics().drawImage(out, 0, 0, bum.getWidth(), 200, this);
    this.contrastfilter.setContrast(this.gain[this.contrast] + 1.0F);
    this.contrastfilter.setBrightness(this.gain[this.bright] + 1.0F);
    this.contrastfilter.filter(bum, bum);
    this.gfilt.setGain(this.gain[this.gainvalue]);
    this.gfilt.filter(bum, bum);
    this.hsb.setSFactor(this.gain[this.sat]);
    this.hsb.setHFactor(this.gain[this.hue]);
    this.hsb.filter(bum, bum);
    out.createGraphics().drawImage(bum, 0, 0, out.getWidth(), 200, this);
    g = in.createGraphics();
    g.drawImage(out, 0, 0, 640, 400, this);
    return in;
  }
  
  protected BufferedImage FilterImage2(BufferedImage in, boolean poster) {
    if (blur) {
      Graphics2D g2 = (Graphics2D)in.getGraphics();
      g2.drawImage(in, this.blurOp, 0, 0);
      in.getGraphics().drawImage(in, 0, 0, this);
    } 
    if (sharp) {
      Graphics2D g2 = (Graphics2D)in.getGraphics();
      g2.drawImage(in, this.sharpOp, 0, 0);
      in.getGraphics().drawImage(in, 0, 0, this);
    } 
    if (!plusmode && (this.addr != 0 || this.addg != 0 || this.addb != 0))
      ManipulateRGB(in); 
    this.ctr.setContrast(this.gain[this.contrast] + 1.0F);
    this.ctr.setBrightness(this.gain[this.bright] + 1.0F);
    this.ctr.filter(in, in);
    this.gfilt.setGain(this.gain[this.gainvalue]);
    this.gfilt.filter(in, in);
    this.hsb.setSFactor(this.gain[this.sat]);
    this.hsb.setHFactor(this.gain[this.hue]);
    this.hsb.filter(in, in);
    return in;
  }
  
  public static void setPlusInk(int i, int value) {
    CPC.Palcols[i & 0xF] = new Color(value);
    GateArrayColors[i & 0xF] = value;
    GateArray.setPalette(i & 0xF, value);
    CPC.inksEdited = false;
    INK(i & 0xF, i & 0xF);
  }
  
  protected int[] getRGB(int value) {
    int[] rgb = new int[3];
    rgb[0] = value >> 16 & 0xFF;
    rgb[1] = value >> 8 & 0xFF;
    rgb[2] = value & 0xFF;
    return rgb;
  }
  
  public void setPlusINK(int value) {
    setPlusINK(this.pen, value);
  }
  
  public void setPlusINK(int pen, int value) {
    CPC.Palcols[pen] = new Color(value);
    GateArrayColors[pen] = value;
    GateArray.setPalette(pen, value);
    CPC.inksEdited = false;
  }
  
  public void setINK(int value) {
    setINK(this.pen, value);
  }
  
  public void setINK(int pen, int value) {
    Color col = new Color(value);
    findCPCInk(col);
    for (int i = 0; i < CPC.Palcols.length; i++) {
      int R, G, B, r = CPC.Palcols[i].getRed();
      int g = CPC.Palcols[i].getGreen();
      int b = CPC.Palcols[i].getBlue();
      if (!green) {
        R = RGBtoCPC(col.getRed(), false);
        G = RGBtoCPC(col.getGreen(), false);
        B = RGBtoCPC(col.getBlue(), false);
      } else {
        r = CPC.Greencols[i].getRed();
        g = CPC.Greencols[i].getGreen();
        b = CPC.Greencols[i].getBlue();
        R = col.getRed();
        G = col.getGreen();
        B = col.getBlue();
        int d = R + G + B;
        d /= 3;
        R = d;
        G = d;
        B = d;
      } 
      if (r >= R - 10 && r <= R + 10 && g >= G - 10 && g <= G + 10 && b >= B - 10 && b <= B + 10) {
        INK(pen, i);
        break;
      } 
    } 
  }
  
  protected void prepareInput(BufferedImage input) {
    if (ditherval < 181 && !plusmode)
      this.pseudo.getGraphics().drawImage(input, 0, 0, 640, 400, this); 
    int width = input.getWidth();
    int height = input.getHeight();
    int xstep = 1;
    if (this.mode == 1)
      xstep = 2; 
    if (this.mode == 0)
      xstep = 4; 
    Graphics d = this.showImage.createGraphics();
    d.setColor(Color.black);
    d.fillRect(0, 0, 384, 272);
    d.drawImage(input, 32, 36, 320, 200, this);
    if (ditherval < 181 && !plusmode)
      input.getGraphics().drawImage(this.pseudo, 0, 0, 640, 400, this); 
  }
  
  protected void buildCPCPalette(BufferedImage input) {
    Graphics v = input.getGraphics();
    int tolerance = ImageProcessor.tolerance.getValue() / 10 + 1;
    this.mode = GateArray.getSMode();
    normalPaint.output.append("Process pass 1...\n");
    if (input == null)
      return; 
    int width = input.getWidth();
    int height = input.getHeight();
    int xstep = 1;
    if (width > 640)
      width = 640; 
    if (height > 400)
      height = 400; 
    if (this.mode == 1)
      xstep = 2; 
    if (this.mode == 0)
      xstep = 4; 
    int keeppen = this.pen;
    this.palcount = new int[27];
    if (plusmode) {
      int div;
      for (int k = 0; k < 4096; k++)
        this.used[k] = 0; 
      if (this.addr != 0 || this.addg != 0 || this.addb != 0)
        ManipulateRGB(input); 
      int offset = 0;
      int having = 0;
      int toldiv = ImageProcessor.divider.getValue() / 5 + 1;
      int tol = 0;
      boolean put = false;
      normalPaint.output.append("Tolerance is " + tolerance + "\n");
      int n;
      for (n = 0; n < width; n += tolerance * xstep) {
        int ydot;
        for (ydot = 0; ydot < height; ydot += tolerance * 2) {
          if (!ImageProcessor.method.isSelected() && !ImageProcessor.method1.isSelected()) {
            tol++;
            if (tol >= toldiv) {
              tol = 0;
              put = true;
            } 
          } else {
            put = true;
          } 
          if (put) {
            int col = input.getRGB(n, ydot);
            int[] rgb = getRGB(col);
            int r = GateArray.LUM(rgb[0] >> 4);
            int i6 = GateArray.LUM(rgb[1] >> 4);
            int b = GateArray.LUM(rgb[2] >> 4);
            int value = GateArray.putRGB(r, i6, b);
            for (int i7 = 0; i7 < 4096; i7++) {
              if (i7 != 6000 && this.colours[i7] == value) {
                this.used[i7] = this.used[i7] + 1;
                i7 = 6000;
              } 
            } 
          } 
          put = false;
        } 
      } 
      for (int m = 0; m < 4096; m++) {
        if (this.used[m] != 0)
          having++; 
      } 
      normalPaint.output.append("Colours found: " + having + "\n");
      int d = 16;
      if (this.mode == 1)
        d = 4; 
      if (having >= d) {
        div = having / d;
      } else {
        div = having;
      } 
      int divider = ImageProcessor.divider.getValue() / 10 + 1;
      int[] pal = new int[16];
      int[] havingcol = new int[4096];
      int[] haveused = new int[4096];
      int hoffset = 0;
      int pos = 0;
      int[] colli = new int[having];
      for (int i1 = 0; i1 < 4096; i1++) {
        if (this.used[i1] != 0) {
          pos++;
          haveused[hoffset] = this.used[i1];
          colli[hoffset++] = this.colours[i1];
        } 
      } 
      int hoff = 0;
      int yoff = 0;
      String[] foof = new String[having];
      int i2;
      for (i2 = 0; i2 < having; i2++)
        foof[i2] = "" + Util.hex(colli[i2]); 
      Collections.sort(Arrays.asList((Comparable[])foof));
      for (i2 = 0; i2 < having; i2++) {
        try {
          colli[i2] = Util.hexValue(foof[i2]);
        } catch (Exception r) {
          break;
        } 
      } 
      this.pali = new BufferedImage(having * 16, 16, 1);
      System.arraycopy(colli, 0, havingcol, 0, colli.length);
      Graphics g = this.pali.createGraphics();
      g.setColor(Color.BLACK);
      g.fillRect(0, 0, having * 16, 16);
      for (int i3 = 0; i3 < having; i3++) {
        g.setColor(new Color(colli[i3]));
        g.fillRect(hoff, yoff, 16, 16);
        hoff += 16;
      } 
      QuantizeFilter cop = new QuantizeFilter();
      cop.setDither(false);
      cop.setSerpentine(false);
      cop.setNumColors(16);
      cop.filter(this.pali, this.pali);
      int[] ppal = new int[16];
      for (int i4 = 0; i4 < 16; i4++)
        ppal[i4] = -1; 
      int vpos = 0;
      int i5;
      for (i5 = 0; i5 < having; i5++) {
        int value = this.pali.getRGB(i5 * 16, 8);
        put = true;
        for (int gg = 0; gg < 16; gg++) {
          if (ppal[gg] == value) {
            put = false;
            break;
          } 
        } 
        if (put)
          ppal[vpos++] = value; 
      } 
      offset = 0;
      if (ImageProcessor.method1.isSelected()) {
        int dd = having / divider / 16;
        dd++;
        for (int i6 = 0; i6 < 16; i6++) {
          pal[i6] = havingcol[offset];
          try {
            offset += pos / 2 / pos / 2 / dd * divider;
          } catch (Exception e) {
            break;
          } 
        } 
        int[] buff = new int[16];
        System.arraycopy(pal, 0, buff, 0, 16);
        for (int i7 = 0; i7 < 16; i7++)
          pal[i7] = buff[this.pals[i7]]; 
      } else if (!ImageProcessor.method.isSelected()) {
        System.arraycopy(ppal, 0, pal, 0, 16);
        int[] buff = new int[16];
        System.arraycopy(pal, 0, buff, 0, 16);
        for (int i6 = 0; i6 < 16; i6++)
          pal[i6] = buff[this.pals[i6]]; 
      } else {
        for (i5 = 0; i5 < having; i5 += div / divider) {
          if (haveused[i5] != -1) {
            try {
              pal[offset] = havingcol[i5];
              offset++;
            } catch (Exception exception) {}
            if (offset == 16)
              break; 
          } 
        } 
      } 
      if (ImageProcessor.ordered != null && ImageProcessor.ordered.isSelected())
        Arrays.sort(pal); 
      for (i5 = 0; i5 < 16; i5++) {
        if (!this.lockPEN[i5])
          setPlusINK(i5 & 0xF, pal[i5 & 0xF]); 
        INK(i5 & 0xF, i5 & 0xF);
      } 
      return;
    } 
    int xdot;
    for (xdot = 0; xdot < width; xdot += xstep) {
      for (int ydot = 0; ydot < height; ydot += 2) {
        Color test = new Color(input.getRGB(xdot, ydot));
        findCPCInk(test);
        Color peng = new Color(this.CPCRed, this.CPCGreen, this.CPCBlue);
        for (int k = 0; k < 27; k++) {
          if (getCOL(this.Col[k]) == getCOL(peng))
            this.palcount[k] = this.palcount[k] + 1; 
        } 
      } 
    } 
    this.count = 0;
    int[] check = new int[27];
    int number = 0;
    for (int p = 0; p < 27; p++) {
      if (this.palcount[p] != 0)
        number++; 
      check[p] = this.palcount[p];
    } 
    normalPaint.output.append(number + " INKs found.\n");
    Arrays.sort(check);
    int[] recheck = new int[27];
    int collect = 16;
    this.outcount = new int[collect];
    int i;
    for (i = 0; i < 27; i++)
      recheck[i] = check[26 - i]; 
    check = recheck;
    for (i = 0; i < 27; i++) {
      for (int q = 0; q < 27; q++) {
        if (this.palcount[q] == check[i])
          this.outcount[this.count++] = q; 
        if (this.count == collect)
          break; 
      } 
    } 
    for (i = 0; i < 27; i++)
      this.realInks[i] = -1; 
    for (i = 0; i < 27; i++) {
      for (int q = 0; q < 27; q++) {
        if (this.palcount[q] == check[i])
          this.realInks[i] = q; 
      } 
    } 
    if (ImageProcessor.ordered != null && ImageProcessor.ordered.isSelected() && !plusmode)
      Arrays.sort(this.outcount); 
    this.counted = new int[collect];
    for (int pf = 0; pf < 16; pf++) {
      if (!this.lockPEN[pf])
        INK(pf, 0); 
    } 
    String outtext = "Palette: ";
    int max = (this.mode == 0) ? 16 : ((this.mode == 1) ? 4 : 2);
    int j;
    for (j = 0; j < collect; j++) {
      if (!this.lockPEN[j])
        INK(j, this.outcount[j]); 
      if (j < max)
        outtext = outtext + this.outcount[j]; 
      this.counted[j] = this.outcount[j];
      if (j < collect - 1 && j < max - 1)
        outtext = outtext + ","; 
    } 
    normalPaint.output.append("Process pass 2...\n");
    outtext = outtext + "\n";
    for (j = 0; j < max; j++) {
      outtext = outtext + this.cpccolors[this.outcount[j]];
      if (j < max - 1)
        outtext = outtext + ","; 
    } 
    normalPaint.output.append(outtext + "\n");
    normalPaint.output.select(2000000000, 2000000000);
    this.pen = keeppen;
  }
  
  public void checkLoadImg() {
    int checksum = 0;
    for (int xdot = 0; xdot < this.loadedImage.getWidth(); xdot += 10) {
      for (int ydot = 0; ydot < this.loadedImage.getHeight(); ydot += 10) {
        Color test = new Color(this.loadedImage.getRGB(xdot, ydot));
        checksum += getCOL(test);
      } 
    } 
    if (checksum == 0)
      convertScreen(this.loadname); 
  }
  
  public void checkImage() {
    int checksum = 0;
    int xdot = 0;
    for (; xdot < this.scrollImage.getWidth(); xdot += 10) {
      int ydot = 0;
      for (; ydot < this.scrollImage.getHeight(); ydot += 10) {
        Color test = new Color(this.scrollImage.getRGB(xdot, ydot));
        checksum += getCOL(test);
      } 
    } 
    if (checksum == 0)
      convertScreen(this.loadname); 
  }
  
  public void savescreen(BufferedImage ima, String filename, String filetype) {
    try {
      File file = new File(filename);
      ImageIO.write(ima, filetype, file);
    } catch (Exception exception) {}
  }
  
  public void Autostore() {
    try {
      String append = "";
      if (this.autoIndex < 100)
        append = append + "0"; 
      if (this.autoIndex < 10)
        append = append + "0"; 
      append = append + "" + this.autoIndex++;
      File file = new File("store_" + append + ".bmp");
      ImageIO.write(this.outimage, "bmp", file);
    } catch (Exception exception) {}
  }
  
  public void convert(boolean detect) {
    if (this.scr)
      return; 
    this.scr = false;
    if (this.keepinks)
      detect = false; 
    if (ImageProcessor.method2.getValue() != 0)
      preCalculate(this.loadedImage, ImageProcessor.method2.getValue()); 
    Graphics d = this.showImage.createGraphics();
    d.setColor(Color.black);
    d.fillRect(0, 0, 384, 272);
    d.drawImage(this.loadedImage, 32, 36, 320, 200, this);
    boolean detectIt = (detect && !this.detected);
    if (detectIt)
      System.out.println("Calculating palette..."); 
    refactorImage(detectIt);
    if (detectIt) {
      recalculate = 1;
      this.detected = true;
      return;
    } 
    if (this.CPCImage == null)
      return; 
    int width = this.CPCImage.getWidth();
    for (int y = 0; y < 200; y++) {
      for (int x = 0; x < width; x++) {
        Color test = new Color(this.CPCImage.getRGB(x, y));
        findCPCInk(test);
        Color peng = new Color(this.CPCRed, this.CPCGreen, this.CPCBlue);
        for (int p = 0; p < 16; p++) {
          if (getCOL(getColor(p)) == getCOL(peng)) {
            plot(x, y, p & 0xF);
            break;
          } 
        } 
      } 
    } 
  }
  
  public void ManipulateRGB(BufferedImage in) {
    for (int x = 0; x < in.getWidth(); x++) {
      for (int y = 0; y < in.getHeight(); y++) {
        Graphics g = in.getGraphics();
        g.setColor(ManipulateRGB(new Color(in.getRGB(x, y)), this.addr, this.addg, this.addb));
        g.fillRect(x, y, 1, 1);
      } 
    } 
  }
  
  public Color ManipulateRGB(Color SourceColor, int addR, int addG, int addB) {
    int r = SourceColor.getRed();
    int g = SourceColor.getGreen();
    int b = SourceColor.getBlue();
    r += addR;
    g += addG;
    b += addB;
    if (r < 0)
      r = 0; 
    if (r > 255)
      r = 255; 
    if (g < 0)
      g = 0; 
    if (g > 255)
      g = 255; 
    if (b < 0)
      b = 0; 
    if (b > 255)
      b = 255; 
    return new Color(r, g, b);
  }
  
  static boolean plusmode = false;
  
  protected boolean processing;
  
  int cols;
  
  int reset;
  
  int cycles;
  
  public int RGBtoCPC(int src, boolean plus) {
    if (!plus)
      return (src < this.dark) ? 0 : ((src < this.medium) ? 125 : 255); 
    return src;
  }
  
  public void findCPCInk(Color test) {
    this.RedPixel = test.getRed() & 0xFF;
    this.GreenPixel = test.getGreen() & 0xFF;
    this.BluePixel = test.getBlue() & 0xFF;
    if (!green) {
      this.CPCRed = RGBtoCPC(this.RedPixel, plusmode);
      this.CPCGreen = RGBtoCPC(this.GreenPixel, plusmode);
      this.CPCBlue = RGBtoCPC(this.BluePixel, plusmode);
    } else {
      this.CPCRed = this.RedPixel;
      this.CPCGreen = this.GreenPixel;
      this.CPCBlue = this.BluePixel;
    } 
  }
  
  public int replaceInk(int[] inInk) {
    int outInk = this.realInks[this.pen];
    int cols = 16;
    if (this.mode == 1)
      cols = 4; 
    if (this.mode == 2)
      cols = 2; 
    int c = 0;
    for (; c < inInk.length; c++) {
      int pn = 0;
      for (; pn < cols; pn++) {
        if (this.realInks[pn] == inInk[c]) {
          outInk = inInk[c];
          return outInk;
        } 
      } 
    } 
    return outInk;
  }
  
  public Color getCol(int index) {
    if (green)
      return CPC.Greencols[index]; 
    return CPC.Palcols[index];
  }
  
  public Color getColor(int index) {
    if (green)
      return CPC.Greencols[GateArray.getInk(index)]; 
    return CPC.Palcols[GateArray.getInk(index)];
  }
  
  public void clear() {
    if (this.processing)
      return; 
    Graphics page = getGraphics();
    if (green) {
      setBackground(CPC.getGCol(0));
    } else {
      setBackground(CPC.getCol(0));
    } 
    page.drawRect(0, 0, 640, 400);
    repaint();
    for (int y = 0; y < 16383; y++)
      CPC.POKE(49152 + y, 0); 
  }
  
  public void putScreen() {
    if (this.processing)
      return; 
    if (this.filling)
      return; 
    if (!isDoubleBuffered()) {
      System.out.println("Doublebuffering");
      setDoubleBuffered(true);
    } 
    Graphics page = getGraphics();
    this.sourceImage = new BufferedImage(640, 400, 1);
    if (Display.doublesize) {
      this.sw = 80;
      this.sh = 480;
    } else {
      this.sw = 40;
      this.sh = 240;
    } 
    if (JEMU.large) {
      this.sourceImage.getGraphics().drawImage(Display.image, 0, 0, 640, 400, 64, this.sw, 704, this.sh, this);
    } else {
      this.sourceImage.getGraphics().drawImage(Display.image, 0, 0, 640, 400, 32, this.sw, 352, this.sh, this);
    } 
    if (page != null)
      page.drawImage(this.sourceImage, 0, 0, 640, 400, this); 
    if (this.mode == 0)
      this.outimage = new BufferedImage(160, 200, 1); 
    if (this.mode == 1)
      this.outimage = new BufferedImage(320, 200, 1); 
    if (this.mode == 2)
      this.outimage = new BufferedImage(640, 200, 1); 
    this.outimage.getGraphics().drawImage(this.sourceImage, 0, 0, this.outimage.getWidth(), 200, this);
    Zoom();
  }
  
  public void buildScreen(BufferedImage image) {
    for (int x = 0; x < 640; x++) {
      for (int y = 0; y < 400; y++) {
        Color test = new Color(image.getRGB(x, y));
        Color testb = CPC.getCol(this.pen);
        if (green)
          testb = CPC.getGCol(this.pen); 
        if (getCOL(test) == getCOL(testb)) {
          int cpcX = x;
          int cpcY = y / 2;
          if (this.mode == 0)
            cpcX /= 4; 
          if (this.mode == 1)
            cpcX /= 2; 
          plot(cpcX, cpcY, this.pen);
        } 
      } 
    } 
  }
  
  public void putText() {
    BufferedImage off_Image = new BufferedImage(640, 400, 1);
    Graphics page = off_Image.createGraphics();
    page.setColor(new Color(255, 113, 222));
    page.fillRect(0, 0, 640, 400);
    page.setFont(new Font(this.fontname, 0 + this.italic + this.bold, Integer.parseInt(normalPaint.textsize.getText())));
    if (green) {
      page.setColor(CPC.getGCol(this.pen));
    } else {
      page.setColor(CPC.getCol(this.pen));
    } 
    page.drawString(normalPaint.text.getText(), this.textX, this.textY);
    buildScreen(off_Image);
  }
  
  public void putObject(int number) {
    BufferedImage off_Image = new BufferedImage(640, 400, 1);
    Graphics page = off_Image.createGraphics();
    page.setColor(new Color(255, 113, 222));
    page.fillRect(0, 0, 640, 400);
    if (green) {
      page.setColor(CPC.getGCol(this.pen));
    } else {
      page.setColor(CPC.getCol(this.pen));
    } 
    int xs = 1;
    int ys = 2;
    if (this.mode == 0)
      xs = 4; 
    if (this.mode == 1)
      xs = 2; 
    this.lineX = this.lineX / xs * xs;
    this.lineY = this.lineY / ys * ys;
    int fromx = this.lineX;
    int fromy = this.lineY;
    int tox = this.toX - this.lineX;
    int toy = this.toY - this.lineY;
    if (this.toX < this.lineX) {
      fromx = this.toX;
      tox = this.lineX - this.toX;
    } else {
      fromx = this.lineX;
      tox = this.toX - this.lineX;
    } 
    if (this.toY < this.lineY) {
      fromy = this.toY;
      toy = this.lineY - this.toY;
    } else {
      fromy = this.lineY;
      toy = this.toY - this.lineY;
    } 
    tox = tox / xs * xs;
    toy = toy / ys * ys;
    if (number == 1)
      page.drawLine(this.lineX, this.lineY, this.toX, this.toY); 
    if (number == 2)
      page.drawRect(fromx, fromy, tox, toy); 
    if (number == 3)
      page.drawOval(fromx, fromy, tox, toy); 
    if (number == 4)
      page.fillRect(fromx, fromy, tox + xs, toy + ys); 
    if (number == 5)
      page.fillOval(fromx, fromy, tox + xs, toy + ys); 
    buildScreen(off_Image);
  }
  
  public void copyShape() {
    if (this.shapeW <= 0 || this.shapeH <= 0)
      return; 
    putScreen();
    BufferedImage buffimg = new BufferedImage(640, 400, 1);
    if (JEMU.large) {
      buffimg.getGraphics().drawImage(Display.image, 0, 0, 640, 400, 64, this.sw, 704, this.sh, this);
    } else {
      buffimg.getGraphics().drawImage(Display.image, 0, 0, 640, 400, 32, this.sw, 352, this.sh, this);
    } 
    this.shapeBrush = new BufferedImage(this.shapeW, this.shapeH, 1);
    this.shapeBrush.getGraphics().drawImage(buffimg, 0 - this.shapeX, 0 - this.shapeY, this.shapeW, this.shapeH, 0, 0, this.shapeW + this.shapeX, this.shapeH + this.shapeY, this);
    int checksum = 0;
    int xdot = 0;
    for (; xdot < this.shapeBrush.getWidth(); xdot += 2) {
      int ydot = 0;
      for (; ydot < this.shapeBrush.getHeight(); ydot += 2) {
        Color test = new Color(this.shapeBrush.getRGB(xdot, ydot));
        checksum += getCOL(test);
      } 
    } 
  }
  
  public void showShape(int x, int y) {
    if (this.shapeBrush == null)
      return; 
    putScreen();
    Graphics page = getGraphics();
    page.drawImage(this.shapeBrush, x, y, this);
  }
  
  public void buildShape(int xpos, int ypos) {
    int pf = 0;
    for (; pf < 27; pf++) {
      if (green) {
        this.Col[pf] = new Color(GateArrayGreens[pf]);
      } else {
        this.Col[pf] = new Color(GateArrayColors[pf]);
      } 
    } 
    if (this.shapeBrush == null)
      return; 
    int xs = 4;
    int ys = 2;
    int pns = 16;
    if (this.mode == 1) {
      xs = 2;
      pns = 4;
    } 
    if (this.mode == 2) {
      xs = 1;
      pns = 2;
    } 
    int x = 0;
    for (; x < this.shapeBrush.getWidth(); x += xs) {
      int y = 0;
      for (; y < this.shapeBrush.getHeight(); y += ys) {
        int pn = 0;
        for (; pn < pns; pn++) {
          Color test = new Color(this.shapeBrush.getRGB(x, y));
          Color testb = this.Col[GateArray.getInk(pn)];
          int plusminus = 64;
          if (plusmode)
            plusminus = 2; 
          if ((!green && test.getBlue() >= testb.getBlue() - plusminus && test.getBlue() <= testb.getBlue() + plusminus && test.getGreen() >= testb.getGreen() - plusminus && test.getGreen() <= testb.getGreen() + plusminus && test.getRed() >= testb.getRed() - plusminus && test.getRed() <= testb.getRed() + plusminus) || (green && test.getGreen() >= testb.getGreen() - 4 && test.getGreen() <= testb.getGreen() + 4)) {
            int cpcX = x + xpos;
            int cpcY = (y + ypos) / 2;
            if (this.mode == 0)
              cpcX /= 4; 
            if (this.mode == 1)
              cpcX /= 2; 
            try {
              if (pn != this.transpen)
                plot(cpcX, cpcY, pn); 
            } catch (Exception e) {
              e.printStackTrace();
            } 
          } 
        } 
      } 
    } 
  }
  
  public void mouseReleased(MouseEvent event) {
    System.gc();
    int xs = 1;
    int ys = 2;
    if (this.mode == 0)
      xs = 4; 
    if (this.mode == 1)
      xs = 2; 
    int xc = event.getX() / xs * xs;
    int yc = event.getY() / ys * ys;
    if (MODE == MODE_MINITEXT)
      putText(xc, yc); 
    if (MODE == MODE_TEXT)
      putText(); 
    if (MODE == MODE_LINE)
      putObject(1); 
    if (MODE == MODE_RECTANGLE)
      putObject(2); 
    if (MODE == MODE_CIRCLE)
      putObject(3); 
    if (MODE == MODE_FRECT)
      putObject(4); 
    if (MODE == MODE_FILL) {
      Fill(xc, yc, (BufferedImage)null, (this.commandInt > 0));
      filled = 1;
    } 
    if (MODE == MODE_FCIRCLE)
      putObject(5); 
    if (MODE == MODE_COPY) {
      copyShape();
      MODE = MODE_PASTE;
    } else if (MODE == MODE_PASTE && this.shapeBrush != null) {
      if (xc >= 640 - this.shapeBrush.getWidth())
        xc = 640 - this.shapeBrush.getWidth(); 
      if (yc >= 400 - this.shapeBrush.getHeight())
        yc = 400 - this.shapeBrush.getHeight(); 
      buildShape(xc, yc);
    } 
    putScreen();
  }
  
  public void mouseClicked(MouseEvent event) {}
  
  public void mouseEntered(MouseEvent event) {
    this.paint = true;
    setIcon((Icon)null);
  }
  
  public void mouseExited(MouseEvent event) {
    this.paint = false;
    try {
      setIcon(new ImageIcon(this.sourceImage));
    } catch (Exception exception) {}
  }
  
  public byte[] getPlusPalette() {
    if (!plusmode)
      return new byte[this.pluspalette.length]; 
    makePlusPalette();
    return this.pluspalette;
  }
  
  public boolean getPlus() {
    return plusmode;
  }
  
  public void makePlusPalette() {
    try {
      for (int pen = 0; pen < 16; pen++) {
        int pos = pen * 2;
        int f = GateArrayColors[pen];
        int[] rgb = getRGB(f);
        int r = rgb[0] >> 4;
        int g = rgb[1] >> 4;
        int b = rgb[2] >> 4;
        String R = Integer.toHexString(r);
        String G = Integer.toHexString(g);
        String B = Integer.toHexString(b);
        String result = R + B;
        int bg = Util.hexValue(result);
        this.pluspalette[pos] = (byte)bg;
        result = G;
        bg = Util.hexValue(result);
        this.pluspalette[pos + 1] = (byte)bg;
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void mouseMoved(MouseEvent event) {
    if (recalculate != 0)
      return; 
    this.bufferTimer = 0;
    int xs = 1;
    int ys = 2;
    if (this.mode == 0)
      xs = 4; 
    if (this.mode == 1)
      xs = 2; 
    int xc = event.getX() / xs * xs;
    int yc = event.getY() / ys * ys;
    this.zoomx = event.getX();
    this.zoomy = event.getY();
    filled = 0;
    putScreen();
    Graphics page = getGraphics();
    if (MODE == MODE_MINITEXT) {
      if (green) {
        page.setColor(CPC.getGCol(this.textpen));
      } else {
        page.setColor(CPC.getCol(this.textpen));
      } 
      page.fillRect(xc, yc, this.minisize, 10);
    } 
    if (MODE == MODE_PAINT || MODE == MODE_LINE) {
      if (green) {
        page.setColor(CPC.getGCol(this.pen));
      } else {
        page.setColor(CPC.getCol(this.pen));
      } 
      page.fillRect(xc, yc, xs, ys);
      this.painted = true;
    } 
    if (MODE == MODE_CIRCLE || MODE == MODE_FCIRCLE || MODE == MODE_COPY || MODE == MODE_RECTANGLE || MODE == MODE_FRECT) {
      if (green) {
        page.setColor(CPC.getGCol(this.pen));
      } else {
        page.setColor(CPC.getCol(this.pen));
      } 
      cross(xc, yc);
      page.fillRect(xc, yc, xs, ys);
      this.painted = true;
    } 
    if (MODE == MODE_PASTE && this.shapeBrush != null) {
      if (xc >= 640 - this.shapeBrush.getWidth())
        xc = 640 - this.shapeBrush.getWidth(); 
      if (yc >= 400 - this.shapeBrush.getHeight())
        yc = 400 - this.shapeBrush.getHeight(); 
      showShape(xc, yc);
    } 
    if (MODE == MODE_TEXT) {
      putScreen();
      Point current = event.getPoint();
      this.textX = current.x / xs * xs;
      this.textY = current.y / ys * ys;
      page.setFont(new Font(this.fontname, 0 + this.italic + this.bold, Integer.parseInt(normalPaint.textsize.getText())));
      if (green) {
        page.setColor(CPC.getGCol(this.pen));
      } else {
        page.setColor(CPC.getCol(this.pen));
      } 
      page.drawString(normalPaint.text.getText(), this.textX, this.textY);
    } 
    this.flip = !this.flip;
    if (this.flip) {
      page.setColor(this.crossfade1);
    } else {
      page.setColor(this.crossfade2);
    } 
    page.fillRect(xc, yc + 6, xs, 10);
    page.fillRect(xc, yc - 14, xs, 10);
    page.fillRect(xc + 6, yc, xs + 10, ys);
    page.fillRect(xc - 16, yc, xs + 10, ys);
  }
  
  public void cross(int xc, int yc) {
    Graphics page = getGraphics();
    page.setColor(this.random);
    page.drawLine(0, yc, 640, yc);
    page.drawLine(0, yc + 1, 640, yc + 1);
    page.drawLine(xc, 0, xc, 400);
    if (this.mode == 1 || this.mode == 0)
      page.drawLine(xc + 1, 0, xc + 1, 400); 
    if (this.mode == 0) {
      page.drawLine(xc + 2, 0, xc + 2, 400);
      page.drawLine(xc + 3, 0, xc + 3, 400);
    } 
  }
  
  public static boolean autostore = false;
  
  public static boolean loadmovie;
  
  public static boolean savemovie;
  
  public static boolean recordmovie = false;
  
  public static boolean stop = false;
  
  int waitA;
  
  int waitB;
  
  BufferedImage showImage;
  
  BufferedImage bzm;
  
  int bufferTimer;
  
  int undopos;
  
  protected byte[] undo1;
  
  protected byte[] undo2;
  
  protected byte[] undo3;
  
  protected byte[] undo4;
  
  protected byte[] undo5;
  
  protected byte[] undo6;
  
  protected byte[] undo7;
  
  protected byte[] undo8;
  
  protected byte[] undo9;
  
  protected byte[] undo10;
  
  protected byte[] undo11;
  
  protected byte[] undo12;
  
  protected byte[] undo13;
  
  protected byte[] undo14;
  
  protected byte[] undo15;
  
  protected byte[] undo16;
  
  protected byte[] undo17;
  
  protected byte[] undo18;
  
  protected byte[] undo19;
  
  protected byte[] undo20;
  
  ItemListener restoreListener;
  
  int mask;
  
  protected int[] xx;
  
  protected int[] yy;
  
  protected int z;
  
  protected int xStep;
  
  protected int yStep;
  
  protected Color hf;
  
  protected Color vfl;
  
  protected Color vfr;
  
  protected Color fr;
  
  protected Color fl;
  
  protected int fillX;
  
  protected int fillY;
  
  protected boolean showFill;
  
  protected boolean filling;
  
  public int commandInt;
  
  public void cycle() {
    if (green) {
      Switches.monitormode = 2;
    } else {
      Switches.monitormode = 0;
    } 
    if (++this.bufferTimer > 100) {
      this.bufferTimer = 0;
      putScreen();
    } 
    if (this.showImage != null && normalPaint.noMouse) {
      Graphics g = this.bzm.getGraphics();
      g.setColor(new Color(this.CPCpalette[1]));
      g.fillRect(0, 0, 386, 274);
      g.drawImage(this.showImage, 0, 0, this);
      normalPaint.proc.image.setIcon(new ImageIcon(this.bzm));
    } 
    if (this.maker.smode != GateArray.getSMode()) {
      this.maker.smode = GateArray.getSMode();
      this.maker.mode.setText("MODE " + GateArray.getSMode());
    } 
    if (this.maker.exact.isSelected()) {
      this.waitA = 3;
      this.waitB = 6;
    } else {
      this.waitA = 10;
      this.waitB = 30;
    } 
    if (CPC.playmovie && this.maker.moviepos.getValue() != CPC.moviecount)
      this.maker.moviepos.setValue(CPC.moviecount); 
    if (dragname != null) {
      this.loadname = dragname;
      dragname = null;
      convertScreen(this.loadname);
    } 
    this.maker.watch.repaint();
    this.maker.max.setText("" + (CPC.maxcount + 1));
    this.maker.counter.setText("" + (CPC.moviecount + 1));
    if (this.makemovie) {
      this.processing = true;
    } else {
      this.processing = false;
    } 
    if (stop) {
      stop = false;
      this.makemovie = false;
      ImageProcessor.precalculate.setSelected(this.toggleRaster);
      this.toggleRaster = false;
    } 
    if (recordmovie) {
      if (!CPC.playmovie) {
        moviemake = 0;
        this.makemovie = true;
        CPC.moviecount = 0;
        CPC.maxcount = 0;
        initRecord();
      } 
      recordmovie = false;
    } 
    if (loadmovie) {
      loadmovie = false;
      restoreMovie();
    } 
    if (savemovie) {
      savemovie = false;
      if (CPC.maxcount > 1)
        storeMovie(); 
    } 
    if (this.maker.nextB.isSelected() && CPC.moviecount < CPC.maxcount) {
      CPC.moviecount++;
      update(CPC.moviecount);
    } 
    if (this.maker.prevB.isSelected() && CPC.moviecount > 0) {
      CPC.moviecount--;
      update(CPC.moviecount);
    } 
    if (this.makemovie) {
      moviemake++;
      if (moviemake == this.waitA)
        renderMovie(); 
      if (moviemake == this.waitB) {
        makeMovie();
        moviemake = 0;
      } 
    } 
    if (autostore) {
      Autostore();
      autostore = false;
    } 
    if (!isVisible())
      System.err.println("paint is cycling:" + this.cycles++); 
    this.reset++;
    if (this.reset > 200) {
      this.reset = 0;
      normalPaint.reset();
    } 
    if (this.importname != null) {
      this.importscr++;
      if (this.importscr == 40)
        CPC.POKE(36863, 3); 
      if (this.importscr == 70) {
        convertScreen(this.importname);
        MODE = MODE_IMPORT;
        this.loadname = this.importname;
        this.importname = null;
        this.importscr = 0;
        if (!hasFocus())
          requestFocus(); 
      } 
    } 
    this.random = new Color(Util.random(255), Util.random(255), Util.random(255));
    if (filled > 0) {
      filled++;
      if (filled >= 20) {
        filled = 0;
        putScreen();
        normalPaint.reset();
      } 
    } 
    if (this.checkPal > 0) {
      if (this.checkPal < 50) {
        this.checkPal++;
      } else if (!GateArray.cpc.floppymotor) {
        this.checkPal++;
      } 
      if (this.checkPal == 60) {
        setPal();
        filled = 1;
      } 
      if (this.checkPal == 70)
        this.checkPal = 0; 
    } 
    if (this.doCycle) {
      if (MODE != MODE_IMPORT) {
        normalPaint.ScrollUpDown.setEnabled(false);
        normalPaint.ScrollLeftRight.setEnabled(false);
      } else {
        normalPaint.ScrollUpDown.setEnabled(true);
        normalPaint.ScrollLeftRight.setEnabled(true);
      } 
      if (recalculate > 0) {
        recalculate++;
        if (recalculate == 20) {
          GateArray.cpc.endFlip();
          recalculate();
          convert(true);
        } 
        if (recalculate == 30)
          writeOutput(); 
        if (recalculate == 40) {
          recalculate = 0;
          normalPaint.output.append("Size viewed: 640x400, ratio = 1.6 Origin : (" + this.scroll + "," + this.scrollb + ")\n");
          normalPaint.output.select(2000000000, 2000000000);
          filled = 1;
        } 
      } 
      if (this.cycled > 0) {
        this.cycled++;
        if (this.cycled == 10)
          convert(true); 
        if (this.cycled == 20) {
          filled = 1;
          this.cycled = 0;
        } 
      } 
    } 
    this.mode = GateArray.getSMode();
  }
  
  public void makeUndo() {
    if (this.undopos < 20)
      this.undopos++; 
    switch (this.undopos) {
      case 1:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo1, 0, 16384);
        break;
      case 2:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo2, 0, 16384);
        break;
      case 3:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo3, 0, 16384);
        break;
      case 4:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo4, 0, 16384);
        break;
      case 5:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo5, 0, 16384);
        break;
      case 6:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo6, 0, 16384);
        break;
      case 7:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo7, 0, 16384);
        break;
      case 8:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo8, 0, 16384);
        break;
      case 9:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo9, 0, 16384);
        break;
      case 10:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo10, 0, 16384);
        break;
      case 11:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo11, 0, 16384);
        break;
      case 12:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo12, 0, 16384);
        break;
      case 13:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo13, 0, 16384);
        break;
      case 14:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo14, 0, 16384);
        break;
      case 15:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo15, 0, 16384);
        break;
      case 16:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo16, 0, 16384);
        break;
      case 17:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo17, 0, 16384);
        break;
      case 18:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo18, 0, 16384);
        break;
      case 19:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo19, 0, 16384);
        break;
      case 20:
        System.arraycopy(GateArray.screenmemory, 49152, this.undo20, 0, 16384);
        break;
    } 
  }
  
  public void Undo() {
    if (this.undopos == 0)
      return; 
    switch (this.undopos) {
      case 1:
        System.arraycopy(this.undo1, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 2:
        System.arraycopy(this.undo2, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 3:
        System.arraycopy(this.undo3, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 4:
        System.arraycopy(this.undo4, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 5:
        System.arraycopy(this.undo5, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 6:
        System.arraycopy(this.undo6, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 7:
        System.arraycopy(this.undo7, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 8:
        System.arraycopy(this.undo8, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 9:
        System.arraycopy(this.undo9, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 10:
        System.arraycopy(this.undo10, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 11:
        System.arraycopy(this.undo11, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 12:
        System.arraycopy(this.undo12, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 13:
        System.arraycopy(this.undo13, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 14:
        System.arraycopy(this.undo14, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 15:
        System.arraycopy(this.undo15, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 16:
        System.arraycopy(this.undo16, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 17:
        System.arraycopy(this.undo17, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 18:
        System.arraycopy(this.undo18, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 19:
        System.arraycopy(this.undo19, 0, GateArray.screenmemory, 49152, 16384);
        break;
      case 20:
        System.arraycopy(this.undo20, 0, GateArray.screenmemory, 49152, 16384);
        break;
      default:
        return;
    } 
    this.undopos--;
    if (this.undopos == 0)
      this.undopos = 1; 
    filled = 1;
  }
  
  public static void INK(int pen, int ink) {
    int addressA = 45529;
    int addressB = 45546;
    if (Switches.ROM.equals("CPC6128") || Switches.ROM.equals("CPC664")) {
      addressA = 47060;
      addressB = 47077;
    } 
    CPC.POKE(addressA + 1 + pen, GateArrayINKs[ink]);
    CPC.POKE(addressB + 1 + pen, GateArrayINKs[ink]);
  }
  
  public void DSKLoad() {
    JComboBox<String> filelist = new JComboBox();
    String[] files = normalPaint.files;
    int y;
    for (y = 0; y < files.length; y++)
      files[y] = files[y].substring(0, 12); 
    for (y = 0; y < files.length; y++) {
      if (files[y].endsWith("SCR") || files[y].endsWith("BIN"))
        filelist.addItem(files[y]); 
    } 
    if (filelist.getItemAt(0) == null)
      return; 
    Object[] object = { filelist, this.restorePal };
    int selectedValue = JOptionPane.showOptionDialog(this, object, "Choose file:", 2, 2, null, null, null);
    if (selectedValue != 0)
      return; 
    try {
      String lname = filelist.getSelectedItem().toString();
      byte[] load = lname.getBytes("UTF-8");
      for (int i = 923; i < 935; i++)
        CPC.POKE(36864 + i, load[i - 923]); 
      CPC.POKE(36863, 10);
      if (this.resPal)
        this.checkPal = 1; 
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void setPal() {
    resetCPCColours();
    int ad = 55249;
    plusmode = false;
    if (GateArray.screenmemory[51152] == -13 && GateArray.screenmemory[51153] == 1)
      plusmode = true; 
    ImageProcessor.OVERRIDE = true;
    if (plusmode) {
      ImageProcessor.plus.setSelected(true);
      ImageProcessor.divider.setEnabled(true);
      ImageProcessor.dlabel.setEnabled(true);
    } else {
      ImageProcessor.plus.setSelected(false);
      ImageProcessor.divider.setEnabled(false);
      ImageProcessor.dlabel.setEnabled(false);
    } 
    ImageProcessor.OVERRIDE = false;
    if (plusmode) {
      makePlus(GateArray.screenmemory, 49152);
    } else {
      int checksum = 0;
      int i;
      for (i = 0; i < 16; i++)
        checksum += CPC.PEEK(55249 + i); 
      if (checksum != 0) {
        for (i = 0; i < 16; i++)
          INK(i, CPC.PEEK(55249 + i)); 
        checksum = CPC.PEEK(55248);
        if (checksum == 0)
          checksum = 3; 
        CPC.POKE(36863, checksum);
      } 
    } 
    putScreen();
  }
  
  public void minitext() {
    String[] pena = { 
        "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
        "10", "11", "12", "13", "14", "15" };
    String[] penb = { 
        "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
        "10", "11", "12", "13", "14", "15", "Off" };
    String[] transb = { 
        "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
        "10", "11", "12", "13", "14", "15", "Transparent" };
    JPanel pen1 = new JPanel();
    pen1.setLayout(new FlowLayout(2, 1, 2));
    JPanel pen2 = new JPanel();
    pen2.setLayout(new FlowLayout(2, 1, 2));
    JPanel backg = new JPanel();
    backg.setLayout(new FlowLayout(2, 1, 2));
    JComboBox<String> penA = new JComboBox<>(pena);
    JComboBox<String> penB = new JComboBox<>(penb);
    JComboBox<String> transB = new JComboBox<>(transb);
    penA.setSelectedIndex(this.textpen);
    penB.setSelectedIndex(this.smoothpen);
    transB.setSelectedIndex(this.transback);
    if (this.mode == 2) {
      penB.setEnabled(false);
      penB.setSelectedIndex(16);
    } 
    JLabel penaa = new JLabel("Text-PEN    ");
    JLabel penbb = new JLabel("Smooth-PEN    ");
    JLabel transbb = new JLabel("Background    ");
    backg.add(transbb);
    backg.add(transB);
    pen1.add(penaa);
    pen1.add(penA);
    pen2.add(penbb);
    pen2.add(penB);
    JTextField inputtext = new JTextField();
    inputtext.setText(this.minitext);
    Object[] object = { inputtext, pen1, pen2, backg };
    int selectedValue = JOptionPane.showOptionDialog(this, object, "Enter mini-text:", 2, 2, null, null, null);
    if (selectedValue != 0)
      return; 
    try {
      int pn1 = Integer.parseInt(penA.getSelectedItem().toString());
      String pn2s = penB.getSelectedItem().toString();
      String pn3s = transB.getSelectedItem().toString();
      int pn2 = 0;
      int pn3 = 0;
      if (pn2s.equals("Off")) {
        pn2 = 16;
      } else {
        pn2 = Integer.parseInt(penB.getSelectedItem().toString());
      } 
      if (pn3s.equals("Transparent")) {
        pn3 = 16;
      } else {
        pn3 = Integer.parseInt(transB.getSelectedItem().toString());
      } 
      String enteredText = inputtext.getText();
      createText(pn1, pn2, pn3, enteredText);
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void createText(int pen1, int pen2, int pen3, String text) {
    this.textpen = pen1;
    this.smoothpen = pen2;
    this.transback = pen3;
    this.minitext = text;
    text = text.toUpperCase();
    this.output = new String[text.length()];
    int i = 0;
    for (; i < this.output.length; i++)
      this.output[i] = text.substring(i, i + 1); 
    this.minisize = this.output.length * 5;
    if (this.mode == 1)
      this.minisize *= 2; 
    if (this.mode == 0)
      this.minisize *= 4; 
    MODE = MODE_MINITEXT;
  }
  
  public void putText(int x, int y) {
    y /= 2;
    int width = this.minisize;
    if (this.mode == 1) {
      x /= 2;
      width /= 2;
    } 
    if (this.mode == 0) {
      x /= 4;
      width /= 4;
    } 
    int posx = x;
    int i = 0;
    for (; i < width / 5; i++) {
      int[] letter = this.minifont.sp;
      if (this.output[i].equals("A"))
        letter = this.minifont.A; 
      if (this.output[i].equals("B"))
        letter = this.minifont.B; 
      if (this.output[i].equals("C"))
        letter = this.minifont.C; 
      if (this.output[i].equals("D"))
        letter = this.minifont.D; 
      if (this.output[i].equals("E"))
        letter = this.minifont.E; 
      if (this.output[i].equals("F"))
        letter = this.minifont.F; 
      if (this.output[i].equals("G"))
        letter = this.minifont.G; 
      if (this.output[i].equals("H"))
        letter = this.minifont.H; 
      if (this.output[i].equals("I"))
        letter = this.minifont.I; 
      if (this.output[i].equals("J"))
        letter = this.minifont.J; 
      if (this.output[i].equals("K"))
        letter = this.minifont.K; 
      if (this.output[i].equals("L"))
        letter = this.minifont.L; 
      if (this.output[i].equals("M"))
        letter = this.minifont.M; 
      if (this.output[i].equals("N"))
        letter = this.minifont.N; 
      if (this.output[i].equals("O"))
        letter = this.minifont.O; 
      if (this.output[i].equals("P"))
        letter = this.minifont.P; 
      if (this.output[i].equals("Q"))
        letter = this.minifont.Q; 
      if (this.output[i].equals("R"))
        letter = this.minifont.R; 
      if (this.output[i].equals("S"))
        letter = this.minifont.S; 
      if (this.output[i].equals("T"))
        letter = this.minifont.T; 
      if (this.output[i].equals("U"))
        letter = this.minifont.U; 
      if (this.output[i].equals("V"))
        letter = this.minifont.V; 
      if (this.output[i].equals("W"))
        letter = this.minifont.W; 
      if (this.output[i].equals("X"))
        letter = this.minifont.X; 
      if (this.output[i].equals("Y"))
        letter = this.minifont.Y; 
      if (this.output[i].equals("Z"))
        letter = this.minifont.Z; 
      if (this.output[i].equals("1"))
        letter = this.minifont.n1; 
      if (this.output[i].equals("2"))
        letter = this.minifont.n2; 
      if (this.output[i].equals("3"))
        letter = this.minifont.n3; 
      if (this.output[i].equals("4"))
        letter = this.minifont.n4; 
      if (this.output[i].equals("5"))
        letter = this.minifont.n5; 
      if (this.output[i].equals("6"))
        letter = this.minifont.n6; 
      if (this.output[i].equals("7"))
        letter = this.minifont.n7; 
      if (this.output[i].equals("8"))
        letter = this.minifont.n8; 
      if (this.output[i].equals("9"))
        letter = this.minifont.n9; 
      if (this.output[i].equals("0"))
        letter = this.minifont.n0; 
      if (this.output[i].equals("©"))
        letter = this.minifont.cr; 
      if (this.output[i].equals("@"))
        letter = this.minifont.at; 
      if (this.output[i].equals("-"))
        letter = this.minifont.mn; 
      if (this.output[i].equals("+"))
        letter = this.minifont.pl; 
      if (this.output[i].equals(","))
        letter = this.minifont.km; 
      if (this.output[i].equals(";"))
        letter = this.minifont.sm; 
      if (this.output[i].equals("."))
        letter = this.minifont.pt; 
      if (this.output[i].equals(":"))
        letter = this.minifont.dp; 
      if (this.output[i].equals("/"))
        letter = this.minifont.sl; 
      if (this.output[i].equals("\\"))
        letter = this.minifont.bs; 
      if (this.output[i].equals("\""))
        letter = this.minifont.qt; 
      if (this.output[i].equals("?"))
        letter = this.minifont.qm; 
      if (this.output[i].equals("!"))
        letter = this.minifont.xm; 
      if (this.output[i].equals("$"))
        letter = this.minifont.dl; 
      if (this.output[i].equals("&"))
        letter = this.minifont.nd; 
      if (this.output[i].equals("#"))
        letter = this.minifont.rt; 
      if (this.output[i].equals("*"))
        letter = this.minifont.mp; 
      if (this.output[i].equals("_"))
        letter = this.minifont.us; 
      if (this.output[i].equals("("))
        letter = this.minifont.bo; 
      if (this.output[i].equals(")"))
        letter = this.minifont.bc; 
      if (this.output[i].equals("["))
        letter = this.minifont.co; 
      if (this.output[i].equals("]"))
        letter = this.minifont.cc; 
      if (this.output[i].equals("="))
        letter = this.minifont.eq; 
      if (this.output[i].equals("<"))
        letter = this.minifont.st; 
      if (this.output[i].equals(">"))
        letter = this.minifont.lt; 
      if (this.output[i].equals("%"))
        letter = this.minifont.pc; 
      if (this.output[i].equals("|"))
        letter = this.minifont.rx; 
      if (this.output[i].equals("'"))
        letter = this.minifont.qo; 
      if (this.output[i].equals("{"))
        letter = this.minifont.rc; 
      if (this.output[i].equals("}"))
        letter = this.minifont.ro; 
      int block = 0;
      for (int ypixel = 0; ypixel < 5; ypixel++) {
        for (int xpixel = 0; xpixel < 5; xpixel++) {
          if (letter[block] == 1)
            plot(posx + xpixel, y + ypixel, this.textpen); 
          if (letter[block] == 2 && this.smoothpen < 16)
            plot(posx + xpixel, y + ypixel, this.smoothpen); 
          if (letter[block] == 0 && this.transback < 16)
            plot(posx + xpixel, y + ypixel, this.transback); 
          block++;
        } 
      } 
      posx += 5;
    } 
  }
  
  protected int getCOL(Color input) {
    return input.getRGB() & this.mask;
  }
  
  public void Fill(int x, int y, BufferedImage img, boolean dither) {
    int pp = this.pen;
    if (dither && img == null) {
      int cmd = this.commandInt;
      switch (cmd) {
        case 1:
          this.dither1 = 0;
          this.dither2 = 1;
          break;
        case 2:
          this.dither1 = 0;
          this.dither2 = 2;
          break;
        case 3:
          this.dither1 = 0;
          this.dither2 = 3;
          break;
        case 4:
          this.dither1 = 1;
          this.dither2 = 2;
          break;
        case 5:
          this.dither1 = 1;
          this.dither2 = 3;
          break;
        case 6:
          this.dither1 = 2;
          this.dither2 = 3;
          break;
        case 7:
          this.dither1 = 0;
          this.dither2 = 4;
          break;
        case 8:
          this.dither1 = 0;
          this.dither2 = 5;
          break;
        case 9:
          this.dither1 = 0;
          this.dither2 = 6;
          break;
        case 10:
          this.dither1 = 0;
          this.dither2 = 7;
          break;
        case 11:
          this.dither1 = 0;
          this.dither2 = 8;
          break;
        case 12:
          this.dither1 = 0;
          this.dither2 = 9;
          break;
        case 13:
          this.dither1 = 0;
          this.dither2 = 10;
          break;
        case 14:
          this.dither1 = 0;
          this.dither2 = 11;
          break;
        case 15:
          this.dither1 = 0;
          this.dither2 = 12;
          break;
        case 16:
          this.dither1 = 0;
          this.dither2 = 13;
          break;
        case 17:
          this.dither1 = 0;
          this.dither2 = 14;
          break;
        case 18:
          this.dither1 = 0;
          this.dither2 = 15;
          break;
        case 19:
          this.dither1 = 1;
          this.dither2 = 4;
          break;
        case 20:
          this.dither1 = 1;
          this.dither2 = 5;
          break;
        case 21:
          this.dither1 = 1;
          this.dither2 = 6;
          break;
        case 22:
          this.dither1 = 1;
          this.dither2 = 7;
          break;
        case 23:
          this.dither1 = 1;
          this.dither2 = 8;
          break;
        case 24:
          this.dither1 = 1;
          this.dither2 = 9;
          break;
        case 25:
          this.dither1 = 1;
          this.dither2 = 10;
          break;
        case 26:
          this.dither1 = 1;
          this.dither2 = 11;
          break;
        case 27:
          this.dither1 = 1;
          this.dither2 = 12;
          break;
        case 28:
          this.dither1 = 1;
          this.dither2 = 13;
          break;
        case 29:
          this.dither1 = 1;
          this.dither2 = 14;
          break;
        case 30:
          this.dither1 = 1;
          this.dither2 = 15;
          break;
        case 31:
          this.dither1 = 2;
          this.dither2 = 4;
          break;
        case 32:
          this.dither1 = 2;
          this.dither2 = 5;
          break;
        case 33:
          this.dither1 = 2;
          this.dither2 = 6;
          break;
        case 34:
          this.dither1 = 2;
          this.dither2 = 7;
          break;
        case 35:
          this.dither1 = 2;
          this.dither2 = 8;
          break;
        case 36:
          this.dither1 = 2;
          this.dither2 = 9;
          break;
        case 37:
          this.dither1 = 2;
          this.dither2 = 10;
          break;
        case 38:
          this.dither1 = 2;
          this.dither2 = 11;
          break;
        case 39:
          this.dither1 = 2;
          this.dither2 = 12;
          break;
        case 40:
          this.dither1 = 2;
          this.dither2 = 13;
          break;
        case 41:
          this.dither1 = 2;
          this.dither2 = 14;
          break;
        case 42:
          this.dither1 = 2;
          this.dither2 = 15;
          break;
        case 43:
          this.dither1 = 3;
          this.dither2 = 4;
          break;
        case 44:
          this.dither1 = 3;
          this.dither2 = 5;
          break;
        case 45:
          this.dither1 = 3;
          this.dither2 = 6;
          break;
        case 46:
          this.dither1 = 3;
          this.dither2 = 7;
          break;
        case 47:
          this.dither1 = 3;
          this.dither2 = 8;
          break;
        case 48:
          this.dither1 = 3;
          this.dither2 = 9;
          break;
        case 49:
          this.dither1 = 3;
          this.dither2 = 10;
          break;
        case 50:
          this.dither1 = 3;
          this.dither2 = 11;
          break;
        case 51:
          this.dither1 = 3;
          this.dither2 = 12;
          break;
        case 52:
          this.dither1 = 3;
          this.dither2 = 13;
          break;
        case 53:
          this.dither1 = 3;
          this.dither2 = 14;
          break;
        case 54:
          this.dither1 = 3;
          this.dither2 = 15;
          break;
        case 55:
          this.dither1 = 4;
          this.dither2 = 5;
          break;
        case 56:
          this.dither1 = 4;
          this.dither2 = 6;
          break;
        case 57:
          this.dither1 = 4;
          this.dither2 = 7;
          break;
        case 58:
          this.dither1 = 4;
          this.dither2 = 8;
          break;
        case 59:
          this.dither1 = 4;
          this.dither2 = 9;
          break;
        case 60:
          this.dither1 = 4;
          this.dither2 = 10;
          break;
        case 61:
          this.dither1 = 4;
          this.dither2 = 11;
          break;
        case 62:
          this.dither1 = 4;
          this.dither2 = 12;
          break;
        case 63:
          this.dither1 = 4;
          this.dither2 = 13;
          break;
        case 64:
          this.dither1 = 4;
          this.dither2 = 14;
          break;
        case 65:
          this.dither1 = 4;
          this.dither2 = 15;
          break;
        case 66:
          this.dither1 = 5;
          this.dither2 = 6;
          break;
        case 67:
          this.dither1 = 5;
          this.dither2 = 7;
          break;
        case 68:
          this.dither1 = 5;
          this.dither2 = 8;
          break;
        case 69:
          this.dither1 = 5;
          this.dither2 = 9;
          break;
        case 70:
          this.dither1 = 5;
          this.dither2 = 10;
          break;
        case 71:
          this.dither1 = 5;
          this.dither2 = 11;
          break;
        case 72:
          this.dither1 = 5;
          this.dither2 = 12;
          break;
        case 73:
          this.dither1 = 5;
          this.dither2 = 13;
          break;
        case 74:
          this.dither1 = 5;
          this.dither2 = 14;
          break;
        case 75:
          this.dither1 = 5;
          this.dither2 = 15;
          break;
        case 76:
          this.dither1 = 6;
          this.dither2 = 7;
          break;
        case 77:
          this.dither1 = 6;
          this.dither2 = 8;
          break;
        case 78:
          this.dither1 = 6;
          this.dither2 = 9;
          break;
        case 79:
          this.dither1 = 6;
          this.dither2 = 10;
          break;
        case 80:
          this.dither1 = 6;
          this.dither2 = 11;
          break;
        case 81:
          this.dither1 = 6;
          this.dither2 = 12;
          break;
        case 82:
          this.dither1 = 6;
          this.dither2 = 13;
          break;
        case 83:
          this.dither1 = 6;
          this.dither2 = 14;
          break;
        case 84:
          this.dither1 = 6;
          this.dither2 = 15;
          break;
        case 85:
          this.dither1 = 7;
          this.dither2 = 8;
          break;
        case 86:
          this.dither1 = 7;
          this.dither2 = 9;
          break;
        case 87:
          this.dither1 = 7;
          this.dither2 = 10;
          break;
        case 88:
          this.dither1 = 7;
          this.dither2 = 11;
          break;
        case 89:
          this.dither1 = 7;
          this.dither2 = 12;
          break;
        case 90:
          this.dither1 = 7;
          this.dither2 = 13;
          break;
        case 91:
          this.dither1 = 7;
          this.dither2 = 14;
          break;
        case 92:
          this.dither1 = 7;
          this.dither2 = 15;
          break;
        case 93:
          this.dither1 = 8;
          this.dither2 = 9;
          break;
        case 94:
          this.dither1 = 8;
          this.dither2 = 10;
          break;
        case 95:
          this.dither1 = 8;
          this.dither2 = 11;
          break;
        case 96:
          this.dither1 = 8;
          this.dither2 = 12;
          break;
        case 97:
          this.dither1 = 8;
          this.dither2 = 13;
          break;
        case 98:
          this.dither1 = 8;
          this.dither2 = 14;
          break;
        case 99:
          this.dither1 = 8;
          this.dither2 = 15;
          break;
        case 100:
          this.dither1 = 9;
          this.dither2 = 10;
          break;
        case 101:
          this.dither1 = 9;
          this.dither2 = 11;
          break;
        case 102:
          this.dither1 = 9;
          this.dither2 = 12;
          break;
        case 103:
          this.dither1 = 9;
          this.dither2 = 13;
          break;
        case 104:
          this.dither1 = 9;
          this.dither2 = 14;
          break;
        case 105:
          this.dither1 = 9;
          this.dither2 = 15;
          break;
        case 106:
          this.dither1 = 10;
          this.dither2 = 11;
          break;
        case 107:
          this.dither1 = 10;
          this.dither2 = 12;
          break;
        case 108:
          this.dither1 = 10;
          this.dither2 = 13;
          break;
        case 109:
          this.dither1 = 10;
          this.dither2 = 14;
          break;
        case 110:
          this.dither1 = 10;
          this.dither2 = 15;
          break;
        case 111:
          this.dither1 = 11;
          this.dither2 = 12;
          break;
        case 112:
          this.dither1 = 11;
          this.dither2 = 13;
          break;
        case 113:
          this.dither1 = 11;
          this.dither2 = 14;
          break;
        case 114:
          this.dither1 = 11;
          this.dither2 = 15;
          break;
        case 115:
          this.dither1 = 12;
          this.dither2 = 13;
          break;
        case 116:
          this.dither1 = 12;
          this.dither2 = 14;
          break;
        case 117:
          this.dither1 = 12;
          this.dither2 = 15;
          break;
        case 118:
          this.dither1 = 13;
          this.dither2 = 14;
          break;
        case 119:
          this.dither1 = 13;
          this.dither2 = 15;
          break;
        case 120:
          this.dither1 = 14;
          this.dither2 = 15;
          break;
        default:
          this.dither1 = this.pen;
          this.dither2 = this.pen;
          break;
      } 
      for (int d = 0; d < this.ditherMatrix.length; d++)
        this.ditherMatrix[d] = -1; 
      this.ditherpos = 0;
      if (getCOL(test(x, y, (BufferedImage)null)) == getCOL(CPC.getCol(this.dither1))) {
        int dither3 = this.dither1;
        this.dither1 = this.dither2;
        this.dither2 = dither3;
      } 
      this.pen = this.dither1;
    } 
    filled = 0;
    for (int pf = 0; pf < 800; pf++) {
      this.yy[pf] = -1;
      this.xx[pf] = -1;
    } 
    this.fillX = x;
    this.fillY = y;
    this.xStep = 1;
    this.yStep = 2;
    if (this.mode == 1)
      this.xStep = 2; 
    if (this.mode == 0)
      this.xStep = 4; 
    if (img == null) {
      putScreen();
    } else {
      this.xStep = 1;
      this.yStep = 1;
    } 
    this.z = 0;
    this.hf = test(x, y, img);
    if (green && this.hf == CPC.getGCol(this.pen))
      return; 
    if (!green && getCOL(this.hf) == getCOL(CPC.getCol(this.pen)))
      return; 
    this.filling = true;
    searchUP(img, dither);
    if (dither && img == null)
      ditherPlot(); 
    this.pen = pp;
    putScreen();
  }
  
  void ditherPlot() {
    int ap = 0;
    for (int d = 0; d < this.ditherMatrix.length; d += 2) {
      if (this.ditherMatrix[d] >= 0) {
        int plot, x = this.ditherMatrix[d];
        int y = this.ditherMatrix[d + 1];
        if (x % 2 == 1) {
          ap = 1;
        } else {
          ap = 0;
        } 
        if (y % 2 == 1)
          if (ap == 0) {
            ap = 1;
          } else {
            ap = 0;
          }  
        if (ap == 1) {
          plot = this.dither1;
        } else {
          plot = this.dither2;
        } 
        plot(x, y, plot);
      } 
    } 
  }
  
  public void reCalc() {
    this.z--;
    if (this.z >= 0) {
      if (this.xx[this.z] >= 0)
        this.fillX = this.xx[this.z]; 
      if (this.yy[this.z] >= 0)
        this.fillY = this.yy[this.z]; 
    } 
  }
  
  public void searchUP(BufferedImage img, boolean dither) {
    while (this.z >= 0) {
      Graphics page = (img == null) ? getGraphics() : img.getGraphics();
      if (green) {
        page.setColor(CPC.getGCol(this.pen));
      } else {
        page.setColor(CPC.getCol(this.pen));
      } 
      while (getCOL(test(this.fillX, this.fillY, img)) == getCOL(this.hf) && this.fillY < ((img == null) ? 400 : img.getHeight()))
        this.fillY += this.yStep; 
      this.fillY -= this.yStep;
      this.fl = new Color(200, 100, 45);
      this.fr = this.fl;
      while (this.fillY >= 0 && getCOL(test(this.fillX, this.fillY, img)) == getCOL(this.hf) && this.fillX >= 0 && this.fillX <= ((img == null) ? 640 : img.getWidth()) - this.xStep) {
        this.vfl = this.fl;
        this.fl = test(this.fillX - this.xStep, this.fillY, img);
        if (getCOL(this.vfl) != getCOL(this.hf) && getCOL(this.fl) == getCOL(this.hf))
          try {
            if (this.fillX >= this.xStep) {
              this.xx[this.z] = this.fillX - this.xStep;
              this.yy[this.z] = this.fillY;
              this.z++;
            } else {
              this.xx[this.z] = 0;
              this.yy[this.z] = this.fillY;
              this.z++;
            } 
          } catch (Exception e) {
            e.printStackTrace();
            filled = 1;
            this.filling = false;
            this.z = -1;
            break;
          }  
        this.vfr = this.fr;
        this.fr = test(this.fillX + this.xStep, this.fillY, (img == null) ? this.sourceImage : img);
        if (getCOL(this.vfr) != getCOL(this.hf) && getCOL(this.fr) == getCOL(this.hf))
          try {
            this.xx[this.z] = this.fillX + this.xStep;
            this.yy[this.z] = this.fillY;
            this.z++;
          } catch (Exception e) {
            filled = 1;
            this.filling = false;
            this.z = -1;
            break;
          }  
        if (img == null) {
          int cpcY = this.fillY / ((img == null) ? 2 : 1);
          int cpcX = this.fillX / ((img == null) ? this.xStep : 1);
          if (this.mode == 2)
            cpcX++; 
          plot(cpcX, cpcY, this.pen);
          if (dither) {
            this.ditherMatrix[this.ditherpos++] = cpcX;
            this.ditherMatrix[this.ditherpos++] = cpcY;
          } 
        } 
        if (green) {
          if (img == null) {
            this.sourceImage.getGraphics().setColor(CPC.getGCol(this.pen));
          } else {
            page.setColor(CPC.getGCol(this.pen));
          } 
        } else if (img == null) {
          this.sourceImage.getGraphics().setColor(CPC.getCol(this.pen));
        } else {
          page.setColor(CPC.getCol(this.pen));
        } 
        if (img == null) {
          this.sourceImage.getGraphics().fillRect(this.fillX, this.fillY, this.xStep, this.yStep);
        } else {
          page.fillRect(this.fillX, this.fillY, this.xStep, this.yStep);
          if (dither) {
            this.ditherMatrix[this.ditherpos++] = this.fillX;
            this.ditherMatrix[this.ditherpos++] = this.fillY;
          } 
        } 
        if (this.showFill && img == null)
          page.fillRect(this.fillX, this.fillY, this.xStep, this.yStep); 
        this.fillY -= this.yStep;
      } 
      reCalc();
    } 
    filled = 1;
    this.filling = false;
  }
  
  public Color test(int x, int y, BufferedImage img) {
    if (x < 0)
      x = 0; 
    if (y < 0)
      y = 0; 
    if (img == null)
      img = this.sourceImage; 
    if (x >= img.getWidth())
      x = img.getWidth() - 1; 
    if (y >= img.getHeight())
      y = img.getHeight() - 1; 
    return new Color(img.getRGB(x, y));
  }
  
  protected static final int[] ditherBayer4x4Matrix = new int[] { 
      1, 15, 2, 12, 9, 5, 10, 6, 3, 13, 
      0, 14, 11, 7, 8, 4 };
  
  protected static final int[] ditherBayer8x8Matrix = new int[] { 
      0, 48, 12, 60, 3, 51, 15, 63, 32, 16, 
      44, 28, 35, 19, 47, 31, 8, 56, 4, 52, 
      11, 59, 7, 55, 40, 24, 36, 20, 43, 27, 
      39, 23, 2, 50, 14, 62, 1, 49, 13, 61, 
      34, 18, 46, 30, 33, 17, 45, 29, 10, 58, 
      6, 54, 9, 57, 5, 53, 42, 26, 38, 22, 
      41, 25, 37, 21 };
  
  protected static final int[] ditherMagic4x4Matrix = new int[] { 
      0, 14, 3, 13, 11, 5, 8, 6, 12, 2, 
      15, 1, 7, 9, 4, 10 };
  
  public static final int[] ditherOrdered4x4Matrix = new int[] { 
      0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 
      1, 9, 15, 7, 13, 5 };
  
  public static final int[] ditherLines4x4Matrix = new int[] { 
      0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 
      10, 11, 12, 13, 14, 15 };
  
  public static final int[] dither90Halftone6x6Matrix = new int[] { 
      29, 18, 12, 19, 30, 34, 17, 7, 4, 8, 
      20, 28, 11, 3, 0, 1, 9, 27, 16, 6, 
      2, 5, 13, 26, 25, 15, 10, 14, 21, 31, 
      33, 25, 24, 23, 33, 36 };
  
  public static final int[] ditherOrdered6x6Matrix = new int[] { 
      1, 59, 15, 55, 2, 56, 12, 52, 33, 17, 
      47, 31, 34, 18, 44, 28, 9, 49, 5, 63, 
      10, 50, 6, 60, 41, 25, 37, 21, 42, 26, 
      38, 22, 3, 57, 13, 53, 0, 58, 14, 54, 
      35, 19, 45, 29, 32, 16, 46, 30, 11, 51, 
      7, 61, 8, 48, 4, 62, 43, 27, 39, 23, 
      40, 24, 36, 20 };
  
  public static final int[] ditherOrdered8x8Matrix = new int[] { 
      1, 235, 59, 219, 15, 231, 55, 215, 2, 232, 
      56, 216, 12, 228, 52, 212, 129, 65, 187, 123, 
      143, 79, 183, 119, 130, 66, 184, 120, 140, 76, 
      180, 116, 33, 193, 17, 251, 47, 207, 31, 247, 
      34, 194, 18, 248, 44, 204, 28, 244, 161, 97, 
      145, 81, 175, 111, 159, 95, 162, 98, 146, 82, 
      172, 108, 156, 92, 9, 225, 49, 209, 5, 239, 
      63, 223, 10, 226, 50, 210, 6, 236, 60, 220, 
      137, 73, 177, 113, 133, 69, 191, 127, 138, 74, 
      178, 114, 134, 70, 188, 124, 41, 201, 25, 241, 
      37, 197, 21, 255, 42, 202, 26, 242, 38, 198, 
      22, 252, 169, 105, 153, 89, 165, 101, 149, 85, 
      170, 106, 154, 90, 166, 102, 150, 86, 3, 233, 
      57, 217, 13, 229, 53, 213, 0, 234, 58, 218, 
      14, 230, 54, 214, 131, 67, 185, 121, 141, 77, 
      181, 117, 128, 64, 186, 122, 142, 78, 182, 118, 
      35, 195, 19, 249, 45, 205, 29, 245, 32, 192, 
      16, 250, 46, 206, 30, 246, 163, 99, 147, 83, 
      173, 109, 157, 93, 160, 96, 144, 80, 174, 110, 
      158, 94, 11, 227, 51, 211, 7, 237, 61, 221, 
      8, 224, 48, 208, 4, 238, 62, 222, 139, 75, 
      179, 115, 135, 71, 189, 125, 136, 72, 176, 112, 
      132, 68, 190, 126, 43, 203, 27, 243, 39, 199, 
      23, 253, 40, 200, 24, 240, 36, 196, 20, 254, 
      171, 107, 155, 91, 167, 103, 151, 87, 168, 104, 
      152, 88, 164, 100, 148, 84 };
  
  public static final int[] ditherCluster3Matrix = new int[] { 
      9, 11, 10, 8, 6, 7, 12, 17, 16, 5, 
      0, 1, 13, 14, 15, 4, 3, 2, 8, 6, 
      7, 9, 11, 10, 5, 0, 1, 12, 17, 16, 
      4, 3, 2, 13, 14, 15 };
  
  public static final int[] ditherCluster4Matrix = new int[] { 
      18, 20, 19, 16, 13, 11, 12, 15, 27, 28, 
      29, 22, 4, 3, 2, 9, 26, 31, 30, 21, 
      5, 0, 1, 10, 23, 25, 24, 17, 8, 6, 
      7, 14, 13, 11, 12, 15, 18, 20, 19, 16, 
      4, 3, 2, 9, 27, 28, 29, 22, 5, 0, 
      1, 10, 26, 31, 30, 21, 8, 6, 7, 14, 
      23, 25, 24, 17 };
  
  public static final int[] ditherCluster8Matrix = new int[] { 
      64, 69, 77, 87, 86, 76, 68, 67, 63, 58, 
      50, 40, 41, 51, 59, 60, 70, 94, 100, 109, 
      108, 99, 93, 75, 57, 33, 27, 18, 19, 28, 
      34, 52, 78, 101, 114, 116, 115, 112, 98, 83, 
      49, 26, 13, 11, 12, 15, 29, 44, 88, 110, 
      123, 124, 125, 118, 107, 85, 39, 17, 4, 3, 
      2, 9, 20, 42, 89, 111, 122, 127, 126, 117, 
      106, 84, 38, 16, 5, 0, 1, 10, 21, 43, 
      79, 102, 119, 121, 120, 113, 97, 82, 48, 25, 
      8, 6, 7, 14, 30, 45, 71, 95, 103, 104, 
      105, 96, 92, 74, 56, 32, 24, 23, 22, 31, 
      35, 53, 65, 72, 80, 90, 91, 81, 73, 66, 
      62, 55, 47, 37, 36, 46, 54, 61, 63, 58, 
      50, 40, 41, 51, 59, 60, 64, 69, 77, 87, 
      86, 76, 68, 67, 57, 33, 27, 18, 19, 28, 
      34, 52, 70, 94, 100, 109, 108, 99, 93, 75, 
      49, 26, 13, 11, 12, 15, 29, 44, 78, 101, 
      114, 116, 115, 112, 98, 83, 39, 17, 4, 3, 
      2, 9, 20, 42, 88, 110, 123, 124, 125, 118, 
      107, 85, 38, 16, 5, 0, 1, 10, 21, 43, 
      89, 111, 122, 127, 126, 117, 106, 84, 48, 25, 
      8, 6, 7, 14, 30, 45, 79, 102, 119, 121, 
      120, 113, 97, 82, 56, 32, 24, 23, 22, 31, 
      35, 53, 71, 95, 103, 104, 105, 96, 92, 74, 
      62, 55, 47, 37, 36, 46, 54, 61, 65, 72, 
      80, 90, 91, 81, 73, 66 };
  
  public final int MATRIX_4x4_BAYER = 1;
  
  public final int MATRIX_8x8_BAYER = 2;
  
  public final int MATRIX_4x4_SQUARE = 3;
  
  public final int MATRIX_4x4_ORDERED = 4;
  
  public final int MATRIX_4x4_LINES = 5;
  
  public final int MATRIX_6x6_HALFTONE = 6;
  
  public final int MATRIX_6x6_ORDERED = 7;
  
  public final int MATRIX_8x8_ORDERED = 8;
  
  public final int MATRIX_CLUSTER3 = 9;
  
  public final int MATRIX_CLUSTER4 = 10;
  
  public final int MATRIX_CLUSTER8 = 11;
  
  int[] matrix;
  
  DitherFilter dither;
  
  public int ditherlevel;
  
  public int oldditherlevel;
  
  public int dithermethod;
  
  int[][] monochrome;
  
  boolean useMonochrome;
  
  boolean makeMono;
  
  public void setMatrixMethod(int method) {
    this.matrix = null;
    switch (method) {
      case 1:
        this.matrix = new int[ditherBayer4x4Matrix.length];
        System.arraycopy(ditherBayer4x4Matrix, 0, this.matrix, 0, this.matrix.length);
        break;
      case 2:
        this.matrix = new int[ditherBayer8x8Matrix.length];
        System.arraycopy(ditherBayer8x8Matrix, 0, this.matrix, 0, this.matrix.length);
        break;
      case 3:
        this.matrix = new int[ditherMagic4x4Matrix.length];
        System.arraycopy(ditherMagic4x4Matrix, 0, this.matrix, 0, this.matrix.length);
        break;
      case 4:
        this.matrix = new int[ditherOrdered4x4Matrix.length];
        System.arraycopy(ditherOrdered4x4Matrix, 0, this.matrix, 0, this.matrix.length);
        break;
      case 5:
        this.matrix = new int[ditherLines4x4Matrix.length];
        System.arraycopy(ditherLines4x4Matrix, 0, this.matrix, 0, this.matrix.length);
        break;
      case 6:
        this.matrix = new int[dither90Halftone6x6Matrix.length];
        System.arraycopy(dither90Halftone6x6Matrix, 0, this.matrix, 0, this.matrix.length);
        break;
      case 7:
        this.matrix = new int[ditherOrdered6x6Matrix.length];
        System.arraycopy(ditherOrdered6x6Matrix, 0, this.matrix, 0, this.matrix.length);
        break;
      case 8:
        this.matrix = new int[ditherOrdered8x8Matrix.length];
        System.arraycopy(ditherOrdered8x8Matrix, 0, this.matrix, 0, this.matrix.length);
        break;
      case 9:
        this.matrix = new int[ditherCluster3Matrix.length];
        System.arraycopy(ditherCluster3Matrix, 0, this.matrix, 0, this.matrix.length);
        break;
      case 10:
        this.matrix = new int[ditherCluster4Matrix.length];
        System.arraycopy(ditherCluster4Matrix, 0, this.matrix, 0, this.matrix.length);
        break;
      case 11:
        this.matrix = new int[ditherCluster8Matrix.length];
        System.arraycopy(ditherCluster8Matrix, 0, this.matrix, 0, this.matrix.length);
        break;
    } 
  }
  
  public void buildCPCScreen(BufferedImage image, int[] colorPallet, boolean preRender) {
    this.useMonochrome = false;
    if (ImageProcessor.ordered != null && ImageProcessor.ordered.isSelected() && this.makeMono)
      this.useMonochrome = true; 
    int[] buffer = new int[colorPallet.length];
    if (this.useMonochrome) {
      System.arraycopy(colorPallet, 0, buffer, 0, colorPallet.length);
      System.arraycopy(this.monochrome[this.mode], 0, colorPallet, 0, colorPallet.length);
    } 
    if (dobump)
      this.bump.filter(image, image); 
    if (this.dlevel) {
      this.dither = new DitherFilter();
      this.dither.setLevels(this.ditherlevel);
      this.dither.setColorDither(true);
      setMatrixMethod(this.dithermethod);
      this.dither.setMatrix(this.matrix);
      this.dither.filter(image, image);
    } 
    if (preRender)
      preRender(image); 
    boolean dithering = true;
    if (ditherval > 118)
      dithering = false; 
    int[][] cpComp = new int[colorPallet.length][3];
    for (int k = 0; k < colorPallet.length; k++) {
      cpComp[k][0] = red(colorPallet[k]);
      cpComp[k][1] = green(colorPallet[k]);
      cpComp[k][2] = blue(colorPallet[k]);
    } 
    for (int y = 0; y < image.getHeight(); y++) {
      for (int x = 0; x < image.getWidth(); x++) {
        int pixel = image.getRGB(x, y);
        int pixelR = red(pixel);
        int pixelG = green(pixel);
        int pixelB = blue(pixel);
        int minimumDistance = 195076;
        int ncIndex = -1;
        for (int j = 0; j < colorPallet.length; j++) {
          int rDiff = pixelR - cpComp[j][0];
          int gDiff = pixelG - cpComp[j][1];
          int bDiff = pixelB - cpComp[j][2];
          int distance = (int)((rDiff * rDiff) * 0.299D + (gDiff * gDiff) * 0.587D + (bDiff * bDiff) * 0.114D);
          if (distance < minimumDistance) {
            minimumDistance = distance;
            ncIndex = j;
          } 
        } 
        image.setRGB(x, y, colorPallet[ncIndex]);
        if (dithering)
          for (int i = 0; i < 4; i++) {
            int xCoor = (i == 0) ? (x + 1) : ((i == 1) ? (x - 1) : ((i == 2) ? x : (x + 1)));
            int yCoor = (i == 0) ? y : (y + 1);
            if (xCoor >= 0 && xCoor < image.getWidth() && yCoor < image.getHeight()) {
              double factor = (i == 0) ? (7.0D / ditherval) : ((i == 1) ? (3.0D / ditherval) : ((i == 2) ? (5.0D / ditherval) : (1.0D / ditherval)));
              int p = image.getRGB(xCoor, yCoor);
              int newRed = (int)Math.round(red(p) + factor * (pixelR - cpComp[ncIndex][0]));
              int newGreen = (int)Math.round(green(p) + factor * (pixelG - cpComp[ncIndex][1]));
              int newBlue = (int)Math.round(blue(p) + factor * (pixelB - cpComp[ncIndex][2]));
              if (newRed < 0)
                newRed = 0; 
              if (newRed > 255)
                newRed = 255; 
              if (newGreen < 0)
                newGreen = 0; 
              if (newGreen > 255)
                newGreen = 255; 
              if (newBlue < 0)
                newBlue = 0; 
              if (newBlue > 255)
                newBlue = 255; 
              image.setRGB(xCoor, yCoor, -16777216 + (newRed << 16) + (newGreen << 8) + newBlue);
            } 
          }  
      } 
    } 
    if (this.useMonochrome)
      for (int x = 0; x < image.getWidth(); x++) {
        for (int i = 0; i < image.getHeight(); i++) {
          int colorPixel = image.getRGB(x, i) & 0xFFFFFF;
          for (int j = 0; j < colorPallet.length; j++) {
            if (colorPixel == colorPallet[j])
              image.setRGB(x, i, buffer[j]); 
          } 
        } 
      }  
  }
  
  public static int red(int argb) {
    return argb >> 16 & 0xFF;
  }
  
  public static int green(int argb) {
    return argb >> 8 & 0xFF;
  }
  
  public static int blue(int argb) {
    return argb & 0xFF;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\paint\PaintCanvas.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */