package jemu.ui.paint;

public class RGBColor {
  private int color;
  
  public void setColor(int rgb) {
    this.color = rgb;
  }
  
  public int getRed() {
    return this.color >> 16 & 0xFF;
  }
  
  public int getGreen() {
    return this.color >> 8 & 0xFF;
  }
  
  public int getBlue() {
    return this.color & 0xFF;
  }
  
  public void setRGB(int r, int g, int b) {
    this.color = 0xFF000000 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | b & 0xFF;
  }
  
  public int getRGB() {
    return this.color;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\paint\RGBColor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */