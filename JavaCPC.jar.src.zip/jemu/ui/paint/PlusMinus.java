package jemu.ui.paint;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;

public class PlusMinus extends JPanel {
  public JButton minus;
  
  public JButton plus;
  
  public PlusMinus() {
    initComponents();
  }
  
  private void initComponents() {
    this.plus = new JButton();
    this.minus = new JButton();
    setLayout(new GridBagLayout());
    this.plus.setFont(new Font("Tahoma", 1, 8));
    this.plus.setText("+");
    this.plus.setBorder(BorderFactory.createBevelBorder(0));
    this.plus.setFocusable(false);
    this.plus.setMaximumSize(new Dimension(12, 12));
    this.plus.setMinimumSize(new Dimension(12, 12));
    this.plus.setName("");
    this.plus.setPreferredSize(new Dimension(12, 12));
    add(this.plus, new GridBagConstraints());
    this.minus.setFont(new Font("Tahoma", 1, 8));
    this.minus.setText("-");
    this.minus.setBorder(BorderFactory.createBevelBorder(0));
    this.minus.setFocusable(false);
    this.minus.setMaximumSize(new Dimension(12, 12));
    this.minus.setMinimumSize(new Dimension(12, 12));
    this.minus.setName("");
    this.minus.setPreferredSize(new Dimension(12, 12));
    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridx = 0;
    gridBagConstraints.gridy = 1;
    add(this.minus, gridBagConstraints);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\paint\PlusMinus.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */