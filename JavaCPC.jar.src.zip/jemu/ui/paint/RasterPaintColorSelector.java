package jemu.ui.paint;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.LayoutStyle;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import jemu.system.cpc.GateArray;

public class RasterPaintColorSelector extends JFrame {
  RasterPaint rPaint;
  
  public RasterPaintColorSelector(RasterPaint paint) {
    this.rPaint = paint;
    initComponents();
    this.jButton3.setEnabled(false);
  }
  
  protected static int[] GateArrayINKs = new int[] { 
      20, 4, 21, 28, 24, 29, 12, 5, 13, 22, 
      6, 23, 30, 0, 31, 14, 7, 15, 18, 2, 
      19, 26, 25, 27, 10, 3, 11 };
  
  public JButton jButton1;
  
  public JButton jButton2;
  
  public JButton jButton3;
  
  public JComboBox<String> jComboBox1;
  
  public JComboBox<String> jComboBox2;
  
  public JComboBox<String> jComboBox3;
  
  public JPanel jPanel1;
  
  public JPanel jPanel2;
  
  public JPanel jPanel3;
  
  public void setPen1(int pen) {
    this.jPanel1.setBackground(new Color(GateArray.inkTranslateColor[GateArray.Inks[pen]]));
    this.jComboBox1.setSelectedIndex(pen);
    if (this.rPaint.manualP1[this.rPaint.pen1zone][this.rPaint.pen1line] || this.rPaint.manualP2[this.rPaint.pen2line] || this.rPaint.manualP3[this.rPaint.pen3line]) {
      this.jButton3.setEnabled(true);
    } else {
      this.jButton3.setEnabled(false);
    } 
  }
  
  public void setPen2(int pen) {
    this.jPanel2.setBackground(new Color(GateArray.inkTranslateColor[GateArray.Inks[pen]]));
    this.jComboBox2.setSelectedIndex(pen);
  }
  
  public void setPen3(int pen) {
    this.jPanel3.setBackground(new Color(GateArray.inkTranslateColor[GateArray.Inks[pen]]));
    this.jComboBox3.setSelectedIndex(pen);
  }
  
  private void initComponents() {
    this.jPanel1 = new JPanel();
    this.jPanel2 = new JPanel();
    this.jPanel3 = new JPanel();
    this.jComboBox1 = new JComboBox<>();
    this.jButton1 = new JButton();
    this.jComboBox2 = new JComboBox<>();
    this.jComboBox3 = new JComboBox<>();
    this.jButton2 = new JButton();
    this.jButton3 = new JButton();
    setTitle("Color Chooser");
    setResizable(false);
    this.jPanel1.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel1.setPreferredSize(new Dimension(64, 64));
    GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
    this.jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(jPanel1Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 60, 32767));
    jPanel1Layout.setVerticalGroup(jPanel1Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 60, 32767));
    this.jPanel2.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel2.setPreferredSize(new Dimension(64, 64));
    GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
    this.jPanel2.setLayout(jPanel2Layout);
    jPanel2Layout.setHorizontalGroup(jPanel2Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 60, 32767));
    jPanel2Layout.setVerticalGroup(jPanel2Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 60, 32767));
    this.jPanel3.setBorder(BorderFactory.createEtchedBorder());
    this.jPanel3.setPreferredSize(new Dimension(64, 64));
    GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
    this.jPanel3.setLayout(jPanel3Layout);
    jPanel3Layout.setHorizontalGroup(jPanel3Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 60, 32767));
    jPanel3Layout.setVerticalGroup(jPanel3Layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 60, 32767));
    this.jComboBox1.setModel(new DefaultComboBoxModel<>(new String[] { 
            "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
            "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", 
            "20", "21", "22", "23", "24", "25", "26" }));
    this.jButton1.setText("SET");
    this.jButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            RasterPaintColorSelector.this.jButton1ActionPerformed(evt);
          }
        });
    this.jComboBox2.setModel(new DefaultComboBoxModel<>(new String[] { 
            "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
            "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", 
            "20", "21", "22", "23", "24", "25", "26" }));
    this.jComboBox3.setModel(new DefaultComboBoxModel<>(new String[] { 
            "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
            "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", 
            "20", "21", "22", "23", "24", "25", "26" }));
    this.jButton2.setText("DEL");
    this.jButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            RasterPaintColorSelector.this.jButton2ActionPerformed(evt);
          }
        });
    this.jButton3.setText("REM");
    this.jButton3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            RasterPaintColorSelector.this.jButton3ActionPerformed(evt);
          }
        });
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
            .addComponent(this.jComboBox1, 0, -1, 32767)
            .addComponent(this.jPanel1, -1, -1, 32767)
            .addComponent(this.jButton1, GroupLayout.Alignment.LEADING, -1, -1, 32767))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(this.jPanel2, -1, -1, 32767)
            .addComponent(this.jComboBox2, 0, -1, 32767)
            .addComponent(this.jButton3, -1, -1, 32767))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(this.jPanel3, -1, -1, 32767)
            .addComponent(this.jComboBox3, 0, -1, 32767)
            .addComponent(this.jButton2, -1, -1, 32767))
          .addContainerGap()));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jPanel3, -2, -1, -2)
            .addComponent(this.jPanel2, -2, -1, -2)
            .addComponent(this.jPanel1, -2, -1, -2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jComboBox1, -2, -1, -2)
            .addComponent(this.jComboBox2, -2, -1, -2)
            .addComponent(this.jComboBox3, -2, -1, -2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jButton1)
            .addComponent(this.jButton2)
            .addComponent(this.jButton3))
          .addContainerGap()));
    pack();
  }
  
  private void jButton1ActionPerformed(ActionEvent evt) {
    this.rPaint.manualPen1[this.rPaint.pen1zone][this.rPaint.pen1line] = this.jComboBox1.getSelectedIndex();
    this.rPaint.manualP1[this.rPaint.pen1zone][this.rPaint.pen1line] = true;
    this.rPaint.manualPen2[this.rPaint.pen1line] = this.jComboBox2.getSelectedIndex();
    this.rPaint.manualP2[this.rPaint.pen2line] = true;
    this.rPaint.manualPen3[this.rPaint.pen3line] = this.jComboBox3.getSelectedIndex();
    this.rPaint.manualP3[this.rPaint.pen3line] = true;
    this.rPaint.reImport();
    setPen1(this.rPaint.manualPen1[this.rPaint.pen1zone][this.rPaint.pen1line]);
    setPen2(this.rPaint.manualPen2[this.rPaint.pen2line]);
    setPen3(this.rPaint.manualPen3[this.rPaint.pen3line]);
  }
  
  private void jButton2ActionPerformed(ActionEvent evt) {
    this.rPaint.resetManualInks();
    this.rPaint.reImport();
    setPen1(this.rPaint.manualPen1[this.rPaint.pen1zone][this.rPaint.pen1line]);
    setPen2(this.rPaint.manualPen2[this.rPaint.pen2line]);
    setPen3(this.rPaint.manualPen3[this.rPaint.pen3line]);
  }
  
  private void jButton3ActionPerformed(ActionEvent evt) {
    this.rPaint.manualP1[this.rPaint.pen1zone][this.rPaint.pen1line] = false;
    this.rPaint.manualP2[this.rPaint.pen2line] = false;
    this.rPaint.manualP2[this.rPaint.pen3line] = false;
    this.rPaint.reImport();
    setPen1(this.rPaint.manualPen1[this.rPaint.pen1zone][this.rPaint.pen1line]);
    setPen2(this.rPaint.manualPen2[this.rPaint.pen2line]);
    setPen3(this.rPaint.manualPen3[this.rPaint.pen3line]);
  }
  
  public static void main(String[] args) {
    try {
      for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
          UIManager.setLookAndFeel(info.getClassName());
          break;
        } 
      } 
    } catch (ClassNotFoundException ex) {
      Logger.getLogger(RasterPaintColorSelector.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (InstantiationException ex) {
      Logger.getLogger(RasterPaintColorSelector.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (IllegalAccessException ex) {
      Logger.getLogger(RasterPaintColorSelector.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (UnsupportedLookAndFeelException ex) {
      Logger.getLogger(RasterPaintColorSelector.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new RasterPaintColorSelector(null)).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\paint\RasterPaintColorSelector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */