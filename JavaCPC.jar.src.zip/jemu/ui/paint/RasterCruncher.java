package jemu.ui.paint;

import java.awt.FileDialog;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import javax.swing.JFrame;

public class RasterCruncher {
  int countequal;
  
  int countdiff;
  
  boolean crunchdata;
  
  byte[] packeddata;
  
  FileDialog dialog;
  
  public static void main(String[] args) {
    RasterCruncher c = new RasterCruncher();
    c.unPack();
  }
  
  public void unPack() {
    if (this.dialog == null)
      this.dialog = new FileDialog(new JFrame(), "Open", 0); 
    this.dialog.setVisible(true);
    String file = this.dialog.getFile();
    if (file != null) {
      String path = this.dialog.getDirectory();
      String[] files = (new File(path)).list();
      for (int i = 0; i < files.length; i++) {
        if (files[i].toLowerCase().endsWith(".pkm") || files[i].toLowerCase().endsWith(".pkz"))
          unpack(path, files[i]); 
      } 
    } 
    System.exit(0);
  }
  
  public void unpack(String path, String file) {
    File a = new File(path + file);
    byte[] toUncrunch = new byte[(int)a.length()];
    try {
      BufferedInputStream bin = new BufferedInputStream(new FileInputStream(a));
      bin.read(toUncrunch);
      bin.close();
      byte[] unpacked = new byte[262144000];
      uncrunch(toUncrunch, unpacked);
      int lastoff = unpacked.length;
      for (int i = unpacked.length - 1; i >= 0; i--) {
        int g = unpacked[i] & 0xFF;
        if (g == 0)
          lastoff--; 
        if (g != 0)
          break; 
      } 
      byte[] f = new byte[lastoff];
      System.arraycopy(unpacked, 0, f, 0, f.length);
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File(path + file + ".RAW")));
      bos.write(f);
      bos.close();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public byte[] uncrunch(byte[] packed) {
    int packedpos = 0, unpackedpos = 0, tmppos = 0;
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    for (packedpos = 0; packedpos < packed.length; ) {
      int temp = packed[packedpos++] & 0xFF;
      if (temp > 127) {
        int i = temp;
        for (tmppos = 0; tmppos < i - 128; tmppos++) {
          temp = packed[packedpos++] & 0xFF;
          bos.write(temp);
        } 
        continue;
      } 
      int temp2 = temp;
      temp = packed[packedpos++] & 0xFF;
      for (tmppos = 0; tmppos < temp2; tmppos++)
        bos.write(temp); 
    } 
    return bos.toByteArray();
  }
  
  public byte[] uncrunch(byte[] packed, byte[] unpack) {
    byte[] unpacked = new byte[262144000];
    int packedpos = 0, unpackedpos = 0, tmppos = 0;
    for (packedpos = 0; packedpos < packed.length; ) {
      int temp = packed[packedpos++] & 0xFF;
      if (temp > 127) {
        int j = temp;
        for (tmppos = 0; tmppos < j - 128; tmppos++) {
          temp = packed[packedpos++] & 0xFF;
          unpacked[unpackedpos++] = (byte)temp;
        } 
        continue;
      } 
      int temp2 = temp;
      temp = packed[packedpos++] & 0xFF;
      for (tmppos = 0; tmppos < temp2; tmppos++)
        unpacked[unpackedpos++] = (byte)temp; 
    } 
    int lastoff = unpacked.length;
    for (int i = unpacked.length - 1; i >= 0; i--) {
      int g = unpacked[i] & 0xFF;
      if (g == 0)
        lastoff--; 
      if (g != 0)
        break; 
    } 
    byte[] f = new byte[lastoff];
    System.arraycopy(unpacked, 0, f, 0, f.length);
    return f;
  }
  
  public byte[] crunch(byte[] data) {
    int packedpos = 0, unpackedpos = 0, tempcount = 0, tempunpackedpos = 0, i = 0;
    this.packeddata = new byte[data.length * 2];
    int datalength = data.length - 1;
    unpackedpos = 0;
    packedpos = 0;
    this.countequal = 0;
    this.countdiff = 0;
    this.crunchdata = true;
    while (this.crunchdata) {
      byte temp = data[unpackedpos];
      if (data[unpackedpos] != data[unpackedpos + 1]) {
        tempcount = 0;
        tempunpackedpos = unpackedpos;
        while (tempcount < 126 && data[tempunpackedpos] != data[tempunpackedpos + 1] && tempunpackedpos < datalength - 1) {
          tempcount++;
          tempunpackedpos++;
        } 
        tempunpackedpos++;
        this.packeddata[packedpos] = (byte)(127 + tempcount + 1);
        packedpos++;
        for (i = 0; i < tempcount; i++) {
          this.packeddata[packedpos] = data[unpackedpos];
          packedpos++;
          unpackedpos++;
        } 
        if (tempunpackedpos >= datalength - 1) {
          this.crunchdata = false;
          break;
        } 
        continue;
      } 
      tempcount = 0;
      while (tempcount < 126 && temp == data[unpackedpos + 1] && unpackedpos < datalength - 1) {
        tempcount++;
        unpackedpos++;
      } 
      unpackedpos++;
      this.packeddata[packedpos] = (byte)(tempcount + 1);
      this.packeddata[packedpos + 1] = temp;
      packedpos += 2;
      if (unpackedpos >= datalength - 1) {
        this.crunchdata = false;
        break;
      } 
    } 
    byte[] packed = new byte[packedpos];
    System.arraycopy(this.packeddata, 0, packed, 0, packed.length);
    return packed;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\paint\RasterCruncher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */