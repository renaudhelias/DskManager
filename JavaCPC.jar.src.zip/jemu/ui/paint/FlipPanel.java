package jemu.ui.paint;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.LayoutStyle;

public class FlipPanel extends JPanel {
  public JToggleButton flip;
  
  public JButton getA;
  
  public JButton getB;
  
  public JButton merge;
  
  public JButton putA;
  
  public JButton putB;
  
  public FlipPanel() {
    initComponents();
  }
  
  private void initComponents() {
    this.putA = new JButton();
    this.putB = new JButton();
    this.getA = new JButton();
    this.getB = new JButton();
    this.merge = new JButton();
    this.flip = new JToggleButton();
    this.putA.setText("Put FlipImage A");
    this.putA.setFocusPainted(false);
    this.putA.setFocusable(false);
    this.putB.setText("Put FlipImage B");
    this.putB.setFocusPainted(false);
    this.putB.setFocusable(false);
    this.getA.setText("Get FlipImage A");
    this.getA.setFocusPainted(false);
    this.getA.setFocusable(false);
    this.getB.setText("Get FlipImage B");
    this.getB.setFocusPainted(false);
    this.getB.setFocusable(false);
    this.merge.setText("Merge Images");
    this.merge.setFocusPainted(false);
    this.merge.setFocusable(false);
    this.flip.setText("Do Flip");
    this.flip.setFocusPainted(false);
    this.flip.setFocusable(false);
    GroupLayout layout = new GroupLayout(this);
    setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
            .addComponent(this.merge, GroupLayout.Alignment.LEADING, -1, -1, 32767)
            .addComponent(this.putB, GroupLayout.Alignment.LEADING, -1, -1, 32767)
            .addComponent(this.putA, GroupLayout.Alignment.LEADING, -1, -1, 32767))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
            .addComponent(this.flip, -1, -1, 32767)
            .addComponent(this.getB, -1, -1, 32767)
            .addComponent(this.getA, -1, -1, 32767))
          .addContainerGap(11, 32767)));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.putA)
            .addComponent(this.getA))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.putB)
            .addComponent(this.getB))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.merge)
            .addComponent(this.flip))
          .addContainerGap(-1, 32767)));
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\paint\FlipPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */