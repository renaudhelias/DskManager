package jemu.ui.paint;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.SpinnerListModel;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import jemu.system.cpc.CPC;
import jemu.system.cpc.GateArray;
import jemu.ui.Main;
import jemu.ui.Switches;

public class normalPaint extends JPanel implements MouseMotionListener, MouseWheelListener, ItemListener, MouseListener, ActionListener {
  public JFrame getImageProcessor() {
    return this.manipframe;
  }
  
  public void componentResized(ComponentEvent e) {}
  
  protected String ver = "3.4";
  
  BufferedImage mouseOver = new BufferedImage(384, 272, 1);
  
  public static boolean noMouse = true;
  
  public static String[] files;
  
  JToggleButton keep;
  
  JToggleButton keepinks;
  
  JToggleButton grey;
  
  JToggleButton italic;
  
  JToggleButton bold;
  
  JToggleButton blur;
  
  JToggleButton sharp;
  
  JToggleButton green;
  
  public static JToggleButton zoom;
  
  JToggleButton stretch;
  
  private ArrayList<DropTarget> dropTargetList;
  
  public static JScrollBar ScrollUpDown;
  
  public static JScrollBar ScrollLeftRight;
  
  public static JSlider raster_slider;
  
  public static JSlider bright_slider;
  
  public static JSlider contrast_slider;
  
  public static JSlider redslider;
  
  public static JSlider greenslider;
  
  public static JSlider blueslider;
  
  public static JSlider darkslider;
  
  public static JSlider mediumslider;
  
  public static JCheckBox dither_slider;
  
  public static JComboBox dither_levels;
  
  public static JComboBox dither_method;
  
  public static JComboBox ditherLevel;
  
  public static JCheckBox bumpbox;
  
  JPanel buttons;
  
  JPanel panel;
  
  JPanel other;
  
  JPanel paint;
  
  JPanel paint1;
  
  JPanel options;
  
  JPanel misc;
  
  JPanel textarea;
  
  JPanel sliders;
  
  JPanel rslider;
  
  JPanel gslider;
  
  JPanel bslider;
  
  JPanel dslider;
  
  JPanel brslider;
  
  JPanel daslider;
  
  JPanel meslider;
  
  JPanel gaslider;
  
  JPanel huslider;
  
  JPanel saslider;
  
  JPanel ctslider;
  
  public static ImageProcessor proc;
  
  public static RGBSlider rgbcho;
  
  public static JSlider gainslider;
  
  public static JSlider hueslider;
  
  public static JSlider satslider;
  
  public void mouseMoved(MouseEvent e) {
    if (e.getSource() == proc.image) {
      int x = e.getX();
      int y = e.getY();
      noMouse = false;
      Graphics ds = this.mouseOver.createGraphics();
      ds.drawImage(Paintbox.showImage, 0, 0, null);
      ds.setColor(Color.RED);
      ds.drawRect(x - 2, y - 2, 4, 4);
      proc.image.setIcon(new ImageIcon(this.mouseOver));
      try {
        Color col = new Color(Paintbox.showImage.getRGB(x, y));
        if (PaintCanvas.plusmode) {
          int R = GateArray.LUM(col.getRed() >> 4);
          int G = GateArray.LUM(col.getGreen() >> 4);
          int B = GateArray.LUM(col.getBlue() >> 4);
          col = new Color(R, G, B);
          ImageProcessor.col.setBackground(col);
        } else {
          int R, G, B;
          if (!PaintCanvas.green) {
            R = Paintbox.RGBtoCPC(col.getRed(), false);
            G = Paintbox.RGBtoCPC(col.getGreen(), false);
            B = Paintbox.RGBtoCPC(col.getBlue(), false);
          } else {
            R = col.getRed();
            G = col.getGreen();
            B = col.getBlue();
            int d = R + G + B;
            d /= 3;
            R = d;
            G = d;
            B = d;
          } 
          col = new Color(R, G, B);
          ImageProcessor.col.setBackground(col);
        } 
      } catch (Exception exception) {}
    } 
  }
  
  public void mouseDragged(MouseEvent e) {}
  
  public void mouseWheelMoved(MouseWheelEvent e) {
    int d = e.getUnitsToScroll();
    if (ScrollUpDown.getMaximum() > 0) {
      if (d > 0) {
        int p = ScrollUpDown.getValue();
        int m = ScrollUpDown.getMaximum();
        if (p + d * 2 <= m)
          ScrollUpDown.setValue(p + d * 2); 
      } else if (d < 0) {
        int p = ScrollUpDown.getValue();
        int m = ScrollUpDown.getMinimum();
        if (p + d * 2 >= m)
          ScrollUpDown.setValue(p + d * 2); 
      } 
    } else if (ScrollLeftRight.getMaximum() > 0) {
      if (d > 0) {
        int p = ScrollLeftRight.getValue();
        int m = ScrollLeftRight.getMaximum();
        if (p + d * 2 <= m)
          ScrollLeftRight.setValue(p + d * 2); 
      } else if (d < 0) {
        int p = ScrollLeftRight.getValue();
        int m = ScrollLeftRight.getMinimum();
        if (p + d * 2 >= m)
          ScrollLeftRight.setValue(p + d * 2); 
      } 
    } 
  }
  
  public void itemStateChanged(ItemEvent e) {
    if (e.getSource() == ImageProcessor.ordered)
      PaintCanvas.recalculate = 1; 
    if (!ImageProcessor.OVERRIDE) {
      Paintbox.painted = true;
      reset();
      PaintCanvas.recalculate = 1;
      Paintbox.recalculate();
      Paintbox.detected = false;
      System.out.println("Changed");
      if (ImageProcessor.plus.isSelected()) {
        if (this.green.isEnabled())
          this.green.setEnabled(false); 
        if (this.green.isSelected()) {
          this.green.setSelected(false);
          PaintCanvas.green = false;
          unlockALL();
          Paintbox.keepinks = false;
        } 
      } else if (!this.green.isEnabled()) {
        this.green.setEnabled(true);
      } 
    } 
  }
  
  protected JCheckBox crunch = new JCheckBox("Crunch picture");
  
  final ImageIcon setTop = createIcon("icons/totop.gif");
  
  final ImageIcon isTop = createIcon("icons/istop.gif");
  
  final ImageIcon plotB = createIcon("icons/plot.gif");
  
  final ImageIcon circleB = createIcon("icons/circle.gif");
  
  final ImageIcon fcircleB = createIcon("icons/fcircle.gif");
  
  final ImageIcon rectB = createIcon("icons/rectangle.gif");
  
  final ImageIcon frectB = createIcon("icons/frectangle.gif");
  
  final ImageIcon impB = createIcon("icons/import.gif");
  
  final ImageIcon lineB = createIcon("icons/line.gif");
  
  final ImageIcon saveB = createIcon("icons/save.gif");
  
  final ImageIcon savePB = createIcon("icons/save_pc.gif");
  
  final ImageIcon fillB = createIcon("icons/fill.gif");
  
  final ImageIcon undoB = createIcon("icons/undo.gif");
  
  final ImageIcon textB = createIcon("icons/text.gif");
  
  final ImageIcon pen0B = createIcon("icons/pen0.gif");
  
  final ImageIcon pen1B = createIcon("icons/pen1.gif");
  
  final ImageIcon pen2B = createIcon("icons/pen2.gif");
  
  final ImageIcon pen3B = createIcon("icons/pen3.gif");
  
  final ImageIcon pen4B = createIcon("icons/pen4.gif");
  
  final ImageIcon pen5B = createIcon("icons/pen5.gif");
  
  final ImageIcon pen6B = createIcon("icons/pen6.gif");
  
  final ImageIcon pen7B = createIcon("icons/pen7.gif");
  
  final ImageIcon pen8B = createIcon("icons/pen8.gif");
  
  final ImageIcon pen9B = createIcon("icons/pen9.gif");
  
  final ImageIcon pen10B = createIcon("icons/pen10.gif");
  
  final ImageIcon pen11B = createIcon("icons/pen11.gif");
  
  final ImageIcon pen12B = createIcon("icons/pen12.gif");
  
  final ImageIcon pen13B = createIcon("icons/pen13.gif");
  
  final ImageIcon pen14B = createIcon("icons/pen14.gif");
  
  final ImageIcon pen15B = createIcon("icons/pen15.gif");
  
  final ImageIcon pen0Bd = createIcon("icons/pen0d.gif");
  
  final ImageIcon pen1Bd = createIcon("icons/pen1d.gif");
  
  final ImageIcon pen2Bd = createIcon("icons/pen2d.gif");
  
  final ImageIcon pen3Bd = createIcon("icons/pen3d.gif");
  
  final ImageIcon pen4Bd = createIcon("icons/pen4d.gif");
  
  final ImageIcon pen5Bd = createIcon("icons/pen5d.gif");
  
  final ImageIcon pen6Bd = createIcon("icons/pen6d.gif");
  
  final ImageIcon pen7Bd = createIcon("icons/pen7d.gif");
  
  final ImageIcon pen8Bd = createIcon("icons/pen8d.gif");
  
  final ImageIcon pen9Bd = createIcon("icons/pen9d.gif");
  
  final ImageIcon pen10Bd = createIcon("icons/pen10d.gif");
  
  final ImageIcon pen11Bd = createIcon("icons/pen11d.gif");
  
  final ImageIcon pen12Bd = createIcon("icons/pen12d.gif");
  
  final ImageIcon pen13Bd = createIcon("icons/pen13d.gif");
  
  final ImageIcon pen14Bd = createIcon("icons/pen14d.gif");
  
  final ImageIcon pen15Bd = createIcon("icons/pen15d.gif");
  
  final ImageIcon clearB = createIcon("icons/clear.gif");
  
  final ImageIcon copyB = createIcon("icons/copy.gif");
  
  final ImageIcon pasteB = createIcon("icons/paste.gif");
  
  final ImageIcon posterizeB = createIcon("icons/posterize.gif");
  
  final ImageIcon asbmpB = createIcon("icons/asbmp.gif");
  
  final ImageIcon mode1B = createIcon("icons/mode1.gif");
  
  final ImageIcon mode2B = createIcon("icons/mode2.gif");
  
  final ImageIcon mode0B = createIcon("icons/mode0.gif");
  
  final ImageIcon dskLoad = createIcon("icons/dsk_load.gif");
  
  final ImageIcon miniText = createIcon("icons/minitext.gif");
  
  private int APPLET_WIDTH = 400;
  
  private int APPLET_HEIGHT = 250;
  
  String welcome = "*************************************************\n**              JavaCPC Paint " + this.ver + "+             **\n**              ==================             **\n**                 Normal mode                 **\n**          ©2009-" + Main.year + " by Devilmarkus          **\n*************************************************\n                                                                                                    \n";
  
  private static PaintCanvas Paintbox;
  
  private static JComboBox fontbox;
  
  private static JComboBox changepen;
  
  private static JComboBox transpen;
  
  private static JSpinner zooms;
  
  private static JSpinner storeto;
  
  private static JButton sto;
  
  private static JButton resto;
  
  private static JLabel change;
  
  private static JLabel changei;
  
  private static JLabel entertext;
  
  private static JButton blanklabel;
  
  private static JButton setToTop;
  
  private static JButton blanklabel2;
  
  private static JButton asbmp;
  
  private static JButton posterize;
  
  private static JButton moviemaker;
  
  private static FlipPanel flipp;
  
  private static JLabel translabel;
  
  public static JTextArea output;
  
  static JScrollPane outpane;
  
  private JButton clearButton;
  
  private JButton dskButton;
  
  private JButton miniButton;
  
  private JButton save;
  
  private JButton savepc;
  
  private static Button okpen;
  
  private static JPanel pen0;
  
  private static JPanel pen1;
  
  private static JPanel pen2;
  
  private static JPanel pen3;
  
  private static JPanel pen4;
  
  private static JPanel pen5;
  
  private static JPanel pen6;
  
  private static JPanel pen7;
  
  private static JPanel pen8;
  
  private static JPanel pen9;
  
  private static JPanel pen10;
  
  private static JPanel pen11;
  
  private static JPanel pen12;
  
  private static JPanel pen13;
  
  private static JPanel pen14;
  
  private static JPanel pen15;
  
  private static JLabel pen0l;
  
  private static JLabel pen1l;
  
  private static JLabel pen2l;
  
  private static JLabel pen3l;
  
  private static JLabel pen4l;
  
  private static JLabel pen5l;
  
  private static JLabel pen6l;
  
  private static JLabel pen7l;
  
  private static JLabel pen8l;
  
  private static JLabel pen9l;
  
  private static JLabel pen10l;
  
  private static JLabel pen11l;
  
  private static JLabel pen12l;
  
  private static JLabel pen13l;
  
  private static JLabel pen14l;
  
  private static JLabel pen15l;
  
  private static JButton scrmode;
  
  public static JTextField text;
  
  public static JTextField textsize;
  
  private static JButton addtext;
  
  private static JButton addplot;
  
  private static JButton addline;
  
  private static JButton addrect;
  
  private static JButton addoval;
  
  private static JButton addfrect;
  
  private static JButton addfoval;
  
  private static JButton undo;
  
  private static JButton fill;
  
  private static JButton impscr;
  
  private static JButton copy;
  
  private static JButton paste;
  
  String[] ditherlevels;
  
  public void initialize() {
    setLayout(new FlowLayout(0, 3, 3));
    String[] pens = { 
        "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
        "10", "11", "12", "13", "14", "15" };
    String[] transpens = { 
        "Off", "0", "1", "2", "3", "4", "5", "6", "7", "8", 
        "9", "10", "11", "12", "13", "14", "15" };
    String[] inks = { 
        "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
        "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", 
        "20", "21", "22", "23", "24", "25", "26" };
    blanklabel = new JButton("");
    blanklabel.setBorder((Border)null);
    blanklabel.setFocusable(false);
    setToTop = new JButton(this.setTop);
    setToTop.setBorder((Border)null);
    setToTop.setFocusable(false);
    blanklabel2 = new JButton("");
    blanklabel2.setBorder((Border)null);
    blanklabel2.setFocusable(false);
    translabel = new JLabel("Shape trans.");
    translabel.setFocusable(false);
    this.buttons = new JPanel();
    this.buttons.setLayout(new FlowLayout(1, 1, 2));
    this.buttons.setBorder(new EtchedBorder());
    this.options = new JPanel();
    this.options.setLayout(new FlowLayout(0, 12, 4));
    this.misc = new JPanel();
    this.misc.setLayout(new FlowLayout(0, 12, 4));
    this.options.setBorder(new EtchedBorder());
    this.misc.setBorder(new EtchedBorder());
    this.textarea = new JPanel();
    this.textarea.setLayout(new FlowLayout(1, 12, 4));
    this.textarea.setBorder(new EtchedBorder());
    this.sliders = new JPanel();
    this.sliders.setLayout(new FlowLayout(1, 2, 4));
    this.sliders.setBorder(new EtchedBorder());
    this.rslider = new JPanel();
    this.rslider.setLayout(new BorderLayout());
    this.rslider.setBorder(new EtchedBorder());
    this.gslider = new JPanel();
    this.gslider.setLayout(new BorderLayout());
    this.gslider.setBorder(new EtchedBorder());
    this.bslider = new JPanel();
    this.bslider.setLayout(new BorderLayout());
    this.bslider.setBorder(new EtchedBorder());
    this.dslider = new JPanel();
    this.dslider.setLayout(new BorderLayout());
    this.dslider.setBorder(new EtchedBorder());
    this.brslider = new JPanel();
    this.brslider.setLayout(new BorderLayout());
    this.brslider.setBorder(new EtchedBorder());
    this.ctslider = new JPanel();
    this.ctslider.setLayout(new BorderLayout());
    this.ctslider.setBorder(new EtchedBorder());
    this.meslider = new JPanel();
    this.meslider.setLayout(new BorderLayout());
    this.meslider.setBorder(new EtchedBorder());
    this.daslider = new JPanel();
    this.daslider.setLayout(new BorderLayout());
    this.daslider.setBorder(new EtchedBorder());
    this.gaslider = new JPanel();
    this.gaslider.setLayout(new BorderLayout());
    this.gaslider.setBorder(new EtchedBorder());
    this.huslider = new JPanel();
    this.huslider.setLayout(new BorderLayout());
    this.huslider.setBorder(new EtchedBorder());
    this.saslider = new JPanel();
    this.saslider.setLayout(new BorderLayout());
    this.saslider.setBorder(new EtchedBorder());
    this.panel = new JPanel();
    this.panel.setLayout(new FlowLayout(1, 3, 4));
    this.paint = new JPanel();
    this.paint1 = new JPanel();
    this.paint.setLayout(new FlowLayout(1, 1, 1));
    this.paint1.setLayout(new BorderLayout());
    this.paint.setBorder(new EtchedBorder());
    this.paint1.setBorder((Border)null);
    this.other = new JPanel();
    this.other.setLayout(new GridLayout(23, 1));
    this.panel.setBorder(new EtchedBorder());
    this.other.setBorder(new EtchedBorder());
    entertext = new JLabel("Enter Text here");
    entertext.setFocusable(false);
    Dimension n = new Dimension(30, 20);
    changepen = new JComboBox();
    transpen = new JComboBox();
    SpinnerListModel zm = new SpinnerListModel(new Object[] { 
          "st", "0.125", "0.25", "0.50", "0.75", "1.00", "1.25", "1.50", "1.75", "2.00", 
          "2.25", "2.50", "2.75", "3.00", "3.25", "3.50", "3.75", "4.00", "en" });
    SpinnerListModel stom = new SpinnerListModel(new Object[] { 
          "st", "00", "01", "02", "03", "04", "05", "06", "07", "08", 
          "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", 
          "19", "en" });
    storeto = new JSpinner(stom);
    storeto.setValue("00");
    storeto.setFocusable(false);
    storeto.addChangeListener(this.stolistener);
    sto = new JButton("Store");
    resto = new JButton("Restore");
    sto.setFocusable(false);
    resto.setFocusable(false);
    zooms = new JSpinner(zm);
    zooms.setValue("1.00");
    zooms.setFocusable(false);
    zooms.addChangeListener(this.zoomlistener);
    change = new JLabel("Change PEN");
    changei = new JLabel("    Image storage:");
    change.setFocusable(false);
    changei.setFocusable(false);
    int y;
    for (y = 0; y < pens.length; y++)
      changepen.addItem(pens[y]); 
    for (y = 0; y < transpens.length; y++)
      transpen.addItem(transpens[y]); 
    okpen = new Button("OK");
    this.keep = new JToggleButton("Keep");
    this.keep.addItemListener(this.itemListener);
    this.keep.setFocusable(false);
    this.stretch = new JToggleButton("Stretch");
    this.stretch.addItemListener(this.stretchListener);
    this.stretch.setFocusable(false);
    this.keepinks = new JToggleButton("Lock INKs");
    this.keepinks.addItemListener(this.inkListener);
    this.keepinks.setFocusable(false);
    this.grey = new JToggleButton("B/W");
    this.grey.addItemListener(this.greyListener);
    this.grey.setFocusable(false);
    this.italic = new JToggleButton("<html><b><i>i</i></b></html>");
    this.italic.addItemListener(this.italicListener);
    this.italic.setFocusable(false);
    this.bold = new JToggleButton("<html><b>B</b></html>");
    this.bold.addItemListener(this.boldListener);
    this.bold.setFocusable(false);
    this.blur = new JToggleButton("Soft");
    this.blur.addItemListener(this.blurListener);
    this.blur.setFocusable(false);
    this.sharp = new JToggleButton("Sharp");
    this.sharp.addItemListener(this.sharpListener);
    this.sharp.setFocusable(false);
    this.green = new JToggleButton("Grey");
    this.green.addItemListener(this.greenListener);
    this.green.setFocusable(false);
    zoom = new JToggleButton("Zoom");
    zoom.addItemListener(this.zoomListener);
    zoom.setFocusable(false);
    GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
    String[] fontNames = env.getAvailableFontFamilyNames();
    Paintbox = new PaintCanvas();
    if (PaintCanvas.green) {
      Paintbox.setBackground(CPC.getGCol(0));
    } else {
      Paintbox.setBackground(CPC.getCol(0));
    } 
    Paintbox.loadScreens();
    Paintbox.showname = "JavaCPC Paint " + this.ver + "+";
    this.dropTargetList = new ArrayList<>();
    DropListener myListener = new DropListener();
    registerDropListener(this.dropTargetList, this, myListener);
    text = new JTextField();
    textsize = new JTextField();
    fontbox = new JComboBox();
    output = new JTextArea();
    output.setColumns(60);
    output.setRows(6);
    try {
      InputStream in = getClass().getResourceAsStream("amstrad_cpc464.ttf");
      Font font = Font.createFont(0, in).deriveFont(0, 8.0F);
      output.setFont(font);
      output.setBackground(new Color(0, 0, 128));
      output.setForeground(new Color(255, 255, 0));
      output.setColumns(56);
    } catch (Exception e) {
      output.setFont(new Font("Monospaced", 1, 11));
    } 
    output.setEditable(false);
    outpane = new JScrollPane(output);
    outpane.setAutoscrolls(true);
    output.setAutoscrolls(true);
    output.append(this.welcome);
    this.dskButton = new JButton(this.dskLoad);
    this.dskButton.setBorder((Border)null);
    this.miniButton = new JButton(this.miniText);
    this.miniButton.setBorder((Border)null);
    for (int i = 0; i < fontNames.length; i++)
      fontbox.addItem(fontNames[i]); 
    fontbox.setPreferredSize(new Dimension(150, 20));
    fontbox.setSize(new Dimension(150, 20));
    fontbox.setMaximumSize(new Dimension(150, 20));
    Paintbox.fontname = fontbox.getSelectedItem().toString();
    ScrollUpDown = new JScrollBar();
    ScrollLeftRight = new JScrollBar();
    raster_slider = new JSlider();
    dither_slider = new JCheckBox("Ordered Dithering");
    dither_levels = new JComboBox();
    ditherLevel = new JComboBox();
    ditherLevel.setSize(new Dimension(80, 18));
    ditherLevel.setPreferredSize(new Dimension(80, 18));
    ditherLevel.setMaximumSize(new Dimension(80, 18));
    ditherLevel.setFocusable(false);
    bumpbox = new JCheckBox("Bump mapping");
    dither_method = new JComboBox();
    this.ditherlevels = new String[] { 
        "4x4 Bayer", "8x8 Bayer", "4x4 Square", "4x4 Ordered", "4x4 Lines", "6x6 Halftone", "6x6 Ordered", "8x8 Ordered", "Cluster3", "Cluster4", 
        "Cluster8" };
    dither_method.setModel(new DefaultComboBoxModel<>(this.ditherlevels));
    dither_levels.setModel(new DefaultComboBoxModel<>(new String[] { 
            "2", "4", "6", "8", "10", "12", "14", "16", "18", "20", 
            "22", "24", "26", "28", "30", "32" }));
    dither_levels.setSelectedIndex(9);
    String[] ditherModel = { 
        "MODE 2:", "0 + 1", "MODE 1:", "0 + 2", "0 + 3", "1 + 2", "1 + 3", "2 + 3", "MODE 0:", "0 + 4", 
        "0 + 5", "0 + 6", "0 + 7", "0 + 8", "0 + 9", "0 + 10", "0 + 11", "0 + 12", "0 + 13", "0 + 14", 
        "0 + 15", "1 - 4", "1 - 5", "1 - 6", "1 - 7", "1 - 8", "1 - 9", "1 - 10", "1 - 11", "1 - 12", 
        "1 - 13", "1 - 14", "1 - 15", "2 - 4", "2 - 5", "2 - 6", "2 - 7", "2 - 8", "2 - 9", "2 - 10", 
        "2 - 11", "2 - 12", "2 - 13", "2 - 14", "2 - 15", "3 - 4", "3 - 5", "3 - 6", "3 - 7", "3 - 8", 
        "3 - 9", "3 - 10", "3 - 11", "3 - 12", "3 - 13", "3 - 14", "3 - 15", "4 - 5", "4 - 6", "4 - 7", 
        "4 - 8", "4 - 9", "4 - 10", "4 - 11", "4 - 12", "4 - 13", "4 - 14", "4 - 15", "5 - 6", "5 - 7", 
        "5 - 8", "5 - 9", "5 - 10", "5 - 11", "5 - 12", "5 - 13", "5 - 14", "5 - 15", "6 - 7", "6 - 8", 
        "6 - 9", "6 - 10", "6 - 11", "6 - 12", "6 - 13", "6 - 14", "6 - 15", "7 - 8", "7 - 9", "7 - 10", 
        "7 - 11", "7 - 12", "7 - 13", "7 - 14", "7 - 15", "8 - 9", "8 - 10", "8 - 11", "8 - 12", "8 - 13", 
        "8 - 14", "8 - 15", "9 - 10", "9 - 11", "9 - 12", "9 - 13", "9 - 14", "9 - 15", "10 - 11", "10 - 12", 
        "10 - 13", "10 - 14", "10 - 15", "11 - 12", "11 - 13", "11 - 14", "11 - 15", "12 - 13", "12 - 14", "12 - 15", 
        "13 - 14", "13 - 15", "14 - 15" };
    ditherLevel.setModel(new DefaultComboBoxModel<>(ditherModel));
    dither_method.setSelectedIndex(2);
    bright_slider = new JSlider();
    contrast_slider = new JSlider();
    redslider = new JSlider();
    greenslider = new JSlider();
    blueslider = new JSlider();
    darkslider = new JSlider();
    mediumslider = new JSlider();
    gainslider = new JSlider();
    hueslider = new JSlider();
    satslider = new JSlider();
    this.save = new JButton(this.saveB);
    this.savepc = new JButton(this.savePB);
    impscr = new JButton(this.impB);
    addline = new JButton(this.lineB);
    addplot = new JButton(this.plotB);
    addrect = new JButton(this.rectB);
    addoval = new JButton(this.circleB);
    addfrect = new JButton(this.frectB);
    addfoval = new JButton(this.fcircleB);
    posterize = new JButton(this.posterizeB);
    moviemaker = new JButton("MovieMaker");
    moviemaker.setFocusPainted(false);
    moviemaker.setFocusable(false);
    flipp = new FlipPanel();
    asbmp = new JButton(this.asbmpB);
    copy = new JButton(this.copyB);
    paste = new JButton(this.pasteB);
    undo = new JButton(this.undoB);
    fill = new JButton(this.fillB);
    addtext = new JButton(this.textB);
    undo.setBorder((Border)null);
    fill.setBorder((Border)null);
    addtext.setBorder((Border)null);
    this.save.setBorder((Border)null);
    this.savepc.setBorder((Border)null);
    impscr.setBorder((Border)null);
    addline.setBorder((Border)null);
    addplot.setBorder((Border)null);
    addrect.setBorder((Border)null);
    addoval.setBorder((Border)null);
    addfrect.setBorder((Border)null);
    addfoval.setBorder((Border)null);
    copy.setBorder((Border)null);
    paste.setBorder((Border)null);
    this.clearButton = new JButton(this.clearB);
    this.clearButton.setBorder((Border)null);
    posterize.setBorder((Border)null);
    asbmp.setBorder((Border)null);
    pen0 = new JPanel();
    pen1 = new JPanel();
    pen2 = new JPanel();
    pen3 = new JPanel();
    pen4 = new JPanel();
    pen5 = new JPanel();
    pen6 = new JPanel();
    pen7 = new JPanel();
    pen8 = new JPanel();
    pen9 = new JPanel();
    pen10 = new JPanel();
    pen11 = new JPanel();
    pen12 = new JPanel();
    pen13 = new JPanel();
    pen14 = new JPanel();
    pen15 = new JPanel();
    pen0.addMouseListener(this);
    pen1.addMouseListener(this);
    pen2.addMouseListener(this);
    pen3.addMouseListener(this);
    pen4.addMouseListener(this);
    pen5.addMouseListener(this);
    pen6.addMouseListener(this);
    pen7.addMouseListener(this);
    pen8.addMouseListener(this);
    pen9.addMouseListener(this);
    pen10.addMouseListener(this);
    pen11.addMouseListener(this);
    pen12.addMouseListener(this);
    pen13.addMouseListener(this);
    pen14.addMouseListener(this);
    pen15.addMouseListener(this);
    pen0.setLayout(new BorderLayout());
    pen1.setLayout(new BorderLayout());
    pen2.setLayout(new BorderLayout());
    pen3.setLayout(new BorderLayout());
    pen4.setLayout(new BorderLayout());
    pen5.setLayout(new BorderLayout());
    pen6.setLayout(new BorderLayout());
    pen7.setLayout(new BorderLayout());
    pen8.setLayout(new BorderLayout());
    pen9.setLayout(new BorderLayout());
    pen10.setLayout(new BorderLayout());
    pen11.setLayout(new BorderLayout());
    pen12.setLayout(new BorderLayout());
    pen13.setLayout(new BorderLayout());
    pen14.setLayout(new BorderLayout());
    pen15.setLayout(new BorderLayout());
    pen0l = new JLabel(this.pen0B);
    pen1l = new JLabel(this.pen1B);
    pen2l = new JLabel(this.pen2B);
    pen3l = new JLabel(this.pen3B);
    pen4l = new JLabel(this.pen4B);
    pen5l = new JLabel(this.pen5B);
    pen6l = new JLabel(this.pen6B);
    pen7l = new JLabel(this.pen7B);
    pen8l = new JLabel(this.pen8B);
    pen9l = new JLabel(this.pen9B);
    pen10l = new JLabel(this.pen10B);
    pen11l = new JLabel(this.pen11B);
    pen12l = new JLabel(this.pen12B);
    pen13l = new JLabel(this.pen13B);
    pen14l = new JLabel(this.pen14B);
    pen15l = new JLabel(this.pen15B);
    pen0.add(pen0l, "Center");
    pen1.add(pen1l, "Center");
    pen2.add(pen2l, "Center");
    pen3.add(pen3l, "Center");
    pen4.add(pen4l, "Center");
    pen5.add(pen5l, "Center");
    pen6.add(pen6l, "Center");
    pen7.add(pen7l, "Center");
    pen8.add(pen8l, "Center");
    pen9.add(pen9l, "Center");
    pen10.add(pen10l, "Center");
    pen11.add(pen11l, "Center");
    pen12.add(pen12l, "Center");
    pen13.add(pen13l, "Center");
    pen14.add(pen14l, "Center");
    pen15.add(pen15l, "Center");
    Dimension b = new Dimension(48, 20);
    pen0.setSize(b);
    pen1.setSize(b);
    pen2.setSize(b);
    pen3.setSize(b);
    pen4.setSize(b);
    pen5.setSize(b);
    pen6.setSize(b);
    pen7.setSize(b);
    pen8.setSize(b);
    pen9.setSize(b);
    pen10.setSize(b);
    pen11.setSize(b);
    pen12.setSize(b);
    pen13.setSize(b);
    pen14.setSize(b);
    pen15.setSize(b);
    pen0l.setSize(b);
    pen1l.setSize(b);
    pen2l.setSize(b);
    pen3l.setSize(b);
    pen4l.setSize(b);
    pen5l.setSize(b);
    pen6l.setSize(b);
    pen7l.setSize(b);
    pen8l.setSize(b);
    pen9l.setSize(b);
    pen10l.setSize(b);
    pen11l.setSize(b);
    pen12l.setSize(b);
    pen13l.setSize(b);
    pen14l.setSize(b);
    pen15l.setSize(b);
    pen0.setBorder((Border)null);
    pen1.setBorder((Border)null);
    pen2.setBorder((Border)null);
    pen3.setBorder((Border)null);
    pen4.setBorder((Border)null);
    pen5.setBorder((Border)null);
    pen6.setBorder((Border)null);
    pen7.setBorder((Border)null);
    pen8.setBorder((Border)null);
    pen9.setBorder((Border)null);
    pen10.setBorder((Border)null);
    pen11.setBorder((Border)null);
    pen12.setBorder((Border)null);
    pen13.setBorder((Border)null);
    pen14.setBorder((Border)null);
    pen15.setBorder((Border)null);
    pen0l.setBorder((Border)null);
    pen1l.setBorder((Border)null);
    pen2l.setBorder((Border)null);
    pen3l.setBorder((Border)null);
    pen4l.setBorder((Border)null);
    pen5l.setBorder((Border)null);
    pen6l.setBorder((Border)null);
    pen7l.setBorder((Border)null);
    pen8l.setBorder((Border)null);
    pen9l.setBorder((Border)null);
    pen10l.setBorder((Border)null);
    pen11l.setBorder((Border)null);
    pen12l.setBorder((Border)null);
    pen13l.setBorder((Border)null);
    pen14l.setBorder((Border)null);
    pen15l.setBorder((Border)null);
    scrmode = new JButton(this.mode1B);
    scrmode.setBorder((Border)null);
    if (PaintCanvas.green) {
      pen0.setBackground(CPC.getGCol(0));
      pen1.setBackground(CPC.getGCol(1));
      pen2.setBackground(CPC.getGCol(2));
      pen3.setBackground(CPC.getGCol(3));
      pen4.setBackground(CPC.getGCol(4));
      pen5.setBackground(CPC.getGCol(5));
      pen6.setBackground(CPC.getGCol(6));
      pen7.setBackground(CPC.getGCol(7));
      pen8.setBackground(CPC.getGCol(8));
      pen9.setBackground(CPC.getGCol(9));
      pen10.setBackground(CPC.getGCol(10));
      pen11.setBackground(CPC.getGCol(11));
      pen12.setBackground(CPC.getGCol(12));
      pen13.setBackground(CPC.getGCol(13));
      pen14.setBackground(CPC.getGCol(14));
      pen15.setBackground(CPC.getGCol(15));
    } else {
      pen0.setBackground(CPC.getCol(0));
      pen1.setBackground(CPC.getCol(1));
      pen2.setBackground(CPC.getCol(2));
      pen3.setBackground(CPC.getCol(3));
      pen4.setBackground(CPC.getCol(4));
      pen5.setBackground(CPC.getCol(5));
      pen6.setBackground(CPC.getCol(6));
      pen7.setBackground(CPC.getCol(7));
      pen8.setBackground(CPC.getCol(8));
      pen9.setBackground(CPC.getCol(9));
      pen10.setBackground(CPC.getCol(10));
      pen11.setBackground(CPC.getCol(11));
      pen12.setBackground(CPC.getCol(12));
      pen13.setBackground(CPC.getCol(13));
      pen14.setBackground(CPC.getCol(14));
      pen15.setBackground(CPC.getCol(15));
    } 
    this.clearButton.addActionListener(this);
    addplot.addActionListener(this);
    addtext.addActionListener(this);
    scrmode.addActionListener(this);
    posterize.addActionListener(this);
    moviemaker.addActionListener(this);
    asbmp.addActionListener(this);
    undo.addActionListener(this);
    fill.addActionListener(this);
    addline.addActionListener(this);
    addrect.addActionListener(this);
    addoval.addActionListener(this);
    addfrect.addActionListener(this);
    addfoval.addActionListener(this);
    fontbox.addActionListener(this);
    copy.addActionListener(this);
    paste.addActionListener(this);
    this.save.addActionListener(this);
    this.savepc.addActionListener(this);
    impscr.addActionListener(this);
    okpen.addActionListener(this);
    changepen.addActionListener(this);
    transpen.addActionListener(this);
    setToTop.addActionListener(this);
    sto.addActionListener(this);
    resto.addActionListener(this);
    this.dskButton.addActionListener(this);
    this.miniButton.addActionListener(this);
    raster_slider.setMinimum(15);
    raster_slider.setMaximum(120);
    raster_slider.setValue(120);
    raster_slider.setInverted(true);
    raster_slider.setOrientation(1);
    raster_slider.setPaintTicks(true);
    raster_slider.setPaintLabels(false);
    raster_slider.setPaintTrack(true);
    raster_slider.setMinorTickSpacing(15);
    raster_slider.setSnapToTicks(false);
    raster_slider.setPreferredSize(new Dimension(34, 100));
    raster_slider.setBorder(new EtchedBorder());
    raster_slider.setEnabled(true);
    raster_slider.addChangeListener(new ChangeListener() {
          private int lastValue = 0;
          
          public void stateChanged(ChangeEvent e) {
            this.lastValue = normalPaint.raster_slider.getValue();
            normalPaint.Paintbox;
            PaintCanvas.ditherval = this.lastValue;
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
          }
        });
    dither_slider.setEnabled(true);
    dither_slider.addChangeListener(new ChangeListener() {
          private int lastValue = 0;
          
          public void stateChanged(ChangeEvent e) {
            normalPaint.Paintbox.dlevel = normalPaint.dither_slider.isSelected();
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
          }
        });
    bumpbox.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent e) {
            normalPaint.Paintbox;
            PaintCanvas.dobump = normalPaint.bumpbox.isSelected();
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
          }
        });
    dither_method.setEnabled(true);
    final String[] lev = { 
        "2", "4", "6", "8", "10", "12", "14", "16", "18", "20", 
        "22", "24", "26", "28", "30", "32" };
    dither_levels.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            normalPaint.Paintbox.ditherlevel = Integer.parseInt(lev[normalPaint.dither_levels.getSelectedIndex()]);
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
          }
        });
    ditherLevel.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            int cmd = normalPaint.ditherLevel.getSelectedIndex();
            if (cmd == 0 || cmd == 2 || cmd == 8)
              cmd = 0; 
            if (cmd > 1)
              cmd--; 
            if (cmd > 6)
              cmd--; 
            normalPaint.Paintbox.commandInt = cmd;
            System.out.println("Dither changed to " + normalPaint.Paintbox.commandInt);
          }
        });
    dither_method.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            normalPaint.Paintbox.dithermethod = normalPaint.dither_method.getSelectedIndex() + 1;
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
          }
        });
    bright_slider.setMinimum(0);
    bright_slider.setMaximum(200);
    bright_slider.setValue(100);
    bright_slider.setInverted(false);
    bright_slider.setOrientation(1);
    bright_slider.setPaintTicks(true);
    bright_slider.setPaintLabels(false);
    bright_slider.setPaintTrack(true);
    bright_slider.setMinorTickSpacing(25);
    bright_slider.setSnapToTicks(false);
    bright_slider.setPreferredSize(new Dimension(34, 100));
    bright_slider.setBorder(new EtchedBorder());
    bright_slider.setEnabled(true);
    bright_slider.addChangeListener(new ChangeListener() {
          private int lastValue = 0;
          
          public void stateChanged(ChangeEvent e) {
            this.lastValue = normalPaint.bright_slider.getValue();
            normalPaint.this.bright.setText("" + this.lastValue);
            normalPaint.Paintbox.bright = this.lastValue;
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
            normalPaint.Paintbox.detected = false;
          }
        });
    contrast_slider.setMinimum(0);
    contrast_slider.setMaximum(200);
    contrast_slider.setValue(100);
    contrast_slider.setInverted(false);
    contrast_slider.setOrientation(1);
    contrast_slider.setPaintTicks(true);
    contrast_slider.setPaintLabels(false);
    contrast_slider.setPaintTrack(true);
    contrast_slider.setMinorTickSpacing(25);
    contrast_slider.setSnapToTicks(false);
    contrast_slider.setPreferredSize(new Dimension(34, 100));
    contrast_slider.setBorder(new EtchedBorder());
    contrast_slider.setEnabled(true);
    contrast_slider.addChangeListener(new ChangeListener() {
          private int lastValue = 0;
          
          public void stateChanged(ChangeEvent e) {
            this.lastValue = normalPaint.contrast_slider.getValue();
            normalPaint.this.contrast.setText("" + this.lastValue);
            normalPaint.Paintbox.contrast = this.lastValue;
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
            normalPaint.Paintbox.detected = false;
          }
        });
    redslider.setMinimum(-255);
    redslider.setMaximum(255);
    redslider.setValue(0);
    redslider.setOrientation(1);
    redslider.setPaintTicks(true);
    redslider.setPaintLabels(false);
    redslider.setPaintTrack(true);
    redslider.setMinorTickSpacing(64);
    redslider.setSnapToTicks(false);
    redslider.setPreferredSize(new Dimension(30, 100));
    redslider.setBorder(new EtchedBorder());
    redslider.setEnabled(true);
    redslider.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent e) {
            normalPaint.Paintbox.addr = normalPaint.redslider.getValue();
            normalPaint.this.rl.setText("" + normalPaint.Paintbox.addr);
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
            normalPaint.Paintbox.detected = false;
          }
        });
    greenslider.setMinimum(-255);
    greenslider.setMaximum(255);
    greenslider.setValue(0);
    greenslider.setOrientation(1);
    greenslider.setPaintTicks(true);
    greenslider.setPaintLabels(false);
    greenslider.setPaintTrack(true);
    greenslider.setMinorTickSpacing(64);
    greenslider.setSnapToTicks(false);
    greenslider.setPreferredSize(new Dimension(30, 100));
    greenslider.setBorder(new EtchedBorder());
    greenslider.setEnabled(true);
    greenslider.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent e) {
            normalPaint.Paintbox.addg = normalPaint.greenslider.getValue();
            normalPaint.this.gl.setText("" + normalPaint.Paintbox.addg);
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
            normalPaint.Paintbox.detected = false;
          }
        });
    blueslider.setMinimum(-255);
    blueslider.setMaximum(255);
    blueslider.setValue(0);
    blueslider.setOrientation(1);
    blueslider.setPaintTicks(true);
    blueslider.setPaintLabels(false);
    blueslider.setPaintTrack(true);
    blueslider.setMinorTickSpacing(64);
    blueslider.setSnapToTicks(false);
    blueslider.setPreferredSize(new Dimension(30, 100));
    blueslider.setBorder(new EtchedBorder());
    blueslider.setEnabled(true);
    blueslider.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent e) {
            normalPaint.Paintbox.addb = normalPaint.blueslider.getValue();
            normalPaint.this.bl.setText("" + normalPaint.Paintbox.addb);
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
            normalPaint.Paintbox.detected = false;
          }
        });
    darkslider.setMinimum(0);
    darkslider.setMaximum(255);
    darkslider.setValue(85);
    darkslider.setInverted(false);
    darkslider.setOrientation(1);
    darkslider.setPaintTicks(true);
    darkslider.setPaintLabels(false);
    darkslider.setPaintTrack(true);
    darkslider.setMinorTickSpacing(17);
    darkslider.setSnapToTicks(true);
    darkslider.setPreferredSize(new Dimension(30, 100));
    darkslider.setBorder(new EtchedBorder());
    darkslider.setEnabled(true);
    darkslider.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent e) {
            normalPaint.Paintbox.dark = normalPaint.darkslider.getValue();
            normalPaint.this.dark.setText(normalPaint.Paintbox.dark + "");
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
            normalPaint.Paintbox.detected = false;
          }
        });
    mediumslider.setMinimum(0);
    mediumslider.setMaximum(255);
    mediumslider.setValue(170);
    mediumslider.setInverted(false);
    mediumslider.setOrientation(1);
    mediumslider.setPaintTicks(true);
    mediumslider.setPaintLabels(false);
    mediumslider.setPaintTrack(true);
    mediumslider.setMinorTickSpacing(17);
    mediumslider.setSnapToTicks(true);
    mediumslider.setPreferredSize(new Dimension(30, 100));
    mediumslider.setBorder(new EtchedBorder());
    mediumslider.setEnabled(true);
    mediumslider.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent e) {
            normalPaint.Paintbox.medium = normalPaint.mediumslider.getValue();
            normalPaint.this.medium.setText(normalPaint.Paintbox.medium + "");
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
            normalPaint.Paintbox.detected = false;
          }
        });
    gainslider.setMinimum(0);
    gainslider.setMaximum(200);
    gainslider.setValue(150);
    gainslider.setInverted(false);
    gainslider.setOrientation(1);
    gainslider.setPaintTicks(true);
    gainslider.setPaintLabels(false);
    gainslider.setPaintTrack(true);
    gainslider.setMinorTickSpacing(25);
    gainslider.setSnapToTicks(false);
    gainslider.setPreferredSize(new Dimension(30, 100));
    gainslider.setBorder(new EtchedBorder());
    gainslider.setEnabled(true);
    gainslider.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent e) {
            normalPaint.Paintbox.gainvalue = normalPaint.gainslider.getValue();
            normalPaint.this.gain.setText(normalPaint.Paintbox.gainvalue + "");
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
            normalPaint.Paintbox.detected = false;
          }
        });
    satslider.setMinimum(0);
    satslider.setMaximum(200);
    satslider.setValue(100);
    satslider.setInverted(false);
    satslider.setOrientation(1);
    satslider.setPaintTicks(true);
    satslider.setPaintLabels(false);
    satslider.setPaintTrack(true);
    satslider.setMinorTickSpacing(25);
    satslider.setSnapToTicks(false);
    satslider.setPreferredSize(new Dimension(30, 100));
    satslider.setBorder(new EtchedBorder());
    satslider.setEnabled(true);
    satslider.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent e) {
            normalPaint.Paintbox.sat = normalPaint.satslider.getValue();
            normalPaint.this.sat.setText(normalPaint.Paintbox.sat + "");
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
            normalPaint.Paintbox.detected = false;
          }
        });
    hueslider.setMinimum(0);
    hueslider.setMaximum(200);
    hueslider.setValue(100);
    hueslider.setInverted(false);
    hueslider.setOrientation(1);
    hueslider.setPaintTicks(true);
    hueslider.setPaintLabels(false);
    hueslider.setPaintTrack(true);
    hueslider.setMinorTickSpacing(25);
    hueslider.setSnapToTicks(false);
    hueslider.setPreferredSize(new Dimension(30, 100));
    hueslider.setBorder(new EtchedBorder());
    hueslider.setEnabled(true);
    hueslider.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent e) {
            normalPaint.Paintbox.hue = normalPaint.hueslider.getValue();
            normalPaint.this.hue.setText(normalPaint.Paintbox.hue + "");
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
            normalPaint.Paintbox.detected = false;
          }
        });
    ScrollUpDown.setMinimum(0);
    ScrollUpDown.setMaximum(1);
    ScrollUpDown.setValue(0);
    ScrollUpDown.setOrientation(1);
    ScrollUpDown.setPreferredSize(new Dimension(14, 400));
    ScrollUpDown.setBorder(new EtchedBorder());
    ScrollUpDown.setBorder((Border)null);
    ScrollUpDown.setEnabled(false);
    ScrollUpDown.addAdjustmentListener(new AdjustmentListener() {
          private int lastValue = 0;
          
          public void adjustmentValueChanged(AdjustmentEvent e) {
            this.lastValue = normalPaint.ScrollUpDown.getValue();
            if (normalPaint.Paintbox.scroll != this.lastValue) {
              normalPaint.Paintbox.scroll = this.lastValue;
              normalPaint.Paintbox.scrollImage();
              normalPaint.ScrollUpDown.repaint();
            } 
          }
        });
    ScrollLeftRight.setMinimum(0);
    ScrollLeftRight.setMaximum(1);
    ScrollLeftRight.setValue(0);
    ScrollLeftRight.setOrientation(0);
    ScrollLeftRight.setPreferredSize(new Dimension(640, 12));
    ScrollLeftRight.setBorder(new EtchedBorder());
    ScrollLeftRight.setBorder((Border)null);
    ScrollLeftRight.setEnabled(false);
    ScrollLeftRight.addAdjustmentListener(new AdjustmentListener() {
          private int lastValue = 0;
          
          public void adjustmentValueChanged(AdjustmentEvent e) {
            this.lastValue = normalPaint.ScrollLeftRight.getValue();
            if (normalPaint.Paintbox.scrollb != this.lastValue) {
              normalPaint.Paintbox.scrollb = this.lastValue;
              normalPaint.Paintbox.scrollImage();
              normalPaint.ScrollUpDown.repaint();
            } 
          }
        });
    this.buttons.add(this.clearButton);
    this.buttons.add(impscr);
    this.buttons.add(copy);
    this.buttons.add(paste);
    this.buttons.add(addplot);
    this.buttons.add(addline);
    this.buttons.add(addrect);
    this.buttons.add(addfrect);
    this.buttons.add(addoval);
    this.buttons.add(addfoval);
    this.buttons.add(fill);
    this.buttons.add(addtext);
    this.buttons.add(this.save);
    this.buttons.add(this.savepc);
    this.paint1.add(this.buttons, "North");
    this.paint1.add(Paintbox, "West");
    this.paint1.add(ScrollUpDown, "East");
    this.paint1.add(ScrollLeftRight, "South");
    this.paint.add(this.paint1);
    this.other.add(setToTop);
    this.other.add(this.dskButton);
    this.other.add(asbmp);
    this.other.add(pen0);
    this.other.add(pen1);
    this.other.add(pen2);
    this.other.add(pen3);
    this.other.add(pen4);
    this.other.add(pen5);
    this.other.add(pen6);
    this.other.add(pen7);
    this.other.add(pen8);
    this.other.add(pen9);
    this.other.add(pen10);
    this.other.add(pen11);
    this.other.add(pen12);
    this.other.add(pen13);
    this.other.add(pen14);
    this.other.add(pen15);
    this.other.add(undo);
    this.other.add(this.miniButton);
    this.other.add(scrmode);
    this.other.add(posterize);
    text.setColumns(15);
    textsize.setColumns(3);
    textsize.setText("90");
    this.options.add(this.keepinks);
    this.options.add(this.keep);
    this.options.add(zooms);
    this.options.add(this.stretch);
    this.options.add(zoom);
    this.options.add(moviemaker);
    this.options.add(new JLabel("Dithered fill:"));
    this.options.add(ditherLevel);
    this.misc.add(translabel);
    this.misc.add(transpen);
    this.misc.add(change);
    this.misc.add(changepen);
    this.misc.add(changei);
    this.misc.add(sto);
    this.misc.add(resto);
    this.misc.add(storeto);
    this.textarea.add(entertext);
    this.textarea.add(text);
    this.textarea.add(fontbox);
    this.textarea.add(textsize);
    this.textarea.add(this.italic);
    this.textarea.add(this.bold);
    this.textarea.add(this.crunch);
    this.crunch.setFocusable(false);
    this.crunch.addActionListener(this);
    this.crunch.setVisible(false);
    this.panel.add(outpane);
    this.panel.add(flipp);
    flipp.putA.addActionListener(this);
    flipp.putB.addActionListener(this);
    flipp.getA.addActionListener(this);
    flipp.getB.addActionListener(this);
    flipp.merge.addActionListener(this);
    flipp.flip.addActionListener(this);
    JLabel lab1 = new JLabel("RED");
    JLabel lab2 = new JLabel("GREEN");
    JLabel lab3 = new JLabel("BLUE");
    JLabel lab4 = new JLabel("LOW");
    JLabel lab5 = new JLabel("MED");
    JLabel lab6 = new JLabel("DITHER");
    JLabel lab7 = new JLabel("BRIGHT");
    JLabel lab8 = new JLabel("GAIN");
    JLabel lab9 = new JLabel("HUE");
    JLabel lab10 = new JLabel("SAT");
    JLabel lab11 = new JLabel("CONTRAST");
    lab1.setFont(new Font("Tahoma", 1, 8));
    lab2.setFont(new Font("Tahoma", 1, 8));
    lab3.setFont(new Font("Tahoma", 1, 8));
    lab4.setFont(new Font("Tahoma", 1, 8));
    lab5.setFont(new Font("Tahoma", 1, 8));
    lab6.setFont(new Font("Tahoma", 1, 8));
    lab7.setFont(new Font("Tahoma", 1, 8));
    lab8.setFont(new Font("Tahoma", 1, 8));
    lab9.setFont(new Font("Tahoma", 1, 8));
    lab10.setFont(new Font("Tahoma", 1, 8));
    lab11.setFont(new Font("Tahoma", 1, 8));
    this.rslider.add(redslider, "Center");
    this.rslider.add(this.rl, "South");
    this.rslider.add(lab1, "North");
    this.gslider.add(greenslider, "Center");
    this.gslider.add(this.gl, "South");
    this.gslider.add(lab2, "North");
    this.bslider.add(blueslider, "Center");
    this.bslider.add(this.bl, "South");
    this.bslider.add(lab3, "North");
    this.meslider.add(mediumslider, "Center");
    this.meslider.add(this.medium, "South");
    this.meslider.add(lab4, "North");
    this.daslider.add(darkslider, "Center");
    this.daslider.add(this.dark, "South");
    this.daslider.add(lab5, "North");
    this.dslider.add(raster_slider, "Center");
    this.dslider.add(new JLabel("Dither"), "South");
    this.dslider.add(lab6, "North");
    this.brslider.add(bright_slider, "Center");
    this.brslider.add(this.bright, "South");
    this.brslider.add(lab7, "North");
    this.ctslider.add(contrast_slider, "Center");
    this.ctslider.add(this.contrast, "South");
    this.ctslider.add(lab11, "North");
    this.gaslider.add(gainslider, "Center");
    this.gaslider.add(this.gain, "South");
    this.gaslider.add(lab8, "North");
    this.huslider.add(hueslider, "Center");
    this.huslider.add(this.hue, "South");
    this.huslider.add(lab9, "North");
    this.saslider.add(satslider, "Center");
    this.saslider.add(this.sat, "South");
    this.saslider.add(lab10, "North");
    this.manipframe = new JFrame("Effectmixer");
    this.manipframe.setDefaultCloseOperation(0);
    this.manipframe.setResizable(false);
    this.manipframe.setAlwaysOnTop(false);
    this.manipframe.setLayout(new BorderLayout());
    JPanel mani = new JPanel();
    mani.setLayout(new FlowLayout(0, 3, 3));
    mani.add(this.rslider);
    mani.add(this.gslider);
    mani.add(this.bslider);
    mani.add(this.daslider);
    mani.add(this.meslider);
    mani.add(this.dslider);
    mani.add(this.brslider);
    mani.add(this.ctslider);
    mani.add(this.gaslider);
    mani.add(this.huslider);
    mani.add(this.saslider);
    JPanel pann = new JPanel();
    pann.setLayout(new BorderLayout());
    pann.add(bumpbox, "North");
    JPanel dit = new JPanel();
    dit.setLayout(new BorderLayout());
    dit.add(dither_slider, "North");
    dit.add(dither_method, "Center");
    dit.add(dither_levels, "South");
    pann.add(dit, "Center");
    mani.add(pann);
    proc = new ImageProcessor();
    proc.sliders.add(mani);
    proc.image.addMouseListener(this);
    proc.image.addMouseMotionListener(this);
    addMouseWheelListener(this);
    proc.addMouseWheelListener(this);
    Color half = proc.getBackground();
    setBackground(new Color(half.getRed() / 2, half.getGreen() / 2, half.getBlue() / 2));
    proc.buttons.setPreferredSize(new Dimension(200, (satslider.getPreferredSize()).height + 28));
    proc.but1.add(this.grey);
    proc.but2.add(this.green);
    proc.but3.add(this.blur);
    proc.but4.add(this.sharp);
    this.manipframe.add(proc);
    proc.Presets.addActionListener(this);
    ImageProcessor.plus.addItemListener(this);
    ImageProcessor.precalculate.addItemListener(this);
    ImageProcessor.preorder.addItemListener(this);
    ImageProcessor.method.addItemListener(this);
    ImageProcessor.method1.addItemListener(this);
    ImageProcessor.ordered.addItemListener(this);
    ImageProcessor.tolerance.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent e) {
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
            normalPaint.Paintbox.detected = false;
          }
        });
    proc.toleranceSetter.plus.addActionListener(this);
    proc.toleranceSetter.minus.addActionListener(this);
    ImageProcessor.method2.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent e) {
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
            normalPaint.Paintbox.detected = false;
          }
        });
    ImageProcessor.divider.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent e) {
            normalPaint.Paintbox;
            PaintCanvas.recalculate = 1;
            normalPaint.Paintbox.detected = false;
          }
        });
    proc.dividerSetter.plus.addActionListener(this);
    proc.dividerSetter.minus.addActionListener(this);
    registerDropListener(this.dropTargetList, proc, myListener);
    this.manipframe.pack();
    this.manipframe.setVisible(true);
    this.manipframe.setLocation((this.panel.getLocation()).x + this.panel.getWidth(), (this.panel.getLocation()).y);
    add(this.paint);
    add(this.other);
    add(this.options);
    add(this.misc);
    add(this.textarea);
    add(this.panel);
    setSize(this.APPLET_WIDTH, this.APPLET_HEIGHT);
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            int h = normalPaint.this.options.getHeight() - 2;
            int w = normalPaint.this.panel.getWidth();
            normalPaint.this.options.setPreferredSize(new Dimension(w, h));
            normalPaint.this.misc.setPreferredSize(new Dimension(w, h));
            normalPaint.this.textarea.setPreferredSize(new Dimension(w, h));
            normalPaint.this.options.setSize(new Dimension(w, h));
            normalPaint.this.misc.setSize(new Dimension(w, h));
            normalPaint.this.textarea.setSize(new Dimension(w, h));
            normalPaint.outpane.setPreferredSize(new Dimension(normalPaint.outpane.getWidth(), 130));
            normalPaint.outpane.setSize(new Dimension(normalPaint.outpane.getWidth(), 130));
          }
        });
  }
  
  JLabel hue = new JLabel("100");
  
  JLabel sat = new JLabel("100");
  
  JLabel gain = new JLabel("150");
  
  JLabel dark = new JLabel("85");
  
  JLabel medium = new JLabel("170");
  
  JLabel bright = new JLabel("100");
  
  JLabel contrast = new JLabel("100");
  
  JLabel rl = new JLabel("00");
  
  JLabel gl = new JLabel("00");
  
  JLabel bl = new JLabel("00");
  
  public JFrame manipframe;
  
  Color crunchColor;
  
  public FlipPanel getFlip() {
    return flipp;
  }
  
  public boolean getPlus() {
    return Paintbox.getPlus();
  }
  
  public void checkButton() {
    copy.setEnabled((PaintCanvas.MODE != PaintCanvas.MODE_COPY));
    paste.setEnabled((PaintCanvas.MODE != PaintCanvas.MODE_PASTE));
    addplot.setEnabled((PaintCanvas.MODE != PaintCanvas.MODE_PAINT));
    addline.setEnabled((PaintCanvas.MODE != PaintCanvas.MODE_LINE));
    addrect.setEnabled((PaintCanvas.MODE != PaintCanvas.MODE_RECTANGLE));
    addfrect.setEnabled((PaintCanvas.MODE != PaintCanvas.MODE_FRECT));
    addoval.setEnabled((PaintCanvas.MODE != PaintCanvas.MODE_CIRCLE));
    addfoval.setEnabled((PaintCanvas.MODE != PaintCanvas.MODE_FCIRCLE));
    fill.setEnabled((PaintCanvas.MODE != PaintCanvas.MODE_FILL));
    addtext.setEnabled((PaintCanvas.MODE != PaintCanvas.MODE_TEXT));
    if (Paintbox.mode == 1 && scrmode.getIcon() != this.mode1B)
      scrmode.setIcon(this.mode1B); 
    if (Paintbox.mode == 0 && scrmode.getIcon() != this.mode0B)
      scrmode.setIcon(this.mode0B); 
    if (Paintbox.mode == 2 && scrmode.getIcon() != this.mode2B)
      scrmode.setIcon(this.mode2B); 
  }
  
  public static void reset() {
    if (PaintCanvas.green) {
      pen0.setBackground(CPC.getGCol(0));
      pen1.setBackground(CPC.getGCol(1));
      pen2.setBackground(CPC.getGCol(2));
      pen3.setBackground(CPC.getGCol(3));
      pen4.setBackground(CPC.getGCol(4));
      pen5.setBackground(CPC.getGCol(5));
      pen6.setBackground(CPC.getGCol(6));
      pen7.setBackground(CPC.getGCol(7));
      pen8.setBackground(CPC.getGCol(8));
      pen9.setBackground(CPC.getGCol(9));
      pen10.setBackground(CPC.getGCol(10));
      pen11.setBackground(CPC.getGCol(11));
      pen12.setBackground(CPC.getGCol(12));
      pen13.setBackground(CPC.getGCol(13));
      pen14.setBackground(CPC.getGCol(14));
      pen15.setBackground(CPC.getGCol(15));
    } else {
      pen0.setBackground(CPC.getCol(0));
      pen1.setBackground(CPC.getCol(1));
      pen2.setBackground(CPC.getCol(2));
      pen3.setBackground(CPC.getCol(3));
      pen4.setBackground(CPC.getCol(4));
      pen5.setBackground(CPC.getCol(5));
      pen6.setBackground(CPC.getCol(6));
      pen7.setBackground(CPC.getCol(7));
      pen8.setBackground(CPC.getCol(8));
      pen9.setBackground(CPC.getCol(9));
      pen10.setBackground(CPC.getCol(10));
      pen11.setBackground(CPC.getCol(11));
      pen12.setBackground(CPC.getCol(12));
      pen13.setBackground(CPC.getCol(13));
      pen14.setBackground(CPC.getCol(14));
      pen15.setBackground(CPC.getCol(15));
    } 
    if (Paintbox.mode == 2) {
      if (pen3.isVisible())
        pen3.setVisible(false); 
      if (pen2.isVisible())
        pen2.setVisible(false); 
    } else {
      if (!pen3.isVisible())
        pen3.setVisible(true); 
      if (!pen2.isVisible())
        pen2.setVisible(true); 
    } 
    if (Paintbox.mode == 0) {
      if (!pen4.isVisible())
        pen4.setVisible(true); 
      if (!pen5.isVisible())
        pen5.setVisible(true); 
      if (!pen6.isVisible())
        pen6.setVisible(true); 
      if (!pen7.isVisible())
        pen7.setVisible(true); 
      if (!pen8.isVisible())
        pen8.setVisible(true); 
      if (!pen9.isVisible())
        pen9.setVisible(true); 
      if (!pen10.isVisible())
        pen10.setVisible(true); 
      if (!pen11.isVisible())
        pen11.setVisible(true); 
      if (!pen12.isVisible())
        pen12.setVisible(true); 
      if (!pen13.isVisible())
        pen13.setVisible(true); 
      if (!pen14.isVisible())
        pen14.setVisible(true); 
      if (!pen15.isVisible())
        pen15.setVisible(true); 
    } else {
      if (pen4.isVisible())
        pen4.setVisible(false); 
      if (pen5.isVisible())
        pen5.setVisible(false); 
      if (pen6.isVisible())
        pen6.setVisible(false); 
      if (pen7.isVisible())
        pen7.setVisible(false); 
      if (pen8.isVisible())
        pen8.setVisible(false); 
      if (pen9.isVisible())
        pen9.setVisible(false); 
      if (pen10.isVisible())
        pen10.setVisible(false); 
      if (pen11.isVisible())
        pen11.setVisible(false); 
      if (pen12.isVisible())
        pen12.setVisible(false); 
      if (pen13.isVisible())
        pen13.setVisible(false); 
      if (pen14.isVisible())
        pen14.setVisible(false); 
      if (pen15.isVisible())
        pen15.setVisible(false); 
    } 
  }
  
  public String showname() {
    try {
      return "JavaCPC Paint " + this.ver + "+ - " + Paintbox.showname();
    } catch (Exception exception) {
      return "JavaCPC Paint " + this.ver + "+";
    } 
  }
  
  public void loadDsk() {
    Paintbox.DSKLoad();
  }
  
  public byte[] getPlusPalette() {
    return Paintbox.getPlusPalette();
  }
  
  public void actionPerformed(ActionEvent event) {
    Paintbox.painted = true;
    reset();
    if (event.getSource() == this.crunch) {
      if (this.crunchColor == null)
        this.crunchColor = this.crunch.getForeground(); 
      this.crunch.setForeground(this.crunch.isSelected() ? Color.green : this.crunchColor);
    } 
    if (event.getSource() == proc.toleranceSetter.plus) {
      int value = ImageProcessor.tolerance.getValue();
      if (value < 100) {
        value += 5;
        ImageProcessor.tolerance.setValue(value);
        PaintCanvas.recalculate = 1;
        Paintbox.detected = false;
      } 
    } 
    if (event.getSource() == proc.toleranceSetter.minus) {
      int value = ImageProcessor.tolerance.getValue();
      if (value > 0) {
        value -= 5;
        ImageProcessor.tolerance.setValue(value);
        PaintCanvas.recalculate = 1;
        Paintbox.detected = false;
      } 
    } 
    if (event.getSource() == proc.dividerSetter.plus) {
      int value = ImageProcessor.divider.getValue();
      if (value < 100) {
        value += 5;
        ImageProcessor.divider.setValue(value);
        PaintCanvas.recalculate = 1;
        Paintbox.detected = false;
      } 
    } 
    if (event.getSource() == proc.dividerSetter.minus) {
      int value = ImageProcessor.divider.getValue();
      if (value > 0) {
        value -= 5;
        ImageProcessor.divider.setValue(value);
        PaintCanvas.recalculate = 1;
        Paintbox.detected = false;
      } 
    } 
    if (event.getSource() == proc.Presets) {
      int l = proc.Presets.getSelectedIndex();
      switch (l) {
        case 0:
          redslider.setValue(0);
          greenslider.setValue(0);
          blueslider.setValue(0);
          darkslider.setValue(85);
          mediumslider.setValue(170);
          raster_slider.setValue(120);
          bright_slider.setValue(100);
          contrast_slider.setValue(100);
          gainslider.setValue(150);
          hueslider.setValue(100);
          satslider.setValue(100);
          break;
        case 1:
          redslider.setValue(0);
          greenslider.setValue(0);
          blueslider.setValue(0);
          darkslider.setValue(85);
          mediumslider.setValue(170);
          bright_slider.setValue(110);
          contrast_slider.setValue(105);
          gainslider.setValue(130);
          hueslider.setValue(100);
          satslider.setValue(104);
          break;
        case 2:
          redslider.setValue(0);
          greenslider.setValue(0);
          blueslider.setValue(0);
          darkslider.setValue(85);
          mediumslider.setValue(170);
          bright_slider.setValue(110);
          contrast_slider.setValue(110);
          gainslider.setValue(125);
          hueslider.setValue(100);
          satslider.setValue(104);
          break;
        case 3:
          redslider.setValue(0);
          greenslider.setValue(0);
          blueslider.setValue(0);
          darkslider.setValue(85);
          mediumslider.setValue(170);
          bright_slider.setValue(100);
          contrast_slider.setValue(200);
          gainslider.setValue(10);
          hueslider.setValue(100);
          satslider.setValue(200);
          break;
        case 4:
          redslider.setValue(0);
          greenslider.setValue(0);
          blueslider.setValue(0);
          darkslider.setValue(85);
          mediumslider.setValue(170);
          bright_slider.setValue(100);
          contrast_slider.setValue(100);
          gainslider.setValue(110);
          hueslider.setValue(125);
          satslider.setValue(100);
          break;
        case 5:
          redslider.setValue(0);
          greenslider.setValue(0);
          blueslider.setValue(0);
          darkslider.setValue(85);
          mediumslider.setValue(170);
          bright_slider.setValue(100);
          contrast_slider.setValue(200);
          gainslider.setValue(145);
          hueslider.setValue(100);
          satslider.setValue(100);
          break;
        case 6:
          redslider.setValue(0);
          greenslider.setValue(0);
          blueslider.setValue(0);
          darkslider.setValue(85);
          mediumslider.setValue(170);
          bright_slider.setValue(100);
          contrast_slider.setValue(100);
          gainslider.setValue(135);
          hueslider.setValue(100);
          satslider.setValue(105);
          break;
        case 7:
          redslider.setValue(0);
          greenslider.setValue(0);
          blueslider.setValue(0);
          darkslider.setValue(85);
          mediumslider.setValue(170);
          raster_slider.setValue(120);
          bright_slider.setValue(115);
          contrast_slider.setValue(110);
          gainslider.setValue(140);
          hueslider.setValue(100);
          satslider.setValue(104);
          break;
        case 8:
          redslider.setValue(0);
          greenslider.setValue(0);
          blueslider.setValue(0);
          darkslider.setValue(85);
          mediumslider.setValue(170);
          raster_slider.setValue(15);
          bright_slider.setValue(75);
          contrast_slider.setValue(80);
          gainslider.setValue(148);
          hueslider.setValue(100);
          satslider.setValue(103);
          PaintCanvas.INK(0, 0);
          PaintCanvas.INK(1, 24);
          PaintCanvas.INK(2, 20);
          PaintCanvas.INK(3, 8);
          CPC.POKE(36863, 1);
          Paintbox.mode = 1;
          this.keepinks.setSelected(true);
          break;
      } 
    } 
    if (event.getSource() == this.save)
      CPC.savescreen = true; 
    if (event.getSource() == flipp.getA)
      Paintbox.getFlipA(); 
    if (event.getSource() == flipp.getB)
      Paintbox.getFlipB(); 
    if (event.getSource() == flipp.putA)
      Paintbox.putFlipA(); 
    if (event.getSource() == flipp.putB)
      Paintbox.putFlipB(); 
    if (event.getSource() == flipp.flip)
      CPC.showflippreview = flipp.flip.isSelected(); 
    if (event.getSource() == flipp.merge)
      Paintbox.deFlip(); 
    if (event.getSource() == changepen) {
      int pen = Integer.parseInt(changepen.getSelectedItem().toString());
      changeInk(pen);
    } 
    if (event.getSource() == transpen) {
      String gotpen = transpen.getSelectedItem().toString();
      Paintbox.transpen = 17;
      if (!gotpen.equals("Off"))
        Paintbox.transpen = Integer.parseInt(gotpen); 
      output.append("Transparent shape PEN is " + gotpen + "\n");
    } 
    if (event.getSource() == sto)
      Paintbox.storeScreen(); 
    if (event.getSource() == resto) {
      ImageProcessor.plus.removeItemListener(this);
      Paintbox.restoreScreen();
      ImageProcessor.plus.addItemListener(this);
    } 
    if (event.getSource() == setToTop) {
      if (CPC.PaintOnTop) {
        setToTop.setIcon(this.setTop);
        CPC.PaintOnTop = false;
      } else {
        setToTop.setIcon(this.isTop);
        CPC.PaintOnTop = true;
      } 
      CPC.setPaintOnTop = true;
    } 
    if (event.getSource() == this.dskButton)
      CPC.normalupdatebox = true; 
    if (event.getSource() == this.miniButton)
      Paintbox.minitext(); 
    if (event.getSource() == this.savepc) {
      CPC.packScreen = this.crunch.isSelected();
      Switches.savePScr = true;
    } 
    if (event.getSource() == scrmode) {
      if (Paintbox.mode == 1) {
        Paintbox.mode = 2;
        CPC.POKE(36863, 2);
      } else if (Paintbox.mode == 2) {
        Paintbox.mode = 0;
        CPC.POKE(36863, 3);
      } else if (Paintbox.mode == 0) {
        Paintbox.mode = 1;
        CPC.POKE(36863, 1);
      } 
      reset();
      if (PaintCanvas.MODE == PaintCanvas.MODE_IMPORT)
        PaintCanvas.recalculate = 1; 
      Paintbox.detected = false;
    } 
    if (event.getSource() == fontbox)
      Paintbox.fontname = fontbox.getSelectedItem().toString(); 
    if (event.getSource() == this.clearButton)
      Paintbox.clear(); 
    if (event.getSource() == undo)
      Paintbox.Undo(); 
    if (event.getSource() == fill)
      PaintCanvas.MODE = PaintCanvas.MODE_FILL; 
    if (event.getSource() == copy)
      PaintCanvas.MODE = PaintCanvas.MODE_COPY; 
    if (event.getSource() == paste)
      PaintCanvas.MODE = PaintCanvas.MODE_PASTE; 
    if (event.getSource() == addplot)
      PaintCanvas.MODE = PaintCanvas.MODE_PAINT; 
    if (event.getSource() == addline)
      PaintCanvas.MODE = PaintCanvas.MODE_LINE; 
    if (event.getSource() == addrect)
      PaintCanvas.MODE = PaintCanvas.MODE_RECTANGLE; 
    if (event.getSource() == addoval)
      PaintCanvas.MODE = PaintCanvas.MODE_CIRCLE; 
    if (event.getSource() == addfrect)
      PaintCanvas.MODE = PaintCanvas.MODE_FRECT; 
    if (event.getSource() == addfoval)
      PaintCanvas.MODE = PaintCanvas.MODE_FCIRCLE; 
    if (event.getSource() == addtext) {
      Paintbox.text = text.getText();
      Paintbox.textsize = Integer.parseInt(textsize.getText());
      PaintCanvas.MODE = PaintCanvas.MODE_TEXT;
    } 
    if (event.getSource() == impscr) {
      Paintbox.scrollImage = null;
      Paintbox.loadedImage = null;
      Runtime.getRuntime().gc();
      Paintbox.convertScreen();
    } 
    if (event.getSource() == posterize)
      Paintbox.posterize(); 
    if (event.getSource() == moviemaker)
      Paintbox.maker.setVisible(!Paintbox.maker.isVisible()); 
    if (event.getSource() == asbmp)
      PaintCanvas.autostore = true; 
  }
  
  public void makeUndo() {
    Paintbox.makeUndo();
  }
  
  public void Undo() {
    Paintbox.Undo();
  }
  
  public void cycle() {
    if (Paintbox.maker.inklock.isSelected() != this.keepinks.isSelected())
      this.keepinks.setSelected(Paintbox.maker.inklock.isSelected()); 
    checkButton();
    if (CPC.PEEK(36864) != 42 && CPC.PEEK(37160) != 82 && CPC.PEEK(37415) != 65) {
      if (scrmode.isEnabled()) {
        scrmode.setEnabled(false);
        this.save.setEnabled(false);
        this.dskButton.setEnabled(false);
      } 
    } else if (!scrmode.isEnabled()) {
      scrmode.setEnabled(true);
      this.save.setEnabled(true);
      this.dskButton.setEnabled(true);
    } 
    Paintbox.cycle();
  }
  
  protected ImageIcon createIcon(String path) {
    URL imgURL = getClass().getResource(path);
    if (imgURL != null)
      return new ImageIcon(imgURL); 
    System.err.println("Couldn't find file: " + path);
    return null;
  }
  
  ItemListener itemListener = new ItemListener() {
      public void itemStateChanged(ItemEvent itemEvent) {
        normalPaint.Paintbox.keep = normalPaint.this.keep.isSelected();
        if (normalPaint.Paintbox.keep)
          normalPaint.this.stretch.setSelected(false); 
        try {
          normalPaint.Paintbox.convertScreen(normalPaint.Paintbox.loadname);
        } catch (Exception e) {
          e.printStackTrace();
        } 
      }
    };
  
  ItemListener stretchListener = new ItemListener() {
      public void itemStateChanged(ItemEvent itemEvent) {
        normalPaint.Paintbox.stretch = normalPaint.this.stretch.isSelected();
        if (normalPaint.Paintbox.stretch)
          normalPaint.this.keep.setSelected(false); 
        try {
          normalPaint.Paintbox.convertScreen(normalPaint.Paintbox.loadname);
        } catch (Exception e) {
          e.printStackTrace();
        } 
      }
    };
  
  ItemListener inkListener = new ItemListener() {
      public void itemStateChanged(ItemEvent itemEvent) {
        int state = itemEvent.getStateChange();
        normalPaint.Paintbox.maker.inklock.setSelected((state == 1));
        if (state == 1) {
          normalPaint.this.lockALL();
          normalPaint.Paintbox.keepinks = true;
        } 
        if (state == 2) {
          normalPaint.this.unlockALL();
          normalPaint.Paintbox.keepinks = false;
        } 
      }
    };
  
  ItemListener greyListener = new ItemListener() {
      public void itemStateChanged(ItemEvent itemEvent) {
        int state = itemEvent.getStateChange();
        if (state == 1) {
          normalPaint.Paintbox.gray = true;
          try {
            normalPaint.Paintbox.convertScreen(normalPaint.Paintbox.loadname);
          } catch (Exception e) {
            e.printStackTrace();
          } 
        } 
        if (state == 2) {
          normalPaint.Paintbox.gray = false;
          try {
            normalPaint.Paintbox.convertScreen(normalPaint.Paintbox.loadname);
          } catch (Exception e) {
            e.printStackTrace();
          } 
        } 
      }
    };
  
  ItemListener italicListener = new ItemListener() {
      public void itemStateChanged(ItemEvent itemEvent) {
        int state = itemEvent.getStateChange();
        if (state == 1)
          normalPaint.Paintbox.italic = 2; 
        if (state == 2)
          normalPaint.Paintbox.italic = 0; 
      }
    };
  
  ItemListener boldListener = new ItemListener() {
      public void itemStateChanged(ItemEvent itemEvent) {
        int state = itemEvent.getStateChange();
        if (state == 1)
          normalPaint.Paintbox.bold = 1; 
        if (state == 2)
          normalPaint.Paintbox.bold = 0; 
      }
    };
  
  ItemListener blurListener = new ItemListener() {
      public void itemStateChanged(ItemEvent itemEvent) {
        int state = itemEvent.getStateChange();
        if (state == 1) {
          normalPaint.Paintbox;
          PaintCanvas.blur = true;
        } 
        if (state == 2) {
          normalPaint.Paintbox;
          PaintCanvas.blur = false;
        } 
        normalPaint.Paintbox;
        normalPaint.Paintbox;
        if (PaintCanvas.MODE == PaintCanvas.MODE_IMPORT) {
          normalPaint.Paintbox;
          PaintCanvas.recalculate = 1;
        } 
      }
    };
  
  ItemListener sharpListener = new ItemListener() {
      public void itemStateChanged(ItemEvent itemEvent) {
        int state = itemEvent.getStateChange();
        if (state == 1) {
          normalPaint.Paintbox;
          PaintCanvas.sharp = true;
        } 
        if (state == 2) {
          normalPaint.Paintbox;
          PaintCanvas.sharp = false;
        } 
        normalPaint.Paintbox;
        normalPaint.Paintbox;
        if (PaintCanvas.MODE == PaintCanvas.MODE_IMPORT) {
          normalPaint.Paintbox;
          PaintCanvas.recalculate = 1;
        } 
      }
    };
  
  ItemListener greenListener = new ItemListener() {
      public void itemStateChanged(ItemEvent itemEvent) {
        normalPaint.Paintbox.buildGreenPalette();
        normalPaint.Paintbox;
        if (PaintCanvas.green) {
          normalPaint.this.keepinks.setSelected(true);
        } else {
          normalPaint.this.keepinks.setSelected(false);
        } 
        normalPaint.Paintbox;
        normalPaint.Paintbox;
        if (PaintCanvas.MODE == PaintCanvas.MODE_IMPORT) {
          normalPaint.Paintbox;
          PaintCanvas.recalculate = 1;
        } 
      }
    };
  
  ItemListener zoomListener = new ItemListener() {
      public void itemStateChanged(ItemEvent itemEvent) {
        normalPaint.Paintbox.zoomframe.setVisible(normalPaint.zoom.isSelected());
      }
    };
  
  ChangeListener stolistener = new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        if (normalPaint.storeto.getValue().toString().equals("st")) {
          normalPaint.storeto.setValue("19");
          return;
        } 
        if (normalPaint.storeto.getValue().toString().equals("en")) {
          normalPaint.storeto.setValue("00");
          return;
        } 
        normalPaint.Paintbox.choosenImage = Integer.parseInt(normalPaint.storeto.getValue().toString());
      }
    };
  
  ChangeListener zoomlistener = new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        if (normalPaint.zooms.getValue().toString().equals("st")) {
          normalPaint.zooms.setValue("4.00");
          return;
        } 
        if (normalPaint.zooms.getValue().toString().equals("en")) {
          normalPaint.zooms.setValue("0.25");
          return;
        } 
        String got = normalPaint.zooms.getValue().toString();
        if (got.equals("0.125"))
          normalPaint.Paintbox.zoomfactor = 0.25D; 
        if (got.equals("0.25"))
          normalPaint.Paintbox.zoomfactor = 0.25D; 
        if (got.equals("0.50"))
          normalPaint.Paintbox.zoomfactor = 0.5D; 
        if (got.equals("0.75"))
          normalPaint.Paintbox.zoomfactor = 0.75D; 
        if (got.equals("1.00"))
          normalPaint.Paintbox.zoomfactor = 1.0D; 
        if (got.equals("1.25"))
          normalPaint.Paintbox.zoomfactor = 1.25D; 
        if (got.equals("1.50"))
          normalPaint.Paintbox.zoomfactor = 1.5D; 
        if (got.equals("1.75"))
          normalPaint.Paintbox.zoomfactor = 1.75D; 
        if (got.equals("2.00"))
          normalPaint.Paintbox.zoomfactor = 2.0D; 
        if (got.equals("2.25"))
          normalPaint.Paintbox.zoomfactor = 2.25D; 
        if (got.equals("2.50"))
          normalPaint.Paintbox.zoomfactor = 2.5D; 
        if (got.equals("2.75"))
          normalPaint.Paintbox.zoomfactor = 2.75D; 
        if (got.equals("3.00"))
          normalPaint.Paintbox.zoomfactor = 3.0D; 
        if (got.equals("3.25"))
          normalPaint.Paintbox.zoomfactor = 3.25D; 
        if (got.equals("3.50"))
          normalPaint.Paintbox.zoomfactor = 3.5D; 
        if (got.equals("3.75"))
          normalPaint.Paintbox.zoomfactor = 3.75D; 
        if (got.equals("4.00"))
          normalPaint.Paintbox.zoomfactor = 4.0D; 
        if (normalPaint.Paintbox.keep)
          try {
            normalPaint.Paintbox.convertScreen(normalPaint.Paintbox.loadname);
          } catch (Exception r) {
            r.printStackTrace();
          }  
      }
    };
  
  private class DropListener extends DropTargetAdapter {
    private DropListener() {}
    
    public void drop(DropTargetDropEvent dtde) {
      try {
        Transferable t = dtde.getTransferable();
        if (t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
          dtde.acceptDrop(3);
          Object userObject = t.getTransferData(DataFlavor.javaFileListFlavor);
          if (userObject instanceof List) {
            String fileName = ((List<E>)userObject).get(0).toString();
            normalPaint.Paintbox.convertScreen(fileName);
            normalPaint.Paintbox.loadname = fileName;
          } 
          dtde.dropComplete(true);
        } 
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
    }
  }
  
  private static void registerDropListener(ArrayList<DropTarget> list, Container basePanel, DropListener myListener) {
    list.add(new DropTarget(basePanel, myListener));
    Component[] components = basePanel.getComponents();
    for (int i = 0; i < components.length; i++) {
      Component component = components[i];
      if (component instanceof Container) {
        registerDropListener(list, (Container)component, myListener);
      } else {
        list.add(new DropTarget(component, myListener));
      } 
    } 
  }
  
  public void setFilename(String fname) {
    Paintbox.importname = fname;
  }
  
  public void mouseExited(MouseEvent e) {
    if (e.getSource() == proc.image)
      noMouse = true; 
  }
  
  public void mouseEntered(MouseEvent e) {
    if (e.getSource() == proc.image)
      noMouse = false; 
  }
  
  public void Enable() {
    pen0l.setEnabled(true);
    pen1l.setEnabled(true);
    pen2l.setEnabled(true);
    pen3l.setEnabled(true);
    pen4l.setEnabled(true);
    pen5l.setEnabled(true);
    pen6l.setEnabled(true);
    pen7l.setEnabled(true);
    pen8l.setEnabled(true);
    pen9l.setEnabled(true);
    pen10l.setEnabled(true);
    pen11l.setEnabled(true);
    pen12l.setEnabled(true);
    pen13l.setEnabled(true);
    pen14l.setEnabled(true);
    pen15l.setEnabled(true);
  }
  
  public void mouseReleased(MouseEvent event) {
    if (event.getSource() == pen0) {
      Enable();
      pen0l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 0;
    } 
    if (event.getSource() == pen1) {
      Enable();
      pen1l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 1;
    } 
    if (event.getSource() == pen2) {
      Enable();
      pen2l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 2;
    } 
    if (event.getSource() == pen3) {
      Enable();
      pen3l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 3;
    } 
    if (event.getSource() == pen4) {
      Enable();
      pen4l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 4;
    } 
    if (event.getSource() == pen5) {
      Enable();
      pen5l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 5;
    } 
    if (event.getSource() == pen6) {
      Enable();
      pen6l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 6;
    } 
    if (event.getSource() == pen7) {
      Enable();
      pen7l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 7;
    } 
    if (event.getSource() == pen8) {
      Enable();
      pen8l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 8;
    } 
    if (event.getSource() == pen9) {
      Enable();
      pen9l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 9;
    } 
    if (event.getSource() == pen10) {
      Enable();
      pen10l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 10;
    } 
    if (event.getSource() == pen11) {
      Enable();
      pen11l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 11;
    } 
    if (event.getSource() == pen12) {
      Enable();
      pen12l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 12;
    } 
    if (event.getSource() == pen13) {
      Enable();
      pen13l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 13;
    } 
    if (event.getSource() == pen14) {
      Enable();
      pen14l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 14;
    } 
    if (event.getSource() == pen15) {
      Enable();
      pen15l.setEnabled(false);
      ditherLevel.setSelectedIndex(0);
      Paintbox.pen = 15;
    } 
  }
  
  int ink = 0;
  
  InkSelector select;
  
  public void mousePressed(MouseEvent e) {}
  
  public void changeInk(int pen) {
    if (PaintCanvas.plusmode) {
      if (rgbcho == null)
        rgbcho = new RGBSlider(); 
      Paintbox.setPENs();
      rgbcho.setVisible(true);
      rgbcho.PEN(pen, Paintbox.CPCpalette[pen]);
    } else {
      if (this.select == null)
        this.select = new InkSelector(Paintbox); 
      this.select.setVisible(true);
      this.ink = GateArray.getInk(pen);
      this.select.PEN(pen, this.ink);
    } 
  }
  
  public void unlockALL() {
    for (int i = 0; i < Paintbox.lockPEN.length; i++)
      Paintbox.lockPEN[i] = false; 
    pen0l.setIcon(this.pen0B);
    pen1l.setIcon(this.pen1B);
    pen2l.setIcon(this.pen2B);
    pen3l.setIcon(this.pen3B);
    pen4l.setIcon(this.pen4B);
    pen5l.setIcon(this.pen5B);
    pen6l.setIcon(this.pen6B);
    pen7l.setIcon(this.pen7B);
    pen8l.setIcon(this.pen8B);
    pen9l.setIcon(this.pen9B);
    pen10l.setIcon(this.pen10B);
    pen11l.setIcon(this.pen11B);
    pen12l.setIcon(this.pen12B);
    pen13l.setIcon(this.pen13B);
    pen14l.setIcon(this.pen14B);
    pen15l.setIcon(this.pen15B);
  }
  
  public void lockALL() {
    for (int i = 0; i < Paintbox.lockPEN.length; i++)
      Paintbox.lockPEN[i] = true; 
    pen0l.setIcon(this.pen0Bd);
    pen1l.setIcon(this.pen1Bd);
    pen2l.setIcon(this.pen2Bd);
    pen3l.setIcon(this.pen3Bd);
    pen4l.setIcon(this.pen4Bd);
    pen5l.setIcon(this.pen5Bd);
    pen6l.setIcon(this.pen6Bd);
    pen7l.setIcon(this.pen7Bd);
    pen8l.setIcon(this.pen8Bd);
    pen9l.setIcon(this.pen9Bd);
    pen10l.setIcon(this.pen10Bd);
    pen11l.setIcon(this.pen11Bd);
    pen12l.setIcon(this.pen12Bd);
    pen13l.setIcon(this.pen13Bd);
    pen14l.setIcon(this.pen14Bd);
    pen15l.setIcon(this.pen15Bd);
  }
  
  public void mouseClicked(MouseEvent e) {
    if (e.getSource() == proc.image) {
      int x = e.getX();
      int y = e.getY();
      try {
        if (PaintCanvas.plusmode) {
          Paintbox.setPlusINK(Paintbox.showImage.getRGB(x, y));
        } else {
          Paintbox.setINK(Paintbox.showImage.getRGB(x, y));
        } 
      } catch (Exception exception) {}
      return;
    } 
    if (e.getClickCount() == 2 || e.getButton() != 1) {
      if (e.getSource() == pen0)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[0] = !Paintbox.lockPEN[0];
          System.out.println("PEN 0 locked:" + Paintbox.lockPEN[0]);
          if (Paintbox.lockPEN[0]) {
            pen0l.setIcon(this.pen0Bd);
          } else {
            pen0l.setIcon(this.pen0B);
          } 
        } else {
          changeInk(0);
        }  
      if (e.getSource() == pen1)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[1] = !Paintbox.lockPEN[1];
          if (Paintbox.lockPEN[1]) {
            pen1l.setIcon(this.pen1Bd);
          } else {
            pen1l.setIcon(this.pen1B);
          } 
        } else {
          changeInk(1);
        }  
      if (e.getSource() == pen2)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[2] = !Paintbox.lockPEN[2];
          if (Paintbox.lockPEN[2]) {
            pen2l.setIcon(this.pen2Bd);
          } else {
            pen2l.setIcon(this.pen2B);
          } 
        } else {
          changeInk(2);
        }  
      if (e.getSource() == pen3)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[3] = !Paintbox.lockPEN[3];
          if (Paintbox.lockPEN[3]) {
            pen3l.setIcon(this.pen3Bd);
          } else {
            pen3l.setIcon(this.pen3B);
          } 
        } else {
          changeInk(3);
        }  
      if (e.getSource() == pen4)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[4] = !Paintbox.lockPEN[4];
          if (Paintbox.lockPEN[4]) {
            pen4l.setIcon(this.pen4Bd);
          } else {
            pen4l.setIcon(this.pen4B);
          } 
        } else {
          changeInk(4);
        }  
      if (e.getSource() == pen5)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[5] = !Paintbox.lockPEN[5];
          if (Paintbox.lockPEN[5]) {
            pen5l.setIcon(this.pen5Bd);
          } else {
            pen5l.setIcon(this.pen5B);
          } 
        } else {
          changeInk(5);
        }  
      if (e.getSource() == pen6)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[6] = !Paintbox.lockPEN[6];
          if (Paintbox.lockPEN[6]) {
            pen6l.setIcon(this.pen6Bd);
          } else {
            pen6l.setIcon(this.pen6B);
          } 
        } else {
          changeInk(6);
        }  
      if (e.getSource() == pen7)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[7] = !Paintbox.lockPEN[7];
          if (Paintbox.lockPEN[7]) {
            pen7l.setIcon(this.pen7Bd);
          } else {
            pen7l.setIcon(this.pen7B);
          } 
        } else {
          changeInk(7);
        }  
      if (e.getSource() == pen8)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[8] = !Paintbox.lockPEN[8];
          if (Paintbox.lockPEN[8]) {
            pen8l.setIcon(this.pen8Bd);
          } else {
            pen8l.setIcon(this.pen8B);
          } 
        } else {
          changeInk(8);
        }  
      if (e.getSource() == pen9)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[9] = !Paintbox.lockPEN[9];
          if (Paintbox.lockPEN[9]) {
            pen9l.setIcon(this.pen9Bd);
          } else {
            pen9l.setIcon(this.pen9B);
          } 
        } else {
          changeInk(9);
        }  
      if (e.getSource() == pen10)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[10] = !Paintbox.lockPEN[10];
          if (Paintbox.lockPEN[10]) {
            pen10l.setIcon(this.pen10Bd);
          } else {
            pen10l.setIcon(this.pen10B);
          } 
        } else {
          changeInk(10);
        }  
      if (e.getSource() == pen11)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[11] = !Paintbox.lockPEN[11];
          if (Paintbox.lockPEN[11]) {
            pen11l.setIcon(this.pen11Bd);
          } else {
            pen11l.setIcon(this.pen11B);
          } 
        } else {
          changeInk(11);
        }  
      if (e.getSource() == pen12)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[12] = !Paintbox.lockPEN[12];
          if (Paintbox.lockPEN[12]) {
            pen12l.setIcon(this.pen12Bd);
          } else {
            pen12l.setIcon(this.pen12B);
          } 
        } else {
          changeInk(12);
        }  
      if (e.getSource() == pen13)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[13] = !Paintbox.lockPEN[13];
          if (Paintbox.lockPEN[13]) {
            pen13l.setIcon(this.pen13Bd);
          } else {
            pen13l.setIcon(this.pen13B);
          } 
        } else {
          changeInk(13);
        }  
      if (e.getSource() == pen14)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[14] = !Paintbox.lockPEN[14];
          if (Paintbox.lockPEN[14]) {
            pen14l.setIcon(this.pen14Bd);
          } else {
            pen14l.setIcon(this.pen14B);
          } 
        } else {
          changeInk(14);
        }  
      if (e.getSource() == pen15)
        if (e.getButton() == 1) {
          Paintbox.lockPEN[15] = !Paintbox.lockPEN[15];
          if (Paintbox.lockPEN[15]) {
            pen15l.setIcon(this.pen15Bd);
          } else {
            pen15l.setIcon(this.pen15B);
          } 
        } else {
          changeInk(15);
        }  
    } 
  }
  
  public void putFlipA() {
    Paintbox.putFlipA();
  }
  
  public void putFlipB() {
    Paintbox.putFlipB();
  }
  
  public void getFlipA() {
    Paintbox.getFlipA();
  }
  
  public void getFlipB() {
    Paintbox.getFlipB();
  }
  
  public void deFlip() {
    Paintbox.deFlip();
  }
  
  public void makeMovie() {
    Paintbox.makeMovie();
  }
  
  public void resetMovie() {
    CPC.moviecount = 0;
  }
  
  public void renderMovie() {
    Paintbox.makemovie = !Paintbox.makemovie;
    if (Paintbox.makemovie)
      Paintbox.initRecord(); 
  }
  
  public void storeMovie() {
    Paintbox.storeMovie();
  }
  
  public void restoreMovie() {
    Paintbox.restoreMovie();
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\paint\normalPaint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */