package jemu.ui.paint;

import java.io.File;
import javax.swing.filechooser.FileFilter;

public class ImageFilter extends FileFilter {
  public boolean accept(File f) {
    if (f.isDirectory())
      return true; 
    String extension = Utils.getExtension(f);
    if (extension != null) {
      if (extension
        .equals("gif") || extension
        .equals("jpeg") || extension
        .equals("jpg") || extension
        .equals("scr") || extension
        .equals("bmp") || extension
        .equals("tga") || extension
        .equals("pcx") || extension
        .equals("png") || extension
        .equals("iff") || extension
        .equals("ilbm") || extension
        .equals("sna"))
        return true; 
      return false;
    } 
    return false;
  }
  
  public String getDescription() {
    return "Supported formats";
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\paint\ImageFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */