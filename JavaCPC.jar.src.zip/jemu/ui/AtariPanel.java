package jemu.ui;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Panel;
import javax.swing.JFrame;

public class AtariPanel extends JFrame {
  Atari800 emulator;
  
  public Canvas emu(final String[] args) {
    this.emulator = new Atari800(new Panel());
    Thread runner = new Thread() {
        public void run() {
          AtariPanel.this.emulator.main2(args);
        }
      };
    runner.start();
    while (this.emulator.canvas == null) {
      try {
        Thread.sleep(10L);
      } catch (Exception exception) {}
    } 
    this.emulator.canvas.setPreferredSize(new Dimension(672, 480));
    return this.emulator.canvas;
  }
  
  public AtariPanel(String[] args) {
    initComponents();
    add(emu(args), "Center");
    pack();
  }
  
  private void initComponents() {
    setDefaultCloseOperation(3);
    pack();
  }
  
  public static void main(final String[] args) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new AtariPanel(args)).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\AtariPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */