package jemu.ui;

import java.awt.Color;
import javax.swing.JProgressBar;
import jemu.settings.Palette;

public class DesktopHelper {
  String info = "|SHOW - open printer console\n|HIDE - hide printer console\n|ONLINE - sets printer online\n|OFFLINE - sets printer offline\n|CLEAR - clears printer console content\n|BIGGER - increases fontsize of printer\n|SMALLER - decreases fontsize\n|SIZE,[size] - sets fontsize in pt\n|FONT1 - |FONT9 - sets printerfont\n|QUIT - quits JavaCPC emulator\n|GREEN - emulates greenmonitor\n|GRAY / |GREY - emulates graymonitor\n|COLOR / |COLOUR - colourmonitor\n|32INKS - emulates JavaCPC specialinks\n|SCREENSHOT - Saves a screenshot\n|SAVEDSK - Lets the user save actual DSK in DF0\n|MAKEDSK - creates a DATA formatted DSK\n|SCANLINES - enables scanlines\n|SCANLINESOFF - disables scanlines\n|INFO / |HELP - this info";
  
  public static void updatePalette(int index) {
    Color col = new Color(Palette.getRGB(index));
    switch (index) {
      case 0:
        Desktop.pan1.setBackground(col);
        break;
      case 1:
        Desktop.pan2.setBackground(col);
        break;
      case 2:
        Desktop.pan3.setBackground(col);
        break;
      case 3:
        Desktop.pan4.setBackground(col);
        break;
      case 4:
        Desktop.pan5.setBackground(col);
        break;
      case 5:
        Desktop.pan6.setBackground(col);
        break;
      case 6:
        Desktop.pan7.setBackground(col);
        break;
      case 7:
        Desktop.pan8.setBackground(col);
        break;
      case 8:
        Desktop.pan9.setBackground(col);
        break;
      case 9:
        Desktop.pan10.setBackground(col);
        break;
      case 10:
        Desktop.pan11.setBackground(col);
        break;
      case 11:
        Desktop.pan12.setBackground(col);
        break;
      case 12:
        Desktop.pan13.setBackground(col);
        break;
      case 13:
        Desktop.pan14.setBackground(col);
        break;
      case 14:
        Desktop.pan15.setBackground(col);
        break;
      case 15:
        Desktop.pan16.setBackground(col);
        break;
      case 16:
        Desktop.pan17.setBackground(col);
        break;
      case 17:
        Desktop.pan18.setBackground(col);
        break;
      case 18:
        Desktop.pan19.setBackground(col);
        break;
      case 19:
        Desktop.pan20.setBackground(col);
        break;
      case 20:
        Desktop.pan21.setBackground(col);
        break;
      case 21:
        Desktop.pan22.setBackground(col);
        break;
      case 22:
        Desktop.pan23.setBackground(col);
        break;
      case 23:
        Desktop.pan24.setBackground(col);
        break;
      case 24:
        Desktop.pan25.setBackground(col);
        break;
      case 25:
        Desktop.pan26.setBackground(col);
        break;
      case 26:
        Desktop.pan27.setBackground(col);
        break;
      case 27:
        Desktop.pan28.setBackground(col);
        break;
      case 28:
        Desktop.pan29.setBackground(col);
        break;
      case 29:
        Desktop.pan30.setBackground(col);
        break;
      case 30:
        Desktop.pan31.setBackground(col);
        break;
      case 31:
        Desktop.pan32.setBackground(col);
        break;
    } 
    if (Desktop.selectedInk == index) {
      Desktop.selpan.setBackground(new Color(Palette.getRGB(Desktop.selectedInk)));
      Desktop.fieldRed.setText((new Color(Palette.getRGB(Desktop.selectedInk))).getRed() + "");
      Desktop.fieldGreen.setText((new Color(Palette.getRGB(Desktop.selectedInk))).getGreen() + "");
      Desktop.fieldBlue.setText((new Color(Palette.getRGB(Desktop.selectedInk))).getBlue() + "");
      Desktop.jSlider3.setValue((new Color(Palette.getRGB(Desktop.selectedInk))).getRed());
      Desktop.jSlider4.setValue((new Color(Palette.getRGB(Desktop.selectedInk))).getGreen());
      Desktop.jSlider5.setValue((new Color(Palette.getRGB(Desktop.selectedInk))).getBlue());
    } 
  }
  
  public String[] syntheticaStyles = new String[] { 
      "de.javasoft.plaf.synthetica.SyntheticaStandardLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaAluOxideLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaBlackEyeLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaBlackMoonLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaBlackStarLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaBlueIceLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaBlueLightLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaBlueMoonLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaBlueSteelLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaClassyLookAndFeel", 
      "de.javasoft.plaf.synthetica.SyntheticaGreenDreamLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaMauveMetallicLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaOrangeMetallicLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaSilverMoonLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaSimple2DLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaSkyMetallicLookAndFeel", "de.javasoft.plaf.synthetica.SyntheticaWhiteVisionLookAndFeel" };
  
  public int mem = 0;
  
  public int coname = 0;
  
  public int look;
  
  public boolean synthetica = true;
  
  public String[] looks = new String[] { 
      "Metal", "Nimbus", "System", "Motif", "JavaCPC", "DarkGrey", "Snow", "GX4000", "DarkTobaco", "Kunststoff", 
      "Pgs", "Acryl", "Aero", "Aluminium", "Bernstein", "Fast", "HiFi", "Luna", "McWin", "Mint", 
      "Noire", "Texture", "Synthetica", "AluOxide", "BlackEye", "BlackMoon", "BlackStar", "BlueIce", "BlueLight", "BlueMoon", 
      "BlueSteel", "Classy", "GreenDream", "MauveMetallic", "OrangeMetallic", "SilverMoon", "Simple2D", "SkyMetallic", "WhiteVision", "Own Style" };
  
  public static JProgressBar blast;
  
  public static JProgressBar audio;
  
  public String[] systems = new String[] { 
      "Your Config", "CPC 464", "CPC 464 (Amsdos)", "CPC 664", "CPC 6128", "KC Compact", "KC Compact (DOS)", "Future OS", "Future OS (Autoboot)", "SymbOS", 
      "SymbOS (Autoboot)" };
  
  public String[] LowerROMs = new String[] { "none", "OS464.ROM", "OS664.ROM", "OS6128.ROM", "KCCOS.ROM", "OS-C64.ROM", "*" };
  
  public Scroller scroll;
  
  public String[] UpperROMs = new String[] { 
      "none", "BASIC1-0.ROM", "BASIC664.ROM", "BASIC1-1.ROM", "KCCBAS.ROM", "AMSDOS.ROM", "PARADOS.ROM", "VaraDOS.ROM", "DEPROMA.ROM", "VORTEX10.ROM", 
      "VORTEX20.ROM", "XDDOS210.ROM", "ART0.ROM", "ART1.ROM", "ART2.ROM", "DKSPEECH.ROM", "MAXAM115.ROM", "sym-romAboot.ROM", "sym-romA.ROM", "sym-romB.ROM", 
      "sym-romC.ROM", "sym-romD.ROM", "Stk12-1.ROM", "Stk12-2.ROM", "Stk12Gen.ROM", "FOSC-E-A.ROM", "FOSC-E-B.ROM", "FOSC-E-C.ROM", "FOSC-E-D.ROM", "ROManager.ROM", 
      "TOOL-ROM-ENG.ROM", "Wallpaper_1.ROM", "ROMPKP1.ROM", "ROMPKP2.ROM", "STK1.ROM", "STK2.ROM", "LOCKSMIT.ROM", "RDOS-EXT.ROM", "BASIC-C64.ROM", "*" };
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jem\\ui\DesktopHelper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */