package jemu.core;

import java.awt.EventQueue;
import java.io.File;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class Util {
  public static final int JVM_UNDEFINED = 0;
  
  public static final int JVM_MS = 1;
  
  public static final int JVM_NETSCAPE = 2;
  
  public static final int JVM_UNKNOWN = 3;
  
  public static int jvmType = 0;
  
  private static Object[] jvmData;
  
  private static Method assertPermission;
  
  private static EventQueue systemEventQueue = null;
  
  protected static final String HEX_CHARS = "0123456789ABCDEF";
  
  static String str;
  
  public static boolean equals(Object o1, Object o2) {
    boolean result;
    if (o1 == null) {
      result = (o2 == null);
    } else {
      result = o1.equals(o2);
    } 
    return result;
  }
  
  public static int[] arrayInsert(int[] source, int start, int count, int value) {
    int[] result;
    if (count <= 0) {
      result = new int[source.length];
      System.arraycopy(source, 0, result, 0, source.length);
    } else {
      result = new int[source.length + count];
      if (start > 0)
        System.arraycopy(source, 0, result, 0, start); 
      int rem = source.length - start;
      if (rem > 0)
        System.arraycopy(source, start, result, start + count, rem); 
      for (int i = start; i < start + count; i++)
        result[i] = value; 
    } 
    return result;
  }
  
  public static int[] arrayDelete(int[] source, int start, int count) {
    int[] result;
    if (count <= 0) {
      result = new int[source.length];
      System.arraycopy(source, 0, result, 0, source.length);
    } else {
      result = new int[source.length - count];
      if (start > 0)
        System.arraycopy(source, 0, result, 0, start); 
      if (start + count < source.length)
        System.arraycopy(source, start + count, result, start, source.length - start + count); 
    } 
    return result;
  }
  
  public static int[] ensureArraySize(int[] source, int size, int value) {
    int[] result = source;
    if (result.length < size) {
      result = arrayInsert(result, result.length, size - result.length, value);
    } else if (result.length > size) {
      result = arrayDelete(result, size, result.length - size);
    } 
    return result;
  }
  
  public static double[] arrayInsert(double[] source, int start, int count, double value) {
    double[] result;
    if (count <= 0) {
      result = new double[source.length];
      System.arraycopy(source, 0, result, 0, source.length);
    } else {
      result = new double[source.length + count];
      if (start > 0)
        System.arraycopy(source, 0, result, 0, start); 
      int rem = source.length - start;
      if (rem > 0)
        System.arraycopy(source, start, result, start + count, rem); 
      for (int i = start; i < start + count; i++)
        result[i] = value; 
    } 
    return result;
  }
  
  public static double[] arrayDelete(double[] source, int start, int count) {
    double[] result;
    if (count <= 0) {
      result = new double[source.length];
      System.arraycopy(source, 0, result, 0, source.length);
    } else {
      result = new double[source.length - count];
      if (start > 0)
        System.arraycopy(source, 0, result, 0, start); 
      if (start + count < source.length)
        System.arraycopy(source, start + count, result, start, source.length - start + count); 
    } 
    return result;
  }
  
  public static double[] ensureArraySize(double[] source, int size, double value) {
    double[] result = source;
    if (result.length < size) {
      result = arrayInsert(result, result.length, size - result.length, value);
    } else if (result.length > size) {
      result = arrayDelete(result, size, result.length - size);
    } 
    return result;
  }
  
  public static Object[] arrayInsert(Object[] source, int start, int count, Object value) {
    Object[] result = source;
    if (count > 0) {
      result = (Object[])Array.newInstance(source.getClass().getComponentType(), source.length + count);
      if (start > 0)
        System.arraycopy(source, 0, result, 0, start); 
      int rem = source.length - start;
      if (rem > 0)
        System.arraycopy(source, start, result, start + count, rem); 
      for (int i = start; i < start + count; i++)
        result[i] = value; 
    } 
    return result;
  }
  
  public static Object[] arrayDelete(Object[] source, int start, int count) {
    Object[] result;
    if (count <= 0) {
      result = new Object[source.length];
      System.arraycopy(source, 0, result, 0, source.length);
    } else {
      result = new Object[source.length - count];
      if (start > 0)
        System.arraycopy(source, 0, result, 0, start); 
      if (start + count < source.length)
        System.arraycopy(source, start + count, result, start, source.length - start + count); 
    } 
    return result;
  }
  
  public static Object[] arrayDeleteElement(Object[] source, Object element) {
    for (int i = 0; i < source.length; i++) {
      if (source[i] == element)
        return arrayDelete(source, i, 1); 
    } 
    return source;
  }
  
  public static Object[] ensureArraySize(Object[] source, int size, Object value) {
    Object[] result = source;
    if (result.length < size) {
      result = arrayInsert(result, result.length, size - result.length, value);
    } else if (result.length > size) {
      result = arrayDelete(result, size, result.length - size);
    } 
    return result;
  }
  
  public static final Object secureMethod(Class cl, String methodName, Class[] paramTypes, Object instance, Object[] params) throws Exception {
    return secureExecute(cl.getMethod(methodName, paramTypes), instance, params);
  }
  
  public static final Object secureConstructor(Class cl, Class[] paramTypes, Object[] params) throws Exception {
    return secureExecute(cl.getConstructor(paramTypes), null, params);
  }
  
  private static final Object secureExecute(Object routine, Object instance, Object[] params) throws Exception {
    int i;
    switch (determineJVM()) {
      case 1:
        for (i = 0; i < jvmData.length; i++) {
          assertPermission.invoke(null, new Object[] { jvmData[i] });
        } 
        break;
    } 
    try {
      if (routine instanceof Method)
        return ((Method)routine).invoke(instance, params); 
      return ((Constructor)routine).newInstance(params);
    } catch (InvocationTargetException invocationTargetException) {
      System.out.println("InvocationTarget Exception in secureExecute");
      Throwable t = invocationTargetException.getTargetException();
      if (t instanceof Exception)
        throw (Exception)t; 
      throw invocationTargetException;
    } 
  }
  
  public static int determineJVM() {
    if (jvmType == 0) {
      try {
        if (Class.forName("com.ms.security.PermissionUtils") != null) {
          jvmData = new Object[4];
          Class<?> pi = Class.forName("com.ms.security.PermissionID");
          jvmData[0] = pi.getField("SYSTEM").get(null);
          jvmData[1] = pi.getField("FILEIO").get(null);
          jvmData[2] = pi.getField("UI").get(null);
          jvmData[3] = pi.getField("PROPERTY").get(null);
          Class<?> pe = Class.forName("com.ms.security.PolicyEngine");
          assertPermission = pe.getMethod("assertPermission", new Class[] { pi });
          jvmType = 1;
        } 
      } catch (Throwable t) {
        if (!(t instanceof ClassNotFoundException))
          t.printStackTrace(); 
      } 
      if (jvmType == 0)
        try {
          if (Class.forName("netscape.security.AppletSecurity") != null)
            jvmType = 2; 
        } catch (Throwable t) {
          if (!(t instanceof ClassNotFoundException))
            t.printStackTrace(); 
        }  
      if (jvmType == 0)
        jvmType = 3; 
    } 
    return jvmType;
  }
  
  public static int[] sort(int[] source, boolean copy) {
    int[] result;
    if (copy) {
      result = new int[source.length];
      System.arraycopy(source, 0, result, 0, source.length);
    } else {
      result = source;
    } 
    for (int i = 0; i < result.length - 1; i++) {
      for (int j = i + 1; j < result.length; j++) {
        if (result[i] > result[j])
          swap(result, i, j); 
      } 
    } 
    return result;
  }
  
  public static void swap(int[] source, int index1, int index2) {
    int temp = source[index1];
    source[index1] = source[index2];
    source[index2] = temp;
  }
  
  public static String fileNameToURLString(String filename) throws Exception {
    String path = ((File)secureConstructor(File.class, new Class[] { String.class }, new Object[] { filename })).getAbsolutePath();
    if (File.separatorChar != '/')
      path = path.replace(File.separatorChar, '/'); 
    if (!path.startsWith("/"))
      path = "/" + path; 
    return "file:" + path;
  }
  
  public static Vector arrayToVector(Object[] items) {
    Vector<Object> result = new Vector(items.length);
    for (int i = 0; i < items.length; i++)
      result.addElement(items[i]); 
    return result;
  }
  
  public static Hashtable arraysToHashtable(Object[] keys, Object[] items) {
    Hashtable<Object, Object> result = new Hashtable<>(keys.length);
    for (int i = 0; i < keys.length; i++)
      result.put(keys[i], items[i]); 
    return result;
  }
  
  public static int compare(Object o1, Object o2) {
    return compare(o1, o2, true);
  }
  
  public static int compare(Object o1, Object o2, boolean caseSensitive) {
    int result;
    if (o1 == null) {
      result = (o2 == null) ? 0 : -1;
    } else if (o2 == null) {
      result = 1;
    } else if (o1.equals(o2)) {
      result = 0;
    } else if (o1 instanceof Number && o2 instanceof Number) {
      double d1 = ((Number)o1).doubleValue();
      double d2 = ((Number)o2).doubleValue();
      if (d1 == d2) {
        result = 0;
      } else {
        result = (d1 > d2) ? 1 : -1;
      } 
    } else if (caseSensitive) {
      result = o1.toString().compareTo(o2.toString());
    } else {
      result = o1.toString().toUpperCase().compareTo(o2
          .toString().toUpperCase());
    } 
    return result;
  }
  
  public static void sort(Vector v) {
    sort(v, true, false);
  }
  
  public static void sort(Vector v, boolean ascending, boolean caseSensitive) {
    int mul = ascending ? 1 : -1;
    for (int i = 0; i < v.size() - 1; i++) {
      for (int j = i + 1; j < v.size(); j++) {
        if (mul * compare(v.elementAt(i), v.elementAt(j), caseSensitive) > 0)
          swap(v, i, j); 
      } 
    } 
  }
  
  public static void sort(Vector v, boolean ascending, Method method, boolean caseSensitive) throws InvocationTargetException, IllegalAccessException {
    Object[] noParms = new Object[0];
    int mul = ascending ? 1 : -1;
    for (int i = 0; i < v.size() - 1; i++) {
      for (int j = i + 1; j < v.size(); j++) {
        if (mul * compare(method.invoke(v.elementAt(i), noParms), method
            .invoke(v.elementAt(j), noParms), caseSensitive) > 0)
          swap(v, i, j); 
      } 
    } 
  }
  
  public static Vector enumerationToVector(Enumeration en) {
    Vector result = new Vector();
    while (en.hasMoreElements())
      result.addElement(en.nextElement()); 
    return result;
  }
  
  public static void swap(Vector<Object> v, int index1, int index2) {
    Object o1 = v.elementAt(index1);
    Object o2 = v.elementAt(index2);
    v.setElementAt(o2, index1);
    v.setElementAt(o1, index2);
  }
  
  public static String nullString(String value) {
    return (value == null) ? "" : value;
  }
  
  public static void vectorAddVector(Vector source, Vector elements) {
    if (elements != null) {
      int count = elements.size();
      for (int i = 0; i < count; i++)
        source.addElement(elements.elementAt(i)); 
    } 
  }
  
  public static String asString(Object value) {
    return (value == null) ? null : value.toString();
  }
  
  public static boolean getBoolean(Object source) {
    return getBoolean(source, false);
  }
  
  public static boolean getBoolean(Object source, boolean defValue) {
    if (source instanceof String) {
      source = ((String)source).toUpperCase();
      return ("TRUE".equals(source) || "T".equals(source) || "YES".equals(source) || "Y".equals(source) || "1"
        .equals(source));
    } 
    if (source instanceof Boolean)
      return ((Boolean)source).booleanValue(); 
    return defValue;
  }
  
  public static char getChar(Object source) {
    return getChar(source, false);
  }
  
  public static char getChar(Object source, char defValue) {
    if (source instanceof String) {
      String str = (String)source;
      return (str.length() == 0) ? defValue : str.charAt(0);
    } 
    if (source instanceof Character)
      return ((Character)source).charValue(); 
    return defValue;
  }
  
  public static int getInt(Object source) {
    return getInt(source, 0);
  }
  
  public static int getInt(Object source, int defValue) {
    if (source instanceof String) {
      String str = (String)source;
      try {
        if (str.length() > 0 && str.charAt(0) == '#')
          return hexValue(str.substring(1)); 
        return Integer.parseInt(str);
      } catch (Exception exception) {}
    } else if (source instanceof Number) {
      return ((Number)source).intValue();
    } 
    return defValue;
  }
  
  public static double getDouble(Object source) {
    return getDouble(source, 0.0D);
  }
  
  public static double getDouble(Object source, double defValue) {
    if (source instanceof String)
      try {
        return Double.valueOf((String)source).doubleValue();
      } catch (Exception e) {
        return defValue;
      }  
    if (source instanceof Number)
      return ((Number)source).doubleValue(); 
    return defValue;
  }
  
  public static long getLong(Object source) {
    return getLong(source, 0L);
  }
  
  public static long getLong(Object source, long defValue) {
    if (source instanceof String) {
      try {
        return Long.parseLong((String)source);
      } catch (Exception exception) {}
    } else if (source instanceof Number) {
      return ((Number)source).longValue();
    } 
    return defValue;
  }
  
  public static byte hexValue(char value) {
    if (value >= 'a')
      return (byte)(value - 97 + 10); 
    if (value > '9')
      return (byte)(value - 65 + 10); 
    return (byte)(value - 48);
  }
  
  public static int hexValue(String source) {
    int result = 0;
    source = source.trim();
    for (int i = 0; i < source.length(); i++) {
      byte val = hexValue(source.charAt(i));
      if (val < 0 || val > 15) {
        System.err.println("Illegal hex character in " + source);
        return 0;
      } 
      result = (result << 4) + val;
    } 
    return result;
  }
  
  public static void mkdirs(String path) throws Exception {
    path = path.replace('\\', '/');
    if (!path.endsWith("/"))
      path = path + "/"; 
    int index = 0;
    while ((index = path.indexOf('/', index)) != -1) {
      File file = new File(path.substring(0, ++index));
      boolean exists = ((Boolean)secureMethod(File.class, "exists", new Class[0], file, new Object[0])).booleanValue();
      if (!exists)
        secureMethod(File.class, "mkdir", new Class[0], file, new Object[0]); 
      boolean directory = ((Boolean)secureMethod(File.class, "isDirectory", new Class[0], file, new Object[0])).booleanValue();
      if (!directory)
        throw new Exception("File \"" + file.getPath() + "\" is not a directory"); 
    } 
  }
  
  public static Class findClass(String packageName, String className) {
    Class result;
    if (className.indexOf('.') == -1)
      className = packageName + "." + className; 
    try {
      result = Class.forName(className);
    } catch (Exception e) {
      result = null;
    } 
    return result;
  }
  
  public static Object getClassInstance(String packageName, String className) throws Exception {
    Class cl = findClass(packageName, className);
    return (cl != null) ? cl.newInstance() : null;
  }
  
  public static String dumpBytes(byte[] buffer) {
    return dumpBytes(buffer, 0, buffer.length, true, true, true);
  }
  
  public static String dumpBytes(byte[] buffer, int start) {
    return dumpBytes(buffer, 0, buffer.length, true, true, true, start);
  }
  
  public static String dumpBytes(int[] buffer) {
    return dumpBytes(buffer, 0, buffer.length, true, true, true);
  }
  
  public static String dumpBytes(byte[] buffer, int offset, int length, boolean showAddr, boolean showChars, boolean lineFeed) {
    length += offset;
    StringBuilder buff = new StringBuilder(80 * (length + 15) / 16);
    for (int i = offset; i < length; i += 16) {
      String end = "; ";
      if (showAddr)
        buff.append(hex(i)).append(": "); 
      int j = 0;
      for (; j < 16 && i + j < length; j++) {
        byte data = buffer[i + j];
        buff.append(hex(data)).append(" ");
        end = end + ((data >= 32 && data < Byte.MAX_VALUE) ? (char)data : 46);
      } 
      for (; j < 16; j++)
        buff.append("   "); 
      if (showChars)
        buff.append(end); 
      if (lineFeed)
        buff.append("\r\n"); 
    } 
    return buff.toString();
  }
  
  public static String dumpBytes(byte[] buffer, int offset, int length, boolean showAddr, boolean showChars, boolean lineFeed, int start) {
    length += offset;
    StringBuilder buff = new StringBuilder(80 * (length + 15) / 16);
    for (int i = offset; i < length; i += 16) {
      String end = "; ";
      if (showAddr)
        buff.append(hex(i + start)).append(": "); 
      int j = 0;
      for (; j < 16 && i + j < length; j++) {
        byte data = buffer[i + j];
        buff.append(hex(data)).append(" ");
        end = end + ((data >= 32 && data < Byte.MAX_VALUE) ? (char)data : 46);
      } 
      for (; j < 16; j++)
        buff.append("   "); 
      if (showChars)
        buff.append(end); 
      if (lineFeed)
        buff.append("\n"); 
    } 
    return buff.toString();
  }
  
  public static String dumpBytes(int[] buffer, int offset, int length, boolean showAddr, boolean showChars, boolean lineFeed) {
    length += offset;
    StringBuilder buff = new StringBuilder(80 * (length + 15) / 16);
    for (int i = offset; i < length; i += 16) {
      String end = "; ";
      if (showAddr)
        buff.append(hex(i)).append(": "); 
      int j = 0;
      for (; j < 16 && i + j < length; j++) {
        byte data = (byte)buffer[i + j];
        buff.append(hex(data)).append(" ");
        end = end + ((data >= 32 && data < Byte.MAX_VALUE) ? (char)data : 46);
      } 
      for (; j < 16; j++)
        buff.append("   "); 
      if (showChars)
        buff.append(end); 
      if (lineFeed)
        buff.append("\n"); 
    } 
    return buff.toString();
  }
  
  public static String hex(byte value) {
    str = "XY";
    str = str.replace('X', "0123456789ABCDEF".charAt((value & 0xF0) >> 4));
    str = str.replace('Y', "0123456789ABCDEF".charAt(value & 0xF));
    return str;
  }
  
  public static String hex(short value) {
    return hex((byte)(value >> 8)) + hex((byte)value);
  }
  
  public static String hex(int value) {
    return hex((short)(value >> 16)) + hex((short)value);
  }
  
  public static int random(int n) {
    double decimal = Math.random();
    int value = (int)Math.round(decimal * n);
    return value;
  }
  
  public long readPackedULong(byte[] source, int offset) {
    long result = 0L;
    int shift = 0;
    while (true) {
      int val = source[offset++] & 0xFF;
      result |= (val & 0x7F) << shift;
      shift += 7;
      if ((val & 0x80) == 0)
        return result; 
    } 
  }
  
  public int readPackedUInt(byte[] source, int offset) {
    return (int)readPackedULong(source, offset);
  }
  
  public int skipPackedNumber(byte[] source, int offset) {
    while ((source[offset++] & 0x80) != 0);
    return offset;
  }
  
  public long readPackedLong(byte[] source, int offset) {
    int val = source[offset++];
    long result = (val & 0x3F);
    boolean sign = ((val & 0x40) != 0);
    int shift = 6;
    while ((val & 0x80) != 0) {
      val = source[offset++];
      result |= (val & 0x7F) << shift;
      shift += 7;
    } 
    return sign ? -result : result;
  }
  
  public int readPackedInt(byte[] source, int offset) {
    return (int)readPackedLong(source, offset);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\Util.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */