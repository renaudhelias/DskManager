package jemu.core.renderer;

import jemu.core.device.Device;
import jemu.ui.Display;

public class Renderer extends Device {
  protected Display display;
  
  protected int[] pixels;
  
  public Renderer(String type) {
    super(type);
  }
  
  public void setDisplay(Display value) {
    this.display = value;
    this.pixels = this.display.getPixels();
  }
  
  public Display getDisplay() {
    return this.display;
  }
  
  public int[] getPixels() {
    return this.pixels;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\renderer\Renderer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */