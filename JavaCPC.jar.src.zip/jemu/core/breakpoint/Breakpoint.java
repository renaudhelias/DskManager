package jemu.core.breakpoint;

import jemu.core.cpu.ProgramCounterObserverImpl;

public abstract class Breakpoint extends ProgramCounterObserverImpl {
  public Breakpoint(int address) {
    super(address);
  }
  
  public Breakpoint(int cycles, boolean put) {
    super(cycles, put);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\breakpoint\Breakpoint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */