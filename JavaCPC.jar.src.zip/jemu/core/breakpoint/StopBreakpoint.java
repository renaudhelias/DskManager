package jemu.core.breakpoint;

import jemu.core.Util;
import jemu.core.cpu.Processor;
import jemu.core.samples.Samples;
import jemu.ui.Debugger;
import jemu.ui.Desktop;
import jemu.ui.JEMU;

public class StopBreakpoint extends ProcessorBreakpoint {
  private int cycles = 0;
  
  public void update(int address) {
    if (address == getAddress()) {
      if (this.cycles >= getCycles()) {
        this.cycles = -1;
        getProcessor().stop();
        JEMU.debugger.getDebuggerComputer().stop();
        Debugger.setDisass(address);
        Debugger.setEditor(address);
        System.out.println("StopBreakpoint at address &" + Util.hex(address));
        Samples.BREAK.play();
        if (JEMU.iframe == null) {
          JEMU.debugframe.setVisible(true);
        } else {
          Desktop.debug.setVisible(true);
        } 
      } 
      this.cycles++;
    } 
  }
  
  public StopBreakpoint(Processor processor, int address) {
    super(processor, address);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\breakpoint\StopBreakpoint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */