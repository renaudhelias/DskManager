package jemu.core.breakpoint;

import jemu.core.cpu.Processor;

public abstract class ProcessorBreakpoint extends Breakpoint {
  private Processor processor;
  
  public Processor getProcessor() {
    return this.processor;
  }
  
  public void setProcessor(Processor processor) {
    this.processor = processor;
  }
  
  public ProcessorBreakpoint(Processor processor, int address) {
    super(address);
    setProcessor(processor);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\breakpoint\ProcessorBreakpoint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */