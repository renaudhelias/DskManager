package jemu.core.device.MultiFace;

import jemu.system.cpc.CPC;

public class MultiFace extends MultifaceDevice {
  public static final byte[] MultifaceRam = new byte[8192];
  
  protected int Multiface_Flags = 0;
  
  protected int MULTIFACE_FLAGS_RAM_ENABLED = 1;
  
  public MultiFace() {
    super("Multiface 2 ©1988 by Romantic Robot");
  }
  
  public void writePort(int port, int data) {
    if (!CPC.mfisconnected)
      return; 
    if ((port & 0xFFFD) == 65256)
      setRamState(((port ^ 0xFFFFFFFF) & 0x2) >> 1); 
    byte PortHighByte = (byte)(port >> 8);
    if (PortHighByte == Byte.MAX_VALUE)
      if ((data & 0xC0) == 64) {
        int PenIndex = MultifaceRam[8143];
        MultifaceRam[0x1F90 | (PenIndex & 0x10) << 2 | PenIndex & 0xF] = (byte)data;
      } else {
        MultifaceRam[0x1FCF | (data & 0xC0) >> 2] = (byte)data;
      }  
    if (PortHighByte == -68)
      MultifaceRam[7423] = (byte)data; 
    if (PortHighByte == -67) {
      int CRTCRegIndex = MultifaceRam[7423];
      MultifaceRam[7600 + (CRTCRegIndex & 0xF)] = (byte)data;
    } 
    if (PortHighByte == -9)
      MultifaceRam[6143] = (byte)data; 
    if (PortHighByte == -33)
      MultifaceRam[6828] = (byte)data; 
  }
  
  protected void setRamState(int RamState) {
    if (RamState != 0) {
      this.Multiface_Flags |= this.MULTIFACE_FLAGS_RAM_ENABLED;
      CPC.memory.setMultiEnabled(true);
    } else {
      this.Multiface_Flags &= this.MULTIFACE_FLAGS_RAM_ENABLED ^ 0xFFFFFFFF;
      if (CPC.memory.multi)
        CPC.memory.setMultiEnabled(false); 
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\MultiFace\MultiFace.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */