package jemu.core.device.memory;

import jemu.core.device.Device;

public abstract class Memory extends Device {
  protected int size;
  
  public Memory(String type, int size) {
    super(type);
    this.size = size;
  }
  
  public int getAddressSize() {
    return this.size;
  }
  
  public int readByte(int address, Object config) {
    return readByte(address);
  }
  
  public int readWriteByte(int address, Object config) {
    return readWriteByte(address);
  }
  
  public int readWriteByte(int address, Object config, int forcedbank, boolean forced) {
    return readWriteByte(address, forcedbank, forced);
  }
  
  public void writeByte(int address, int value, Object config) {
    writeByte(address, value);
  }
  
  public void writeByte(int address, int value, Object config, int forcedbank, boolean forced) {
    writeByte(address, value, forcedbank, true);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\memory\Memory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */