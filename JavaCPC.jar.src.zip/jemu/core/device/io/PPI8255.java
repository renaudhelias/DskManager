package jemu.core.device.io;

import jemu.core.device.Device;
import jemu.core.device.IOPort;
import jemu.system.cpc.CPC;

public class PPI8255 extends Device {
  public static final int PORT_A = 0;
  
  public static final int PORT_B = 1;
  
  public static final int PORT_C = 2;
  
  public static final int PORT_CONTROL = 3;
  
  protected int portLowMask = 1;
  
  protected int portLowTest = 1;
  
  protected int portHighMask = 2;
  
  protected int portHighTest = 2;
  
  protected IOPort[] ports = new IOPort[] { new IOPort(0), new IOPort(0), new IOPort(0), new IOPort(255) };
  
  int port1;
  
  int port2;
  
  int port3;
  
  public PPI8255() {
    super("8255 PPI");
  }
  
  public void setPortMasks(int lowMask, int lowTest, int highMask, int highTest) {
    this.portLowMask = lowMask;
    this.portLowTest = lowTest;
    this.portHighMask = highMask;
    this.portHighTest = highTest;
  }
  
  public int readPort(int port) {
    int selPort = ((port & this.portHighMask) == this.portHighTest) ? 2 : 0;
    if ((port & this.portLowMask) == this.portLowTest)
      selPort++; 
    int result = this.ports[selPort].read();
    return result;
  }
  
  public void writePort(int port, int value) {
    int selPort = ((port & this.portHighMask) == this.portHighTest) ? 2 : 0;
    if ((port & this.portLowMask) == this.portLowTest)
      selPort++; 
    if (selPort == 3) {
      if ((value & 0x80) == 0) {
        IOPort ioPort = this.ports[2];
        int mask = 1 << (value >> 1 & 0x7);
        if ((value & 0x1) == 0) {
          ioPort.write(ioPort.readOutput() & (mask ^ 0xFF));
        } else {
          ioPort.write(ioPort.readOutput() | mask);
        } 
      } else {
        setControl(value);
      } 
    } else {
      switch (selPort) {
        case 0:
          this.port1 = value;
          break;
        case 1:
          this.port2 = value;
          break;
        case 2:
          this.port3 = value;
          break;
      } 
      this.ports[selPort].write(value);
    } 
  }
  
  public void setReadDevice(int port, Device device, int readPort) {
    this.ports[port].setInputDevice(device, readPort);
  }
  
  public void setWriteDevice(int port, Device device, int writePort) {
    this.ports[port].setOutputDevice(device, writePort);
  }
  
  protected String readWrite(int port, int mask) {
    return ((this.ports[port].getPortMode() & mask) == 0) ? "read" : "write";
  }
  
  public int readOutput(int port) {
    return this.ports[port].readOutput();
  }
  
  public String toString() {
    return super.toString() + ": Port A = " + readWrite(0, 255) + ", Port B = " + 
      readWrite(1, 255) + ", Port C (Upper) = " + readWrite(2, 240) + ", Port C (Lower) = " + 
      readWrite(2, 15);
  }
  
  public void setOutputValue(int port, int value) {
    this.ports[port].setOutput(value);
  }
  
  public int getOutputValue(int port) {
    return this.ports[port].getOutput();
  }
  
  public void setControl(int value) {
    this.ports[3].setOutput(value);
    this.ports[0].setPortMode(((value & 0x10) != 0) ? 0 : 255);
    if (CPC.memory.plus) {
      this.ports[1].setPortMode(0);
    } else {
      this.ports[1].setPortMode(((value & 0x2) != 0) ? 0 : 255);
    } 
    int mode = ((value & 0x8) != 0) ? 0 : 240;
    if ((value & 0x1) == 0) {
      this.ports[2].setPortMode(mode | 0xF);
    } else {
      this.ports[2].setPortMode(mode);
    } 
    if (CPC.memory.plus)
      return; 
    this.ports[0].write(0);
    this.ports[1].write(0);
    this.ports[2].write(0);
  }
  
  public int getPORT_CONTROL() {
    return this.ports[3].getOutput() | 0x80;
  }
  
  public int getPORT_A() {
    return this.ports[0].getOutput();
  }
  
  public int getPORT_B() {
    return this.ports[1].getOutput();
  }
  
  public int getPORT_C() {
    return this.ports[2].getOutput();
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\io\PPI8255.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */