package jemu.core.device.sound;

import jemu.ui.Switches;

public class DigiBlaster extends DigiDevice {
  boolean useStereo;
  
  boolean toggleStereo;
  
  public DigiBlaster() {
    super("Digiblaster");
    this.useStereo = false;
    this.toggleStereo = false;
  }
  
  public void writePort(int port, int value) {
    if (port == 61311 || port < 61184)
      return; 
    if (Switches.digiblaster) {
      if (AY_3_8910.digiblast = false)
        this.toggleStereo = false; 
      AY_3_8910.digicount = 1;
      AY_3_8910.digiblast = true;
      int audiobyte = (value ^ 0x80) * Switches.Blastervolume / 100 ^ 0x80;
      if (this.useStereo) {
        if (this.toggleStereo) {
          AY_3_8910.blasterB = audiobyte;
        } else {
          AY_3_8910.blasterA = audiobyte;
        } 
        this.toggleStereo = !this.toggleStereo;
      } else {
        AY_3_8910.blasterA = AY_3_8910.blasterB = audiobyte;
      } 
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\sound\DigiBlaster.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */