package jemu.core.device.sound;

import jemu.core.device.Device;

public class SoundDevice1 extends Device {
  protected SoundPlayer1 player;
  
  public SoundDevice1(String name) {
    super(name);
  }
  
  public SoundPlayer1 getSoundPlayer1() {
    return this.player;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\sound\SoundDevice1.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */