package jemu.core.device.sound;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import jemu.system.cpc.CPC;
import jemu.system.cpc.GateArray;
import jemu.ui.Display;
import jemu.ui.LCDDisplay;

public class YMControl extends JInternalFrame implements WindowListener, MouseListener {
  public static LCDDisplay display;
  
  public void mouseClicked(MouseEvent e) {
    if (e.getClickCount() > 1)
      dval = (dval == 255) ? 0 : 255; 
  }
  
  public void mousePressed(MouseEvent e) {}
  
  public void mouseReleased(MouseEvent e) {}
  
  public void mouseEntered(MouseEvent e) {}
  
  public void mouseExited(MouseEvent e) {}
  
  static BufferedImage lcd = new BufferedImage(350, 50, 12);
  
  public static int displaycount1 = 0;
  
  public static int displaycount2 = 0;
  
  protected static int displaycount3 = 0;
  
  public static int DisplayStart;
  
  public static int DisplayEnd = 0;
  
  public static String Monitor = "";
  
  static String dot = ":";
  
  protected static Font font;
  
  protected static Font font2;
  
  protected boolean playing = false;
  
  public JButton btnREC = new JButton("Rec");
  
  public JButton btnPLAY = new JButton("Play");
  
  public JButton btnLOAD = new JButton("Open");
  
  public JButton btnSTOP = new JButton("Stop");
  
  public JButton btnSAVE = new JButton("Save");
  
  public static int counter = 0;
  
  public static JSlider ympos = new JSlider();
  
  public JPanel controls;
  
  static JFrame fram;
  
  public void windowClosing(WindowEvent e) {
    setVisible(false);
  }
  
  public void windowClosed(WindowEvent e) {
    setVisible(false);
  }
  
  public void windowDeactivated(WindowEvent e) {}
  
  public void windowActivated(WindowEvent e) {}
  
  public void windowDeiconified(WindowEvent e) {}
  
  public void windowOpened(WindowEvent e) {}
  
  public void windowIconified(WindowEvent e) {}
  
  public YMControl() {
    display = new LCDDisplay(350, 50);
    display.addMouseListener(this);
    display.setPreferredSize(new Dimension(350, 50));
    ympos.setMaximum(0);
    ympos.setValue(0);
    setLayout(new BorderLayout());
    ympos.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseDragged(MouseEvent evt) {
            JavaSound.clear();
            GateArray.cpc.Slide(YMControl.ympos.getValue());
          }
        });
    this.btnPLAY.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (!CPC.YM_Rec) {
              if (Display.skin == 1) {
                Display.skin = 2;
              } else if (Display.skin == 2) {
                Display.skin = 1;
              } 
              CPC.st_mode = false;
              CPC.zx_mode = false;
              CPC.YM_Minutes = 0;
              CPC.YM_Seconds = 0;
              YMControl.displaycount1 = 0;
              YMControl.displaycount2 = 0;
              YMControl.DisplayStart = 0;
              CPC.ymcount = 0;
              CPC.YM_Play = true;
              CPC.YM_Rec = false;
              YMControl.UpdateLCD("*YM PLAYER*");
            } 
          }
        });
    this.btnREC.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (!CPC.YM_Play) {
              CPC.doRecord = false;
              YMControl.displaycount1 = 0;
              YMControl.displaycount2 = 0;
              YMControl.DisplayStart = 0;
              CPC.YM_registers = 16;
              CPC.atari_st_mode = false;
              CPC.oldYM = false;
              CPC.YM_Minutes = 0;
              CPC.YM_Seconds = 0;
              CPC.ymcount = 0;
              CPC.YM_RecCount = 0;
              CPC.YM_vbl = 0;
              CPC.YM_Play = false;
              CPC.YM_Rec = true;
              YMControl.UpdateLCD("*  PAUSE  *");
            } 
          }
        });
    this.btnSTOP.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            CPC.YM_Minutes = 0;
            CPC.YM_Seconds = 0;
            CPC.ymcount = 0;
            CPC.YM_Play = false;
            CPC.YM_Rec = false;
            CPC.YM_Stop = true;
            YMControl.displaycount1 = 0;
            YMControl.displaycount2 = 0;
            YMControl.DisplayStart = 0;
            YMControl.UpdateLCD("*YM PLAYER*");
          }
        });
    this.btnLOAD.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (!CPC.YM_Rec && !CPC.YM_Play)
              CPC.YM_Load = true; 
          }
        });
    this.btnSAVE.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (!CPC.YM_Rec && !CPC.YM_Play)
              CPC.YM_Save = true; 
          }
        });
    this.controls = new JPanel();
    this.controls.setLayout(new FlowLayout(1, 4, 4));
    this.controls.add(this.btnREC);
    this.controls.add(this.btnPLAY);
    this.controls.add(this.btnSTOP);
    this.controls.add(this.btnLOAD);
    this.controls.add(this.btnSAVE);
    add((Component)display, "North");
    add(this.controls, "Center");
    add(ympos, "South");
    pack();
    this.btnLOAD.setFocusable(false);
    this.btnPLAY.setFocusable(false);
    this.btnSTOP.setFocusable(false);
    this.btnSAVE.setFocusable(false);
    InputStream in = getClass().getResourceAsStream("tran.ttf");
    try {
      font = Font.createFont(0, in).deriveFont(0, 54.0F);
    } catch (Exception exception) {}
    in = getClass().getResourceAsStream("pixel.ttf");
    try {
      font2 = Font.createFont(0, in).deriveFont(0, 20.0F);
    } catch (Exception exception) {}
    setForeground(Color.LIGHT_GRAY);
    setBackground(Color.DARK_GRAY);
    setTitle("YM-control");
    pack();
    setResizable(false);
    setVisible(false);
  }
  
  static BufferedImage lcd2 = new BufferedImage(175, 25, 12);
  
  static int dingel = 0;
  
  static String lcdtext;
  
  static int ol;
  
  static int or;
  
  static int llc;
  
  static int rrc;
  
  public static void UpdateLCD(String input) {
    lcdtext = input;
    if (lcdtext.startsWith("*"))
      reset(); 
    Graphics d = lcd2.createGraphics();
    d.setColor(Color.white);
    d.fillRect(0, 0, 175, 50);
    d.setColor(Color.black);
    if (showtrack) {
      d.fillRect(1, 4, 3, 1);
      d.fillRect(1, 5, 1, 4);
      d.fillRect(3, 5, 1, 4);
      d.fillRect(2, 6, 1, 1);
      d.fillRect(1, 14, 2, 1);
      d.fillRect(1, 15, 1, 3);
      d.fillRect(1, 16, 2, 1);
      d.fillRect(1, 18, 2, 1);
      d.fillRect(3, 15, 1, 1);
      d.fillRect(3, 17, 1, 1);
      int pos = 7;
      for (int j = 0; j < JavaSound.data.length - 182; j += 2) {
        int k = (JavaSound.data[j] & 0xFF) >> 4;
        if (j == 0)
          ol = k; 
        d.drawLine(pos, -6 + k, pos, -6 + ol);
        ol = k;
        k = (JavaSound.data[j + 1] & 0xFF) >> 4;
        if (j == 0)
          or = k; 
        d.drawLine(pos, 4 + k, pos++, 4 + or);
        or = k;
      } 
    } else {
      d.setFont(font2);
      d.drawString(input, 8, 20);
    } 
    int lc = JavaSound.data[0] & 0xFF;
    int rc = JavaSound.data[1] & 0xFF;
    lc ^= 0x80;
    rc ^= 0x80;
    if (lc >> 1 > llc)
      llc = lc >> 1; 
    if (rc >> 1 > rrc)
      rrc = rc >> 1; 
    if (rrc == 0)
      rrc = 1; 
    if (llc == 0)
      llc = 1; 
    int i;
    for (i = 0; i < rrc * 2; i += 2)
      d.drawLine(7 + i, 22, 7 + i, 23); 
    for (i = 0; i < llc * 2; i += 2)
      d.drawLine(171 - i, 22, 171 - i, 23); 
    if (llc > 0)
      llc--; 
    if (rrc > 0)
      rrc--; 
    for (int x = 0; x < 175; x++) {
      for (int y = 0; y < 25; y++)
        display.setPixel(x * 2, y * 2, ((lcd2.getRGB(x, y) & 0xFF) != dval)); 
    } 
    display.updateDisplay();
  }
  
  static int dval = 255;
  
  public static boolean showtrack = false;
  
  static int displaycount4;
  
  public static void reset() {
    displaycount1 = displaycount2 = displaycount3 = displaycount4 = 0;
    DisplayStart = 0;
    showtrack = false;
  }
  
  public static void doYMDisplay(String minutes, String seconds, String milliseconds, String YMtitle, String YMauthor, String YMcreator) {
    String dispText = "        " + YMtitle + " - " + YMauthor + " - " + YMcreator + "        ";
    displaycount1++;
    if (displaycount1 >= 500) {
      displaycount2++;
      if (displaycount2 >= 10) {
        DisplayEnd = dispText.length();
        DisplayStart++;
        if (DisplayStart > DisplayEnd - 11)
          DisplayStart = 0; 
        displaycount2 = 0;
        if (displaycount1 >= 500 + (DisplayEnd - 11) * 10) {
          displaycount4++;
          if (displaycount4 < 500) {
            showtrack = true;
            displaycount2 = 500;
            DisplayStart = 0;
          } else {
            displaycount4 = 0;
            DisplayStart = 0;
            showtrack = false;
            displaycount1 = 0;
          } 
        } 
      } 
    } 
    if (!showtrack) {
      if (displaycount1 >= 500) {
        UpdateLCD(dispText.substring(DisplayStart, DisplayStart + 11));
      } else {
        minutes = minutes.replace(":", dot);
        UpdateLCD(minutes + dot + seconds + "\"" + milliseconds + " ");
      } 
    } else {
      UpdateLCD("");
    } 
    Monitor = " " + minutes + ":" + seconds + "\"" + milliseconds + " ";
    displaycount3++;
    if (displaycount3 >= 25)
      dot = " "; 
    if (displaycount3 >= 50) {
      dot = ":";
      displaycount3 = 0;
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\sound\YMControl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */