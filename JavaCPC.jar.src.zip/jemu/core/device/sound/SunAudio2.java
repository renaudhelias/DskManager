package jemu.core.device.sound;

import java.io.InputStream;

public class SunAudio2 extends SoundPlayer2 implements Runnable {
  protected final int[] frequencies = new int[] { 49716, 44100, 32000, 22050, 16000, 11025, 8000, 6000, 11025 };
  
  protected AudioStream stream;
  
  protected boolean playing = false;
  
  protected int samples;
  
  protected boolean stereo;
  
  protected int updates;
  
  public synchronized void stop(InputStream as) {}
  
  public synchronized void start(InputStream as) {}
  
  public SunAudio2(int samples, boolean stereo) {
    this.samples = samples;
    this.stereo = stereo;
    init();
  }
  
  public void init() {
    this.stream = new AudioStream(this.samples);
  }
  
  public int getSampleRate() {
    return 8000;
  }
  
  public long getDeviation() {
    return 1600L;
  }
  
  public long getUpdates() {
    int result = this.updates;
    this.updates = 0;
    return result;
  }
  
  public long getCount() {
    return System.currentTimeMillis();
  }
  
  public void play() {
    if (!this.playing) {
      this.stream.sync();
      this.playing = true;
      Thread thread = new Thread(this);
      thread.setPriority(10);
      thread.start();
    } 
  }
  
  public void stop() {
    if (this.playing) {
      stop(this.stream);
      this.playing = false;
    } 
  }
  
  public void dispose() {
    stop();
  }
  
  public void resync() {
    this.stream.sync();
  }
  
  public void run() {
    if (this.playing)
      start(this.stream); 
    while (this.playing) {
      try {
        Thread.sleep(1L);
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
  }
  
  public void writeStereo(int a, int b) {
    this.stream.writeulaw((byte)(a | b));
    switch (this.format) {
      case 0:
        this.stream.writeulaw((byte)(a | b));
        break;
      case 1:
        this.stream.writeulaw(SoundUtil.pcm8ToULaw((byte)(a | b)));
        break;
      case 2:
        this.stream.writeulaw(SoundUtil.upcm8ToULaw((byte)(a | b)));
        break;
      case 3:
        this.stream.writeulaw(SoundUtil.pcm16ToULaw(a + b));
        break;
      case 4:
        this.stream.writeulaw(SoundUtil.upcm16ToULaw(a + b));
        break;
    } 
    this.updates++;
  }
  
  protected class AudioStream extends InputStream {
    byte[] buffer;
    
    int pos = 0;
    
    int wrPos = 0;
    
    int size = 0;
    
    protected AudioStream(int samples) {
      this.buffer = new byte[samples];
    }
    
    public int read() {
      waitForData(1);
      int result = this.buffer[this.pos] & 0xFF;
      this.pos = (this.pos + 1) % this.buffer.length;
      this.size--;
      return result;
    }
    
    public void waitForData(int count) {
      while (this.size < count) {
        synchronized (this) {
          try {
            wait();
          } catch (Exception e) {
            e.printStackTrace();
          } 
        } 
      } 
    }
    
    public int read(byte[] buff, int offs, int len) {
      waitForData(len);
      int end = len + offs;
      for (; offs < end; offs++) {
        buff[offs] = this.buffer[this.pos];
        this.pos = (this.pos + 1) % this.buffer.length;
      } 
      this.size -= len;
      return len;
    }
    
    public void writeulaw(byte value) {
      this.buffer[this.wrPos] = value;
      this.wrPos = (this.wrPos + 1) % this.buffer.length;
      this.size++;
      synchronized (this) {
        notify();
      } 
    }
    
    public int available() {
      return 8000;
    }
    
    public void close() {
      SunAudio2.this.playing = false;
    }
    
    public void sync() {}
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\sound\SunAudio2.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */