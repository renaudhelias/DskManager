package jemu.core.device.sound;

import jemu.core.Util;
import jemu.core.device.Device;
import jemu.core.device.IOPort;
import jemu.settings.Settings;
import jemu.system.cpc.CPC;
import jemu.system.cpc.CPCMemory;
import jemu.ui.Desktop;
import jemu.ui.Display;
import jemu.ui.ScreenCapture;
import jemu.ui.Switches;

public class AY_3_8910 extends SoundDevice {
  public static boolean build;
  
  int[] mfpPrediv = new int[] { 0, 4, 10, 16, 50, 64, 100, 200 };
  
  protected int[] Buffered = new int[1000];
  
  public static final double[] LOG_VOLUME = new double[] { 
      0.08286408D, 0.1171875D, 0.1657282D, 0.234375D, 0.3314563D, 0.46875D, 0.6629126D, 0.9375D, 1.325825D, 1.875D, 
      2.65165D, 3.75D, 5.303301D, 7.5D, 10.6066D, 15.0D };
  
  byte[] regis = new byte[14];
  
  public byte[] getPSGRegisters() {
    for (int i = 0; i < 14; i++)
      this.regis[i] = (byte)getRegister(i); 
    return this.regis;
  }
  
  public void writePSGRegisters(byte[] regs) {
    for (int i = 0; i < 14; i++)
      setRegister(i, regs[i] & 0xFF); 
  }
  
  public static final double[] LOG_VOLUME_A = new double[] { 
      0.0D, 0.291348135D, 0.377409018D, 0.405813687D, 0.599450675D, 0.741130694D, 1.12748913D, 2.08514534D, 2.36758984D, 4.09155413D, 
      5.64934768D, 6.96772717D, 8.8908217D, 10.8194095D, 12.9095903D, 15.0D };
  
  public static final double[] LOG_VOLUME_B = new double[] { 
      0.0D, 0.291348135D, 0.377409018D, 0.405813687D, 0.599450675D, 0.886930648D, 1.23529412D, 2.01945525D, 2.37857633D, 3.8237583D, 
      5.34195468D, 6.70450904D, 8.46166171D, 10.6250858D, 12.6333257D, 15.0D };
  
  public static final double[] LOG_VOLUME_C = new double[] { 
      0.0D, 0.065461203D, 0.107576104D, 0.151979858D, 0.258640421D, 0.412680247D, 0.651865415D, 0.883955138D, 1.386587319D, 1.959029526D, 
      2.947585259D, 4.071183337D, 5.990386816D, 8.165712977D, 11.66994735D, 15.0D };
  
  public static final double[] LOG_VOLUME_D = new double[] { 
      0.0D, 0.102998397D, 0.189059281D, 0.283588921D, 0.439230945D, 0.601052872D, 0.86472877D, 1.151522087D, 1.639047837D, 2.20233463D, 
      3.133211261D, 4.184023804D, 5.984893568D, 7.983291371D, 11.30785076D, 15.0D };
  
  public static final double[] LOG_VOLUME_L = new double[] { 
      0.0D, 1.0D, 2.0D, 3.0D, 4.0D, 5.0D, 6.0D, 7.0D, 8.0D, 9.0D, 
      10.0D, 11.0D, 12.0D, 13.0D, 14.0D, 15.0D };
  
  protected double outvolume = 1.0D;
  
  protected int vuL;
  
  protected int vuR;
  
  protected int leftchange;
  
  protected int rightchange;
  
  protected int midchange;
  
  public boolean register13Updated = false;
  
  public static boolean digiblast = false;
  
  public static int leftChannel;
  
  public static int rightChannel;
  
  public static int tapeNoise;
  
  public static int blasterA;
  
  public static int blasterB;
  
  protected int volumen = 0;
  
  int volcount;
  
  int vucount;
  
  protected int digibuffer = 20000;
  
  public static int digicount = 0;
  
  public final int BDIR_MASK = 4;
  
  public final int BC2_MASK = 2;
  
  public final int BC1_MASK = 1;
  
  public final int PORT_A = 0;
  
  public final int PORT_B = 1;
  
  protected static final int INACTIVE = 0;
  
  protected static final int LATCH = 1;
  
  protected static final int READ = 2;
  
  protected static final int WRITE = 3;
  
  protected static final int[] STATES = new int[] { 0, 1, 0, 2, 1, 0, 3, 1 };
  
  protected static final int AFINE = 0;
  
  protected static final int ACOARSE = 1;
  
  protected static final int BFINE = 2;
  
  protected static final int BCOARSE = 3;
  
  protected static final int CFINE = 4;
  
  protected static final int CCOARSE = 5;
  
  protected static final int NOISEPERIOD = 6;
  
  protected static final int ENABLE = 7;
  
  protected static final int AVOL = 8;
  
  protected static final int BVOL = 9;
  
  protected static final int CVOL = 10;
  
  protected static final int EFINE = 11;
  
  protected static final int ECOARSE = 12;
  
  protected static final int ESHAPE = 13;
  
  protected static final int REG_PORTA = 14;
  
  protected static final int REG_PORTB = 15;
  
  protected static final int ENABLE_A = 1;
  
  protected static final int ENABLE_B = 2;
  
  protected static final int ENABLE_C = 4;
  
  protected static final int NOISE_A = 8;
  
  protected static final int NOISE_B = 16;
  
  protected static final int NOISE_C = 32;
  
  protected static final int PORT_A_OUT = 64;
  
  protected static final int PORT_B_OUT = 128;
  
  protected static final int NOISE_ALL = 56;
  
  protected static final int A = 0;
  
  protected static final int B = 1;
  
  protected static final int C = 2;
  
  protected static final int NOISE = 3;
  
  protected static final int ENVELOPE = 4;
  
  protected int step = 32768;
  
  protected int maxReg = 15;
  
  protected static int[] regs = new int[16];
  
  protected int selReg = 0;
  
  protected int bdirBC2BC1 = 0;
  
  protected int state = 0;
  
  protected int clockSpeed = 1000000;
  
  protected IOPort[] ports = new IOPort[] { new IOPort(0), new IOPort(0) };
  
  protected int[] envelope = new int[3];
  
  protected int[] output = new int[4];
  
  protected int[] count = new int[5];
  
  protected int[] period = new int[5];
  
  protected int[] volume = new int[5];
  
  protected int outN;
  
  protected int random = 1;
  
  protected int countEnv;
  
  protected int hold;
  
  protected int alternate;
  
  protected int attack;
  
  protected int holding;
  
  protected int updateStep;
  
  int pt;
  
  int oldwrite;
  
  protected boolean blockWRITE;
  
  public AY_3_8910() {
    super("AY-3-8910/2/3 Programmable Sound Generator");
    this.oldwrite = 0;
    this.blockWRITE = false;
    this.lowpass = 0;
    this.ppo = -600000;
    this.circlebuffer = new int[1600];
    this.writepos = 1599;
    this.readpos = 0;
    setClockSpeed(this.clockSpeed);
    int pufferSize = Settings.getInt("audio_puffersize", 4096);
    this.player = SoundUtil.getSoundPlayer(pufferSize, true);
    this.player.setFormat(2);
  }
  
  public void reset() {
    this.selReg = 0;
    this.random = 1;
    this.leftc = this.center = this.rightc = 0;
    this.countEnv = 0;
    for (int r = 0; r < this.maxReg; r++)
      setRegister(r, 0); 
    setRegister(0, 90);
    setRegister(2, 90);
    setRegister(4, 90);
    setRegister(6, 1);
    setRegister(7, 63);
    setRegister(11, 13);
    setRegister(13, 24);
  }
  
  public void setClockSpeed(int value) {
    this.clockSpeed = value;
    this.updateStep = (int)(this.step * 8L * JavaSound.SAMPLE_RATE / this.clockSpeed);
    this.output[3] = 255;
    for (int i = 0; i <= 4; i++) {
      this.count[i] = this.updateStep;
      this.period[i] = this.updateStep;
    } 
    this.period[4] = 0;
    this.count[3] = 32767;
  }
  
  public void changeClockSpeed(int value) {
    this.clockSpeed = value;
    this.updateStep = (int)(this.step * 8L * JavaSound.SAMPLE_RATE / this.clockSpeed);
  }
  
  public void changePlayer() {
    if (build) {
      this.player.init();
      changeClockSpeed(this.clockSpeed);
    } 
    build = true;
  }
  
  public void setSelectedRegister(int value) {
    this.selReg = value & 0xF;
    Desktop.selpsg = this.selReg;
  }
  
  public int getSelectedRegister() {
    return this.selReg;
  }
  
  public void resetRegisters() {
    for (int r = 0; r < 16; r++)
      setRegister(r, 0); 
    setRegister(0, 90);
    setRegister(2, 90);
    setRegister(4, 90);
    setRegister(6, 1);
    setRegister(7, 63);
    setRegister(11, 13);
    setRegister(13, 24);
  }
  
  public void setBDIR_BC2_BC1_old(int value, int dataValue) {
    if (this.bdirBC2BC1 != value) {
      this.bdirBC2BC1 = value;
      this.state = STATES[this.bdirBC2BC1];
      if (this.blockWRITE && this.state == 3) {
        this.blockWRITE = false;
        return;
      } 
      writePort(20, dataValue);
    } 
  }
  
  public void setBDIR_BC2_BC1(int value, int dataValue) {
    if (this.bdirBC2BC1 != value) {
      this.bdirBC2BC1 = value;
      this.state = STATES[this.bdirBC2BC1];
      if (this.state == 1)
        this.selReg = value & 0x1F; 
      if (this.blockWRITE && this.state == 3) {
        this.blockWRITE = false;
      } else if (!this.blockWRITE) {
        writePort(20, dataValue);
        return;
      } 
      if (dataValue > 7)
        writePort(20, dataValue); 
    } 
  }
  
  public int getBDIR_BC2_BC1() {
    return this.bdirBC2BC1;
  }
  
  public int readPort(int port) {
    if (this.selReg != 0)
      return (this.state == 2) ? readRegister(this.selReg) : 255; 
    return 255;
  }
  
  public void setReg(int value) {
    setRegister(this.selReg, value);
  }
  
  public void writePort(int port, int value) {
    switch (this.state) {
      case 1:
        this.selReg = value & 0x1F;
        Desktop.selpsg = this.selReg;
        break;
      case 3:
        if (port != 20)
          this.blockWRITE = true; 
        setReg(value & 0xFF);
        break;
    } 
  }
  
  public int getRegister(int index) {
    return regs[index];
  }
  
  public static String getReg(int index) {
    return Util.hex(regs[index]).substring(6);
  }
  
  public static int getR13() {
    return regs[13];
  }
  
  public int readRegister(int index) {
    if (index <= this.maxReg)
      return (index < 14) ? regs[index] : this.ports[index - 14].read(); 
    return 255;
  }
  
  public boolean registerUpdated() {
    return this.register13Updated;
  }
  
  public void resetUpdated() {
    this.register13Updated = false;
  }
  
  public void setRegister(int index, int value) {
    if (index == 13)
      this.register13Updated = true; 
    if (index < 14) {
      if (index == 13 || regs[index] != value) {
        int val, vol, last, newCount;
        regs[index] = value;
        switch (index) {
          case 0:
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
            index >>= 1;
            val = ((regs[(index << 1) + 1] & 0xF) << 8 | regs[index << 1]) * this.updateStep;
            last = this.period[index];
            this.period[index] = val = (val < 32768) ? 32768 : val;
            newCount = this.count[index] - val - last;
            this.count[index] = (newCount < 1) ? 1 : newCount;
            break;
          case 6:
            val = (value & 0x1F) * this.updateStep;
            if (!Switches.ayeffect)
              val *= 2; 
            last = this.period[3];
            this.period[3] = val = (val == 0) ? this.updateStep : val;
            newCount = this.count[3] - val - last;
            this.count[3] = (newCount < 1) ? 1 : newCount;
            break;
          case 8:
          case 9:
          case 10:
            this.volume[index - 8] = ((value & 0x10) == 0) ? (value & 0xF) : this.volume[4];
            break;
          case 11:
          case 12:
            val = (regs[12] << 8 | regs[11]) * this.updateStep << 1;
            last = this.period[4];
            this.period[4] = val;
            newCount = this.count[4] - val - last;
            this.count[4] = (newCount < 1) ? 1 : newCount;
            break;
          case 13:
            this.attack = ((value & 0x4) == 0) ? 0 : 15;
            if ((value & 0x8) == 0) {
              this.hold = 1;
              this.alternate = this.attack;
            } else {
              this.hold = value & 0x1;
              this.alternate = value & 0x2;
              if (this.hold != 0)
                this.attack = this.alternate; 
            } 
            this.count[4] = this.period[4];
            this.countEnv = 15;
            this.holding = 0;
            vol = this.volume[4] = this.attack ^ 0xF;
            if ((regs[8] & 0x10) != 0)
              this.volume[0] = vol; 
            if ((regs[9] & 0x10) != 0)
              this.volume[1] = vol; 
            if ((regs[10] & 0x10) != 0)
              this.volume[2] = vol; 
            break;
        } 
      } 
    } else {
      this.ports[index - 14].write(value);
    } 
  }
  
  public void writeAudio() {
    int enable = regs[7];
    if ((enable & 0x1) != 0) {
      if (this.count[0] <= this.step)
        this.count[0] = this.count[0] + this.step; 
      this.output[0] = 1;
    } 
    if ((enable & 0x2) != 0) {
      if (this.count[1] <= this.step)
        this.count[1] = this.count[1] + this.step; 
      this.output[1] = 1;
    } 
    if ((enable & 0x4) != 0) {
      if (this.count[2] <= this.step)
        this.count[2] = this.count[2] + this.step; 
      this.output[2] = 1;
    } 
    this.outN = this.output[3] | enable;
    if ((enable & 0x38) == 56 && this.count[3] <= this.step)
      this.count[3] = this.count[3] + this.step; 
    int[] cnt = new int[3];
    int left = this.step;
    do {
      int add = (this.count[3] < left) ? this.count[3] : left;
      for (int chan = 0; chan <= 2; chan++) {
        int chcnt = this.count[chan];
        if ((this.outN & 8 << chan) != 0) {
          int val = (this.output[chan] == 0) ? cnt[chan] : (cnt[chan] + chcnt);
          if ((chcnt -= add) <= 0) {
            int p = this.period[chan];
            while (true) {
              if ((chcnt += p) > 0) {
                this.output[chan] = this.output[chan] ^ 0x1;
                if ((this.output[chan] ^ 0x1) != 0)
                  val += p - chcnt; 
                break;
              } 
              val += p;
              if ((chcnt += p) > 0) {
                if (this.output[chan] == 0)
                  val -= chcnt; 
                break;
              } 
            } 
          } else if (this.output[chan] != 0) {
            val -= chcnt;
          } 
          cnt[chan] = val;
        } else if ((chcnt -= add) <= 0) {
          int p = this.period[chan];
          do {
            if ((chcnt += p) > 0) {
              this.output[chan] = this.output[chan] ^ 0x1;
              break;
            } 
          } while ((chcnt += p) <= 0);
        } 
        this.count[chan] = chcnt;
      } 
      this.count[3] = this.count[3] - add;
      if (this.count[3] - add <= 0) {
        int val = this.random + 1;
        if ((val & 0x2) != 0) {
          this.output[3] = this.output[3] ^ 0xFF;
          this.outN = this.output[3] ^ 0xFF | enable;
        } 
        this.random = ((this.random & 0x1) == 0) ? (this.random >> 1) : ((this.random ^ 0x28000) >> 1);
        this.count[3] = this.count[3] + this.period[3];
      } 
      left -= add;
    } while (left > 0);
    this.count[4] = this.count[4] - this.step;
    if (this.holding == 0 && this.period[4] != 0 && this.count[4] - this.step <= 0) {
      int ce = this.countEnv;
      int p = this.period[4];
      do {
        ce--;
        this.count[4] = this.count[4] + p;
      } while (this.count[4] + p <= 0);
      if (ce < 0)
        if (this.hold != 0) {
          if (this.alternate != 0)
            this.attack ^= 0xF; 
          this.holding = 1;
          ce = 0;
        } else {
          if (this.alternate != 0 && (ce & 0x10) != 0)
            this.attack ^= 0xF; 
          ce &= 0xF;
        }  
      this.countEnv = ce;
      int vol = this.volume[4] = ce ^ this.attack;
      if ((regs[8] & 0x10) != 0)
        this.volume[0] = vol; 
      if ((regs[9] & 0x10) != 0)
        this.volume[1] = vol; 
      if ((regs[10] & 0x10) != 0)
        this.volume[2] = vol; 
    } 
    if (Switches.VSoftOutput) {
      this.leftc = (int)(LOG_VOLUME_B[this.volume[0]] * (cnt[0] >> 13));
      this.center = (int)(LOG_VOLUME_B[this.volume[1]] * (cnt[1] >> 13));
      this.rightc = (int)(LOG_VOLUME_B[this.volume[2]] * (cnt[2] >> 13));
    } else if (Switches.LION) {
      this.leftc = (int)(LOG_VOLUME_C[this.volume[0]] * (cnt[0] >> 13));
      this.center = (int)(LOG_VOLUME_C[this.volume[1]] * (cnt[1] >> 13));
      this.rightc = (int)(LOG_VOLUME_C[this.volume[2]] * (cnt[2] >> 13));
    } else if (Switches.HACKER) {
      this.leftc = (int)(LOG_VOLUME_D[this.volume[0]] * (cnt[0] >> 13));
      this.center = (int)(LOG_VOLUME_D[this.volume[1]] * (cnt[1] >> 13));
      this.rightc = (int)(LOG_VOLUME_D[this.volume[2]] * (cnt[2] >> 13));
    } else if (Switches.CPCE95) {
      this.leftc = (int)(LOG_VOLUME[this.volume[0]] * (cnt[0] >> 13));
      this.center = (int)(LOG_VOLUME[this.volume[1]] * (cnt[1] >> 13));
      this.rightc = (int)(LOG_VOLUME[this.volume[2]] * (cnt[2] >> 13));
    } else if (Switches.linear) {
      this.leftc = (int)(LOG_VOLUME_L[this.volume[0]] * (cnt[0] >> 13));
      this.center = (int)(LOG_VOLUME_L[this.volume[1]] * (cnt[1] >> 13));
      this.rightc = (int)(LOG_VOLUME_L[this.volume[2]] * (cnt[2] >> 13));
    } else {
      this.leftc = (int)(LOG_VOLUME_A[this.volume[0]] * (cnt[0] >> 13));
      this.center = (int)(LOG_VOLUME_A[this.volume[1]] * (cnt[1] >> 13));
      this.rightc = (int)(LOG_VOLUME_A[this.volume[2]] * (cnt[2] >> 13));
    } 
    this.leftc = (int)(this.leftc * Switches.volume);
    this.center = (int)(this.center * Switches.volume);
    this.rightc = (int)(this.rightc * Switches.volume);
    if (!Switches.ayeffect && !Speaker)
      this.center = (int)(this.center * 0.75D); 
    if (Desktop.chanA.isSelected())
      this.leftc = 0; 
    if (Desktop.chanB.isSelected())
      this.center = 0; 
    if (Desktop.chanC.isSelected())
      this.rightc = 0; 
    if (digiblast) {
      BvuMeter();
    } else {
      vuMeter(this.leftc, this.center, this.rightc);
    } 
    leftChannel = this.leftc + this.center;
    rightChannel = this.center + this.rightc;
    soundOutput(leftChannel, rightChannel);
  }
  
  public static boolean liveNoise = true;
  
  int po;
  
  int lowpass;
  
  public static boolean Speaker = false;
  
  int ppo;
  
  int t;
  
  int p;
  
  int q;
  
  int r;
  
  public void setReadDevice(int port, Device device, int readPort) {
    this.ports[port].setInputDevice(device, readPort);
  }
  
  public void soundOutput(int left, int right) {
    if (digiblast && readRegister(7) != 63 && (readRegister(8) != 0 || readRegister(9) != 0 || readRegister(10) != 0))
      digiblast = false; 
    if (digiblast) {
      leftChannel = blasterA;
      rightChannel = blasterB;
    } 
    if (Switches.audioenabler != 1)
      leftChannel = rightChannel = 0; 
    if (ScreenCapture.record)
      leftChannel = rightChannel = 0; 
    if (digicount != 0)
      digicount++; 
    if (digicount >= this.digibuffer) {
      digiblast = false;
      digicount = 0;
    } 
    if (updatecount != 0) {
      updatecount++;
      if (updatecount > 1000) {
        updatecount = 0;
        updateBuffer();
      } 
    } 
    if (Switches.dbeffect) {
      buffer_write(rightChannel);
      rightChannel = buffer_read();
    } 
    if (Speaker) {
      int val = this.leftc + this.center + this.rightc;
      this.leftO = 0;
      if (digiblast) {
        this.rightO = rightChannel;
      } else {
        this.rightO = val;
      } 
    } else {
      this.leftO = leftChannel;
      this.rightO = rightChannel;
    } 
    this.player.writeStereo(this.leftO, this.rightO);
    if (CPC.playmovie || (Switches.FloppySound && Switches.audioenabler == 1)) {
      if (tapeNoise == 0 && liveNoise) {
        this.player.writeMono(CPCMemory.byteNoise >> 5);
      } else {
        this.player.writeMono(tapeNoise);
      } 
    } else {
      this.player.writeMono(0);
    } 
    if (changeformat) {
      changeformat = false;
      changePlayer();
      CPC.replay = true;
    } 
  }
  
  public static int skip = 10;
  
  int leftc;
  
  int center;
  
  int rightc;
  
  int leftO;
  
  int rightO;
  
  public static boolean changeformat = false;
  
  public static int buffersize = 1600;
  
  public static int updatecount = 0;
  
  int[] circlebuffer;
  
  int writepos;
  
  int readpos;
  
  protected void updateBuffer() {
    if (buffersize != this.circlebuffer.length) {
      System.out.println("Changing buffersize to: " + buffersize);
      try {
        this.writepos = buffersize - 1;
        this.readpos = 0;
        this.circlebuffer = new int[buffersize];
      } catch (Exception e) {
        updatecount = 1;
      } 
    } 
  }
  
  void buffer_write(int val) {
    try {
      this.circlebuffer[this.writepos] = val;
      this.writepos = (this.writepos + 1) % this.circlebuffer.length;
    } catch (Exception e) {
      updatecount = 1;
    } 
  }
  
  int buffer_read() {
    try {
      int val = this.circlebuffer[this.readpos];
      this.readpos = (this.readpos + 1) % this.circlebuffer.length;
      return val;
    } catch (Exception e) {
      updatecount = 1;
      return 0;
    } 
  }
  
  public void setWriteDevice(int port, Device device, int writePort) {
    this.ports[port].setOutputDevice(device, writePort);
  }
  
  public void vuMeter(int left, int mid, int right) {
    this.volcount++;
    if (this.volcount >= 1024) {
      this.volcount = 0;
      if (left > this.leftchange) {
        this.leftchange = left;
      } else if (this.leftchange > 0) {
        this.leftchange--;
      } 
      if (mid > this.midchange) {
        this.midchange = mid;
      } else if (this.midchange > 0) {
        this.midchange--;
      } 
      if (right > this.rightchange) {
        this.rightchange = right;
      } else if (this.rightchange > 0) {
        this.rightchange--;
      } 
      try {
        if (Desktop.midvumeter.isShowing()) {
          Desktop.midvumeter.setValue(this.midchange);
          Desktop.leftvumeter.setValue(this.leftchange);
          Desktop.rightvumeter.setValue(this.rightchange);
        } 
      } catch (Exception exception) {}
      Display.left = this.leftchange;
      Display.right = this.rightchange;
    } 
  }
  
  public void BvuMeter() {
    this.volcount++;
    if (this.volcount >= 768) {
      this.volcount = 0;
      int left = blasterA;
      if (left > this.leftchange) {
        this.leftchange = left;
      } else if (this.leftchange > 0) {
        this.leftchange--;
      } 
      int right = blasterB;
      if (right > this.rightchange) {
        this.rightchange = right;
      } else if (this.rightchange > 0) {
        this.rightchange--;
      } 
      try {
        if (Desktop.midvumeter.isShowing()) {
          Desktop.leftvumeter.setValue((this.leftchange ^ 0x80) / 2);
          Desktop.rightvumeter.setValue((this.rightchange ^ 0x80) / 2);
          Desktop.midvumeter.setValue(0);
        } 
      } catch (Exception exception) {}
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\sound\AY_3_8910.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */