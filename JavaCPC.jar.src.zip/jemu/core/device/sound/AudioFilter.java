package jemu.core.device.sound;

import jemu.system.cpc.CPC;

public class AudioFilter {
  int samplerate = 0;
  
  float[] xv = new float[5];
  
  float[] yv = new float[5];
  
  float[] xvb = new float[5];
  
  float[] yvb = new float[5];
  
  float[] lxv = new float[5];
  
  float[] lyv = new float[5];
  
  float[] lxvb = new float[5];
  
  float[] lyvb = new float[5];
  
  float[] lgain = new float[] { 3725.5374F, 2400.3887F, 756.6409F, 207.28209F, 71.0137F, 21.467102F, 7.826146F, 3.086545F };
  
  float[] lamp1 = new float[] { -0.48143458F, -0.43826514F, -0.3192142F, -0.1873795F, -0.09541143F, -0.030118875F, -0.020804841F, -0.10512065F };
  
  float[] lamp2 = new float[] { 2.2757854F, 2.1121554F, 1.6366981F, 1.0546654F, 0.5918063F, 0.1826757F, -0.08646132F, -0.64417714F };
  
  float[] lamp3 = new float[] { -4.0715513F, -3.8611944F, -3.2112699F, -2.3139884F, -1.485773F, -0.67997855F, -0.53674823F, -1.5857846F };
  
  float[] lamp4 = new float[] { 3.2729056F, 3.1806386F, 2.87264F, 2.369513F, 1.7640694F, 0.7820952F, -0.4004146F, -1.8487071F };
  
  float[] gain = new float[] { 1.1997832F, 1.2280024F, 1.3275825F, 1.5102526F, 1.7694795F, 2.309374F, 3.2389278F, 5.0474687F };
  
  float[] amp1 = new float[] { -0.6946954F, -0.66313434F, -0.5673839F, -0.43843073F, -0.31938264F, -0.18752757F, -0.09552066F, -0.040515784F };
  
  float[] amp2 = new float[] { 3.0315082F, 2.9244757F, 2.590048F, 2.112791F, 1.6373997F, 1.0553633F, 0.5924018F, 0.26181084F };
  
  float[] amp3 = new float[] { -4.973334F, -4.85176F, -4.459446F, -3.8620236F, -3.212277F, -2.3151495F, -1.4869195F, -0.82892686F };
  
  float[] amp4 = new float[] { 3.6362052F, 3.5899198F, 3.4351044F, 3.1810088F, 2.8731477F, 2.3702435F, 1.7650644F, 1.0386523F };
  
  public static boolean lowpass = false;
  
  public static boolean highpass = false;
  
  public void setSampleRate(int rate) {
    this.samplerate = rate;
  }
  
  public int HighpassFilterLeft(int x) {
    if (CPC.tapeRelay && CPC.trueaudio)
      x ^= 0x80; 
    this.xv[0] = this.xv[1];
    this.xv[1] = this.xv[2];
    this.xv[2] = this.xv[3];
    this.xv[3] = this.xv[4];
    this.xv[4] = x / this.gain[this.samplerate];
    this.yv[0] = this.yv[1];
    this.yv[1] = this.yv[2];
    this.yv[2] = this.yv[3];
    this.yv[3] = this.yv[4];
    this.yv[4] = this.xv[0] + this.xv[4] - 4.0F * (this.xv[1] + this.xv[3]) + 6.0F * this.xv[2] + this.amp1[this.samplerate] * this.yv[0] + this.amp2[this.samplerate] * this.yv[1] + this.amp3[this.samplerate] * this.yv[2] + this.amp4[this.samplerate] * this.yv[3];
    x = (int)this.yv[4];
    if (CPC.tapeRelay)
      x ^= 0x80; 
    return x;
  }
  
  public int HighpassFilterRight(int x) {
    if (CPC.tapeRelay && CPC.trueaudio)
      x ^= 0x80; 
    this.xvb[0] = this.xvb[1];
    this.xvb[1] = this.xvb[2];
    this.xvb[2] = this.xvb[3];
    this.xvb[3] = this.xvb[4];
    this.xvb[4] = x / this.gain[this.samplerate];
    this.yvb[0] = this.yvb[1];
    this.yvb[1] = this.yvb[2];
    this.yvb[2] = this.yvb[3];
    this.yvb[3] = this.yvb[4];
    this.yvb[4] = this.xvb[0] + this.xvb[4] - 4.0F * (this.xvb[1] + this.xvb[3]) + 6.0F * this.xvb[2] + this.amp1[this.samplerate] * this.yvb[0] + this.amp2[this.samplerate] * this.yvb[1] + this.amp3[this.samplerate] * this.yvb[2] + this.amp4[this.samplerate] * this.yvb[3];
    x = (int)this.yvb[4];
    if (CPC.tapeRelay)
      x ^= 0x80; 
    return x;
  }
  
  public int LowpassFilterLeft(int x) {
    if (CPC.tapeRelay)
      x ^= 0x80; 
    this.lxv[0] = this.lxv[1];
    this.lxv[1] = this.lxv[2];
    this.lxv[2] = this.lxv[3];
    this.lxv[3] = this.lxv[4];
    this.lxv[4] = x / this.lgain[this.samplerate];
    this.lyv[0] = this.lyv[1];
    this.lyv[1] = this.lyv[2];
    this.lyv[2] = this.lyv[3];
    this.lyv[3] = this.lyv[4];
    this.lyv[4] = this.lxv[0] + this.lxv[4] + 4.0F * (this.lxv[1] + this.lxv[3]) + 6.0F * this.lxv[2] + this.lamp1[this.samplerate] * this.lyv[0] + this.lamp2[this.samplerate] * this.lyv[1] + this.lamp3[this.samplerate] * this.lyv[2] + this.lamp4[this.samplerate] * this.lyv[3];
    x = (int)this.lyv[4];
    if (CPC.tapeRelay && CPC.trueaudio)
      x ^= 0x80; 
    return x;
  }
  
  public int LowpassFilterRight(int x) {
    if (CPC.tapeRelay)
      x ^= 0x80; 
    this.lxvb[0] = this.lxvb[1];
    this.lxvb[1] = this.lxvb[2];
    this.lxvb[2] = this.lxvb[3];
    this.lxvb[3] = this.lxvb[4];
    this.lxvb[4] = x / this.lgain[this.samplerate];
    this.lyvb[0] = this.lyvb[1];
    this.lyvb[1] = this.lyvb[2];
    this.lyvb[2] = this.lyvb[3];
    this.lyvb[3] = this.lyvb[4];
    this.lyvb[4] = this.lxvb[0] + this.lxvb[4] + 4.0F * (this.lxvb[1] + this.lxvb[3]) + 6.0F * this.lxvb[2] + this.lamp1[this.samplerate] * this.lyvb[0] + this.lamp2[this.samplerate] * this.lyvb[1] + this.lamp3[this.samplerate] * this.lyvb[2] + this.lamp4[this.samplerate] * this.lyvb[3];
    x = (int)this.lyvb[4];
    if (CPC.tapeRelay && CPC.trueaudio)
      x ^= 0x80; 
    return x;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\sound\AudioFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */