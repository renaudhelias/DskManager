package jemu.core.device.sound;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;
import jemu.settings.Settings;

public class JavaSound1 extends SunAudio1 {
  public static int SAMPLE_RATE = 44100;
  
  public static boolean muted = false;
  
  protected static AudioFormat STEREO_FORMAT = new AudioFormat(SAMPLE_RATE, 8, 2, false, true);
  
  protected SourceDataLine line;
  
  protected byte[] data;
  
  protected int offset = 0;
  
  protected int channels;
  
  protected long startCount;
  
  protected int rate;
  
  public JavaSound1(int samples, boolean stereo) {
    super(samples, stereo);
  }
  
  public int getSampleRate() {
    return SAMPLE_RATE;
  }
  
  public void init() {
    this.rate = Integer.parseInt(Settings.get("samplerate", "1"));
    SAMPLE_RATE = this.frequencies[this.rate];
    System.out.println("Samplerate is " + SAMPLE_RATE + "hz");
    STEREO_FORMAT = new AudioFormat(SAMPLE_RATE, 8, 2, false, false);
    this.format = 2;
    this.channels = this.stereo ? 2 : 1;
    this.data = new byte[this.samples * this.channels];
    AudioFormat fmt = STEREO_FORMAT;
    try {
      if (this.line != null) {
        this.line.flush();
        this.line.close();
      } 
      this.line = (SourceDataLine)AudioSystem.getLine(new DataLine.Info(SourceDataLine.class, fmt));
      this.line.open();
      System.out.println("Line for PSG YM 1 started!");
    } catch (Exception e) {
      e.printStackTrace();
    } 
    System.out.println("JavaSound: " + this.samples + " x " + this.channels);
    System.out.println("Line Buffer: " + this.line.getBufferSize() + " for " + this.line
        .getClass());
    clear();
    resync();
  }
  
  public void clear() {
    if (this.data == null)
      return; 
    for (int i = 0; i < this.data.length; i++)
      this.data[i] = Byte.MIN_VALUE; 
  }
  
  public void resync() {
    this.line.flush();
    for (int i = 0; i < this.data.length; i++)
      this.data[i] = Byte.MIN_VALUE; 
    this.startCount = this.line.getLongFramePosition();
    int sample = SAMPLE_RATE / 10 * this.channels;
    while (sample > 0) {
      int len = Math.min(this.data.length, sample);
      this.line.write(this.data, 0, len);
      sample -= len;
    } 
    System.out.println("resync: start=" + this.startCount);
  }
  
  public long getCount() {
    return this.line.getLongFramePosition() - this.startCount - 100L;
  }
  
  public long getDeviation() {
    return (SAMPLE_RATE / 10);
  }
  
  public void play() {
    resync();
    this.line.start();
  }
  
  public void stop() {
    this.line.stop();
  }
  
  public void dispose() {
    this.line.close();
  }
  
  public void writeStereo(int a, int b) {
    a ^= 0x80;
    b ^= 0x80;
    switch (this.format) {
      case 0:
        this.data[this.offset] = SoundUtil.ulawToUPCM8((byte)a);
        this.data[this.offset + 1] = SoundUtil.ulawToUPCM8((byte)b);
        break;
      case 2:
        this.data[this.offset] = (byte)a;
        this.data[this.offset + 1] = (byte)b;
        break;
    } 
    if (muted) {
      this.data[this.offset] = 0;
      this.data[this.offset + 1] = 0;
    } 
    if ((this.offset += 2) == this.data.length) {
      this.line.write(this.data, 0, this.data.length);
      this.offset = 0;
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\sound\JavaSound1.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */