package jemu.core.device.sound;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;

public class test {
  SourceDataLine line;
  
  int offset = 0;
  
  byte[] data = new byte[400];
  
  int[] left = new int[200];
  
  int[] right = new int[200];
  
  public void init() {
    AudioFormat form = new AudioFormat(44100.0F, 8, 2, false, true);
    try {
      this.line = (SourceDataLine)AudioSystem.getLine(new DataLine.Info(SourceDataLine.class, form, 88200));
      this.line.open();
      this.line.start();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  int p = 100;
  
  int k = 1;
  
  public static void main(String[] args) {
    int[] vals = { 
        1, 1, 1, 1, 2, 3, 3, 4, 5, 5, 
        6, 7, 7, 7, 7, 8, 8, 8, 8, 8, 
        8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 
        9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 
        10, 10, 10, 10, 10, 10, 10, 11, 11, 11, 
        11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 
        11, 11, 11, 11, 11, 11, 12, 12, 12, 12, 
        12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 
        12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 
        12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 
        13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 
        13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 
        13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 
        13, 13, 14, 14, 14, 14, 14, 14, 14, 14, 
        14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 
        14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 
        14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 
        14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 
        14, 14, 14, 15, 15, 15, 15, 15, 15, 15, 
        15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 
        15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 
        15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 
        15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 
        15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 
        15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 
        15, 15, 15, 15, 15, 15 };
    int k = 0;
    for (int i = 0; i < vals.length; i++) {
      if (k != vals[i]) {
        k = vals[i];
        System.out.println(i);
      } 
    } 
    test tet = new test();
    tet.init();
    while (tet.player != null)
      tet.player.run(); 
  }
  
  int ggl = 80;
  
  int gg = 1;
  
  Thread player = new Thread() {
      public void run() {
        test.this.data[test.this.offset] = (byte)test.this.p;
        test.this.data[test.this.offset + 1] = (byte)test.this.p;
        test.this.p += test.this.k;
        test.this.ggl += test.this.gg;
        if (test.this.ggl > 200)
          test.this.gg = -((int)(Math.random() * 2.0D)); 
        if (test.this.ggl < 100)
          test.this.gg = (int)(Math.random() * 2.0D); 
        if (test.this.p > test.this.ggl) {
          test.this.k--;
        } else {
          test.this.k++;
        } 
        if ((test.this.offset += 2) == test.this.data.length) {
          test.this.line.write(test.this.data, 0, test.this.data.length);
          test.this.offset = 0;
        } 
      }
    };
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\sound\test.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */