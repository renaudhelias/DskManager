package jemu.core.device.sound;

import java.applet.Applet;
import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.Stack;
import java.util.concurrent.ArrayBlockingQueue;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;

public class T extends Applet implements Runnable {
  private boolean[] keys = new boolean[255];
  
  private static final int WIDTH = 10;
  
  private static final int HEIGHT = 20;
  
  private static final int BOXWIDTH = 15;
  
  private static final int MARGIN = 3;
  
  private static final int PADDING = 5;
  
  private static final int TOP = 40;
  
  private static final int SCOREBOXW = 80;
  
  private static final int RIGHTBOXW = 101;
  
  private static final int LEFT = 100;
  
  private final int RIGHTBOX = 190;
  
  private static final int LIGHT = 16776960;
  
  private static final int BLACK = 0;
  
  private static final int WHITE = 16777215;
  
  private static final int MIDDLEGROUND = 13421772;
  
  private static final int FOREGROUND = 0;
  
  private static Color DARKER = new Color(240, 240, 240);
  
  private static final String config = "\000\000\000\000\000\001\b\000\001M\001:\003.\000\000샿\000\000\026M\002R\023\037샿\000\000\b\000\b\000\b\000샿\000\000\005?\007W\004N샿\000\000\000\000\b\000\000\000샿\001W\b\000\003M\b\000샿\000\000\000\000\000\001\b\000\000w\005C\004)\000\000샿\000\000\021J\005W\027r샿\000\000\b\000\b\000\b\000샿\000\000\002\027\003f\003@샿\000\000\000\000\b\000\000\000샿\002\037\003l\007a\000\000샿\000\000\000\000\000\017\004\013\001.\002-\007W\000\000샿\000\000\rC\0033\bH샿\000\000\004\000\b\000\004\000샿\000\000\0051\007q\003k샿\000\000\000\000\b\000\000\000샿\004\000\b\000\000\000\000\000샿\000\000\004l\0003\000\000샿\000\000\026\013\000.\fO샿\000\000\022w\000\017\000\000샿\000\000\004j\001\000\000\n샿\000\000\004$\000\024\000\000샿\007a\000\000\b\000\000\000샿\000\000\b\000\000C\b\000\001\n\000\000샿\000\000\002\002\004a\000\000샿\000\000\020\000\000)\004\004샿\000\000\001\t\000\037\000\030샿\000\000\003|\000\017\000\000샿\001\017\b\000\000\000\000\000샿\000\000\005Z\001$\000\000샿\000\000\025>\001\037\tl샿\000\000.F\000{\001e샿\000\000\006#\000q\002p샿\000\000\004\031\000\017\001\b\001\005\000\000샿\000f\b\000\b\000\b\000샿\000\000\006p\000f\003\032\0024\000\000샿\000\000\020f\0023\020\000샿\000\000\b\000\001M\013\032\0023\020\000샿\000\000\004\000\0023\004\000샿\000\000\000\000\b\000\000\000샿\004\000\b\000\b\000\000\000샿\000\000\004\026\002\000\000\000샿\000\000\000\000\000\n\0166샿\000\000\0054\000C\000s샿\000\000\000\037\000\001\004#\001\000\001\t샿\000\000\b\000\000\005\b\000\000\017\006p\005\037\000\000샿\b\000\b\000\003v\000\000샿";
  
  private int step;
  
  private PriorityQueue<Integer> cmds = new PriorityQueue<>();
  
  private static final int SAMPLE_RATE = 44100;
  
  private static final int STEPS_PER_SEC = 80;
  
  private static final int CHANNELS = 8;
  
  private static final int FILTER_RES = 0;
  
  private static final int FILTER_LP = 1;
  
  private static final int FILTER_BP = 2;
  
  private static final int FILTER_HP = 3;
  
  private static final int TIME = 4;
  
  private static final int FREQ = 5;
  
  private static final int PHASE = 6;
  
  private static final int OSC_FB = 7;
  
  private static final int FILTER_Z1 = 8;
  
  private static final int FILTER_Z2 = 9;
  
  private static final int OSC_ENV = 10;
  
  private static final int FB_ENV = 11;
  
  private static final int FREQ_ENV = 12;
  
  private static final int FILT_ENV = 13;
  
  private static final int NOISE_ENV = 14;
  
  private final float[][][] envelopes = new float[8][5][];
  
  private final float[][] channels = new float[8][16];
  
  public final void start() {
    (new Thread(this)).start();
  }
  
  public final void run() {
    enableEvents(8L);
    setSize(500, 445);
    int xPiece = 4, yPiece = 0;
    int[][] grid = new int[10][20];
    boolean O = false;
    boolean I = true;
    boolean[][] currentPiece = { { false, false, false, false }, { false, false, false, false }, { false, false, false, false }, { false, false, false, false } };
    boolean newPiece = true;
    int score = 0;
    int level = 0;
    int levelInc = 0;
    boolean justEnded = false;
    boolean[][][] pieces = { { { true, false, false, false }, { true, false, false, false }, { true, true, false, false }, { false, false, false, false } }, { { false, true, false, false }, { false, true, false, false }, { true, true, false, false }, { false, false, false, false } }, { { true, false, false, false }, { true, false, false, false }, { true, false, false, false }, { true, false, false, false } }, { { false, true, false, false }, { true, true, true, false }, { false, false, false, false }, { false, false, false, false } }, { { true, true, false, false }, { false, true, true, false }, { false, false, false, false }, { false, false, false, false } }, { { false, true, true, false }, { true, true, false, false }, { false, false, false, false }, { false, false, false, false } }, { { true, true, false, false }, { true, true, false, false }, { false, false, false, false }, { false, false, false, false } } };
    long lastTime_yLevel = 0L;
    long lastTime_rotate = 0L;
    long lastTime_move = 0L;
    long lastTime_music = 0L;
    int[] colours = { 16777164, 16750848, 52479, 16711680, 65280, 255, 16776960, 65535, 16711935 };
    String[] pieceNames = { "L BLOCK", "R. L BLOCK", "LINE PIECE!", "T BLOCK", "SQUIGGLY", "R. SQUIGGLY", " SQUARE" };
    Random r = new Random();
    int nextPieceNum = r.nextInt(7);
    int curPieceNum = nextPieceNum;
    float downSpeed = 1.0F;
    Stack<Point> fillStack = new Stack<>();
    ArrayBlockingQueue<Integer> yQueue = new ArrayBlockingQueue<>(20);
    BufferedImage screen = new BufferedImage(500, 470, 1);
    Graphics g = screen.getGraphics();
    Graphics appletGraphics = getGraphics();
    String courierNew = "Courier New";
    Font font = new Font(courierNew, 0, 12);
    Font fontMedium = new Font(courierNew, 0, 28);
    g.setFont(font);
    boolean gameOver = true;
    boolean[][] nextPiece = new boolean[4][4];
    float xOffset = 0.0F, yOffset = 0.0F;
    boolean playMusic = true;
    String tetrisSong = "삀hc\037c`\021ad\017cf!da\020`c\017\\a!a\\\020da\020dh cf\020ad\020c`0ad\020fc hc da a\\ a\\?\021f] ai\020dm\020d\bd\bck\020ai\020_h0d\\\020h_\020a\b_\bf]\020\\d\020`c `c\020da\020cf hc ad \\a \\a?\001hc `c\020da\020fc da\020`c\020a\\ a\\\020ad\020hd fc\020ad\020`c0ad\020cf ch ad a\\ \\a?\021]f ia\020md\020d\bd\bkc\020ai\020h_0\\d\020_h\020a\b_\b]f\020d\\\020c` `c\020ad\020fc ch ad \\a a\\?\001a\020h\020a\020h\020a\020h\020a\020h\020`\020h\020`\020h\020`\020h\020`\020h\020a\020h\020a\020h\020a\020h\020a\020h\020`\020h\020`\020h\020`\020h\020`\020h삁D\017P\020D\021P\017D\020P\021D\020P\017I\021U\020I\020U\020I\020U\020I\020U\020H\020T\020H\020T\020D\020P\020D\020P\020I\020U\020I\020U\020I\020U\020K\020L\020N\020B B B\bB\bI\020E\020@\020L L @\bA\bB\020C W W P T\020I\020P\020I\020P\020I?\001D\020P\020D\020P\020D\020P\020D\020P\020I\020U\020I\020U\020I\020U\020I\020U\020H\020T\020H\020T\020D\020P\020D\020P\020I\020U\020I\020U\020I\020U\020K\020L\020N\020B B B\bB\bI\020E\020@\020L L @\bA\bB\020C W W P T\020I\020P\020I\020P\020I삂\017H!H\037H\bH\031H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H";
    String hitBottom = "삆^";
    String clearRow = "g";
    String fail = "삄L";
    String rotate = "삆N";
    AudioFormat format = new AudioFormat(44100.0F, 16, 1, true, true);
    SourceDataLine dest = null;
    try {
      dest = AudioSystem.getSourceDataLine(format, null);
      dest.open(format, 4096);
    } catch (Exception exception) {}
    dest.start();
    int samplesPerStep = 551;
    byte[] outBuffer = new byte[samplesPerStep * 2];
    String[] fields = "\000\000\000\000\000\001\b\000\001M\001:\003.\000\000샿\000\000\026M\002R\023\037샿\000\000\b\000\b\000\b\000샿\000\000\005?\007W\004N샿\000\000\000\000\b\000\000\000샿\001W\b\000\003M\b\000샿\000\000\000\000\000\001\b\000\000w\005C\004)\000\000샿\000\000\021J\005W\027r샿\000\000\b\000\b\000\b\000샿\000\000\002\027\003f\003@샿\000\000\000\000\b\000\000\000샿\002\037\003l\007a\000\000샿\000\000\000\000\000\017\004\013\001.\002-\007W\000\000샿\000\000\rC\0033\bH샿\000\000\004\000\b\000\004\000샿\000\000\0051\007q\003k샿\000\000\000\000\b\000\000\000샿\004\000\b\000\000\000\000\000샿\000\000\004l\0003\000\000샿\000\000\026\013\000.\fO샿\000\000\022w\000\017\000\000샿\000\000\004j\001\000\000\n샿\000\000\004$\000\024\000\000샿\007a\000\000\b\000\000\000샿\000\000\b\000\000C\b\000\001\n\000\000샿\000\000\002\002\004a\000\000샿\000\000\020\000\000)\004\004샿\000\000\001\t\000\037\000\030샿\000\000\003|\000\017\000\000샿\001\017\b\000\000\000\000\000샿\000\000\005Z\001$\000\000샿\000\000\025>\001\037\tl샿\000\000.F\000{\001e샿\000\000\006#\000q\002p샿\000\000\004\031\000\017\001\b\001\005\000\000샿\000f\b\000\b\000\b\000샿\000\000\006p\000f\003\032\0024\000\000샿\000\000\020f\0023\020\000샿\000\000\b\000\001M\013\032\0023\020\000샿\000\000\004\000\0023\004\000샿\000\000\000\000\b\000\000\000샿\004\000\b\000\b\000\000\000샿\000\000\004\026\002\000\000\000샿\000\000\000\000\000\n\0166샿\000\000\0054\000C\000s샿\000\000\000\037\000\001\004#\001\000\001\t샿\000\000\b\000\000\005\b\000\000\017\006p\005\037\000\000샿\b\000\b\000\003v\000\000샿".split("샿");
    int field = 0;
    for (int i1 = 0; i1 < this.channels.length; i1++) {
      for (int j = 0; j < 5; j++) {
        String env = fields[field++];
        this.envelopes[i1][j] = new float[env.length() / 2];
        for (int k = 0; k < env.length() / 2; k++)
          this.envelopes[i1][j][k] = (env.charAt(k * 2) << 7 | env.charAt(k * 2 + 1)) / 1024.0F; 
      } 
      String filter = fields[field++];
      for (int i = 0; i < 4; i++)
        this.channels[i1][i] = (filter.charAt(i * 2) << 7 | filter.charAt(i * 2 + 1)) / 1024.0F; 
      this.channels[i1][4] = 100.0F;
    } 
    int rand = 0;
    long sleepTime = 0L;
    boolean playedEnding = true;
    int blockColour = 1;
    int nextColour = colours[r.nextInt(colours.length)];
    String name = "Elliot Walmsley";
    String game = "Tetris4k";
    while (true) {
      int i;
      for (i = 0; i < 255; i++) {
        if (this.keys[i]) {
          gameOver = false;
          xPiece = 3;
          yPiece = 0;
          grid = new int[10][20];
          newPiece = true;
          nextPieceNum = r.nextInt(7);
          curPieceNum = nextPieceNum;
          score = 0;
          level = 0;
          levelInc = 0;
          sleepTime = 0L;
          format = new AudioFormat(44100.0F, 16, 1, true, true);
          dest = null;
          try {
            dest = AudioSystem.getSourceDataLine(format, null);
            dest.open(format, 4096);
          } catch (Exception exception) {}
          dest.start();
          samplesPerStep = 551;
          outBuffer = new byte[samplesPerStep * 2];
          fields = "\000\000\000\000\000\001\b\000\001M\001:\003.\000\000샿\000\000\026M\002R\023\037샿\000\000\b\000\b\000\b\000샿\000\000\005?\007W\004N샿\000\000\000\000\b\000\000\000샿\001W\b\000\003M\b\000샿\000\000\000\000\000\001\b\000\000w\005C\004)\000\000샿\000\000\021J\005W\027r샿\000\000\b\000\b\000\b\000샿\000\000\002\027\003f\003@샿\000\000\000\000\b\000\000\000샿\002\037\003l\007a\000\000샿\000\000\000\000\000\017\004\013\001.\002-\007W\000\000샿\000\000\rC\0033\bH샿\000\000\004\000\b\000\004\000샿\000\000\0051\007q\003k샿\000\000\000\000\b\000\000\000샿\004\000\b\000\000\000\000\000샿\000\000\004l\0003\000\000샿\000\000\026\013\000.\fO샿\000\000\022w\000\017\000\000샿\000\000\004j\001\000\000\n샿\000\000\004$\000\024\000\000샿\007a\000\000\b\000\000\000샿\000\000\b\000\000C\b\000\001\n\000\000샿\000\000\002\002\004a\000\000샿\000\000\020\000\000)\004\004샿\000\000\001\t\000\037\000\030샿\000\000\003|\000\017\000\000샿\001\017\b\000\000\000\000\000샿\000\000\005Z\001$\000\000샿\000\000\025>\001\037\tl샿\000\000.F\000{\001e샿\000\000\006#\000q\002p샿\000\000\004\031\000\017\001\b\001\005\000\000샿\000f\b\000\b\000\b\000샿\000\000\006p\000f\003\032\0024\000\000샿\000\000\020f\0023\020\000샿\000\000\b\000\001M\013\032\0023\020\000샿\000\000\004\000\0023\004\000샿\000\000\000\000\b\000\000\000샿\004\000\b\000\b\000\000\000샿\000\000\004\026\002\000\000\000샿\000\000\000\000\000\n\0166샿\000\000\0054\000C\000s샿\000\000\000\037\000\001\004#\001\000\001\t샿\000\000\b\000\000\005\b\000\000\017\006p\005\037\000\000샿\b\000\b\000\003v\000\000샿".split("샿");
          field = 0;
          for (int j = 0; j < this.channels.length; j++) {
            for (int k = 0; k < 5; k++) {
              String env = fields[field++];
              this.envelopes[j][k] = new float[env.length() / 2];
              for (int n = 0; n < env.length() / 2; n++)
                this.envelopes[j][k][n] = (env.charAt(n * 2) << 7 | env.charAt(n * 2 + 1)) / 1024.0F; 
            } 
            String filter = fields[field++];
            for (int m = 0; m < 4; m++)
              this.channels[j][m] = (filter.charAt(m * 2) << 7 | filter.charAt(m * 2 + 1)) / 1024.0F; 
            this.channels[j][4] = 100.0F;
          } 
          rand = 0;
        } 
      } 
      while (!gameOver) {
        if (this.cmds.isEmpty() && playedEnding)
          play("삀hc\037c`\021ad\017cf!da\020`c\017\\a!a\\\020da\020dh cf\020ad\020c`0ad\020fc hc da a\\ a\\?\021f] ai\020dm\020d\bd\bck\020ai\020_h0d\\\020h_\020a\b_\bf]\020\\d\020`c `c\020da\020cf hc ad \\a \\a?\001hc `c\020da\020fc da\020`c\020a\\ a\\\020ad\020hd fc\020ad\020`c0ad\020cf ch ad a\\ \\a?\021]f ia\020md\020d\bd\bkc\020ai\020h_0\\d\020_h\020a\b_\b]f\020d\\\020c` `c\020ad\020fc ch ad \\a a\\?\001a\020h\020a\020h\020a\020h\020a\020h\020`\020h\020`\020h\020`\020h\020`\020h\020a\020h\020a\020h\020a\020h\020a\020h\020`\020h\020`\020h\020`\020h\020`\020h삁D\017P\020D\021P\017D\020P\021D\020P\017I\021U\020I\020U\020I\020U\020I\020U\020H\020T\020H\020T\020D\020P\020D\020P\020I\020U\020I\020U\020I\020U\020K\020L\020N\020B B B\bB\bI\020E\020@\020L L @\bA\bB\020C W W P T\020I\020P\020I\020P\020I?\001D\020P\020D\020P\020D\020P\020D\020P\020I\020U\020I\020U\020I\020U\020I\020U\020H\020T\020H\020T\020D\020P\020D\020P\020I\020U\020I\020U\020I\020U\020K\020L\020N\020B B B\bB\bI\020E\020@\020L L @\bA\bB\020C W W P T\020I\020P\020I\020P\020I삂\017H!H\037H\bH\031H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H H H H\bH\030H H H H\020H\020H"); 
        synchronized (this) {
          while (!this.cmds.isEmpty() && ((Integer)this.cmds.peek()).intValue() >> 12 == this.step) {
            int cmd = ((Integer)this.cmds.poll()).intValue();
            int chan = cmd >> 8 & 0x7;
            this.channels[chan][5] = 440.0F * (float)Math.pow(2.0D, ((cmd & 0x3F) - 33) / 12.0D);
            this.channels[chan][4] = 0.0F;
          } 
        } 
        if (playMusic)
          this.step++; 
        for (i = 0; i < outBuffer.length / 2; i++) {
          float out = 0.0F;
          for (int k = 0; k < this.channels.length; k++) {
            float chanOut = 0.0F;
            float[] channel = this.channels[k];
            channel[10] = evalEnv(this.envelopes[k][0], channel[4], channel[10]);
            channel[11] = evalEnv(this.envelopes[k][1], channel[4], channel[11]);
            channel[12] = evalEnv(this.envelopes[k][2], channel[4], channel[12]);
            channel[13] = evalEnv(this.envelopes[k][3], channel[4], channel[13]);
            channel[14] = evalEnv(this.envelopes[k][4], channel[4], channel[14]);
            rand = (rand * 16598013 + 2820163) % 16777216;
            float noise = (rand / 1.6777216E7F - 0.5F) * channel[14];
            float osc = (float)Math.sin(channel[6] * Math.PI * 2.0D + (channel[7] * channel[11]));
            channel[7] = (osc + channel[7]) * 0.5F;
            osc *= channel[10];
            float f = channel[13];
            float lp = channel[9] + f * channel[8];
            float hp = osc + noise - lp - channel[0] * channel[8];
            float bp = channel[8] + f * hp;
            chanOut = channel[1] * lp + channel[2] * bp + channel[3] * hp;
            channel[8] = bp;
            channel[9] = lp;
            channel[4] = channel[4] + 2.2675737E-5F;
            channel[6] = channel[6] + channel[5] * channel[12] / 44100.0F;
            if (channel[6] > 1.0F)
              channel[6] = channel[6] - 1.0F; 
            if (k >= 5)
              chanOut *= 2.0F; 
            out += chanOut;
          } 
          short outS = (short)(int)(out * 5000.0F);
          outBuffer[i * 2 + 1] = (byte)(outS & 0xFF);
          outBuffer[i * 2] = (byte)(outS >> 8);
        } 
        dest.write(outBuffer, 0, outBuffer.length);
        if (!playedEnding && sleepTime < System.currentTimeMillis() - 2500L) {
          playedEnding = true;
          gameOver = true;
        } 
        if (playedEnding) {
          if (newPiece) {
            int n;
            for (n = 0; n < 4; n++) {
              for (int i2 = 0; i2 < 4; i2++)
                currentPiece[i2][n] = pieces[nextPieceNum][n][i2]; 
            } 
            curPieceNum = nextPieceNum;
            nextPieceNum = r.nextInt(7);
            blockColour = nextColour;
            nextColour = colours[r.nextInt(colours.length)];
            nextPiece = new boolean[4][4];
            for (n = 0; n < 4; n++) {
              for (int i2 = 0; i2 < 4; i2++)
                nextPiece[i2][n] = pieces[nextPieceNum][n][i2]; 
            } 
            yPiece = 0;
            xPiece = 4;
            for (int x = 0; x < 10; x++) {
              if (grid[x][0] != 0) {
                justEnded = true;
                playedEnding = false;
              } 
            } 
            int k;
            for (k = 0; k < 4; k++) {
              for (int i2 = 0; i2 < 4; i2++) {
                if (currentPiece[i2][k] && 
                  grid[xPiece + i2][yPiece + k] != 0) {
                  justEnded = true;
                  playedEnding = false;
                } 
              } 
            } 
            for (k = 0; k < 4; k++) {
              for (int i2 = 0; i2 < 4; i2++) {
                if (currentPiece[i2][k])
                  grid[xPiece + i2][yPiece + k] = blockColour; 
              } 
            } 
            newPiece = false;
          } 
          if (this.keys[77] && System.currentTimeMillis() - lastTime_music > 300L) {
            playMusic = !playMusic;
            lastTime_music = System.currentTimeMillis();
          } 
          if ((this.keys[87] || this.keys[38] || this.keys[32]) && System.currentTimeMillis() - lastTime_rotate > 150L) {
            lastTime_rotate = System.currentTimeMillis();
            for (int k = 0; k < 4; k++) {
              for (int x = 0; x < 4; x++) {
                if (currentPiece[x][k])
                  grid[xPiece + x][yPiece + k] = 0; 
              } 
            } 
            boolean[][] temp = new boolean[4][4];
            boolean[][] saveCurPiece = (boolean[][])currentPiece.clone();
            for (int n = 0; n < 4; n++) {
              for (int x = 0; x < 4; x++)
                temp[x][n] = currentPiece[n][3 - x]; 
            } 
            int shift = -1;
            int space = 0;
            while (shift == -1 && space < 4) {
              for (int i4 = 0; i4 < 4; i4++) {
                if (temp[space][i4])
                  shift = space; 
              } 
              space++;
            } 
            boolean[][] temp2 = new boolean[4][4];
            for (int i2 = 0; i2 < 4; i2++) {
              for (int x = 0; x < 4 - shift; x++)
                temp2[x][i2] = temp[x + shift][i2]; 
            } 
            temp = (boolean[][])temp2.clone();
            boolean switchPieces = true;
            int i3;
            for (i3 = 0; i3 < 4; i3++) {
              for (int x = 0; x < 4; x++) {
                if (temp[x][i3] && 
                  x + xPiece > 9)
                  switchPieces = false; 
              } 
            } 
            for (i3 = 0; i3 < 4; i3++) {
              for (int x = 0; x < 4; x++) {
                if (temp[x][i3] && 
                  i3 + yPiece > 19)
                  switchPieces = false; 
              } 
            } 
            if (switchPieces)
              for (i3 = 0; i3 < 4; i3++) {
                for (int x = 0; x < 4; x++) {
                  if (temp[x][i3] && 
                    grid[xPiece + x][yPiece + i3] != 0)
                    switchPieces = false; 
                } 
              }  
            currentPiece = (boolean[][])saveCurPiece.clone();
            if (switchPieces) {
              play("삆N");
              currentPiece = (boolean[][])temp.clone();
            } 
            for (i3 = 0; i3 < 4; i3++) {
              for (int x = 0; x < 4; x++) {
                if (currentPiece[x][i3])
                  grid[xPiece + x][yPiece + i3] = blockColour; 
              } 
            } 
          } 
          downSpeed = 1.0F;
          if (this.keys[83] || this.keys[40])
            downSpeed = 0.1F; 
          if ((this.keys[65] || this.keys[37]) && System.currentTimeMillis() - lastTime_move > 100L) {
            lastTime_move = System.currentTimeMillis();
            for (int k = 0; k < 4; k++) {
              for (int x = 0; x < 4; x++) {
                if (currentPiece[x][k])
                  grid[xPiece + x][yPiece + k] = 0; 
              } 
            } 
            boolean canMoveLeft = true;
            int n;
            for (n = 0; n < 4; n++) {
              int x = 0;
              int leftBlockX = -1;
              while (x < 4 && leftBlockX == -1) {
                if (currentPiece[x][n])
                  leftBlockX = x; 
                x++;
              } 
              if (leftBlockX != -1)
                if (xPiece + leftBlockX - 1 >= 0) {
                  if (grid[xPiece + leftBlockX - 1][yPiece + n] != 0)
                    canMoveLeft = false; 
                } else {
                  canMoveLeft = false;
                }  
            } 
            if (canMoveLeft)
              xPiece--; 
            for (n = 0; n < 4; n++) {
              for (int x = 0; x < 4; x++) {
                if (currentPiece[x][n])
                  grid[xPiece + x][yPiece + n] = blockColour; 
              } 
            } 
          } 
          if ((this.keys[68] || this.keys[39]) && System.currentTimeMillis() - lastTime_move > 100L) {
            lastTime_move = System.currentTimeMillis();
            for (int k = 0; k < 4; k++) {
              for (int x = 0; x < 4; x++) {
                if (currentPiece[x][k])
                  grid[xPiece + x][yPiece + k] = 0; 
              } 
            } 
            boolean canMoveRight = true;
            int n;
            for (n = 0; n < 4; n++) {
              int x = 3;
              int rightBlockX = -1;
              while (x >= 0 && rightBlockX == -1) {
                if (currentPiece[x][n])
                  rightBlockX = x; 
                x--;
              } 
              if (rightBlockX != -1)
                if (xPiece + rightBlockX + 1 < 10) {
                  if (grid[xPiece + rightBlockX + 1][yPiece + n] != 0)
                    canMoveRight = false; 
                } else {
                  canMoveRight = false;
                }  
            } 
            if (canMoveRight)
              xPiece++; 
            for (n = 0; n < 4; n++) {
              for (int x = 0; x < 4; x++) {
                if (currentPiece[x][n])
                  grid[xPiece + x][yPiece + n] = blockColour; 
              } 
            } 
          } 
          if ((float)(System.currentTimeMillis() - lastTime_yLevel) > (500.0F - level * 40.0F) * downSpeed && yQueue.isEmpty()) {
            for (int k = 0; k < 4; k++) {
              for (int x = 0; x < 4; x++) {
                if (currentPiece[x][k])
                  grid[xPiece + x][yPiece + k] = 0; 
              } 
            } 
            boolean canMoveDown = true;
            int col = 0;
            while (canMoveDown && col < 4) {
              int n = 3;
              int bot = -1;
              while (n >= 0 && bot == -1) {
                if (currentPiece[col][n])
                  bot = n; 
                n--;
              } 
              if (bot != -1)
                if (bot + yPiece + 1 < 20) {
                  if (grid[xPiece + col][bot + yPiece + 1] != 0)
                    canMoveDown = false; 
                } else {
                  canMoveDown = false;
                }  
              col++;
            } 
            if (canMoveDown) {
              yPiece++;
              for (int n = 0; n < 4; n++) {
                for (int x = 0; x < 4; x++) {
                  if (currentPiece[x][n])
                    grid[xPiece + x][yPiece + n] = blockColour; 
                } 
              } 
            } else {
              score++;
              levelInc++;
              if (levelInc > 15) {
                level++;
                levelInc = 0;
              } 
              for (int n = 0; n < 4; n++) {
                for (int x = 0; x < 4; x++) {
                  if (currentPiece[x][n])
                    grid[xPiece + x][yPiece + n] = blockColour; 
                } 
              } 
              boolean removed = false;
              for (int i2 = 0; i2 < 20; i2++) {
                boolean filled = true;
                int x;
                for (x = 0; x < 10; x++) {
                  if (grid[x][i2] == 0)
                    filled = false; 
                } 
                if (filled) {
                  removed = true;
                  score += 10;
                  for (x = 0; x < 10; x++)
                    fillStack.add(new Point(x, i2)); 
                  yQueue.add(Integer.valueOf(i2));
                } 
              } 
              if (removed) {
                play("g");
              } else {
                play("삆^");
              } 
              newPiece = true;
            } 
            lastTime_yLevel = System.currentTimeMillis();
          } 
          if (!fillStack.isEmpty()) {
            Point p = fillStack.pop();
            grid[p.x][p.y] = 0;
            if (fillStack.isEmpty()) {
              int k;
              for (k = 0; k < 4; k++) {
                for (int x = 0; x < 4; x++) {
                  if (currentPiece[x][k])
                    grid[xPiece + x][yPiece + k] = 0; 
                } 
              } 
              while (!yQueue.isEmpty()) {
                int y3 = ((Integer)yQueue.poll()).intValue();
                for (int y2 = y3; y2 > 0; y2--) {
                  for (int x = 0; x < 10; x++)
                    grid[x][y2] = grid[x][y2 - 1]; 
                } 
              } 
              for (k = 0; k < 4; k++) {
                for (int x = 0; x < 4; x++) {
                  if (currentPiece[x][k])
                    grid[xPiece + x][yPiece + k] = blockColour; 
                } 
              } 
            } 
          } 
        } 
        g.setColor(new Color(16777215));
        g.fillRect(0, 0, 800, 600);
        yOffset += 0.3F;
        xOffset += 0.3F;
        g.setColor(DARKER);
        int j;
        for (j = 0; j < 15; j++) {
          for (int x = 0; x < 15; x++)
            g.drawOval((int)((x * 50) + xOffset), (int)((j * 50) + yOffset), 25, 25); 
        } 
        if (xOffset > 0.0F) {
          xOffset = -50.0F;
          yOffset = -50.0F;
        } 
        g.setColor(new Color(13421772));
        for (j = 0; j < 20; j++) {
          for (int x = 0; x < 10; x++)
            g.drawRect(105 + 18 * x, 45 + 18 * j, 15, 15); 
        } 
        for (j = 0; j < 20; j++) {
          for (int x = 0; x < 10; x++) {
            if (grid[x][j] != 0) {
              g.setColor(new Color(0));
              g.fillRect(105 + 18 * x - 2, 45 + 18 * j - 2, 20, 20);
              g.setColor(new Color(16777215));
              g.fillRect(105 + 18 * x, 45 + 18 * j, 16, 16);
              g.setColor(new Color(grid[x][j]));
              g.fillRect(105 + 18 * x + 1, 45 + 18 * j + 1, 14, 14);
            } 
          } 
        } 
        g.setColor(new Color(13421772));
        g.drawRect(290, 45, 101, 357);
        g.setColor(new Color(16777215));
        g.drawLine(294, 45, 387, 45);
        g.drawLine(294, 402, 387, 402);
        for (j = 0; j < 4; j++) {
          for (int x = 0; x < 4; x++) {
            g.setColor(new Color(13421772));
            g.drawRect(290 + 18 * x + 16, 195 + 18 * j, 15, 15);
            if (nextPiece[x][j]) {
              g.setColor(new Color(0));
              g.fillRect(290 + 18 * x + 14, 195 + 18 * j - 2, 20, 20);
              g.setColor(new Color(16777215));
              g.fillRect(290 + 18 * x + 16, 195 + 18 * j + 0, 16, 16);
              g.setColor(new Color(nextColour));
              g.fillRect(290 + 18 * x + 17, 195 + 18 * j + 1, 14, 14);
            } 
          } 
        } 
        g.setColor(new Color(13421772));
        g.drawRect(300, 189, 81, 81);
        int l = 100;
        int t = 18;
        int m = 1;
        g.drawString("M", 87, 28);
        if (playMusic)
          g.setColor(new Color(0)); 
        int[] soundXPoints = { 100, 105, 105, 100 };
        int[] soundYPoints = { 22, 19, 28, 25 };
        g.drawPolygon(soundXPoints, soundYPoints, soundXPoints.length);
        g.drawArc(97, 16, 14, 15, -45, 90);
        g.drawArc(101, 13, 15, 21, -45, 90);
        g.setColor(new Color(0));
        g.drawString("Score", 322, 137);
        g.drawString("Level", 322, 300);
        g.setFont(fontMedium);
        g.drawString(String.valueOf(level), (int)(340.0F - 20.0F * Integer.toString(level).length() / 2.0F), 337);
        g.drawString(String.valueOf(score), (int)(340.0F - 20.0F * Integer.toString(score).length() / 2.0F), 174);
        g.setFont(font);
        String piece = pieceNames[curPieceNum];
        g.drawString(String.valueOf(piece), 330 - piece.length() * 5 / 2, 78);
        g.setColor(new Color(0));
        g.drawString("Tetris4k by Elliot Walmsley", 146, 27);
        appletGraphics.drawImage(screen, 0, 0, null);
        if (justEnded) {
          this.cmds.clear();
          play("삄L");
          playedEnding = false;
          justEnded = false;
          sleepTime = System.currentTimeMillis();
        } 
        if (!isActive()) {
          dest.stop();
          dest.close();
          return;
        } 
      } 
      g.setColor(new Color(16777215));
      g.fillRect(0, 0, 500, 470);
      g.setColor(new Color(13421772));
      for (int y = 0; y < 20; y++) {
        for (int x = 0; x < 10; x++)
          g.drawRect(105 + 18 * x, 45 + 18 * y, 15, 15); 
      } 
      g.setColor(new Color(13421772));
      g.drawRect(290, 45, 101, 357);
      g.setColor(new Color(16777215));
      g.drawLine(294, 45, 387, 45);
      g.drawLine(294, 402, 387, 402);
      g.setColor(new Color(0));
      g.drawString("by Elliot Walmsley", 182, 147);
      g.setFont(new Font(courierNew, 1, 64));
      g.drawString("Tetris4k", 80, 127);
      g.setFont(font);
      g.drawString("www.crustycabbage.com", 168, 326);
      g.setFont(fontMedium);
      g.drawString("PRESS ANY KEY TO PLAY", 68, 238);
      g.setFont(font);
      appletGraphics.drawImage(screen, 0, 0, null);
      try {
        Thread.sleep(16L);
      } catch (InterruptedException e1) {
        e1.printStackTrace();
      } 
    } 
  }
  
  public final synchronized void play(String cmd) {
    int step = this.step;
    int chan = 0;
    for (int i = 0; i < cmd.length(); i++) {
      int c = cmd.charAt(i);
      if (c >= 128) {
        chan = c & 0x7;
        step = this.step;
      } else if (c >= 64) {
        this.cmds.add(Integer.valueOf(step << 12 | chan << 8 | c));
      } else {
        step += c;
      } 
    } 
  }
  
  public final float evalEnv(float[] env, float t, float last) {
    int s1 = 1;
    while (s1 < env.length / 2 - 1 && env[s1 * 2] < t)
      s1++; 
    int s0 = s1 - 1;
    s0 *= 2;
    s1 *= 2;
    float dt = (t - env[s0]) / (env[s1] - env[s0]);
    if (dt < 0.0F)
      dt = 0.0F; 
    if (dt > 1.0F)
      dt = 1.0F; 
    return (env[s0 + 1] * (1.0F - dt) + env[s1 + 1] * dt) * 0.1F + last * 0.9F;
  }
  
  public final void processEvent(AWTEvent e) {
    boolean down = false;
    if (((KeyEvent)e).getKeyCode() < 256)
      switch (e.getID()) {
        case 401:
          down = true;
        case 402:
          this.keys[((KeyEvent)e).getKeyCode()] = down;
          break;
      }  
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\sound\T.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */