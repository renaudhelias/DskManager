package jemu.core.device;

public class FileDescriptor {
  public String description;
  
  public String filename;
  
  public String instructions;
  
  public FileDescriptor(String description, String filename, String instructions) {
    this.description = description;
    this.filename = filename;
    this.instructions = instructions;
  }
  
  public String toString() {
    return this.description;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\FileDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */