package jemu.core.device.crtc;

import jemu.core.device.Device;

public abstract class CRTC extends Device {
  protected CRTCListener listener;
  
  public CRTC(String type) {
    super(type);
  }
  
  public void setCRTCListener(CRTCListener listener) {
    this.listener = listener;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\crtc\CRTC.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */