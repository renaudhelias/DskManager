package jemu.core.device.crtc;

public interface CRTCListener {
  void hSyncStart();
  
  void hSyncEnd();
  
  void vDispStart();
  
  void hDispStart();
  
  void vSyncStart();
  
  void vSyncEnd();
  
  void vSync(boolean paramBoolean);
  
  void vSync();
  
  void reset();
  
  void hDispEnd();
  
  void cursor();
  
  boolean getOut();
  
  void modeCheck();
  
  int PEEK(int paramInt);
  
  void POKE(int paramInt1, int paramInt2);
  
  int getScreenMode();
  
  int getHPOS();
  
  int getVPOS();
  
  int getLineNumber();
  
  int[] getField();
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\crtc\CRTCListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */