package jemu.core.device;

import java.awt.EventQueue;
import javax.swing.GroupLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.LayoutStyle;

public class Opening extends JFrame {
  private JLabel jLabel1;
  
  private JLabel jLabel2;
  
  public JProgressBar progress;
  
  public Opening() {
    initComponents();
  }
  
  private void initComponents() {
    this.jLabel1 = new JLabel();
    this.jLabel2 = new JLabel();
    this.progress = new JProgressBar();
    setDefaultCloseOperation(2);
    setTitle("Opening ZIP file...");
    this.jLabel1.setText("Opening file:");
    this.jLabel2.setText("jLabel2");
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.progress, -2, 223, -2)
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.jLabel1)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jLabel2)))
          .addContainerGap(-1, 32767)));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jLabel1)
            .addComponent(this.jLabel2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.progress, -2, -1, -2)
          .addContainerGap(-1, 32767)));
    pack();
  }
  
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new Opening()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\Opening.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */