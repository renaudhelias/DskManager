package jemu.core.device.realtimeclock;

import jemu.core.device.Device;

public class ClockDevice extends Device {
  public ClockDevice(String name) {
    super(name);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\realtimeclock\ClockDevice.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */