package jemu.core.device.realtimeclock;

import jemu.ui.JEMU;

public class SF2Mouse extends ClockDevice {
  int[] controls;
  
  int sequence;
  
  int controlport;
  
  int readport;
  
  int[] controlbyte;
  
  public SF2Mouse() {
    super("Symbiface II Mouse");
    this.controls = new int[] { 0, 0, 0, 0 };
    this.sequence = 0;
    this.controlport = 1;
    this.readport = 255;
    this.controlbyte = new int[] { 2, 1, 0, 0 };
  }
  
  public void writePort(int port, int value) {
    port &= 0xFFFF;
    if (port < 10) {
      this.controls[port] = value;
    } else if (port == 64847) {
      this.readport = value;
    } else {
      this.controlport = value;
    } 
  }
  
  public int readPort(int port) {
    port &= 0xFFFF;
    if (!JEMU.SF2Mouse)
      return 255; 
    if (port == 64847)
      return this.readport; 
    if (port == 64834) {
      int cmd = this.controls[this.sequence];
      this.controls[this.sequence] = 0;
      this.sequence++;
      if (this.sequence > 3)
        this.sequence = 0; 
      return cmd;
    } 
    return 255;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\realtimeclock\SF2Mouse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */