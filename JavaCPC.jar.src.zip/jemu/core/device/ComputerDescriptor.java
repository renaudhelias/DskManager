package jemu.core.device;

public class ComputerDescriptor {
  public String key;
  
  public String name;
  
  public String className;
  
  public ComputerDescriptor(String key, String name, String className) {
    this.key = key;
    this.name = name;
    this.className = className;
  }
  
  public String toString() {
    return this.name;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\ComputerDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */