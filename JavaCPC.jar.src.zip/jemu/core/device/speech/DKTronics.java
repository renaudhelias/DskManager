package jemu.core.device.speech;

import jemu.core.Util;

public class DKTronics extends SpeechDevice {
  public static int LRQ;
  
  protected int SBY;
  
  protected boolean DEBUG = false;
  
  protected int speechCount = 0;
  
  protected int speechlength = 0;
  
  protected int length = 0;
  
  protected int phonemelength = 0;
  
  public boolean doCycle = false;
  
  protected Speech speech = new Speech();
  
  int counter;
  
  public DKTronics() {
    super("DK'Tronics Speech Synthesizer");
    LRQ = 127;
    this.SBY = 0;
  }
  
  public int readPort(int port) {
    if (Speech.enabled && !Speech.SSA) {
      if (this.DEBUG)
        System.out.println("Port read on " + 
            Util.hex((short)port) + " - " + Util.hex((short)(LRQ | this.SBY))); 
      return LRQ | this.SBY;
    } 
    return 255;
  }
  
  public void writePort(int port, int value) {
    if (Speech.enabled && !Speech.SSA) {
      LRQ = 255;
      value &= 0x3F;
      this.speechCount = 0;
      this.doCycle = true;
      this.phonemelength = Speech.lengths[value];
      this.speechlength += this.phonemelength * 256;
      this.length = this.speechlength;
      this.speech.SpeechByte += Util.hex(value).substring(6) + ",";
      if (this.DEBUG)
        System.out.println("Port write to " + Util.hex((short)port) + " - Value:" + Util.hex((short)value)); 
    } 
  }
  
  public void reset() {
    LRQ = 127;
    this.SBY = 0;
    this.speech.SpeechByte = "";
    this.doCycle = false;
  }
  
  public void cycle() {
    if (this.counter == 0)
      this.counter = this.length; 
    if (this.speechCount++ < this.phonemelength) {
      this.SBY = 64;
    } else {
      this.SBY = 0;
    } 
    if (this.speechCount == this.counter && this.SBY == 0) {
      this.counter = 0;
      this.speechlength = 0;
      this.speechCount = 0;
      this.speech.Translate(this.speech.SpeechByte);
      this.doCycle = false;
      this.SBY = 0;
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\speech\DKTronics.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */