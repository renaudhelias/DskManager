package jemu.core.device.speech;

import jemu.core.Util;

public class Speech {
  public static boolean enabled = false;
  
  public static boolean SSA = false;
  
  public static boolean DEBUG = false;
  
  public static int portCount = 0;
  
  public static int[] lengths = new int[] { 
      10, 30, 40, 100, 200, 420, 260, 70, 120, 210, 
      140, 140, 70, 140, 170, 70, 180, 100, 290, 250, 
      280, 70, 100, 100, 100, 180, 120, 130, 80, 180, 
      100, 260, 370, 160, 140, 190, 80, 160, 190, 120, 
      150, 190, 160, 210, 220, 110, 180, 360, 200, 130, 
      190, 160, 300, 240, 240, 90, 190, 180, 330, 290, 
      350, 40, 190, 50, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0 };
  
  SPO256 SPO;
  
  Thread SPEECH;
  
  protected String[] Phoneme;
  
  protected int[] bytes;
  
  public String SpeechByte = "";
  
  public static String output = "";
  
  public String Translate(String input) {
    String out = "";
    if (DEBUG)
      System.out.println("input:" + input); 
    int len = input.length() / 3;
    this.Phoneme = new String[len];
    this.bytes = new int[len];
    int i;
    for (i = 0; i < len; i++) {
      String got = input;
      this.Phoneme[i] = got.substring(0, 2);
      input = input.substring(3);
    } 
    for (i = 0; i < len; i++) {
      try {
        output += Util.hexValue(this.Phoneme[i]);
        switch (Util.hexValue(this.Phoneme[i])) {
          case 0:
            this.Phoneme[i] = "PA1";
            break;
          case 1:
            this.Phoneme[i] = "PA2";
            break;
          case 2:
            this.Phoneme[i] = "PA3";
            break;
          case 3:
            this.Phoneme[i] = "PA4";
            break;
          case 4:
            this.Phoneme[i] = "PA5";
            break;
          case 5:
            this.Phoneme[i] = "OY";
            break;
          case 6:
            this.Phoneme[i] = "AY";
            break;
          case 7:
            this.Phoneme[i] = "EH";
            break;
          case 8:
            this.Phoneme[i] = "KK3";
            break;
          case 9:
            this.Phoneme[i] = "PP";
            break;
          case 10:
            this.Phoneme[i] = "JH";
            break;
          case 11:
            this.Phoneme[i] = "NN1";
            break;
          case 12:
            this.Phoneme[i] = "IH";
            break;
          case 13:
            this.Phoneme[i] = "TT2";
            break;
          case 14:
            this.Phoneme[i] = "RR1";
            break;
          case 15:
            this.Phoneme[i] = "AX";
            break;
          case 16:
            this.Phoneme[i] = "MM";
            break;
          case 17:
            this.Phoneme[i] = "TT1";
            break;
          case 18:
            this.Phoneme[i] = "DH1";
            break;
          case 19:
            this.Phoneme[i] = "IY";
            break;
          case 20:
            this.Phoneme[i] = "EY";
            break;
          case 21:
            this.Phoneme[i] = "DD1";
            break;
          case 22:
            this.Phoneme[i] = "UW1";
            break;
          case 23:
            this.Phoneme[i] = "AO";
            break;
          case 24:
            this.Phoneme[i] = "AA";
            break;
          case 25:
            this.Phoneme[i] = "YY2";
            break;
          case 26:
            this.Phoneme[i] = "AE";
            break;
          case 27:
            this.Phoneme[i] = "HH1";
            break;
          case 28:
            this.Phoneme[i] = "BB1";
            break;
          case 29:
            this.Phoneme[i] = "TH";
            break;
          case 30:
            this.Phoneme[i] = "UH";
            break;
          case 31:
            this.Phoneme[i] = "UW2";
            break;
          case 32:
            this.Phoneme[i] = "AW";
            break;
          case 33:
            this.Phoneme[i] = "DD2";
            break;
          case 34:
            this.Phoneme[i] = "GG3";
            break;
          case 35:
            this.Phoneme[i] = "VV";
            break;
          case 36:
            this.Phoneme[i] = "GG1";
            break;
          case 37:
            this.Phoneme[i] = "SH";
            break;
          case 38:
            this.Phoneme[i] = "ZH";
            break;
          case 39:
            this.Phoneme[i] = "RR2";
            break;
          case 40:
            this.Phoneme[i] = "FF";
            break;
          case 41:
            this.Phoneme[i] = "KK2";
            break;
          case 42:
            this.Phoneme[i] = "KK1";
            break;
          case 43:
            this.Phoneme[i] = "ZZ";
            break;
          case 44:
            this.Phoneme[i] = "NG";
            break;
          case 45:
            this.Phoneme[i] = "LL";
            break;
          case 46:
            this.Phoneme[i] = "WW";
            break;
          case 47:
            this.Phoneme[i] = "XR";
            break;
          case 48:
            this.Phoneme[i] = "WH";
            break;
          case 49:
            this.Phoneme[i] = "YY1";
            break;
          case 50:
            this.Phoneme[i] = "CH";
            break;
          case 51:
            this.Phoneme[i] = "ER1";
            break;
          case 52:
            this.Phoneme[i] = "ER2";
            break;
          case 53:
            this.Phoneme[i] = "OW";
            break;
          case 54:
            this.Phoneme[i] = "DH2";
            break;
          case 55:
            this.Phoneme[i] = "SS";
            break;
          case 56:
            this.Phoneme[i] = "NN2";
            break;
          case 57:
            this.Phoneme[i] = "HH2";
            break;
          case 58:
            this.Phoneme[i] = "OR";
            break;
          case 59:
            this.Phoneme[i] = "AR";
            break;
          case 60:
            this.Phoneme[i] = "YR";
            break;
          case 61:
            this.Phoneme[i] = "GG2";
            break;
          case 62:
            this.Phoneme[i] = "EL";
            break;
          case 63:
            this.Phoneme[i] = "BB2";
            break;
          default:
            this.Phoneme[i] = "ignore";
            break;
        } 
      } catch (Exception exception) {}
    } 
    this.SpeechByte = "";
    out = "|";
    for (i = 0; i < len; i++) {
      if (!this.Phoneme[i].equals("ignore"))
        out = out + this.Phoneme[i] + "|"; 
    } 
    say(out);
    return out;
  }
  
  public void say(final String out) {
    if (DEBUG)
      System.out.println("Saying:" + out); 
    this.SPEECH = new Thread() {
        public void run() {
          Speech.this.SPO = new SPO256();
          Speech.this.SPO.Output(out, Speech.SSA ? 1 : 0);
        }
      };
    this.SPEECH.start();
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\speech\Speech.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */