package jemu.core.device.speech;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.LayoutStyle;

public class Main extends JFrame {
  SPO256 speech;
  
  TextConverter conv;
  
  private JTextPane input;
  
  private JButton jButton1;
  
  private JButton jButton2;
  
  private JCheckBox jCheckBox1;
  
  private JScrollPane jScrollPane1;
  
  private JScrollPane jScrollPane2;
  
  private JTextPane output;
  
  private JCheckBox spell;
  
  public Main() {
    initComponents();
    this.speech = new SPO256();
    this.conv = new TextConverter();
    this.speech.Output("JH|AA|VV|AA|SS|IY|PA3|PP|IY|PA3|SS|IY|PA3|PA4|EH|SS|PA3|PP|IY|PA3|OW|PA3|PA4|TT2|UW2|HH1|AA|NN1|DD1|RR2|EH|DD1|FF|IH|FF|TT2|IY|SS|IH|PA3|KK1|SS|PA4|CH|IH|PP|PA4|RR2|EH|DD1|YY1|PA4|TT2|UW2|PA4|EH|MM|UH|LL|EY|TT2|PA1|PA4", 
        
        this.jCheckBox1.isSelected() ? 1 : 0);
  }
  
  private void initComponents() {
    this.jScrollPane1 = new JScrollPane();
    this.input = new JTextPane();
    this.jButton1 = new JButton();
    this.jButton2 = new JButton();
    this.jScrollPane2 = new JScrollPane();
    this.output = new JTextPane();
    this.spell = new JCheckBox();
    this.jCheckBox1 = new JCheckBox();
    setDefaultCloseOperation(3);
    setTitle("JaSPO-256 v.0.1");
    setResizable(false);
    this.input.setText("JASPO-256 speech for java");
    this.jScrollPane1.setViewportView(this.input);
    this.jButton1.setText("Speak it!");
    this.jButton1.setFocusable(false);
    this.jButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Main.this.jButton1ActionPerformed(evt);
          }
        });
    this.jButton2.setText("Say it!");
    this.jButton2.setFocusable(false);
    this.jButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Main.this.jButton2ActionPerformed(evt);
          }
        });
    this.output.setEditable(false);
    this.jScrollPane2.setViewportView(this.output);
    this.spell.setSelected(true);
    this.spell.setText("Spell capitals");
    this.spell.setFocusable(false);
    this.jCheckBox1.setText("SSA1");
    this.jCheckBox1.setFocusable(false);
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addGap(10, 10, 10)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jScrollPane2)
            .addComponent(this.jScrollPane1)
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.spell, -2, 100, -2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jCheckBox1)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 32, 32767)
              .addComponent(this.jButton2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jButton1)))
          .addContainerGap()));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addGap(11, 11, 11)
          .addComponent(this.jScrollPane1, -2, 150, -2)
          .addGap(10, 10, 10)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jButton2)
            .addComponent(this.spell)
            .addComponent(this.jButton1)
            .addComponent(this.jCheckBox1))
          .addGap(7, 7, 7)
          .addComponent(this.jScrollPane2, -1, 91, 32767)
          .addContainerGap()));
    pack();
  }
  
  private void jButton1ActionPerformed(ActionEvent evt) {
    this.output.setText(this.input.getText());
    this.speech.Output(this.input.getText(), this.jCheckBox1.isSelected() ? 1 : 0);
  }
  
  private void jButton2ActionPerformed(ActionEvent evt) {
    if (!this.spell.isSelected()) {
      s = this.conv.getPhoneWord(this.input.getText().toLowerCase());
    } else {
      s = this.conv.getPhoneWord(this.input.getText());
    } 
    this.speech.Output(s, this.jCheckBox1.isSelected() ? 1 : 0);
    String s = s.replace("|PA4|PA4|PA4|PA4|PA4|PA4|PA4|PA4", "");
    this.output.setText(s);
    System.gc();
  }
  
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new Main()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\speech\Main.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */