package jemu.core.device.speech;

import java.util.StringTokenizer;
import java.util.Vector;

public class TextConverter {
  public Vector getWords(String s) {
    Vector<String> vector = new Vector();
    for (StringTokenizer stringtokenizer = new StringTokenizer(s, "()'\"\\!?{}/-"); stringtokenizer.hasMoreElements(); vector.addElement(stringtokenizer.nextToken().toLowerCase()));
    return vector;
  }
  
  public String getPhoneWord(String s) {
    s = s.replace("ready", "redy");
    s = s.replace("dark", "darck");
    s = s.replace("darkness", "darck ness");
    s = s.replace("heart", "haard");
    s = s.replace("JavaCPC", "javaCPC");
    s = replace(s, "*JASPO*", "JH|AA|SS|PP|OW");
    s = replace(s, "*jaspo*", "JH|AA|SS|PP|OW");
    s = replace(s, "*JaSPO*", "JH|AA|SS|PP|OW");
    s = replace(s, "*A*", "EY|PA3");
    s = replace(s, "*B*", "BB2|IY|PA3");
    s = replace(s, "*C*", "SS|IY|PA3");
    s = replace(s, "*D*", "DD1|IY|PA3");
    s = replace(s, "*E*", "IY|PA3");
    s = replace(s, "*F*", "EH|FF|PA3");
    s = replace(s, "*G*", "JH|IY|PA3");
    s = replace(s, "*H*", "EY|CH|PA3");
    s = replace(s, "*I*", "AY|PA3");
    s = replace(s, "*J*", "JH|EY|PA3");
    s = replace(s, "*K*", "KK1|EY|PA3");
    s = replace(s, "*L*", "EH|LL|PA3");
    s = replace(s, "*M*", "EH|MM|PA3");
    s = replace(s, "*N*", "EH|NG|PA3");
    s = replace(s, "*O*", "OW|PA3");
    s = replace(s, "*P*", "PP|IY|PA3");
    s = replace(s, "*Q*", "KK1|YY2|UW2|PA3");
    s = replace(s, "*R*", "AR|PA3");
    s = replace(s, "*S*", "EH|SS|PA3");
    s = replace(s, "*T*", "TT2|IY|PA3");
    s = replace(s, "*U*", "YY1|UW2|PA3");
    s = replace(s, "*V*", "VV|IY|PA3");
    s = replace(s, "*W*", "DD1|AA|PA2|BB2|EL|YY1|UW2|PA3");
    s = replace(s, "*X*", "EH|KK1|SS|PA3");
    s = replace(s, "*Y*", "WW|AY|PA3");
    s = replace(s, "*Z*", "ZZ|EH|PA2|DD2|PA3");
    s = replace(s, "*while*", "WW|AY|LL");
    s = replace(s, "*whil*", "WW|IH|LL");
    s = replace(s, "*because*", "BB2|IY|KK3|OR|SS");
    s = replace(s, "*1*", "WW|AO|NN1");
    s = replace(s, "*2*", "TT2|UW2");
    s = replace(s, "*3*", "FF|RR1|IY");
    s = replace(s, "*4*", "FF|OR");
    s = replace(s, "*5*", "FF|AY|PA3|VV");
    s = replace(s, "*6*", "SS|IH|PA3|KK1|SS");
    s = replace(s, "*7*", "SS|EH|PA3|VV|NN1");
    s = replace(s, "*8*", "EY|PA3|TT2");
    s = replace(s, "*9*", "NN2|AY|NN1");
    s = replace(s, "*0*", "ZZ|IH|RR2|OW");
    s = replace(s, "*their*", "TH|EH|ER2");
    s = replace(s, "*you*", "YY1|UW2");
    s = replace(s, "*measure*", "MM|EY|SH|OR");
    s = replace(s, "*measur*", "MM|EY|SS|OR");
    s = replace(s, "*human*", "HH1|IY|UW2|MM|AA|NN1");
    s = replace(s, "*world*", "WW|OR|LL|DD1");
    s = replace(s, "*year*", "YY1|IY|XR");
    s = replace(s, "*cent*", "SS|EH|NN1|TT2");
    s = replace(s, "*being*", "BB2|IH|IH|NG");
    s = replace(s, "*ever*", "EH|PA3|VV|ER2");
    s = replace(s, "*application*", "AA|PP|LL|IH|KK3|EY|SH|AX|NN1");
    s = replace(s, "*evel*", "IY|PA3|VV|EH|LL");
    s = replace(s, "*evil*", "IY|PA3|VV|IH|LL");
    s = replace(s, "*ted*", "TT2|EH|DD1");
    s = replace(s, "*want*", "WW|AA|NN1|TT2");
    s = replace(s, "*charac*", "KK1|AE|RR2|AA|KK3");
    s = replace(s, "*chine*", "CH|AY|NN1");
    s = replace(s, "*have*", "HH1|AE|PA3|VV");
    s = replace(s, "*over*", "OW|PA3|VV|ER2");
    s = replace(s, "*ing*", "IH|NG");
    s = replace(s, "*ince*", "IH|NN1|SS");
    s = replace(s, "*nce*", "NN1|SS");
    s = replace(s, "*ed", "EH|DD1");
    s = replace(s, "*thought*", "TH|OW|TT2");
    s = replace(s, "*though*", "TH|OW");
    s = replace(s, "*through*", "TH|RR2|UW2");
    s = replace(s, "*drought*", "DD2|RR2|OR|TT2");
    s = replace(s, "*brought*", "BB2|RR2|OR|TT2");
    s = replace(s, "*rough*", "|RR2|AX|FF");
    s = replace(s, "*ough*", "AW|PA1|HH1");
    s = replace(s, "*mould*", "MM|UH|PA2|DD2");
    s = replace(s, "*ould*", "UH|PA2|DD2");
    s = replace(s, "*uild*", "UW2|LL|DD1");
    s = replace(s, "*eicest*", "SS|EH|SS|TT2");
    s = replace(s, "*icest*", "AY|SS|EH|SS|TT2");
    s = replace(s, "*igh*", "AY");
    s = replace(s, "*cause*", "KK3|OR|SS");
    s = replace(s, "*aus*", "OR|SS");
    s = replace(s, "*cial*", "SS|AY|LL");
    s = replace(s, "*tia*", "TT2|YR");
    s = replace(s, "*tio*", "TT2|AY");
    s = replace(s, "*one*", "WW|AO|NN1");
    s = replace(s, "*lly*", "LL|IY");
    s = replace(s, "*dis*", "DD1|IH|SS");
    s = replace(s, "*que*", "KK2|WW");
    s = replace(s, "*qu*", "KK2|WW");
    s = replace(s, "*sky*", "SS|KK2|AY");
    s = replace(s, "*fly*", "FF|LL|AY");
    s = replace(s, "*ly*", "LL|IY");
    s = replace(s, "*than*", "TH|AA|NN1");
    s = replace(s, "*that*", "TH|AA|TT2");
    s = replace(s, "*thee*", "TH|IY");
    s = replace(s, "*the*", "TH|AX");
    s = replace(s, "*them*", "TH|EH|MM");
    s = replace(s, "*thence*", "TH|EH|NN1|SS");
    s = replace(s, "*then*", "TH|EH|NN1");
    s = replace(s, "*there*", "TH|XR");
    s = replace(s, "*they*", "TH|AY");
    s = replace(s, "*this*", "TH|IH|SS");
    s = replace(s, "*thus*", "TH|AX|SS");
    s = replace(s, "*abe*", "EY|BB1");
    s = replace(s, "*ace*", "EY|PA2|SS");
    s = replace(s, "*ade*", "EY|DD1");
    s = replace(s, "*afe*", "EY|FF");
    s = replace(s, "*age*", "EY|PA2|JH");
    s = replace(s, "*ake*", "EY|PA3|KK1");
    s = replace(s, "*ale*", "EY|LL");
    s = replace(s, "*ame*", "EY|MM");
    s = replace(s, "*ane*", "EY|NN1");
    s = replace(s, "*ape*", "EY|PP");
    s = replace(s, "*ase*", "EY|SS");
    s = replace(s, "*aze*", "EY|ZZ");
    s = replace(s, "*ate*", "EY|TT2|PA1");
    s = replace(s, "*ave*", "EY|PA3|VV");
    s = replace(s, "*azy*", "AA|ZZ|IY");
    s = replace(s, "*ede*", "IY|DD1");
    s = replace(s, "*eke*", "IY|PA3|KK1");
    s = replace(s, "*eme*", "IY|MM");
    s = replace(s, "*ere*", "IY|RR2");
    s = replace(s, "*ese*", "IY|SS");
    s = replace(s, "*ete*", "IY|TT2");
    s = replace(s, "*iev*", "IH|EH|PA3|VV");
    s = replace(s, "*eve*", "IY|PA3|VV");
    s = replace(s, "*eze*", "IY|ZZ");
    s = replace(s, "*ibe*", "AY|PA2|BB2");
    s = replace(s, "*ice*", "AY|SS|SS");
    s = replace(s, "*ide*", "AY|DD1");
    s = replace(s, "*ife*", "AY|FF");
    s = replace(s, "*ige*", "IH|PA3|GG3");
    s = replace(s, "*ike*", "AY|KK2");
    s = replace(s, "*ile*", "AY|LL");
    s = replace(s, "*ime*", "AY|MM");
    s = replace(s, "*ine*", "AY|NN1");
    s = replace(s, "*ipe*", "AY|PP");
    s = replace(s, "*ire*", "AY|RR2");
    s = replace(s, "*ise*", "AY|SS");
    s = replace(s, "*ite*", "AY|TT2");
    s = replace(s, "*usive*", "UW1|SS|IH|PA3|VV");
    s = replace(s, "*asive*", "EY|SS|IH|PA3|VV");
    s = replace(s, "*ive*", "AY|PA3|VV");
    s = replace(s, "*ize*", "AY|ZZ");
    s = replace(s, "*obe*", "OW|PA2|BB2");
    s = replace(s, "*ode*", "OW|DD1");
    s = replace(s, "*oke*", "OW|PA2|KK1");
    s = replace(s, "*ole*", "OW|LL");
    s = replace(s, "*ome*", "OW|MM");
    s = replace(s, "*one*", "OW|NN1");
    s = replace(s, "*ope*", "OW|PP");
    s = replace(s, "*ore*", "OR");
    s = replace(s, "*pn*", "NN1");
    s = replace(s, "*kn*", "NN1");
    s = replace(s, "*th*", "TH");
    s = replace(s, "*ch*", "CH");
    s = replace(s, "*sh*", "SH");
    s = replace(s, "*ck*", "KK2");
    s = replace(s, "*or*", "OR");
    s = replace(s, "*ose*", "OW|SS");
    s = replace(s, "*ote*", "OW|TT2");
    s = replace(s, "*ove*", "OW|PA3|VV");
    s = replace(s, "*owe*", "OW");
    s = replace(s, "*oze*", "OW|ZZ");
    s = replace(s, "*ube*", "UW1|PA2|BB2");
    s = replace(s, "*uce*", "UW1|SS|SS");
    s = replace(s, "*ude*", "UW1|DD1");
    s = replace(s, "*uge*", "UW1|PA2|JH");
    s = replace(s, "*uke*", "UW1|PA3|KK1");
    s = replace(s, "*ule*", "UW1|LL");
    s = replace(s, "*ume*", "UW1|MM");
    s = replace(s, "*une*", "UW1|NN1");
    s = replace(s, "*upe*", "UW1|PP");
    s = replace(s, "*ure*", "UW1|RR2");
    s = replace(s, "*usa*", "AX|SS|AA");
    s = replace(s, "use*", "YY1|UW2|SS");
    s = replace(s, "*use*", "UW1|SS");
    s = replace(s, "usu*", "YY1|UW2|SS|YY1|UH");
    s = replace(s, "*ute*", "UW1|TT2");
    s = replace(s, "*uze*", "UW1|ZZ");
    s = replace(s, "*air*", "EH|XR");
    s = replace(s, "*all *", "OR|LL|PA4");
    s = replace(s, "*all*", "AA|LL");
    s = replace(s, "*aria*", "EY|RR2|YR");
    s = replace(s, "*imple*", "IH|MM|PP|LL");
    s = replace(s, "*ear*", "IY|XR");
    s = replace(s, "*eat*", "EY|TT2");
    s = replace(s, "*ar*", "AR");
    s = replace(s, "*ic*", "IH|KK3");
    s = replace(s, "*er*", "ER2");
    s = replace(s, "*ew*", "YY1|UW2");
    s = replace(s, "*ind*", "IH|NN1|DD1");
    s = replace(s, "*ow*", "OW");
    s = replace(s, "*aa*", "AA|AR");
    s = replace(s, "*ae*", "AA|AE");
    s = replace(s, "*ai*", "EY");
    s = replace(s, "*au*", "OR");
    s = replace(s, "*ea*", "IY|AA");
    s = replace(s, "*ee*", "IY");
    s = replace(s, "*ei*", "EH|IH");
    s = replace(s, "*eo*", "EH|OW");
    s = replace(s, "*eu*", "YY1|UW2");
    s = replace(s, "*ia*", "YR");
    s = replace(s, "*ie*", "IY");
    s = replace(s, "*is*", "IH|SS");
    s = replace(s, "*io*", "ee|oo");
    s = replace(s, "*oa*", "OW");
    s = replace(s, "*oe*", "OW");
    s = replace(s, "*oi*", "OY");
    s = replace(s, "*oo*", "UW2");
    s = replace(s, "*ou*", "AW");
    s = replace(s, "*ua*", "AX|AE");
    s = replace(s, "*ue*", "UW2");
    s = replace(s, "*ui*", "UW2");
    s = replace(s, "*bb*", "BB2");
    s = replace(s, "*cc*", "KK1|SS");
    s = replace(s, "*dd*", "DD");
    s = replace(s, "*ff*", "FF");
    s = replace(s, "*gg*", "GG1");
    s = replace(s, "*ll*", "LL");
    s = replace(s, "*mm*", "MM");
    s = replace(s, "*nn*", "NN1");
    s = replace(s, "*pp*", "PP");
    s = replace(s, "*ss*", "SS");
    s = replace(s, "*tt*", "TT1");
    s = replace(s, "*zz*", "ZZ");
    s = replace(s, "*my*", "MM|AY");
    s = replace(s, "*we*", "WW|IY");
    s = replace(s, "*to*", "TT2|UW2");
    s = replace(s, "*or*", "OR");
    s = replace(s, "ok", "OW|KK1|EY");
    s = replace(s, "* ok *", "OW|KK1|EY");
    s = replace(s, "* ok", "OW|KK1|EY");
    s = replace(s, "*y*", "YY1");
    s = replace(s, "*a*", "AA");
    s = replace(s, "*ä*", "AE");
    s = replace(s, "*ö*", "AO");
    s = replace(s, "*ü*", "YY1");
    s = replace(s, "*ß*", "SS|PA1");
    s = replace(s, "*e", "PA3");
    s = replace(s, "*e*", "EH");
    s = replace(s, "i*", "AY|PA3");
    s = replace(s, "* i *", "PA4|AY|PA4");
    s = replace(s, "*i*", "IH");
    s = replace(s, "*o*", "OW");
    s = replace(s, "*q*", "KK2|WW");
    s = replace(s, "*u*", "UH");
    s = replace(s, "*b*", "BB2");
    s = replace(s, "c*", "KK2");
    s = replace(s, "*c*", "SS");
    s = replace(s, "d*", "DD1");
    s = replace(s, "*d", "DD1");
    s = replace(s, "*ds", "d|z");
    s = replace(s, "*d*", "DD1");
    s = replace(s, "*f*", "FF");
    s = replace(s, "*g*", "GG1");
    s = replace(s, "*h*", "HH1");
    s = replace(s, "*j*", "JH");
    s = replace(s, "*k*", "KK1");
    s = replace(s, "l*", "LL");
    s = replace(s, "*l*", "LL");
    s = replace(s, "*m*", "MM");
    s = replace(s, "*n*", "NN1");
    s = replace(s, "*p*", "PP");
    s = replace(s, "*r*", "RR2");
    s = replace(s, "*s*", "SS");
    s = replace(s, "*t*", "TT1");
    s = replace(s, "*v*", "VV");
    s = replace(s, "*w*", "WW");
    s = replace(s, "*x*", "KK3|SS");
    s = replace(s, "*z*", "ZZ");
    s = replace(s, "* *", "PA4");
    s = replace(s, "*.*", "PA4");
    s = replace(s, "*,*", "PA4");
    s = replace(s, "*;*", "PA4");
    s = replace(s, "*:*", "PA4");
    s = replace(s, "*-*", "PA3");
    String s1 = "";
    for (StringTokenizer stringtokenizer = new StringTokenizer(s, "[]"); stringtokenizer.hasMoreTokens(); ) {
      s1 = s1 + stringtokenizer.nextToken();
      if (stringtokenizer.hasMoreTokens())
        s1 = s1 + "|"; 
    } 
    return s1 + "|PA4|PA4|PA4|PA4|PA4|PA4|PA4|PA4";
  }
  
  private String replace(String s, String s1, String s2) {
    String s3 = s;
    if (s1.startsWith("*") && s1.endsWith("*")) {
      boolean flag = false;
      s1 = s1.substring(1, s1.length() - 1);
      int i = 0;
      boolean flag1 = true;
      while (flag1) {
        int j = s.indexOf(s1, i);
        if (j >= 0) {
          boolean flag2 = true;
          for (int k = j; k >= 0; k--) {
            String s4 = s.substring(k, k + 1);
            if (s4.equals("[")) {
              flag2 = false;
              break;
            } 
            if (s4.equals("]"))
              break; 
          } 
          if (flag2) {
            s3 = "";
            if (j > 0)
              s3 = s3 + s.substring(0, j); 
            s3 = s3 + "[" + s2 + "]";
            if (j + s1.length() < s.length())
              s3 = s3 + s.substring(j + s1.length(), s.length()); 
            flag1 = false;
            flag = true;
            continue;
          } 
          i = j + 1;
          continue;
        } 
        flag1 = false;
      } 
      if (flag)
        s3 = replace(s3, "*" + s1 + "*", s2); 
    } else if (s1.endsWith("*")) {
      s1 = s1.substring(0, s1.length() - 1);
      if (s.startsWith(s1))
        s3 = "[" + s2 + "]" + s.substring(s1.length(), s.length()); 
    } else if (s1.startsWith("*")) {
      s1 = s1.substring(1, s1.length());
      if (s.endsWith(s1))
        s3 = s.substring(0, s.length() - s1.length()) + "[" + s2 + "]"; 
    } else if (s.equals(s1)) {
      s3 = "[" + s2 + "]";
    } 
    return s3;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\speech\TextConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */