package jemu.core.device.internalfilesystem;

import java.awt.image.BufferedImage;
import java.awt.image.IndexColorModel;
import java.awt.image.WritableRaster;
import java.util.zip.CRC32;

class BeauchampEncoder {
  public static final boolean ENCODE_ALPHA = true;
  
  public static final boolean NO_ALPHA = false;
  
  public static final int FILTER_NONE = 0;
  
  public static final int FILTER_SUB = 1;
  
  public static final int FILTER_UP = 2;
  
  public static final int FILTER_LAST = 2;
  
  protected byte[] pngBytes;
  
  protected byte[] priorRow;
  
  protected byte[] leftBytes;
  
  protected int width;
  
  protected int height;
  
  protected int bytePos;
  
  protected int maxPos;
  
  protected int hdrPos;
  
  protected int dataPos;
  
  protected int endPos;
  
  protected CRC32 crc;
  
  protected long crcValue;
  
  protected boolean encodeAlpha;
  
  protected int filter;
  
  protected int bytesPerPixel;
  
  protected int compressionLevel;
  
  protected BufferedImage image;
  
  protected WritableRaster wRaster;
  
  protected int tType;
  
  public BeauchampEncoder() {
    this(null, false, 0, 0);
  }
  
  public BeauchampEncoder(BufferedImage bufferedimage) {
    this(bufferedimage, false, 0, 0);
  }
  
  public BeauchampEncoder(BufferedImage bufferedimage, boolean flag) {
    this(bufferedimage, flag, 0, 0);
  }
  
  public BeauchampEncoder(BufferedImage bufferedimage, boolean flag, int i) {
    this(bufferedimage, flag, i, 0);
  }
  
  public BeauchampEncoder(BufferedImage bufferedimage, boolean flag, int i, int j) {
    this.crc = new CRC32();
    this.encodeAlpha = flag;
    setFilter(i);
    if (j >= 0 && j <= 9)
      this.compressionLevel = j; 
    this.image = bufferedimage;
  }
  
  protected boolean establishStorageInfo() {
    this.wRaster = this.image.getRaster();
    int i = this.wRaster.getNumDataElements();
    this.tType = this.wRaster.getTransferType();
    if ((this.tType == 0 && i == 4) || (this.tType == 3 && i == 1)) {
      this.bytesPerPixel = this.encodeAlpha ? 4 : 3;
    } else if (this.tType == 0 && i == 1) {
      this.bytesPerPixel = 1;
      this.encodeAlpha = false;
    } else {
      return false;
    } 
    return true;
  }
  
  public byte[] pngEncode() {
    return pngEncode(this.encodeAlpha);
  }
  
  public byte[] pngEncode(boolean flag) {
    byte[] abyte0 = { -119, 80, 78, 71, 13, 10, 26, 10 };
    if (this.image == null)
      return null; 
    this.width = this.image.getWidth(null);
    this.height = this.image.getHeight(null);
    this.image = this.image;
    if (!establishStorageInfo())
      return null; 
    this.pngBytes = new byte[(this.width + 1) * this.height * 3 + 200];
    this.maxPos = 0;
    this.bytePos = writeBytes(abyte0, 0);
    this.hdrPos = this.bytePos;
    writeHeader();
    this.dataPos = this.bytePos;
    if (writeImageData()) {
      writeEnd();
      this.pngBytes = resizeByteArray(this.pngBytes, this.maxPos);
    } else {
      this.pngBytes = null;
    } 
    return this.pngBytes;
  }
  
  public void setImage(BufferedImage bufferedimage) {
    this.image = bufferedimage;
    this.pngBytes = null;
  }
  
  protected void writeHeader() {
    int i = this.bytePos = writeInt4(13, this.bytePos);
    this.bytePos = writeString("IHDR", this.bytePos);
    this.width = this.image.getWidth(null);
    this.height = this.image.getHeight(null);
    this.bytePos = writeInt4(this.width, this.bytePos);
    this.bytePos = writeInt4(this.height, this.bytePos);
    this.bytePos = writeByte(8, this.bytePos);
    if (this.bytesPerPixel != 1) {
      this.bytePos = writeByte(this.encodeAlpha ? 6 : 2, this.bytePos);
    } else {
      this.bytePos = writeByte(3, this.bytePos);
    } 
    this.bytePos = writeByte(0, this.bytePos);
    this.bytePos = writeByte(0, this.bytePos);
    this.bytePos = writeByte(0, this.bytePos);
    this.crc.reset();
    this.crc.update(this.pngBytes, i, this.bytePos - i);
    this.crcValue = this.crc.getValue();
    this.bytePos = writeInt4((int)this.crcValue, this.bytePos);
  }
  
  protected boolean writeImageData() {
    // Byte code:
    //   0: aload_0
    //   1: getfield height : I
    //   4: istore_1
    //   5: iconst_0
    //   6: istore_2
    //   7: new java/util/zip/Deflater
    //   10: dup
    //   11: aload_0
    //   12: getfield compressionLevel : I
    //   15: invokespecial <init> : (I)V
    //   18: astore_3
    //   19: new java/io/ByteArrayOutputStream
    //   22: dup
    //   23: sipush #1024
    //   26: invokespecial <init> : (I)V
    //   29: astore #4
    //   31: new java/util/zip/DeflaterOutputStream
    //   34: dup
    //   35: aload #4
    //   37: aload_3
    //   38: invokespecial <init> : (Ljava/io/OutputStream;Ljava/util/zip/Deflater;)V
    //   41: astore #5
    //   43: aload_0
    //   44: getfield bytesPerPixel : I
    //   47: iconst_1
    //   48: if_icmpne -> 65
    //   51: aload_0
    //   52: aload_0
    //   53: getfield image : Ljava/awt/image/BufferedImage;
    //   56: invokevirtual getColorModel : ()Ljava/awt/image/ColorModel;
    //   59: checkcast java/awt/image/IndexColorModel
    //   62: invokevirtual writePalette : (Ljava/awt/image/IndexColorModel;)V
    //   65: iload_1
    //   66: ifle -> 560
    //   69: sipush #32767
    //   72: aload_0
    //   73: getfield width : I
    //   76: aload_0
    //   77: getfield bytesPerPixel : I
    //   80: iconst_1
    //   81: iadd
    //   82: imul
    //   83: idiv
    //   84: iload_1
    //   85: invokestatic min : (II)I
    //   88: istore #6
    //   90: aload_0
    //   91: getfield width : I
    //   94: iload #6
    //   96: imul
    //   97: aload_0
    //   98: getfield bytesPerPixel : I
    //   101: imul
    //   102: iload #6
    //   104: iadd
    //   105: newarray byte
    //   107: astore #7
    //   109: aload_0
    //   110: getfield filter : I
    //   113: iconst_1
    //   114: if_icmpne -> 125
    //   117: aload_0
    //   118: bipush #16
    //   120: newarray byte
    //   122: putfield leftBytes : [B
    //   125: aload_0
    //   126: getfield filter : I
    //   129: iconst_2
    //   130: if_icmpne -> 148
    //   133: aload_0
    //   134: aload_0
    //   135: getfield width : I
    //   138: aload_0
    //   139: getfield bytesPerPixel : I
    //   142: imul
    //   143: newarray byte
    //   145: putfield priorRow : [B
    //   148: aload_0
    //   149: getfield tType : I
    //   152: ifne -> 185
    //   155: aload_0
    //   156: getfield wRaster : Ljava/awt/image/WritableRaster;
    //   159: iconst_0
    //   160: iload_2
    //   161: aload_0
    //   162: getfield width : I
    //   165: iload #6
    //   167: aconst_null
    //   168: invokevirtual getDataElements : (IIIILjava/lang/Object;)Ljava/lang/Object;
    //   171: checkcast [B
    //   174: checkcast [B
    //   177: astore #8
    //   179: aconst_null
    //   180: astore #9
    //   182: goto -> 212
    //   185: aload_0
    //   186: getfield wRaster : Ljava/awt/image/WritableRaster;
    //   189: iconst_0
    //   190: iload_2
    //   191: aload_0
    //   192: getfield width : I
    //   195: iload #6
    //   197: aconst_null
    //   198: invokevirtual getDataElements : (IIIILjava/lang/Object;)Ljava/lang/Object;
    //   201: checkcast [I
    //   204: checkcast [I
    //   207: astore #9
    //   209: aconst_null
    //   210: astore #8
    //   212: iconst_0
    //   213: istore #10
    //   215: iconst_0
    //   216: istore #11
    //   218: iconst_1
    //   219: istore #12
    //   221: iconst_0
    //   222: istore #13
    //   224: iload #13
    //   226: aload_0
    //   227: getfield width : I
    //   230: iload #6
    //   232: imul
    //   233: if_icmpge -> 537
    //   236: iload #13
    //   238: aload_0
    //   239: getfield width : I
    //   242: irem
    //   243: ifne -> 263
    //   246: aload #7
    //   248: iload #10
    //   250: iinc #10, 1
    //   253: aload_0
    //   254: getfield filter : I
    //   257: i2b
    //   258: bastore
    //   259: iload #10
    //   261: istore #12
    //   263: aload_0
    //   264: getfield bytesPerPixel : I
    //   267: iconst_1
    //   268: if_icmpne -> 290
    //   271: aload #7
    //   273: iload #10
    //   275: iinc #10, 1
    //   278: aload #8
    //   280: iload #11
    //   282: iinc #11, 1
    //   285: baload
    //   286: bastore
    //   287: goto -> 468
    //   290: aload_0
    //   291: getfield tType : I
    //   294: ifne -> 377
    //   297: aload #7
    //   299: iload #10
    //   301: iinc #10, 1
    //   304: aload #8
    //   306: iload #11
    //   308: iinc #11, 1
    //   311: baload
    //   312: bastore
    //   313: aload #7
    //   315: iload #10
    //   317: iinc #10, 1
    //   320: aload #8
    //   322: iload #11
    //   324: iinc #11, 1
    //   327: baload
    //   328: bastore
    //   329: aload #7
    //   331: iload #10
    //   333: iinc #10, 1
    //   336: aload #8
    //   338: iload #11
    //   340: iinc #11, 1
    //   343: baload
    //   344: bastore
    //   345: aload_0
    //   346: getfield encodeAlpha : Z
    //   349: ifeq -> 371
    //   352: aload #7
    //   354: iload #10
    //   356: iinc #10, 1
    //   359: aload #8
    //   361: iload #11
    //   363: iinc #11, 1
    //   366: baload
    //   367: bastore
    //   368: goto -> 468
    //   371: iinc #11, 1
    //   374: goto -> 468
    //   377: aload #7
    //   379: iload #10
    //   381: iinc #10, 1
    //   384: aload #9
    //   386: iload #11
    //   388: iaload
    //   389: bipush #16
    //   391: ishr
    //   392: sipush #255
    //   395: iand
    //   396: i2b
    //   397: bastore
    //   398: aload #7
    //   400: iload #10
    //   402: iinc #10, 1
    //   405: aload #9
    //   407: iload #11
    //   409: iaload
    //   410: bipush #8
    //   412: ishr
    //   413: sipush #255
    //   416: iand
    //   417: i2b
    //   418: bastore
    //   419: aload #7
    //   421: iload #10
    //   423: iinc #10, 1
    //   426: aload #9
    //   428: iload #11
    //   430: iaload
    //   431: sipush #255
    //   434: iand
    //   435: i2b
    //   436: bastore
    //   437: aload_0
    //   438: getfield encodeAlpha : Z
    //   441: ifeq -> 465
    //   444: aload #7
    //   446: iload #10
    //   448: iinc #10, 1
    //   451: aload #9
    //   453: iload #11
    //   455: iaload
    //   456: bipush #24
    //   458: ishr
    //   459: sipush #255
    //   462: iand
    //   463: i2b
    //   464: bastore
    //   465: iinc #11, 1
    //   468: iload #13
    //   470: aload_0
    //   471: getfield width : I
    //   474: irem
    //   475: aload_0
    //   476: getfield width : I
    //   479: iconst_1
    //   480: isub
    //   481: if_icmpne -> 531
    //   484: aload_0
    //   485: getfield filter : I
    //   488: ifeq -> 531
    //   491: aload_0
    //   492: getfield filter : I
    //   495: iconst_1
    //   496: if_icmpne -> 511
    //   499: aload_0
    //   500: aload #7
    //   502: iload #12
    //   504: aload_0
    //   505: getfield width : I
    //   508: invokevirtual filterSub : ([BII)V
    //   511: aload_0
    //   512: getfield filter : I
    //   515: iconst_2
    //   516: if_icmpne -> 531
    //   519: aload_0
    //   520: aload #7
    //   522: iload #12
    //   524: aload_0
    //   525: getfield width : I
    //   528: invokevirtual filterUp : ([BII)V
    //   531: iinc #13, 1
    //   534: goto -> 224
    //   537: aload #5
    //   539: aload #7
    //   541: iconst_0
    //   542: iload #10
    //   544: invokevirtual write : ([BII)V
    //   547: iload_2
    //   548: iload #6
    //   550: iadd
    //   551: istore_2
    //   552: iload_1
    //   553: iload #6
    //   555: isub
    //   556: istore_1
    //   557: goto -> 65
    //   560: aload #5
    //   562: invokevirtual close : ()V
    //   565: aload #4
    //   567: invokevirtual toByteArray : ()[B
    //   570: astore #7
    //   572: aload #7
    //   574: arraylength
    //   575: istore #8
    //   577: aload_0
    //   578: getfield crc : Ljava/util/zip/CRC32;
    //   581: invokevirtual reset : ()V
    //   584: aload_0
    //   585: aload_0
    //   586: iload #8
    //   588: aload_0
    //   589: getfield bytePos : I
    //   592: invokevirtual writeInt4 : (II)I
    //   595: putfield bytePos : I
    //   598: aload_0
    //   599: aload_0
    //   600: ldc 'IDAT'
    //   602: aload_0
    //   603: getfield bytePos : I
    //   606: invokevirtual writeString : (Ljava/lang/String;I)I
    //   609: putfield bytePos : I
    //   612: aload_0
    //   613: getfield crc : Ljava/util/zip/CRC32;
    //   616: ldc 'IDAT'
    //   618: invokevirtual getBytes : ()[B
    //   621: invokevirtual update : ([B)V
    //   624: aload_0
    //   625: aload_0
    //   626: aload #7
    //   628: iload #8
    //   630: aload_0
    //   631: getfield bytePos : I
    //   634: invokevirtual writeBytes : ([BII)I
    //   637: putfield bytePos : I
    //   640: aload_0
    //   641: getfield crc : Ljava/util/zip/CRC32;
    //   644: aload #7
    //   646: iconst_0
    //   647: iload #8
    //   649: invokevirtual update : ([BII)V
    //   652: aload_0
    //   653: aload_0
    //   654: getfield crc : Ljava/util/zip/CRC32;
    //   657: invokevirtual getValue : ()J
    //   660: putfield crcValue : J
    //   663: aload_0
    //   664: aload_0
    //   665: aload_0
    //   666: getfield crcValue : J
    //   669: l2i
    //   670: aload_0
    //   671: getfield bytePos : I
    //   674: invokevirtual writeInt4 : (II)I
    //   677: putfield bytePos : I
    //   680: aload_3
    //   681: invokevirtual finish : ()V
    //   684: iconst_1
    //   685: ireturn
    //   686: astore #6
    //   688: getstatic java/lang/System.err : Ljava/io/PrintStream;
    //   691: aload #6
    //   693: invokevirtual toString : ()Ljava/lang/String;
    //   696: invokevirtual println : (Ljava/lang/String;)V
    //   699: iconst_0
    //   700: ireturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #155	-> 0
    //   #156	-> 5
    //   #157	-> 7
    //   #158	-> 19
    //   #159	-> 31
    //   #160	-> 43
    //   #161	-> 51
    //   #165	-> 65
    //   #167	-> 69
    //   #168	-> 90
    //   #169	-> 109
    //   #170	-> 117
    //   #171	-> 125
    //   #172	-> 133
    //   #175	-> 148
    //   #177	-> 155
    //   #178	-> 179
    //   #181	-> 185
    //   #182	-> 209
    //   #184	-> 212
    //   #185	-> 215
    //   #186	-> 218
    //   #187	-> 221
    //   #189	-> 236
    //   #191	-> 246
    //   #192	-> 259
    //   #194	-> 263
    //   #195	-> 271
    //   #197	-> 290
    //   #199	-> 297
    //   #200	-> 313
    //   #201	-> 329
    //   #202	-> 345
    //   #203	-> 352
    //   #205	-> 371
    //   #208	-> 377
    //   #209	-> 398
    //   #210	-> 419
    //   #211	-> 437
    //   #212	-> 444
    //   #213	-> 465
    //   #215	-> 468
    //   #217	-> 491
    //   #218	-> 499
    //   #219	-> 511
    //   #220	-> 519
    //   #187	-> 531
    //   #224	-> 537
    //   #225	-> 547
    //   #165	-> 552
    //   #228	-> 560
    //   #229	-> 565
    //   #230	-> 572
    //   #231	-> 577
    //   #232	-> 584
    //   #233	-> 598
    //   #234	-> 612
    //   #235	-> 624
    //   #236	-> 640
    //   #237	-> 652
    //   #238	-> 663
    //   #239	-> 680
    //   #240	-> 684
    //   #242	-> 686
    //   #244	-> 688
    //   #246	-> 699
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   179	6	8	abyte2	[B
    //   182	3	9	ai	[I
    //   224	313	13	l1	I
    //   109	443	7	abyte0	[B
    //   212	340	8	abyte2	[B
    //   209	343	9	ai	[I
    //   215	337	10	l	I
    //   218	334	11	j1	I
    //   221	331	12	i1	I
    //   90	470	6	k	I
    //   572	114	7	abyte1	[B
    //   577	109	8	k1	I
    //   688	11	6	ioexception	Ljava/io/IOException;
    //   0	701	0	this	Ljemu/core/device/internalfilesystem/BeauchampEncoder;
    //   5	696	1	i	I
    //   7	694	2	j	I
    //   19	682	3	deflater	Ljava/util/zip/Deflater;
    //   31	670	4	bytearrayoutputstream	Ljava/io/ByteArrayOutputStream;
    //   43	658	5	deflateroutputstream	Ljava/util/zip/DeflaterOutputStream;
    // Exception table:
    //   from	to	target	type
    //   65	685	686	java/io/IOException
  }
  
  protected void writePalette(IndexColorModel indexcolormodel) {
    byte[] abyte0 = new byte[256];
    byte[] abyte1 = new byte[256];
    byte[] abyte2 = new byte[256];
    byte[] abyte3 = new byte[768];
    indexcolormodel.getReds(abyte0);
    indexcolormodel.getGreens(abyte1);
    indexcolormodel.getBlues(abyte2);
    for (int i = 0; i < 256; i++) {
      abyte3[i * 3] = abyte0[i];
      abyte3[i * 3 + 1] = abyte1[i];
      abyte3[i * 3 + 2] = abyte2[i];
    } 
    this.bytePos = writeInt4(768, this.bytePos);
    this.bytePos = writeString("PLTE", this.bytePos);
    this.crc.reset();
    this.crc.update("PLTE".getBytes());
    this.bytePos = writeBytes(abyte3, this.bytePos);
    this.crc.update(abyte3);
    this.crcValue = this.crc.getValue();
    this.bytePos = writeInt4((int)this.crcValue, this.bytePos);
  }
  
  protected void filterSub(byte[] abyte0, int i, int j) {
    int l = this.bytesPerPixel;
    int i1 = i + l;
    int j1 = j * this.bytesPerPixel;
    int k1 = l;
    int l1 = 0;
    for (int k = i1; k < i + j1; k++) {
      this.leftBytes[k1] = abyte0[k];
      abyte0[k] = (byte)((abyte0[k] - this.leftBytes[l1]) % 256);
      k1 = (k1 + 1) % 15;
      l1 = (l1 + 1) % 15;
    } 
  }
  
  protected void filterUp(byte[] abyte0, int i, int j) {
    int l = j * this.bytesPerPixel;
    for (int k = 0; k < l; k++) {
      byte byte0 = abyte0[i + k];
      abyte0[i + k] = (byte)((abyte0[i + k] - this.priorRow[k]) % 256);
      this.priorRow[k] = byte0;
    } 
  }
  
  public int getCompressionLevel() {
    return this.compressionLevel;
  }
  
  public boolean getEncodeAlpha() {
    return this.encodeAlpha;
  }
  
  public int getFilter() {
    return this.filter;
  }
  
  protected byte[] resizeByteArray(byte[] abyte0, int i) {
    byte[] abyte1 = new byte[i];
    int j = abyte0.length;
    System.arraycopy(abyte0, 0, abyte1, 0, Math.min(j, i));
    return abyte1;
  }
  
  public void setCompressionLevel(int i) {
    if (i >= 0 && i <= 9)
      this.compressionLevel = i; 
  }
  
  public void setEncodeAlpha(boolean flag) {
    this.encodeAlpha = flag;
  }
  
  public void setFilter(int i) {
    this.filter = 0;
    if (i <= 2)
      this.filter = i; 
  }
  
  protected int writeByte(int i, int j) {
    byte[] abyte0 = { (byte)i };
    return writeBytes(abyte0, j);
  }
  
  protected int writeBytes(byte[] abyte0, int i) {
    this.maxPos = Math.max(this.maxPos, i + abyte0.length);
    if (abyte0.length + i > this.pngBytes.length)
      this.pngBytes = resizeByteArray(this.pngBytes, this.pngBytes.length + Math.max(1000, abyte0.length)); 
    System.arraycopy(abyte0, 0, this.pngBytes, i, abyte0.length);
    return i + abyte0.length;
  }
  
  protected int writeBytes(byte[] abyte0, int i, int j) {
    this.maxPos = Math.max(this.maxPos, j + i);
    if (i + j > this.pngBytes.length)
      this.pngBytes = resizeByteArray(this.pngBytes, this.pngBytes.length + Math.max(1000, i)); 
    System.arraycopy(abyte0, 0, this.pngBytes, j, i);
    return j + i;
  }
  
  protected void writeEnd() {
    this.bytePos = writeInt4(0, this.bytePos);
    this.bytePos = writeString("IEND", this.bytePos);
    this.crc.reset();
    this.crc.update("IEND".getBytes());
    this.crcValue = this.crc.getValue();
    this.bytePos = writeInt4((int)this.crcValue, this.bytePos);
  }
  
  protected int writeInt2(int i, int j) {
    byte[] abyte0 = { (byte)(i >> 8 & 0xFF), (byte)(i & 0xFF) };
    return writeBytes(abyte0, j);
  }
  
  protected int writeInt4(int i, int j) {
    byte[] abyte0 = { (byte)(i >> 24 & 0xFF), (byte)(i >> 16 & 0xFF), (byte)(i >> 8 & 0xFF), (byte)(i & 0xFF) };
    return writeBytes(abyte0, j);
  }
  
  protected int writeString(String s, int i) {
    return writeBytes(s.getBytes(), i);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\internalfilesystem\BeauchampEncoder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */