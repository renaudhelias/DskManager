package jemu.core.device.internalfilesystem;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import jemu.core.Util;
import jemu.core.device.Device;
import jemu.core.device.sound.DigiDevice;
import jemu.settings.Settings;
import jemu.system.cpc.CPC;
import jemu.system.cpc.GateArray;
import jemu.ui.Desktop;
import jemu.ui.JEMU;
import jemu.ui.Switches;

public class InternalFileSystem extends DigiDevice {
  protected File checkfile;
  
  protected String systempath = "";
  
  protected String filename = "";
  
  protected int outport = 255;
  
  protected String content = "";
  
  protected final String up = "\013";
  
  String feed;
  
  String loadcommand;
  
  int loadaddress;
  
  byte[] HEADER;
  
  protected String internalname;
  
  protected int namepos;
  
  protected int filetypepos;
  
  protected int datalengthpos;
  
  protected int datalocationpos;
  
  protected int firstblockpos;
  
  protected int filelengthpos;
  
  protected int execaddresspos;
  
  protected int lengthpos;
  
  protected int checksumpos;
  
  byte[] address1;
  
  byte[] address2;
  
  byte[] address3;
  
  boolean enabled;
  
  int commandport;
  
  int nextcommand;
  
  int oldval;
  
  int feedpos;
  
  int pc;
  
  int pause;
  
  public InternalFileSystem() {
    super("Internal Filesystem");
    this.feed = null;
    this.loadcommand = "";
    this.loadaddress = 0;
    this.internalname = "           ";
    this.namepos = 1;
    this.filetypepos = 18;
    this.datalengthpos = 19;
    this.datalocationpos = 21;
    this.firstblockpos = 23;
    this.filelengthpos = 24;
    this.execaddresspos = 26;
    this.lengthpos = 64;
    this.checksumpos = 67;
    this.address1 = new byte[2];
    this.address2 = new byte[2];
    this.address3 = new byte[2];
    this.enabled = false;
    this.nextcommand = 0;
    this.oldval = 0;
    this.feedpos = 0;
    this.pc = 0;
    this.pause = 0;
    try {
      this.systempath = Settings.get("filesystem_path", (new File("")).getCanonicalPath() + "/");
      this.systempath = this.systempath.replace("\\", "/");
    } catch (Exception exception) {}
  }
  
  protected void writetype(String tocpc) {
    GateArray.cpc.fromautoboot = true;
    GateArray.cpc.BasicAutoType(tocpc, true);
  }
  
  protected void write(String tocpc) {
    this.feedpos = 0;
    this.feed = tocpc;
  }
  
  protected void dir(String name) {
    if (name.length() < 1) {
      name = "C:/";
      File a = new File(name);
      if (!a.exists())
        name = "/Users/"; 
    } 
    long dirs = 0L;
    long files = 0L;
    long sizes = 0L;
    this.checkfile = new File(name);
    String[] check = this.checkfile.list();
    int l = GateArray.getSMode();
    if (l == 2)
      l = 3; 
    String line = "--------------------";
    if (l == 1)
      line = line + "--------------------"; 
    if (l == 3)
      line = line + "------------------------------------------------------------"; 
    String tocpc = "Directory for \"" + name + "\"\r\n" + line;
    boolean lf = false;
    int lft = 1;
    if (check != null)
      for (int i = 0; i < check.length; i++) {
        int size = 0;
        tocpc = tocpc + " ";
        if ((new File(name + check[i])).isDirectory()) {
          dirs++;
        } else {
          files++;
          size = (int)(new File(name + check[i])).length();
          sizes += size;
        } 
        String d = check[i].toUpperCase();
        while (d.length() < 12)
          d = d + " "; 
        if (d.contains(".")) {
          d = d.replace(".", "ZZZZ1111eeee4444");
          String[] ir = d.split("ZZZZ1111eeee4444");
          while (ir[0].length() < 8)
            ir[0] = ir[0] + " "; 
          d = ir[0] + "." + ir[1];
        } 
        while (d.length() > 12)
          d = d.substring(0, d.length() - 1); 
        while (d.length() < 12)
          d = d + " "; 
        tocpc = tocpc + d;
        if (size != 0) {
          String s = "";
          if (size < 1024) {
            s = size + "B";
          } else {
            s = (size / 1000) + "K";
            if (size / 1000 > 1024)
              s = (size / 1000 / 1000) + "M"; 
          } 
          while (s.length() < 5)
            s = " " + s; 
          tocpc = tocpc + ":" + s;
        } else {
          tocpc = tocpc + ":[DIR]";
        } 
        if (l == 0)
          lf = true; 
        if (lf) {
          tocpc = tocpc + "\r\n";
        } else {
          tocpc = tocpc + " ";
        } 
        lf = false;
        lft++;
        if (lft > l) {
          lf = true;
          lft = 0;
        } 
      }  
    tocpc = tocpc + "\r\n" + line + dirs + " dirs, " + files + " files, " + sizes + " bytes\r\n";
    write(tocpc);
  }
  
  protected void setPath(String command) {
    String old = this.systempath;
    command = command.replace("\\", "/");
    if (!command.endsWith("/"))
      command = command + "/"; 
    if (command.contains(":") || command.startsWith("/")) {
      this.systempath = command;
    } else if (command.contains("..")) {
      if (this.systempath.endsWith("/")) {
        this.systempath = this.systempath.substring(0, this.systempath.length() - 1);
        if (this.systempath.contains("/")) {
          while (!this.systempath.endsWith("/"))
            this.systempath = this.systempath.substring(0, this.systempath.length() - 1); 
          this.systempath = this.systempath.substring(0, this.systempath.length() - 1);
        } 
      } else if (this.systempath.contains("/")) {
        while (!this.systempath.endsWith("/"))
          this.systempath = this.systempath.substring(0, this.systempath.length() - 1); 
        this.systempath = this.systempath.substring(0, this.systempath.length() - 1);
      } 
      this.systempath += "/";
    } else {
      this.systempath += command;
    } 
    this.systempath = this.systempath.replace("\\", "/");
    File a = new File(this.systempath);
    if (!a.exists()) {
      String str = "*ERROR* Path " + this.systempath + " not found" + '\007';
      write(str);
      this.systempath = old;
      return;
    } 
    String tocpc = "Path changed to " + this.systempath;
    write(tocpc);
    Settings.set("filesystem_path", this.systempath);
    System.out.println("Path seth to " + this.systempath);
  }
  
  protected void mkdir(String command) {
    File a = new File(this.systempath + command);
    if (!a.exists()) {
      a.mkdir();
      String tocpc = "DIR " + command + " created.";
      write(tocpc);
    } else {
      String tocpc = "*ERROR* DIR " + command + " already exists" + '\007';
      write(tocpc);
    } 
  }
  
  protected void del(String command) {
    File a = new File(this.systempath + command);
    command = command.replace("*", "~~");
    if (command.contains("~~")) {
      a = new File(this.systempath);
      command = command.replace("~~", "");
      System.out.println("deleting " + command);
      String[] list = a.list();
      String result = "";
      if (list.length < 1) {
        write("*Error* No file to delete\007");
        return;
      } 
      for (int i = 0; i < list.length; i++) {
        System.out.println("checking " + list[i]);
        a = new File(this.systempath + list[i]);
        if (a.isFile() && list[i].toLowerCase().contains(command.toLowerCase())) {
          a.delete();
          result = result + list[i];
          int dd = 0;
          while (a.exists()) {
            dd++;
            if (dd > 100000) {
              result = result + " *Error*\r\n";
              break;
            } 
          } 
          if (dd < 10000)
            result = result + " erased\r\n"; 
        } 
      } 
      write(result);
      return;
    } 
    if (a.exists()) {
      a.delete();
      int dd = 0;
      do {
        dd++;
      } while (a.exists() && dd <= 100000);
      if (a.exists()) {
        String tocpc = "*ERROR* Cannot delete " + command + '\007';
        write(tocpc);
      } else {
        String tocpc = command + " erased";
        write(tocpc);
      } 
    } else {
      String tocpc = "*ERROR* File " + command + " not found" + '\007';
      write(tocpc);
    } 
  }
  
  protected void load(String command) {
    this.loadaddress = Device.getWord(this.address1, 0);
    clear();
    if (command.toLowerCase().endsWith(".dsk")) {
      try {
        int d = GateArray.cpc.getCurrentDrive();
        GateArray.cpc.setCurrentDrive(this.loadaddress);
        GateArray.cpc.loadFile(0, this.systempath + command);
        Settings.set("file.drive" + Integer.toString(this.loadaddress), this.systempath + command);
        Settings.setBoolean("loaddrive" + Integer.toString(this.loadaddress), true);
        GateArray.cpc.setCurrentDrive(d);
      } catch (Exception exception) {}
      return;
    } 
    File a = new File(this.systempath + command);
    if (!a.exists() || a.isDirectory()) {
      if (a.isDirectory()) {
        String tocpc = "\r\n'*ERROR* " + command + " is a folder\r\n";
        writetype(tocpc);
        return;
      } 
      a = new File(this.systempath + command + ".BAS");
      if (!a.exists() || a.isDirectory()) {
        a = new File(this.systempath + command + ".BIN");
        if (!a.exists() || a.isDirectory()) {
          a = new File(this.systempath + command + ".SNA");
          if (!a.exists()) {
            String tocpc = "\r\n'*ERROR* File " + command + " not found\r\n";
            writetype(tocpc);
            return;
          } 
        } 
      } 
    } 
    int siz = (int)a.length();
    byte[] data = new byte[siz];
    try {
      BufferedInputStream bin = new BufferedInputStream(new FileInputStream(a));
      bin.read(data);
      bin.close();
      System.out.println(a.getAbsolutePath());
      if (a.getAbsolutePath().toLowerCase().endsWith(".txt")) {
        StringBuilder build = new StringBuilder();
        for (int i = 0; i < data.length; i++)
          build.append((char)(data[i] & 0xFF)); 
        GateArray.cpc.BasicAutoType(build.toString());
      } else {
        GateArray.cpc.loadFile(data, this.loadaddress);
      } 
    } catch (Exception exception) {}
  }
  
  protected void save(String command) {
    if (command.startsWith("&")) {
      command = command.replace("&", "");
      try {
        this.loadaddress = Util.hexValue(command);
      } catch (Exception exception) {}
    } else {
      File a = new File(this.systempath + command);
      int siz = (int)a.length();
      byte[] data = new byte[siz];
      try {
        BufferedInputStream bin = new BufferedInputStream(new FileInputStream(a));
        bin.read(data);
        bin.close();
        GateArray.cpc.loadFile(data, this.loadaddress);
      } catch (Exception exception) {}
    } 
  }
  
  public byte[] makeHeader(int type, int start, int length, int exec, String intname, byte[] data) {
    this.HEADER = new byte[128];
    intname = intname.replace(".", "");
    while (intname.length() > 11)
      intname = intname.substring(0, intname.length() - 1); 
    intname = intname.toUpperCase();
    try {
      System.arraycopy("           ".getBytes("UTF-8"), 0, this.HEADER, this.namepos, 11);
      System.arraycopy(intname.getBytes("UTF-8"), 0, this.HEADER, this.namepos, intname.length());
    } catch (Exception e) {
      System.err.println("Something went wrong with " + intname);
    } 
    this.HEADER[this.filetypepos] = (byte)type;
    Device.putWord(this.HEADER, this.datalengthpos, length);
    Device.putWord(this.HEADER, this.datalocationpos, start);
    this.HEADER[this.firstblockpos] = -1;
    Device.putWord(this.HEADER, this.filelengthpos, length);
    Device.putWord(this.HEADER, this.execaddresspos, exec);
    put24Bit(this.HEADER, this.lengthpos, length);
    put24Bit(this.HEADER, this.checksumpos, CPC.ChecksumAMSDOS(this.HEADER));
    return addHeader(data);
  }
  
  public static void put24Bit(byte[] buffer, int offs, int data) {
    buffer[offs] = (byte)(data & 0xFF);
    buffer[offs + 1] = (byte)(data >> 8 & 0xFF);
    buffer[offs + 2] = (byte)(data >> 16 & 0xFF);
  }
  
  public byte[] addHeader(byte[] SOURCEFILE) {
    byte[] RESULT = new byte[SOURCEFILE.length + 128];
    System.arraycopy(this.HEADER, 0, RESULT, 0, 128);
    System.arraycopy(SOURCEFILE, 0, RESULT, 128, SOURCEFILE.length);
    SOURCEFILE = new byte[RESULT.length];
    System.arraycopy(RESULT, 0, SOURCEFILE, 0, SOURCEFILE.length);
    return RESULT;
  }
  
  protected void savebin(String command) {
    command = command.toUpperCase();
    if (!command.contains(".")) {
      command = command + ".BIN";
    } else if (command.endsWith(".")) {
      command = command.substring(0, command.length() - 1);
    } 
    File a = new File(this.systempath + command);
    if (a.exists()) {
      String old = command;
      command = command.replace(".BIN", ".BAK");
      if (!command.endsWith(".BAK"))
        command = command + ".BAK"; 
      File b = new File(this.systempath + command);
      a.renameTo(b);
      command = old;
      a = new File(this.systempath + old);
    } 
    int siz = Device.getWord(this.address2, 0);
    int start = Device.getWord(this.address1, 0);
    int begin = Device.getWord(this.address3, 0);
    clear();
    int pos = start;
    byte[] data = new byte[siz];
    int d = 0;
    for (int i = pos; i < pos + siz; i++)
      data[d++] = (byte)CPC.memory.readWriteByte(i); 
    data = makeHeader(2, start, siz, begin, command, data);
    try {
      BufferedOutputStream bin = new BufferedOutputStream(new FileOutputStream(a));
      bin.write(data);
      bin.close();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  protected void savebas(String command) {
    command = command.toUpperCase();
    if (command.endsWith(".SNA")) {
      int sizemem = 512;
      if (CPC.memory.getRAMType() == 0)
        sizemem = 64; 
      if (CPC.memory.getRAMType() == 1)
        sizemem = 128; 
      if (CPC.memory.getRAMType() == 15)
        sizemem = 256; 
      byte[] arrayOfByte = GateArray.cpc.getSNA(sizemem);
      File file = new File(this.systempath + command);
      try {
        BufferedOutputStream bin = new BufferedOutputStream(new FileOutputStream(file));
        bin.write(arrayOfByte);
        bin.close();
      } catch (Exception e) {
        e.printStackTrace();
      } 
      return;
    } 
    if (command.endsWith(".DSK")) {
      byte[] arrayOfByte = GateArray.cpc.getDSKImage(0);
      File file = new File(this.systempath + command);
      try {
        BufferedOutputStream bin = new BufferedOutputStream(new FileOutputStream(file));
        bin.write(arrayOfByte);
        bin.close();
      } catch (Exception e) {
        e.printStackTrace();
      } 
      return;
    } 
    if (!command.contains(".")) {
      command = command + ".BAS";
    } else if (command.endsWith(".")) {
      command = command.substring(0, command.length() - 1);
    } 
    String oldc = command;
    System.out.println("Storing " + this.systempath + command);
    File a = new File(this.systempath + command);
    if (a.exists()) {
      command = command.replace(".BAS", ".BAK");
      if (!command.endsWith(".BAK"))
        command = command + ".BAK"; 
      File b = new File(this.systempath + command);
      a.renameTo(b);
    } 
    command = oldc;
    a = new File(this.systempath + command);
    int siz = GateArray.cpc.getBasSize1_1();
    if (Switches.ROM.equals("CPC464"))
      siz = GateArray.cpc.getBasSize1_0(); 
    int pos = 368;
    byte[] data = new byte[siz + 2];
    int d = 0;
    for (int i = pos; i < pos + siz; i++)
      data[d++] = (byte)CPC.memory.readWriteByte(i); 
    data = makeHeader(0, 368, siz, 0, command, data);
    try {
      if (command.toLowerCase().contains(".txt")) {
        String listing = GateArray.cpc.getBasList();
        data = listing.getBytes("UTF-8");
      } 
      BufferedOutputStream bin = new BufferedOutputStream(new FileOutputStream(a));
      bin.write(data);
      bin.close();
    } catch (Exception e) {
      write("*Error* save failed\007");
    } 
  }
  
  protected void hextype(String command) {
    this.feed = null;
    int l = GateArray.getSMode();
    if (l != 2) {
      write("Please set MODE to 2 and retry.");
      return;
    } 
    File a = new File(this.systempath + command);
    int siz = (int)a.length();
    byte[] data = new byte[siz];
    try {
      BufferedInputStream bin = new BufferedInputStream(new FileInputStream(a));
      bin.read(data);
      bin.close();
      String d = Util.dumpBytes(data, 0, data.length, true, true, true);
      write(d);
    } catch (Exception e) {
      write("*Error* file " + command + " not found" + '\007');
    } 
  }
  
  private String readAllBytes(String filePath) {
    String content = "";
    try {
      content = new String(Files.readAllBytes(Paths.get(filePath, new String[0])));
    } catch (Exception exception) {}
    return content;
  }
  
  protected void assemble(final String command) {
    this.feed = null;
    try {
      File a = new File(this.systempath + command);
      if (!a.exists()) {
        write("*Error* file " + command + " not found" + '\007');
        return;
      } 
      final String v = readAllBytes(this.systempath + command);
      Thread t = new Thread() {
          public void run() {
            try {
              Thread.sleep(1000L);
              GateArray.cpc.assemble(InternalFileSystem.this.systempath + command, v);
            } catch (Exception exception) {}
          }
        };
      write("Assembling " + command);
      t.start();
    } catch (Exception e) {
      write("*Error* file " + command + " not found" + '\007');
    } 
  }
  
  protected void type(String command) {
    this.feed = null;
    File a = new File(this.systempath + command);
    int siz = (int)a.length();
    byte[] data = new byte[siz];
    try {
      BufferedInputStream bin = new BufferedInputStream(new FileInputStream(a));
      bin.read(data);
      bin.close();
      StringBuilder b = new StringBuilder();
      for (int i = 0; i < data.length; i++) {
        int p = data[i] & 0xFF;
        if (p > 30 || p == 13 || p == 10)
          b.append("" + (char)(data[i] & 0xFF)); 
      } 
      write(b.toString());
    } catch (Exception e) {
      write("*Error* file " + command + " not found" + '\007');
    } 
  }
  
  protected void clear() {
    this.address1[0] = 0;
    this.address1[1] = 0;
    this.address2[0] = 0;
    this.address2[1] = 0;
    this.address3[0] = 0;
    this.address3[1] = 0;
  }
  
  protected void executeCommand(int command_exec_code, String command) {
    System.out.println("Running command #" + command_exec_code + " command: " + command);
    switch (command_exec_code) {
      case 0:
        setPath(command);
        break;
      case 1:
        dir(this.systempath);
        break;
      case 2:
        load(command);
        break;
      case 3:
        save(command);
        break;
      case 4:
        savebas(command);
        break;
      case 5:
        mkdir(command);
        break;
      case 6:
        del(command);
        break;
      case 7:
        clear();
        load(command);
        break;
      case 8:
        savebin(command);
        break;
      case 9:
        type(command);
        break;
      case 10:
        hextype(command);
        break;
      case 11:
        doTurbo();
        break;
      case 12:
        doTurboOff();
        break;
      case 13:
        doZ80Turbo();
        break;
      case 14:
        doZ80TurboOff();
        break;
      case 15:
        assemble(command);
        break;
    } 
  }
  
  protected void doTurbo() {
    if (Switches.turbo < 2) {
      Desktop.jCheckBox8.setSelected(true);
      System.out.println("Turbo enabled");
      Switches.turbo = 2;
      JEMU.turbo.setState(true);
    } 
  }
  
  protected void doTurboOff() {
    if (Switches.turbo > 1) {
      Desktop.jCheckBox8.setSelected(false);
      System.out.println("Turbo disabled");
      Switches.turbo = 1;
      JEMU.turbo.setState(false);
    } 
  }
  
  protected void doZ80Turbo() {
    Desktop.jCheckBox19.setSelected(true);
    GateArray.cpc.setZ80Turbo(true);
    JEMU.z80turbo.setState(true);
    System.out.println("Z80 turbo enabled");
  }
  
  protected void doZ80TurboOff() {
    Desktop.jCheckBox19.setSelected(false);
    GateArray.cpc.setZ80Turbo(false);
    JEMU.z80turbo.setState(false);
    System.out.println("Z80 turbo disabled");
  }
  
  public void writePort(int port, int value) {
    port &= 0xFFFF;
    if (port > 65529 || port < 65408)
      return; 
    if (value == 2 && this.feed != null) {
      this.feed = null;
      write("\r\n*Stopped*\r\n");
    } 
    if (this.feed != null) {
      if (value == 255 && this.pc != GateArray.cpc.z80.getPC())
        if (this.feedpos == this.feed.length()) {
          this.feed = null;
          this.outport = 0;
        } else {
          this.outport = this.feed.charAt(this.feedpos);
          this.feedpos++;
        }  
      return;
    } 
    if (port != 65520) {
      if (this.oldval == value)
        return; 
      this.oldval = value;
    } 
    this.outport = 0;
    if (this.nextcommand != 0) {
      switch (this.nextcommand) {
        case 1:
          this.address1[1] = (byte)value;
          break;
        case 2:
          this.address1[0] = (byte)value;
          break;
        case 3:
          this.address2[1] = (byte)value;
          break;
        case 4:
          this.address2[0] = (byte)value;
          break;
        case 5:
          this.address3[1] = (byte)value;
          break;
        case 6:
          this.address3[0] = (byte)value;
          break;
      } 
      this.nextcommand = 0;
      this.outport = 255;
      return;
    } 
    if (value < 20 && port != 65520) {
      this.commandport = value;
      System.out.println("Commandport is: " + value);
    } else if (value == 255 && port != 65520) {
      executeCommand(this.commandport, this.content);
      this.content = "";
    } else if (value == 20 && port != 65520) {
      this.nextcommand = 1;
    } else if (value == 21 && port != 65520) {
      this.nextcommand = 2;
    } else if (value == 30 && port != 65520) {
      this.nextcommand = 3;
    } else if (value == 31 && port != 65520) {
      this.nextcommand = 4;
    } else if (value == 40 && port != 65520) {
      this.nextcommand = 5;
    } else if (value == 41 && port != 65520) {
      this.nextcommand = 6;
      System.out.println("next is 6");
    } else {
      this.content += (char)value;
    } 
    this.outport = 255;
  }
  
  public int readPort(int port) {
    if (port > 65529 || port < 65408)
      return 255; 
    return this.outport;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\internalfilesystem\InternalFileSystem.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */