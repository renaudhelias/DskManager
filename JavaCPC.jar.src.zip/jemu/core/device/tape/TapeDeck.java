package jemu.core.device.tape;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.net.URL;
import javax.swing.AbstractListModel;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JToggleButton;
import javax.swing.Timer;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import jemu.core.samples.Samples;
import jemu.settings.Settings;
import jemu.system.cpc.CPC;
import jemu.system.cpc.GateArray;
import jemu.ui.Desktop;
import jemu.ui.JEMU;
import jemu.ui.Switches;

public class TapeDeck extends JFrame implements ActionListener, MouseListener {
  int tapePlay = 0;
  
  public void mousePressed(MouseEvent e) {
    this.tapePlay = blocklist.getSelectedIndex();
  }
  
  public void mouseClicked(MouseEvent e) {}
  
  public void mouseReleased(MouseEvent e) {
    setPos(this.tapePlay);
    blocks.setPopupMenuVisible(false);
    blocks.setSelected(false);
  }
  
  public void mouseEntered(MouseEvent e) {}
  
  public void mouseExited(MouseEvent e) {}
  
  public int resettime = 0;
  
  public static JPanel tapepanel;
  
  public static JCheckBox ascdt;
  
  public static JButton saveit;
  
  public String filename;
  
  public static JProgressBar position;
  
  protected String Counter;
  
  final URL cursorim = getClass().getResource("image/icon_finger.gif");
  
  final Image cursor = getToolkit().getImage(this.cursorim);
  
  Cursor finger;
  
  int pos;
  
  int stepper = 1;
  
  int updater = 6;
  
  int stoptimer;
  
  public int updatewheels;
  
  protected JPanel drivepanel;
  
  protected JPanel wheelpanel;
  
  protected JPanel infopanel;
  
  public static boolean tapeChanged = false;
  
  public static boolean blanktape = false;
  
  protected int lastnumber;
  
  public int WAVBYTE = 0;
  
  private int update = 0;
  
  public static JMenuBar tapeblocks = new JMenuBar();
  
  public static JMenu drive;
  
  public static JMenu blocks;
  
  public static JScrollPane blockpane;
  
  public static JList blocklist;
  
  public static JMenu info;
  
  public JMenuItem play;
  
  public JCheckBox recFull;
  
  public JRadioButton c90;
  
  public JRadioButton c60;
  
  public JRadioButton c30;
  
  public JMenuItem create;
  
  public JMenuItem resize;
  
  public JMenuItem record;
  
  public JMenuItem rewind;
  
  public JMenuItem forward;
  
  public JMenuItem stop;
  
  public JMenuItem pause;
  
  public JMenuItem eject;
  
  public static JMenuItem savetape;
  
  public static JMenuItem tapeload;
  
  public int block = 0;
  
  TapeInfo tapeinfo = new TapeInfo();
  
  TapeWheels wheels = new TapeWheels();
  
  final URL tapeupe = getClass().getResource("image/upper_tape_e.png");
  
  final ImageIcon tapupe = new ImageIcon(this.tapeupe);
  
  final URL tapeup = getClass().getResource("image/upper_tape.png");
  
  final ImageIcon tapup = new ImageIcon(this.tapeup);
  
  final URL tapeupl = getClass().getResource("image/upper_ltape.png");
  
  final ImageIcon tapupl = new ImageIcon(this.tapeupl);
  
  final URL tapeupr = getClass().getResource("image/upper_rtape.png");
  
  final ImageIcon tapupr = new ImageIcon(this.tapeupr);
  
  final URL tapelefte = getClass().getResource("image/left_tape_e.png");
  
  final ImageIcon taplefte = new ImageIcon(this.tapelefte);
  
  final URL tapeleft = getClass().getResource("image/left_tape.png");
  
  final ImageIcon tapleft = new ImageIcon(this.tapeleft);
  
  final URL[] twheel = new URL[5];
  
  final ImageIcon[] wheel = new ImageIcon[5];
  
  final URL taperighte = getClass().getResource("image/right_tape_e.png");
  
  final ImageIcon taprighte = new ImageIcon(this.taperighte);
  
  final URL taperight = getClass().getResource("image/right_tape.png");
  
  final ImageIcon tapright = new ImageIcon(this.taperight);
  
  final URL tapelowe = getClass().getResource("image/lower_tape_e.png");
  
  final ImageIcon taplowe = new ImageIcon(this.tapelowe);
  
  final URL tapelow = getClass().getResource("image/lower_tape.png");
  
  final ImageIcon taplow = new ImageIcon(this.tapelow);
  
  final URL recb = getClass().getResource("image/but_rec.png");
  
  final ImageIcon recbu = new ImageIcon(this.recb);
  
  final URL rewb = getClass().getResource("image/but_rew.png");
  
  final ImageIcon rewbu = new ImageIcon(this.rewb);
  
  final URL ffb = getClass().getResource("image/but_ff.png");
  
  final ImageIcon ffbu = new ImageIcon(this.ffb);
  
  final URL playb = getClass().getResource("image/but_play.png");
  
  final ImageIcon playbu = new ImageIcon(this.playb);
  
  final URL stopb = getClass().getResource("image/but_stop.png");
  
  final ImageIcon stopbu = new ImageIcon(this.stopb);
  
  final URL pauseb = getClass().getResource("image/but_pause.png");
  
  final ImageIcon pausebu = new ImageIcon(this.pauseb);
  
  final URL recbp = getClass().getResource("image/but_rec_p.png");
  
  final ImageIcon recbup = new ImageIcon(this.recbp);
  
  final URL rewbp = getClass().getResource("image/but_rew_p.png");
  
  final ImageIcon rewbup = new ImageIcon(this.rewbp);
  
  final URL ffbp = getClass().getResource("image/but_ff_p.png");
  
  final ImageIcon ffbup = new ImageIcon(this.ffbp);
  
  final URL playbp = getClass().getResource("image/but_play_p.png");
  
  final ImageIcon playbup = new ImageIcon(this.playbp);
  
  final URL stopbp = getClass().getResource("image/but_stop_p.png");
  
  final ImageIcon stopbup = new ImageIcon(this.stopbp);
  
  final URL pausebp = getClass().getResource("image/but_pause_p.png");
  
  final ImageIcon pausebup = new ImageIcon(this.pausebp);
  
  final JLabel tup = new JLabel(this.tapup);
  
  final JLabel tupl = new JLabel(this.tapupl);
  
  final JLabel tupr = new JLabel(this.tapupr);
  
  final JLabel tleft = new JLabel(this.tapleft);
  
  JLabel wleft;
  
  JLabel wright;
  
  final JLabel tright = new JLabel(this.tapright);
  
  final JLabel tlow = new JLabel(this.taplow);
  
  public static Color CPCGRAY = new Color(55, 55, 55);
  
  public boolean buttonpressed;
  
  public static boolean isMem;
  
  public boolean paused;
  
  public boolean played;
  
  public boolean recorded = false;
  
  protected boolean playing = false;
  
  public JButton btnREC = new JButton(this.recbu);
  
  public JButton btnREW = new JButton(this.rewbu);
  
  public JButton btnPLAY = new JButton(this.playbu);
  
  public JButton btnFF = new JButton(this.ffbu);
  
  public JButton btnStart = new JButton("►");
  
  public JButton btnStop = new JButton("■");
  
  JButton btnSTOP = new JButton(this.stopbu);
  
  JButton btnPAUSE = new JButton(this.pausebu);
  
  JButton reset = new JButton(" ");
  
  JLabel blanker = new JLabel("          ");
  
  JLabel blanker2 = new JLabel("  ");
  
  public static double counter = 0.0D;
  
  public static String before = "00";
  
  public static TapeCounter TapeCounter = new TapeCounter();
  
  public static TapeCounter TapeMemory = new TapeCounter();
  
  public JToggleButton memory = new JToggleButton("Mem");
  
  public static double memCount = 0.0D;
  
  int paintthis;
  
  boolean hastape;
  
  int skin;
  
  public boolean started;
  
  ActionListener updateTape;
  
  public Timer Updater;
  
  boolean C90;
  
  boolean C30;
  
  public static void main(String[] args) {
    TapeDeck deck = new TapeDeck();
    deck.setVisible(true);
    deck.Updater.start();
  }
  
  public void windowClosing(WindowEvent e) {
    CPC.tapedeck = false;
    setVisible(false);
  }
  
  public void windowClosed(WindowEvent e) {
    CPC.tapedeck = false;
    setVisible(false);
  }
  
  public void windowDeactivated(WindowEvent e) {}
  
  public void windowActivated(WindowEvent e) {}
  
  public void windowDeiconified(WindowEvent e) {}
  
  public void windowOpened(WindowEvent e) {}
  
  public void windowIconified(WindowEvent e) {}
  
  public void reSize() {
    if (CPC.tapesample == null)
      return; 
    String count = JOptionPane.showInputDialog(new JFrame("Resize"), "Resize cassette to:\r\nEnter minutes please.");
    if (count != null)
      try {
        int newSize = Integer.parseInt(count);
        newSize *= GateArray.cpc.frequency * 60;
        int hasSize = CPC.tapesample.length;
        byte[] buffer = new byte[newSize];
        if (newSize < hasSize) {
          int n = JOptionPane.showConfirmDialog(new JFrame(), "New size is smaller than loaded tape.\r\nAre you sure?", "Please confirm", 0);
          if (n != 0)
            return; 
        } 
        if (newSize < hasSize) {
          System.arraycopy(CPC.tapesample, 0, buffer, 0, newSize);
        } else {
          for (int i = hasSize; i < buffer.length; i++)
            buffer[i] = Byte.MIN_VALUE; 
          System.arraycopy(CPC.tapesample, 0, buffer, 0, hasSize);
        } 
        CPC.tapesample = new byte[newSize];
        System.arraycopy(buffer, 0, CPC.tapesample, 0, newSize);
        buildTapeBlocks();
      } catch (Exception exception) {} 
  }
  
  public void setName(String text) {
    this.filename = text;
  }
  
  public void showText(String text) {}
  
  public void showText() {}
  
  public TapeDeck() {
    this.paintthis = 0;
    this.hastape = false;
    this.skin = 0;
    this.started = false;
    this.updateTape = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          TapeDeck.this.checkTape();
          TapeDeck.this.paintWheels();
          TapeDeck.this.started = true;
        }
      };
    this.Updater = new Timer(10, this.updateTape);
    this.C90 = false;
    this.C30 = false;
    ascdt = new JCheckBox("as CDT (Windows)");
    saveit = new JButton("Save");
    saveit.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            CPC.savetape = true;
          }
        });
    saveit.setFocusable(false);
    position = new JProgressBar();
    position.setIndeterminate(false);
    position.setPreferredSize(new Dimension(247, 12));
    tapepanel = new JPanel();
    tapepanel.setBackground(Color.black);
    this.Counter = "000";
    this.filename = "No tape inserted...";
    for (int i = 0; i < 4; i++) {
      this.twheel[i] = getClass().getResource("image/wheel" + i + ".png");
      this.wheel[i] = new ImageIcon(this.twheel[i]);
    } 
    this.twheel[4] = getClass().getResource("image/wheel_e.png");
    this.wheel[4] = new ImageIcon(this.twheel[4]);
    Samples.volume = Samples.Volume.HIGH;
    tapepanel.setLayout(new FlowLayout(1, 6, 4));
    this.btnREW.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            TapeDeck.this.pressRew();
          }
        });
    this.btnPLAY.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            TapeDeck.this.pressPlay();
          }
        });
    this.btnREC.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            TapeDeck.this.pressRec(false);
          }
        });
    this.btnFF.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            TapeDeck.this.pressFwd();
          }
        });
    this.btnStart.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            String count = JOptionPane.showInputDialog(new JFrame("Jump"), "Jump to counter:");
            if (count != null)
              try {
                int counter = Integer.parseInt(count);
                GateArray.cpc.jumpTape(counter);
              } catch (Exception exception) {} 
          }
        });
    this.btnStop.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            GateArray.cpc.stopTapeMotor();
          }
        });
    this.btnSTOP.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            TapeDeck.this.pressStop();
          }
        });
    this.reset.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            TapeDeck.this.showText();
            TapeDeck.counter = 0.0D;
            TapeDeck.before = "000";
            CPC.tapeBandPosition = 0;
            TapeDeck.TapeCounter.setCounter(0.0D);
          }
        });
    this.btnPAUSE.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            TapeDeck.this.pressPause();
          }
        });
    this.memory.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (!TapeDeck.isMem) {
              TapeDeck.this.memory.setSelected(true);
              TapeDeck.this.memory.setBackground(Color.GREEN);
              TapeDeck.TapeMemory.setForeground(Color.WHITE);
              TapeDeck.TapeMemory.setBackground(Color.GRAY);
              TapeDeck.isMem = true;
              TapeDeck.memCount = TapeDeck.TapeCounter.getCounter();
              TapeDeck.TapeMemory.setCounter(TapeDeck.memCount);
            } else {
              TapeDeck.isMem = false;
              TapeDeck.this.memory.setSelected(false);
              TapeDeck.this.memory.setBackground(new Color(192, 192, 192));
              TapeDeck.TapeMemory.setCounter(0.0D);
            } 
          }
        });
    tapepanel.add(TapeCounter);
    tapepanel.add(this.reset);
    tapepanel.add(this.blanker);
    tapepanel.add(this.btnStart);
    tapepanel.add(this.blanker2);
    tapepanel.add(this.memory);
    tapepanel.add(TapeMemory);
    this.wleft = new JLabel(this.wheel[0]);
    this.wright = new JLabel(this.wheel[0]);
    this.drivepanel = new JPanel();
    this.wheelpanel = new JPanel();
    this.infopanel = new JPanel();
    this.drivepanel.setLayout(new BorderLayout());
    this.wheelpanel.setLayout(new FlowLayout(0, 0, 0));
    this.infopanel.setLayout(new BorderLayout());
    this.infopanel.add(this.tup, "North");
    this.infopanel.add(this.tupl, "West");
    this.infopanel.add(this.tapeinfo, "Center");
    this.infopanel.add(this.tupr, "East");
    this.infopanel.setBorder((Border)null);
    this.tleft.setBorder((Border)null);
    this.wleft.setBorder((Border)null);
    this.wheels.setBorder((Border)null);
    this.wheelpanel.setBorder((Border)null);
    this.tright.setBorder((Border)null);
    this.wright.setBorder((Border)null);
    this.tlow.setBorder((Border)null);
    this.tapeinfo.setBorder((Border)null);
    this.tup.setBorder((Border)null);
    this.tupl.setBorder((Border)null);
    this.tupr.setBorder((Border)null);
    this.drivepanel.add(this.infopanel, "North");
    this.drivepanel.add(this.tleft, "West");
    this.wheelpanel.add(this.wleft, "West");
    this.wheelpanel.add(this.wheels, "Center");
    this.wheelpanel.add(this.wright, "East");
    this.drivepanel.add(this.wheelpanel, "Center");
    this.drivepanel.add(this.tright, "East");
    this.drivepanel.add(this.tlow, "South");
    this.drivepanel.setDoubleBuffered(false);
    tapepanel.add(this.drivepanel);
    this.finger = Toolkit.getDefaultToolkit().createCustomCursor(this.cursor, new Point(7, 2), "gunCursor");
    this.reset.setCursor(this.finger);
    this.memory.setCursor(this.finger);
    this.btnREC.setCursor(this.finger);
    this.btnPLAY.setCursor(this.finger);
    this.btnREW.setCursor(this.finger);
    this.btnFF.setCursor(this.finger);
    this.btnSTOP.setCursor(this.finger);
    this.btnPAUSE.setCursor(this.finger);
    this.btnStart.setCursor(this.finger);
    this.btnStop.setCursor(this.finger);
    tapepanel.add(this.btnREC);
    tapepanel.add(this.btnPLAY);
    tapepanel.add(this.btnREW);
    tapepanel.add(this.btnFF);
    tapepanel.add(this.btnSTOP);
    tapepanel.add(this.btnPAUSE);
    tapepanel.add(position);
    tapepanel.add(saveit);
    if (JEMU.isWindows()) {
      tapepanel.add(ascdt);
      ascdt.setVisible(true);
    } else {
      ascdt.setVisible(false);
    } 
    ascdt.setFocusable(false);
    drive = new JMenu("Drive");
    blocks = new JMenu("Blocks");
    blockpane = new JScrollPane();
    blocklist = new JList();
    blocklist.setBorder((Border)null);
    blockpane.setBorder((Border)null);
    blockpane.setViewportView(blocklist);
    blockpane.setPreferredSize(new Dimension(150, 300));
    blocklist.addMouseListener(this);
    blocks.add(blockpane);
    info = new JMenu("Options");
    this.c30 = new JRadioButton("C15 Cassette (7,5 min.)");
    this.c60 = new JRadioButton("C60 Cassette (30 min.)");
    this.c90 = new JRadioButton("C90 Cassette (45 min.)");
    this.recFull = new JCheckBox("Store complete tape");
    this.recFull.setFocusable(false);
    this.recFull.setSelected(Settings.getBoolean("record_full_tape", true));
    CPC.recordFull = this.recFull.isSelected();
    this.recFull.addActionListener(this);
    String tapesize = Settings.get("tape_size", "C30");
    if (tapesize.equals("C90")) {
      this.c90.setSelected(true);
    } else if (tapesize.equals("C60")) {
      this.c60.setSelected(true);
    } else {
      this.c30.setSelected(true);
    } 
    this.c30.addActionListener(this);
    this.c30.setFocusable(false);
    this.c60.addActionListener(this);
    this.c60.setFocusable(false);
    this.c90.addActionListener(this);
    this.c90.setFocusable(false);
    ButtonGroup group = new ButtonGroup();
    group.add(this.c30);
    group.add(this.c60);
    group.add(this.c90);
    this.create = new JMenuItem("Create blank cassette");
    this.create.addActionListener(this);
    this.resize = new JMenuItem("Resize cassette");
    this.resize.addActionListener(this);
    this.play = new JMenuItem("Press Play");
    this.play.addActionListener(this);
    this.record = new JMenuItem("Press Rec & Play");
    this.record.addActionListener(this);
    this.rewind = new JMenuItem("Press Rewind");
    this.rewind.addActionListener(this);
    this.forward = new JMenuItem("Press Fast Forward");
    this.forward.addActionListener(this);
    this.stop = new JMenuItem("Press Stop/Eject");
    this.stop.addActionListener(this);
    this.pause = new JMenuItem("Press Pause");
    this.pause.addActionListener(this);
    this.eject = new JMenuItem("Eject Tape");
    this.eject.addActionListener(this);
    savetape = new JMenuItem("Save WAV-tape");
    savetape.addActionListener(this);
    savetape.setEnabled(false);
    tapeload = new JMenuItem("Load tape-file");
    tapeload.addActionListener(this);
    tapeload.setEnabled(true);
    drive.add(tapeload);
    drive.addSeparator();
    drive.add(this.play);
    drive.add(this.record);
    drive.add(this.rewind);
    drive.add(this.forward);
    drive.add(this.stop);
    drive.add(this.pause);
    drive.add(this.eject);
    drive.addSeparator();
    drive.add(savetape);
    drive.addActionListener(this);
    info.add(this.c30);
    info.add(this.c60);
    info.add(this.c90);
    info.add(this.recFull);
    info.add(this.create);
    info.addSeparator();
    info.add(this.resize);
    info.addActionListener(this);
    tapeblocks.add(drive);
    tapeblocks.add(blocks);
    tapeblocks.add(info);
    this.btnREW.setBorder(new BevelBorder(0));
    this.btnREW.setFocusable(false);
    this.btnREW.setBackground(Color.DARK_GRAY);
    this.btnREW.setForeground(Color.WHITE);
    this.memory.setFocusable(false);
    this.memory.setBackground(Color.DARK_GRAY);
    TapeMemory.setBorder(new BevelBorder(1));
    TapeMemory.setFocusable(true);
    TapeMemory.setBackground(Color.BLACK);
    TapeMemory.setForeground(Color.BLACK);
    this.btnPLAY.setBorder(new BevelBorder(0));
    this.btnREW.setFocusable(false);
    this.btnFF.setBorder(new BevelBorder(0));
    this.btnSTOP.setBorder(new BevelBorder(0));
    this.btnStart.setBorder(new BevelBorder(0));
    this.btnStop.setBorder(new BevelBorder(0));
    this.btnPAUSE.setBorder(new BevelBorder(0));
    TapeCounter.setBorder(new BevelBorder(1));
    this.reset.setBorder(new BevelBorder(0));
    this.btnREC.setBorder(new BevelBorder(0));
    this.btnPLAY.setFocusable(false);
    this.btnFF.setFocusable(false);
    this.btnSTOP.setFocusable(false);
    this.btnPAUSE.setFocusable(false);
    this.btnStart.setFocusable(false);
    this.btnStop.setFocusable(false);
    this.reset.setFocusable(false);
    TapeCounter.setFocusable(false);
    TapeCounter.setFont(new Font("Monospaced", 1, 12));
    TapeCounter.setDoubleBuffered(false);
    this.btnREC.setBackground(new Color(255, 0, 0));
    this.btnPLAY.setBackground(Color.DARK_GRAY);
    this.btnFF.setBackground(Color.DARK_GRAY);
    this.btnSTOP.setBackground(Color.DARK_GRAY);
    this.btnPAUSE.setBackground(Color.DARK_GRAY);
    this.reset.setBackground(Color.DARK_GRAY);
    this.btnREC.setForeground(Color.WHITE);
    this.btnPLAY.setForeground(Color.WHITE);
    this.btnFF.setForeground(Color.WHITE);
    this.btnSTOP.setForeground(Color.WHITE);
    this.btnPAUSE.setForeground(Color.WHITE);
    TapeCounter.setBackground(Color.DARK_GRAY);
    TapeCounter.setForeground(Color.WHITE);
    this.reset.setForeground(Color.LIGHT_GRAY);
    tapepanel.setForeground(Color.LIGHT_GRAY);
    tapepanel.setBackground(Color.BLACK);
    setLayout(new BorderLayout());
    add(tapeblocks, "North");
    add(tapepanel, "Center");
    setTitle("TapeDeck");
    pack();
    setSize(272, 402);
    setResizable(false);
    setAlwaysOnTop(true);
    blocks.setEnabled(false);
  }
  
  public void paintWheels() {
    if (blocklist.isShowing())
      return; 
    if (CPC.tapesample != null) {
      if (position.getMaximum() != CPC.tapesample.length)
        position.setMaximum(CPC.tapesample.length); 
      position.setValue(CPC.tapeBandPosition);
      if (CPC.tapeRec) {
        position.setIndeterminate(true);
      } else {
        position.setIndeterminate(false);
      } 
    } 
    if (this.stoptimer != 0) {
      this.stoptimer++;
      if (this.stoptimer == 10) {
        this.stoptimer = 0;
        this.btnSTOP.setIcon(this.stopbu);
      } 
    } 
    this.paintthis++;
    if (this.paintthis > 20) {
      this.paintthis = 0;
      doPaint();
    } 
    this.updatewheels++;
    if (this.updatewheels > this.updater) {
      setWheels();
      this.updatewheels = 0;
    } 
  }
  
  public void doPaint() {
    try {
      if (!tapeload.isShowing() && !this.c90.isShowing()) {
        this.wheels.paintWheels();
        if (CPC.tapesample != null)
          this.tapeinfo.paintInfo(); 
      } 
    } catch (Exception exception) {}
  }
  
  public void checkTape() {
    this.hastape = (CPC.tapesample != null);
    if (!this.hastape && this.skin == 0) {
      this.skin = 1;
      this.tup.setIcon(this.tapupe);
      this.tleft.setIcon(this.taplefte);
      this.tright.setIcon(this.taprighte);
      this.tlow.setIcon(this.taplowe);
      this.tupl.setVisible(false);
      this.tupr.setVisible(false);
      this.tapeinfo.setVisible(false);
      setSize(272, 402);
      doPaint();
    } 
    if (this.hastape && this.skin == 1) {
      this.skin = 0;
      this.tup.setIcon(this.tapup);
      this.tleft.setIcon(this.tapleft);
      this.tright.setIcon(this.tapright);
      this.tlow.setIcon(this.taplow);
      this.tupl.setVisible(true);
      this.tupr.setVisible(true);
      this.tapeinfo.setVisible(true);
      setSize(272, 402);
      doPaint();
    } 
  }
  
  public void setWheels() {
    int pos2;
    if (!this.hastape) {
      this.wleft.setIcon(this.wheel[4]);
      this.wright.setIcon(this.wheel[4]);
      return;
    } 
    if ((CPC.playing && (CPC.tapeRelay || CPC.trueaudio) && !this.paused && (CPC.tapeRec || CPC.tapePlay)) || CPC.tapeRewind || CPC.tapeFastForward)
      this.pos += this.stepper; 
    if (this.pos >= 4 || this.pos <= -4)
      this.pos = 0; 
    switch (this.pos) {
      case -1:
        pos2 = 3;
        break;
      case -2:
        pos2 = 2;
        break;
      case -3:
        pos2 = 1;
        break;
      default:
        pos2 = this.pos;
        break;
    } 
    this.wleft.setIcon(this.wheel[pos2]);
    this.wright.setIcon(this.wheel[pos2]);
  }
  
  public void setPos(int i) {
    try {
      CPC.tapeBandPosition = CPC.blocks[i];
      TapeCounter.setCounter(GateArray.cpc.getTapeCounter());
      GateArray.cpc.printTapeTime();
      System.out.println("Setting tape position to " + (int)GateArray.cpc.getTapeCounter());
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == this.recFull) {
      Settings.setBoolean("record_full_tape", this.recFull.isSelected());
      CPC.recordFull = this.recFull.isSelected();
    } 
    if (e.getSource() == this.create)
      pressRec(true); 
    if (e.getSource() == this.resize)
      reSize(); 
    if (e.getSource() == savetape)
      CPC.savetape = true; 
    if (e.getSource() == tapeload)
      CPC.tapeload = true; 
    if (e.getSource() == this.play)
      pressPlay(); 
    if (e.getSource() == this.record)
      pressRec(false); 
    if (e.getSource() == this.rewind)
      pressRew(); 
    if (e.getSource() == this.forward)
      pressFwd(); 
    if (e.getSource() == this.stop)
      pressStop(); 
    if (e.getSource() == this.pause)
      pressPause(); 
    if (e.getSource() == this.eject)
      pressEject(); 
    if (e.getSource() == this.c30) {
      Settings.set("tape_size", "C30");
      this.C30 = this.c30.isSelected();
      this.C90 = false;
    } 
    if (e.getSource() == this.c90) {
      Settings.set("tape_size", "C90");
      this.C90 = this.c90.isSelected();
      this.C30 = false;
    } 
    if (e.getSource() == this.c60) {
      Settings.set("tape_size", "C60");
      this.C90 = !this.c60.isSelected();
      this.C30 = false;
    } 
  }
  
  public void pressPlay() {
    showText();
    this.buttonpressed = true;
    if (!CPC.tapeRec) {
      this.stepper = 1;
      this.updater = 6;
      blanktape = false;
      if (Switches.FloppySound && (CPC.tapeFastForward || CPC.tapeRewind))
        Samples.TAPESTOP.play(); 
      this.playing = true;
      CPC.tapeRec = false;
      CPC.tapePlay = true;
      CPC.tapeRewind = false;
      CPC.tapeFastForward = false;
      if (Switches.FloppySound) {
        Samples.TAPEKEY.play();
        Samples.WINDMOTOR.stop();
        Samples.REWINDMOTOR.stop();
        if (CPC.tapeRelay)
          Samples.TAPEMOTOR.loop(); 
      } 
      this.btnREW.setIcon(this.rewbu);
      this.btnFF.setIcon(this.ffbu);
      this.btnPLAY.setIcon(this.playbup);
      this.btnSTOP.setIcon(this.stopbu);
      this.btnREC.setIcon(this.recbu);
      this.btnREW.setBorder(new BevelBorder(0));
      this.btnPLAY.setBorder(new BevelBorder(1));
      this.btnPLAY.setBackground(Color.BLACK);
      this.btnFF.setBorder(new BevelBorder(0));
      this.btnSTOP.setBorder(new BevelBorder(0));
      this.btnREC.setBorder(new BevelBorder(0));
      this.btnREC.setBackground(new Color(255, 0, 0));
      this.btnREW.setBackground(Color.DARK_GRAY);
      this.btnFF.setBackground(Color.DARK_GRAY);
      this.btnREC.setForeground(Color.WHITE);
      this.btnREW.setForeground(Color.WHITE);
      this.btnPLAY.setForeground(Color.LIGHT_GRAY);
      this.btnFF.setForeground(Color.WHITE);
      createBlocks(CPC.tapesample);
    } 
  }
  
  public void pressRec(boolean pause) {
    if (CPC.tapesample == null)
      pause = true; 
    GateArray.cpc.counterInit = 20;
    if (pause) {
      this.tapeinfo.setInfo("My tape - not saved yet!!!", false);
      setName("Blank tape inserted...");
      CPC.ids = null;
      CPC.blocks = null;
    } 
    this.buttonpressed = true;
    if (!this.playing) {
      this.stepper = 1;
      this.updater = 6;
      blanktape = pause;
      tapeChanged = true;
      showText(this.filename);
      CPC.tapeloaded = true;
      if (pause)
        CPC.tapesample = null; 
      CPC.tape_stereo = false;
      long Size = Switches.availmem;
      this.C30 = this.c30.isSelected();
      this.C90 = false;
      if (this.c90.isSelected()) {
        this.C90 = true;
      } else if (this.c60.isSelected()) {
        this.C90 = false;
      } 
      if (this.C90 && Size > 119216000L) {
        Size = 119216000L;
      } else if (Size > 79500000L) {
        Size = 79500000L;
      } 
      if (this.C30)
        Size = 19853000L; 
      if (pause) {
        try {
          CPC.tapesample = new byte[(int)Size];
          for (int i = 0; i < CPC.tapesample.length; i++)
            CPC.tapesample[i] = Byte.MIN_VALUE; 
          System.out.println(Size);
        } catch (Exception tooLarge) {
          tooLarge.printStackTrace();
          System.exit(0);
        } 
        GateArray.cpc.frequency = 44100;
        CPC.tape_stereo = false;
        if (Switches.khz44) {
          CPC.tape_delay = 22;
          GateArray.cpc.frequency = 44100;
        } 
        if (Switches.khz11) {
          CPC.tape_delay = 90;
          GateArray.cpc.frequency = 11025;
        } 
        if (!Switches.khz11 && !Switches.khz44) {
          CPC.tape_delay = 45;
          GateArray.cpc.frequency = 22050;
        } 
        CPC.tapeBandPosition = 0;
        CPC.recordcount = 0;
        createBlocks(CPC.tapesample);
      } 
      buildTapeBlocks();
      CPC.tapeRec = true;
      CPC.tapePlay = true;
      CPC.tapeRewind = false;
      CPC.tapeFastForward = false;
      this.playing = false;
      if (Switches.FloppySound) {
        Samples.TAPEKEY.play();
        Samples.WINDMOTOR.stop();
        Samples.REWINDMOTOR.stop();
        if (CPC.tapeRelay)
          Samples.TAPEMOTOR.loop(); 
      } 
      this.btnREW.setIcon(this.rewbu);
      this.btnFF.setIcon(this.ffbu);
      this.btnPLAY.setIcon(this.playbup);
      this.btnSTOP.setIcon(this.stopbu);
      this.btnREC.setIcon(this.recbup);
      this.btnREW.setBorder(new BevelBorder(0));
      this.btnPLAY.setBorder(new BevelBorder(1));
      this.btnFF.setBorder(new BevelBorder(0));
      this.btnSTOP.setBorder(new BevelBorder(0));
      this.btnREC.setBorder(new BevelBorder(1));
      this.btnREC.setBackground(Color.BLACK);
      this.btnREW.setBackground(Color.DARK_GRAY);
      this.btnPLAY.setBackground(Color.BLACK);
      this.btnFF.setBackground(Color.DARK_GRAY);
      this.btnREC.setForeground(Color.LIGHT_GRAY);
      this.btnREW.setForeground(Color.WHITE);
      this.btnPLAY.setForeground(Color.LIGHT_GRAY);
      this.btnFF.setForeground(Color.WHITE);
    } 
  }
  
  public void pressRew() {
    showText();
    this.buttonpressed = true;
    if (!CPC.tapeRec) {
      this.stepper = -1;
      this.updater = 1;
      blanktape = false;
      if (Switches.FloppySound && 
        CPC.tapeFastForward)
        Samples.TAPESTOP.play(); 
      CPC.tapeRec = false;
      CPC.tapeRewind = true;
      CPC.tapeFastForward = false;
      this.playing = false;
      this.btnREW.setIcon(this.rewbup);
      this.btnFF.setIcon(this.ffbu);
      this.btnSTOP.setIcon(this.stopbu);
      this.btnREC.setIcon(this.recbu);
      this.btnREC.setForeground(Color.WHITE);
      this.btnREW.setForeground(Color.LIGHT_GRAY);
      this.btnFF.setForeground(Color.WHITE);
      this.btnREW.setBorder(new BevelBorder(1));
      if (!CPC.tapePlay) {
        this.btnPLAY.setBorder(new BevelBorder(0));
        this.btnPLAY.setBackground(Color.DARK_GRAY);
      } 
      this.btnFF.setBorder(new BevelBorder(0));
      this.btnSTOP.setBorder(new BevelBorder(0));
      this.btnREW.setBackground(Color.BLACK);
      this.btnFF.setBackground(Color.DARK_GRAY);
      if (Switches.FloppySound) {
        Samples.TAPEKEY.play();
        Samples.WINDMOTOR.stop();
        Samples.REWINDMOTOR.loop();
        Samples.TAPEMOTOR.stop();
      } 
    } 
  }
  
  public void pressFwd() {
    showText();
    this.buttonpressed = true;
    if (!CPC.tapeRec) {
      this.stepper = 1;
      this.updater = 1;
      blanktape = false;
      if (Switches.FloppySound && 
        CPC.tapeRewind)
        Samples.TAPESTOP.play(); 
      CPC.tapeRec = false;
      CPC.tapeRewind = false;
      CPC.tapeFastForward = true;
      this.playing = false;
      if (Switches.FloppySound) {
        Samples.TAPEKEY.play();
        Samples.WINDMOTOR.loop();
        Samples.REWINDMOTOR.stop();
        Samples.TAPEMOTOR.stop();
      } 
      this.btnREW.setBorder(new BevelBorder(0));
      if (!CPC.tapePlay) {
        this.btnPLAY.setBackground(Color.DARK_GRAY);
        this.btnPLAY.setBorder(new BevelBorder(0));
      } 
      this.btnREW.setIcon(this.rewbu);
      this.btnFF.setIcon(this.ffbup);
      this.btnSTOP.setIcon(this.stopbu);
      this.btnREC.setIcon(this.recbu);
      this.btnFF.setBorder(new BevelBorder(1));
      this.btnSTOP.setBorder(new BevelBorder(0));
      this.btnREC.setBorder(new BevelBorder(0));
      this.btnREC.setBackground(new Color(255, 0, 0));
      this.btnREW.setBackground(Color.DARK_GRAY);
      this.btnFF.setBackground(Color.BLACK);
      this.btnREC.setForeground(Color.WHITE);
      this.btnREW.setForeground(Color.WHITE);
      this.btnFF.setForeground(Color.LIGHT_GRAY);
    } 
  }
  
  public void pressStop() {
    if (!CPC.tapePlay && !CPC.tapeRewind && !CPC.tapeFastForward && 
      !CPC.tapeloaded) {
      if (!tapeChanged) {
        CPC.tapeload = true;
        return;
      } 
      if (CPC.recordcount < 100) {
        CPC.tapeload = true;
        return;
      } 
    } 
    CPC.tapeRec = false;
    blanktape = false;
    if (CPC.tapesample == null)
      setName("No tape inserted..."); 
    this.btnSTOP.setIcon(this.stopbup);
    this.stoptimer = 1;
    showText();
    GateArray.cpc.restoreScreen();
    rebuildBlocks(CPC.tapeBandPosition);
    this.stepper = 1;
    this.updater = 6;
    if (!this.buttonpressed) {
      if (tapeChanged && CPC.recordcount > 100) {
        Object[] options = { "Yes", "No" };
        int n = JOptionPane.showOptionDialog(this, "Your WAV is not saved!\nDo you want to save it now?", "Save your tape?", 0, 2, null, options, options[0]);
        if (n != 1) {
          CPC.savetape = true;
          return;
        } 
      } 
      Desktop.checkdrives = true;
      CPC.tapesample = null;
      tapeChanged = false;
      setInfo("", true);
      setName("No tape inserted...");
      Settings.set("tapelabel", "");
      Settings.set("file.tape", "~none~");
      Settings.setBoolean("loadtape", false);
      showText();
      CPC.tapeloaded = false;
      TapeCounter.setCounter(0.0D);
      this.Counter = "000";
      CPC.tapeBandPosition = 0;
      CPC.ids = null;
      CPC.blocks = null;
      buildTapeBlocks();
      if (Switches.FloppySound)
        Samples.TAPEEJECT.play(); 
      doPaint();
      setWheels();
      checkTape();
      paintWheels();
      this.skin = 1;
      this.tup.setIcon(this.tapupe);
      this.tleft.setIcon(this.taplefte);
      this.tright.setIcon(this.taprighte);
      this.tlow.setIcon(this.taplowe);
      this.tupl.setVisible(false);
      this.tupr.setVisible(false);
      this.tapeinfo.setVisible(false);
      setSize(272, 402);
      tapepanel.repaint();
    } 
    CPC.tapeRec = false;
    CPC.tapePlay = false;
    CPC.tapeRewind = false;
    CPC.tapeFastForward = false;
    this.buttonpressed = false;
    this.playing = false;
    if (Switches.FloppySound) {
      Samples.TAPESTOP.play();
      Samples.WINDMOTOR.stop();
      Samples.REWINDMOTOR.stop();
      Samples.TAPEMOTOR.stop();
    } 
    this.btnREW.setIcon(this.rewbu);
    this.btnFF.setIcon(this.ffbu);
    this.btnPLAY.setIcon(this.playbu);
    this.btnREC.setIcon(this.recbu);
    this.btnREW.setBorder(new BevelBorder(0));
    this.btnPLAY.setBorder(new BevelBorder(0));
    this.btnFF.setBorder(new BevelBorder(0));
    this.btnSTOP.setBorder(new BevelBorder(0));
    this.btnREC.setBorder(new BevelBorder(0));
    this.btnREC.setBackground(new Color(255, 0, 0));
    this.btnREW.setBackground(Color.DARK_GRAY);
    this.btnPLAY.setBackground(Color.DARK_GRAY);
    this.btnFF.setBackground(Color.DARK_GRAY);
    this.btnREC.setForeground(Color.WHITE);
    this.btnREW.setForeground(Color.WHITE);
    this.btnPLAY.setForeground(Color.WHITE);
    this.btnFF.setForeground(Color.WHITE);
  }
  
  public void pressPause() {
    showText();
    if (Switches.FloppySound)
      Samples.TAPEKEY.play(); 
    if (this.paused) {
      this.btnPAUSE.setIcon(this.pausebu);
      this.btnPAUSE.setBackground(Color.DARK_GRAY);
      this.paused = false;
      if (CPC.tapePlay || CPC.tapeRec)
        this.stepper = 1; 
    } else {
      this.btnPAUSE.setIcon(this.pausebup);
      this.btnPAUSE.setBackground(Color.BLACK);
      this.paused = true;
      this.stepper = 1;
    } 
  }
  
  public void pressEject() {
    Settings.set("tapelabel", "");
    System.out.println("Tape ejected");
    pressStop();
    pressStop();
    buildTapeBlocks();
  }
  
  public String getCounter(int pos) {
    int ccounter = 0;
    try {
      ccounter = (int)GateArray.cpc.getTapeCounter(CPC.blocks[pos]);
    } catch (Exception exception) {}
    String before = "";
    if (ccounter <= 99)
      before = "0"; 
    if (ccounter <= 9)
      before = "00"; 
    return before + ccounter;
  }
  
  public void createBlocks(byte[] sample) {
    if (CPC.isCDT)
      return; 
    if (sample == null)
      return; 
    int blocks = 0;
    boolean toggleBlock = true;
    int[] positions = new int[10000];
    int i;
    for (i = 0; i < sample.length - 20000; i += 20000) {
      boolean blank = true;
      int v = 0;
      for (int g = 0; g < 20000; g++) {
        try {
          v = sample[i + g] & 0xFF;
          if (v == 38) {
            blank = false;
            break;
          } 
        } catch (Exception e) {}
      } 
      if (toggleBlock != blank) {
        toggleBlock = blank;
        positions[blocks] = i;
        blocks++;
      } 
    } 
    CPC.ids = new String[blocks + 2];
    CPC.blocks = new int[blocks + 2];
    CPC.blocks[0] = 0;
    CPC.ids[0] = "Pause";
    for (i = 0; i <= blocks; i++) {
      if (i % 2 == 0) {
        CPC.ids[i + 1] = "Turbo data";
      } else {
        CPC.ids[i + 1] = "Pause";
      } 
      CPC.blocks[i + 1] = positions[i];
    } 
    CPC.ids[blocks + 1] = "Eject tape";
    CPC.blocks[blocks + 1] = CPC.tapesample.length;
    System.out.println(blocks + " blocks found.");
    buildTapeBlocks();
  }
  
  public void buildTapeBlocks() {
    savetape.setEnabled(false);
    String foundblocks = "";
    try {
      if (CPC.ids != null) {
        blocks.setEnabled(true);
        for (int i = 0; i < CPC.ids.length; i++) {
          String ccounter = getCounter(i);
          String str1 = "" + (i + 1);
          while (str1.length() < 3)
            str1 = "0" + str1; 
          foundblocks = foundblocks + str1 + " - " + ccounter + ": " + CPC.ids[i] + "#";
        } 
      } else {
        if (CPC.tapesample != null)
          createBlocks(CPC.tapesample); 
        blocks.setEnabled(true);
      } 
      final String[] bl = foundblocks.split("#");
      blocklist.setModel(new AbstractListModel() {
            public int getSize() {
              return bl.length;
            }
            
            public Object getElementAt(int i) {
              return bl[i];
            }
          });
    } catch (Exception e) {
      blocks.setEnabled(false);
    } 
    if (CPC.tapesample != null)
      savetape.setEnabled(true); 
  }
  
  public void rebuildBlocks(int value) {
    if (CPC.ids == null)
      return; 
    for (int i = 1; i < CPC.ids.length; i++) {
      try {
        if (CPC.blocks[i] > value) {
          blocklist.setSelectedIndex(i - 1);
          break;
        } 
      } catch (Exception e) {
        break;
      } 
    } 
  }
  
  public void setInfo(String s, boolean store) {
    this.tapeinfo.setInfo(s, store);
  }
  
  public String getCounter() {
    return this.Counter;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\tape\TapeDeck.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */