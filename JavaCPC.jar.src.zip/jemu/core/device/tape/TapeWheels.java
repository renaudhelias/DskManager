package jemu.core.device.tape;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;
import jemu.system.cpc.CPC;
import jemu.system.cpc.GateArray;
import jemu.ui.Switches;

public class TapeWheels extends JPanel {
  BufferedImage panel;
  
  private final int CANVAS_WIDTH = 55;
  
  private final int CANVAS_HEIGHT = 28;
  
  private Color wheel;
  
  private Color spindle;
  
  private Color back;
  
  private Color mirror;
  
  private boolean flash;
  
  private boolean flashb;
  
  Graphics page;
  
  private int center;
  
  private int right;
  
  private int left;
  
  private int leftwheel;
  
  private int rightwheel;
  
  private int size;
  
  private int highvalue;
  
  public TapeWheels() {
    this.panel = new BufferedImage(55, 28, 1);
    this.wheel = new Color(13816796);
    this.spindle = new Color(5978926);
    this.back = new Color(3421752);
    this.mirror = new Color(11180181);
    this.center = -4;
    this.right = 48;
    this.left = -30;
    setBackground(this.back);
    setForeground(Color.GRAY);
    setPreferredSize(new Dimension(55, 28));
    setFont(new Font("Arial", 1, 9));
    this.page = this.panel.getGraphics();
  }
  
  public void paintWheels() {
    Graphics p = getGraphics();
    this.page.setColor(this.back);
    this.page.fillRect(0, 0, 55, 28);
    this.page.setColor(this.mirror);
    this.page.fillRect(6, 2, 42, 20);
    if (CPC.tapesample != null && 
      CPC.tapesample.length > 1) {
      int div = 2;
      if (Switches.khz11)
        div = 4; 
      if (Switches.khz44)
        div = 1; 
      this.leftwheel = GateArray.cpc.getLeftRadius();
      this.rightwheel = GateArray.cpc.getRightRadius();
      if (this.leftwheel < 1)
        this.leftwheel = 1; 
      this.rightwheel++;
      this.page.setColor(this.spindle);
      if (TapeDeck.tapeChanged)
        if (this.flash) {
          this.page.setColor(Color.red);
          this.flash = false;
        } else {
          this.flash = true;
        }  
      this.page.fillOval(this.left - this.leftwheel / 2, this.center - this.leftwheel / 2, 36 + this.leftwheel, 36 + this.leftwheel);
      if (TapeDeck.tapeChanged)
        if (this.flashb) {
          this.page.setColor(Color.green);
          this.flashb = false;
        } else {
          this.flashb = true;
        }  
      this.page.fillOval(this.right - this.rightwheel / 2, this.center - this.rightwheel / 2, 36 + this.rightwheel, 36 + this.rightwheel);
      this.page.setColor(this.wheel);
      this.page.fillOval(this.left, this.center, 36, 36);
      this.page.fillOval(this.right, this.center, 36, 36);
    } 
    p.drawImage(this.panel, 0, 0, this);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\tape\TapeWheels.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */