package jemu.core.device.tape;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import javax.swing.JPanel;
import jemu.settings.Settings;

public class TapeInfo extends JPanel {
  BufferedImage panel;
  
  private final int CANVAS_WIDTH = 152;
  
  private final int CANVAS_HEIGHT = 26;
  
  private Color back;
  
  private Color text;
  
  public String Info;
  
  private Font font;
  
  private int center;
  
  Graphics page;
  
  public TapeInfo() {
    this.panel = new BufferedImage(152, 26, 1);
    this.page = this.panel.getGraphics();
    this.back = new Color(15263976);
    this.text = new Color(1381735);
    this.center = 16;
    setInfo(Settings.get("tapelabel", ""), false);
    setBackground(this.back);
    setForeground(this.text);
    setSize(152, 26);
    setPreferredSize(new Dimension(152, 26));
  }
  
  public void setInfo(String s, boolean store) {
    this.Info = s;
    while (this.Info.contains("  "))
      this.Info = this.Info.replace("  ", " "); 
    if (this.Info.length() < 1)
      return; 
    int d = this.Info.charAt(0);
    if (d >= 48 && d <= 57 && this.Info.contains(" ")) {
      while (!this.Info.startsWith(" "))
        this.Info = this.Info.substring(1); 
      this.Info = this.Info.substring(1);
    } 
    d = this.Info.charAt(0);
    if ((d <= 64 || d == 45) && this.Info.contains(" ")) {
      while (!this.Info.startsWith(" "))
        this.Info = this.Info.substring(1); 
      this.Info = this.Info.substring(1);
    } 
    d = this.Info.charAt(0);
    if (d >= 48 && d <= 57 && this.Info.contains(" ")) {
      while (!this.Info.startsWith(" "))
        this.Info = this.Info.substring(1); 
      this.Info = this.Info.substring(1);
    } 
    d = this.Info.charAt(0);
    if ((d <= 64 || d == 45) && this.Info.contains(" ")) {
      while (!this.Info.startsWith(" "))
        this.Info = this.Info.substring(1); 
      this.Info = this.Info.substring(1);
    } 
    boolean ignore = false;
    String newInfo = "";
    String reInfo = "";
    for (int i = 0; i < this.Info.length(); i++) {
      newInfo = "" + this.Info.charAt(i);
      if ((i > 0 && this.Info.charAt(i - 1) == ' ') || i == 0) {
        ignore = true;
      } else {
        ignore = false;
      } 
      if (!ignore) {
        newInfo = newInfo.toLowerCase();
      } else {
        newInfo = newInfo.toUpperCase();
      } 
      reInfo = reInfo + newInfo;
    } 
    if (reInfo.contains(" (")) {
      while (reInfo.contains("("))
        reInfo = reInfo.substring(0, reInfo.length() - 1); 
      reInfo = reInfo.replace(" (", "");
    } 
    this.Info = reInfo;
    System.out.println("Setting tapelabel:" + this.Info);
    Settings.set("tapelabel", this.Info);
    InputStream in = getClass().getResourceAsStream("image/SF-Heather.ttf");
    try {
      if (this.Info.length() < 10) {
        this.font = Font.createFont(0, in).deriveFont(0, 18.0F);
      } else if (this.Info.length() < 15) {
        this.font = Font.createFont(0, in).deriveFont(0, 16.0F);
      } else if (this.Info.length() < 18) {
        this.font = Font.createFont(0, in).deriveFont(0, 14.0F);
      } else if (this.Info.length() < 22) {
        this.font = Font.createFont(0, in).deriveFont(0, 13.0F);
      } else if (this.Info.length() < 25) {
        this.font = Font.createFont(0, in).deriveFont(0, 12.0F);
      } else if (this.Info.length() < 30) {
        this.font = Font.createFont(0, in).deriveFont(0, 11.0F);
      } else {
        this.font = Font.createFont(0, in).deriveFont(0, 9.0F);
      } 
    } catch (Exception e) {
      System.err.println(e.getMessage());
      this.font = new Font("Arial", 3, 12);
    } 
    this.page.setFont(this.font);
  }
  
  public void paintInfo() {
    if (this.Info == null || this.Info.length() < 1)
      return; 
    this.page.setFont(this.font);
    Graphics p = getGraphics();
    this.page.setColor(this.back);
    this.page.fillRect(0, 0, 152, 26);
    this.page.setColor(this.text);
    this.page.drawString(this.Info, 0, this.center);
    p.drawImage(this.panel, 0, 0, this);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\tape\TapeInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */