package jemu.core.device.tape;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class CounterDigit extends JPanel {
  final URL digitsDark = getClass().getResource("counter.png");
  
  final URL digitsLight = getClass().getResource("counter2.png");
  
  Image Digits = getToolkit().getImage(this.digitsDark);
  
  boolean light = false;
  
  int pos;
  
  int height;
  
  BufferedImage imag;
  
  private JLabel jLabel1;
  
  public void toggleFormat() {
    this.light = !this.light;
    if (this.light) {
      this.Digits = getToolkit().getImage(this.digitsLight);
    } else {
      this.Digits = getToolkit().getImage(this.digitsDark);
    } 
  }
  
  public CounterDigit() {
    this.pos = 0;
    this.height = 22;
    this.imag = new BufferedImage(11, this.height, 1);
    initComponents();
  }
  
  public void setValue(double value) {
    value *= 10.0D;
    this.pos = (int)(value * 2.2D);
    Graphics g = this.imag.createGraphics();
    g.drawImage(this.Digits, 0, 0 - this.pos, this);
    int p = 0;
    for (int i = 0; i < 56; i += 6) {
      g.setColor(new Color(0, 0, 0, 224 - (i << 2)));
      g.drawLine(0, p, 11, p);
      g.drawLine(0, this.height - p, 11, this.height - p);
      p++;
    } 
    this.jLabel1.setIcon(new ImageIcon(this.imag));
  }
  
  private void initComponents() {
    this.jLabel1 = new JLabel();
    setLayout(new BorderLayout());
    this.jLabel1.setBackground(new Color(0, 0, 204));
    add(this.jLabel1, "Center");
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\tape\CounterDigit.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */