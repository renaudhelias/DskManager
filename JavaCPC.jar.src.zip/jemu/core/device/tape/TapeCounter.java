package jemu.core.device.tape;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;

public class TapeCounter extends JPanel {
  double counterValue;
  
  private CounterDigit counterDigit1;
  
  private CounterDigit counterDigit2;
  
  private CounterDigit counterDigit3;
  
  public TapeCounter() {
    this.counterValue = 0.0D;
    initComponents();
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            TapeCounter.this.setCounter(0.0D);
          }
        });
  }
  
  public double getCounter() {
    return this.counterValue;
  }
  
  public void setCounter(double value) {
    value += 0.001D;
    value %= 1000.0D;
    this.counterValue = value;
    String p = "" + value;
    if (p.toLowerCase().contains("nan"))
      return; 
    if (value < 10.0D) {
      p = "00" + p;
    } else if (value < 100.0D) {
      p = "0" + p;
    } 
    String d1 = "" + p.charAt(0);
    String d2 = "" + p.charAt(1);
    String d3 = "" + p.charAt(2) + "." + p.charAt(4) + p.charAt(5);
    double dig1 = Double.parseDouble(d1);
    double dig2 = Double.parseDouble(d2);
    double dig3 = Double.parseDouble(d3);
    dig3 %= 10.0D;
    dig2 %= 10.0D;
    dig1 %= 10.0D;
    if (dig3 > 9.1D)
      dig2 += (dig3 - 9.0D) * 10.0D / 10.0D; 
    if (dig2 > 9.1D)
      dig1 += (dig2 - 9.0D) * 10.0D / 10.0D; 
    this.counterDigit1.setValue(dig1);
    this.counterDigit2.setValue(dig2);
    this.counterDigit3.setValue(dig3);
  }
  
  private void initComponents() {
    this.counterDigit1 = new CounterDigit();
    this.counterDigit2 = new CounterDigit();
    this.counterDigit3 = new CounterDigit();
    addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            TapeCounter.this.formMouseClicked(evt);
          }
        });
    setLayout(new FlowLayout(1, 0, 0));
    this.counterDigit1.setFocusable(false);
    this.counterDigit1.setPreferredSize(new Dimension(11, 22));
    add(this.counterDigit1);
    this.counterDigit2.setFocusable(false);
    this.counterDigit2.setPreferredSize(new Dimension(11, 22));
    add(this.counterDigit2);
    this.counterDigit3.setFocusable(false);
    this.counterDigit3.setPreferredSize(new Dimension(11, 22));
    add(this.counterDigit3);
  }
  
  private void formMouseClicked(MouseEvent evt) {
    if (evt.getClickCount() > 1) {
      this.counterDigit1.toggleFormat();
      this.counterDigit2.toggleFormat();
      this.counterDigit3.toggleFormat();
      setCounter(getCounter());
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\tape\TapeCounter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */