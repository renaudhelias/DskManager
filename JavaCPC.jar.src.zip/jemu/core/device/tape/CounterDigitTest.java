package jemu.core.device.tape;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class CounterDigitTest extends JFrame {
  double value = 900.0001D;
  
  ActionListener updateTape = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        CounterDigitTest.this.value += 0.10001D;
        CounterDigitTest.this.value %= 1000.0D;
        String p = "" + CounterDigitTest.this.value;
        if (CounterDigitTest.this.value < 10.0D) {
          p = "00" + p;
        } else if (CounterDigitTest.this.value < 100.0D) {
          p = "0" + p;
        } 
        String d1 = "" + p.charAt(0);
        String d2 = "" + p.charAt(1);
        String d3 = "" + p.charAt(2) + "." + p.charAt(4) + p.charAt(5) + p.charAt(6);
        double dig1 = Double.parseDouble(d1);
        double dig2 = Double.parseDouble(d2);
        double dig3 = Double.parseDouble(d3);
        dig3 %= 10.0D;
        dig2 %= 10.0D;
        dig1 %= 10.0D;
        if (dig3 > 8.9D)
          dig2 += (dig3 - 9.0D) * 10.0D / 10.0D; 
        if (dig2 > 8.9D)
          dig1 += (dig2 - 9.0D) * 10.0D / 10.0D; 
        CounterDigitTest.this.counterDigit1.setValue(dig1);
        CounterDigitTest.this.counterDigit2.setValue(dig2);
        CounterDigitTest.this.counterDigit3.setValue(dig3);
      }
    };
  
  public Timer Updater = new Timer(100, this.updateTape);
  
  private CounterDigit counterDigit1;
  
  private CounterDigit counterDigit2;
  
  private CounterDigit counterDigit3;
  
  private JButton jButton1;
  
  private JCheckBox jCheckBox1;
  
  private JLabel jLabel1;
  
  private JLabel jLabel2;
  
  private JLabel jLabel3;
  
  public CounterDigitTest() {
    initComponents();
    this.counterDigit1.setValue(0.0D);
    this.counterDigit2.setValue(0.0D);
    this.counterDigit3.setValue(0.0D);
  }
  
  private void initComponents() {
    this.jLabel3 = new JLabel();
    this.counterDigit1 = new CounterDigit();
    this.counterDigit2 = new CounterDigit();
    this.counterDigit3 = new CounterDigit();
    this.jLabel1 = new JLabel();
    this.jCheckBox1 = new JCheckBox();
    this.jLabel2 = new JLabel();
    this.jButton1 = new JButton();
    setDefaultCloseOperation(3);
    setBackground(new Color(0, 0, 0));
    setResizable(false);
    getContentPane().setLayout(new FlowLayout(1, 0, 5));
    this.jLabel3.setText("            ");
    getContentPane().add(this.jLabel3);
    this.counterDigit1.setPreferredSize(new Dimension(11, 22));
    getContentPane().add(this.counterDigit1);
    this.counterDigit2.setPreferredSize(new Dimension(11, 22));
    getContentPane().add(this.counterDigit2);
    this.counterDigit3.setPreferredSize(new Dimension(11, 22));
    getContentPane().add(this.counterDigit3);
    this.jLabel1.setText("            ");
    getContentPane().add(this.jLabel1);
    this.jCheckBox1.setText("Run");
    this.jCheckBox1.setFocusable(false);
    this.jCheckBox1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            CounterDigitTest.this.jCheckBox1ActionPerformed(evt);
          }
        });
    getContentPane().add(this.jCheckBox1);
    this.jLabel2.setText("            ");
    getContentPane().add(this.jLabel2);
    this.jButton1.setText("Reset");
    this.jButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            CounterDigitTest.this.jButton1ActionPerformed(evt);
          }
        });
    getContentPane().add(this.jButton1);
    pack();
  }
  
  private void jCheckBox1ActionPerformed(ActionEvent evt) {
    if (this.jCheckBox1.isSelected()) {
      this.Updater.start();
    } else {
      this.Updater.stop();
    } 
  }
  
  private void jButton1ActionPerformed(ActionEvent evt) {
    this.value = 900.0D;
    this.counterDigit1.setValue(0.0D);
    this.counterDigit2.setValue(0.0D);
    this.counterDigit3.setValue(0.0D);
  }
  
  public static void main(String[] args) {
    try {
      for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
          UIManager.setLookAndFeel(info.getClassName());
          break;
        } 
      } 
    } catch (ClassNotFoundException ex) {
      Logger.getLogger(CounterDigitTest.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (InstantiationException ex) {
      Logger.getLogger(CounterDigitTest.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (IllegalAccessException ex) {
      Logger.getLogger(CounterDigitTest.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (UnsupportedLookAndFeelException ex) {
      Logger.getLogger(CounterDigitTest.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new CounterDigitTest()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\tape\CounterDigitTest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */