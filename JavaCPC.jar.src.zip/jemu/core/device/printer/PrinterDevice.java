package jemu.core.device.printer;

import jemu.core.device.Device;

public class PrinterDevice extends Device {
  public PrinterDevice(String name) {
    super(name);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\printer\PrinterDevice.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */