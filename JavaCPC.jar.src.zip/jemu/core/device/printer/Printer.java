package jemu.core.device.printer;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import jemu.ui.Desktop;
import jemu.ui.Switches;

public class Printer extends PrinterDevice {
  DMP2000 dmp;
  
  public Thread printer;
  
  boolean isRunning = false;
  
  boolean init = true;
  
  final JFrame frame = new JFrame("Amstrad DMP 2000");
  
  public static boolean matrixprinter = false;
  
  boolean hasmatrixpanel;
  
  public Printer() {
    super("Amstrad DMP 2000");
    this.hasmatrixpanel = false;
  }
  
  public void init() {
    if (this.dmp == null) {
      this.dmp = new DMP2000();
      if (Desktop.isDesktop) {
        Desktop.printframe.remove(Desktop.textprinter);
        Desktop.printframe.add(this.dmp, "Center");
        this.hasmatrixpanel = true;
        Desktop.printframe.pack();
      } else {
        this.frame.setLayout(new BorderLayout());
        this.frame.add(this.dmp, "Center");
        this.frame.setDefaultCloseOperation(1);
        this.frame.pack();
        this.frame.setAlwaysOnTop(false);
      } 
    } 
    this.dmp.print(10);
    this.dmp.ypos -= this.dmp.ydpi;
    this.dmp.yprint -= this.dmp.ydpi;
    this.dmp.clearPage();
    this.isRunning = true;
    System.out.println("Printer installed!");
  }
  
  public void open() {
    if (Switches.Printer && !this.isRunning)
      init(); 
    if (Desktop.isDesktop) {
      Desktop.printframe.setVisible(!Desktop.printframe.isVisible());
    } else {
      if (this.isRunning && Switches.Printer)
        this.frame.setVisible(!this.frame.isVisible()); 
      if (this.frame.isVisible())
        this.frame.requestFocus(); 
    } 
  }
  
  public void writePort(int port, int value) {
    // Byte code:
    //   0: getstatic jemu/ui/Desktop.isDesktop : Z
    //   3: ifeq -> 148
    //   6: aload_0
    //   7: getfield isRunning : Z
    //   10: ifeq -> 148
    //   13: getstatic jemu/core/device/printer/Printer.matrixprinter : Z
    //   16: ifeq -> 85
    //   19: aload_0
    //   20: getfield hasmatrixpanel : Z
    //   23: ifne -> 148
    //   26: getstatic jemu/ui/JEMU.desktop : Ljemu/ui/Desktop;
    //   29: pop
    //   30: getstatic jemu/ui/Desktop.printframe : Ljavax/swing/JInternalFrame;
    //   33: getstatic jemu/ui/JEMU.desktop : Ljemu/ui/Desktop;
    //   36: pop
    //   37: getstatic jemu/ui/Desktop.textprinter : Ljavax/swing/JPanel;
    //   40: invokevirtual remove : (Ljava/awt/Component;)V
    //   43: getstatic jemu/ui/JEMU.desktop : Ljemu/ui/Desktop;
    //   46: pop
    //   47: getstatic jemu/ui/Desktop.printframe : Ljavax/swing/JInternalFrame;
    //   50: aload_0
    //   51: getfield dmp : Ljemu/core/device/printer/DMP2000;
    //   54: ldc 'Center'
    //   56: invokevirtual add : (Ljava/awt/Component;Ljava/lang/Object;)V
    //   59: aload_0
    //   60: iconst_1
    //   61: putfield hasmatrixpanel : Z
    //   64: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   67: ldc 'Matrixprinter replaced Textprinter!'
    //   69: invokevirtual println : (Ljava/lang/String;)V
    //   72: getstatic jemu/ui/JEMU.desktop : Ljemu/ui/Desktop;
    //   75: pop
    //   76: getstatic jemu/ui/Desktop.printframe : Ljavax/swing/JInternalFrame;
    //   79: invokevirtual pack : ()V
    //   82: goto -> 148
    //   85: aload_0
    //   86: getfield hasmatrixpanel : Z
    //   89: ifeq -> 148
    //   92: getstatic jemu/ui/JEMU.desktop : Ljemu/ui/Desktop;
    //   95: pop
    //   96: getstatic jemu/ui/Desktop.printframe : Ljavax/swing/JInternalFrame;
    //   99: aload_0
    //   100: getfield dmp : Ljemu/core/device/printer/DMP2000;
    //   103: invokevirtual remove : (Ljava/awt/Component;)V
    //   106: getstatic jemu/ui/JEMU.desktop : Ljemu/ui/Desktop;
    //   109: pop
    //   110: getstatic jemu/ui/Desktop.printframe : Ljavax/swing/JInternalFrame;
    //   113: getstatic jemu/ui/JEMU.desktop : Ljemu/ui/Desktop;
    //   116: pop
    //   117: getstatic jemu/ui/Desktop.textprinter : Ljavax/swing/JPanel;
    //   120: ldc 'Center'
    //   122: invokevirtual add : (Ljava/awt/Component;Ljava/lang/Object;)V
    //   125: aload_0
    //   126: iconst_0
    //   127: putfield hasmatrixpanel : Z
    //   130: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   133: ldc 'Textprinter replaced Matrixprinter!'
    //   135: invokevirtual println : (Ljava/lang/String;)V
    //   138: getstatic jemu/ui/JEMU.desktop : Ljemu/ui/Desktop;
    //   141: pop
    //   142: getstatic jemu/ui/Desktop.printframe : Ljavax/swing/JInternalFrame;
    //   145: invokevirtual pack : ()V
    //   148: getstatic jemu/core/device/printer/Printer.matrixprinter : Z
    //   151: ifeq -> 284
    //   154: getstatic jemu/ui/JEMU.textprinter : Ljemu/core/device/printer/TextPrinter;
    //   157: ifnull -> 184
    //   160: getstatic jemu/ui/JEMU.textprinter : Ljemu/core/device/printer/TextPrinter;
    //   163: pop
    //   164: getstatic jemu/core/device/printer/TextPrinter.typeconsole : Ljavax/swing/JFrame;
    //   167: invokevirtual isVisible : ()Z
    //   170: ifeq -> 184
    //   173: getstatic jemu/ui/JEMU.textprinter : Ljemu/core/device/printer/TextPrinter;
    //   176: pop
    //   177: getstatic jemu/core/device/printer/TextPrinter.typeconsole : Ljavax/swing/JFrame;
    //   180: iconst_0
    //   181: invokevirtual setVisible : (Z)V
    //   184: getstatic jemu/ui/Switches.Printer : Z
    //   187: ifeq -> 201
    //   190: aload_0
    //   191: getfield isRunning : Z
    //   194: ifne -> 201
    //   197: aload_0
    //   198: invokevirtual init : ()V
    //   201: aload_0
    //   202: getfield isRunning : Z
    //   205: ifeq -> 305
    //   208: getstatic jemu/ui/Switches.Printer : Z
    //   211: ifeq -> 305
    //   214: iload_2
    //   215: ifle -> 305
    //   218: iload_2
    //   219: bipush #120
    //   221: if_icmpge -> 305
    //   224: getstatic jemu/ui/Desktop.isDesktop : Z
    //   227: ifeq -> 257
    //   230: getstatic jemu/ui/JEMU.desktop : Ljemu/ui/Desktop;
    //   233: pop
    //   234: getstatic jemu/ui/Desktop.printframe : Ljavax/swing/JInternalFrame;
    //   237: invokevirtual isVisible : ()Z
    //   240: ifne -> 257
    //   243: getstatic jemu/ui/JEMU.desktop : Ljemu/ui/Desktop;
    //   246: pop
    //   247: getstatic jemu/ui/Desktop.printframe : Ljavax/swing/JInternalFrame;
    //   250: iconst_1
    //   251: invokevirtual setVisible : (Z)V
    //   254: goto -> 305
    //   257: getstatic jemu/ui/Desktop.isDesktop : Z
    //   260: ifne -> 305
    //   263: aload_0
    //   264: getfield frame : Ljavax/swing/JFrame;
    //   267: invokevirtual isVisible : ()Z
    //   270: ifne -> 305
    //   273: aload_0
    //   274: getfield frame : Ljavax/swing/JFrame;
    //   277: iconst_1
    //   278: invokevirtual setVisible : (Z)V
    //   281: goto -> 305
    //   284: aload_0
    //   285: getfield dmp : Ljemu/core/device/printer/DMP2000;
    //   288: ifnull -> 305
    //   291: getstatic jemu/ui/Desktop.isDesktop : Z
    //   294: ifne -> 305
    //   297: aload_0
    //   298: getfield frame : Ljavax/swing/JFrame;
    //   301: iconst_0
    //   302: invokevirtual setVisible : (Z)V
    //   305: iload_2
    //   306: sipush #128
    //   309: iand
    //   310: ifeq -> 364
    //   313: getstatic jemu/ui/Switches.Printer : Z
    //   316: ifeq -> 364
    //   319: iload_2
    //   320: bipush #127
    //   322: iand
    //   323: istore_2
    //   324: getstatic jemu/core/device/printer/Printer.matrixprinter : Z
    //   327: ifeq -> 341
    //   330: aload_0
    //   331: getfield dmp : Ljemu/core/device/printer/DMP2000;
    //   334: iload_2
    //   335: invokevirtual print : (I)V
    //   338: goto -> 364
    //   341: getstatic jemu/ui/JEMU.textprinter : Ljemu/core/device/printer/TextPrinter;
    //   344: ifnonnull -> 357
    //   347: new jemu/core/device/printer/TextPrinter
    //   350: dup
    //   351: invokespecial <init> : ()V
    //   354: putstatic jemu/ui/JEMU.textprinter : Ljemu/core/device/printer/TextPrinter;
    //   357: getstatic jemu/ui/JEMU.textprinter : Ljemu/core/device/printer/TextPrinter;
    //   360: iload_2
    //   361: invokevirtual print : (I)V
    //   364: return
    // Line number table:
    //   Java source line number -> byte code offset
    //   #97	-> 0
    //   #98	-> 13
    //   #99	-> 19
    //   #100	-> 26
    //   #101	-> 43
    //   #102	-> 59
    //   #103	-> 64
    //   #104	-> 72
    //   #107	-> 85
    //   #108	-> 92
    //   #109	-> 106
    //   #110	-> 125
    //   #111	-> 130
    //   #112	-> 138
    //   #116	-> 148
    //   #117	-> 154
    //   #118	-> 160
    //   #119	-> 173
    //   #122	-> 184
    //   #123	-> 197
    //   #125	-> 201
    //   #126	-> 224
    //   #127	-> 243
    //   #128	-> 257
    //   #129	-> 273
    //   #132	-> 284
    //   #133	-> 291
    //   #134	-> 297
    //   #137	-> 305
    //   #138	-> 319
    //   #139	-> 324
    //   #140	-> 330
    //   #142	-> 341
    //   #143	-> 347
    //   #145	-> 357
    //   #149	-> 364
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	365	0	this	Ljemu/core/device/printer/Printer;
    //   0	365	1	port	I
    //   0	365	2	value	I
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\printer\Printer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */