package jemu.core.device.printer;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.GroupLayout;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JToggleButton;
import javax.swing.LayoutStyle;

public class BMPtoFont extends JFrame {
  BufferedImage buffer;
  
  private JScrollPane jScrollPane1;
  
  private JToggleButton jToggleButton1;
  
  private JTextArea text;
  
  public BMPtoFont() {
    initComponents();
  }
  
  public void go2() {
    String name = "C:\\8x8\\font.bmp";
    String width = "    public int width = 8;\n";
    String height = "    public int height = 8;\n\n";
    this.text.append(width);
    this.text.append(height);
    String Byte = "    public byte[] char";
    String Byte2 = " = {";
    String Byte3 = "    };";
    try {
      this.buffer = readImage(name);
      int x = 0;
      int y = 1;
      int step = 10;
      int ch = 32;
      for (int hg = 0; hg < 6; hg++) {
        x = 0;
        for (int no = 0; no < 16; no++) {
          String byt = Byte + ch + Byte2 + "\n        ";
          for (int yy = 0 + y; yy < 8 + y; yy++) {
            for (int xx = 0 + x; xx < 8 + x; xx++) {
              Color check = new Color(this.buffer.getRGB(xx, yy));
              int num = check.getGreen();
              byte dot = 0;
              if (num < 128)
                dot = 1; 
              byt = byt + " " + dot + ",";
            } 
            byt = byt + "\n        ";
          } 
          x += step;
          ch++;
          byt = byt.substring(0, byt.length() - 1);
          byt = byt + "\n" + Byte3 + "\n\n";
          this.text.append(byt);
        } 
        y += step;
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void go() {
    String path = "C:\\8x8\\";
    String width = "    public int width = ";
    String height = "    public int height = ";
    int w = 0;
    int h = 0;
    boolean infoprinted = false;
    String Byte = "    public byte[] char";
    String Byte2 = " = {";
    String Byte3 = "    };";
    for (int no = 32; no < 130; no++) {
      String name = path + no + ".bmp";
      try {
        String byt = Byte + no + Byte2;
        if (no == 129)
          byt = Byte + "Test" + Byte2; 
        this.buffer = readImage(name);
        w = this.buffer.getWidth();
        h = this.buffer.getHeight();
        if (!infoprinted) {
          infoprinted = true;
          width = width + "" + w + ";\n\n";
          height = height + "" + h + ";\n\n";
          this.text.append(width);
          this.text.append(height);
        } 
        for (int y = 0; y < this.buffer.getHeight(); y++) {
          byt = byt + "\n       ";
          for (int x = 0; x < this.buffer.getWidth(); x++) {
            Color check = new Color(this.buffer.getRGB(x, y));
            int num = check.getGreen();
            byte dot = 0;
            if (num < 128)
              dot = 1; 
            byt = byt + " " + dot + ",";
          } 
        } 
        byt = byt.substring(0, byt.length() - 1);
        byt = byt + "\n" + Byte3 + "\n\n";
        this.text.append(byt);
      } catch (Exception exception) {}
    } 
  }
  
  public BufferedImage readImage(String filename) throws IOException {
    File imagein = new File(filename);
    BufferedImage bi = ImageIO.read(imagein);
    BufferedImage bo = new BufferedImage(bi.getWidth(), bi.getHeight(), 4);
    bo.getGraphics().drawImage(bi, 0, 0, this);
    return bo;
  }
  
  private void initComponents() {
    this.jScrollPane1 = new JScrollPane();
    this.text = new JTextArea();
    this.jToggleButton1 = new JToggleButton();
    setDefaultCloseOperation(3);
    this.text.setColumns(20);
    this.text.setFont(new Font("Courier", 0, 12));
    this.text.setRows(5);
    this.jScrollPane1.setViewportView(this.text);
    this.jToggleButton1.setText("Run!");
    this.jToggleButton1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            BMPtoFont.this.jToggleButton1ActionPerformed(evt);
          }
        });
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(this.jScrollPane1, -1, 725, 32767)
            .addComponent(this.jToggleButton1, GroupLayout.Alignment.TRAILING))
          .addContainerGap()));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addComponent(this.jScrollPane1, -2, 404, -2)
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.jToggleButton1)
          .addContainerGap(-1, 32767)));
    pack();
  }
  
  private void jToggleButton1ActionPerformed(ActionEvent evt) {
    go2();
  }
  
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new BMPtoFont()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\device\printer\BMPtoFont.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */