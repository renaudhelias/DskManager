package jemu.core.samples;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

public class SampleDemo extends JFrame {
  protected boolean playing = false;
  
  public SampleDemo() {
    Samples.init();
    Samples.volume = Samples.Volume.HIGH;
    Container cp = getContentPane();
    cp.setLayout(new FlowLayout(1, 10, 10));
    JButton btnSound1 = new JButton("Eject");
    btnSound1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            Samples.EJECT.play();
          }
        });
    cp.add(btnSound1);
    JButton btnSound2 = new JButton("Insert");
    btnSound2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            Samples.INSERT.play();
          }
        });
    cp.add(btnSound2);
    JButton btnSound3 = new JButton("Motor");
    btnSound3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (SampleDemo.this.playing) {
              Samples.MOTOR.stop();
              SampleDemo.this.playing = false;
            } else {
              Samples.MOTOR.loop();
              SampleDemo.this.playing = true;
            } 
          }
        });
    cp.add(btnSound3);
    JButton btnSound4 = new JButton("Seek");
    btnSound4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            Samples.SEEK.play();
          }
        });
    cp.add(btnSound4);
    JButton btnSound5 = new JButton("Seekback");
    btnSound5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            Samples.SEEKBACK.play();
          }
        });
    cp.add(btnSound5);
    JButton btnSound6 = new JButton("Track");
    btnSound6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            Samples.TRACK.play();
          }
        });
    cp.add(btnSound6);
    JButton btnSound7 = new JButton("Trackback");
    btnSound7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            Samples.TRACKBACK.play();
          }
        });
    cp.add(btnSound7);
    JButton btnSound8 = new JButton("Degauss");
    btnSound8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            Samples.DEGAUSS.play();
          }
        });
    cp.add(btnSound8);
    JButton btnSound9 = new JButton("RelOn");
    btnSound9.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            Samples.RELAIS.play();
          }
        });
    cp.add(btnSound9);
    JButton btnSound10 = new JButton("RelOff");
    btnSound10.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            Samples.RELAISOFF.play();
          }
        });
    cp.add(btnSound10);
    JButton btnSound11 = new JButton("TaMotor");
    btnSound11.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (SampleDemo.this.playing) {
              Samples.TAPEMOTOR.stop();
              SampleDemo.this.playing = false;
            } else {
              Samples.TAPEMOTOR.loop();
              SampleDemo.this.playing = true;
            } 
          }
        });
    cp.add(btnSound11);
    JButton btnSound12 = new JButton("TaRew");
    btnSound12.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (SampleDemo.this.playing) {
              Samples.REWINDMOTOR.stop();
              SampleDemo.this.playing = false;
            } else {
              Samples.REWINDMOTOR.loop();
              SampleDemo.this.playing = true;
            } 
          }
        });
    cp.add(btnSound12);
    JButton btnSound13 = new JButton("TaFF");
    btnSound13.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (SampleDemo.this.playing) {
              Samples.WINDMOTOR.stop();
              SampleDemo.this.playing = false;
            } else {
              Samples.WINDMOTOR.loop();
              SampleDemo.this.playing = true;
            } 
          }
        });
    cp.add(btnSound13);
    setDefaultCloseOperation(2);
    setTitle("Test Samples");
    pack();
    setVisible(true);
  }
  
  public static void main(String[] args) {
    new SampleDemo();
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\samples\SampleDemo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */