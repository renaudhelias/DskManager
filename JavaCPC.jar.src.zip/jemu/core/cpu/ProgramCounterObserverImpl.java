package jemu.core.cpu;

public abstract class ProgramCounterObserverImpl implements ProgramCounterObserver {
  private int address = 655360;
  
  private int cycles = 655360;
  
  public int getAddress() {
    return this.address;
  }
  
  public int getCycles() {
    return this.cycles;
  }
  
  public void setAddress(int address) {
    this.address = address;
  }
  
  public void setCycles(int cycles) {
    this.cycles = cycles;
  }
  
  public abstract void update(int paramInt);
  
  public ProgramCounterObserverImpl(int address) {
    setAddress(address);
  }
  
  public ProgramCounterObserverImpl(int cycles, boolean put) {
    setCycles(cycles);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\cpu\ProgramCounterObserverImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */