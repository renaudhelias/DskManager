package jemu.core.cpu;

import jemu.core.Util;
import jemu.core.device.Register;
import jemu.system.cpc.CPC;
import jemu.system.cpc.GateArray;

public class Z80 extends Processor {
  protected int MEMPTR;
  
  protected static final byte[] Z80_TIME_PRE = new byte[] { 
      4, 10, 7, 6, 4, 4, 7, 4, 4, 11, 
      7, 6, 4, 4, 7, 4, 8, 10, 7, 6, 
      4, 4, 7, 4, 12, 11, 7, 6, 4, 4, 
      7, 4, 7, 10, 16, 6, 4, 4, 7, 4, 
      7, 11, 16, 6, 4, 4, 7, 4, 7, 10, 
      13, 6, 11, 11, 10, 4, 7, 11, 13, 6, 
      4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 
      7, 4, 4, 4, 4, 4, 4, 4, 7, 4, 
      4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 
      4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 
      4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 
      7, 4, 7, 7, 7, 7, 7, 7, 4, 7, 
      4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 
      4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 
      4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 
      7, 4, 4, 4, 4, 4, 4, 4, 7, 4, 
      4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 
      4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 
      4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 
      7, 4, 5, 10, 10, 10, 10, 11, 8, 11, 
      5, 10, 10, 4, 10, 17, 8, 11, 5, 10, 
      10, 8, 10, 11, 8, 11, 5, 4, 10, 8, 
      10, 4, 8, 11, 5, 10, 10, 19, 10, 11, 
      8, 11, 5, 4, 10, 4, 10, 4, 8, 11, 
      5, 10, 10, 4, 10, 11, 8, 11, 5, 6, 
      10, 4, 10, 4, 8, 11 };
  
  public static final byte[] Z80_TIME_PRE_ED = new byte[] { 
      4, 4, 11, 16, 4, 10, 4, 5, 4, 4, 
      11, 16, 4, 10, 4, 5, 4, 4, 11, 16, 
      4, 10, 4, 5, 4, 4, 11, 16, 4, 10, 
      4, 5, 4, 4, 11, 16, 4, 10, 4, 14, 
      4, 4, 11, 16, 4, 10, 4, 14, 4, 4, 
      11, 16, 4, 10, 4, 4, 4, 4, 11, 16, 
      4, 10, 4, 4, 12, 12, 12, 12, 12, 12, 
      12, 12, 12, 12, 12, 12, 12, 12, 12, 12 };
  
  protected static final int CYCLES_EXTRA_JRCC = 0;
  
  protected static final int CYCLES_EXTRA_DJNZ = 1;
  
  protected static final int CYCLES_EXTRA_CALLCC = 2;
  
  protected static final int CYCLES_EXTRA_RETCC = 3;
  
  protected static final int CYCLES_EXTRA_LDIR = 4;
  
  protected static final int CYCLES_EXTRA_CPIR = 5;
  
  protected static final int CYCLES_EXTRA_INIR = 6;
  
  protected static final int CYCLES_EXTRA_OTIR = 7;
  
  protected static final int CYCLES_EXTRA_IDXNORM = 8;
  
  protected static final int CYCLES_EXTRA_IDXLDIN = 9;
  
  protected static final int CYCLES_EXTRA_IDXCB = 10;
  
  protected static final int CYCLES_EXTRA_IM0 = 11;
  
  protected static final int CYCLES_EXTRA_IM1 = 12;
  
  protected static final int CYCLES_EXTRA_IM2 = 13;
  
  protected static final int CYCLES_EXTRA_INTACK = 14;
  
  protected static final byte[] Z80_TIME_EXTRA = new byte[] { 
      5, 5, 7, 6, 5, 5, 5, 5, 8, 5, 
      4, 0, 0, 17, 2 };
  
  public static final int B = 0;
  
  public static final int C = 1;
  
  public static final int D = 2;
  
  public static final int E = 3;
  
  public static final int H = 4;
  
  public static final int L = 5;
  
  public static final int F = 6;
  
  public static final int A = 7;
  
  public static final int B1 = 8;
  
  public static final int C1 = 9;
  
  public static final int D1 = 10;
  
  public static final int E1 = 11;
  
  public static final int H1 = 12;
  
  public static final int L1 = 13;
  
  public static final int F1 = 14;
  
  public static final int A1 = 15;
  
  public static final int BC = 0;
  
  public static final int DE = 2;
  
  public static final int HL = 4;
  
  public static final int AF = 6;
  
  public static final int FS = 128;
  
  public static final int FZ = 64;
  
  public static final int F5 = 32;
  
  public static final int FH = 16;
  
  public static final int F3 = 8;
  
  public static final int FPV = 4;
  
  public static final int FN = 2;
  
  public static final int FC = 1;
  
  protected static final int FLAG_MASK_LDI = 193;
  
  protected static final int FLAG_MASK_LDD = 233;
  
  protected static final int FLAG_MASK_LDIR = 233;
  
  protected static final int FLAG_MASK_LDDR = 193;
  
  protected static final int FLAG_MASK_CPIR = 250;
  
  protected static final int FLAG_MASK_CPL = 197;
  
  protected static final int FLAG_MASK_CCF = 197;
  
  protected static final int FLAG_MASK_SCF = 197;
  
  protected static final int FLAG_MASK_ADDHL = 196;
  
  protected static final int FLAG_MASK_RLCA = 196;
  
  protected static final int FLAG_MASK_RLD = 1;
  
  protected static final int FLAG_MASK_BIT = 1;
  
  protected static final int FLAG_MASK_IN = 1;
  
  protected static final int FLAG_MASK_INI = 232;
  
  protected int[] reg = new int[16];
  
  protected int SP;
  
  protected int PC;
  
  protected int IX;
  
  protected int IY;
  
  protected int I;
  
  protected int R;
  
  protected int R7;
  
  protected int IM;
  
  protected boolean IFF1;
  
  protected boolean IFF2;
  
  protected boolean noWait = false;
  
  protected boolean inHalt = false;
  
  protected boolean interruptExecute = false;
  
  protected int interruptVector = 255;
  
  protected byte[] timePre = new byte[256];
  
  protected byte[] timePost = new byte[256];
  
  protected byte[] timePreCB = new byte[256];
  
  protected byte[] timePostCB = new byte[256];
  
  protected byte[] timePreED = new byte[128];
  
  protected byte[] timePostED = new byte[128];
  
  protected byte[] timeExtra = new byte[2];
  
  protected static int[] PARITY = new int[256];
  
  protected boolean checkintafter;
  
  static {
    for (int i = 0; i < 256; i++) {
      int p = ((i & 0x1) == 0) ? 4 : 0;
      if ((i & 0x2) != 0)
        p ^= 0x4; 
      if ((i & 0x4) != 0)
        p ^= 0x4; 
      if ((i & 0x8) != 0)
        p ^= 0x4; 
      if ((i & 0x10) != 0)
        p ^= 0x4; 
      if ((i & 0x20) != 0)
        p ^= 0x4; 
      if ((i & 0x40) != 0)
        p ^= 0x4; 
      if ((i & 0x80) != 0)
        p ^= 0x4; 
      PARITY[i] = p;
    } 
  }
  
  public Z80(long cyclesPerSecond) {
    super("Zilog Z80", cyclesPerSecond);
    setTimes();
  }
  
  protected void setTimes() {
    byte[] zeros = new byte[256];
    byte[] timesCB = new byte[256];
    int i;
    for (i = 0; i < 256; i++) {
      if ((i & 0x7) != 6) {
        timesCB[i] = 4;
      } else if ((i & 0xC0) == 64) {
        timesCB[i] = 8;
      } else {
        timesCB[i] = 11;
      } 
    } 
    setTimes(Z80_TIME_PRE, zeros, timesCB, zeros, Z80_TIME_PRE_ED, new byte[80], Z80_TIME_EXTRA);
    this.timePost[219] = 3;
    this.timePost[211] = 3;
    for (i = 0; i < 64; i += 8) {
      this.timePostED[64 + i] = 4;
      this.timePostED[65 + i] = 4;
    } 
  }
  
  protected void setTimes(byte[] pre, byte[] post, byte[] preCB, byte[] postCB, byte[] preED, byte[] postED, byte[] extra) {
    this.timePre = checkByteArraySize(pre, 256);
    this.timePost = checkByteArraySize(post, 256);
    this.timePreCB = checkByteArraySize(preCB, 256);
    this.timePostCB = checkByteArraySize(postCB, 256);
    checkByteArraySize(preED, 80);
    checkByteArraySize(postED, 80);
    this.timePreED = new byte[256];
    this.timePostED = new byte[256];
    int i;
    for (i = 0; i < 256; i++) {
      this.timePreED[i] = this.timePre[0];
      this.timePostED[i] = this.timePost[0];
    } 
    System.arraycopy(preED, 0, this.timePreED, 64, 64);
    System.arraycopy(postED, 0, this.timePostED, 64, 64);
    for (i = 0; i < 4; i++) {
      System.arraycopy(preED, 64 + i * 4, this.timePreED, 160 + i * 8, 4);
      System.arraycopy(postED, 64 + i * 4, this.timePostED, 160 + i * 8, 4);
    } 
    this.timeExtra = checkByteArraySize(extra, 15);
  }
  
  protected static byte[] checkByteArraySize(byte[] value, int length) {
    int len = (value == null) ? 0 : value.length;
    if (len != length)
      throw new RuntimeException("Invalid Length for byte array: " + len + ". Should be " + length); 
    return value;
  }
  
  public void reset() {
    super.reset();
    for (int i = 0; i < this.reg.length; i++)
      this.reg[i] = 0; 
    this.SP = this.PC = this.IX = this.IY = 0;
    this.I = this.R = this.R7 = this.IM = this.MEMPTR = 0;
    this.IFF1 = this.IFF2 = false;
    this.interruptPending = 0;
    this.interruptExecute = this.inHalt = this.noWait = false;
  }
  
  public void stepOver() {
    int opcode = this.memory.readByte(this.PC);
    switch (opcode) {
      case 118:
        runTo(this.PC + 1 & 0xFFFF);
        return;
      case 237:
        stepOverED();
        return;
      case 196:
      case 204:
      case 205:
      case 212:
      case 220:
      case 228:
      case 244:
      case 252:
        runTo(this.PC + 3 & 0xFFFF);
        return;
    } 
    step();
  }
  
  protected void stepOverED() {
    int opcode = this.memory.readByte(this.PC + 1 & 0xFFFF);
    switch (opcode) {
      case 176:
      case 177:
      case 178:
      case 179:
      case 184:
      case 185:
      case 186:
      case 187:
        runTo(this.PC + 2 & 0xFFFF);
        return;
    } 
    step();
  }
  
  public final void step() {
    if (this.interruptExecute) {
      doInterrupt();
    } else if (this.inHalt) {
      step(0);
    } else {
      step(fetchOpCode());
    } 
  }
  
  protected final void step(int opcode) {
    this.checkintafter = true;
    this.noWait = false;
    executeNormal(opcode);
    this.interruptExecute = (this.interruptPending != 0 && this.checkintafter && this.IFF1);
  }
  
  protected void executeNormal(int opcode) {
    cycle(this.timePre[opcode]);
    this.R++;
    switch (opcode) {
      case 0:
        nop();
        break;
      case 1:
      case 17:
      case 33:
      case 49:
        ldddnn(opcode, fetchWord());
        break;
      case 2:
        ldbca();
        break;
      case 3:
      case 19:
      case 35:
      case 51:
        incss(opcode);
        break;
      case 4:
      case 12:
      case 20:
      case 28:
      case 36:
      case 44:
      case 60:
        incr(opcode);
        break;
      case 5:
      case 13:
      case 21:
      case 29:
      case 37:
      case 45:
      case 61:
        decr(opcode);
        break;
      case 6:
      case 14:
      case 22:
      case 30:
      case 38:
      case 46:
      case 62:
        ldrn(opcode, fetch());
        break;
      case 7:
        rlca();
        break;
      case 8:
        exafaf1();
        break;
      case 9:
      case 25:
      case 41:
      case 57:
        addhlss(opcode);
        break;
      case 10:
        ldabc();
        break;
      case 11:
      case 27:
      case 43:
      case 59:
        decss(opcode);
        break;
      case 15:
        rrca();
        break;
      case 16:
        djnze((byte)fetch());
        break;
      case 18:
        lddea();
        break;
      case 23:
        rla();
        break;
      case 24:
        jre((byte)fetch());
        break;
      case 26:
        ldade();
        break;
      case 31:
        rra();
        break;
      case 32:
        jrnze((byte)fetch());
        break;
      case 34:
        ldxxhl(fetchWord());
        break;
      case 39:
        daa();
        break;
      case 40:
        jrze((byte)fetch());
        break;
      case 42:
        ldhlxx(fetchWord());
        break;
      case 47:
        cpl();
        break;
      case 48:
        jrnce((byte)fetch());
        break;
      case 50:
        ldxxa(fetchWord());
        break;
      case 52:
        incchl();
        break;
      case 53:
        decchl();
        break;
      case 54:
        ldhln(fetch());
        break;
      case 55:
        scf();
        break;
      case 56:
        jrce((byte)fetch());
        break;
      case 58:
        ldaxx(fetchWord());
        break;
      case 63:
        ccf();
        break;
      case 64:
      case 65:
      case 66:
      case 67:
      case 68:
      case 69:
      case 71:
      case 72:
      case 73:
      case 74:
      case 75:
      case 76:
      case 77:
      case 79:
      case 80:
      case 81:
      case 82:
      case 83:
      case 84:
      case 85:
      case 87:
      case 88:
      case 89:
      case 90:
      case 91:
      case 92:
      case 93:
      case 95:
      case 96:
      case 97:
      case 98:
      case 99:
      case 100:
      case 101:
      case 103:
      case 104:
      case 105:
      case 106:
      case 107:
      case 108:
      case 109:
      case 111:
      case 120:
      case 121:
      case 122:
      case 123:
      case 124:
      case 125:
      case 127:
        ldrr(opcode);
        break;
      case 70:
      case 78:
      case 86:
      case 94:
      case 102:
      case 110:
      case 126:
        ldrhl(opcode);
        break;
      case 112:
      case 113:
      case 114:
      case 115:
      case 116:
      case 117:
      case 119:
        ldhlr(opcode);
        break;
      case 118:
        halt();
        break;
      case 128:
      case 129:
      case 130:
      case 131:
      case 132:
      case 133:
      case 135:
        addar(opcode);
        break;
      case 134:
        addahl();
        break;
      case 136:
      case 137:
      case 138:
      case 139:
      case 140:
      case 141:
      case 143:
        adcar(opcode);
        break;
      case 142:
        adcahl();
        break;
      case 144:
      case 145:
      case 146:
      case 147:
      case 148:
      case 149:
      case 151:
        subar(opcode);
        break;
      case 150:
        subahl();
        break;
      case 152:
      case 153:
      case 154:
      case 155:
      case 156:
      case 157:
      case 159:
        sbcar(opcode);
        break;
      case 158:
        sbcahl();
        break;
      case 160:
      case 161:
      case 162:
      case 163:
      case 164:
      case 165:
      case 167:
        andar(opcode);
        break;
      case 166:
        andahl();
        break;
      case 168:
      case 169:
      case 170:
      case 171:
      case 172:
      case 173:
      case 175:
        xorar(opcode);
        break;
      case 174:
        xorahl();
        break;
      case 176:
      case 177:
      case 178:
      case 179:
      case 180:
      case 181:
      case 183:
        orar(opcode);
        break;
      case 182:
        orahl();
        break;
      case 184:
      case 185:
      case 186:
      case 187:
      case 188:
      case 189:
      case 191:
        cpar(opcode);
        break;
      case 190:
        cpahl();
        break;
      case 192:
      case 200:
      case 208:
      case 216:
      case 224:
      case 232:
      case 240:
      case 248:
        retcc(opcode);
        break;
      case 193:
      case 209:
      case 225:
      case 241:
        popqq(opcode);
        break;
      case 194:
      case 202:
      case 210:
      case 218:
      case 226:
      case 234:
      case 242:
      case 250:
        jpccnn(opcode, fetchWord());
        break;
      case 195:
        jpnn(fetchWord());
        break;
      case 196:
      case 204:
      case 212:
      case 220:
      case 228:
      case 236:
      case 244:
      case 252:
        callccnn(opcode, fetchWord());
        break;
      case 197:
      case 213:
      case 229:
      case 245:
        pushqq(opcode);
        break;
      case 198:
        addan(fetch());
        break;
      case 199:
      case 207:
      case 215:
      case 223:
      case 231:
      case 239:
      case 247:
      case 255:
        rstp(opcode);
        break;
      case 201:
        ret();
        break;
      case 203:
        executeCB(fetch(), false);
        break;
      case 205:
        callnn(fetchWord());
        break;
      case 206:
        adcan(fetch());
        break;
      case 211:
        outna(fetch());
        break;
      case 214:
        suban(fetch());
        break;
      case 217:
        exx();
        break;
      case 219:
        inan(fetch());
        break;
      case 221:
        this.IX = executeDDFD(this.IX, fetch());
        break;
      case 222:
        sbcan(fetch());
        break;
      case 227:
        exsphl();
        break;
      case 230:
        andan(fetch());
        break;
      case 233:
        jphl();
        break;
      case 235:
        exdehl();
        break;
      case 237:
        executeED(fetch());
        break;
      case 238:
        xoran(fetch());
        break;
      case 243:
        di();
        break;
      case 246:
        oran(fetch());
        break;
      case 249:
        ldsphl();
        break;
      case 251:
        ei();
        break;
      case 253:
        this.IY = executeDDFD(this.IY, fetch());
        break;
      case 254:
        cpan(fetch());
        break;
      default:
        throw new RuntimeException("Invalid Opcode: " + Util.hex((byte)opcode));
    } 
    cycle(this.timePost[opcode]);
  }
  
  protected void executeCB(int opcode, boolean ixiy) {
    cycle(this.timePreCB[opcode]);
    this.R++;
    int result = -1;
    switch (ixiy ? (opcode & 0xF8 | 0x6) : opcode) {
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 7:
        rlcr(opcode);
        break;
      case 6:
        result = rlchl();
        break;
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 15:
        rrcr(opcode);
        break;
      case 14:
        result = rrchl();
        break;
      case 16:
      case 17:
      case 18:
      case 19:
      case 20:
      case 21:
      case 23:
        rlr(opcode);
        break;
      case 22:
        result = rlhl();
        break;
      case 24:
      case 25:
      case 26:
      case 27:
      case 28:
      case 29:
      case 31:
        rrr(opcode);
        break;
      case 30:
        result = rrhl();
        break;
      case 32:
      case 33:
      case 34:
      case 35:
      case 36:
      case 37:
      case 39:
        slar(opcode);
        break;
      case 38:
        result = slahl();
        break;
      case 40:
      case 41:
      case 42:
      case 43:
      case 44:
      case 45:
      case 47:
        srar(opcode);
        break;
      case 46:
        result = srahl();
        break;
      case 48:
      case 49:
      case 50:
      case 51:
      case 52:
      case 53:
      case 55:
        sllr(opcode);
        break;
      case 54:
        result = sllhl();
        break;
      case 56:
      case 57:
      case 58:
      case 59:
      case 60:
      case 61:
      case 63:
        srlr(opcode);
        break;
      case 62:
        result = srlhl();
        break;
      case 64:
      case 65:
      case 66:
      case 67:
      case 68:
      case 69:
      case 71:
      case 72:
      case 73:
      case 74:
      case 75:
      case 76:
      case 77:
      case 79:
      case 80:
      case 81:
      case 82:
      case 83:
      case 84:
      case 85:
      case 87:
      case 88:
      case 89:
      case 90:
      case 91:
      case 92:
      case 93:
      case 95:
      case 96:
      case 97:
      case 98:
      case 99:
      case 100:
      case 101:
      case 103:
      case 104:
      case 105:
      case 106:
      case 107:
      case 108:
      case 109:
      case 111:
      case 112:
      case 113:
      case 114:
      case 115:
      case 116:
      case 117:
      case 119:
      case 120:
      case 121:
      case 122:
      case 123:
      case 124:
      case 125:
      case 127:
        bitbr(opcode);
        break;
      case 70:
      case 78:
      case 86:
      case 94:
      case 102:
      case 110:
      case 118:
      case 126:
        bitbhl(opcode);
        break;
      case 128:
      case 129:
      case 130:
      case 131:
      case 132:
      case 133:
      case 135:
      case 136:
      case 137:
      case 138:
      case 139:
      case 140:
      case 141:
      case 143:
      case 144:
      case 145:
      case 146:
      case 147:
      case 148:
      case 149:
      case 151:
      case 152:
      case 153:
      case 154:
      case 155:
      case 156:
      case 157:
      case 159:
      case 160:
      case 161:
      case 162:
      case 163:
      case 164:
      case 165:
      case 167:
      case 168:
      case 169:
      case 170:
      case 171:
      case 172:
      case 173:
      case 175:
      case 176:
      case 177:
      case 178:
      case 179:
      case 180:
      case 181:
      case 183:
      case 184:
      case 185:
      case 186:
      case 187:
      case 188:
      case 189:
      case 191:
        resbr(opcode);
        break;
      case 134:
      case 142:
      case 150:
      case 158:
      case 166:
      case 174:
      case 182:
      case 190:
        result = resbhl(opcode);
        break;
      case 192:
      case 193:
      case 194:
      case 195:
      case 196:
      case 197:
      case 199:
      case 200:
      case 201:
      case 202:
      case 203:
      case 204:
      case 205:
      case 207:
      case 208:
      case 209:
      case 210:
      case 211:
      case 212:
      case 213:
      case 215:
      case 216:
      case 217:
      case 218:
      case 219:
      case 220:
      case 221:
      case 223:
      case 224:
      case 225:
      case 226:
      case 227:
      case 228:
      case 229:
      case 231:
      case 232:
      case 233:
      case 234:
      case 235:
      case 236:
      case 237:
      case 239:
      case 240:
      case 241:
      case 242:
      case 243:
      case 244:
      case 245:
      case 247:
      case 248:
      case 249:
      case 250:
      case 251:
      case 252:
      case 253:
      case 255:
        setbr(opcode);
        break;
      case 198:
      case 206:
      case 214:
      case 222:
      case 230:
      case 238:
      case 246:
      case 254:
        result = setbhl(opcode);
        break;
      default:
        throw new RuntimeException("Invalid Opcode: CB " + opcode);
    } 
    if (ixiy && (opcode & 0x7) != 6 && (opcode & 0xC0) != 64) {
      int r = opcode & 0x7;
      this.reg[r] = result;
    } 
    cycle(this.timePostCB[opcode]);
  }
  
  protected void executeED(int opcode) {
    cycle(this.timePreED[opcode]);
    this.R++;
    switch (opcode) {
      case 64:
      case 72:
      case 80:
      case 88:
      case 96:
      case 104:
      case 120:
        inrc(opcode);
        break;
      case 65:
      case 73:
      case 81:
      case 89:
      case 97:
      case 105:
      case 121:
        outcr(opcode);
        break;
      case 66:
      case 82:
      case 98:
      case 114:
        sbchlss(opcode);
        break;
      case 67:
      case 83:
      case 99:
      case 115:
        ldxxdd(opcode, fetchWord());
        break;
      case 68:
      case 76:
      case 84:
      case 92:
      case 100:
      case 108:
      case 116:
      case 124:
        neg();
        break;
      case 69:
      case 85:
      case 101:
      case 117:
        retn();
        break;
      case 70:
      case 78:
      case 102:
      case 110:
        imn(0);
        break;
      case 71:
        ldia();
        break;
      case 74:
      case 90:
      case 106:
      case 122:
        adchlss(opcode);
        break;
      case 75:
      case 91:
      case 107:
      case 123:
        ldddxx(opcode, fetchWord());
        break;
      case 77:
      case 93:
      case 109:
      case 125:
        reti();
        break;
      case 79:
        ldra();
        break;
      case 86:
      case 118:
        imn(1);
        break;
      case 87:
        ldai();
        break;
      case 94:
      case 126:
        imn(2);
        break;
      case 95:
        ldar();
        break;
      case 103:
        rrd();
        break;
      case 111:
        rld();
        break;
      case 112:
        inc();
        break;
      case 113:
        outc0();
        break;
      case 160:
        ldi();
        break;
      case 161:
        cpi();
        break;
      case 162:
        ini();
        break;
      case 163:
        outi();
        break;
      case 168:
        ldd();
        break;
      case 169:
        cpd();
        break;
      case 170:
        ind();
        break;
      case 171:
        outd();
        break;
      case 176:
        ldir();
        break;
      case 177:
        cpir();
        break;
      case 178:
        inir();
        break;
      case 179:
        otir();
        break;
      case 184:
        lddr();
        break;
      case 185:
        cpdr();
        break;
      case 186:
        indr();
        break;
      case 187:
        otdr();
        break;
      case 252:
        if (CPC.loadtap) {
          GateArray.cpc.loadblock();
          break;
        } 
        nop();
        break;
      default:
        nop();
        break;
    } 
    cycle(this.timePostED[opcode]);
  }
  
  protected int executeDDFD(int ixiy, int opcode) {
    switch (opcode) {
      case 9:
      case 25:
      case 33:
      case 34:
      case 35:
      case 36:
      case 37:
      case 38:
      case 41:
      case 42:
      case 43:
      case 44:
      case 45:
      case 46:
      case 57:
      case 68:
      case 69:
      case 76:
      case 77:
      case 84:
      case 85:
      case 92:
      case 93:
      case 96:
      case 97:
      case 98:
      case 99:
      case 101:
      case 103:
      case 104:
      case 105:
      case 106:
      case 107:
      case 108:
      case 111:
      case 124:
      case 125:
      case 132:
      case 133:
      case 140:
      case 141:
      case 148:
      case 149:
      case 156:
      case 157:
      case 164:
      case 165:
      case 172:
      case 173:
      case 180:
      case 181:
      case 188:
      case 189:
      case 225:
      case 227:
      case 229:
      case 233:
      case 249:
        ixiy = swapDDFD(ixiy, opcode);
        return ixiy;
      case 52:
      case 53:
      case 70:
      case 78:
      case 86:
      case 94:
      case 112:
      case 113:
      case 114:
      case 115:
      case 119:
      case 126:
      case 134:
      case 142:
      case 150:
      case 158:
      case 166:
      case 174:
      case 182:
      case 190:
        indexDDFD(ixiy, opcode, 8);
        return ixiy;
      case 54:
        indexDDFD(ixiy, opcode, 9);
        return ixiy;
      case 203:
        indexDDFDCB(ixiy, 10);
        return ixiy;
      case 102:
      case 110:
        ldrixiyd(ixiy, opcode);
        return ixiy;
      case 116:
        cycle();
      case 117:
        ldixiydr(ixiy, opcode);
        return ixiy;
    } 
    executeNormal(opcode);
    return ixiy;
  }
  
  protected int swapDDFD(int ixiy, int opcode) {
    int hl = getqq(4);
    setqq(4, ixiy);
    executeNormal(opcode);
    ixiy = getqq(4);
    setqq(4, hl);
    return ixiy;
  }
  
  protected void indexDDFD(int ixiy, int opcode, int extra) {
    cycle(this.timeExtra[extra]);
    int hl = getqq(4);
    setqq(4, this.MEMPTR = ixiy + (byte)fetch() & 0xFFFF);
    executeNormal(opcode);
    setqq(4, hl);
  }
  
  protected void indexDDFDCB(int ixiy, int extra) {
    cycle(this.timeExtra[extra]);
    int hl = getqq(4);
    setqq(4, this.MEMPTR = ixiy + (byte)fetch() & 0xFFFF);
    executeCB(fetchOpCode(), true);
    setqq(4, hl);
  }
  
  protected void ldrixiyd(int ixiy, int opcode) {
    cycle(this.timePre[opcode] + this.timeExtra[8]);
    this.R++;
    int r = (opcode & 0x38) >> 3;
    cycle(this.timePost[opcode]);
    this.reg[r] = readByte(this.MEMPTR = ixiy + (byte)fetch() & 0xFFFF);
  }
  
  protected void ldixiydr(int ixiy, int opcode) {
    cycle(this.timePre[opcode] + this.timeExtra[8]);
    this.R++;
    int r = opcode & 0x7;
    cycle(this.timePost[opcode]);
    writeByte(this.MEMPTR = ixiy + (byte)fetch() & 0xFFFF, this.reg[r]);
  }
  
  protected void stopHalt() {
    if (this.inHalt) {
      this.inHalt = false;
      this.PC = this.PC + 1 & 0xFFFF;
    } 
  }
  
  public void nmi() {
    this.IFF1 = false;
    stopHalt();
    cycle(this.timePre[205]);
    callnn(102);
    cycle(this.timePost[205]);
  }
  
  protected void doInterrupt() {
    this.interruptExecute = false;
    stopHalt();
    if (!this.noWait)
      cycle(this.timeExtra[14]); 
    if (this.interruptDevice != null)
      this.interruptDevice.setInterrupt(1); 
    interruptNotify();
    this.IFF1 = this.IFF2 = false;
    switch (this.IM) {
      case 0:
        cycle(this.timeExtra[11]);
        step(this.interruptVector);
        break;
      case 1:
        cycle(this.timeExtra[12]);
        step(255);
        break;
      case 2:
        cycle(this.timeExtra[13]);
        push(this.PC);
        this.MEMPTR = this.PC = readWord(this.I << 8 | this.interruptVector);
        break;
    } 
  }
  
  protected void interruptNotify() {}
  
  protected int fetchWord() {
    int lsb = fetch();
    return lsb | fetch() << 8;
  }
  
  protected int fetch() {
    int result = readByte(this.PC);
    this.PC = this.PC + 1 & 0xFFFF;
    return result;
  }
  
  protected int fetchOpCode() {
    int result = readByte(this.PC);
    this.PC = this.PC + 1 & 0xFFFF;
    return result;
  }
  
  protected void ldrr(int opcode) {
    int r = (opcode & 0x38) >> 3;
    int r1 = opcode & 0x7;
    this.reg[r] = this.reg[r1];
  }
  
  protected void ldrn(int opcode, int n) {
    int r = (opcode & 0x38) >> 3;
    this.reg[r] = n;
  }
  
  protected void ldrhl(int opcode) {
    int r = (opcode & 0x38) >> 3;
    this.reg[r] = readByte(getqq(4));
  }
  
  protected void ldhlr(int opcode) {
    int r = opcode & 0x7;
    writeByte(getqq(4), this.reg[r]);
  }
  
  protected void ldhln(int n) {
    writeByte(getqq(4), n);
  }
  
  protected void ldabc() {
    int addr = getqq(0);
    this.reg[7] = readByte(addr);
    this.MEMPTR = addr + 1;
  }
  
  protected void ldade() {
    int addr = getqq(2);
    this.reg[7] = readByte(addr);
    this.MEMPTR = addr + 1;
  }
  
  protected void ldaxx(int xx) {
    this.reg[7] = readByte(xx);
    this.MEMPTR = xx + 1;
  }
  
  protected void ldbca() {
    int addr = getqq(0);
    int a = this.reg[7];
    writeByte(addr, a);
    this.MEMPTR = addr + 1 & 0xFF | a << 8;
  }
  
  protected void lddea() {
    int addr = getqq(2);
    int a = this.reg[7];
    writeByte(addr, a);
    this.MEMPTR = addr + 1 & 0xFF | a << 8;
  }
  
  protected void ldxxa(int xx) {
    int a = this.reg[7];
    writeByte(xx, a);
    this.MEMPTR = xx + 1 & 0xFF | a << 8;
  }
  
  protected void ldai() {
    ldair(this.I);
  }
  
  protected void ldar() {
    ldair(this.R & 0x7F | this.R7);
  }
  
  protected void ldia() {
    this.I = this.reg[7];
    this.noWait = true;
  }
  
  protected void ldra() {
    this.R = this.reg[7];
    this.R7 = this.reg[7] & 0x80;
    this.noWait = true;
  }
  
  protected void ldddnn(int opcode, int nn) {
    int dd = (opcode & 0x30) >> 3;
    setdd(dd, nn);
  }
  
  protected void ldhlxx(int xx) {
    setqq(4, readWord(xx));
    this.MEMPTR = xx + 1;
  }
  
  protected void ldddxx(int opcode, int xx) {
    int dd = (opcode & 0x30) >> 3;
    setdd(dd, readWord(xx));
    this.MEMPTR = xx + 1;
  }
  
  protected void ldxxhl(int xx) {
    writeWord(xx, getdd(4));
    this.MEMPTR = xx + 1;
  }
  
  protected void ldxxdd(int opcode, int xx) {
    int dd = (opcode & 0x30) >> 3;
    writeWord(xx, getdd(dd));
    this.MEMPTR = xx + 1;
  }
  
  protected void ldsphl() {
    this.SP = getqq(4);
  }
  
  protected void pushqq(int opcode) {
    int qq = (opcode & 0x30) >> 3;
    push(getqq(qq));
  }
  
  protected void popqq(int opcode) {
    int qq = (opcode & 0x30) >> 3;
    setqq(qq, pop());
  }
  
  protected void exdehl() {
    int temp = this.reg[2];
    this.reg[2] = this.reg[4];
    this.reg[4] = temp;
    temp = this.reg[3];
    this.reg[3] = this.reg[5];
    this.reg[5] = temp;
  }
  
  protected void exafaf1() {
    int temp = this.reg[7];
    this.reg[7] = this.reg[15];
    this.reg[15] = temp;
    temp = this.reg[6];
    this.reg[6] = this.reg[14];
    this.reg[14] = temp;
  }
  
  protected void exx() {
    for (int i = 0; i <= 5; i++) {
      int temp = this.reg[i];
      this.reg[i] = this.reg[i + 8];
      this.reg[i + 8] = temp;
    } 
  }
  
  protected void exsphl() {
    int data = readWord(this.SP);
    writeWord(this.SP, getqq(4));
    setqq(4, this.MEMPTR = data);
    this.noWait = true;
  }
  
  protected void ldi() {
    this.noWait = true;
    int de = getqq(2);
    int hl = getqq(4);
    int n = readByte(hl++);
    writeByte(de++, n);
    endldi(de, hl, n);
  }
  
  protected void ldir() {
    ldi();
    if ((this.reg[6] & 0x4) != 0) {
      this.PC = this.PC - 2 & 0xFFFF;
      this.MEMPTR = this.PC + 1;
      cycle(this.timeExtra[4]);
    } 
    this.noWait = true;
  }
  
  protected void ldd() {
    this.noWait = true;
    int de = getqq(2);
    int hl = getqq(4);
    int n = readByte(hl--);
    writeByte(de--, n);
    endldi(de, hl, n);
  }
  
  protected void lddr() {
    ldd();
    if ((this.reg[6] & 0x4) != 0) {
      this.PC = this.PC - 2 & 0xFFFF;
      this.MEMPTR = this.PC + 1;
      cycle(this.timeExtra[4]);
    } 
    this.noWait = true;
  }
  
  protected void cpi() {
    cpid(1);
  }
  
  protected void cpir() {
    cpid(1);
    if ((this.reg[6] & 0x44) == 4) {
      this.PC = this.PC - 2 & 0xFFFF;
      this.MEMPTR = this.PC + 1;
      cycle(this.timeExtra[5]);
      this.noWait = true;
    } 
  }
  
  protected void cpd() {
    cpid(-1);
  }
  
  protected void cpdr() {
    cpid(-1);
    if ((this.reg[6] & 0x44) == 4) {
      this.PC = this.PC - 2 & 0xFFFF;
      this.MEMPTR = this.PC + 1;
      cycle(this.timeExtra[5]);
      this.noWait = true;
    } 
  }
  
  protected void addar(int opcode) {
    int r = opcode & 0x7;
    addan(this.reg[r], 0);
  }
  
  protected void addan(int n) {
    addan(n, 0);
  }
  
  protected void addahl() {
    addan(readByte(getqq(4)), 0);
  }
  
  protected void adcar(int opcode) {
    int r = opcode & 0x7;
    addan(this.reg[r], this.reg[6] & 0x1);
  }
  
  protected void adcan(int n) {
    addan(n, this.reg[6] & 0x1);
  }
  
  protected void adcahl() {
    addan(readByte(getqq(4)), this.reg[6] & 0x1);
  }
  
  protected void subar(int opcode) {
    int r = opcode & 0x7;
    suba(this.reg[r], 0);
  }
  
  protected void suban(int n) {
    suba(n, 0);
  }
  
  protected void subahl() {
    suba(readByte(getqq(4)), 0);
  }
  
  protected void sbcar(int opcode) {
    int r = opcode & 0x7;
    suba(this.reg[r], this.reg[6] & 0x1);
  }
  
  protected void sbcan(int n) {
    suba(n, this.reg[6] & 0x1);
  }
  
  protected void sbcahl() {
    suba(readByte(getqq(4)), this.reg[6] & 0x1);
  }
  
  protected void andar(int opcode) {
    int r = opcode & 0x7;
    andan(this.reg[r]);
  }
  
  protected void andan(int n) {
    int a = this.reg[7] = this.reg[7] & n;
    int f = a & 0xA8 | 0x10 | PARITY[a];
    this.reg[6] = (a == 0) ? (f | 0x40) : f;
  }
  
  protected void andahl() {
    andan(readByte(getqq(4)));
  }
  
  protected void orar(int opcode) {
    int r = opcode & 0x7;
    oran(this.reg[r]);
  }
  
  protected void oran(int n) {
    int a = this.reg[7] = this.reg[7] | n;
    int f = a & 0xA8 | PARITY[a];
    this.reg[6] = (a == 0) ? (f | 0x40) : f;
  }
  
  protected void orahl() {
    oran(readByte(getqq(4)));
  }
  
  protected void xorar(int opcode) {
    int r = opcode & 0x7;
    xoran(this.reg[r]);
  }
  
  protected void xoran(int n) {
    int a = this.reg[7] = this.reg[7] ^ n;
    int f = a & 0xA8 | PARITY[a];
    this.reg[6] = (a == 0) ? (f | 0x40) : f;
  }
  
  protected void xorahl() {
    xoran(readByte(getqq(4)));
  }
  
  protected void cpar(int opcode) {
    int r = opcode & 0x7;
    cpan(this.reg[r]);
  }
  
  protected void cpan(int n) {
    int a = this.reg[7];
    int result = a - n;
    int f = result & 0x80 | 0x2 | n & 0x28;
    if (result < 0)
      f |= 0x1; 
    result &= 0xFF;
    if (((a ^ n) & 0x80) != 0 && ((result ^ a) & 0x80) != 0)
      f |= 0x4; 
    if ((a & 0xF) - (n & 0xF) < 0)
      f |= 0x10; 
    this.reg[6] = (result == 0) ? (f | 0x40) : f;
  }
  
  protected void cpin(int n) {
    int a = this.reg[7];
    int result = a - n;
    int f = result & 0x80 | 0x2;
    if (result < 0)
      f |= 0x1; 
    result &= 0xFF;
    if (((a ^ n) & 0x80) != 0 && ((result ^ a) & 0x80) != 0)
      f |= 0x4; 
    if ((a & 0xF) - (n & 0xF) < 0)
      f |= 0x10; 
    this.reg[6] = (result == 0) ? (f | 0x40) : f;
    result -= this.reg[6] >> 4 & 0x1;
    this.reg[6] = this.reg[6] | (result & 0x2) << 4;
    this.reg[6] = this.reg[6] | result & 0x8;
  }
  
  protected void cpahl() {
    cpan(readByte(getqq(4)));
  }
  
  protected void incr(int opcode) {
    int r = (opcode & 0x38) >> 3;
    this.reg[r] = incn(this.reg[r]);
  }
  
  protected void incchl() {
    int hl = getqq(4);
    writeByte(hl, incn(readByte(hl)));
  }
  
  protected void decr(int opcode) {
    int r = (opcode & 0x38) >> 3;
    this.reg[r] = decn(this.reg[r]);
  }
  
  protected void decchl() {
    int hl = getqq(4);
    writeByte(hl, decn(readByte(hl)));
  }
  
  protected void daa() {
    int a = this.reg[7];
    int f = this.reg[6];
    int lsn = a & 0xF;
    int add = (lsn > 9 || (f & 0x10) != 0) ? 6 : 0;
    if ((f & 0x1) != 0 || a > 153) {
      f |= 0x1;
      add |= 0x60;
    } 
    if ((f & 0x2) != 0) {
      suba(add, 0);
    } else {
      addan(add, 0);
    } 
    this.reg[6] = this.reg[6] & 0xFFFFFFFA | f & 0x1 | PARITY[this.reg[7]];
  }
  
  protected void cpl() {
    int a = this.reg[7] = (this.reg[7] ^ 0xFFFFFFFF) & 0xFF;
    this.reg[6] = this.reg[6] & 0xC5 | a & 0x28 | 0x10 | 0x2;
  }
  
  protected void neg() {
    int a = this.reg[7];
    this.reg[7] = 0;
    suba(a, 0);
  }
  
  protected void ccf() {
    int f = this.reg[6];
    this.reg[6] = f & 0xC5 ^ 0x1 | this.reg[7] & 0x28 | (((f & 0x1) == 0) ? 0 : 16);
  }
  
  protected void scf() {
    this.reg[6] = this.reg[6] & 0xC5 | this.reg[7] & 0x28 | 0x1;
  }
  
  protected void nop() {}
  
  public void haltstop() {
    this.inHalt = true;
  }
  
  protected void halt() {
    this.inHalt = true;
    this.PC = this.PC - 1 & 0xFFFF;
  }
  
  public void di() {
    this.IFF1 = this.IFF2 = false;
  }
  
  public void ei() {
    this.checkintafter = false;
    this.IFF1 = this.IFF2 = true;
  }
  
  protected void imn(int n) {
    this.IM = n;
  }
  
  protected void addhlss(int opcode) {
    int ss = (opcode & 0x30) >> 3;
    int hl = getqq(4);
    this.MEMPTR = hl + 1;
    int n = getdd(ss);
    int result = hl + n;
    int f = this.reg[6] & 0xC4 | result >> 8 & 0x28;
    if ((result & 0x10000) != 0)
      f |= 0x1; 
    if ((hl & 0xFFF) + (n & 0xFFF) > 4095)
      f |= 0x10; 
    setqq(4, result);
    this.reg[6] = f;
  }
  
  protected void adchlss(int opcode) {
    int ss = (opcode & 0x30) >> 3;
    int hl = getqq(4);
    this.MEMPTR = hl + 1;
    int n = getdd(ss);
    int c = this.reg[6] & 0x1;
    int result = hl + n + c;
    int f = result >> 8 & 0xA8;
    if ((result & 0x10000) != 0)
      f |= 0x1; 
    if ((hl & 0xFFF) + (n & 0xFFF) + c > 4095)
      f |= 0x10; 
    if (((hl ^ n) & 0x8000) == 0 && ((result ^ hl) & 0x8000) != 0)
      f |= 0x4; 
    setqq(4, result &= 0xFFFF);
    this.reg[6] = (result == 0) ? (f | 0x40) : f;
  }
  
  protected void sbchlss(int opcode) {
    int ss = (opcode & 0x30) >> 3;
    int hl = getqq(4);
    this.MEMPTR = hl + 1;
    int n = getdd(ss);
    int c = this.reg[6] & 0x1;
    int result = hl - n - c;
    int f = result >> 8 & 0xA8 | 0x2;
    if (result < 0)
      f |= 0x1; 
    if ((hl & 0xFFF) - (n & 0xFFF) - c < 0)
      f |= 0x10; 
    if (((hl ^ n) & 0x8000) != 0 && ((result ^ hl) & 0x8000) != 0)
      f |= 0x4; 
    setqq(4, result &= 0xFFFF);
    this.reg[6] = (result == 0) ? (f | 0x40) : f;
  }
  
  protected void incss(int opcode) {
    int ss = (opcode & 0x30) >> 3;
    setdd(ss, getdd(ss) + 1 & 0xFFFF);
  }
  
  protected void decss(int opcode) {
    int ss = (opcode & 0x30) >> 3;
    setdd(ss, getdd(ss) - 1 & 0xFFFF);
  }
  
  protected void rlca() {
    int a = this.reg[7];
    int c = ((a & 0x80) == 0) ? 0 : 1;
    this.reg[7] = a = (a << 1 | c) & 0xFF;
    this.reg[6] = this.reg[6] & 0xC4 | a & 0x28 | c;
  }
  
  protected void rla() {
    int a = this.reg[7];
    int f = this.reg[6];
    a = a << 1 | f & 0x1;
    f = f & 0xC4 | a & 0x28;
    this.reg[7] = a & 0xFF;
    this.reg[6] = ((a & 0x100) != 0) ? (f | 0x1) : f;
  }
  
  protected void rrca() {
    int a = this.reg[7];
    int c = a & 0x1;
    this.reg[7] = a = (a >> 1 | c << 7) & 0xFF;
    this.reg[6] = this.reg[6] & 0xC4 | a & 0x28 | c;
  }
  
  protected void rra() {
    int a = this.reg[7];
    int f = this.reg[6];
    int c = a & 0x1;
    this.reg[7] = a = (((f & 0x1) == 0) ? (a >> 1) : (a >> 1 | 0x80)) & 0xFF;
    this.reg[6] = this.reg[6] & 0xC4 | a & 0x28 | c;
  }
  
  protected void rlcr(int opcode) {
    int r = opcode & 0x7;
    this.reg[r] = rlcn(this.reg[r]);
  }
  
  protected int rlchl() {
    int hl = getqq(4);
    return writeByte(hl, rlcn(readByte(hl)));
  }
  
  protected void rlr(int opcode) {
    int r = opcode & 0x7;
    this.reg[r] = rln(this.reg[r]);
  }
  
  protected int rlhl() {
    int hl = getqq(4);
    return writeByte(hl, rln(readByte(hl)));
  }
  
  protected void rrcr(int opcode) {
    int r = opcode & 0x7;
    this.reg[r] = rrcn(this.reg[r]);
  }
  
  protected int rrchl() {
    int hl = getqq(4);
    return writeByte(hl, rrcn(readByte(hl)));
  }
  
  protected void rrr(int opcode) {
    int r = opcode & 0x7;
    this.reg[r] = rrn(this.reg[r]);
  }
  
  protected int rrhl() {
    int hl = getqq(4);
    return writeByte(hl, rrn(readByte(hl)));
  }
  
  protected void slar(int opcode) {
    int r = opcode & 0x7;
    this.reg[r] = slan(this.reg[r]);
  }
  
  protected int slahl() {
    int hl = getqq(4);
    return writeByte(hl, slan(readByte(hl)));
  }
  
  protected void sllr(int opcode) {
    int r = opcode & 0x7;
    this.reg[r] = slln(this.reg[r]);
  }
  
  protected int sllhl() {
    int hl = getqq(4);
    return writeByte(hl, slln(readByte(hl)));
  }
  
  protected void srar(int opcode) {
    int r = opcode & 0x7;
    this.reg[r] = sran(this.reg[r]);
  }
  
  protected int srahl() {
    int hl = getqq(4);
    return writeByte(hl, sran(readByte(hl)));
  }
  
  protected void srlr(int opcode) {
    int r = opcode & 0x7;
    this.reg[r] = srln(this.reg[r]);
  }
  
  protected int srlhl() {
    int hl = getqq(4);
    return writeByte(hl, srln(readByte(hl)));
  }
  
  protected void rld() {
    int a = this.reg[7];
    int hl = getqq(4);
    this.MEMPTR = hl + 1;
    int b = readByte(hl);
    writeByte(hl, (b << 4 | a & 0xF) & 0xFF);
    this.reg[7] = a = a & 0xF0 | b >> 4 & 0xF;
    int f = this.reg[6] & 0x1 | a & 0xA8 | PARITY[a];
    this.reg[6] = (a == 0) ? (f | 0x40) : f;
  }
  
  protected void rrd() {
    int a = this.reg[7];
    int hl = getqq(4);
    this.MEMPTR = hl + 1;
    int b = readByte(hl);
    writeByte(hl, a << 4 & 0xF0 | b >> 4 & 0xF);
    this.reg[7] = a = a & 0xF0 | b & 0xF;
    int f = this.reg[6] & 0x1 | a & 0xA8 | PARITY[a];
    this.reg[6] = (a == 0) ? (f | 0x40) : f;
  }
  
  protected void bitbr(int opcode) {
    int r = opcode & 0x7;
    bitbn(this.reg[r], opcode);
  }
  
  protected void bitbhl(int opcode) {
    int hl = getqq(4);
    int b = (opcode & 0x38) >> 3;
    int n = readByte(hl) & 1 << b;
    int f = this.reg[6] & 0x1 | n & 0x80 | this.MEMPTR >> 8 & 0x28 | 0x10;
    this.reg[6] = (n == 0) ? (f | 0x44) : f;
  }
  
  protected void setbr(int opcode) {
    int r = opcode & 0x7;
    this.reg[r] = setbn(this.reg[r], opcode);
  }
  
  protected int setbhl(int opcode) {
    int hl = getqq(4);
    return writeByte(hl, setbn(readByte(hl), opcode));
  }
  
  protected void resbr(int opcode) {
    int r = opcode & 0x7;
    this.reg[r] = resbn(this.reg[r], opcode);
  }
  
  protected int resbhl(int opcode) {
    int hl = getqq(4);
    return writeByte(hl, resbn(readByte(hl), opcode));
  }
  
  protected void jpnn(int nn) {
    this.MEMPTR = this.PC = nn;
  }
  
  protected static final int[] CC_MASK = new int[] { 64, 64, 1, 1, 4, 4, 128, 128 };
  
  protected static final int[] CC_TEST = new int[] { 0, 64, 0, 1, 0, 4, 0, 128 };
  
  protected void jpccnn(int opcode, int nn) {
    int cc = (opcode & 0x38) >> 3;
    if ((this.reg[6] & CC_MASK[cc]) == CC_TEST[cc])
      this.MEMPTR = this.PC = nn; 
  }
  
  protected void jre(byte e) {
    this.MEMPTR = this.PC = this.PC + e & 0xFFFF;
  }
  
  protected void jrce(byte e) {
    if ((this.reg[6] & 0x1) != 0) {
      this.MEMPTR = this.PC = this.PC + e & 0xFFFF;
      cycle(this.timeExtra[0]);
    } 
  }
  
  protected void jrnce(byte e) {
    if ((this.reg[6] & 0x1) == 0) {
      this.MEMPTR = this.PC = this.PC + e & 0xFFFF;
      cycle(this.timeExtra[0]);
    } 
  }
  
  protected void jrze(byte e) {
    if ((this.reg[6] & 0x40) != 0) {
      this.MEMPTR = this.PC = this.PC + e & 0xFFFF;
      cycle(this.timeExtra[0]);
    } 
  }
  
  protected void jrnze(byte e) {
    if ((this.reg[6] & 0x40) == 0) {
      this.MEMPTR = this.PC = this.PC + e & 0xFFFF;
      cycle(this.timeExtra[0]);
    } 
  }
  
  protected void jphl() {
    this.PC = getqq(4);
  }
  
  protected void djnze(byte e) {
    int b = this.reg[0] = this.reg[0] - 1 & 0xFF;
    if (b != 0) {
      this.MEMPTR = this.PC = this.PC + e & 0xFFFF;
      cycle(this.timeExtra[1]);
    } 
  }
  
  protected void callnn(int nn) {
    push(this.PC);
    this.MEMPTR = this.PC = nn;
  }
  
  protected void callccnn(int opcode, int nn) {
    int cc = (opcode & 0x38) >> 3;
    if ((this.reg[6] & CC_MASK[cc]) == CC_TEST[cc]) {
      push(this.PC);
      this.PC = nn;
      cycle(this.timeExtra[2]);
    } 
    this.MEMPTR = nn;
  }
  
  public void ret() {
    this.MEMPTR = this.PC = pop();
  }
  
  protected void retcc(int opcode) {
    int cc = (opcode & 0x38) >> 3;
    if ((this.reg[6] & CC_MASK[cc]) == CC_TEST[cc]) {
      this.MEMPTR = this.PC = pop();
      cycle(this.timeExtra[3]);
    } 
  }
  
  protected void reti() {
    this.MEMPTR = this.PC = pop();
    this.IFF1 = this.IFF2;
  }
  
  protected void retn() {
    this.MEMPTR = this.PC = pop();
    this.IFF1 = this.IFF2;
  }
  
  protected void rstp(int opcode) {
    push(this.PC);
    this.MEMPTR = this.PC = opcode & 0x38;
  }
  
  protected void inan(int n) {
    int addr = this.reg[7] << 8 | n;
    this.reg[7] = in(addr);
    this.MEMPTR = addr + 1;
  }
  
  protected void inrc(int opcode) {
    int r = (opcode & 0x38) >> 3;
    int bc = getqq(0);
    int result = this.reg[r] = in(bc);
    int f = this.reg[6] & 0x1 | result & 0xA8 | PARITY[result];
    this.reg[6] = (result == 0) ? (f | 0x40) : f;
    this.MEMPTR = bc + 1;
  }
  
  protected void inc() {
    int bc = getqq(0);
    int result = in(bc);
    int f = this.reg[6] & 0x1 | result & 0xA8 | PARITY[result];
    this.reg[6] = (result == 0) ? (f | 0x40) : f;
    this.MEMPTR = bc + 1;
  }
  
  protected void ini() {
    inid(1);
  }
  
  protected void inir() {
    inid(1);
    if ((this.reg[6] & 0x40) == 0) {
      this.PC = this.PC - 2 & 0xFFFF;
      cycle(this.timeExtra[6]);
    } 
  }
  
  protected void ind() {
    inid(-1);
  }
  
  protected void indr() {
    inid(-1);
    if ((this.reg[6] & 0x40) == 0) {
      this.PC = this.PC - 2 & 0xFFFF;
      cycle(this.timeExtra[6]);
    } 
  }
  
  protected void outna(int n) {
    int a = this.reg[7];
    int a8 = a << 8;
    int addr = a8 | n;
    out(addr, a);
    this.MEMPTR = n + 1 & 0xFF | a8;
  }
  
  protected void outcr(int opcode) {
    int r = (opcode & 0x38) >> 3;
    int bc = getqq(0);
    out(bc, this.reg[r]);
    this.MEMPTR = bc + 1;
  }
  
  protected void outc0() {
    int bc = getqq(0);
    out(bc, 0);
    this.MEMPTR = bc + 1;
  }
  
  protected void outi() {
    outid(1);
  }
  
  protected void otir() {
    outid(1);
    if ((this.reg[6] & 0x40) == 0) {
      this.PC = this.PC - 2 & 0xFFFF;
      cycle(this.timeExtra[7]);
    } 
  }
  
  protected void outd() {
    outid(-1);
  }
  
  protected void otdr() {
    outid(-1);
    if ((this.reg[6] & 0x40) == 0) {
      this.PC = this.PC - 2 & 0xFFFF;
      cycle(this.timeExtra[7]);
    } 
  }
  
  protected void endldi(int de, int hl, int n) {
    setqq(2, de & 0xFFFF);
    setqq(4, hl & 0xFFFF);
    int bc = getqq(0) - 1 & 0xFFFF;
    setqq(0, bc);
    n += this.reg[7];
    int f = this.reg[6] & 0xC1 | n << 4 & 0x20 | n & 0x8;
    this.reg[6] = (bc != 0) ? (f | 0x4) : f;
  }
  
  protected void bitbn(int n, int opcode) {
    int b = (opcode & 0x38) >> 3;
    int f = this.reg[6] & 0x1 | n & 0x28 | 0x10;
    if ((n >> b & 0x1) != 0) {
      this.reg[6] = (b == 7) ? (f | 0x80) : f;
    } else {
      this.reg[6] = f | 0x44;
    } 
  }
  
  protected void cpid(int add) {
    int hl = getqq(4);
    int a = this.reg[7];
    int n = readByte(hl);
    int result = a - n & 0xFF;
    int f = this.reg[6] & 0x1 | result & 0x80 | 0x2;
    if (result == 0)
      f |= 0x40; 
    if ((a & 0xF) - (n & 0xF) < 0) {
      f |= 0x10;
      result--;
    } 
    hl = hl + add & 0xFFFF;
    setqq(4, hl);
    int bc = getqq(0) - 1 & 0xFFFF;
    setqq(0, bc);
    this.reg[6] = ((bc != 0) ? (f | 0x4) : f) | result << 4 & 0x20 | result & 0x8;
    this.MEMPTR += add;
  }
  
  protected void ldair(int a) {
    this.reg[7] = a;
    int f = a & 0xA8 | this.reg[6] & 0x1;
    if (this.IFF2)
      f |= 0x4; 
    this.reg[6] = (a == 0) ? (f | 0x40) : f;
    this.noWait = true;
  }
  
  protected void addan(int n, int c) {
    int a = this.reg[7];
    int result = a + n + c;
    int f = result & 0xA8;
    if ((result & 0x100) != 0)
      f |= 0x1; 
    this.reg[7] = result &= 0xFF;
    if (((a ^ n) & 0x80) == 0 && ((result ^ a) & 0x80) != 0)
      f |= 0x4; 
    if ((a & 0xF) + (n & 0xF) + c > 15)
      f |= 0x10; 
    this.reg[6] = (result == 0) ? (f | 0x40) : f;
  }
  
  protected void suba(int n, int c) {
    int a = this.reg[7];
    int result = a - n - c;
    int f = result & 0xA8 | 0x2;
    if (result < 0)
      f |= 0x1; 
    this.reg[7] = result &= 0xFF;
    if (((a ^ n) & 0x80) != 0 && ((result ^ a) & 0x80) != 0)
      f |= 0x4; 
    if ((a & 0xF) - (n & 0xF) - c < 0)
      f |= 0x10; 
    this.reg[6] = (result == 0) ? (f | 0x40) : f;
  }
  
  protected int incn(int n) {
    n = n + 1 & 0xFF;
    int f = n & 0xA8 | this.reg[6] & 0x1;
    if ((n & 0xF) == 0)
      f |= 0x10; 
    if (n == 128) {
      f |= 0x4;
    } else if (n == 0) {
      f |= 0x40;
    } 
    this.reg[6] = f;
    return n;
  }
  
  protected int decn(int n) {
    n = n - 1 & 0xFF;
    int f = n & 0xA8 | this.reg[6] & 0x1 | 0x2;
    if ((n & 0xF) == 15)
      f |= 0x10; 
    if (n == 127) {
      f |= 0x4;
    } else if (n == 0) {
      f |= 0x40;
    } 
    this.reg[6] = f;
    return n;
  }
  
  protected int rlcn(int n) {
    int c = ((n & 0x80) == 0) ? 0 : 1;
    n = (n << 1 | c) & 0xFF;
    int f = n & 0xA8 | c | PARITY[n];
    this.reg[6] = (n == 0) ? (f | 0x40) : f;
    return n;
  }
  
  protected int rln(int n) {
    int f = this.reg[6];
    n = n << 1 | f & 0x1;
    f = n & 0xA8;
    if ((n & 0x100) != 0)
      f |= 0x1; 
    n &= 0xFF;
    this.reg[6] = ((n == 0) ? (f | 0x40) : f) | PARITY[n];
    return n;
  }
  
  protected int rrcn(int n) {
    int c = n & 0x1;
    n = (n >> 1 | c << 7) & 0xFF;
    int f = n & 0xA8 | c | PARITY[n];
    this.reg[6] = (n == 0) ? (f | 0x40) : f;
    return n;
  }
  
  protected int rrn(int n) {
    int f = this.reg[6];
    int c = n & 0x1;
    n = (((f & 0x1) == 0) ? (n >> 1) : (n >> 1 | 0x80)) & 0xFF;
    f = n & 0xA8 | c | PARITY[n];
    this.reg[6] = (n == 0) ? (f | 0x40) : f;
    return n;
  }
  
  protected int slan(int n) {
    n <<= 1;
    int f = n & 0xA8;
    if ((n & 0x100) != 0)
      f |= 0x1; 
    n &= 0xFF;
    this.reg[6] = ((n == 0) ? (f | 0x40) : f) | PARITY[n];
    return n;
  }
  
  protected int slln(int n) {
    n = n << 1 | 0x1;
    int f = n & 0xA8;
    if ((n & 0x100) != 0)
      f |= 0x1; 
    n &= 0xFF;
    this.reg[6] = ((n == 0) ? (f | 0x40) : f) | PARITY[n];
    return n;
  }
  
  protected int sran(int n) {
    int c = n & 0x1;
    n = n >> 1 | n & 0x80;
    int f = n & 0xA8 | c | PARITY[n];
    this.reg[6] = (n == 0) ? (f | 0x40) : f;
    return n;
  }
  
  protected int srln(int n) {
    int c = n & 0x1;
    n >>= 1;
    int f = n & 0xA8 | c | PARITY[n];
    this.reg[6] = (n == 0) ? (f | 0x40) : f;
    return n;
  }
  
  protected int setbn(int n, int opcode) {
    int b = (opcode & 0x38) >> 3;
    return n | 1 << b;
  }
  
  protected int resbn(int n, int opcode) {
    int b = (opcode & 0x38) >> 3;
    return n & (1 << b ^ 0xFFFFFFFF);
  }
  
  protected void inid(int add) {
    int hl = getqq(4);
    int b = this.reg[0];
    int c = this.reg[1];
    int bc = b << 8 | c;
    int result = in(bc);
    writeByte(hl, result);
    setqq(4, hl + add & 0xFFFF);
    c = (((c + add & 0xFF) + result & 0x100) != 0) ? 17 : 0;
    this.reg[0] = b = decn(b);
    this.reg[6] = this.reg[6] & 0xE8 | c | PARITY[result] | (result & 0x80) >> 6;
    this.MEMPTR = bc + add;
  }
  
  protected void outid(int add) {
    int hl = getqq(4);
    int b = this.reg[0] = decn(this.reg[0]);
    int addr = b << 8 | this.reg[1];
    out(addr, readByte(hl));
    setqq(4, hl + add & 0xFFFF);
    this.MEMPTR = addr + add;
  }
  
  protected int getqq(int index) {
    return (index == 6) ? (this.reg[index] | this.reg[index + 1] << 8) : (this.reg[index + 1] | this.reg[index] << 8);
  }
  
  protected void setqq(int index, int value) {
    if (index == 6) {
      this.reg[index] = value & 0xFF;
      this.reg[index + 1] = value >> 8 & 0xFF;
    } else {
      this.reg[index + 1] = value & 0xFF;
      this.reg[index] = value >> 8 & 0xFF;
    } 
  }
  
  protected int getdd(int index) {
    return (index == 6) ? this.SP : (this.reg[index + 1] | this.reg[index] << 8);
  }
  
  protected void setdd(int index, int value) {
    if (index == 6) {
      this.SP = value & 0xFFFF;
    } else {
      this.reg[index + 1] = value & 0xFF;
      this.reg[index] = value >> 8 & 0xFF;
    } 
  }
  
  protected int pop() {
    int result = readWord(this.SP);
    this.SP = this.SP + 2 & 0xFFFF;
    return result;
  }
  
  public void push(int data) {
    this.SP = this.SP - 2 & 0xFFFF;
    writeWord(this.SP, data);
  }
  
  protected static final Register[] REGISTERS = new Register[] { 
      new Register("Flags", 8, "SZ-H-VNC"), new Register("AF", 16), new Register("AF'", 16, 1), new Register("HL", 16), new Register("HL'", 16, 1), new Register("DE", 16), new Register("DE'", 16, 1), new Register("BC", 16), new Register("BC'", 16, 1), new Register("IX", 16), 
      new Register("SP", 16, 1), new Register("IY", 16), new Register("I", 8, 1), new Register("PC", 16), new Register("R", 8, 1), new Register("MEMPTR", 16), new Register("IM", 8, 1), new Register("IFF1", 8), new Register("IFF2", 8, 1) };
  
  public Register[] getRegisters() {
    return REGISTERS;
  }
  
  public int getRegisterValue(int index) {
    switch (index) {
      case 0:
        result = this.reg[6];
        return result;
      case 1:
        result = getqq(6);
        return result;
      case 2:
        result = this.reg[14] | this.reg[15] << 8;
        return result;
      case 3:
        result = getqq(4);
        return result;
      case 4:
        result = getqq(12);
        return result;
      case 5:
        result = getqq(2);
        return result;
      case 6:
        result = getqq(10);
        return result;
      case 7:
        result = getqq(0);
        return result;
      case 8:
        result = getqq(8);
        return result;
      case 9:
        result = this.IX;
        return result;
      case 10:
        result = this.SP;
        return result;
      case 11:
        result = this.IY;
        return result;
      case 12:
        result = this.I;
        return result;
      case 13:
        result = this.PC;
        return result;
      case 14:
        result = this.R & 0x7F | this.R7;
        return result;
      case 15:
        result = this.MEMPTR;
        return result;
      case 16:
        result = this.IM;
        return result;
      case 17:
        result = this.IFF1 ? 1 : 0;
        return result;
      case 18:
        result = this.IFF2 ? 1 : 0;
        return result;
    } 
    int result = 0;
    return result;
  }
  
  public int getProgramCounter() {
    return this.PC;
  }
  
  public int getStackPointer() {
    return this.SP;
  }
  
  public void setAF(int value) {
    setqq(6, value);
  }
  
  public void setB(int value) {
    setqq(0, value);
  }
  
  public void setBC(int value) {
    setqq(0, value);
  }
  
  public void setDE(int value) {
    setqq(2, value);
  }
  
  public void setHL(int value) {
    setqq(4, value);
  }
  
  public void setR(int value) {
    this.R = value & 0xFF;
    this.R7 = value & 0x80;
  }
  
  public void setI(int value) {
    this.I = value & 0xFF;
  }
  
  public void setIFF1(boolean value) {
    this.IFF1 = value;
  }
  
  public void setIFF2(boolean value) {
    this.IFF2 = value;
  }
  
  public int getIFF1() {
    if (this.IFF1)
      return 1; 
    return 0;
  }
  
  public int getIFF2() {
    if (this.IFF2)
      return 1; 
    return 0;
  }
  
  public void setIX(int value) {
    this.IX = value & 0xFFFF;
  }
  
  public void setIY(int value) {
    this.IY = value & 0xFFFF;
  }
  
  public void setSP(int value) {
    this.SP = value & 0xFFFF;
  }
  
  public void setPC(int value) {
    this.PC = value & 0xFFFF;
  }
  
  public int getMEMPTR() {
    return this.MEMPTR & 0xFFFF;
  }
  
  public void setIM(int value) {
    this.IM = value & 0xFF;
  }
  
  public int getIM() {
    return this.IM;
  }
  
  public void setF(int value) {
    setqq(6, value);
  }
  
  public void incHL() {
    setqq(4, getHL() + 1);
  }
  
  public void setAF1(int value) {
    this.reg[14] = value & 0xFF;
    this.reg[15] = value >> 8 & 0xFF;
  }
  
  public void setBC1(int value) {
    setqq(8, value);
  }
  
  public void setDE1(int value) {
    setqq(10, value);
  }
  
  public void setHL1(int value) {
    setqq(12, value);
  }
  
  public boolean isInHalt() {
    return this.inHalt;
  }
  
  public int getF() {
    return 6;
  }
  
  public int getA() {
    return 7;
  }
  
  public void setA(int value) {
    this.reg[7] = value;
  }
  
  public int getC() {
    return 1;
  }
  
  public int getB() {
    return 0;
  }
  
  public int getE() {
    return 3;
  }
  
  public int getD() {
    return 2;
  }
  
  public int getL() {
    return 5;
  }
  
  public int getH() {
    return 4;
  }
  
  public int getR() {
    return this.R & 0x7F | this.R7;
  }
  
  public int getI() {
    return this.I;
  }
  
  public int getPC() {
    return this.PC;
  }
  
  public int getAF() {
    return getqq(6);
  }
  
  public int getBC() {
    return getqq(0);
  }
  
  public int getDE() {
    return getqq(2);
  }
  
  public int getHL() {
    return getqq(4);
  }
  
  public int getIX() {
    return this.IX;
  }
  
  public int getIY() {
    return this.IY;
  }
  
  public int getSP() {
    return this.SP;
  }
  
  public int getAF1() {
    return this.reg[14] | this.reg[15] << 8;
  }
  
  public int getBC1() {
    return getqq(8);
  }
  
  public int getDE1() {
    return getqq(10);
  }
  
  public int getHL1() {
    return getqq(12);
  }
  
  public String getState() {
    String result = "AF :" + Util.hex((short)getqq(6)) + " HL :" + Util.hex((short)getqq(4)) + " DE :" + Util.hex((short)getqq(2)) + " BC :" + Util.hex((short)getqq(0)) + " IX :" + Util.hex((short)this.IX) + " IY :" + Util.hex((short)this.IY) + "\nAF':" + Util.hex((byte)this.reg[15]) + Util.hex((byte)this.reg[14]) + " HL':" + Util.hex((short)getqq(12)) + " DE':" + Util.hex((short)getqq(10)) + " BC':" + Util.hex((short)getqq(8)) + " Cycles: " + Util.hex((int)this.cycles);
    return result;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\cpu\Z80.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */