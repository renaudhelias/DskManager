package jemu.core.cpu;

import java.util.ArrayList;
import java.util.List;
import jemu.core.Util;
import jemu.core.device.Device;
import jemu.core.device.DeviceMapping;
import jemu.ui.Switches;

public abstract class Processor extends Device {
  public int actualAddress;
  
  protected Device memory;
  
  protected DeviceMapping[] inputDevice = new DeviceMapping[0];
  
  protected DeviceMapping[] outputDevice = new DeviceMapping[0];
  
  protected Device cycleDevice = null;
  
  protected Device interruptDevice = null;
  
  protected int interruptPending = 0;
  
  protected long cycles = 0L;
  
  protected long cyclesPerSecond;
  
  private long cyclePreviousProgramCounter = 1048575L;
  
  protected boolean stopped = false;
  
  private final List<ProgramCounterObserver> programCounterObservers;
  
  public Processor(String type, long cyclesPerSecond) {
    super(type);
    this.programCounterObservers = new ArrayList<>();
    this.cyclesPerSecond = cyclesPerSecond;
  }
  
  public void cycle(int count) {
    if (this.cycleDevice == null)
      return; 
    for (; count > 0; count--) {
      this.cycles++;
      this.cycleDevice.cycle();
    } 
    if (Switches.breakpoints) {
      int cycleProgramCounter = getProgramCounter();
      if (cycleProgramCounter != this.cyclePreviousProgramCounter) {
        notifyProgramCounterObservers();
        this.cyclePreviousProgramCounter = cycleProgramCounter;
      } 
    } 
  }
  
  public void cycle() {
    cycle(1);
  }
  
  public void reset() {
    this.cycles = 0L;
  }
  
  public long getCycles() {
    return this.cycles;
  }
  
  public abstract void step();
  
  public abstract void stepOver();
  
  public void run() {
    this.stopped = false;
    do {
      step();
    } while (!this.stopped);
  }
  
  public void runTo(int address) {
    this.stopped = false;
    do {
      step();
    } while (!this.stopped && getProgramCounter() != address);
  }
  
  public synchronized void stop() {
    this.stopped = true;
  }
  
  public final int readWord(int addr) {
    return readByte(addr) + (readByte(addr + 1 & 0xFFFF) << 8);
  }
  
  public final void writeWord(int addr, int value) {
    writeByte(addr, value);
    writeByte(addr + 1 & 0xFFFF, value >> 8);
  }
  
  public int readByte(int address) {
    try {
      return this.memory.readByte(address);
    } catch (Exception exception) {
      return 0;
    } 
  }
  
  public int writeByte(int address, int value) {
    return this.memory.writeByte(address, value);
  }
  
  public final int in(int port) {
    int result = 255;
    for (int i = 0; i < this.inputDevice.length; i++)
      result &= this.inputDevice[i].readPort(port); 
    return result;
  }
  
  public final void out(int port, int value) {
    for (int i = 0; i < this.outputDevice.length; i++) {
      try {
        this.outputDevice[i].writePort(port, value);
      } catch (Exception exception) {}
    } 
  }
  
  public final void setMemoryDevice(Device value) {
    this.memory = value;
  }
  
  public final Device getMemoryDevice() {
    return this.memory;
  }
  
  public final void addInputDeviceMapping(DeviceMapping value) {
    this.inputDevice = (DeviceMapping[])Util.arrayInsert((Object[])this.inputDevice, this.inputDevice.length, 1, value);
  }
  
  public final void removeInputDeviceMapping(DeviceMapping value) {
    this.inputDevice = (DeviceMapping[])Util.arrayDeleteElement((Object[])this.inputDevice, value);
  }
  
  public final void addOutputDeviceMapping(DeviceMapping value) {
    this.outputDevice = (DeviceMapping[])Util.arrayInsert((Object[])this.outputDevice, this.outputDevice.length, 1, value);
  }
  
  public final void removeOutputDeviceMapping(DeviceMapping value) {
    this.outputDevice = (DeviceMapping[])Util.arrayDeleteElement((Object[])this.outputDevice, value);
  }
  
  public final void setCycleDevice(Device value) {
    this.cycleDevice = value;
  }
  
  public final void setInterruptDevice(Device value) {
    this.interruptDevice = value;
  }
  
  public void setInterrupt(int mask) {
    this.interruptPending |= mask;
  }
  
  public void clearInterrupt(int mask) {
    this.interruptPending &= mask ^ 0xFFFFFFFF;
  }
  
  public abstract String getState();
  
  public abstract int getProgramCounter();
  
  public abstract int getStackPointer();
  
  public long getCyclesPerSecond() {
    return this.cyclesPerSecond;
  }
  
  public void setCyclesPerSecond(long value) {
    this.cyclesPerSecond = value;
  }
  
  public void attachProgramCounterObserver(ProgramCounterObserver o) {
    this.programCounterObservers.add(o);
  }
  
  public void detachProgramCounterObserver(ProgramCounterObserver o) {
    this.programCounterObservers.remove(o);
  }
  
  public void notifyProgramCounterObservers() {
    int address = getProgramCounter();
    this.actualAddress = address;
    if (!this.programCounterObservers.isEmpty())
      try {
        for (ProgramCounterObserver o : this.programCounterObservers)
          o.update(address); 
      } catch (Exception e) {
        System.err.println("A bug happened");
      }  
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\core\cpu\Processor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */