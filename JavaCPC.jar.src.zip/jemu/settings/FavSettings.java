package jemu.settings;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Properties;

public class FavSettings {
  private static File file = new File(System.getProperty("user.home"), "/JavaCPC/favsettings.ini");
  
  private static File removeme = new File(System.getProperty("user.home"), "/JavaCPC/favsettings.xml");
  
  private static final FavSettings instance = new FavSettings();
  
  private final Properties props = new Properties();
  
  public static final String DSKICON = "icon_image_";
  
  public static final String DSKLABEL = "icon_label_";
  
  public static final String DSKTEXT = "icon_text_";
  
  public static final String DSKPOSX = "icon_pos_x_";
  
  public static final String DSKPOSY = "icon_pos_y_";
  
  private FavSettings() {
    try {
      if (System.getSecurityManager() != null) {
        file.mkdir();
        System.getSecurityManager().checkRead(file.getAbsolutePath());
      } 
      this.props.load(new FileInputStream(file));
      if (removeme.exists())
        removeme.delete(); 
      System.out.println("loaded " + this.props.size() + " favourites settings");
    } catch (Throwable t) {
      CreateFirst();
      redo();
    } 
  }
  
  private void redo() {
    try {
      if (System.getSecurityManager() != null)
        System.getSecurityManager().checkRead(file.getAbsolutePath()); 
      this.props.load(new FileInputStream(file));
      System.out.println("loaded " + this.props.size() + " favourites settings");
    } catch (Throwable t) {
      System.out.println("can't load user settings (" + t.getMessage() + ")");
    } 
  }
  
  public void CreateFirst() {
    String name = "favsettings.ini";
    byte[] buffer = null;
    int offs = 0;
    try {
      InputStream stream = null;
      try {
        InputStream is = getClass().getResourceAsStream(name);
        stream = is;
        int size = is.available();
        buffer = new byte[size];
        while (size > 0) {
          int read = stream.read(buffer, offs, size);
          if (read == -1)
            break; 
          offs += read;
          size -= read;
        } 
      } finally {
        if (stream != null)
          stream.close(); 
      } 
    } catch (Exception e) {
      System.err.println("File not found...");
    } 
    if (buffer != null)
      try {
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
        bos.write(buffer);
        bos.close();
      } catch (Exception exception) {} 
  }
  
  public static boolean getBoolean(String key, boolean defaultValue) {
    String value = instance.props.getProperty(key);
    if (value == null)
      return defaultValue; 
    return value.equals("true");
  }
  
  public static void setBoolean(String key, boolean value) {
    instance.props.setProperty(key, value ? "true" : "false");
    save();
  }
  
  public static String get(String key, String defaultValue) {
    String value = instance.props.getProperty(key);
    if (value == null)
      return defaultValue; 
    return value;
  }
  
  public static void set(String key, String value) {
    if (value.equals(get(key, null)))
      return; 
    instance.props.setProperty(key, value);
    save();
  }
  
  private static void save() {
    try {
      File f = new File(System.getProperty("user.home"), "JavaCPC");
      f.mkdir();
      if (System.getSecurityManager() != null)
        System.getSecurityManager().checkWrite(file.getAbsolutePath()); 
      FileOutputStream fos = new FileOutputStream(file);
      instance.props.store(fos, "[Favourite - Settings]");
      fos.close();
    } catch (Throwable t) {
      System.out.println("can't save user settings (" + t.getMessage() + ")");
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\settings\FavSettings.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */