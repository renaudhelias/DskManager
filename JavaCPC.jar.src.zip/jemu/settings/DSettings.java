package jemu.settings;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Properties;

public class DSettings {
  static int tried;
  
  public static void resetSettings() {
    while (file.exists()) {
      try {
        file.delete();
        Thread.sleep(100L);
        tried++;
        if (tried > 10) {
          System.out.println("Clearing the desktop config failed...");
          return;
        } 
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
  }
  
  private static File file = new File(System.getProperty("user.home"), "/JavaCPC/desktopsettings.xml");
  
  private static final DSettings instance = new DSettings();
  
  private final Properties props = new Properties();
  
  public static final String ALIGN = "align";
  
  public static final String UNDECORATE = "undecorate";
  
  public static final String STYLE = "look";
  
  public static final String COLOR = "themecolor";
  
  public static final String DESKTOP = "use_desktop";
  
  public static final String WALLPAPER = "wallpaper";
  
  public static final String CONVERTSCREEN = "paint_path";
  
  public static final String STRETCH = "stretch";
  
  public static final String TILED = "tiled";
  
  public static final String CLOCKX = "clockx";
  
  public static final String CLOCKY = "clocky";
  
  public static final String ICON1X = "icon1x";
  
  public static final String ICON1Y = "icon1y";
  
  public static final String ICON2X = "icon2x";
  
  public static final String ICON2Y = "icon2y";
  
  public static final String ICON3X = "icon3x";
  
  public static final String ICON3Y = "icon3y";
  
  public static final String ICON4X = "icon4x";
  
  public static final String ICON4Y = "icon4y";
  
  public static final String ICON5X = "icon5x";
  
  public static final String ICON5Y = "icon5y";
  
  public static final String ICON6X = "icon6x";
  
  public static final String ICON6Y = "icon6y";
  
  public static final String ICON7X = "icon7x";
  
  public static final String ICON7Y = "icon7y";
  
  public static final String ICON8X = "icon8x";
  
  public static final String ICON8Y = "icon8y";
  
  public static final String ICON9X = "icon9x";
  
  public static final String ICON9Y = "icon9y";
  
  public static final String ICON10X = "icon10x";
  
  public static final String ICON10Y = "icon10y";
  
  public static final String ICON11X = "icon11x";
  
  public static final String ICON11Y = "icon11y";
  
  public static final String ICON12X = "icon12x";
  
  public static final String ICON12Y = "icon12y";
  
  public static final String ICON13X = "icon13x";
  
  public static final String ICON13Y = "icon13y";
  
  public static final String ICON14X = "icon14x";
  
  public static final String ICON14Y = "icon14y";
  
  public static final String ICON15X = "icon15x";
  
  public static final String ICON15Y = "icon15y";
  
  public static final String ICON16X = "icon16x";
  
  public static final String ICON16Y = "icon16y";
  
  public static final String ICON17X = "icon17x";
  
  public static final String ICON17Y = "icon17y";
  
  public static final String ICON18X = "icon18x";
  
  public static final String ICON18Y = "icon18y";
  
  public static final String ICON19X = "icon19x";
  
  public static final String ICON19Y = "icon19y";
  
  public static final String ICON20X = "icon20x";
  
  public static final String ICON20Y = "icon20y";
  
  public static final String ICON21X = "icon21x";
  
  public static final String ICON21Y = "icon21y";
  
  public static final String ICON22X = "icon22x";
  
  public static final String ICON22Y = "icon22y";
  
  public static final String ICON23X = "icon23x";
  
  public static final String ICON23Y = "icon23y";
  
  public static final String ICON24X = "icon24x";
  
  public static final String ICON24Y = "icon24y";
  
  public static final String ICON25X = "icon25x";
  
  public static final String ICON25Y = "icon25y";
  
  public static final String ICON26X = "icon26x";
  
  public static final String ICON26Y = "icon26y";
  
  public static final String ICON27X = "icon27x";
  
  public static final String ICON27Y = "icon27y";
  
  public static final String ICON28X = "icon28x";
  
  public static final String ICON28Y = "icon28y";
  
  public static final String ICON29X = "icon29x";
  
  public static final String ICON29Y = "icon29y";
  
  public static final String ICON30X = "icon30x";
  
  public static final String ICON30Y = "icon30y";
  
  public static final String ICON31X = "icon31x";
  
  public static final String ICON31Y = "icon31y";
  
  public static final String ICON32X = "icon32x";
  
  public static final String ICON32Y = "icon32y";
  
  public static final String ICON33X = "icon33x";
  
  public static final String ICON33Y = "icon33y";
  
  public static final String ICON34X = "icon34x";
  
  public static final String ICON34Y = "icon34y";
  
  public static final String ICON35X = "icon35x";
  
  public static final String ICON35Y = "icon35y";
  
  public static final String EMUX = "emux";
  
  public static final String EMUY = "emuy";
  
  private DSettings() {
    try {
      if (System.getSecurityManager() != null) {
        file.mkdir();
        System.getSecurityManager().checkRead(file.getAbsolutePath());
      } 
      this.props.loadFromXML(new FileInputStream(file));
      System.out.println("loaded " + this.props.size() + " desktop settings");
    } catch (Throwable t) {
      CreateFirst();
      redo();
    } 
  }
  
  private void redo() {
    try {
      if (System.getSecurityManager() != null)
        System.getSecurityManager().checkRead(file.getAbsolutePath()); 
      this.props.loadFromXML(new FileInputStream(file));
      System.out.println("loaded " + this.props.size() + " desktop settings");
    } catch (Throwable t) {
      System.out.println("can't load user settings (" + t.getMessage() + ")");
    } 
  }
  
  public void CreateFirst() {
    String name = "desktopsettings.xml";
    byte[] buffer = null;
    int offs = 0;
    try {
      InputStream stream = null;
      try {
        InputStream is = getClass().getResourceAsStream(name);
        stream = is;
        int size = is.available();
        buffer = new byte[size];
        while (size > 0) {
          int read = stream.read(buffer, offs, size);
          if (read == -1)
            break; 
          offs += read;
          size -= read;
        } 
      } finally {
        if (stream != null)
          stream.close(); 
      } 
    } catch (Exception e) {
      System.err.println("File not found...");
    } 
    if (buffer != null)
      try {
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
        bos.write(buffer);
        bos.close();
      } catch (Exception exception) {} 
  }
  
  public static boolean getBoolean(String key, boolean defaultValue) {
    String value = instance.props.getProperty(key);
    if (value == null)
      return defaultValue; 
    return value.equals("true");
  }
  
  public static void setBoolean(String key, boolean value) {
    instance.props.setProperty(key, value ? "true" : "false");
    save();
  }
  
  public static String get(String key, String defaultValue) {
    String value = instance.props.getProperty(key);
    if (value == null)
      return defaultValue; 
    return value;
  }
  
  public static void set(String key, String value) {
    if (value.equals(get(key, null)))
      return; 
    instance.props.setProperty(key, value);
    save();
  }
  
  private static void save() {
    try {
      File f = new File(System.getProperty("user.home"), "JavaCPC");
      f.mkdir();
      if (System.getSecurityManager() != null)
        System.getSecurityManager().checkWrite(file.getAbsolutePath()); 
      FileOutputStream fos = new FileOutputStream(file);
      instance.props.storeToXML(fos, "[Desktop - Settings]");
      fos.close();
    } catch (Throwable t) {
      System.out.println("can't save user settings (" + t.getMessage() + ")");
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\jemu\settings\DSettings.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */