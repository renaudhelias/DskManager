package com.jcraft.jorbis;

class InfoFloor0 {
  int order;
  
  int rate;
  
  int barkmap;
  
  int ampbits;
  
  int ampdB;
  
  int numbooks;
  
  int[] books = new int[16];
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\jcraft\jorbis\InfoFloor0.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */