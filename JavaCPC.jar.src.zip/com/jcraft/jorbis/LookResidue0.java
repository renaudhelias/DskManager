package com.jcraft.jorbis;

class LookResidue0 {
  InfoResidue0 info;
  
  int map;
  
  int parts;
  
  int stages;
  
  CodeBook[] fullbooks;
  
  CodeBook phrasebook;
  
  int[][] partbooks;
  
  int partvals;
  
  int[][] decodemap;
  
  int postbits;
  
  int phrasebits;
  
  int frames;
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\jcraft\jorbis\LookResidue0.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */