package com.jcraft.jorbis;

class LookFloor1 {
  static final int VIF_POSIT = 63;
  
  int[] sorted_index = new int[65];
  
  int[] forward_index = new int[65];
  
  int[] reverse_index = new int[65];
  
  int[] hineighbor = new int[63];
  
  int[] loneighbor = new int[63];
  
  int posts;
  
  int n;
  
  int quant_q;
  
  InfoFloor1 vi;
  
  int phrasebits;
  
  int postbits;
  
  int frames;
  
  void free() {
    this.sorted_index = null;
    this.forward_index = null;
    this.reverse_index = null;
    this.hineighbor = null;
    this.loneighbor = null;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\jcraft\jorbis\LookFloor1.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */