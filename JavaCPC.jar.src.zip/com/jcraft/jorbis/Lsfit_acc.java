package com.jcraft.jorbis;

class Lsfit_acc {
  long x0;
  
  long x1;
  
  long xa;
  
  long ya;
  
  long x2a;
  
  long y2a;
  
  long xya;
  
  long n;
  
  long an;
  
  long un;
  
  long edgey0;
  
  long edgey1;
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\jcraft\jorbis\Lsfit_acc.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */