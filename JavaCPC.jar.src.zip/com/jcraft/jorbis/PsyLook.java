package com.jcraft.jorbis;

class PsyLook {
  int n;
  
  PsyInfo vi;
  
  float[][][] tonecurves;
  
  float[][] peakatt;
  
  float[][][] noisecurves;
  
  float[] ath;
  
  int[] octave;
  
  void init(PsyInfo vi, int n, int rate) {}
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\jcraft\jorbis\PsyLook.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */