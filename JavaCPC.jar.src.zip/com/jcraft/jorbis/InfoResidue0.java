package com.jcraft.jorbis;

class InfoResidue0 {
  int begin;
  
  int end;
  
  int grouping;
  
  int partitions;
  
  int groupbook;
  
  int[] secondstages = new int[64];
  
  int[] booklist = new int[256];
  
  float[] entmax = new float[64];
  
  float[] ampmax = new float[64];
  
  int[] subgrp = new int[64];
  
  int[] blimit = new int[64];
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\jcraft\jorbis\InfoResidue0.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */