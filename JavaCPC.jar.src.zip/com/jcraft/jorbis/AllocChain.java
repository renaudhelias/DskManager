package com.jcraft.jorbis;

class AllocChain {
  Object ptr;
  
  AllocChain next;
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\jcraft\jorbis\AllocChain.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */