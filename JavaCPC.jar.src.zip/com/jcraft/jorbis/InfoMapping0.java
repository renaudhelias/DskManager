package com.jcraft.jorbis;

class InfoMapping0 {
  int submaps;
  
  int[] chmuxlist = new int[256];
  
  int[] timesubmap = new int[16];
  
  int[] floorsubmap = new int[16];
  
  int[] residuesubmap = new int[16];
  
  int[] psysubmap = new int[16];
  
  int coupling_steps;
  
  int[] coupling_mag = new int[256];
  
  int[] coupling_ang = new int[256];
  
  void free() {
    this.chmuxlist = null;
    this.timesubmap = null;
    this.floorsubmap = null;
    this.residuesubmap = null;
    this.psysubmap = null;
    this.coupling_mag = null;
    this.coupling_ang = null;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\jcraft\jorbis\InfoMapping0.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */