package com.jcraft.jorbis;

class DecodeAux {
  int[] tab;
  
  int[] tabl;
  
  int tabn;
  
  int[] ptr0;
  
  int[] ptr1;
  
  int aux;
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\jcraft\jorbis\DecodeAux.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */