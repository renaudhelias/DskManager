package com.jcraft.jorbis;

class LookMapping0 {
  InfoMode mode;
  
  InfoMapping0 map;
  
  Object[] time_look;
  
  Object[] floor_look;
  
  Object[] floor_state;
  
  Object[] residue_look;
  
  PsyLook[] psy_look;
  
  FuncTime[] time_func;
  
  FuncFloor[] floor_func;
  
  FuncResidue[] residue_func;
  
  int ch;
  
  float[][] decay;
  
  int lastframe;
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\jcraft\jorbis\LookMapping0.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */