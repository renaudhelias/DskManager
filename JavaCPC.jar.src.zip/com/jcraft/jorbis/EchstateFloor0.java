package com.jcraft.jorbis;

class EchstateFloor0 {
  int[] codewords;
  
  float[] curve;
  
  long frameno;
  
  long codes;
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\jcraft\jorbis\EchstateFloor0.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */