package com.dreamfabric.jac64;

import java.io.InputStream;
import java.net.URL;

public class SELoader extends Loader {
  String codebase = null;
  
  public SELoader() {}
  
  public SELoader(String codebase) {
    this.codebase = codebase;
  }
  
  public InputStream getResourceStream(String resource) {
    try {
      URL url = getClass().getResource(resource);
      System.out.println("URL: " + url);
      System.out.println("Read ROM " + resource);
      if (url == null)
        url = new URL(this.codebase + resource); 
      return url.openConnection().getInputStream();
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\SELoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */