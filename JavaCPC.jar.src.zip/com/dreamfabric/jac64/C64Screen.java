package com.dreamfabric.jac64;

import java.applet.AudioClip;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.awt.image.MemoryImageSource;
import javax.swing.JPanel;

public class C64Screen extends ExtChip implements Observer, MouseListener, MouseMotionListener {
  public static final String version = "1.11";
  
  public static final int SERIAL_ATN = 8;
  
  public static final int SERIAL_CLK_OUT = 16;
  
  public static final int SERIAL_DATA_OUT = 32;
  
  public static final int SERIAL_CLK_IN = 64;
  
  public static final int SERIAL_DATA_IN = 128;
  
  public static final int RESID_6581 = 1;
  
  public static final int RESID_8580 = 2;
  
  public static final int JACSID = 3;
  
  public static final boolean IRQDEBUG = false;
  
  public static final boolean SPRITEDEBUG = false;
  
  public static final boolean IODEBUG = false;
  
  public static final boolean VIC_MEM_DEBUG = false;
  
  public static final boolean BAD_LINE_DEBUG = false;
  
  public static final boolean STATE_DEBUG = false;
  
  public static final boolean DEBUG_IEC = false;
  
  public static final boolean DEBUG_CYCLES = false;
  
  public static final int IO_UPDATE = 37;
  
  private static final int VIC_IRQ = 1;
  
  public static final int CYCLES_PER_LINE = 63;
  
  public static final int IO_OFFSET = 12288;
  
  public static final boolean SOUND_AVAIABLE = true;
  
  public static final Color TRANSPARENT_BLACK = new Color(0, 0, 64, 64);
  
  public static final Color DARKER_0 = new Color(0, 0, 64, 32);
  
  public static final Color LIGHTER_0 = new Color(224, 224, 255, 48);
  
  public static final Color DARKER_N = new Color(0, 0, 64, 112);
  
  public static final Color LIGHTER_N = new Color(224, 224, 255, 160);
  
  public static final Color LED_ON = new Color(96, 223, 96, 192);
  
  public static final Color LED_OFF = new Color(32, 96, 32, 192);
  
  public static final Color LED_BORDER = new Color(64, 96, 64, 160);
  
  public static final int LABEL_COUNT = 32;
  
  private Color[] darks = new Color[32];
  
  private Color[] lites = new Color[32];
  
  private int colIndex = 0;
  
  private static final int SC_WIDTH = 384;
  
  private static final int SC_HEIGHT = 284;
  
  private final int SC_XOFFS = 32;
  
  private final int SC_SPXOFFS = 8;
  
  private final int FIRST_VISIBLE_VBEAM = 15;
  
  private final int SC_SPYOFFS = 16;
  
  private IMonitor monitor;
  
  private int targetScanTime = 20000;
  
  private int actualScanTime = 20000;
  
  private long lastScan = 0L;
  
  private long nextIOUpdate = 0L;
  
  private boolean DOUBLE = false;
  
  private int reset = 100;
  
  private C64Canvas canvas;
  
  private int[] memory;
  
  private Keyboard keyboard;
  
  ExtChip sidChip;
  
  CIA[] cia;
  
  C1541Chips c1541Chips;
  
  TFE_CS8900 tfe;
  
  int iecLines = 0;
  
  int cia2PRA = 0;
  
  int cia2DDRA = 0;
  
  AudioClip trackSound = null;
  
  AudioClip motorSound = null;
  
  private int lastTrack = 0;
  
  private int lastSector = 0;
  
  private boolean ledOn = false;
  
  private boolean motorOn = false;
  
  boolean emulateDisk = false;
  
  private int[] cbmcolor = VICConstants.COLOR_SETS[0];
  
  public int vicBank;
  
  public int charSet;
  
  public int videoMatrix;
  
  public int videoMode;
  
  int irqMask = 0;
  
  int irqFlags = 0;
  
  int control1 = 0;
  
  int control2 = 0;
  
  int sprXMSB = 0;
  
  int sprEN = 0;
  
  int sprYEX = 0;
  
  int sprXEX = 0;
  
  int sprPri = 0;
  
  int sprMul = 0;
  
  int sprCol = 0;
  
  int sprBgCol = 0;
  
  int sprMC0 = 0;
  
  int sprMC1 = 0;
  
  int vicMem = 0;
  
  int vicMemDDRA = 0;
  
  int vicMemDATA = 0;
  
  public int vbeam = 0;
  
  public int raster = 0;
  
  int bCol = 0;
  
  int[] bgCol = new int[4];
  
  private int vicBase = 0;
  
  private boolean badLine = false;
  
  private int spr0BlockSel;
  
  int vc = 0;
  
  int vcBase = 0;
  
  int rc = 0;
  
  int vmli = 0;
  
  int vPos = 0;
  
  int mpos = 0;
  
  int displayWidth = 384;
  
  int displayHeight = 284;
  
  int offsetX = 0;
  
  int offsetY = 0;
  
  boolean gfxVisible = false;
  
  boolean paintBorder = false;
  
  boolean paintSideBorder = false;
  
  int borderColor = this.cbmcolor[0];
  
  int bgColor = this.cbmcolor[1];
  
  private boolean extended = false;
  
  private boolean multiCol = false;
  
  private boolean blankRow = false;
  
  private boolean hideColumn = false;
  
  int[] multiColor = new int[4];
  
  int[] collissionMask = new int[432];
  
  Sprite[] sprites = new Sprite[8];
  
  private Color[] colors = null;
  
  private int horizScroll = 0;
  
  private int vScroll = 0;
  
  private Image image;
  
  private Graphics g2;
  
  private int charMemoryIndex = 0;
  
  private int[] vicCharCache = new int[40];
  
  private int[] vicColCache = new int[40];
  
  public Image screen = null;
  
  private MemoryImageSource mis = null;
  
  private AudioDriver audioDriver;
  
  int[] mem = new int[112896];
  
  int rnd = 754;
  
  String message;
  
  String tmsg = "";
  
  int frame = 0;
  
  private boolean updating = false;
  
  boolean displayEnabled = true;
  
  boolean irqTriggered = false;
  
  long lastLine = 0L;
  
  long firstLine = 0L;
  
  long lastIRQ = 0L;
  
  int potx = 0;
  
  int poty = 0;
  
  boolean button1 = false;
  
  boolean button2 = false;
  
  public void setAutoscale(boolean val) {
    this.DOUBLE = val;
    this.canvas.setAutoscale(val);
  }
  
  private void makeColors(Color[] colors, Color c1, Color c2) {
    int a0 = c1.getAlpha();
    int r0 = c1.getRed();
    int g0 = c1.getGreen();
    int b0 = c1.getBlue();
    int an = c2.getAlpha();
    int rn = c2.getRed();
    int gn = c2.getGreen();
    int bn = c2.getBlue();
    int lc = 16;
    for (int i = 0, n = lc; i < n; i++) {
      colors[32 - i - 1] = new Color(((lc - i) * r0 + i * rn) / lc, ((lc - i) * g0 + i * gn) / lc, ((lc - i) * b0 + i * bn) / lc, ((lc - i) * a0 + i * an) / lc);
      colors[i] = new Color(((lc - i) * r0 + i * rn) / lc, ((lc - i) * g0 + i * gn) / lc, ((lc - i) * b0 + i * bn) / lc, ((lc - i) * a0 + i * an) / lc);
    } 
  }
  
  public void setColorSet(int c) {
    if (c >= 0 && c < VICConstants.COLOR_SETS.length) {
      this.cbmcolor = VICConstants.COLOR_SETS[c];
      this.borderColor = this.cbmcolor[this.bCol];
      this.bgColor = this.cbmcolor[this.bgCol[0]];
      for (int i = 0, n = 8; i < n; i++) {
        (this.sprites[i]).color[0] = this.bgColor;
        (this.sprites[i]).color[1] = this.cbmcolor[this.sprMC0];
        (this.sprites[i]).color[3] = this.cbmcolor[this.sprMC1];
      } 
    } 
  }
  
  public CIA[] getCIAs() {
    return this.cia;
  }
  
  public void setSID(int sid) {
    switch (sid) {
      case 1:
      case 2:
        if (!(this.sidChip instanceof RESIDChip)) {
          if (this.sidChip != null)
            this.sidChip.stop(); 
          this.sidChip = new RESIDChip(this.cpu, this.audioDriver);
        } 
        ((RESIDChip)this.sidChip).setChipVersion(sid);
        break;
      case 3:
        if (!(this.sidChip instanceof SIDChip)) {
          if (this.sidChip != null)
            this.sidChip.stop(); 
          this.sidChip = new SIDChip(this.cpu, this.audioDriver);
        } 
        break;
    } 
  }
  
  public void setScanRate(double hertz) {
    this.targetScanTime = (int)(1000000.0D / hertz);
    float diff = 0.9692308F;
  }
  
  public int getScanRate() {
    return 1000000 / this.targetScanTime;
  }
  
  public int getActualScanRate() {
    return 1000000 / this.actualScanTime;
  }
  
  public void setIntegerScaling(boolean yes) {
    this.canvas.setIntegerScaling(yes);
  }
  
  public JPanel getScreen() {
    return this.canvas;
  }
  
  public AudioDriver getAudioDriver() {
    return this.audioDriver;
  }
  
  public boolean ready() {
    return this.keyboard.ready;
  }
  
  public void setDisplayFactor(double f) {
    this.displayWidth = (int)(384.0D * f);
    this.displayHeight = (int)(284.0D * f);
    this.crtImage = null;
  }
  
  public void setDisplayOffset(int x, int y) {
    this.offsetX = x;
    this.offsetY = y;
  }
  
  public void dumpGfxStat() {
    this.monitor.info("Char MemoryIndex: 0x" + 
        Integer.toString(this.charMemoryIndex, 16));
    this.monitor.info("CharSet adr: 0x" + 
        Integer.toString(this.charSet, 16));
    this.monitor.info("VideoMode: " + this.videoMode);
    this.monitor.info("Vic Bank: 0x" + 
        Integer.toString(this.vicBank, 16));
    this.monitor.info("Video Matrix: 0x" + 
        Integer.toString(this.videoMatrix, 16));
    this.monitor.info("Text: extended = " + this.extended + " multicol = " + this.multiCol);
    this.monitor.info("24 Rows on? " + (((this.control1 & 0x8) == 0) ? "yes" : "no"));
    this.monitor.info("YScroll = " + (this.control1 & 0x7));
    this.monitor.info("$d011 = " + this.control1);
    this.monitor.info("IRQ Latch: " + 
        Integer.toString(this.irqFlags, 16));
    this.monitor.info("IRQ  Mask: " + 
        Integer.toString(this.irqMask, 16));
    this.monitor.info("IRQ RPos : " + this.raster);
    for (int i = 0, n = 8; i < n; i++)
      this.monitor.info("Sprite " + (i + 1) + " pos = " + (this.sprites[i]).x + ", " + (this.sprites[i]).y); 
    this.monitor.info("IRQFlags: " + getIRQFlags());
    this.monitor.info("NMIFlags: " + getNMIFlags());
    this.monitor.info("CPU IRQLow: " + this.cpu.getIRQLow());
    this.monitor.info("CPU NMILow: " + this.cpu.NMILow);
    this.monitor.info("Current CPU cycles: " + this.cpu.cycles);
    this.monitor.info("Next IO update: " + this.nextIOUpdate);
  }
  
  public void setSoundOn(boolean on) {
    this.audioDriver.setSoundOn(on);
  }
  
  public void setStick(boolean one) {
    this.keyboard.setStick(one);
  }
  
  public void registerHotKey(int key, int mod, String script, Object o) {
    this.keyboard.registerHotKey(key, mod, script, o);
  }
  
  public void setKeyboardEmulation(boolean extended) {
    this.monitor.info("Keyboard extended: " + extended);
    this.keyboard.stickExits = !extended;
    this.keyboard.extendedKeyboardEmulation = extended;
  }
  
  public void init(CPU cpu) {
    init(cpu);
    this.memory = cpu.getMemory();
    this.c1541Chips = (cpu.getDrive()).chips;
    this.c1541Chips.initIEC2(this);
    this.c1541Chips = (cpu.getDrive()).chips;
    this.c1541Chips.setObserver(this);
    int i, n;
    for (i = 0, n = this.sprites.length; i < n; i++) {
      this.sprites[i] = new Sprite();
      (this.sprites[i]).spriteNo = i;
    } 
    this.cia = new CIA[2];
    this.cia[0] = new CIA(cpu, 68608, this);
    this.cia[1] = new CIA(cpu, 68864, this);
    this.tfe = new TFE_CS8900(69120);
    this.keyboard = new Keyboard(this, this.cia[0], this.memory);
    this.canvas = new C64Canvas(this, this.DOUBLE, this.keyboard);
    this.canvas.addMouseMotionListener(this);
    this.canvas.addMouseListener(this);
    this.audioDriver = new AudioDriverSE();
    this.audioDriver.init(44000, 22000);
    setSID(1);
    this.charMemoryIndex = 118784;
    for (i = 0; i < 109056; i++)
      this.mem[i] = this.cbmcolor[6]; 
    this.mis = new MemoryImageSource(384, 284, this.mem, 0, 384);
    this.mis.setAnimated(true);
    this.mis.setFullBufferUpdates(true);
    this.screen = this.canvas.createImage(this.mis);
    initUpdate();
  }
  
  public void update(Object src, Object data) {
    if (src != this.c1541Chips) {
      this.message = (String)data;
    } else {
      updateDisk(src, data);
    } 
  }
  
  void restoreKey(boolean down) {
    if (down) {
      setNMI(1);
    } else {
      clearNMI(1);
    } 
  }
  
  private static final int[] IO_ADDRAND = new int[] { 
      53311, 53311, 53311, 53311, 54303, 54303, 54303, 54303, 55551, 55807, 
      56063, 56319, 56335, 56591, 57087, 57343 };
  
  private int borderState;
  
  private boolean notVisible;
  
  private int xPos;
  
  private long lastCycle;
  
  public static final int IMG_TOTWIDTH = 384;
  
  public static final int IMG_TOTHEIGHT = 284;
  
  public Image crtImage;
  
  long repaint;
  
  public int performRead(int address, long cycles) {
    int pos = address >> 8 & 0xF;
    address &= IO_ADDRAND[pos];
    int val = 0;
    switch (address) {
      case 53248:
      case 53250:
      case 53252:
      case 53254:
      case 53256:
      case 53258:
      case 53260:
      case 53262:
        return (this.sprites[address - 53248 >> 1]).x & 0xFF;
      case 53249:
      case 53251:
      case 53253:
      case 53255:
      case 53257:
      case 53259:
      case 53261:
      case 53263:
        return (this.sprites[address - 53248 >> 1]).y;
      case 53264:
        return this.sprXMSB;
      case 53265:
        return this.control1 & 0x7F | (this.vbeam & 0x100) >> 1;
      case 53266:
        return this.vbeam & 0xFF;
      case 53267:
      case 53268:
        return 0;
      case 53269:
        return this.sprEN;
      case 53270:
        return this.control2;
      case 53271:
        return this.sprYEX;
      case 53272:
        return this.vicMem;
      case 53273:
        return this.irqFlags;
      case 53274:
        return this.irqMask;
      case 53275:
        return this.sprPri;
      case 53276:
        return this.sprMul;
      case 53277:
        return this.sprXEX;
      case 53278:
        val = this.sprCol;
        this.sprCol = 0;
        return val;
      case 53279:
        val = this.sprBgCol;
        this.sprBgCol = 0;
        return val;
      case 53280:
        return this.bCol | 0xF0;
      case 53281:
      case 53282:
      case 53283:
      case 53284:
        return this.bgCol[address - 53281] | 0xF0;
      case 53285:
        return this.sprMC0 | 0xF0;
      case 53286:
        return this.sprMC1 | 0xF0;
      case 53287:
      case 53288:
      case 53289:
      case 53290:
      case 53291:
      case 53292:
      case 53293:
      case 53294:
        return (this.sprites[address - 53287]).col | 0xF0;
      case 54299:
      case 54300:
        return this.sidChip.performRead(12288 + address, cycles);
      case 54297:
        return this.potx;
      case 54298:
        return this.poty;
      case 56320:
        return this.keyboard.readDC00(this.cpu.lastReadOP);
      case 56321:
        return this.keyboard.readDC01(this.cpu.lastReadOP);
      case 56576:
        val = (this.cia2PRA | this.cia2DDRA ^ 0xFFFFFFFF) & 0x3F | this.iecLines & this.c1541Chips.iecLines;
        val &= 0xFF;
        return val;
    } 
    if (pos == 4)
      return this.sidChip.performRead(address + 12288, cycles); 
    if (pos == 13)
      return this.cia[1].performRead(address + 12288, cycles); 
    if (pos == 12)
      return this.cia[0].performRead(address + 12288, cycles); 
    if (pos == 14)
      return this.tfe.performRead(address + 12288, cycles); 
    if (pos >= 8)
      return this.memory[12288 + address] | 0xF0; 
    return 255;
  }
  
  public void performWrite(int address, int data, long cycles) {
    int sprite, j, latchval, i, oldLines, m, n, k, pos = address >> 8 & 0xF;
    address &= IO_ADDRAND[pos];
    this.memory[address + 12288] = data;
    switch (address) {
      case 53248:
      case 53250:
      case 53252:
      case 53254:
      case 53256:
      case 53258:
      case 53260:
      case 53262:
        sprite = address - 53248 >> 1;
        (this.sprites[sprite]).x &= 0x100;
        (this.sprites[sprite]).x += data;
      case 53249:
      case 53251:
      case 53253:
      case 53255:
      case 53257:
      case 53259:
      case 53261:
      case 53263:
        (this.sprites[address - 53248 >> 1]).y = data;
      case 53264:
        this.sprXMSB = data;
        for (j = 0, m = 1, k = 8; j < k; j++, m <<= 1) {
          (this.sprites[j]).x &= 0xFF;
          (this.sprites[j]).x |= ((data & m) != 0) ? 256 : 0;
        } 
      case 53265:
        this.raster = this.raster & 0xFF | data << 1 & 0x100;
        this.control1 = data;
        if (this.vScroll != (data & 0x7)) {
          this.vScroll = data & 0x7;
          boolean oldBadLine = this.badLine;
          this.badLine = (this.displayEnabled && this.vbeam >= 48 && this.vbeam <= 247 && (this.vbeam & 0x7) == this.vScroll);
        } 
        this.extended = ((data & 0x40) != 0);
        this.blankRow = ((data & 0x8) == 0);
        this.videoMode = (this.extended ? 2 : 0) | (this.multiCol ? 1 : 0) | (((data & 0x20) != 0) ? 4 : 0);
      case 53266:
        this.raster = this.raster & 0x100 | data;
      case 53267:
      case 53268:
        return;
      case 53269:
        this.sprEN = data;
        for (j = 0, m = 1, k = 8; j < k; j++, m <<= 1)
          (this.sprites[j]).enabled = ((data & m) != 0); 
      case 53270:
        this.control2 = data;
        this.horizScroll = data & 0x7;
        this.multiCol = ((data & 0x10) != 0);
        this.hideColumn = ((data & 0x8) == 0);
        this.videoMode = (this.extended ? 2 : 0) | (this.multiCol ? 1 : 0) | (((this.control1 & 0x20) != 0) ? 4 : 0);
      case 53271:
        this.sprYEX = data;
        for (j = 0, m = 1, k = 8; j < k; j++, m <<= 1)
          (this.sprites[j]).expandY = ((data & m) != 0); 
      case 53272:
        this.vicMem = data;
        setVideoMem();
      case 53273:
        if ((data & 0x80) != 0)
          data = 255; 
        latchval = 0xFF ^ data;
        this.irqFlags &= latchval;
        if ((this.irqMask & 0xF & this.irqFlags) == 0)
          clearIRQ(1); 
      case 53274:
        this.irqMask = data;
        if ((this.irqMask & 0xF & this.irqFlags) != 0) {
          this.irqFlags |= 0x80;
          setIRQ(1);
        } else {
          clearIRQ(1);
        } 
      case 53275:
        this.sprPri = data;
        for (i = 0, m = 1, k = 8; i < k; i++, m <<= 1)
          (this.sprites[i]).priority = ((data & m) != 0); 
      case 53276:
        this.sprMul = data;
        for (i = 0, m = 1, k = 8; i < k; i++, m <<= 1)
          (this.sprites[i]).multicolor = ((data & m) != 0); 
      case 53277:
        this.sprXEX = data;
        for (i = 0, m = 1, k = 8; i < k; i++, m <<= 1)
          (this.sprites[i]).expandX = ((data & m) != 0); 
      case 53280:
        this.borderColor = this.cbmcolor[this.bCol = data & 0xF];
      case 53281:
        this.bgCol[0] = data & 0xF;
        this.bgColor = this.cbmcolor[data & 0xF];
        for (i = 0, n = 8; i < n; i++)
          (this.sprites[i]).color[0] = this.bgColor; 
      case 53282:
      case 53283:
      case 53284:
        this.bgCol[address - 53281] = data & 0xF;
      case 53285:
        this.sprMC0 = data & 0xF;
        for (i = 0, n = 8; i < n; i++)
          (this.sprites[i]).color[1] = this.cbmcolor[this.sprMC0]; 
      case 53286:
        this.sprMC1 = data & 0xF;
        for (i = 0, n = 8; i < n; i++)
          (this.sprites[i]).color[3] = this.cbmcolor[this.sprMC1]; 
      case 53287:
      case 53288:
      case 53289:
      case 53290:
      case 53291:
      case 53292:
      case 53293:
      case 53294:
        (this.sprites[address - 53287]).color[2] = this.cbmcolor[data & 0xF];
        (this.sprites[address - 53287]).col = data & 0xF;
      case 56320:
      case 56321:
      case 56322:
      case 56323:
        this.cia[0].performWrite(address + 12288, data, this.cpu.cycles);
        this.keyboard.updateKeyboard();
      case 56576:
        this.cia[1].performWrite(address + 12288, data, this.cpu.cycles);
        this.cia2PRA = data;
        data = (this.cia2PRA ^ 0xFFFFFFFF) & this.cia2DDRA;
        oldLines = this.iecLines;
        this.iecLines = data << 2 & 0x80 | data << 2 & 0x40 | data << 1 & 0x10;
        if (((oldLines ^ this.iecLines) & 0x10) != 0)
          this.c1541Chips.atnChanged(((this.iecLines & 0x10) == 0)); 
        this.c1541Chips.updateIECLines();
        setVideoMem();
      case 56578:
        this.cia2DDRA = data;
        this.cia[1].performWrite(address + 12288, data, this.cpu.cycles);
        setVideoMem();
    } 
    if (pos == 4)
      this.sidChip.performWrite(address + 12288, data, cycles); 
    if (pos == 13)
      this.cia[1].performWrite(address + 12288, data, cycles); 
    if (pos == 12)
      this.cia[0].performWrite(address + 12288, data, cycles); 
    if (pos == 14)
      this.tfe.performWrite(address + 12288, data, cycles); 
  }
  
  private void printIECLines() {
    System.out.print("IEC/F: ");
    if ((this.iecLines & 0x10) == 0) {
      System.out.print("A1");
    } else {
      System.out.print("A0");
    } 
    int sdata = ((this.iecLines & 0x40) == 0) ? 1 : 0;
    System.out.print(" C" + sdata);
    sdata = ((this.iecLines & 0x80) == 0) ? 1 : 0;
    System.out.print(" D" + sdata);
    sdata = ((this.c1541Chips.iecLines & 0x40) == 0) ? 1 : 0;
    System.out.print(" c" + sdata);
    sdata = ((this.c1541Chips.iecLines & 0x80) == 0) ? 1 : 0;
    System.out.print(" d" + sdata);
    System.out.println(" => C" + (((this.iecLines & this.c1541Chips.iecLines & 0x80) == 0) ? 1 : 0) + " D" + (((this.iecLines & this.c1541Chips.iecLines & 0x40) == 0) ? 1 : 0));
  }
  
  private void setVideoMem() {
    this.vicBank = (((this.cia2DDRA ^ 0xFFFFFFFF | this.cia2PRA) ^ 0xFFFFFFFF) & 0x3) << 14;
    this.charSet = this.vicBank | (this.vicMem & 0xE) << 10;
    this.videoMatrix = this.vicBank | (this.vicMem & 0xF0) << 6;
    this.vicBase = this.vicBank | (this.vicMem & 0x8) << 10;
    this.spr0BlockSel = 1016 + this.videoMatrix;
    if ((this.vicMem & 0xC) != 4 || (this.vicBank & 0x4000) == 16384) {
      this.charMemoryIndex = this.charSet;
    } else {
      this.charMemoryIndex = (((this.vicMem & 0x2) == 0) ? 0 : 2048) + 118784;
    } 
  }
  
  private void initUpdate() {
    this.vc = 0;
    this.vcBase = 0;
    this.vmli = 0;
    this.updating = true;
    int i;
    for (i = 0; i < 8; i++) {
      (this.sprites[i]).nextByte = 0;
      (this.sprites[i]).painting = false;
      (this.sprites[i]).spriteReg = 0;
    } 
    if (this.colors == null) {
      this.colors = new Color[16];
      for (i = 0; i < 16; i++)
        this.colors[i] = new Color(this.cbmcolor[i]); 
    } 
    this.canvas.setBackground(this.colors[this.memory[65568] & 0xF]);
  }
  
  public C64Screen(IMonitor m, boolean dob) {
    this.borderState = 0;
    this.notVisible = false;
    this.xPos = 0;
    this.lastCycle = 0L;
    this.repaint = 0L;
    this.monitor = m;
    this.DOUBLE = dob;
    setScanRate(50.0D);
    makeColors(this.darks, DARKER_0, DARKER_N);
    makeColors(this.lites, LIGHTER_0, LIGHTER_N);
  }
  
  public final void clock(long cycles) {
    int irqComp, i, mult, n, ypos, k;
    if (this.lastCycle + 1L < cycles)
      System.out.println("More than one cycle passed: " + (cycles - this.lastCycle) + " at " + cycles + " PC: " + Integer.toHexString(this.cpu.pc)); 
    if (this.lastCycle == cycles)
      System.out.println("No diff since last update!!!: " + (cycles - this.lastCycle) + " at " + cycles + " PC: " + Integer.toHexString(this.cpu.pc)); 
    this.lastCycle = cycles;
    int vicCycle = (int)(cycles - this.lastLine);
    if (this.notVisible && vicCycle < 62)
      return; 
    if (this.badLine)
      this.gfxVisible = true; 
    switch (vicCycle) {
      case 0:
        this.vbeam = (this.vbeam + 1) % 312;
        if (this.vbeam == 0)
          this.frame++; 
        this.vPos = this.vbeam - 16;
        if (this.vbeam == 15) {
          this.colIndex++;
          if (this.colIndex >= 32)
            this.colIndex = 0; 
          initUpdate();
        } 
        if ((this.irqMask & 0x2) != 0 && this.sprBgCol != 0 && (this.irqFlags & 0x2) == 0) {
          this.irqFlags |= 0x52;
          setIRQ(1);
        } 
        if ((this.irqMask & 0x4) != 0 && this.sprCol != 0 && (this.irqFlags & 0x4) == 0) {
          this.irqFlags |= 0x54;
          setIRQ(1);
        } 
        irqComp = this.raster;
        if (irqComp > 312)
          irqComp &= 0xFF; 
        if ((this.irqFlags & 0x1) == 0 && irqComp == this.vbeam) {
          this.irqFlags |= 0x1;
          if ((this.irqMask & 0x1) != 0) {
            this.irqFlags |= 0x80;
            this.irqTriggered = true;
            setIRQ(1);
            this.lastIRQ = this.cpu.cycles;
          } 
        } else {
          this.irqTriggered = false;
        } 
        this.notVisible = false;
        if (this.vPos < 0 || this.vPos >= 284) {
          this.cpu.baLowUntil = 0L;
          this.notVisible = true;
        } else {
          if (this.vbeam == 48) {
            this.displayEnabled = ((this.control1 & 0x10) != 0);
            if (this.displayEnabled) {
              this.borderState &= 0xFFFFFFFB;
            } else {
              this.borderState |= 0x4;
            } 
          } 
          this.badLine = (this.displayEnabled && this.vbeam >= 48 && this.vbeam <= 247 && (this.vbeam & 0x7) == this.vScroll);
          for (int m = 0, i1 = 384; m < i1; m++)
            this.collissionMask[m] = 0; 
        } 
      case 1:
        if ((this.sprites[3]).dma)
          this.sprites[3].readSpriteData(); 
        if ((this.sprites[5]).dma)
          this.cpu.baLowUntil = this.lastLine + 6L; 
      case 2:
        return;
      case 3:
        if ((this.sprites[4]).dma)
          this.sprites[4].readSpriteData(); 
        if ((this.sprites[6]).dma)
          this.cpu.baLowUntil = this.lastLine + 8L; 
      case 4:
        return;
      case 5:
        if ((this.sprites[5]).dma)
          this.sprites[5].readSpriteData(); 
        if ((this.sprites[7]).dma)
          this.cpu.baLowUntil = this.lastLine + 10L; 
      case 6:
        return;
      case 7:
        if ((this.sprites[6]).dma)
          this.sprites[6].readSpriteData(); 
      case 8:
        return;
      case 9:
        if ((this.sprites[7]).dma)
          this.sprites[7].readSpriteData(); 
        if (this.blankRow) {
          if (this.vbeam == 247)
            this.borderState |= 0x1; 
        } else {
          if (this.vbeam == 251)
            this.borderState |= 0x1; 
          if (this.vbeam == 51) {
            this.borderState &= 0xFE;
            for (int m = 0, i1 = 7; m < i1; m++) {
              if (!(this.sprites[m]).painting)
                (this.sprites[m]).lineFinished = true; 
            } 
          } 
        } 
        if (this.vbeam == 55) {
          this.borderState &= 0xFE;
          for (int m = 0, i1 = 7; m < i1; m++) {
            if (!(this.sprites[m]).painting)
              (this.sprites[m]).lineFinished = true; 
          } 
        } 
      case 10:
        return;
      case 11:
        if (this.badLine)
          this.cpu.baLowUntil = this.lastLine + 54L; 
      case 12:
        this.mpos = this.vPos * 384;
        drawBackground();
        this.xPos = 16;
        this.mpos += 8;
      case 13:
        drawBackground();
        drawSprites();
        this.mpos += 8;
        this.vc = this.vcBase;
        this.vmli = 0;
        if (this.badLine) {
          this.cpu.baLowUntil = this.lastLine + 54L;
          this.rc = 0;
        } 
      case 14:
        drawBackground();
        drawSprites();
        this.mpos += 8;
        if (this.badLine)
          this.cpu.baLowUntil = this.lastLine + 54L; 
      case 15:
        drawBackground();
        drawSprites();
        this.mpos += 8;
        if (this.badLine)
          this.cpu.baLowUntil = this.lastLine + 54L; 
        for (i = 0, n = 8; i < n; i++) {
          if ((this.sprites[i]).nextByte == 63)
            (this.sprites[i]).dma = false; 
        } 
      case 16:
        if (!this.hideColumn)
          this.borderState &= 0xFD; 
        if (this.badLine) {
          this.cpu.baLowUntil = this.lastLine + 54L;
          this.vicCharCache[this.vmli] = this.memory[this.videoMatrix + (this.vcBase & 0x3FF)];
          this.vicColCache[this.vmli] = this.memory[67584 + (this.vcBase & 0x3FF)];
        } 
        drawGraphics(this.mpos + this.horizScroll);
        drawSprites();
        if (this.borderState != 0)
          drawBackground(); 
        this.mpos += 8;
      case 17:
        if (this.hideColumn)
          this.borderState &= 0xFD; 
        if (this.badLine) {
          this.cpu.baLowUntil = this.lastLine + 54L;
          this.vicCharCache[this.vmli] = this.memory[this.videoMatrix + (this.vcBase + this.vmli & 0x3FF)];
          this.vicColCache[this.vmli] = this.memory[67584 + (this.vcBase + this.vmli & 0x3FF)];
        } 
        drawGraphics(this.mpos + this.horizScroll);
        drawSprites();
        this.mpos += 8;
      default:
        if (this.badLine) {
          this.cpu.baLowUntil = this.lastLine + 54L;
          this.vicCharCache[this.vmli] = this.memory[this.videoMatrix + (this.vcBase + this.vmli & 0x3FF)];
          this.vicColCache[this.vmli] = this.memory[67584 + (this.vcBase + this.vmli & 0x3FF)];
        } 
        drawGraphics(this.mpos + this.horizScroll);
        drawSprites();
        this.mpos += 8;
      case 54:
        if (this.badLine) {
          this.cpu.baLowUntil = this.lastLine + 54L;
          this.vicCharCache[this.vmli] = this.memory[this.videoMatrix + (this.vcBase + this.vmli & 0x3FF)];
          this.vicColCache[this.vmli] = this.memory[67584 + (this.vcBase + this.vmli & 0x3FF)];
        } 
        mult = 1;
        ypos = this.vPos + 16;
        for (j = 0, k = 8; j < k; j++) {
          Sprite sprite = this.sprites[j];
          if (sprite.enabled)
            if (sprite.y == (ypos & 0xFF) && ypos < 270) {
              sprite.nextByte = 0;
              sprite.dma = true;
              sprite.expFlipFlop = true;
            }  
          mult <<= 1;
        } 
        if ((this.sprites[0]).dma)
          this.cpu.baLowUntil = this.lastLine + 59L; 
        drawGraphics(this.mpos + this.horizScroll);
        drawSprites();
        this.mpos += 8;
      case 55:
        if (this.hideColumn)
          this.borderState |= 0x2; 
        if (this.badLine) {
          this.cpu.baLowUntil = this.lastLine + 54L;
          this.vicCharCache[this.vmli] = this.memory[this.videoMatrix + (this.vcBase + this.vmli & 0x3FF)];
          this.vicColCache[this.vmli] = this.memory[67584 + (this.vcBase + this.vmli & 0x3FF)];
        } 
        drawGraphics(this.mpos + this.horizScroll);
        drawSprites();
        if (this.borderState != 0)
          drawBackground(); 
        this.mpos += 8;
      case 56:
        if (!this.hideColumn)
          this.borderState |= 0x2; 
        drawBackground();
        drawSprites();
        this.mpos += 8;
        for (j = 0, k = 8; j < k; j++) {
          Sprite sprite = this.sprites[j];
          if (!sprite.dma)
            sprite.painting = false; 
        } 
        if ((this.sprites[1]).dma)
          this.cpu.baLowUntil = this.lastLine + 61L; 
      case 57:
        for (j = 0, k = 8; j < k; j++) {
          Sprite sprite = this.sprites[j];
          if (sprite.dma)
            sprite.painting = true; 
        } 
        drawBackground();
        drawSprites();
        this.mpos += 8;
        if (this.rc == 7) {
          this.vcBase = this.vc;
          this.gfxVisible = false;
        } 
        if (this.badLine || this.gfxVisible) {
          this.rc = this.rc + 1 & 0x7;
          this.gfxVisible = true;
        } 
        if ((this.sprites[0]).painting)
          this.sprites[0].readSpriteData(); 
        if ((this.sprites[2]).dma)
          this.cpu.baLowUntil = this.lastLine + 63L; 
      case 58:
        drawBackground();
        drawSprites();
        this.mpos += 8;
      case 59:
        drawBackground();
        drawSprites();
        this.mpos += 8;
        if ((this.sprites[1]).painting)
          this.sprites[1].readSpriteData(); 
      case 60:
        drawSprites();
      case 61:
        if ((this.sprites[2]).painting)
          this.sprites[2].readSpriteData(); 
        if ((this.sprites[3]).dma)
          this.cpu.baLowUntil = this.lastLine + 65L; 
      case 62:
        break;
    } 
    for (int j = 0; j < this.sprites.length; j++)
      this.sprites[j].reset(); 
    this.lastLine += 63L;
    if (this.updating && this.vPos == 285) {
      this.mis.newPixels();
      this.canvas.repaint();
      this.actualScanTime = (this.actualScanTime * 9 + (int)(this.audioDriver.getMicros() - this.lastScan)) / 10;
      this.lastScan = this.audioDriver.getMicros();
      this.updating = false;
    } 
    this.notVisible = false;
  }
  
  private void drawBackground() {
    int bpos = this.mpos;
    int currentBg = (this.borderState > 0) ? this.borderColor : this.bgColor;
    for (int i = 0; i < 8; i++)
      this.mem[bpos++] = currentBg; 
  }
  
  private final void drawGraphics(int mpos) {
    if (!this.gfxVisible || this.paintBorder || (this.borderState & 0x1) == 1) {
      mpos -= this.horizScroll;
      int color = (this.paintBorder || this.borderState > 0) ? this.borderColor : this.bgColor;
      for (int i = mpos, n = mpos + 8; i < n; i++)
        this.mem[i] = color; 
      this.vmli++;
      return;
    } 
    int collX = (this.vmli << 3) + this.horizScroll + 32;
    if (this.vmli == 0)
      for (int i = mpos - this.horizScroll, n = i + 8; i < n; i++)
        this.mem[i] = this.bgColor;  
    int position = 0, data = 0, penColor = 0, bgcol = this.bgColor;
    if ((this.control1 & 0x20) == 0) {
      if (this.multiCol) {
        this.multiColor[0] = this.bgColor;
        this.multiColor[1] = this.cbmcolor[this.bgCol[1]];
        this.multiColor[2] = this.cbmcolor[this.bgCol[2]];
      } 
      int pcol;
      penColor = this.cbmcolor[pcol = this.vicColCache[this.vmli] & 0xF];
      if (this.extended) {
        position = this.charMemoryIndex + (((data = this.vicCharCache[this.vmli]) & 0x3F) << 3);
        bgcol = this.cbmcolor[this.bgCol[data >> 6]];
      } else {
        position = this.charMemoryIndex + (this.vicCharCache[this.vmli] << 3);
      } 
      data = this.memory[position + this.rc];
      if (this.multiCol && pcol > 7) {
        this.multiColor[3] = this.cbmcolor[pcol & 0x7];
        for (int pix = 0; pix < 8; pix += 2) {
          int tmp = data >> pix & 0x3;
          this.mem[mpos + 7 - pix] = this.multiColor[tmp];
          this.mem[mpos + 6 - pix] = this.multiColor[tmp];
          if (tmp > 1) {
            tmp = 256;
          } else {
            tmp = 0;
          } 
          this.collissionMask[collX + 6 - pix] = tmp;
          this.collissionMask[collX + 7 - pix] = tmp;
        } 
      } else {
        for (int pix = 0; pix < 8; pix++) {
          if ((data & 1 << pix) > 0) {
            this.mem[mpos + 7 - pix] = penColor;
            this.collissionMask[collX + 7 - pix] = 256;
          } else {
            this.mem[mpos + 7 - pix] = bgcol;
            this.collissionMask[collX + 7 - pix] = 0;
          } 
        } 
      } 
      if (this.multiCol && this.extended)
        for (int pix = 0; pix < 8; pix++)
          this.mem[mpos + 7 - pix] = -16777216;  
    } else {
      try {
        position = this.vicBase + (this.vc & 0x3FF) * 8 + this.rc;
        if (this.multiCol)
          this.multiColor[0] = this.bgColor; 
        int vmliData = this.vicCharCache[this.vmli];
        penColor = this.cbmcolor[(vmliData & 0xF0) >> 4];
        bgcol = this.cbmcolor[vmliData & 0xF];
        data = this.memory[position];
        if (this.multiCol) {
          this.multiColor[1] = this.cbmcolor[vmliData >> 4 & 0xF];
          this.multiColor[2] = this.cbmcolor[vmliData & 0xF];
          this.multiColor[3] = this.cbmcolor[this.vicColCache[this.vmli] & 0xF];
          for (int pix = 0; pix < 8; pix += 2) {
            int tmp;
            this.mem[mpos + 7 - pix] = this.multiColor[tmp = data >> pix & 0x3];
            this.mem[mpos + 6 - pix] = this.multiColor[tmp = data >> pix & 0x3];
            if (tmp > 1) {
              tmp = 256;
            } else {
              tmp = 0;
            } 
            this.collissionMask[collX + 6 - pix] = tmp;
            this.collissionMask[collX + 7 - pix] = tmp;
          } 
        } else {
          for (int pix = 0; pix < 8; pix++) {
            if ((data & 1 << pix) > 0) {
              this.mem[7 - pix + mpos] = penColor;
              this.collissionMask[collX + 7 - pix] = 256;
            } else {
              this.mem[7 - pix + mpos] = bgcol;
              this.collissionMask[collX + 7 - pix] = 0;
            } 
          } 
        } 
        if (this.extended)
          for (int pix = 0; pix < 8; pix++)
            this.mem[mpos + 7 - pix] = -16777216;  
      } catch (Exception exception) {}
    } 
    this.vc++;
    this.vmli++;
  }
  
  private final void drawSprites() {
    int smult = 256;
    int lastX = this.xPos - 8;
    for (int i = 7; i >= 0; i--) {
      Sprite sprite = this.sprites[i];
      smult >>= 1;
      if (!sprite.lineFinished && sprite.painting) {
        int x = sprite.x + 8;
        int mpos = this.vPos * 384;
        if (x < this.xPos) {
          int minX = (lastX > x) ? lastX : x;
          for (int j = minX, m = this.xPos; j < m; j++) {
            int c = sprite.getPixel();
            if (c != 0 && this.borderState == 0) {
              int tmp = this.collissionMask[j] = this.collissionMask[j] | smult;
              if (!sprite.priority || (tmp & 0x100) == 0)
                this.mem[mpos + j] = sprite.color[c]; 
              if (tmp != smult) {
                if ((tmp & 0x100) != 0)
                  this.sprBgCol |= smult; 
                if ((tmp & 0xFF) != smult)
                  this.sprCol |= tmp & 0xFF; 
              } 
            } 
          } 
        } 
      } 
    } 
    this.xPos += 8;
  }
  
  public void stop() {
    motorSound(false);
    this.sidChip.stop();
    this.audioDriver.shutdown();
  }
  
  public void reset() {
    initUpdate();
    this.sidChip.reset();
    this.lastLine = this.cpu.cycles;
    this.nextIOUpdate = this.cpu.cycles + 47L;
    for (int i = 0; i < this.mem.length; i++)
      this.mem[i] = 0; 
    this.reset = 100;
    this.sprCol = 0;
    this.sprBgCol = 0;
    this.cia[0].reset();
    this.cia[1].reset();
    this.keyboard.reset();
    motorSound(false);
    resetInterrupts();
  }
  
  public void paint(Graphics g) {
    if (g == null)
      return; 
    if (this.image == null) {
      this.image = this.canvas.createImage(384, 284);
      this.g2 = this.image.getGraphics();
      this.g2.setFont(new Font("Monospaced", 0, 11));
    } 
    if (this.crtImage == null) {
      this.crtImage = new BufferedImage(this.displayWidth, this.displayHeight, 2);
      Graphics gcrt = this.crtImage.getGraphics();
      gcrt.setColor(TRANSPARENT_BLACK);
      for (int i = 0, n = this.displayHeight; i < n; i += 2)
        gcrt.drawLine(0, i, this.displayWidth, i); 
    } 
    this.g2.drawImage(this.screen, 0, 0, null);
    if (this.reset > 0) {
      this.g2.setColor(this.darks[this.colIndex]);
      int xp = 44;
      if (this.reset < 44)
        xp = this.reset; 
      this.g2.drawString("JaC64 1.11 - Java C64 - www.jac64.com", xp + 1, 9);
      this.g2.setColor(this.lites[this.colIndex]);
      this.g2.drawString("JaC64 1.11 - Java C64 - www.jac64.com", xp, 8);
      this.reset--;
    } else {
      String msg = "JaC64 ";
      if (this.message != null && this.message != "") {
        msg = msg + this.message;
      } else {
        this.colIndex = 0;
      } 
      msg = msg + this.tmsg;
      this.g2.setColor(this.darks[this.colIndex]);
      this.g2.drawString(msg, 1, 9);
      this.g2.setColor(this.lites[this.colIndex]);
      this.g2.drawString(msg, 0, 8);
      if (this.ledOn) {
        this.g2.setColor(LED_ON);
      } else {
        this.g2.setColor(LED_OFF);
      } 
      this.g2.fillRect(372, 3, 7, 1);
      this.g2.setColor(LED_BORDER);
      this.g2.drawRect(371, 2, 8, 2);
    } 
    g.fillRect(0, 0, this.offsetX, this.displayHeight + this.offsetY * 2);
    g.fillRect(this.offsetX + this.displayWidth, 0, this.offsetX, this.displayHeight + this.offsetY * 2);
    g.fillRect(0, 0, this.displayWidth + this.offsetX * 2, this.offsetY);
    g.fillRect(0, this.displayHeight + this.offsetY, this.displayWidth + this.offsetX * 2, this.offsetY);
    Graphics2D g2d = (Graphics2D)g;
    g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
    g2d.drawImage(this.image, this.offsetX, this.offsetY, this.displayWidth, this.displayHeight, null);
    g.drawImage(this.crtImage, this.offsetX, this.offsetY, this.displayWidth, this.displayHeight, null);
  }
  
  private class Sprite {
    boolean painting = false;
    
    boolean dma = false;
    
    int nextByte;
    
    int pointer;
    
    int x;
    
    int y;
    
    int spriteNo;
    
    int spriteReg;
    
    boolean enabled;
    
    boolean expFlipFlop;
    
    boolean multicolor = false;
    
    boolean expandX = false;
    
    boolean expandY = false;
    
    boolean priority = false;
    
    boolean lineFinished = false;
    
    int pixelsLeft = 0;
    
    int currentPixel = 0;
    
    int col;
    
    int[] color = new int[4];
    
    int getPixel() {
      if (this.lineFinished)
        return 0; 
      this.pixelsLeft--;
      if (this.pixelsLeft > 0)
        return this.currentPixel; 
      if (this.pixelsLeft <= 0 && this.spriteReg == 0) {
        this.currentPixel = 0;
        this.lineFinished = true;
        return 0;
      } 
      if (this.multicolor) {
        this.currentPixel = (this.spriteReg & 0xC00000) >> 22;
        this.spriteReg = this.spriteReg << 2 & 0xFFFFFF;
        this.pixelsLeft = 2;
      } else {
        this.currentPixel = (this.spriteReg & 0x800000) >> 22;
        this.spriteReg = this.spriteReg << 1 & 0xFFFFFF;
        this.pixelsLeft = 1;
      } 
      if (this.expandX)
        this.pixelsLeft <<= 1; 
      return this.currentPixel;
    }
    
    void reset() {
      this.lineFinished = false;
    }
    
    void readSpriteData() {
      this.pointer = C64Screen.this.vicBank + C64Screen.this.memory[C64Screen.this.spr0BlockSel + this.spriteNo] * 64;
      this
        
        .spriteReg = (C64Screen.this.memory[this.pointer + this.nextByte++] & 0xFF) << 16 | (C64Screen.this.memory[this.pointer + this.nextByte++] & 0xFF) << 8 | C64Screen.this.memory[this.pointer + this.nextByte++];
      if (!this.expandY)
        this.expFlipFlop = false; 
      if (this.expFlipFlop)
        this.nextByte -= 3; 
      this.expFlipFlop = !this.expFlipFlop;
      this.pixelsLeft = 0;
    }
    
    private Sprite() {}
  }
  
  public void updateDisk(Object obs, Object msg) {
    if (msg == C1541Chips.HEAD_MOVED)
      if (this.lastTrack != this.c1541Chips.currentTrack) {
        this.lastTrack = this.c1541Chips.currentTrack;
        trackSound();
      } else {
        trackSound();
      }  
    this.lastSector = this.c1541Chips.currentSector;
    if (this.motorOn != this.c1541Chips.motorOn)
      motorSound(this.c1541Chips.motorOn); 
    this.tmsg = " track: " + this.lastTrack + " / " + this.lastSector;
    this.ledOn = this.c1541Chips.ledOn;
    this.motorOn = this.c1541Chips.motorOn;
  }
  
  private void trackSound() {
    if (this.trackSound != null)
      this.trackSound.play(); 
  }
  
  public void motorSound(boolean on) {
    if (this.motorSound != null)
      if (on) {
        this.motorSound.loop();
      } else {
        this.motorSound.stop();
      }  
  }
  
  public void setSounds(AudioClip track, AudioClip motor) {
    this.trackSound = track;
    this.motorSound = motor;
  }
  
  public void mouseDragged(MouseEvent e) {
    this.potx = e.getX() & 0xFF;
    this.poty = 255 - (e.getY() & 0xFF);
  }
  
  public void mouseMoved(MouseEvent e) {
    this.potx = e.getX() & 0xFF;
    this.poty = 255 - (e.getY() & 0xFF);
  }
  
  public void mouseClicked(MouseEvent e) {}
  
  public void mouseEntered(MouseEvent e) {}
  
  public void mouseExited(MouseEvent e) {}
  
  public void mousePressed(MouseEvent e) {
    if (e.getButton() == 1) {
      this.button1 = true;
    } else {
      this.button2 = true;
    } 
    this.keyboard.setButtonval(255 - (((this.button1 | this.button2) != 0) ? 16 : 0));
  }
  
  public void mouseReleased(MouseEvent e) {
    if (e.getButton() == 1) {
      this.button1 = false;
    } else {
      this.button2 = false;
    } 
    this.keyboard.setButtonval(255 - (((this.button1 | this.button2) != 0) ? 16 : 0));
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\C64Screen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */