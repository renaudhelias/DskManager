package com.dreamfabric.jac64;

public interface PatchListener {
  boolean readFile(String paramString, int paramInt);
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\PatchListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */