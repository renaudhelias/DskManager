package com.dreamfabric.jac64;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.SourceDataLine;

public class AudioDriverSE extends AudioDriver {
  private SourceDataLine dataLine;
  
  private FloatControl volume;
  
  private int vol = 0;
  
  private boolean soundOn = true;
  
  private boolean fullSpeed = false;
  
  public int available() {
    return this.dataLine.available();
  }
  
  public int getMasterVolume() {
    return this.vol;
  }
  
  public long getMicros() {
    return this.dataLine.getMicrosecondPosition();
  }
  
  public boolean hasSound() {
    return (this.dataLine != null);
  }
  
  public void init(int sampleRate, int bufferSize) {
    AudioFormat af = new AudioFormat(sampleRate, 16, 1, true, false);
    DataLine.Info dli = new DataLine.Info(SourceDataLine.class, af, bufferSize);
    try {
      this.dataLine = (SourceDataLine)AudioSystem.getLine(dli);
      if (this.dataLine == null) {
        System.out.println("DataLine: not existing...");
      } else {
        System.out.println("DataLine allocated: " + this.dataLine);
        this.dataLine.open(this.dataLine.getFormat(), bufferSize);
        this
          .volume = (FloatControl)this.dataLine.getControl(FloatControl.Type.MASTER_GAIN);
        setMasterVolume(100);
        this.dataLine.start();
      } 
    } catch (Exception e) {
      System.out.println("Problem while getting data line ");
      e.printStackTrace();
      this.dataLine = null;
    } 
  }
  
  public void setMasterVolume(int v) {
    if (this.volume != null)
      this.volume.setValue(-10.0F + 0.1F * v); 
    this.vol = v;
  }
  
  public void shutdown() {
    this.dataLine.close();
  }
  
  public void write(byte[] buffer) {
    int bsize = buffer.length;
    if (!this.fullSpeed) {
      while (this.dataLine.available() < bsize) {
        try {
          Thread.sleep(1L);
        } catch (Exception exception) {}
      } 
    } else if (this.dataLine.available() < bsize) {
      return;
    } 
    if (!this.soundOn)
      for (int i = 0; i < buffer.length; i++)
        buffer[i] = 0;  
    this.dataLine.write(buffer, 0, bsize);
  }
  
  public void setSoundOn(boolean on) {
    this.soundOn = on;
  }
  
  public void setFullSpeed(boolean full) {
    this.fullSpeed = full;
  }
  
  public boolean fullSpeed() {
    return this.fullSpeed;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\AudioDriverSE.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */