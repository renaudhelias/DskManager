package com.dreamfabric.jac64;

public abstract class TimeEvent {
  TimeEvent nextEvent;
  
  TimeEvent prevEvent;
  
  boolean scheduled = false;
  
  String name;
  
  protected long time;
  
  public TimeEvent(long time) {
    this.time = time;
  }
  
  public TimeEvent(long time, String name) {
    this.time = time;
    this.name = name;
  }
  
  public final long getTime() {
    return this.time;
  }
  
  public abstract void execute(long paramLong);
  
  public String getShort() {
    return "" + this.time + ((this.name != null) ? (": " + this.name) : "");
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\TimeEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */