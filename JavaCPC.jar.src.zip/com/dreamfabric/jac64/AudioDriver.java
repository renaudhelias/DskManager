package com.dreamfabric.jac64;

public abstract class AudioDriver {
  public abstract void init(int paramInt1, int paramInt2);
  
  public abstract void write(byte[] paramArrayOfbyte);
  
  public abstract long getMicros();
  
  public abstract boolean hasSound();
  
  public abstract int available();
  
  public abstract int getMasterVolume();
  
  public abstract void setMasterVolume(int paramInt);
  
  public abstract void shutdown();
  
  public abstract void setSoundOn(boolean paramBoolean);
  
  public abstract void setFullSpeed(boolean paramBoolean);
  
  public abstract boolean fullSpeed();
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\AudioDriver.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */