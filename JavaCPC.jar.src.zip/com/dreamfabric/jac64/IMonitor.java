package com.dreamfabric.jac64;

public interface IMonitor {
  void init(MOS6510Core paramMOS6510Core);
  
  void setEnabled(boolean paramBoolean);
  
  boolean isEnabled();
  
  void info(Object paramObject);
  
  void warning(Object paramObject);
  
  void error(Object paramObject);
  
  int getLevel();
  
  void setLevel(int paramInt);
  
  void disAssemble(int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, int paramInt4, byte paramByte, int paramInt5, int paramInt6);
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\IMonitor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */