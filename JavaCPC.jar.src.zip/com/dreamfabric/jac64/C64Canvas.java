package com.dreamfabric.jac64;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JPanel;

public class C64Canvas extends JPanel implements KeyListener, FocusListener {
  private static final long serialVersionUID = 5124260828376559537L;
  
  boolean integerScale = true;
  
  C64Screen scr;
  
  Keyboard keyboard;
  
  boolean autoScale;
  
  int w;
  
  int h;
  
  public C64Canvas(C64Screen screen, boolean dob, Keyboard keyboard) {
    this.autoScale = dob;
    this.scr = screen;
    this.keyboard = keyboard;
    setFont(new Font("Monospaced", 0, 11));
    setFocusTraversalKeysEnabled(false);
    addFocusListener(this);
    addKeyListener(this);
  }
  
  public void setAutoscale(boolean val) {
    this.autoScale = val;
  }
  
  public void setIntegerScaling(boolean yes) {
    this.integerScale = yes;
  }
  
  public void update(Graphics g) {
    paint(g);
  }
  
  public void paint(Graphics g) {
    if (this.autoScale && (
      this.w != getWidth() || this.h != 
      getHeight())) {
      this.w = getWidth();
      this.h = getHeight();
      double fac = 1.0D * this.w / 384.0D;
      if (fac > 1.0D * this.h / 284.0D)
        fac = 1.0D * this.h / 284.0D; 
      if (this.integerScale && fac > 1.0D)
        fac = (int)fac; 
      this.scr.setDisplayFactor(fac);
      this.scr.setDisplayOffset((int)(this.w - fac * 384.0D) / 2, (int)(this.h - fac * 284.0D) / 2);
    } 
    this.scr.paint(g);
  }
  
  public void keyPressed(KeyEvent event) {
    this.keyboard.keyPressed(event);
  }
  
  public void keyReleased(KeyEvent event) {
    this.keyboard.keyReleased(event);
  }
  
  public void keyTyped(KeyEvent event) {
    char chr = event.getKeyChar();
    if (chr == 'w' && (
      event.getModifiers() & 0x8) != 0)
      this.scr.getAudioDriver().setFullSpeed(!this.scr.getAudioDriver().fullSpeed()); 
  }
  
  public void focusGained(FocusEvent evt) {
    this.keyboard.reset();
  }
  
  public void focusLost(FocusEvent evt) {
    this.keyboard.reset();
  }
  
  public boolean isFocusTraversable() {
    return true;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\C64Canvas.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */