package com.dreamfabric.jac64;

public class SIDMixer {
  public static int BYTES_PER_SAMPLE = 2;
  
  public static final boolean NO_SOUND = false;
  
  public static final boolean DEBUG = false;
  
  public static int DL_BUFFER_SIZE = 88000;
  
  public static final int SYNCH_BUFFER = 1760;
  
  public static final int EFX_NONE = 0;
  
  public static final int EFX_FLANGER_1 = 1;
  
  public static final int EFX_FLANGER_2 = 2;
  
  public static final int EFX_FLANGER_3 = 3;
  
  public static final int EFX_PHASER_1 = 4;
  
  public static final int EFX_PHASER_2 = 5;
  
  public static final int EFX_CHORUS_1 = 6;
  
  public static final int EFX_CHORUS_2 = 7;
  
  public static final int EFX_ECHO_1 = 8;
  
  public static final int EFX_ECHO_2 = 9;
  
  public static final int EFX_REV_SMALL = 10;
  
  public static final int EFX_REV_MED = 11;
  
  public static final int EFX_REV_LARGE = 12;
  
  public static final int EFX_FSWEEP = 13;
  
  public static final int EFX_FSWEEP_RES = 14;
  
  private String[] efxNames = new String[] { 
      "EFX_NONE", "EFX_FLANGER_1", "EFX_FLANGER_2", "EFX_FLANGER_3", "EFX_PHASER_1", "EFX_PHASER_2", "EFX_CHORUS_1", "EFX_CHORUS_2", "EFX_ECHO_1", "EFX_ECHO_2", 
      "EFX_REV_SMALL", "EFX_REV_MED", "EFX_REV_LARGE", "EFX_FSWEEP", "EFX_FSWEEP_RES" };
  
  public boolean fullSpeed = false;
  
  private SIDVoice psid;
  
  private SIDVoice6581[] channels;
  
  private boolean soundOn = true;
  
  private SIDMixerListener listener = null;
  
  private AudioDriver driver;
  
  byte[] buffer = new byte[88];
  
  byte[] syncBuffer = new byte[4096];
  
  int[] intBuffer = new int[44];
  
  int[] noFltBuffer = new int[44];
  
  boolean effects = false;
  
  public static final int LFO_WAVELEN = 500;
  
  int[] echo;
  
  int echoSize = 0;
  
  int echoPos = 0;
  
  int echoLFODiff = 0;
  
  int echoLFODiffMax = 0;
  
  int echoLFODepth = 50;
  
  int echoFeedback = 0;
  
  int echoLFOSpeed = 0;
  
  int echoLFOPos = 0;
  
  int echoDW = 50;
  
  int maxefx;
  
  int minefx;
  
  int sidVol = 15;
  
  int[] sidVolArr = new int[44];
  
  long lastCycles = 0L;
  
  int filterVal = 0;
  
  public int cutoff = 0;
  
  public int resonance = 0;
  
  int filterOn = 0;
  
  int masterVolume = 100;
  
  boolean lpOn = false;
  
  boolean hpOn = false;
  
  boolean bpOn = false;
  
  long vlp;
  
  long vhp;
  
  long vbp;
  
  long w0;
  
  long div1024Q;
  
  long exVlp;
  
  long exVhp;
  
  long exVo;
  
  long exw0lp;
  
  long exw0hp;
  
  int irq = 0;
  
  int[] sine10Hz;
  
  public static final int SLEEP_SYNC = 1;
  
  private int sleep;
  
  private int syncMode;
  
  private double avg;
  
  private long lastTime;
  
  private long micros;
  
  public void init(SIDVoice6581[] channels, SIDVoice sample, AudioDriver driver) {
    this.channels = channels;
    this.psid = sample;
    this.driver = driver;
    System.out.println("Micros per SIDGen: " + getMicrosPerGen());
    this.exw0hp = 105L;
    this.exw0lp = 104858L;
    this.sine10Hz = new int[500];
    for (int i = 0, n = 500; i < n; i++)
      this.sine10Hz[i] = 
        (int)(500.0D + 500.0D * Math.sin((i * 2) * 3.1415D / 500.0D)); 
    setEFX(8);
    setEFX(0);
  }
  
  public void setListener(SIDMixerListener front) {
    this.listener = front;
  }
  
  public void setEchoTime(int millisDelay) {
    int sampleSize = millisDelay * 44000 / 1000;
    System.out.println("SamplesDelay: " + sampleSize);
    this.echoSize = sampleSize;
    this.echo = new int[this.echoSize];
    this.echoLFODiffMax = this.echoSize * this.echoLFODepth / 110;
    this.echoLFODiff = 0;
    this.echoPos = 0;
  }
  
  public int getEchoTime() {
    return 1000 * this.echoSize / 44000;
  }
  
  public int getEFXCount() {
    return this.efxNames.length;
  }
  
  public String getEFXName(int efx) {
    return this.efxNames[efx];
  }
  
  public void setEchoFeedback(int percen) {
    this.echoFeedback = percen;
  }
  
  public int getEchoFeedback() {
    return this.echoFeedback;
  }
  
  public void setEchoLFOSpeed(int hzd10) {
    this.echoLFOSpeed = hzd10;
  }
  
  public int getEchoLFOSpeed() {
    return this.echoLFOSpeed;
  }
  
  public void setEchoDW(int percent) {
    this.echoDW = percent;
  }
  
  public int getEchoDW() {
    return this.echoDW;
  }
  
  public void setEchoLFODepth(int percent) {
    this.echoLFODepth = percent;
    this.echoLFODiffMax = this.echoSize * this.echoLFODepth / 110;
  }
  
  public int getEchoLFODepth() {
    return this.echoLFODepth;
  }
  
  public boolean getEffectsOn() {
    return this.effects;
  }
  
  public void setEFX(int fx) {
    fx %= this.efxNames.length;
    this.effects = true;
    switch (fx) {
      case 0:
        this.effects = false;
        break;
      case 1:
        setEchoTime(5);
        setEchoFeedback(75);
        setEchoLFOSpeed(1);
        setEchoLFODepth(35);
        setEchoDW(33);
        break;
      case 2:
        setEchoTime(15);
        setEchoFeedback(70);
        setEchoLFOSpeed(5);
        setEchoLFODepth(35);
        setEchoDW(35);
        break;
      case 3:
        setEchoTime(2);
        setEchoFeedback(85);
        setEchoLFOSpeed(3);
        setEchoLFODepth(55);
        setEchoDW(30);
        break;
      case 4:
        setEchoTime(10);
        setEchoFeedback(0);
        setEchoLFOSpeed(1);
        setEchoLFODepth(75);
        setEchoDW(50);
        break;
      case 5:
        setEchoTime(3);
        setEchoFeedback(0);
        setEchoLFOSpeed(2);
        setEchoLFODepth(85);
        setEchoDW(40);
        break;
      case 6:
        setEchoTime(25);
        setEchoFeedback(60);
        setEchoLFOSpeed(1);
        setEchoLFODepth(35);
        setEchoDW(35);
        break;
      case 7:
        setEchoTime(30);
        setEchoFeedback(50);
        setEchoLFOSpeed(5);
        setEchoLFODepth(25);
        setEchoDW(35);
        break;
      case 8:
        setEchoTime(150);
        setEchoFeedback(0);
        setEchoLFOSpeed(0);
        setEchoLFODepth(0);
        setEchoDW(33);
        break;
      case 9:
        setEchoTime(300);
        setEchoFeedback(33);
        setEchoLFOSpeed(0);
        setEchoLFODepth(0);
        setEchoDW(45);
        break;
      case 10:
        setEchoTime(70);
        setEchoFeedback(40);
        setEchoLFOSpeed(0);
        setEchoLFODepth(0);
        setEchoDW(33);
        break;
      case 11:
        setEchoTime(130);
        setEchoFeedback(50);
        setEchoLFOSpeed(0);
        setEchoLFODepth(0);
        setEchoDW(33);
        break;
      case 12:
        setEchoTime(100);
        setEchoFeedback(70);
        setEchoLFOSpeed(0);
        setEchoLFODepth(0);
        setEchoDW(40);
        break;
    } 
    if (this.listener != null)
      this.listener.updateValues(); 
  }
  
  public void setEffectsOn(boolean fx) {
    this.effects = fx;
  }
  
  public boolean isEffectsOn() {
    return this.effects;
  }
  
  public void setFilterCutoffLO(int data) {
    this.cutoff = this.cutoff & 0xFF8 | data & 0x7;
    recalcFilter();
  }
  
  public void setFilterCutoffHI(int data) {
    this.cutoff = this.cutoff & 0x7 | data << 3;
    recalcFilter();
  }
  
  public void setFilterResonance(int data) {
    this.resonance = data;
    recalcFilter();
  }
  
  public void setFilterCtrl(int data) {
    this.lpOn = ((data & 0x10) > 0);
    this.bpOn = ((data & 0x20) > 0);
    this.hpOn = ((data & 0x40) > 0);
    recalcFilter();
  }
  
  public void setFilterOn(int on) {
    this.filterOn = on;
  }
  
  public void setMoogFilterOn(boolean on) {}
  
  public boolean isMoogFilterOn() {
    return false;
  }
  
  public void setMoogResonance(int percent) {}
  
  public int getMoogResonance() {
    return 0;
  }
  
  public void setMoogCutoff(int frq) {}
  
  public int getMoogCutoff() {
    return 0;
  }
  
  public void setMoogSpeed(int hz10) {}
  
  public int getMoogSpeed() {
    return 0;
  }
  
  public void setMoogDepth(int dep) {}
  
  public int getMoogDepth() {
    return 0;
  }
  
  public void setVolume(int vol) {
    this.sidVol = vol;
  }
  
  public void setVolume(int vol, long cycles) {
    if (this.lastCycles > 0L) {
      int pos = (int)((cycles - this.lastCycles) / 32L);
      this.sidVolArr[pos % 44] = vol;
    } else {
      this.sidVol = vol;
    } 
  }
  
  private void recalcFilter() {
    int fCutoff = 30 + 12000 * this.cutoff / 2048;
    this.w0 = (long)(6.283185307179586D * fCutoff * 1.048576D);
    this.div1024Q = (int)(1024.0D / (0.707D + 1.0D * this.resonance / 15.0D));
  }
  
  public void stop() {
    setVolume(0);
  }
  
  public void reset() {
    this.exVo = 0L;
    this.exVhp = 0L;
    this.exVlp = 0L;
    this.cutoff = 0;
    this.resonance = 0;
    this.w0 = 0L;
    this.div1024Q = 0L;
    this.filterOn = 0;
    this.maxefx = 0;
    this.minefx = 0;
    for (int i = 0, n = 44; i < n; i++)
      this.sidVolArr[i] = -1; 
    setVolume(15);
    recalcFilter();
  }
  
  public void printStatus() {
    System.out.println("SIDMixer  ----------------------------");
    System.out.println("Volume: " + this.sidVol);
    System.out.println("FilterOn: " + this.filterOn);
    System.out.println("Cutoff: " + this.cutoff);
    System.out.println("Resonance: " + this.resonance);
    System.out.println("Max Efx:" + this.maxefx);
    System.out.println("Min Efx:" + this.minefx);
  }
  
  public void setFullSpeed(boolean fs) {
    System.out.println("Set full speed: " + fs);
    this.fullSpeed = fs;
  }
  
  public boolean fullSpeed() {
    return this.fullSpeed;
  }
  
  public int[] getBuffer() {
    return this.intBuffer;
  }
  
  public SIDMixer() {
    this.sleep = 100;
    this.syncMode = 0;
    this.avg = 10.0D;
    this.lastTime = System.currentTimeMillis();
    this.micros = 0L;
  }
  
  public SIDMixer(SIDVoice6581[] channels, SIDVoice sample, AudioDriver driver) {
    this.sleep = 100;
    this.syncMode = 0;
    this.avg = 10.0D;
    this.lastTime = System.currentTimeMillis();
    this.micros = 0L;
    init(channels, sample, driver);
  }
  
  public boolean updateSound(long cycles) {
    this.irq++;
    boolean trueIRQ = (this.irq % 20 == 0);
    if (trueIRQ && 
      this.syncMode == 1 && !this.fullSpeed) {
      long elapsed = System.currentTimeMillis() - this.lastTime;
      this.lastTime = System.currentTimeMillis();
      this.avg = 0.99D * this.avg + 0.01D * elapsed;
      if (this.avg < 20.0D)
        this.sleep++; 
      if (this.avg > 20.0D)
        this.sleep--; 
      System.out.println("Avg: " + this.avg + " Sleep: " + (this.sleep / 10.0D) + " " + (this.driver
          .getMicros() - this.micros));
      double slm = 19.75D - (this.driver.getMicros() - this.micros) / 1000.0D;
      try {
        Thread.sleep((int)slm);
      } catch (Exception e) {
        e.printStackTrace();
      } 
      this.micros = this.driver.getMicros();
    } 
    if (!this.driver.hasSound())
      return trueIRQ; 
    if ((this.fullSpeed || this.syncMode == 1) && 
      this.driver.available() < 88)
      return false; 
    this.lastCycles = cycles;
    if (this.soundOn) {
      if (this.psid != null) {
        int[] tBuf = this.psid.generateSound(cycles);
        for (int j = 0, m = 44; j < m; j++) {
          this.intBuffer[j] = 0;
          this.noFltBuffer[j] = tBuf[j] << 4;
        } 
      } else {
        for (int j = 0, m = 44; j < m; j++) {
          this.intBuffer[j] = 0;
          this.noFltBuffer[j] = 0;
        } 
      } 
      int i, n;
      for (i = 0, n = this.channels.length; i < n; i++) {
        int[] tBuf, buf = this.channels[i].generateSound(cycles);
        if ((this.filterOn & 1 << i) > 0) {
          tBuf = this.intBuffer;
        } else {
          tBuf = this.noFltBuffer;
        } 
        for (int j = 0, m = 44; j < m; j++)
          tBuf[j] = tBuf[j] + (buf[j] >> 2); 
      } 
      for (i = 0, n = 44; i < n; i++) {
        int inval = this.intBuffer[i];
        if (this.filterOn > 0) {
          this.vbp -= 8L * this.w0 * this.vhp >> 20L;
          this.vlp -= 8L * this.w0 * this.vbp >> 20L;
          this.vhp = (this.vbp * this.div1024Q >> 10L) - this.vlp - inval;
          this.vbp -= 8L * this.w0 * this.vhp >> 20L;
          this.vlp -= 8L * this.w0 * this.vbp >> 20L;
          this.vhp = (this.vbp * this.div1024Q >> 10L) - this.vlp - inval;
          this.vbp -= 7L * this.w0 * this.vhp >> 20L;
          this.vlp -= 7L * this.w0 * this.vbp >> 20L;
          this.vhp = (this.vbp * this.div1024Q >> 10L) - this.vlp - inval;
          inval = (int)((this.bpOn ? this.vbp : 0L) + (this.hpOn ? this.vhp : 0L) + (this.lpOn ? this.vlp : 0L));
        } 
        inval += this.noFltBuffer[i];
        if (this.sidVolArr[i] != -1) {
          this.sidVol = this.sidVolArr[i];
          this.sidVolArr[i] = -1;
        } 
        inval = inval * this.sidVol >> 2;
        this.exVlp += (8L * this.exw0lp >> 8L) * (inval - this.exVlp) >> 12L;
        this.exVhp += this.exw0hp * 8L * (this.exVlp - this.exVhp) >> 20L;
        this.exVlp += (8L * this.exw0lp >> 8L) * (inval - this.exVlp) >> 12L;
        this.exVhp += this.exw0hp * 8L * (this.exVlp - this.exVhp) >> 20L;
        this.exVo = this.exVlp - this.exVhp;
        this.exVlp += (7L * this.exw0lp >> 8L) * (inval - this.exVlp) >> 12L;
        this.exVhp += this.exw0hp * 7L * (this.exVlp - this.exVhp) >> 20L;
        this.intBuffer[i] = (int)this.exVo;
      } 
      if (this.effects)
        for (i = 0, n = 44; i < n; i++) {
          int exVal = this.intBuffer[i];
          int echoRead = (this.echoPos + this.echoLFODiff) % this.echoSize;
          int out = (exVal * (100 - this.echoDW) + this.echo[echoRead] * this.echoDW) / 100;
          if (out > 32767)
            out = 32767; 
          if (out < -32767)
            out = -32767; 
          this.intBuffer[i] = out;
          exVal += this.echo[echoRead] * this.echoFeedback / 100;
          if (exVal > this.maxefx)
            this.maxefx = exVal; 
          if (exVal < this.minefx)
            this.minefx = exVal; 
          if (exVal > 32767)
            exVal = 32767; 
          if (exVal < -32767)
            exVal = -32767; 
          this.echo[this.echoPos] = exVal;
          this.echoPos = (this.echoPos + 1) % this.echoSize;
        }  
      int bIndex = 0;
      if (BYTES_PER_SAMPLE == 2) {
        for (int j = 0, k = 44; j < k; j++) {
          this.buffer[bIndex++] = (byte)(this.intBuffer[j] & 0xFF);
          this.buffer[bIndex++] = (byte)(this.intBuffer[j] >> 8);
        } 
      } else {
        for (int j = 0, k = 44; j < k; j++)
          this.buffer[bIndex++] = (byte)(this.intBuffer[j] >> 8); 
      } 
    } 
    this.driver.write(this.buffer);
    if (trueIRQ) {
      this.echoLFODiff = this.echoLFODiffMax * this.sine10Hz[this.echoLFOPos] / 1000;
      this.echoLFOPos = (this.echoLFOPos + this.echoLFOSpeed) % 500;
    } 
    return trueIRQ;
  }
  
  public int getMicrosPerGen() {
    long mpg = 44000000L;
    return (int)(mpg / 44000L);
  }
  
  public boolean soundOn() {
    return this.soundOn;
  }
  
  public void setSoundOn(boolean on) {
    this.soundOn = on;
    if (!this.soundOn)
      for (int i = 0, n = this.buffer.length; i < n; i++)
        this.buffer[i] = 0;  
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\SIDMixer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */