package com.dreamfabric.jac64;

public class Hex {
  public static final String hex2(int n) {
    if (n < 16)
      return "0" + Integer.toString(n, 16); 
    return Integer.toString(n, 16);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\Hex.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */