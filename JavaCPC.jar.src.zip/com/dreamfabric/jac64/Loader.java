package com.dreamfabric.jac64;

import java.io.InputStream;

public abstract class Loader {
  public abstract InputStream getResourceStream(String paramString);
  
  public String getResourceString(String rs) {
    InputStream inStr = getResourceStream(rs);
    StringBuffer sb = new StringBuffer();
    try {
      int c;
      while ((c = inStr.read()) != -1)
        sb.append((char)c); 
    } catch (Exception e) {
      e.printStackTrace();
    } 
    return sb.toString();
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\Loader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */