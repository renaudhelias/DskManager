package com.dreamfabric.jac64;

public class EventQueue {
  private TimeEvent first;
  
  public long nextTime;
  
  public void addEvent(TimeEvent event, long time) {
    event.time = time;
    addEvent(event);
  }
  
  public void addEvent(TimeEvent event) {
    if (event.scheduled)
      removeEvent(event); 
    if (this.first == null) {
      this.first = event;
    } else {
      TimeEvent pos = this.first;
      TimeEvent lastPos = this.first;
      while (pos != null && pos.time < event.time) {
        lastPos = pos;
        pos = pos.nextEvent;
      } 
      if (pos == this.first) {
        event.nextEvent = pos;
        this.first = event;
      } else {
        event.nextEvent = pos;
        lastPos.nextEvent = event;
      } 
    } 
    if (this.first != null) {
      this.nextTime = this.first.time;
    } else {
      this.nextTime = 0L;
    } 
    event.scheduled = true;
  }
  
  public boolean removeEvent(TimeEvent event) {
    TimeEvent pos = this.first;
    TimeEvent lastPos = this.first;
    while (pos != null && pos != event) {
      lastPos = pos;
      pos = pos.nextEvent;
    } 
    if (pos == null)
      return false; 
    if (pos == this.first) {
      this.first = pos.nextEvent;
    } else {
      lastPos.nextEvent = pos.nextEvent;
    } 
    pos.nextEvent = null;
    if (this.first != null) {
      this.nextTime = this.first.time;
    } else {
      this.nextTime = 0L;
    } 
    event.scheduled = false;
    return true;
  }
  
  public TimeEvent popFirst() {
    TimeEvent tmp = this.first;
    if (tmp != null) {
      this.first = tmp.nextEvent;
      tmp.nextEvent = null;
    } 
    if (this.first != null) {
      this.nextTime = this.first.time;
    } else {
      this.nextTime = 0L;
    } 
    tmp.scheduled = false;
    return tmp;
  }
  
  public void print() {
    TimeEvent t = this.first;
    System.out.print("nxt: " + this.nextTime + " [");
    while (t != null) {
      System.out.print(t.getShort());
      t = t.nextEvent;
      if (t != null)
        System.out.print(", "); 
    } 
    System.out.println("]");
  }
  
  public void empty() {
    this.first = null;
    this.nextTime = 0L;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\EventQueue.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */