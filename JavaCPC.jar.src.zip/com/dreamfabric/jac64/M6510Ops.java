package com.dreamfabric.jac64;

public interface M6510Ops {
  public static final int BRK = 0;
  
  public static final int ORA_INDX = 1;
  
  public static final int ORA_Z = 5;
  
  public static final int ASL_Z = 6;
  
  public static final int PHP = 8;
  
  public static final int ORA_I = 9;
  
  public static final int ASL_ACC = 10;
  
  public static final int ORA = 13;
  
  public static final int ASL = 14;
  
  public static final int BPL = 16;
  
  public static final int ORA_INDY = 17;
  
  public static final int ORA_ZX = 21;
  
  public static final int ASL_ZX = 22;
  
  public static final int CLC = 24;
  
  public static final int ORA_Y = 25;
  
  public static final int ORA_X = 29;
  
  public static final int ASL_X = 30;
  
  public static final int JSR = 32;
  
  public static final int AND_INDX = 33;
  
  public static final int BIT_Z = 36;
  
  public static final int AND_Z = 37;
  
  public static final int ROL_Z = 38;
  
  public static final int PLP = 40;
  
  public static final int AND_I = 41;
  
  public static final int ROL_ACC = 42;
  
  public static final int BIT = 44;
  
  public static final int AND = 45;
  
  public static final int ROL = 46;
  
  public static final int BMI = 48;
  
  public static final int AND_INDY = 49;
  
  public static final int AND_ZX = 53;
  
  public static final int ROL_ZX = 54;
  
  public static final int SEC = 56;
  
  public static final int AND_Y = 57;
  
  public static final int AND_X = 61;
  
  public static final int ROL_X = 62;
  
  public static final int RTI = 64;
  
  public static final int EOR_INDX = 65;
  
  public static final int EOR_Z = 69;
  
  public static final int LSR_Z = 70;
  
  public static final int PHA = 72;
  
  public static final int EOR_I = 73;
  
  public static final int LSR_ACC = 74;
  
  public static final int JMP = 76;
  
  public static final int EOR = 77;
  
  public static final int LSR = 78;
  
  public static final int BVC = 80;
  
  public static final int EOR_INDY = 81;
  
  public static final int EOR_ZX = 85;
  
  public static final int LSR_ZX = 86;
  
  public static final int CLI = 88;
  
  public static final int EOR_Y = 89;
  
  public static final int EOR_X = 93;
  
  public static final int LSR_X = 94;
  
  public static final int RTS = 96;
  
  public static final int ADC_INDX = 97;
  
  public static final int ADC_Z = 101;
  
  public static final int ROR_Z = 102;
  
  public static final int PLA = 104;
  
  public static final int ADC_I = 105;
  
  public static final int ROR_ACC = 106;
  
  public static final int JMP_IND = 108;
  
  public static final int ADC = 109;
  
  public static final int ROR = 110;
  
  public static final int BVS = 112;
  
  public static final int ADC_INDY = 113;
  
  public static final int ADC_ZX = 117;
  
  public static final int ROR_ZX = 118;
  
  public static final int SEI = 120;
  
  public static final int ADC_Y = 121;
  
  public static final int ADC_X = 125;
  
  public static final int ROR_X = 126;
  
  public static final int STA_INDX = 129;
  
  public static final int STY_Z = 132;
  
  public static final int STA_Z = 133;
  
  public static final int STX_Z = 134;
  
  public static final int DEY = 136;
  
  public static final int TXA = 138;
  
  public static final int STY = 140;
  
  public static final int STA = 141;
  
  public static final int STX = 142;
  
  public static final int BCC = 144;
  
  public static final int STA_INDY = 145;
  
  public static final int STY_ZX = 148;
  
  public static final int STA_ZX = 149;
  
  public static final int STX_ZY = 150;
  
  public static final int TYA = 152;
  
  public static final int STA_Y = 153;
  
  public static final int TXS = 154;
  
  public static final int STA_X = 157;
  
  public static final int LDY_I = 160;
  
  public static final int LDA_INDX = 161;
  
  public static final int LDX_I = 162;
  
  public static final int LDY_Z = 164;
  
  public static final int LDA_Z = 165;
  
  public static final int LDX_Z = 166;
  
  public static final int TAY = 168;
  
  public static final int LDA_I = 169;
  
  public static final int TAX = 170;
  
  public static final int LDY = 172;
  
  public static final int LDA = 173;
  
  public static final int LDX = 174;
  
  public static final int BCS = 176;
  
  public static final int LDA_INDY = 177;
  
  public static final int LDY_ZX = 180;
  
  public static final int LDA_ZX = 181;
  
  public static final int LDX_ZY = 182;
  
  public static final int CLV = 184;
  
  public static final int LDA_Y = 185;
  
  public static final int TSX = 186;
  
  public static final int LDY_X = 188;
  
  public static final int LDA_X = 189;
  
  public static final int LDX_Y = 190;
  
  public static final int CPY_I = 192;
  
  public static final int CMP_INDX = 193;
  
  public static final int CPY_Z = 196;
  
  public static final int CMP_Z = 197;
  
  public static final int DEC_Z = 198;
  
  public static final int INY = 200;
  
  public static final int CMP_I = 201;
  
  public static final int DEX = 202;
  
  public static final int CPY = 204;
  
  public static final int CMP = 205;
  
  public static final int DEC = 206;
  
  public static final int BNE = 208;
  
  public static final int CMP_INDY = 209;
  
  public static final int CMP_ZX = 213;
  
  public static final int DEC_ZX = 214;
  
  public static final int CLD = 216;
  
  public static final int CMP_Y = 217;
  
  public static final int CMP_X = 221;
  
  public static final int DEC_X = 222;
  
  public static final int CPX_I = 224;
  
  public static final int SBC_INDX = 225;
  
  public static final int CPX_Z = 228;
  
  public static final int SBC_Z = 229;
  
  public static final int INC_Z = 230;
  
  public static final int INX = 232;
  
  public static final int SBC_I = 233;
  
  public static final int NOP = 234;
  
  public static final int SBC_I_01 = 235;
  
  public static final int CPX = 236;
  
  public static final int SBC = 237;
  
  public static final int INC = 238;
  
  public static final int BEQ = 240;
  
  public static final int SBC_INDY = 241;
  
  public static final int SBC_ZX = 245;
  
  public static final int INC_ZX = 246;
  
  public static final int SED = 248;
  
  public static final int SBC_Y = 249;
  
  public static final int SBC_X = 253;
  
  public static final int INC_X = 254;
  
  public static final int SLO_INDX = 3;
  
  public static final int RLA_INDX = 35;
  
  public static final int SRE_INDX = 67;
  
  public static final int RRA_INDX = 99;
  
  public static final int SAX_INDX = 131;
  
  public static final int LAX_INDX = 163;
  
  public static final int DCP_INDX = 195;
  
  public static final int ISB_INDX = 227;
  
  public static final int SLO_Z = 7;
  
  public static final int RLA_Z = 39;
  
  public static final int SRE_Z = 71;
  
  public static final int RRA_Z = 103;
  
  public static final int SAX_Z = 135;
  
  public static final int LAX_Z = 167;
  
  public static final int DCP_Z = 199;
  
  public static final int ISB_Z = 231;
  
  public static final int SLO_ZX = 23;
  
  public static final int RLA_ZX = 55;
  
  public static final int SRE_ZX = 87;
  
  public static final int RRA_ZX = 119;
  
  public static final int SAX_ZY = 151;
  
  public static final int LAX_ZY = 183;
  
  public static final int DCP_ZX = 215;
  
  public static final int ISB_ZX = 247;
  
  public static final int SLO = 15;
  
  public static final int RLA = 47;
  
  public static final int SRE = 79;
  
  public static final int RRA = 111;
  
  public static final int SAX = 143;
  
  public static final int LAX = 175;
  
  public static final int DCP = 207;
  
  public static final int ISB = 239;
  
  public static final int SLO_INDY = 19;
  
  public static final int RLA_INDY = 51;
  
  public static final int SRE_INDY = 83;
  
  public static final int RRA_INDY = 115;
  
  public static final int SHA_INDY = 147;
  
  public static final int LAX_INDY = 179;
  
  public static final int DCP_INDY = 211;
  
  public static final int ISB_INDY = 243;
  
  public static final int SLO_Y = 27;
  
  public static final int RLA_Y = 59;
  
  public static final int SRE_Y = 91;
  
  public static final int RRA_Y = 123;
  
  public static final int SHS_Y = 155;
  
  public static final int LAS_Y = 187;
  
  public static final int DCP_Y = 219;
  
  public static final int ISB_Y = 251;
  
  public static final int ANC_I = 11;
  
  public static final int ANC_I_01 = 43;
  
  public static final int ASR_I = 75;
  
  public static final int ARR_I = 107;
  
  public static final int ANE_I = 139;
  
  public static final int LXA_I = 171;
  
  public static final int SBX_I = 203;
  
  public static final int SAY_X = 156;
  
  public static final int XAS_Y = 158;
  
  public static final int SLO_X = 31;
  
  public static final int RLA_X = 63;
  
  public static final int SRE_X = 95;
  
  public static final int RRA_X = 127;
  
  public static final int SHA_Y = 159;
  
  public static final int LAX_Y = 191;
  
  public static final int DCP_X = 223;
  
  public static final int ISB_X = 255;
  
  public static final int HALT_00 = 2;
  
  public static final int HALT_01 = 18;
  
  public static final int HALT_02 = 34;
  
  public static final int HALT_03 = 50;
  
  public static final int HALT_04 = 66;
  
  public static final int HALT_05 = 82;
  
  public static final int HALT_06 = 98;
  
  public static final int HALT_07 = 114;
  
  public static final int HALT_08 = 130;
  
  public static final int HALT_09 = 146;
  
  public static final int HALT_10 = 178;
  
  public static final int HALT_11 = 194;
  
  public static final int HALT_12 = 210;
  
  public static final int HALT_13 = 226;
  
  public static final int HALT_14 = 242;
  
  public static final int LOAD_FILE = 256;
  
  public static final int SLEEP = 257;
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\M6510Ops.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */