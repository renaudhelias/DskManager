package com.dreamfabric.jac64;

public class SIDVoice {
  public int[] intBuffer;
  
  public int[] generateSound(long cycles) {
    return null;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\SIDVoice.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */