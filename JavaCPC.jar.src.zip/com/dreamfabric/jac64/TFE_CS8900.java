package com.dreamfabric.jac64;

public class TFE_CS8900 {
  public static final int RXTXREG = 0;
  
  public static final int TXCMD = 4;
  
  public static final int TXLEN = 6;
  
  public static final int PPDATA = 12;
  
  public static final int PACKET_PP = 10;
  
  private int offset;
  
  public TFE_CS8900(int offset) {
    this.offset = offset;
  }
  
  public int performRead(int address, long cycles) {
    System.out.println("TFE_CS8900: read " + Integer.toString(address, 16));
    switch (address) {
    
    } 
    return 0;
  }
  
  public void performWrite(int address, int data, long cycles) {
    System.out.println("TFE_CS8900: write " + Integer.toString(address, 16) + " = " + data);
    address -= this.offset;
    switch (address) {
    
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\TFE_CS8900.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */