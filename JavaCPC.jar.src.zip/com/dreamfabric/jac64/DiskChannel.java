package com.dreamfabric.jac64;

public class DiskChannel {
  String filename;
  
  byte[] data;
  
  boolean open;
  
  int pos;
  
  int chID;
  
  public DiskChannel(int chID) {
    this.chID = chID;
  }
  
  public void setFilename(String name) {
    this.filename = name;
  }
  
  public void setData(byte[] data) {
    this.data = data;
  }
  
  public byte[] getData() {
    return this.data;
  }
  
  public int readChar() {
    if (this.pos >= this.data.length)
      return -1; 
    return this.data[this.pos++] & 0xFF;
  }
  
  public void open() {
    this.open = true;
    this.pos = 0;
  }
  
  public void close() {
    this.open = false;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\DiskChannel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */