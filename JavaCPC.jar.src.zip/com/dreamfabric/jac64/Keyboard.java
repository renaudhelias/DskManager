package com.dreamfabric.jac64;

import com.dreamfabric.c64utils.C64Script;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Locale;

public class Keyboard {
  public static final int IO_OFFSET = 12288;
  
  public static final int AUTO_SHIFT = 1024;
  
  public static final int AUTO_CTRL = 2048;
  
  public static final int AUTO_COMMODORE = 4096;
  
  public static final int MIN_AUTO = 1024;
  
  public static final int STICK_UPDOWN = 3;
  
  public static final int STICK_LEFTRIGHT = 12;
  
  public static final int STICK_UP = 1;
  
  public static final int STICK_DOWN = 2;
  
  public static final int STICK_LEFT = 4;
  
  public static final int STICK_RIGHT = 8;
  
  public static final int STICK_FIRE = 16;
  
  public static final char[][] KEYMAPS = new char[][] { { 
        's', 'v', ';', 'ö', '\'', 'ä', '[', 'å', '`', '§', 
        '\\', 'Þ', '/', '-', ']', '', '-', 'ȉ', '=', '' }, { 
        'd', 'e', ';', 'ö', '\'', 'ä', '[', 'ü', '`', '^', 
        '\\', 'Ȉ', '/', '-', ']', 'ȉ', '-', 'ß', '=', '' } };
  
  boolean extendedKeyboardEmulation = false;
  
  boolean stickExits = false;
  
  int joystick1 = 255;
  
  int bval;
  
  boolean lastUp = false;
  
  boolean lastLeft = false;
  
  private int joy1 = 255;
  
  private int joy2 = 255;
  
  int stick = 68608;
  
  private int keyPressed = 0;
  
  private int lastKey;
  
  public boolean ready = false;
  
  public int reads = 0;
  
  private C64Script c64script;
  
  private ArrayList hotkeyScript;
  
  int[] keyrow = new int[8];
  
  int[] keycol = new int[8];
  
  int[][] keytable = new int[1024][3];
  
  int keyShift = 0;
  
  int[][] keytableDef = new int[][] { 
      { 65, 1, 2, 0 }, { 66, 3, 4, 0 }, { 67, 2, 4, 0 }, { 68, 2, 2, 0 }, { 69, 1, 6, 0 }, { 70, 2, 5, 0 }, { 71, 3, 2, 0 }, { 72, 3, 5, 0 }, { 73, 4, 1, 0 }, { 74, 4, 2, 0 }, 
      { 75, 4, 5, 0 }, { 76, 5, 2, 0 }, { 77, 4, 4, 0 }, { 78, 4, 7, 0 }, { 79, 4, 6, 0 }, { 80, 5, 1, 0 }, { 81, 7, 6, 0 }, { 82, 2, 1, 0 }, { 83, 1, 5, 0 }, { 84, 2, 6, 0 }, 
      { 85, 3, 6, 0 }, { 86, 3, 7, 0 }, { 87, 1, 1, 0 }, { 88, 2, 7, 0 }, { 89, 3, 1, 0 }, { 90, 1, 4, 0 }, { 48, 4, 3, 0 }, { 49, 7, 0, 0 }, { 50, 7, 3, 0 }, { 51, 1, 0, 0 }, 
      { 52, 1, 3, 0 }, { 53, 2, 0, 0 }, { 54, 2, 3, 0 }, { 55, 3, 0, 0 }, { 56, 3, 3, 0 }, { 57, 4, 0, 0 }, { 10, 0, 1, 0 }, { 10, 0, 1, 0 }, { 32, 7, 4, 0 }, { 44, 5, 7, 0 }, 
      { 46, 5, 4, 0 }, { 92, 6, 5, 0 }, { 59, 5, 5, 0 }, { 45, 5, 0, 0 }, { 61, 5, 3, 0 }, { 96, 7, 1, 0 }, { 39, 6, 2, 0 }, { 109, 5, 3, 0 }, { 91, 5, 6, 0 }, { 93, 6, 1, 0 }, 
      { 27, 7, 1, 0 }, { 47, 6, 7, 0 }, { 111, 6, 7, 0 }, { 63, 6, 7, 1024 }, { 127, 0, 0, 0 }, { 8, 0, 0, 0 }, { 16, 1, 7, 0 }, { 20, 6, 4, 0 }, { 19, 7, 7, 0 }, { 27, 7, 7, 0 }, 
      { 13, 0, 1, 0 }, { 17, 7, 5, 2 }, { 10, 0, 1, 0 }, { 40, 0, 7, 0 }, { 38, 0, 7, 1024 }, { 39, 0, 2, 0 }, { 37, 0, 2, 1024 }, { 112, 0, 4, 0 }, { 114, 0, 5, 0 }, { 116, 0, 6, 0 }, 
      { 118, 0, 3, 0 }, { 36, 6, 3, 0 }, { 35, 6, 6, 0 }, { 155, 6, 0, 0 }, { 9, 7, 2, 0 } };
  
  private int restoreKey = 33;
  
  public static final int USER_UP = 0;
  
  public static final int USER_DOWN = 1;
  
  public static final int USER_LEFT = 2;
  
  public static final int USER_RIGHT = 3;
  
  public static final int USER_FIRE = 4;
  
  private static final int[] ARROWS = new int[] { 38, 0, 40, 0, 37, 0, 39, 0, 17, 3 };
  
  private int[] userDefinedStick = ARROWS;
  
  private CIA cia;
  
  private C64Screen screen;
  
  private void remap(char key, char newkey) {
    for (int i = 0, n = this.keytableDef.length; i < n; i++) {
      if (this.keytableDef[i][0] == key) {
        this.keytableDef[i][0] = newkey;
        System.out.println("Remapped: " + key + " => " + newkey + "  key " + key + " => " + newkey);
        return;
      } 
    } 
  }
  
  private boolean doMap(String ltarget) {
    for (int i = 0, n = KEYMAPS.length; i < n; i++) {
      char[] map = KEYMAPS[i];
      String lang = "" + map[0] + map[1];
      System.out.println("Checking map for: " + lang);
      if (ltarget.equals(lang)) {
        System.out.println("Found map - mapping...");
        for (int j = 2, m = map.length; j < m; j += 2)
          remap(map[j], map[j + 1]); 
        return true;
      } 
    } 
    return false;
  }
  
  public Keyboard(C64Screen screen, CIA cia, int[] memory) {
    Locale locale = Locale.getDefault();
    System.out.println("Locale: " + locale);
    String lang = locale.getLanguage();
    if (!doMap(lang))
      System.out.println("Could not find map for keyboard: " + lang); 
    this.cia = cia;
    this.screen = screen;
    int i;
    for (i = 0; i < this.keytable.length; i++)
      this.keytable[i][0] = -1; 
    for (i = 0; i < this.keytableDef.length; i++) {
      int key = this.keytableDef[i][0];
      this.keytable[key][0] = this.keytableDef[i][1];
      this.keytable[key][1] = this.keytableDef[i][2];
      this.keytable[key][2] = this.keytableDef[i][3];
    } 
    reset();
  }
  
  public void registerHotKey(int key, int modflag, String script, Object o) {
    if (this.hotkeyScript == null) {
      this.c64script = new C64Script();
      this.hotkeyScript = new ArrayList();
    } 
    this.hotkeyScript.add(new Object[] { script, o, { key, modflag } });
  }
  
  public void setStick(boolean one) {
    if (one) {
      this.stick = 68609;
    } else {
      this.stick = 68608;
    } 
  }
  
  private int getUserStick(int key, int location) {
    if (this.userDefinedStick != null)
      for (int i = 0, n = this.userDefinedStick.length; i < n; i += 2) {
        if (key == this.userDefinedStick[i]) {
          int cmpLoc = this.userDefinedStick[i + 1];
          if (cmpLoc == 0 || location == this.userDefinedStick[i + 1])
            return i / 2; 
        } 
      }  
    return -1;
  }
  
  public void keyPressed(KeyEvent event) {
    char chr = event.getKeyChar();
    int key = event.getKeyCode();
    int location = event.getKeyLocation();
    if (this.hotkeyScript != null) {
      int mod = event.getModifiersEx();
      for (int i = 0, n = this.hotkeyScript.size(); i < n; i++) {
        Object[] hk = this.hotkeyScript.get(i);
        int[] keys = (int[])hk[2];
        if (keys[0] == key && (mod & keys[1]) == keys[1])
          this.c64script.interpretCall((String)hk[0], hk[1]); 
      } 
    } 
    if (key == 0) {
      System.out.println("KeyZero ???");
      key = Character.toLowerCase(chr);
    } 
    if (key == this.restoreKey)
      this.screen.restoreKey(true); 
    if (key != this.lastKey)
      this.keyPressed++; 
    this.lastKey = key;
    int usr = getUserStick(key, location);
    if (this.extendedKeyboardEmulation)
      usr = -1; 
    if (usr == -1)
      usr = getNormalStick(key); 
    switch (usr) {
      case 0:
        this.joystick1 &= 0xFE;
        this.lastUp = true;
        if (this.stickExits) {
          updateKeyboard();
          return;
        } 
        break;
      case 1:
        this.joystick1 &= 0xFD;
        this.lastUp = false;
        if (this.stickExits) {
          updateKeyboard();
          return;
        } 
        break;
      case 2:
        this.joystick1 &= 0xFB;
        this.lastLeft = true;
        if (this.stickExits) {
          updateKeyboard();
          return;
        } 
        break;
      case 3:
        this.joystick1 &= 0xF7;
        this.lastLeft = false;
        if (this.stickExits) {
          updateKeyboard();
          return;
        } 
        break;
      case 4:
        this.joystick1 &= 0xEF;
        if (this.stickExits) {
          updateKeyboard();
          return;
        } 
        break;
    } 
    switch (key) {
      case 121:
        setStick((this.stick == 68608));
        break;
      case 120:
        System.out.println("F9");
        this.extendedKeyboardEmulation = !this.extendedKeyboardEmulation;
        this.stickExits = !this.extendedKeyboardEmulation;
        break;
    } 
    if (this.extendedKeyboardEmulation) {
      if ((this.keytable[key][2] & 0x400) != 0) {
        this.keyShift++;
        if (this.keyShift == 1)
          handleKeyPress(16, location); 
      } else if (key == 16) {
        this.keyShift++;
      } 
      handleKeyPress(key, location);
      updateKeyboard();
    } else if (this.keytable[key][2] < 1024) {
      handleKeyPress(key, location);
      updateKeyboard();
    } 
  }
  
  public void keyReleased(KeyEvent event) {
    int key = event.getKeyCode();
    char chr = event.getKeyChar();
    int location = event.getKeyLocation();
    if (key == 0) {
      System.out.println("KeyZero???");
      key = Character.toLowerCase(chr);
    } 
    if (key == this.restoreKey)
      this.screen.restoreKey(false); 
    this.keyPressed--;
    this.lastKey = 0;
    if (this.keyPressed < 0)
      this.keyPressed = 0; 
    int usr = getUserStick(key, location);
    if (usr == -1)
      usr = getNormalStick(key); 
    switch (usr) {
      case 0:
        this.joystick1 |= 0x1;
        if (this.stickExits) {
          updateKeyboard();
          return;
        } 
        break;
      case 1:
        this.joystick1 |= 0x2;
        if (this.stickExits) {
          updateKeyboard();
          return;
        } 
        break;
      case 2:
        this.joystick1 |= 0x4;
        if (this.stickExits) {
          updateKeyboard();
          return;
        } 
        break;
      case 3:
        this.joystick1 |= 0x8;
        if (this.stickExits) {
          updateKeyboard();
          return;
        } 
        break;
      case 4:
        this.joystick1 |= 0x10;
        if (this.stickExits) {
          updateKeyboard();
          return;
        } 
        break;
    } 
    if (this.extendedKeyboardEmulation) {
      if ((this.keytable[key][2] & 0x400) != 0) {
        this.keyShift--;
        if (this.keyShift == 0)
          handleKeyRelease(16, location); 
      } else if (key == 16) {
        this.keyShift--;
        if (this.keyShift > 0)
          return; 
      } 
      handleKeyRelease(key, location);
    } else if (this.keytable[key][2] < 1024) {
      handleKeyRelease(key, location);
    } 
  }
  
  private int getNormalStick(int key) {
    switch (key) {
      case 104:
        return 0;
      case 98:
      case 101:
        return 1;
      case 100:
        return 2;
      case 102:
        return 3;
      case 96:
        return 4;
    } 
    return -1;
  }
  
  private void handleKeyPress(int key, int location) {
    int maprow = this.keytable[key][0];
    int mapcol = this.keytable[key][1];
    if (maprow != -1 && mapcol != -1) {
      this.keyrow[maprow] = this.keyrow[maprow] & 255 - (1 << this.keytable[key][1]);
      this.keycol[mapcol] = this.keycol[mapcol] & 255 - (1 << this.keytable[key][0]);
    } 
  }
  
  private void handleKeyRelease(int key, int location) {
    int maprow = this.keytable[key][0];
    int mapcol = this.keytable[key][1];
    if (maprow != -1 && mapcol != -1) {
      this.keyrow[maprow] = this.keyrow[maprow] | 1 << this.keytable[key][1];
      this.keycol[mapcol] = this.keycol[mapcol] | 1 << this.keytable[key][0];
    } 
    updateKeyboard();
  }
  
  int readDC00(int pc) {
    int val = 255;
    int tmp = (pc < 65536) ? this.joy1 : 255;
    int mask = (this.cia.prb | this.cia.ddrb ^ 0xFFFFFFFF) & tmp;
    for (int m = 1, i = 0; i < 8; m <<= 1, i++) {
      if ((mask & m) == 0)
        val &= this.keycol[i]; 
    } 
    tmp = (pc < 65536) ? this.joy2 : 255;
    return val & (this.cia.pra | this.cia.ddra ^ 0xFFFFFFFF) & tmp;
  }
  
  void setButtonval(int bval) {
    this.bval = bval;
    updateKeyboard();
  }
  
  int readDC01(int pc) {
    int val = 255;
    int tmp = (pc < 65536) ? (this.joy2 & this.bval) : 255;
    int mask = (this.cia.pra | this.cia.ddra ^ 0xFFFFFFFF) & tmp;
    for (int m = 1, i = 0; i < 8; m <<= 1, i++) {
      if ((mask & m) == 0)
        val &= this.keyrow[i]; 
    } 
    tmp = (pc < 65536) ? (this.joy1 & this.bval) : 255;
    return val & (this.cia.prb | this.cia.ddrb ^ 0xFFFFFFFF) & tmp;
  }
  
  void updateKeyboard() {
    int jst = this.joystick1 & this.bval;
    if ((jst & 0x3) == 0)
      jst = (jst | 0x3) & 255 - (this.lastUp ? 1 : 2); 
    if ((jst & 0xC) == 0)
      jst = (jst | 0xC) & 255 - (this.lastLeft ? 4 : 8); 
    this.joy2 = (this.stick == 68608) ? 255 : jst;
    this.joy1 = (this.stick == 68608) ? jst : 255;
    if (!this.ready && this.reads++ > 20) {
      this.ready = true;
      this.reads = 0;
    } 
  }
  
  public void reset() {
    this.lastKey = 0;
    this.keyPressed = 0;
    this.keyShift = 0;
    this.joystick1 = 255;
    this.reads = 0;
    this.ready = false;
    for (int i = 0; i < 8; i++) {
      this.keyrow[i] = 255;
      this.keycol[i] = 255;
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\Keyboard.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */