package com.dreamfabric.jac64;

public class DirEntry {
  public String name;
  
  public int trk;
  
  public int sec;
  
  public int size;
  
  public int type;
  
  public DirEntry(String name, int trk, int sec, int size, int type) {
    this.name = name;
    this.trk = trk;
    this.sec = sec;
    this.size = size;
    this.type = type;
  }
  
  public String getTypeString() {
    switch (this.type) {
      case 128:
        return " DEL ";
      case 129:
        return " SEQ ";
      case 130:
        return " PRG ";
      case 131:
        return " USR ";
      case 132:
        return " REL ";
    } 
    return "---";
  }
  
  public String toString() {
    String typeStr = getTypeString();
    return this.name + " (" + typeStr + ") " + this.size;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\DirEntry.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */