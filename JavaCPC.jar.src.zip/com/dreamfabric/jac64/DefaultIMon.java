package com.dreamfabric.jac64;

public class DefaultIMon implements IMonitor {
  int level = 0;
  
  String prefix = "";
  
  public void init(MOS6510Core cpu) {}
  
  public void setEnabled(boolean b) {}
  
  public boolean isEnabled() {
    return false;
  }
  
  public void info(Object o) {
    output((String)o);
  }
  
  public void setLevel(int level) {
    this.level = level;
  }
  
  public int getLevel() {
    return this.level;
  }
  
  public void warning(Object o) {
    output((String)o);
  }
  
  public void error(Object o) {
    output((String)o);
  }
  
  private void output(String s) {
    if (this.prefix != null) {
      if (s.startsWith(this.prefix))
        System.out.println(s); 
    } else {
      System.out.println(s);
    } 
  }
  
  public void disAssemble(int[] memory, int pc, int acc, int x, int y, byte status, int interruptInExec, int lastI) {}
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jac64\DefaultIMon.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */