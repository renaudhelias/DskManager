package com.dreamfabric.c64utils;

import java.lang.reflect.Method;
import java.util.ArrayList;

public class C64Script {
  int pos;
  
  public void test() {
    System.out.println("Test was called!!!");
  }
  
  public void test2(String arg1) {
    System.out.println("Test2 was called with arg:" + arg1);
  }
  
  public void enterText(String arg1) {
    System.out.println("enterText was called with arg:" + arg1);
  }
  
  private String getString(String line, char endChar) {
    StringBuffer sb = new StringBuffer();
    int max = line.length();
    while (this.pos < max) {
      char c = line.charAt(this.pos++);
      if (c == '\\') {
        sb.append(line.charAt(this.pos++));
        continue;
      } 
      if (c == endChar)
        return sb.toString(); 
      sb.append(c);
    } 
    throw new IllegalArgumentException("Illegal string syntax at: " + this.pos);
  }
  
  public void interpretCall(String line, Object callable) {
    System.out.println("Parsing: " + line);
    String fnName = "";
    this.pos = 0;
    int max = line.length();
    line.trim();
    char c;
    while (this.pos < max && (c = line.charAt(this.pos++)) != '(');
    fnName = line.substring(0, this.pos - 1);
    System.out.println("function name: " + fnName);
    ArrayList<String> args = new ArrayList();
    String value = "";
    while (this.pos < max) {
      Method[] methods;
      int i, n;
      c = line.charAt(this.pos++);
      switch (c) {
        case ',':
          if (value != "") {
            args.add(value);
            value = "";
            continue;
          } 
          throw new IllegalArgumentException("unexpected ',' at " + this.pos);
        case '"':
        case '\'':
          value = getString(line, c);
        case ')':
          if (value != "") {
            args.add(value);
            value = "";
          } 
          methods = callable.getClass().getMethods();
          for (i = 0, n = methods.length; i < n; i++) {
            if (fnName.equals(methods[i].getName())) {
              Method method = methods[i];
              System.out.println("Method found: " + method);
              Class[] pTypes = method.getParameterTypes();
              if (args.size() == pTypes.length) {
                System.out.println("Correct param number, calling method!");
                try {
                  method.invoke(callable, args.toArray());
                } catch (Exception e) {
                  e.printStackTrace();
                } 
              } 
            } 
          } 
          break;
      } 
      value = value + c;
    } 
  }
  
  public static void main(String[] args) {
    C64Script s = new C64Script();
    s.interpretCall(args[0], s);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\c64utils\C64Script.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */