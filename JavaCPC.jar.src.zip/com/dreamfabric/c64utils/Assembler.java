package com.dreamfabric.c64utils;

import com.dreamfabric.jac64.MOS6510Ops;
import java.io.InputStream;
import java.util.Hashtable;
import java.util.Vector;

public class Assembler {
  public static final int DEBUG_LEVEL = 0;
  
  public static final int CODE = 1;
  
  public static final int COMMENT = 2;
  
  public static final int REF_WORD = 0;
  
  public static final int REF_BYTE = 1;
  
  public static final int REF_BYTE_LO = 2;
  
  public static final int REF_BYTE_HI = 3;
  
  public static final int REF_RELATIVE = 4;
  
  public static final int[] REF_SIZE = new int[] { 2, 1, 1, 1, 1 };
  
  private int mode = 1;
  
  private int pos = 0;
  
  private int lastPos = 0;
  
  private Hashtable labels = new Hashtable<>();
  
  private Vector references = new Vector();
  
  private String currentLine;
  
  private String[] tokens;
  
  private int[] memory = new int[65536];
  
  private int lineNo;
  
  protected String workingDir;
  
  public void setMemory(int[] memory) {
    this.memory = memory;
  }
  
  public void setWorkingDir(String dir) {
    this.workingDir = dir;
    if (!this.workingDir.endsWith("/"))
      this.workingDir += "/"; 
    System.out.println("Set working dir to " + this.workingDir);
  }
  
  public int[] assemble(String s, int start) {
    String[] lines = split(s, "\n", false);
    this.labels.clear();
    this.references.removeAllElements();
    setPos(start);
    this.mode = 1;
    for (int i = 0, n = lines.length; i < n; i++) {
      this.currentLine = lines[i];
      if (assembleLine(lines[i], this.memory, this.pos) == 1)
        break; 
      this.lineNo++;
    } 
    resolve();
    return this.memory;
  }
  
  private void setPos(int start) {
    this.pos = start;
    this.lastPos = this.pos;
    System.out.println("Location set to: " + start);
  }
  
  private int assembleLine(String lineOrig, int[] memory, int adr) {
    String line = lineOrig;
    if (this.mode == 2) {
      if (line.endsWith("*/"))
        this.mode = 1; 
      return 0;
    } 
    if (line.startsWith("/*")) {
      this.mode = 2;
      return 0;
    } 
    this.tokens = split(line, " \t", true);
    if (this.tokens == null || this.tokens.length == 0)
      return 0; 
    String label = this.tokens[0].trim();
    if (this.tokens.length == 0 || (this.tokens.length == 1 && label.length() == 0))
      return 0; 
    if (label.equals(".end"))
      return 1; 
    String op = null;
    String operand = null;
    if (this.tokens.length > 1)
      op = this.tokens[1]; 
    if (this.tokens.length > 2)
      operand = this.tokens[2]; 
    if (label.length() > 0)
      if (addLabel(label, op, operand))
        return 0;  
    char c = op.charAt(0);
    if (c == '.') {
      if (op.equals(".word")) {
        this.pos += setValue(0, this.pos, operand, true);
      } else if (op.equals(".byte")) {
        this.pos += setValue(1, this.pos, operand, true);
      } else if (op.equals(".org")) {
        setPos(parseInt(operand));
      } else if (op.equals(".align")) {
        int al = parseInt(operand);
        System.out.println("Aligning to " + al);
        setPos(this.pos - (this.pos & al - 1) + al);
      } else if (op.equals(".binary")) {
        loadBinary(operand);
      } else if (op.equals(".wdir")) {
        setWorkingDir(operand);
      } else {
        error("unhandled operation '" + op + "'");
      } 
    } else if (op.equals("*=")) {
      setPos(resolve(operand, this.pos));
    } else {
      if (op.startsWith(";"))
        return 0; 
      int opI = MOS6510Ops.lookup(op);
      switch (opI) {
        case 8:
        case 16:
        case 25:
        case 42:
        case 56:
        case 67:
        case 74:
          setBranch(MOS6510Ops.lookup(opI, 2048), operand);
          this.lastPos = this.pos;
          return 0;
        case 0:
        case 4:
        case 6:
        case 9:
        case 15:
        case 17:
        case 18:
        case 22:
        case 26:
        case 27:
        case 31:
        case 34:
        case 39:
        case 40:
        case 44:
        case 45:
        case 53:
        case 55:
        case 57:
        case 58:
        case 64:
        case 65:
        case 68:
        case 73:
        case 75:
          memory[this.pos++] = MOS6510Ops.lookup(opI, 0);
          this.lastPos = this.pos;
          return 0;
        case 1:
        case 5:
        case 11:
        case 13:
        case 14:
        case 19:
        case 21:
        case 24:
        case 28:
        case 30:
        case 36:
        case 37:
        case 38:
        case 49:
        case 50:
        case 51:
        case 60:
        case 61:
        case 63:
        case 69:
        case 70:
        case 72:
          c = operand.charAt(0);
          if (c == '#') {
            setOP(opI, 256, this.pos++);
            this.pos += setValue(1, this.pos, operand.substring(1));
          } else if (c == '(') {
            String oplow = operand.toLowerCase();
            int adrMode = 3072;
            int size = 0;
            if (oplow.endsWith(")")) {
              operand = operand.substring(1, operand.length() - 1);
            } else if (oplow.endsWith(",x)")) {
              adrMode = 2304;
              size = 1;
              operand = operand.substring(1, operand.length() - 3);
            } else if (oplow.endsWith("),y")) {
              adrMode = 2560;
              size = 1;
              operand = operand.substring(1, operand.length() - 3);
            } else {
              error("Illegal syntax on indirection op " + op);
            } 
            setOP(opI, adrMode, this.pos++);
            this.pos += setValue(size, this.pos, operand);
          } else {
            String oplow = operand.toLowerCase();
            int adrMode = 768;
            int adrModeZ = 512;
            int size = 0;
            if (oplow.endsWith(",x")) {
              operand = operand.substring(0, operand.length() - 2);
              adrMode = 1536;
              adrModeZ = 1024;
            } else if (oplow.endsWith(",y")) {
              operand = operand.substring(0, operand.length() - 2);
              adrMode = 1792;
              adrModeZ = 1280;
            } 
            if (byteSize(operand)) {
              size = 1;
              adrMode = adrModeZ;
            } 
            setOP(opI, adrMode, this.pos++);
            this.pos += setValue(size, this.pos, operand);
          } 
          this.lastPos = this.pos;
          return 0;
        case 10:
          setOP(opI, 0, this.pos++);
          this.pos += setValue(0, this.pos, operand);
          this.lastPos = this.pos;
          return 0;
      } 
      error("Unhandled OP: '" + op + "' at " + hex4(this.pos));
    } 
    this.lastPos = this.pos;
    return 0;
  }
  
  private int handleStringConstant(int pos, String operand) {
    char c = operand.charAt(0);
    int num = 0;
    if (c == '"') {
      for (int i = 1, n = operand.length(); i < n; i++) {
        c = operand.charAt(i);
        if (c != '"') {
          this.memory[pos] = c;
          pos++;
          num++;
        } 
      } 
    } else if (c == '\'') {
      boolean stuffed = false;
      for (int i = 1, n = operand.length(); i < n; i++) {
        c = operand.charAt(i);
        if (c != '\'' || stuffed) {
          this.memory[pos] = c;
          pos++;
          num++;
          stuffed = false;
        } else {
          stuffed = true;
        } 
      } 
    } 
    return num;
  }
  
  public InputStream openBinary(String binary) {
    return null;
  }
  
  private void loadBinary(String binary) {
    try {
      if (this.workingDir == null)
        this.workingDir = ""; 
      InputStream fs = openBinary(this.workingDir + binary);
      if (fs == null)
        return; 
      int data = 0;
      int initPos = this.pos;
      while ((data = fs.read()) != -1)
        this.memory[this.pos++] = data & 0xFF; 
      System.out.println("Loaded binary file at: " + hex4(initPos) + " len: " + (this.pos - initPos));
      fs.close();
    } catch (Exception e) {
      error("Could not load binary file " + binary);
    } 
  }
  
  private void setOP(int opI, int mode, int pos) {
    int opR = MOS6510Ops.lookup(opI, mode);
    if (opR == -1)
      error(MOS6510Ops.modeString(mode) + " mode not available for " + MOS6510Ops.INS_STR[opI]); 
    this.memory[pos] = opR;
  }
  
  private int setValue(int type, int pos, String value) {
    return setValue(type, pos, value, false);
  }
  
  private int setValue(int type, int pos, String value, boolean allowArrays) {
    if (allowArrays) {
      char c = value.charAt(0);
      if (c == '\'' || c == '"') {
        int lp = this.currentLine.indexOf(c);
        return handleStringConstant(pos, this.currentLine.substring(lp));
      } 
      if (this.tokens.length > 3)
        return setValueArr(type, pos, this.tokens, 2); 
      if (value.indexOf(',') > 0) {
        String[] tok2 = split(value, ",", true);
        return setValueArr(type, pos, tok2, 0);
      } 
    } 
    int val = parseInt(value);
    if (val != -1) {
      setValue(type, pos, val);
      return REF_SIZE[type];
    } 
    createRef(type, pos, value);
    return REF_SIZE[type];
  }
  
  private int setValueArr(int type, int pos, String[] tokens, int start) {
    int len = 0;
    System.out.println("*** Possible array!!!");
    for (int i = start, n = tokens.length; i < n; i++) {
      if (tokens[i].startsWith(";"))
        return len; 
      if (tokens[i].indexOf(',') >= 0) {
        len += setValueArr(type, pos + len, split(tokens[i], ",", true), 0);
      } else {
        len += setValue(type, pos + len, tokens[i], false);
        System.out.println("Arr[" + (i - start) + "] = " + tokens[i]);
      } 
    } 
    return len;
  }
  
  private void setValue(int type, int pos, int value) {
    switch (type) {
      case 0:
        setWordValue(pos, value);
        break;
      case 3:
        setByteValue(pos, value >> 8);
        break;
      case 1:
      case 2:
        setByteValue(pos, value & 0xFF);
        break;
      case 4:
        setRelValue(pos, value);
        break;
    } 
  }
  
  private void error(String s) {
    throw new IllegalArgumentException(s + " at line " + this.lineNo);
  }
  
  private void resolve() {
    for (int i = 0, n = this.references.size(); i < n; i += 2) {
      String name = this.references.elementAt(i);
      int[] data = this.references.elementAt(i + 1);
      int type = data[0];
      int pos = data[1];
      int val = resolve(name, pos);
      setValue(type, pos, val);
    } 
  }
  
  private int resolve(String name, int pos) {
    char c = name.charAt(0);
    if (c == '<')
      return resolve(name.substring(1), pos) & 0xFF; 
    if (c == '>')
      return resolve(name.substring(1), pos) >> 8; 
    for (int i = 0, n = name.length(); i < n; i++) {
      c = name.charAt(i);
      if (c == '+')
        return resolve(name.substring(0, i), pos) + 
          resolve(name.substring(i + 1), pos); 
      if (c == '-')
        return resolve(name.substring(0, i), pos) - 
          resolve(name.substring(i + 1), pos); 
      if (c == '/')
        return resolve(name.substring(0, i), pos) / 
          resolve(name.substring(i + 1), pos); 
      if (c == '*')
        if (i == 0) {
          if (n == 1)
            return pos - 1; 
        } else {
          return resolve(name.substring(0, i), pos) * 
            resolve(name.substring(i + 1), pos);
        }  
    } 
    int adr = getLabelAddress(name);
    if (adr == -1) {
      int val = parseInt(name);
      if (val == -1)
        error("### Could not find label " + name); 
      return val;
    } 
    return adr;
  }
  
  private void setBranch(int op, String line) {
    this.memory[this.pos++] = op;
    setValue(4, this.pos, line);
    this.pos++;
  }
  
  private boolean byteSize(String s) {
    int x = parseInt(s);
    if (x != -1 && x < 256)
      return true; 
    return false;
  }
  
  public static int parseInt(String s) {
    char c = s.charAt(0);
    if (s.endsWith(",")) {
      s = s.substring(0, s.length() - 1);
      System.out.println("Ends with , => " + s);
    } 
    int val = -1;
    try {
      if (c == '$') {
        s = s.substring(1);
        val = Integer.parseInt(s, 16);
      } else if (c == '%') {
        s = s.substring(1);
        val = Integer.parseInt(s, 2);
      } else if (c == '@') {
        s = s.substring(1);
        val = Integer.parseInt(s, 8);
      } else {
        val = Integer.parseInt(s);
      } 
    } catch (Exception exception) {}
    return val;
  }
  
  private void setWordValue(int pos, int val) {
    this.memory[pos] = val & 0xFF;
    this.memory[pos + 1] = val >> 8 & 0xFF;
  }
  
  private void setByteValue(int pos, int val) {
    this.memory[pos] = val & 0xFF;
  }
  
  private void setRelValue(int pos, int val) {
    this.memory[pos] = val - pos + 1 & 0xFF;
  }
  
  private void createRef(int type, int pos, String s) {
    s = s.toLowerCase().trim();
    this.references.addElement(s);
    this.references.addElement(new int[] { type, pos });
  }
  
  private boolean addLabel(String label, String op, String operand) {
    if (label.startsWith(";"))
      return true; 
    boolean rval = false;
    if (op == null || (op != null && op.startsWith(";")))
      rval = true; 
    if ("*".equals(label)) {
      if ("=".equals(op)) {
        setPos(parseInt(operand));
        System.out.println("*** New location: " + hex4(this.pos));
      } 
      return true;
    } 
    int[] lpos = new int[1];
    if ("=".equals(op) || ".equ".equals(op)) {
      lpos[0] = parseInt(operand);
      rval = true;
    } else {
      if (".org".equals(op)) {
        setPos(parseInt(operand));
        rval = true;
      } 
      lpos[0] = this.pos;
    } 
    this.labels.put(label, lpos);
    return rval;
  }
  
  public int getLabelAddress(String label) {
    int[] lpos = (int[])this.labels.get(label);
    if (lpos != null)
      return lpos[0]; 
    return -1;
  }
  
  public void setByteValue(String label, int val) {
    System.out.println("Setting byte value of " + label + " to " + 
        Integer.toString(val, 16));
    int a = getLabelAddress(label);
    if (a != -1) {
      setByteValue(a, val);
    } else {
      throw new IllegalArgumentException("Can not find label: " + label);
    } 
  }
  
  public void setWordValue(String label, int val) {
    System.out.println("Setting word value of " + label + " to " + 
        Integer.toString(val, 16));
    int a = getLabelAddress(label);
    if (a != -1) {
      setWordValue(a, val);
    } else {
      throw new IllegalArgumentException("Can not find label: " + label);
    } 
  }
  
  private String hex4(int pos) {
    String s = null;
    if (pos < 16) {
      s = "$000";
    } else if (pos < 256) {
      s = "$00";
    } else if (pos < 4096) {
      s = "$0";
    } else {
      s = "$";
    } 
    return s + Integer.toString(pos, 16);
  }
  
  private String hex2(int pos) {
    String s = null;
    if (pos < 16) {
      s = "$0";
    } else {
      s = "$";
    } 
    return s + Integer.toString(pos, 16);
  }
  
  private static String[] split(String data, String splits, boolean trim) {
    Vector<String> strings = new Vector();
    int lastPos = 0;
    int mode = 0;
    for (int i = 0, n = data.length(); i < n; i++) {
      char c = data.charAt(i);
      if (splits.indexOf(c) != -1) {
        if (mode == 0) {
          if (lastPos != 0 && lastPos + 1 < n)
            lastPos++; 
          strings.addElement(data.substring(lastPos, i));
        } 
        lastPos = i;
        mode = 1;
      } else {
        mode = 0;
      } 
    } 
    if (lastPos != 0 && lastPos + 1 < data.length())
      lastPos++; 
    strings.addElement(data.substring(lastPos, data.length()));
    String[] retval = new String[strings.size()];
    for (int j = 0, k = retval.length; j < k; j++)
      retval[j] = strings.elementAt(j); 
    return retval;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\c64utils\Assembler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */