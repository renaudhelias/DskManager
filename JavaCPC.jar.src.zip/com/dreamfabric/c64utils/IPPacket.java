package com.dreamfabric.c64utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class IPPacket {
  byte[] data;
  
  byte[] header;
  
  public IPPacket() {}
  
  public IPPacket(byte[] header, byte[] data) {
    this.header = header;
    this.data = data;
  }
  
  public void readIPPacket(InputStream fs) throws IOException {
    byte[] header = new byte[20];
    int pos = 0;
    int c = 0;
    boolean startFound = false;
    while (pos < 20 && (c = fs.read()) != -1) {
      if (c == 69)
        startFound = true; 
      if (startFound)
        header[pos++] = (byte)c; 
    } 
    this.header = header;
    int dataLen = getTotalLength() - 20;
    this.data = new byte[dataLen];
    for (int i = 0, n = dataLen; i < n && (c = fs.read()) != -1; i++)
      this.data[i] = (byte)(c & 0xFF); 
  }
  
  public int getVersion() {
    return this.header[0] >> 4 & 0xF;
  }
  
  public int getHeaderLengthBytes() {
    return 4 * (this.header[0] & 0xF);
  }
  
  public int getServiceType() {
    return this.header[1] & 0xFF;
  }
  
  public int getTotalLength() {
    return get16(2);
  }
  
  public int getID() {
    return get16(4);
  }
  
  public int getFlags() {
    return this.header[6] >> 5 & 0x7;
  }
  
  public int getFragment0() {
    return (this.header[6] & 0x1F) << 8 + this.header[7];
  }
  
  public int getTTL() {
    return this.header[8] & 0xFF;
  }
  
  public int getProtocol() {
    return this.header[9] & 0xFF;
  }
  
  public int getChecksum() {
    return get16(10);
  }
  
  public long getSourceIP() {
    return get32(12);
  }
  
  public long getDestinationIP() {
    return get32(16);
  }
  
  int get16(int pos) {
    return (this.header[pos] & 0xFF) << 8 | this.header[pos + 1] & 0xFF;
  }
  
  long get32(int pos) {
    return (get16(pos) << 16L) + get16(pos + 2);
  }
  
  int getData8(int pos) {
    return this.data[pos] & 0xFF;
  }
  
  int getData16(int pos) {
    return (this.data[pos] & 0xFF) << 8 | this.data[pos + 1] & 0xFF;
  }
  
  long getData32(int pos) {
    return (get16(pos) << 16L) + get16(pos + 2);
  }
  
  public static String getIPStr(long adr) {
    return "" + (adr >> 24L & 0xFFL) + "." + (adr >> 16L & 0xFFL) + "." + (adr >> 8L & 0xFFL) + "." + (adr & 0xFFL);
  }
  
  public static void main(String[] args) throws IOException {
    FileInputStream fs = new FileInputStream("test.txt");
    IPPacket p = new IPPacket();
    p.readIPPacket(fs);
    System.out.println("---- IP Data -----");
    System.out.println("Version: " + p.getVersion());
    System.out.println("HDL: " + p.getHeaderLengthBytes());
    System.out.println("TotLen: " + p.getTotalLength());
    System.out.println("Protocol: " + p.getProtocol());
    System.out.println("IP Adr dst: " + getIPStr(p.getDestinationIP()));
    System.out.println("IP Adr src: " + getIPStr(p.getSourceIP()));
    if (p.getProtocol() == 6) {
      TCPPacket tcp = new TCPPacket(p);
      System.out.println("---- TCP Data -----");
      System.out.println("Source Port: " + tcp.getSourcePort());
      System.out.println("Destination Port: " + tcp.getDestinationPort());
      System.out.println("SeqNo: " + tcp.getSequenceNumber());
      System.out.println("TCP Header length: " + tcp
          .getTCPHeaderLengthBytes());
      int offset = tcp.getTCPHeaderLengthBytes();
      int len = tcp.getTotalLength() - tcp.getHeaderLengthBytes() - offset;
      System.out.println("Content: " + len);
      for (int i = 0, n = len; i < n; i++)
        System.out.print("" + (char)tcp.data[offset + i]); 
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\c64utils\IPPacket.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */