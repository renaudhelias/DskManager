package com.dreamfabric.jsidplay;

import com.dreamfabric.jac64.VICConstants;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JComponent;

public class SIDMixerDisplay extends JComponent {
  private static final int SAMPLE_SIZE = 512;
  
  private static final int STEP_SIZE = 4;
  
  private int[] sampleBuffer = new int[512];
  
  private int samplePos = 0;
  
  private boolean fftDone = false;
  
  private float[] fSamples = new float[512];
  
  private float[] fft;
  
  private static int[] COLOR_SET = VICConstants.COLOR_SETS[2];
  
  private static final Color PENCOLOR = new Color(COLOR_SET[14]);
  
  private static final Color BORDERCOLOR = new Color(COLOR_SET[6]);
  
  public SIDMixerDisplay() {
    setBackground(BORDERCOLOR);
    setForeground(PENCOLOR);
    setDoubleBuffered(true);
    setOpaque(true);
  }
  
  public Dimension getPreferredSize() {
    return new Dimension(240, 32);
  }
  
  public void updateSamples(int[] samples, int count) {
    for (int i = 0, n = count; i < n; i += 2)
      this.sampleBuffer[this.samplePos = (this.samplePos + 1) % 512] = samples[i]; 
    this.fftDone = false;
  }
  
  private void doFFT() {
    if (!this.fftDone) {
      for (int i = 0, n = 512; i < n; i++)
        this.fSamples[i] = this.sampleBuffer[i]; 
      this.fft = FastFourierTransform.fftMag(this.fSamples);
      this.fftDone = true;
    } 
  }
  
  public void paintComponent(Graphics g) {
    doFFT();
    int height = getHeight();
    int width = getWidth() - 4;
    float w = width * 0.49F / 128.0F;
    g.setColor(getBackground());
    g.fillRect(0, 0, getWidth(), height);
    g.setColor(getForeground());
    int last = height * this.sampleBuffer[this.samplePos % 512] / 16000;
    int i, n;
    for (i = 0, n = 511; i < n; i += 4) {
      int x = 2 + (int)(w * (i / 4));
      g.drawLine(x, height / 2 - last, x + 1, height / 2 - (last = height * this.sampleBuffer[(this.samplePos + i + 1) % 512] / 16000));
    } 
    this.fft[0] = 0.0F;
    for (i = 0, n = this.fft.length * 2 / 4; i < n; i++) {
      int fftI = (int)(this.fft[i] / 20.0D);
      int x = 4 + width / 2 + (int)(w * i);
      g.fillRect(x, height - fftI, 1, fftI);
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jsidplay\SIDMixerDisplay.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */