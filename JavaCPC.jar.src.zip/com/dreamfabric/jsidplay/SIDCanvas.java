package com.dreamfabric.jsidplay;

import com.dreamfabric.jac64.SIDVoice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JComponent;

public class SIDCanvas extends JComponent {
  SIDVoice sid;
  
  private static final int ADSR_SIZE = 81;
  
  private static final int FRQ_SIZE = 81;
  
  private static final int SAMPLE_SIZE = 110;
  
  private int[] adsrBuffer = new int[81];
  
  private int[] frqBuffer = new int[81];
  
  private int[] sampleBuffer = new int[110];
  
  private int samplePos = 0;
  
  private int adsrPos;
  
  private int frqPos;
  
  private static final Color PENCOLOR = new Color(49152);
  
  private static final Color BORDERCOLOR = new Color(2113568);
  
  public SIDCanvas(SIDVoice sid) {
    this.sid = sid;
    setFont(new Font("Monospaced", 0, 10));
    setForeground(Color.green);
    setBackground(Color.black);
    setOpaque(true);
    setDoubleBuffered(true);
  }
  
  public Dimension getPreferredSize() {
    return new Dimension(282, 80);
  }
  
  public void updateADSR(double value) {
    this.adsrBuffer[this.adsrPos] = (int)(value * 1000.0D);
    this.adsrPos = (this.adsrPos + 1) % 81;
  }
  
  public void updateFRQ(long value) {
    value /= 8L;
    if (value > 128L)
      value = 128L; 
    this.frqBuffer[this.frqPos] = (int)value;
    this.frqPos = (this.frqPos + 1) % 81;
  }
  
  public void updateSamples(int[] samples, int count) {
    for (int i = 0, n = count; i < n; i += 2)
      this.sampleBuffer[this.samplePos = (this.samplePos + 1) % 110] = samples[i]; 
  }
  
  public void paintComponent(Graphics g) {
    int height = getHeight();
    g.setColor(PENCOLOR);
    g.drawString("Osc Output", 6, 10);
    int last = height * this.sampleBuffer[this.samplePos % 110] / 16000;
    for (int i = 0, n = 109; i < n; i++)
      g.drawLine(i, height - 10 - last, i + 1, height - 10 - (last = height * this.sampleBuffer[(this.samplePos + i + 1) % 110] / 16000)); 
    int pos = 115;
    g.drawString("ADSR Lv", pos, 10);
    int j, k;
    for (j = 0, k = 80; j < k; j++) {
      int ix = (this.adsrPos + j + 81) % 81;
      g.drawLine(pos + j, height - 10 - height * this.adsrBuffer[ix] / 1500, j + pos + 1, height - 10 - height * this.adsrBuffer[(ix + 1) % 81] / 1500);
    } 
    pos += 86;
    g.drawString("Freq.", pos, 10);
    for (j = 0, k = 80; j < k; j++) {
      int ix = (this.adsrPos + j + 81) % 81;
      g.drawLine(pos + j, height - 10 - height * this.frqBuffer[ix] / 200, j + pos + 1, height - 10 - height * this.frqBuffer[(ix + 1) % 81] / 200);
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jsidplay\SIDCanvas.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */