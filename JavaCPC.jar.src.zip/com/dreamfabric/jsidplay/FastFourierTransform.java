package com.dreamfabric.jsidplay;

public final class FastFourierTransform {
  private static int bitrev(int j, int nu) {
    int j1 = j;
    int k = 0;
    for (int i = 1; i <= nu; i++) {
      int j2 = j1 / 2;
      k = 2 * k + j1 - 2 * j2;
      j1 = j2;
    } 
    return k;
  }
  
  public static final float[] fftMag(float[] x) {
    int n = x.length;
    int nu = (int)(Math.log(n) / Math.log(2.0D));
    int n2 = n / 2;
    int nu1 = nu - 1;
    float[] xre = new float[n];
    float[] xim = new float[n];
    float[] mag = new float[n2];
    for (int i = 0; i < n; i++) {
      xre[i] = x[i];
      xim[i] = 0.0F;
    } 
    int k = 0;
    for (int l = 1; l <= nu; l++) {
      while (k < n) {
        for (int m = 1; m <= n2; m++) {
          float p = bitrev(k >> nu1, nu);
          float arg = 6.2831855F * p / n;
          float c = (float)Math.cos(arg);
          float s = (float)Math.sin(arg);
          float tr = xre[k + n2] * c + xim[k + n2] * s;
          float ti = xim[k + n2] * c - xre[k + n2] * s;
          xre[k + n2] = xre[k] - tr;
          xim[k + n2] = xim[k] - ti;
          xre[k] = xre[k] + tr;
          xim[k] = xim[k] + ti;
          k++;
        } 
        k += n2;
      } 
      k = 0;
      nu1--;
      n2 /= 2;
    } 
    k = 0;
    while (k < n) {
      int r = bitrev(k, nu);
      if (r > k) {
        float tr = xre[k];
        float ti = xim[k];
        xre[k] = xre[r];
        xim[k] = xim[r];
        xre[r] = tr;
        xim[r] = ti;
      } 
      k++;
    } 
    mag[0] = (float)Math.sqrt((xre[0] * xre[0] + xim[0] * xim[0])) / n;
    for (int j = 1; j < n / 2; j++)
      mag[j] = 2.0F * (float)Math.sqrt((xre[j] * xre[j] + xim[j] * xim[j])) / n; 
    return mag;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jsidplay\FastFourierTransform.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */