package com.dreamfabric.jsidplay;

import com.dreamfabric.jac64.SIDMixer;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JComponent;

public class PSIDCanvas extends JComponent {
  private static final int CUTOFF_SIZE = 81;
  
  private static final int RESONANCE_SIZE = 81;
  
  private static final int SAMPLE_SIZE = 110;
  
  private int[] cutoffBuffer = new int[81];
  
  private int[] resonanceBuffer = new int[81];
  
  private int[] sampleBuffer = new int[110];
  
  private int cutoffPos;
  
  private int resonancePos;
  
  private static final Color PENCOLOR = new Color(49152);
  
  private static final Color BORDERCOLOR = new Color(2113568);
  
  private SIDMixer mixer;
  
  PSID psid;
  
  public PSIDCanvas(PSID psid, SIDMixer mix) {
    this.psid = psid;
    this.mixer = mix;
    setFont(new Font("Monospaced", 0, 10));
    setForeground(Color.green);
    setBackground(Color.black);
    setOpaque(true);
    setDoubleBuffered(true);
  }
  
  public Dimension getPreferredSize() {
    return new Dimension(282, 80);
  }
  
  public void updateFilter(int cutoff, int resonance) {
    this.cutoffBuffer[this.cutoffPos] = cutoff >> 5;
    this.cutoffPos = (this.cutoffPos + 1) % 81;
    this.resonanceBuffer[this.resonancePos] = resonance << 2;
    this.resonancePos = (this.resonancePos + 1) % 81;
  }
  
  public void paintComponent(Graphics g) {
    boolean quiet = true;
    int height = getHeight();
    if (this.psid.lastPlayedSample < 4) {
      quiet = false;
      int playPos = this.psid.playSamplePos;
      if (playPos + 880 > this.psid.sampleEnd) {
        playPos = this.psid.sampleEnd - 880;
        if (playPos < 0)
          playPos = 0; 
      } 
      for (int j = 0, k = 110; j < k; j++)
        this.sampleBuffer[j] = this.psid.buffer[(j << 3) + playPos]; 
    } 
    g.setColor(PENCOLOR);
    g.drawString("Sample Output", 6, 10);
    if (!quiet)
      for (int j = 0, k = 109; j < k; j++)
        g.drawLine(j, height - 10 - height * (this.sampleBuffer[j] >> 1) / 128, j + 1, height - 10 - height * (this.sampleBuffer[j + 1] >> 1) / 128);  
    int pos = 115;
    g.drawString("Flt.Cutoff", pos, 10);
    int i, n;
    for (i = 0, n = 80; i < n; i++) {
      int ix = (this.cutoffPos + i + 81) % 81;
      g.drawLine(pos + i, height - 10 - height * this.cutoffBuffer[ix] / 128, i + pos + 1, height - 10 - height * this.cutoffBuffer[(ix + 1) % 81] / 128);
    } 
    pos += 86;
    g.drawString("Flt.Res.", pos, 10);
    for (i = 0, n = 80; i < n; i++) {
      int ix = (this.resonancePos + i + 81) % 81;
      g.drawLine(pos + i, height - 10 - height * this.resonanceBuffer[ix] / 128, i + pos + 1, height - 10 - height * this.resonanceBuffer[(ix + 1) % 81] / 128);
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\com\dreamfabric\jsidplay\PSIDCanvas.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */