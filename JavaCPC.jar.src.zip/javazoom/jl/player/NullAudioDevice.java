package javazoom.jl.player;

public class NullAudioDevice extends AudioDeviceBase {
  public int getPosition() {
    return 0;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\javazoom\jl\player\NullAudioDevice.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */