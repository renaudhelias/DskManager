package javazoom.jl.player.advanced;

public abstract class PlaybackListener {
  public void playbackStarted(PlaybackEvent evt) {}
  
  public void playbackFinished(PlaybackEvent evt) {}
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\javazoom\jl\player\advanced\PlaybackListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */