package javazoom.jl.decoder;

import java.io.PrintStream;

public class JavaLayerException extends Exception {
  private Throwable exception;
  
  public JavaLayerException() {}
  
  public JavaLayerException(String msg) {
    super(msg);
  }
  
  public JavaLayerException(String msg, Throwable t) {
    super(msg);
    this.exception = t;
  }
  
  public Throwable getException() {
    return this.exception;
  }
  
  public void printStackTrace() {
    printStackTrace(System.err);
  }
  
  public void printStackTrace(PrintStream ps) {
    if (this.exception == null) {
      super.printStackTrace(ps);
    } else {
      this.exception.printStackTrace();
    } 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\javazoom\jl\decoder\JavaLayerException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */