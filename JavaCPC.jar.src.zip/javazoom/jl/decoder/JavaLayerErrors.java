package javazoom.jl.decoder;

public interface JavaLayerErrors {
  public static final int BITSTREAM_ERROR = 256;
  
  public static final int DECODER_ERROR = 512;
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\javazoom\jl\decoder\JavaLayerErrors.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */