package javazoom.jl.decoder;

import java.io.InputStream;

public interface JavaLayerHook {
  InputStream getResourceAsStream(String paramString);
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\javazoom\jl\decoder\JavaLayerHook.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */