package javazoom.jl.decoder;

import java.io.IOException;

public interface Source {
  public static final long LENGTH_UNKNOWN = -1L;
  
  int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
  
  boolean willReadBlock();
  
  boolean isSeekable();
  
  long length();
  
  long tell();
  
  long seek(long paramLong);
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\javazoom\jl\decoder\Source.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */