package javazoom.jl.decoder;

public interface Control {
  void start();
  
  void stop();
  
  boolean isPlaying();
  
  void pause();
  
  boolean isRandomAccess();
  
  double getPosition();
  
  void setPosition(double paramDouble);
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\javazoom\jl\decoder\Control.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */