package javazoom.jl.decoder;

public class Manager {
  public void addControl(Control c) {}
  
  public void removeControl(Control c) {}
  
  public void removeAll() {}
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\javazoom\jl\decoder\Manager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */