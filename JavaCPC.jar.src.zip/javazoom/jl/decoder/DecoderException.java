package javazoom.jl.decoder;

public class DecoderException extends JavaLayerException implements DecoderErrors {
  private int errorcode = 512;
  
  public DecoderException(String msg, Throwable t) {
    super(msg, t);
  }
  
  public DecoderException(int errorcode, Throwable t) {
    this(getErrorString(errorcode), t);
    this.errorcode = errorcode;
  }
  
  public int getErrorCode() {
    return this.errorcode;
  }
  
  public static String getErrorString(int errorcode) {
    return "Decoder errorcode " + Integer.toHexString(errorcode);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\javazoom\jl\decoder\DecoderException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */