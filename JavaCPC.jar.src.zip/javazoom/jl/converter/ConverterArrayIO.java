package javazoom.jl.converter;

import java.io.IOException;

public class ConverterArrayIO implements ConverterIO {
  private SeekableByteArrayOutputStream _out = null;
  
  public ConverterArrayIO() {
    this._out = new SeekableByteArrayOutputStream();
  }
  
  public byte[] toByteArray() {
    return this._out.toByteArray();
  }
  
  public void close() throws IOException {
    this._out.close();
  }
  
  public void seek(long position) throws IOException {
    this._out.seek(position);
  }
  
  public long tell() throws IOException {
    return this._out.tell();
  }
  
  public int read() throws IOException {
    throw new IOException("ConverterArrayIO read not supported");
  }
  
  public int read(byte[] b, int off, int len) throws IOException {
    throw new IOException("ConverterArrayIO read not supported");
  }
  
  public void write(int b) throws IOException {
    this._out.write(b);
  }
  
  public void write(byte[] b, int off, int len) throws IOException {
    this._out.write(b, off, len);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\javazoom\jl\converter\ConverterArrayIO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */