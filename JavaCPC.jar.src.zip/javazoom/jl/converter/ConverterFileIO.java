package javazoom.jl.converter;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class ConverterFileIO implements ConverterIO {
  private RandomAccessFile _file = null;
  
  public ConverterFileIO(String name) throws FileNotFoundException {
    this._file = new RandomAccessFile(name, "rw");
  }
  
  public void close() throws IOException {
    if (this._file != null) {
      this._file.close();
      this._file = null;
    } 
  }
  
  public void seek(long position) throws IOException {
    this._file.seek(position);
  }
  
  public long tell() throws IOException {
    return this._file.getFilePointer();
  }
  
  public int read() throws IOException {
    return this._file.read();
  }
  
  public int read(byte[] b, int off, int len) throws IOException {
    return this._file.read(b, off, len);
  }
  
  public void write(int b) throws IOException {
    this._file.write(b);
  }
  
  public void write(byte[] b, int off, int len) throws IOException {
    this._file.write(b, off, len);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\javazoom\jl\converter\ConverterFileIO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */