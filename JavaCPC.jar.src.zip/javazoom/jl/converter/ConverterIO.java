package javazoom.jl.converter;

import java.io.IOException;

public interface ConverterIO {
  void close() throws IOException;
  
  void seek(long paramLong) throws IOException;
  
  long tell() throws IOException;
  
  int read() throws IOException;
  
  int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
  
  void write(int paramInt) throws IOException;
  
  void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\javazoom\jl\converter\ConverterIO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */