package JCPC.system.cpc.plus;

public class ASIC_DATA {
  int ASIC_InterruptVector = 255;
  
  int ASIC_RasterInterruptLine;
  
  int ASIC_SoftScroll;
  
  boolean ASIC_PRI_Request;
  
  int ASIC_RasterSplitLine;
  
  int InterruptRequest;
  
  int ASIC_DCSR2;
  
  public ASIC_DMA_CHANNEL[] pChannel = new ASIC_DMA_CHANNEL[] { new ASIC_DMA_CHANNEL(), new ASIC_DMA_CHANNEL(), new ASIC_DMA_CHANNEL() };
  
  public ASIC_DMA[] DMA = new ASIC_DMA[] { new ASIC_DMA(), new ASIC_DMA(), new ASIC_DMA() };
  
  public ASIC_SPRITE_INFO[] Sprites = new ASIC_SPRITE_INFO[] { 
      new ASIC_SPRITE_INFO(), new ASIC_SPRITE_INFO(), new ASIC_SPRITE_INFO(), new ASIC_SPRITE_INFO(), new ASIC_SPRITE_INFO(), new ASIC_SPRITE_INFO(), new ASIC_SPRITE_INFO(), new ASIC_SPRITE_INFO(), new ASIC_SPRITE_INFO(), new ASIC_SPRITE_INFO(), 
      new ASIC_SPRITE_INFO(), new ASIC_SPRITE_INFO(), new ASIC_SPRITE_INFO(), new ASIC_SPRITE_INFO(), new ASIC_SPRITE_INFO(), new ASIC_SPRITE_INFO() };
  
  public class SPRITE_X {
    public int SpriteX_Bl;
    
    public int SpriteX_Bh;
    
    public void writeAddr_W(int word) {
      this.SpriteX_Bl = word & 0xFF;
      this.SpriteX_Bh = word >> 8 & 0xFF;
    }
    
    public int getAddr_W() {
      return this.SpriteX_Bl & 0xFF | this.SpriteX_Bh << 8 & 0xFF00;
    }
  }
  
  public class SPRITE_Y {
    public int SpriteY_Bl;
    
    public int SpriteY_Bh;
    
    public void writeAddr_W(int word) {
      this.SpriteY_Bl = word & 0xFF;
      this.SpriteY_Bh = word >> 8 & 0xFF;
    }
    
    public int getAddr_W() {
      return this.SpriteY_Bl & 0xFF | this.SpriteY_Bh << 8 & 0xFF00;
    }
  }
  
  public class ASIC_SPRITE_INFO {
    public ASIC_DATA.SPRITE_X SpriteX = new ASIC_DATA.SPRITE_X();
    
    public ASIC_DATA.SPRITE_Y SpriteY = new ASIC_DATA.SPRITE_Y();
    
    public int SpriteX_W;
    
    ASIC_ADDR SpriteX_B = new ASIC_ADDR();
    
    ASIC_ADDR SpriteY_W = new ASIC_ADDR();
    
    ASIC_ADDR SpriteY_B = new ASIC_ADDR();
    
    public int SpriteMag;
    
    public int[] pad = new int[3];
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\system\cpc\plus\ASIC_DATA.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */