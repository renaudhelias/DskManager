package JCPC.system.cpc.plus;

public class ASIC_ADDR {
  public addrb Addr_B = new addrb();
  
  public void writeAddr_W(int word) {
    this.Addr_B.l = word & 0xFF;
    this.Addr_B.h = word >> 8 & 0xFF;
  }
  
  public void writeAddr(int word) {
    this.Addr_B.h = word & 0xFF;
    this.Addr_B.l = word >> 8 & 0xFF;
  }
  
  class addrb {
    public int l;
    
    public int h;
  }
  
  public int getAddr_W() {
    return this.Addr_B.l & 0xFF | this.Addr_B.h << 8 & 0xFF00;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\system\cpc\plus\ASIC_ADDR.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */