package JCPC.system.cpc;

import com.nilo.plaf.nimrod.NimRODLookAndFeel;
import com.nilo.plaf.nimrod.NimRODTheme;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;
import javax.swing.LookAndFeel;
import javax.swing.UIManager;
import javax.swing.plaf.metal.MetalTheme;

public class CSDGui extends JFrame {
  boolean enabled;
  
  private ButtonGroup buttonGroup1;
  
  public JTextField cpr01;
  
  public JTextField cpr02;
  
  public JTextField cpr03;
  
  public JTextField cpr04;
  
  public JTextField cpr05;
  
  public JTextField cpr06;
  
  public JTextField cpr07;
  
  public JTextField cpr08;
  
  public JTextField cpr09;
  
  public JTextField cpr10;
  
  public JTextField cpr11;
  
  public JTextField cpr12;
  
  public JButton csdmode;
  
  private JLabel jLabel1;
  
  private JPanel jPanel1;
  
  public JRadioButton jRadioButton1;
  
  public JRadioButton jRadioButton2;
  
  public JRadioButton jRadioButton3;
  
  public JRadioButton jRadioButton4;
  
  public JRadioButton jRadioButton5;
  
  public JButton load1;
  
  public JButton load10;
  
  public JButton load11;
  
  public JButton load12;
  
  public JButton load2;
  
  public JButton load3;
  
  public JButton load4;
  
  public JButton load5;
  
  public JButton load6;
  
  public JButton load7;
  
  public JButton load8;
  
  public JButton load9;
  
  public JButton shuffle;
  
  public CSDGui() {
    initComponents();
  }
  
  public void setCSD(boolean in) {
    this.enabled = in;
    checkEnabled();
  }
  
  protected void checkEnabled() {
    this.enabled = !this.enabled;
    this.cpr01.setEnabled(this.enabled);
    this.cpr02.setEnabled(this.enabled);
    this.cpr03.setEnabled(this.enabled);
    this.cpr04.setEnabled(this.enabled);
    this.cpr05.setEnabled(this.enabled);
    this.cpr06.setEnabled(this.enabled);
    this.cpr07.setEnabled(this.enabled);
    this.cpr08.setEnabled(this.enabled);
    this.cpr09.setEnabled(this.enabled);
    this.cpr10.setEnabled(this.enabled);
    this.cpr11.setEnabled(this.enabled);
    this.cpr12.setEnabled(this.enabled);
    this.load1.setEnabled(this.enabled);
    this.load2.setEnabled(this.enabled);
    this.load3.setEnabled(this.enabled);
    this.load4.setEnabled(this.enabled);
    this.load5.setEnabled(this.enabled);
    this.load6.setEnabled(this.enabled);
    this.load7.setEnabled(this.enabled);
    this.load8.setEnabled(this.enabled);
    this.load9.setEnabled(this.enabled);
    this.load10.setEnabled(this.enabled);
    this.load11.setEnabled(this.enabled);
    this.load12.setEnabled(this.enabled);
  }
  
  private void initComponents() {
    this.buttonGroup1 = new ButtonGroup();
    this.cpr01 = new JTextField();
    this.cpr02 = new JTextField();
    this.cpr04 = new JTextField();
    this.cpr03 = new JTextField();
    this.cpr06 = new JTextField();
    this.cpr05 = new JTextField();
    this.load2 = new JButton();
    this.load1 = new JButton();
    this.load3 = new JButton();
    this.load5 = new JButton();
    this.load4 = new JButton();
    this.load6 = new JButton();
    this.load7 = new JButton();
    this.load8 = new JButton();
    this.load9 = new JButton();
    this.load10 = new JButton();
    this.load11 = new JButton();
    this.load12 = new JButton();
    this.cpr12 = new JTextField();
    this.cpr11 = new JTextField();
    this.cpr10 = new JTextField();
    this.cpr07 = new JTextField();
    this.cpr09 = new JTextField();
    this.cpr08 = new JTextField();
    this.jPanel1 = new JPanel();
    this.jLabel1 = new JLabel();
    this.jRadioButton1 = new JRadioButton();
    this.jRadioButton2 = new JRadioButton();
    this.jRadioButton3 = new JRadioButton();
    this.jRadioButton4 = new JRadioButton();
    this.jRadioButton5 = new JRadioButton();
    this.shuffle = new JButton();
    this.csdmode = new JButton();
    setTitle("CSD Cartridge Panel");
    setResizable(false);
    this.cpr01.setHorizontalAlignment(4);
    this.cpr01.setText("<empty>");
    this.cpr01.setFocusable(false);
    this.cpr02.setHorizontalAlignment(4);
    this.cpr02.setText("<empty>");
    this.cpr02.setFocusable(false);
    this.cpr04.setHorizontalAlignment(4);
    this.cpr04.setText("<empty>");
    this.cpr04.setFocusable(false);
    this.cpr03.setHorizontalAlignment(4);
    this.cpr03.setText("<empty>");
    this.cpr03.setFocusable(false);
    this.cpr06.setHorizontalAlignment(4);
    this.cpr06.setText("<empty>");
    this.cpr06.setFocusable(false);
    this.cpr05.setHorizontalAlignment(4);
    this.cpr05.setText("<empty>");
    this.cpr05.setFocusable(false);
    this.load2.setText("...");
    this.load2.setFocusPainted(false);
    this.load2.setFocusable(false);
    this.load1.setText("...");
    this.load1.setFocusPainted(false);
    this.load1.setFocusable(false);
    this.load3.setText("...");
    this.load3.setFocusPainted(false);
    this.load3.setFocusable(false);
    this.load5.setText("...");
    this.load5.setFocusPainted(false);
    this.load5.setFocusable(false);
    this.load4.setText("...");
    this.load4.setFocusPainted(false);
    this.load4.setFocusable(false);
    this.load6.setText("...");
    this.load6.setFocusPainted(false);
    this.load6.setFocusable(false);
    this.load7.setText("...");
    this.load7.setFocusPainted(false);
    this.load7.setFocusable(false);
    this.load8.setText("...");
    this.load8.setFocusPainted(false);
    this.load8.setFocusable(false);
    this.load9.setText("...");
    this.load9.setFocusPainted(false);
    this.load9.setFocusable(false);
    this.load10.setText("...");
    this.load10.setFocusPainted(false);
    this.load10.setFocusable(false);
    this.load11.setText("...");
    this.load11.setFocusPainted(false);
    this.load11.setFocusable(false);
    this.load12.setText("...");
    this.load12.setFocusPainted(false);
    this.load12.setFocusable(false);
    this.cpr12.setHorizontalAlignment(4);
    this.cpr12.setText("<empty>");
    this.cpr12.setFocusable(false);
    this.cpr11.setHorizontalAlignment(4);
    this.cpr11.setText("<empty>");
    this.cpr11.setFocusable(false);
    this.cpr10.setHorizontalAlignment(4);
    this.cpr10.setText("<empty>");
    this.cpr10.setFocusable(false);
    this.cpr07.setHorizontalAlignment(4);
    this.cpr07.setText("<empty>");
    this.cpr07.setFocusable(false);
    this.cpr09.setHorizontalAlignment(4);
    this.cpr09.setText("<empty>");
    this.cpr09.setFocusable(false);
    this.cpr08.setHorizontalAlignment(4);
    this.cpr08.setText("<empty>");
    this.cpr08.setFocusable(false);
    this.jPanel1.setLayout(new FlowLayout(1, 2, 5));
    this.jLabel1.setFont(new Font("Dialog", 0, 11));
    this.jLabel1.setText("Timer");
    this.jPanel1.add(this.jLabel1);
    this.buttonGroup1.add(this.jRadioButton1);
    this.jRadioButton1.setFont(new Font("Dialog", 0, 11));
    this.jRadioButton1.setSelected(true);
    this.jRadioButton1.setText("Off");
    this.jRadioButton1.setFocusPainted(false);
    this.jRadioButton1.setFocusable(false);
    this.jPanel1.add(this.jRadioButton1);
    this.buttonGroup1.add(this.jRadioButton2);
    this.jRadioButton2.setFont(new Font("Dialog", 0, 11));
    this.jRadioButton2.setText("8s");
    this.jRadioButton2.setFocusPainted(false);
    this.jRadioButton2.setFocusable(false);
    this.jPanel1.add(this.jRadioButton2);
    this.buttonGroup1.add(this.jRadioButton3);
    this.jRadioButton3.setFont(new Font("Dialog", 0, 11));
    this.jRadioButton3.setText("16s");
    this.jRadioButton3.setFocusPainted(false);
    this.jRadioButton3.setFocusable(false);
    this.jPanel1.add(this.jRadioButton3);
    this.buttonGroup1.add(this.jRadioButton4);
    this.jRadioButton4.setFont(new Font("Dialog", 0, 11));
    this.jRadioButton4.setText("32s");
    this.jRadioButton4.setFocusPainted(false);
    this.jRadioButton4.setFocusable(false);
    this.jPanel1.add(this.jRadioButton4);
    this.buttonGroup1.add(this.jRadioButton5);
    this.jRadioButton5.setFont(new Font("Dialog", 0, 11));
    this.jRadioButton5.setText("66s");
    this.jRadioButton5.setFocusPainted(false);
    this.jRadioButton5.setFocusable(false);
    this.jPanel1.add(this.jRadioButton5);
    this.shuffle.setFont(new Font("Dialog", 0, 11));
    this.shuffle.setText("Shuffle");
    this.shuffle.setFocusPainted(false);
    this.shuffle.setFocusable(false);
    this.jPanel1.add(this.shuffle);
    this.csdmode.setFont(new Font("Dialog", 0, 11));
    this.csdmode.setText("Exit CSD Mode");
    this.csdmode.setFocusPainted(false);
    this.csdmode.setFocusable(false);
    this.csdmode.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            CSDGui.this.csdmodeActionPerformed(evt);
          }
        });
    this.jPanel1.add(this.csdmode);
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
              .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                  .addComponent(this.cpr01, -2, 120, -2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.load1)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.cpr02, -2, 120, -2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.load2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.cpr03, -2, 120, -2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.load3))
                .addGroup(layout.createSequentialGroup()
                  .addComponent(this.cpr04, -2, 120, -2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.load4)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.cpr05, -2, 120, -2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.load5)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.cpr06, -2, 120, -2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.load6)))
              .addContainerGap(-1, 32767))
            .addGroup(layout.createSequentialGroup()
              .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                  .addComponent(this.cpr07, -2, 120, -2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.load7)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.cpr08, -2, 120, -2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.load8)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.cpr09, -2, 120, -2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.load9))
                .addGroup(layout.createSequentialGroup()
                  .addComponent(this.cpr10, -2, 120, -2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.load10)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.cpr11, -2, 120, -2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.load11)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.cpr12, -2, 120, -2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.load12)))
              .addGap(0, 0, 32767))))
        .addComponent(this.jPanel1, -1, -1, 32767));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap(-1, 32767)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.cpr01, -2, -1, -2)
            .addComponent(this.load1)
            .addComponent(this.cpr02, -2, -1, -2)
            .addComponent(this.load2)
            .addComponent(this.cpr03, -2, -1, -2)
            .addComponent(this.load3))
          .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.cpr04, -2, -1, -2)
            .addComponent(this.load4)
            .addComponent(this.cpr05, -2, -1, -2)
            .addComponent(this.load5)
            .addComponent(this.cpr06, -2, -1, -2)
            .addComponent(this.load6))
          .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.cpr07, -2, -1, -2)
            .addComponent(this.load7)
            .addComponent(this.cpr08, -2, -1, -2)
            .addComponent(this.load8)
            .addComponent(this.cpr09, -2, -1, -2)
            .addComponent(this.load9))
          .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.cpr10, -2, -1, -2)
            .addComponent(this.load10)
            .addComponent(this.cpr11, -2, -1, -2)
            .addComponent(this.load11)
            .addComponent(this.cpr12, -2, -1, -2)
            .addComponent(this.load12))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(this.jPanel1, -2, -1, -2)));
    pack();
  }
  
  private void csdmodeActionPerformed(ActionEvent evt) {
    checkEnabled();
  }
  
  public static void main(String[] args) {
    try {
      NimRODTheme nt = new NimRODTheme();
      Color flow1 = new Color(4915205);
      Color flow3 = new Color(15397362);
      Color black = new Color(4802644);
      Color white = new Color(16777215);
      Color sec1 = new Color(10747936);
      Color sec2 = new Color(9647933);
      Color sec3 = new Color(16184554);
      Color select = new Color(10747936);
      nt.setPrimary(white);
      nt.setSecondary(white);
      nt.setPrimary1(flow1);
      nt.setPrimary3(flow3);
      nt.setPrimary2(select);
      nt.setSecondary1(sec1);
      nt.setSecondary2(sec2);
      nt.setSecondary3(sec3);
      nt.setBlack(black);
      nt.setWhite(white);
      nt.setMenuOpacity(195);
      nt.setFrameOpacity(120);
      NimRODLookAndFeel NimRODLF = new NimRODLookAndFeel();
      NimRODLookAndFeel.setCurrentTheme((MetalTheme)nt);
      UIManager.setLookAndFeel((LookAndFeel)NimRODLF);
    } catch (Exception exception) {}
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new CSDGui()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\system\cpc\CSDGui.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */