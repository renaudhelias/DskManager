package JCPC.system.cpc;

import JCPC.core.device.crtc.Basic6845;
import JCPC.core.device.crtc.CRTCListener;
import JCPC.core.device.crtc.Slider;
import JCPC.core.renderer.MonitorRenderer;
import JCPC.ui.Display;
import JCPC.ui.GX4000;
import java.awt.Dimension;

public final class GateArray extends MonitorRenderer implements CRTCListener {
  public static final int lowlines = 280;
  
  public static final int highlines = 560;
  
  protected int borderHeight;
  
  public int getBorder() {
    return inks[16];
  }
  
  public int getPaper() {
    return inks[0];
  }
  
  protected static final GraphicsDecoder decoder = new GraphicsDecoder();
  
  protected final int HOFFSET = 686080;
  
  protected final int HOFFSEND = 3831808;
  
  protected Dimension HALF_DISPLAY_SIZE = new Dimension(384, 280);
  
  protected Dimension FULL_DISPLAY_SIZE = new Dimension(768, 280);
  
  static int returnmode = 0;
  
  static int rambank = 0;
  
  static int smode = 1;
  
  public static CPC cpc;
  
  public static Z80 z80;
  
  public Basic6845 crtc;
  
  public int InterruptLineCount;
  
  public int MonitorLineCount;
  
  public int InterruptSyncCount = 0;
  
  protected int hSyncCount;
  
  protected int vSyncCount = 0;
  
  protected int screenMode = -1;
  
  public int newMode = 0;
  
  protected boolean[] isBorder;
  
  protected boolean[] rendered;
  
  protected boolean inHSync = false;
  
  protected boolean outHSync = false;
  
  public static int[] inks = new int[33];
  
  protected byte[] fullMap;
  
  protected byte[] halfMap;
  
  protected int offset = 0;
  
  protected int scanStart = 0;
  
  protected boolean scanStarted;
  
  protected Renderer borderRenderer;
  
  protected Renderer syncRenderer;
  
  protected Renderer defRenderer;
  
  protected Renderer startRenderer;
  
  protected Renderer endRenderer;
  
  protected Renderer renderer;
  
  protected int endPix;
  
  protected int selInk = 0;
  
  protected boolean render = true;
  
  protected boolean rendering = true;
  
  protected int screenData;
  
  public static byte[] screenmemory;
  
  protected int Luminance = 255;
  
  protected static final int[] maTranslate = new int[65536];
  
  protected static int[] CPCInks = new int[33];
  
  protected static int[] CPCInksb = new int[33];
  
  protected static int[] GAInks = new int[] { 
      13, 27, 19, 25, 1, 7, 10, 16, 28, 29, 
      24, 26, 6, 8, 15, 17, 30, 31, 18, 20, 
      0, 2, 9, 11, 4, 22, 21, 23, 3, 5, 
      12, 14 };
  
  protected int[] palette = new int[] { 
      13, 13, 19, 25, 1, 7, 10, 16, 7, 25, 
      24, 26, 6, 8, 15, 17, 1, 19, 18, 20, 
      0, 2, 9, 11, 4, 22, 21, 23, 3, 5, 
      12, 14 };
  
  protected static int[] Inks = new int[] { 
      20, 4, 21, 28, 24, 29, 12, 5, 13, 22, 
      6, 23, 30, 0, 31, 14, 7, 15, 18, 2, 
      19, 26, 25, 27, 10, 3, 11 };
  
  public void resetCPCColours() {
    System.arraycopy(original, 0, this.inkTranslateColor, 0, original.length);
  }
  
  public void setPlusPalette(int ink, int r, int g, int b) {
    r += r >> 5;
    g += g >> 5;
    b += b >> 5;
    setPlusPalette(ink, putRGB(r, g, b));
    if (GX4000.debug != null && GX4000.debug.isVisible() && 
      this.storeColor[ink] != r + g + b) {
      GX4000.debug.INK(ink, putRGB(r, g, b));
      this.storeColor[ink] = r + g + b;
    } 
  }
  
  int[] storeColor = new int[32];
  
  public void setPlusPalette(int ink, int value) {
    this.inkTranslateColor[ink] = value;
    setInk(ink, ink);
  }
  
  public void setPalette(int ink, int value) {
    this.inkTranslateColor[Inks[ink]] = value;
  }
  
  public int getVPOS() {
    return this.crtc.getVVPOS();
  }
  
  public int getHPOS() {
    return this.crtc.getHPOS();
  }
  
  protected static final byte[][] fullMaps = new byte[4][];
  
  protected static int[][] modeTab = new int[4][256];
  
  static {
    int mode;
    for (mode = 0; mode < 4; mode++) {
      for (int j = 0; j < 256; j++) {
        switch (mode) {
          case 0:
            modeTab[0][j] = (j & 0x80) >> 7 | (j & 0x8) >> 2 | (j & 0x20) >> 3 | (j & 0x1) << 2;
            break;
          case 1:
            modeTab[1][j] = (j & 0x80) >> 7 | (j & 0x8) >> 2;
            break;
          case 2:
            modeTab[2][j] = (j & 0x80) >> 7;
            break;
          case 3:
            modeTab[3][j] = (j & 0x80) >> 7 | (j & 0x8) >> 2 | (j & 0x20) >> 3 | (j & 0x1) << 2;
            break;
        } 
      } 
    } 
    for (mode = 0; mode < 4; mode++) {
      byte[] full = new byte[1048576];
      fullMaps[mode] = full;
      for (int j = 0; j < 524288; ) {
        int b1 = j >> 11 & 0xFF;
        int b2 = j >> 3 & 0xFF;
        decoder.decodeFull(full, j * 2, mode, b1);
        j += 4;
        decoder.decodeFull(full, j * 2, mode, b2);
        j += 4;
      } 
    } 
    for (int i = 0; i < maTranslate.length; i++) {
      int j = i << 1;
      maTranslate[i] = j & 0x7FE | (j & 0x6000) << 1;
    } 
  }
  
  public int[] LUM = new int[] { 
      0, 17, 34, 51, 68, 85, 102, 119, 136, 153, 
      170, 187, 204, 221, 238, 255 };
  
  public int[] inkTranslateColor = new int[] { 
      6513507, 6513507, 65379, 16777059, 99, 16711779, 25443, 16737123, 16711779, 16777059, 
      16776960, 16711422, 16711680, 16711935, 16737024, 16737279, 99, 65379, 65280, 65535, 
      0, 255, 25344, 25599, 6488163, 6553443, 6553344, 6553599, 6488064, 6488319, 
      6513408, 6513663 };
  
  protected static final int[] original = new int[] { 
      6513507, 6513507, 65379, 16777059, 99, 16711779, 25443, 16737123, 16711779, 16777059, 
      16776960, 16711422, 16711680, 16711935, 16737024, 16737279, 99, 65379, 65280, 65535, 
      0, 255, 25344, 25599, 6488163, 6553443, 6553344, 6553599, 6488064, 6488319, 
      6513408, 6513663 };
  
  boolean isHScroll;
  
  boolean GateArray_RasterInterruptRequest;
  
  boolean test;
  
  boolean testbars;
  
  public static int SoftScrollRegister;
  
  int oldscroll;
  
  boolean plusdone;
  
  int spritecheck;
  
  int oldline;
  
  int pline;
  
  int lc;
  
  int llc;
  
  int pd;
  
  public boolean simplesprites;
  
  Slider slider;
  
  int[] ff;
  
  int skipsprites;
  
  int vscroll;
  
  public static int verticalScroll;
  
  int[] lines;
  
  int ras;
  
  int borderpixel;
  
  int maxline;
  
  int ticker;
  
  boolean tt;
  
  public boolean nosprites;
  
  protected int horizontalScroll;
  
  protected int horizontalScrollMask;
  
  int p;
  
  int spriteoffset;
  
  int spos;
  
  CPCMemory spritemem;
  
  public int[] xm;
  
  public int[] ym;
  
  int[] xpos;
  
  int[] ypos;
  
  int ymin;
  
  int ymax;
  
  int xmin;
  
  int xmax;
  
  int sproffset;
  
  int pix;
  
  int crtcX;
  
  int crtcY;
  
  int[] result;
  
  int split;
  
  boolean srendered;
  
  int pixelcheck;
  
  boolean[] spriteput;
  
  Thread draw;
  
  boolean spritesput;
  
  int bink;
  
  int rasterline;
  
  int stepper;
  
  int oldra;
  
  int tsync;
  
  int spriteRow;
  
  int activeSprites;
  
  int[] spriteRows;
  
  int poff;
  
  boolean simplesprite;
  
  boolean skippixel;
  
  int[] spritePixel;
  
  int spriteIndex;
  
  int[] yz;
  
  int[] xz;
  
  int bpixelx;
  
  int bpixely;
  
  int spx;
  
  int spy;
  
  int stx;
  
  int sty;
  
  int spixel;
  
  int reg9;
  
  boolean[] delay;
  
  boolean DEBUG_BORDER;
  
  int dev;
  
  boolean skipper;
  
  int r3;
  
  boolean hasscroll;
  
  int scrolline;
  
  int ispos;
  
  public GateArray(CPC cpc) {
    super("Amstrad Gate Array");
    this.GateArray_RasterInterruptRequest = false;
    this.test = true;
    this.plusdone = true;
    this.simplesprites = true;
    this.ff = new int[] { 
        243, 237, 86, 49, 255, 191, 1, 131, 247, 237, 
        73, 1, 0, 244, 237, 73 };
    this.lines = new int[] { 0, 112, 224, 336, 448, 560, 672, 784 };
    this.borderpixel = 0;
    this.nosprites = false;
    this.horizontalScrollMask = 12;
    this.xm = new int[16];
    this.ym = new int[16];
    this.xpos = new int[16];
    this.ypos = new int[16];
    this.result = new int[4];
    this.spriteput = new boolean[16];
    this.spritesput = false;
    this.bink = 16;
    this.spriteRows = new int[16];
    this.spritePixel = new int[16];
    this.yz = new int[16];
    this.xz = new int[16];
    this.spixel = 16777215;
    this.delay = new boolean[16];
    this.DEBUG_BORDER = false;
    this.skipper = false;
    this.pixelmap = new int[16];
    setCycleFrequency(1000000L);
    this;
    GateArray.cpc = cpc;
    z80 = cpc.z80;
    this.crtc = cpc.crtc;
    reset();
    setHalfSize();
  }
  
  public void setHalfSize() {
    if (this.defRenderer == null) {
      this.defRenderer = new FullRenderer();
      this.startRenderer = new FullStartRenderer();
      this.endRenderer = new FullEndRenderer();
      this.borderRenderer = new BorderRenderer(16, 16);
      this.syncRenderer = new BorderRenderer(32, 16);
      this.renderer = this.borderRenderer;
    } 
  }
  
  public void reset() {
    this.oldline = -1;
    this.spritecheck = -1;
    System.out.println("GateArray reset!");
    this.crtc.reset();
    this.horizontalScroll = 0;
    verticalScroll = 0;
    this.InterruptLineCount = 0;
    this.MonitorLineCount = 0;
    this.InterruptSyncCount = 0;
    this.hSyncCount = 0;
    this.vSyncCount = 0;
    this.screenMode = -1;
    this.GateArray_RasterInterruptRequest = false;
    setScreenMode(1);
    for (int i = 0; i < 33; i++)
      inks[i] = -16777216; 
    inks[16] = -8355712;
    Display.vscroll = "" + verticalScroll + " - " + this.horizontalScroll;
    SoftScrollRegister = 0;
    this.horizontalScroll = 0;
    verticalScroll = 0;
    if (this.crtc != null) {
      this.crtc.setVerticalScroll(verticalScroll);
      this.crtc.init();
    } 
    resetCPCColours();
  }
  
  public void memoryReset() {
    this.oldline = -1;
    this.spritecheck = -1;
    this.InterruptLineCount = 0;
    this.MonitorLineCount = 0;
    SoftScrollRegister = 0;
    this.horizontalScroll = 0;
    verticalScroll = 0;
    this.crtc.setVerticalScroll(verticalScroll);
    this.crtc.init();
    resetCPCColours();
    Display.vscroll = "" + verticalScroll + " - " + this.horizontalScroll;
  }
  
  public void setSelectedInk(int value) {
    this.selInk = ((value & 0x1F) < 16) ? (value & 0xF) : 16;
  }
  
  public int getSelectedInk() {
    return this.selInk;
  }
  
  public void setInk(int index, int value) {
    CPCInks[index] = GAInks[value & 0x1F];
    CPCInksb[index] = value;
    inks[index] = this.inkTranslateColor[value & 0x1F];
  }
  
  public void setBorder(int value) {
    CPCInks[16] = GAInks[value & 0x1F];
    CPCInksb[16] = value;
    inks[16] = this.inkTranslateColor[value & 0x1F];
  }
  
  public static int getInk(int index) {
    return CPCInks[index];
  }
  
  public static int getInks(int index) {
    return CPCInksb[index];
  }
  
  public void writePort(int port, int value) {
    if (cpc.memory.plus) {
      cpc.getAsic().writePort(port, value);
      return;
    } 
    if ((value & 0x80) == 0) {
      if ((value & 0x40) == 0) {
        value &= 0x1F;
        this.selInk = (value < 16) ? value : 16;
      } else {
        CPCInks[this.selInk] = GAInks[value & 0x1F];
        CPCInksb[this.selInk] = value & 0x1F;
        inks[this.selInk] = this.inkTranslateColor[value & 0x1F];
      } 
    } else if ((value & 0x40) == 0) {
      cpc.asic.romconfig = value;
      cpc.asic.setModeAndROMEnable();
    } else {
      cpc.memory.setRAMBank(value);
      rambank = value;
    } 
  }
  
  public int getRAMBank() {
    return rambank;
  }
  
  public int getMode() {
    return returnmode;
  }
  
  public void setSoftScroll(int value) {
    SoftScrollRegister = value & 0xFF;
    this.horizontalScrollMask = SOFT_SCROLL_MASK[this.screenMode];
    this.horizontalScroll = SoftScrollRegister & 0xF;
    this.isHScroll = (this.horizontalScroll != 0);
    verticalScroll = SoftScrollRegister >> 4 & 0x7;
    this.crtc.setVerticalScroll(verticalScroll);
  }
  
  public void setScreenMode(int mode) {
    this.screenMode = mode;
    this.fullMap = fullMaps[mode];
    this.horizontalScrollMask = SOFT_SCROLL_MASK[mode];
    this.horizontalScroll = SoftScrollRegister & 0xF;
    this.isHScroll = (this.horizontalScroll != 0);
  }
  
  public int getScreenMode() {
    return this.screenMode;
  }
  
  public static int getSMode() {
    return smode;
  }
  
  public void GateArray_AcknowledgeInterrupt() {
    this.InterruptLineCount &= 0x1F;
    this.GateArray_RasterInterruptRequest = false;
  }
  
  public boolean GateArray_GetInterruptRequest() {
    return this.GateArray_RasterInterruptRequest;
  }
  
  public void GateArray_ClearInterrupt() {
    this.GateArray_RasterInterruptRequest = false;
    z80.Z80_ClearInterruptRequest();
    GateArray_ClearInterruptCount();
    cpc.getAsic().ASIC_ClearRasterInterrupt();
  }
  
  public void GateArray_ClearInterruptCount() {
    this.InterruptLineCount = 0;
  }
  
  public void cycle() {
    if (screenmemory != null) {
      int addr = maTranslate[this.crtc.getMA()] + ((this.crtc.getRA() & 0x7) << 11);
      this.screenData = (this.screenData & 0xFFFF) << 16 | (screenmemory[addr] & 0xFF) << 8 | screenmemory[addr + 1] & 0xFF;
    } 
    if (this.pixels == null) {
      try {
        this.pixels = this.display.getPixels();
      } catch (Exception e) {
        this.pixels = new int[215040];
      } 
      return;
    } 
    if (this.rendered == null)
      this.rendered = new boolean[this.pixels.length]; 
    this.crtc.avoidCollision();
    smode = this.screenMode;
    if ((this.hSyncCount == 3 || this.hSyncCount == 4) && this.crtc.CRTCType != 3)
      modeCheck(); 
    if (this.scanStarted) {
      this.crtc.checkHDisp();
      if (this.hPos < 3831808) {
        this.renderer.render();
      } else {
        this.endRenderer.render();
        this.render = this.scanStarted = false;
      } 
    } else if (this.render && this.hPos >= 686080) {
      this.startRenderer.render();
      this.scanStarted = true;
    } 
    this.crtc.cycle();
    if (this.inHSync) {
      this.hSyncCount++;
      if (this.hSyncCount == 2) {
        this.outHSync = true;
        super.hSyncStart();
      } 
      if (this.hSyncCount == 7)
        endHSync(); 
    } 
    clock();
  }
  
  public boolean getVSync() {
    return this.inVSync;
  }
  
  void checkSlider() {
    if (this.slider == null) {
      this.slider = new Slider();
      this.slider.setVisible(true);
      this.slider.slider.setMaximum(768);
      this.slider.slider.setMinimum(0);
    } 
  }
  
  protected void endHSync() {
    if (this.outHSync) {
      modeCheck();
      super.hSyncEnd();
    } 
    this.outHSync = false;
  }
  
  public void modeCheck() {
    this.screenMode = this.newMode;
    setScreenMode(this.screenMode & 0x3);
  }
  
  public int getScroll() {
    return verticalScroll;
  }
  
  public void ASIC_SetSoftScrollRegister(int value) {
    SoftScrollRegister = value & 0xFF;
    this.horizontalScroll = SoftScrollRegister & 0xF;
    verticalScroll = SoftScrollRegister >> 4 & 0x7;
    this.crtc.setVerticalScroll(verticalScroll);
    Display.vscroll = "" + verticalScroll + " - " + this.horizontalScroll;
    this.isHScroll = (this.horizontalScroll != 0);
  }
  
  public void hSyncStart() {
    this.hSyncCount = 0;
    this.inHSync = true;
    this.renderer = this.syncRenderer;
  }
  
  public void hSync() {
    this.ymax = Basic6845.getR(6) * 8 + this.ymin;
    if (this.render = (this.rendering && this.monitorLine >= -4 && this.monitorLine < 276)) {
      this.offset = this.scanStart;
      this.scanStart += 768;
      if ((SoftScrollRegister & 0x80) << 1 == 0)
        this.borderpixel = this.pixels[1]; 
    } 
    if (this.vSyncCount > 0 && --this.vSyncCount == 0)
      super.vSyncEnd(); 
    this.scanStarted = false;
  }
  
  void GateArray_Interrupt() {
    if (cpc.memory.plus) {
      if (!cpc.getAsic().ASIC_RasterIntEnabled()) {
        cpc.getAsic().ASIC_SetRasterInterrupt();
        z80.Z80_SetInterruptRequest();
      } 
      return;
    } 
    z80.Z80_SetInterruptRequest();
  }
  
  public void hSyncEnd() {
    this.debug = (cpc.getMode() != 3);
    endHSync();
    if (this.InterruptSyncCount == 0) {
      if (++this.InterruptLineCount == 52) {
        this.InterruptLineCount = 0;
        GateArray_Interrupt();
        this.GateArray_RasterInterruptRequest = true;
      } 
    } else if (this.InterruptSyncCount > 0 && --this.InterruptSyncCount == 0) {
      if (this.InterruptLineCount >= 32) {
        GateArray_Interrupt();
        this.GateArray_RasterInterruptRequest = true;
      } 
      this.InterruptLineCount = 0;
    } 
    this.renderer = (this.vSyncCount > 0) ? this.syncRenderer : ((this.crtc.isVDisp() && this.crtc.isHDisp()) ? this.defRenderer : this.borderRenderer);
  }
  
  public void hDispEnd() {
    this.renderer = (this.vSyncCount > 0 || this.crtc.isHSync()) ? this.syncRenderer : this.borderRenderer;
  }
  
  public void hDispStart() {
    this.renderer = (this.vSyncCount > 0 || this.crtc.isHSync()) ? this.syncRenderer : (this.crtc.isVDisp() ? this.defRenderer : this.borderRenderer);
  }
  
  public void setMonitorLine(int value) {
    this.offset += value * 768;
  }
  
  public int getLine() {
    return this.monitorLine;
  }
  
  public void vSyncStart() {
    super.vSyncStart();
    modeCheck();
    this.vSyncCount = 32;
    this.renderer = this.syncRenderer;
    this.InterruptSyncCount = 2;
    if (this.isBorder == null)
      return; 
    this.ymin = Basic6845.getR(4) - Basic6845.getR(7) - 3;
    this.ymin *= 8;
    if ((this.ymin & 0x100) == 256)
      this.ymin |= 0xFF00; 
    if ((this.ymin & 0x8000) != 0)
      this.ymin = -(0 - this.ymin & 0x3F); 
    int d = 0;
    for (int i = 0; i < this.isBorder.length; i += 4) {
      if (!this.isBorder[i]) {
        d = i / 768;
        break;
      } 
    } 
    if (this.ymin >= 0 && d > this.ymin)
      this.ymin = d; 
  }
  
  public void vSyncEnd() {
    modeCheck();
  }
  
  public int[] getField() {
    this.result[0] = this.xmin;
    this.result[1] = this.xmax;
    this.result[2] = this.ymin * 2;
    this.result[3] = this.ymax * 2;
    return this.result;
  }
  
  boolean isScroll() {
    return ((SoftScrollRegister & 0x80) << 1 != 0);
  }
  
  protected void putPixel(int pos, int value) {
    if (this.display.DEBUG_SPRITES)
      this.display.ppixels[pos] = 0; 
    if (this.spritemem == null)
      this.spritemem = (CPCMemory)cpc.getMemory(); 
    this.poff = pos;
    if (pos == 0)
      for (int i = 0; i < 16; i++) {
        this.delay[i] = false;
        if (this.display.DEBUG_SPRITES)
          this.spritemem.putSpriteImg(i); 
      }  
    if (pos % 768 == 0)
      this.skippixel = true; 
    if (pos % 32 == 0 && !cpc.getAsic().isLocked() && this.renderer == this.defRenderer) {
      for (int i = 0; i < 16; i++) {
        if (this.xm[i] != 0)
          setSpriteCoords(i); 
      } 
      this.simplesprite = this.simplesprites;
      if (!this.display.large)
        this.simplesprite = true; 
    } 
    pos += (this.screenMode == 2) ? 0 : this.horizontalScroll;
    this.pixels[pos] = value;
    if (pos % 768 < this.xmin + 16 && isScroll()) {
      this.pixels[pos] = inks[this.bink];
      return;
    } 
    if (pos % 768 > this.xmax && isScroll()) {
      this.pixels[pos] = inks[this.bink];
      return;
    } 
    if (this.renderer == this.borderRenderer && this.DEBUG_BORDER) {
      if (pos == 0)
        this.dev = getBorder(); 
      if (this.pixels[pos] == this.dev)
        this.pixels[pos] = (pos % 8 < 4) ? 16711680 : 0; 
    } 
    if (!this.nosprites && this.renderer != this.borderRenderer && !cpc.getAsic().isLocked()) {
      if (this.simplesprite)
        this.skippixel = !this.skippixel; 
      if (this.skippixel || !this.simplesprite)
        drawSprite(this.poff); 
    } 
  }
  
  public void drawSprite(int pos) {
    this.bpixelx = pos % 768 + 1;
    this.bpixely = pos / 768 + 1;
    for (this.spriteIndex = 15; this.spriteIndex >= 0; this.spriteIndex--) {
      if (this.xm[this.spriteIndex] != 0) {
        this.yz[this.spriteIndex] = this.ym[this.spriteIndex] << 4;
        this.xz[this.spriteIndex] = this.xm[this.spriteIndex] << 4;
        if (this.xpos[this.spriteIndex] >= this.bpixelx - this.xz[this.spriteIndex] && this.xpos[this.spriteIndex] < this.bpixelx && this.ypos[this.spriteIndex] >= this.bpixely - this.yz[this.spriteIndex] && this.ypos[this.spriteIndex] < this.bpixely) {
          this.spx = this.xpos[this.spriteIndex] - this.bpixelx - this.xz[this.spriteIndex];
          this.spy = this.ypos[this.spriteIndex] - this.bpixely - this.yz[this.spriteIndex];
          this.spx /= this.xm[this.spriteIndex];
          this.spy /= this.ym[this.spriteIndex];
          this.spritePixel[this.spriteIndex] = getSpritePixel(this.spx, this.spy, this.spriteIndex);
          this.pixels[pos] = (this.spritePixel[this.spriteIndex] != -1234567890) ? this.spritePixel[this.spriteIndex] : this.pixels[pos];
          if (this.skippixel && this.simplesprite)
            this.pixels[pos - 1] = this.pixels[pos]; 
          if (this.display.DEBUG_SPRITES) {
            this.display.ppixels[pos] = (this.spritePixel[this.spriteIndex] != -1234567890) ? (-16777216 + this.spritePixel[this.spriteIndex]) : this.display.ppixels[pos];
            if (this.skippixel && this.simplesprite)
              this.display.ppixels[pos - 1] = this.display.ppixels[pos]; 
          } 
          this.rendered[pos] = true;
        } 
      } 
    } 
  }
  
  public int getSprX(int index) {
    return this.xpos[index];
  }
  
  public int getSprY(int index) {
    return this.ypos[index];
  }
  
  void setSpriteCoords(int index) {
    this.reg9 = this.crtc.getReg(9);
    if (this.crtc.getReg(0) < 32 && this.reg9 != 7) {
      this.xpos[index] = (this.spritemem.getSpriteX(index) + (this.offset % 768 & 0xFFFFFF00)) % 768;
    } else {
      this.xpos[index] = this.spritemem.getSpriteX(index) + this.xmin;
    } 
    if (this.reg9 != 7) {
      this.ypos[index] = this.spritemem.getSpriteY(index) + this.offset / 768;
      this.delay[index] = true;
    } else if (!this.delay[index]) {
      this.ypos[index] = this.spritemem.getSpriteY(index) + this.ymin;
    } 
  }
  
  int getSpritePixel(int x, int y, int i) {
    if (x < 0 || x > 15 || y < 0 || y > 15)
      return -1234567890; 
    return this.spritemem.getSpriteColor(i, 15 - x, 15 - y);
  }
  
  public void vSync(boolean interlace) {
    for (int i = 0; i < this.rendered.length; i++)
      this.rendered[i] = false; 
    int off = 0;
    int line = 0;
    for (int j = 0; j < this.pixels.length; j++) {
      off++;
      if (off == 768) {
        off = 0;
        line++;
      } 
      if (!this.isBorder[j])
        break; 
    } 
    off = 0;
    line = 0;
    this.xmin = (50 - Basic6845.getR(2)) * 16;
    this.r3 = Basic6845.getR(3) & 0xF;
    if (this.r3 < 6)
      this.xmin += this.r3 * 8; 
    this.r3 = Basic6845.getR(0) - 63;
    this.xmin += this.r3 * 16;
    this.xmax = this.xmin + Basic6845.getR(1) * 16;
    this.scanStart = this.offset = 0;
    cpc.vSync();
    this.maxline = 0;
  }
  
  public void vSync() {
    for (int i = 0; i < this.rendered.length; i++)
      this.rendered[i] = false; 
    this.scanStart = 0;
    try {
      cpc.vSync();
    } catch (Exception exception) {}
  }
  
  public void vDispStart() {}
  
  public void setMemory(byte[] value) {
    screenmemory = value;
  }
  
  public void setRendering(boolean value) {
    this.rendering = value;
    if (!this.rendering)
      this.render = this.scanStarted = false; 
  }
  
  public Dimension getDisplaySize(boolean large) {
    return large ? this.FULL_DISPLAY_SIZE : this.HALF_DISPLAY_SIZE;
  }
  
  public void cursor() {}
  
  protected abstract class Renderer {
    public void render() {}
  }
  
  protected class BorderRenderer extends Renderer {
    protected int ink;
    
    protected int width;
    
    public BorderRenderer(int ink, int width) {
      this.ink = ink;
      this.width = width;
    }
    
    public void render() {
      if (GateArray.this.pixels == null)
        return; 
      if (GateArray.this.isBorder == null || GateArray.this.isBorder.length < 1)
        GateArray.this.isBorder = new boolean[GateArray.this.pixels.length]; 
      int pix = GateArray.inks[this.ink];
      try {
        for (int i = 0; i < this.width; i++) {
          if (GateArray.this.offset < GateArray.this.pixels.length)
            GateArray.this.putPixel(GateArray.this.offset, pix); 
          GateArray.this.isBorder[GateArray.this.offset] = true;
          GateArray.this.offset++;
        } 
      } catch (Exception exception) {}
    }
  }
  
  protected static final int[] SOFT_SCROLL_MASK = new int[] { 12, 14, 15, 12 };
  
  int[] pixelmap;
  
  protected void shiftArray(byte[] bytes, int shift) {
    for (int i = 0; i < shift; i++) {
      byte last = bytes[bytes.length - 1];
      System.arraycopy(bytes, 0, bytes, 1, bytes.length - 2);
      bytes[0] = last;
    } 
  }
  
  int getX() {
    return this.offset % 768;
  }
  
  protected class FullRenderer extends Renderer {
    public void render() {
      if (GateArray.this.isBorder == null || GateArray.this.isBorder.length < 1)
        GateArray.this.isBorder = new boolean[GateArray.this.pixels.length]; 
      int val = (GateArray.this.screenData >> ((GateArray.this.screenMode != 2) ? 0 : (GateArray.this.horizontalScroll & GateArray.SOFT_SCROLL_MASK[GateArray.this.screenMode])) & 0xFFFF) << 4;
      for (int i = 0; i < 16; i++) {
        GateArray.this.isBorder[GateArray.this.offset] = false;
        if (GateArray.this.offset < GateArray.this.pixels.length)
          GateArray.this.putPixel(GateArray.this.offset++, GateArray.inks[GateArray.this.fullMap[val++]]); 
      } 
    }
  }
  
  protected class FullStartRenderer extends Renderer {
    public void render() {
      try {
        GateArray.this.endPix = 16 - (GateArray.this.hPos - 686080 >> 12 & 0xF);
        if (GateArray.this.renderer == GateArray.this.borderRenderer) {
          int pix = GateArray.inks[16];
          for (int i = GateArray.this.endPix; i < 16; i++) {
            GateArray.this.isBorder[GateArray.this.offset] = true;
            if (GateArray.this.offset < GateArray.this.pixels.length)
              GateArray.this.putPixel(GateArray.this.offset++, pix); 
          } 
        } else if (GateArray.this.renderer == GateArray.this.defRenderer) {
          int val = (GateArray.this.screenData >> ((GateArray.this.screenMode != 2) ? 0 : (GateArray.this.horizontalScroll & GateArray.SOFT_SCROLL_MASK[GateArray.this.screenMode])) & 0xFFFF) << 4 + GateArray.this.endPix;
          for (int i = GateArray.this.endPix; i < 16; i++) {
            GateArray.this.isBorder[GateArray.this.offset] = false;
            if (GateArray.this.offset < GateArray.this.pixels.length)
              GateArray.this.putPixel(GateArray.this.offset++, GateArray.inks[GateArray.this.fullMap[val++]]); 
          } 
        } else {
          int pix = GateArray.inks[32];
          for (int i = GateArray.this.endPix; i < 16; i++) {
            GateArray.this.isBorder[GateArray.this.offset] = false;
            if (GateArray.this.offset < GateArray.this.pixels.length)
              GateArray.this.putPixel(GateArray.this.offset++, pix); 
          } 
        } 
      } catch (Exception exception) {}
    }
  }
  
  protected class FullEndRenderer extends Renderer {
    public void render() {
      try {
        if (GateArray.this.renderer == GateArray.this.borderRenderer) {
          int pix = GateArray.inks[16];
          for (int i = 0; i < GateArray.this.endPix; i++) {
            GateArray.this.isBorder[GateArray.this.offset] = true;
            if (GateArray.this.offset < GateArray.this.pixels.length)
              GateArray.this.putPixel(GateArray.this.offset++, pix); 
          } 
        } else if (GateArray.this.renderer == GateArray.this.defRenderer) {
          int val = (GateArray.this.screenData >> ((GateArray.this.screenMode != 2) ? 0 : (GateArray.this.horizontalScroll & GateArray.SOFT_SCROLL_MASK[GateArray.this.screenMode])) & 0xFFFF) << 4;
          for (int i = 0; i < GateArray.this.endPix; i++) {
            GateArray.this.isBorder[GateArray.this.offset] = false;
            if (GateArray.this.offset < GateArray.this.pixels.length)
              GateArray.this.putPixel(GateArray.this.offset++, GateArray.inks[GateArray.this.fullMap[val++]]); 
          } 
        } else {
          int pix = GateArray.inks[32];
          for (int i = 0; i < GateArray.this.endPix; i++) {
            GateArray.this.isBorder[GateArray.this.offset] = false;
            if (GateArray.this.offset < GateArray.this.pixels.length)
              GateArray.this.putPixel(GateArray.this.offset++, pix); 
          } 
        } 
      } catch (Exception exception) {}
    }
  }
  
  public void resetInks() {
    for (int i = 0; i < 17; i++)
      setInk(i, getInks(i)); 
  }
  
  public void resetInkss() {
    for (int i = 0; i < 17; i++)
      setInk(i, i); 
  }
  
  public void init() {
    this.crtc.init();
  }
  
  public int PEEK(int address) {
    return cpc.PEEK(address);
  }
  
  public void POKE(int address, int value) {
    cpc.POKE(address, value);
  }
  
  public static int putRGB(int r, int g, int b) {
    return r << 16 | g << 8 | b;
  }
  
  public boolean getOut() {
    return (this.endPix != 0);
  }
  
  public int getLineNumber() {
    return this.crtc.getLineNumber();
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\system\cpc\GateArray.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */