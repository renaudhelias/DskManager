package JCPC.system.cpc;

import JCPC.core.Util;
import java.net.URL;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;

public enum Samples {
  MOTOR("JCPC/system/cpc/motor.wav"),
  SEEK("JCPC/system/cpc/seek.wav"),
  SEEKBACK("JCPC/system/cpc/seekback.wav"),
  TRACK("JCPC/system/cpc/track.wav"),
  TRACKBACK("JCPC/system/cpc/trackback.wav"),
  RELAIS("JCPC/system/cpc/relon.wav"),
  RELAISOFF("JCPC/system/cpc/reloff.wav"),
  TAPEMOTOR("JCPC/system/cpc/tapmotor.wav"),
  INSERT("JCPC/system/cpc/insert.wav");
  
  public enum Volume {
    MUTE, LOW, MEDIUM, HIGH;
  }
  
  static {
    volume = Volume.HIGH;
    quiet = false;
  }
  
  public boolean nosamples = false;
  
  public static Volume volume;
  
  public static boolean quiet;
  
  private Clip clip;
  
  Samples(String soundFileName) {
    if (this.nosamples)
      return; 
    if (!Util.isWindows()) {
      this.nosamples = true;
      return;
    } 
    try {
      URL url = getClass().getClassLoader().getResource(soundFileName);
      AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(url);
      AudioFormat format = audioInputStream.getFormat();
      DataLine.Info info = new DataLine.Info(Clip.class, format);
      this.clip = (Clip)AudioSystem.getLine(info);
      this.clip.open(audioInputStream);
    } catch (Exception e) {
      this.nosamples = true;
    } 
  }
  
  public void play() {
    if (quiet)
      return; 
    if (this.nosamples)
      return; 
    if (CPC.gx4000)
      return; 
    if (volume != Volume.MUTE) {
      if (this.clip.isRunning())
        this.clip.stop(); 
      this.clip.setFramePosition(0);
      this.clip.start();
    } 
  }
  
  public void click() {
    if (this.nosamples)
      return; 
    if (CPC.gx4000)
      return; 
    if (volume != Volume.MUTE) {
      if (this.clip.isRunning())
        this.clip.stop(); 
      this.clip.setFramePosition(0);
      this.clip.start();
    } 
  }
  
  public void loop() {
    if (this.nosamples)
      return; 
    if (CPC.gx4000)
      return; 
    if (quiet) {
      this;
      SEEK.stop();
      this;
      TRACK.stop();
      this;
      SEEKBACK.stop();
      this;
      TRACKBACK.stop();
      return;
    } 
    if (this.nosamples)
      return; 
    if (volume != Volume.MUTE) {
      if (this.clip.isRunning())
        this.clip.stop(); 
      this.clip.setFramePosition(0);
      this.clip.loop(-1);
    } 
  }
  
  public void turn() {
    if (this.nosamples)
      return; 
    if (CPC.gx4000)
      return; 
    if (volume != Volume.MUTE) {
      if (this.clip.isRunning())
        this.clip.stop(); 
      this.clip.setFramePosition(0);
      this.clip.loop(-1);
    } 
  }
  
  public void loop2() {
    if (this.nosamples)
      return; 
    if (CPC.gx4000)
      return; 
    if (quiet) {
      this;
      SEEK.stop();
      this;
      TRACK.stop();
      this;
      SEEKBACK.stop();
      this;
      TRACKBACK.stop();
      return;
    } 
    if (this.nosamples)
      return; 
    if (volume != Volume.MUTE && 
      !this.clip.isRunning()) {
      this.clip.setFramePosition(0);
      this.clip.loop(-1);
    } 
  }
  
  public void turn2() {
    if (this.nosamples)
      return; 
    if (CPC.gx4000)
      return; 
    if (volume != Volume.MUTE && 
      !this.clip.isRunning()) {
      this.clip.setFramePosition(0);
      this.clip.loop(-1);
    } 
  }
  
  public void stop() {
    if (this.nosamples)
      return; 
    if (CPC.gx4000)
      return; 
    if (this.clip.isRunning())
      this.clip.stop(); 
    this.clip.setFramePosition(0);
    this.clip.stop();
  }
  
  static void init() {
    values();
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\system\cpc\Samples.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */