package JCPC.system.cpc;

public class CPCDiscImageSector {
  private final int track;
  
  private int side;
  
  private final int id;
  
  private final int size;
  
  private byte[] data;
  
  private int ST1;
  
  private int ST2;
  
  public CPCDiscImageSector(int track, int side, int id, int size, byte[] data, int sta1, int sta2) {
    this.track = track;
    this.side = side;
    this.id = id;
    this.size = size;
    this.data = data;
    this.ST1 = sta1;
    this.ST2 = sta2;
  }
  
  public int getId() {
    return this.id;
  }
  
  public int getTrack() {
    return this.track;
  }
  
  public int getSide() {
    return this.side;
  }
  
  public int getSize() {
    return this.size;
  }
  
  public byte[] getData() {
    return this.data;
  }
  
  public int getST1() {
    return this.ST1;
  }
  
  public int getST2() {
    return this.ST2;
  }
  
  public void setST1(int value) {
    this.ST1 = value & 0xFF;
  }
  
  public void setST2(int value) {
    this.ST2 = value & 0xFF;
  }
  
  public void setData(byte[] data) {
    this.data = data;
  }
  
  public void setSide(int side) {
    this.side = side;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\system\cpc\CPCDiscImageSector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */