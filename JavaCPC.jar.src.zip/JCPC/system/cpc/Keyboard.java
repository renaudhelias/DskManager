package JCPC.system.cpc;

import JCPC.core.device.keyboard.MatrixKeyboard;

public class Keyboard extends MatrixKeyboard {
  protected static final int[] KEY_MAP = new int[] { 
      38, 39, 40, 105, 102, 99, 35, 110, 37, 18, 
      103, 104, 101, 97, 98, 96, -1, 65406, 10, 93, 
      100, 16, 92, 17, 61, 45, 91, 80, 222, 59, 
      47, 46, 48, 57, 79, 73, 76, 75, 77, 44, 
      56, 55, 85, 89, 72, 74, 78, 32, 54, 53, 
      82, 84, 71, 70, 66, 86, 52, 51, 69, 87, 
      83, 68, 67, 88, 49, 50, 27, 81, 9, 65, 
      20, 90, 36, 35, 127, 34, 155, 33, -1, 8 };
  
  protected static final int[] GX4000_MAP = new int[] { 
      -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
      -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
      -1, -1, -1, -1, -1, -1, -1, 27, -1, -1, 
      -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
      -1, -1, -1, -1, -1, -1, -1, -1, 36, 35, 
      127, 34, 155, 33, -1, -1, -1, -1, -1, -1, 
      -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
      -1, -1, 38, 40, 37, 39, 17, 18, -1, -1 };
  
  protected int[] bytes = new int[16];
  
  protected int[] KeyboardData = new int[16];
  
  protected int row = 0;
  
  public Keyboard() {
    super("CPC Keyboard", 8, 10);
    for (int i = 0; i < this.bytes.length; i++) {
      this.bytes[i] = 255;
      this.KeyboardData[i] = 255;
    } 
    addKeyMappings(KEY_MAP);
  }
  
  public void setKeyMapping(int map) {
    for (int i = 0; i < this.bytes.length; i++) {
      this.bytes[i] = 255;
      this.KeyboardData[i] = 255;
    } 
    switch (map) {
      case 0:
        addKeyMappings(KEY_MAP);
        System.out.println("Setting CPC plus keyboard");
        break;
      case 1:
        addKeyMappings(GX4000_MAP);
        System.out.println("Setting GX4000 gamepads");
        break;
    } 
  }
  
  protected void keyChanged(int col, int row, int oldValue, int newValue) {
    if (oldValue == 0) {
      if (newValue != 0)
        this.KeyboardData[row] = this.KeyboardData[row] & (1 << col ^ 0xFF); 
    } else if (newValue == 0) {
      this.KeyboardData[row] = this.KeyboardData[row] | 1 << col;
    } 
    System.arraycopy(this.KeyboardData, 0, this.bytes, 0, 16);
  }
  
  public void setSelectedRow(int value) {
    this.row = value;
  }
  
  public int readSelectedRow() {
    return this.bytes[this.row];
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\system\cpc\Keyboard.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */