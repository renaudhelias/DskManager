package JCPC.system.cpc;

import JCPC.core.Util;
import JCPC.core.device.memory.DynamicMemory;
import java.awt.image.BufferedImage;
import java.util.Calendar;

public class CPCMemory extends DynamicMemory {
  public void setCartridge(byte[] in) {}
  
  protected Calendar cal = Calendar.getInstance();
  
  protected int ramtype = 0;
  
  public static final int TYPE_64K = 0;
  
  public static final int TYPE_128K = 1;
  
  public static final int TYPE_256K = 15;
  
  public static final int TYPE_SILICON_DISC = 240;
  
  public static final int TYPE_128_SILICON_DISC = 241;
  
  public static final int TYPE_512K = 255;
  
  protected int[] baseRAM = new int[8];
  
  protected int[] readMap = new int[8];
  
  protected int[] writeMap = new int[8];
  
  protected int ramTYPE;
  
  protected boolean lower = true;
  
  protected boolean upper = true;
  
  public boolean plus = false;
  
  protected int upperROM = 0;
  
  protected int plusROM = 0;
  
  protected int bankRAM = -1;
  
  public static final int BASE_RAM = 0;
  
  public static final int BASE_LOWROM = 9;
  
  public static final int BASE_UPROM = 10;
  
  public static final int BASE_ASIC = 26;
  
  public static final int BASE_CART = 27;
  
  public static final int BASE_MULTIFACE = 59;
  
  CPC cpc;
  
  GateArray gateArray;
  
  public boolean asiclocked;
  
  protected boolean asicRamActive;
  
  int lowRomLoc;
  
  int lowRomPage;
  
  int red;
  
  int green;
  
  int blue;
  
  byte[] posbuf;
  
  int[] spriteX;
  
  int[] spriteY;
  
  int spritepos;
  
  int posx;
  
  int posy;
  
  int[] magnify;
  
  int[] xmag;
  
  int[] ymag;
  
  protected int[] SpritePalette;
  
  int[][] sprdata;
  
  int val;
  
  int[] spriteram;
  
  public BufferedImage[] spriteImg;
  
  String[] CheckInfo;
  
  boolean lowerROMInserted;
  
  boolean DEBUG_UPPER;
  
  boolean useplus;
  
  public int selInk;
  
  int oldInk;
  
  int spos;
  
  int oldd;
  
  int div;
  
  int[][] colbuffer;
  
  int delay;
  
  boolean DEBUG_MF2;
  
  int[] lowRom;
  
  boolean DEBUG_LOWER;
  
  protected boolean isSecondaryRom;
  
  int oldval;
  
  public CPCMemory(int type, CPC cpc, GateArray gateArray) {
    super("CPC Memory", 65536, 60);
    this.asiclocked = true;
    this.asicRamActive = false;
    this.posbuf = new byte[2];
    this.spriteX = new int[16];
    this.spriteY = new int[16];
    this.magnify = new int[] { 0, 1, 2, 4 };
    this.xmag = new int[16];
    this.ymag = new int[16];
    this.SpritePalette = new int[16];
    this.sprdata = new int[16][256];
    this.spriteram = new int[4096];
    this.spriteImg = new BufferedImage[16];
    this.CheckInfo = new String[] { "reset", "setROM", "setLowerEnabled", "setMultiEnabled", "setUpperEnabled", "setUpperROM", "setRamBank" };
    this.lowerROMInserted = false;
    this.DEBUG_UPPER = false;
    this.oldd = -5;
    this.div = 0;
    this.colbuffer = new int[16][2];
    this.DEBUG_MF2 = false;
    this.lowRom = new int[] { 0, 16384, 32768 };
    this.DEBUG_LOWER = false;
    this.isSecondaryRom = false;
    this.cpc = cpc;
    this.gateArray = gateArray;
    this.ramtype = type;
    setRAMType(type);
    reset();
  }
  
  public void changeRamType(int type) {
    this.ramtype = type;
    setRAMType(type);
    reset();
  }
  
  public int[] getBaseRam() {
    return this.baseRAM;
  }
  
  public int getBaseAsic() {
    return 26;
  }
  
  public int readASIC(int address) {
    return this.mem[this.baseAddr[26] + (address & 0x3FFF)] & 0xFF;
  }
  
  public void writeASIC(int address, int value) {
    address &= 0x3FFF;
    this.mem[this.baseAddr[26] + address] = (byte)value;
  }
  
  public void eraseSprite(int index) {
    this.spriteX[index] = -2000;
    this.spriteY[index] = -2000;
    this.xmag[index] = 0;
    this.ymag[index] = 0;
  }
  
  public void setSpritePos2(int index) {
    this.spritepos = 24576 + index * 8;
    this.posbuf[0] = (byte)(readASIC(this.spritepos) & 0xFF);
    this.posbuf[1] = (byte)(readASIC(this.spritepos + 1) & 0xFF);
    if ((this.posbuf[1] & 0x3) == 3)
      this.posbuf[1] = -1; 
    this.spriteX[index] = getWord(this.posbuf, 0);
    if ((this.spriteX[index] & 0x300) == 768)
      this.spriteX[index] = this.spriteX[index] | 0xFF00; 
    if ((this.spriteX[index] & 0x8000) != 0)
      this.spriteX[index] = -(0 - this.spriteX[index] & 0xFFFF); 
    this.posbuf[0] = (byte)readASIC(this.spritepos + 2);
    this.posbuf[1] = (byte)readASIC(this.spritepos + 3);
    if ((this.posbuf[1] & 0x1) == 1)
      this.posbuf[1] = -1; 
    this.spriteY[index] = getWord(this.posbuf, 0) & 0x1FF;
    if ((this.spriteY[index] & 0x100) == 256)
      this.spriteY[index] = this.spriteY[index] | 0xFF00; 
    if ((this.spriteY[index] & 0x8000) != 0)
      this.spriteY[index] = -(0 - this.spriteY[index] & 0xFFFF); 
  }
  
  public void setSpritePos(int index) {
    this.spritepos = 24576 + index * 8;
    this.spriteX[index] = (readASIC(this.spritepos) | readASIC(this.spritepos + 1) << 8) & 0x3FF;
    if ((this.spriteX[index] & 0x300) == 768)
      this.spriteX[index] = this.spriteX[index] | 0xFF00; 
    if ((this.spriteX[index] & 0x8000) != 0)
      this.spriteX[index] = -(0 - this.spriteX[index] & 0xFFFF); 
    this.spriteY[index] = (readASIC(this.spritepos + 2) | readASIC(this.spritepos + 3) << 8) & 0x1FF;
    if ((this.spriteY[index] & 0x100) == 256)
      this.spriteY[index] = this.spriteY[index] | 0xFF00; 
    if ((this.spriteY[index] & 0x8000) != 0)
      this.spriteY[index] = -(0 - this.spriteY[index] & 0xFFFF); 
  }
  
  public void setSpriteX(int index, int value) {
    this.spriteX[index] = value;
  }
  
  public void setSpriteY(int index, int value) {
    this.spriteY[index] = value;
  }
  
  public void setMag(int index, int value) {
    int mag = value & 0xF;
    this.xmag[index] = this.magnify[mag >> 2 & 0x3];
    this.ymag[index] = this.magnify[mag & 0x3];
    this.gateArray.xm[index] = this.xmag[index];
    this.gateArray.ym[index] = this.ymag[index];
  }
  
  public int getSpriteX(int index) {
    return this.spriteX[index];
  }
  
  public int getSpriteY(int index) {
    return this.spriteY[index];
  }
  
  public int[] getSprite(int index) {
    return this.sprdata[index];
  }
  
  public void setSpriteData(int index) {
    for (int i = 0; i < (this.sprdata[index]).length; i++) {
      this.val = this.spriteram[index * 256 + i] & 0xF;
      this.sprdata[index][i] = (this.val == 0) ? -1234567890 : this.SpritePalette[this.val - 1];
    } 
  }
  
  public int getSpriteDebugColor(int index, int x, int y) {
    this.val = this.spriteram[index * 256 + x + y * 16] & 0xF;
    if (this.val == 0)
      return 0; 
    this.val--;
    this.blue = this.gateArray.LUM[readASIC(9250 + this.val * 2) & 0xF];
    this.red = this.gateArray.LUM[readASIC(9250 + this.val * 2) >> 4 & 0xF];
    this.green = this.gateArray.LUM[readASIC(9251 + this.val * 2) & 0xF];
    return -16777216 + (this.red << 16) | this.green << 8 | this.blue;
  }
  
  public int getSpriteColor(int index, int x, int y) {
    this.val = this.spriteram[index * 256 + x + (y << 4)] & 0xF;
    if (this.val == 0)
      return -1234567890; 
    this.val--;
    this.blue = this.gateArray.LUM[readASIC(9250 + (this.val << 1)) & 0xF];
    this.red = this.gateArray.LUM[readASIC(9250 + (this.val << 1)) >> 4 & 0xF];
    this.green = this.gateArray.LUM[readASIC(9251 + (this.val << 1)) & 0xF];
    return this.red << 16 | this.green << 8 | this.blue;
  }
  
  public void setSpritePalette(int i) {
    this.blue = this.gateArray.LUM[readASIC(9250 + i * 2) & 0xF];
    this.red = this.gateArray.LUM[readASIC(9250 + i * 2) >> 4 & 0xF];
    this.green = this.gateArray.LUM[readASIC(9251 + i * 2) & 0xF];
    this.SpritePalette[i] = this.red << 16 | this.green << 8 | this.blue;
  }
  
  public void setSpriteData(int index, int x, int y) {
    this.val = this.spriteram[index * 256 + x + y * 16] & 0xF;
    this.sprdata[index][x + y * 16] = (this.val == 0) ? -1234567890 : this.SpritePalette[this.val - 1];
  }
  
  public void writeSpriteData(int address, int value) {
    this.spriteram[address] = value;
  }
  
  public void destroySprite(int index) {
    this.spritepos = 16384 + index * 256;
    int i;
    for (i = 0; i < 256; i++)
      this.spriteram[index * 256 + i] = 0; 
    for (i = 0; i < (this.sprdata[index]).length; i++)
      writeASIC(i + this.spritepos, Util.random(15)); 
  }
  
  public void putSpriteImg(int index) {
    BufferedImage spriteI = new BufferedImage(16, 16, 2);
    int xoff = 0;
    int yoff = 0;
    for (int y = 0; y < 16; y++) {
      for (int x = 0; x < 16; x++) {
        int rgb = this.spriteram[index * 256 + xoff + (yoff << 4)] & 0xF;
        if (rgb == 0) {
          rgb = -65281;
        } else {
          rgb--;
          this.blue = this.gateArray.LUM[readASIC(9250 + (rgb << 1)) & 0xF];
          this.red = this.gateArray.LUM[readASIC(9250 + (rgb << 1)) >> 4 & 0xF];
          this.green = this.gateArray.LUM[readASIC(9251 + (rgb << 1)) & 0xF];
          rgb = this.red << 16 | this.green << 8 | this.blue;
          rgb -= 16777216;
        } 
        xoff++;
        spriteI.setRGB(x, y, rgb);
      } 
      xoff = 0;
      yoff++;
    } 
    try {
      this.spriteImg[index] = new BufferedImage(16, 16, 2);
      this.spriteImg[index].getGraphics().drawImage(spriteI, 0, 0, 16, 16, null);
    } catch (Exception exception) {}
  }
  
  public void pluspalette(int ink) {
    this.blue = readASIC(0x6400 | ink << 1) & 0xF;
    this.red = readASIC(0x6400 | ink << 1) >> 4 & 0xF;
    this.green = readASIC(0x6401 | ink << 1) & 0xF;
    this.gateArray.setPlusPalette(ink, this.red << 4, this.green << 4, this.blue << 4);
  }
  
  public void setPlus(boolean pl) {
    this.plus = pl;
  }
  
  public void reset(boolean hard) {
    this.lowRomLoc = 0;
    this.lowRomPage = 0;
    if (hard)
      for (int j = 0; j < 65536; j++) {
        this.mem[j] = 0;
        writeASIC(j, 0);
      }  
    killSprites();
    for (int i = 0; i < 16; i++)
      setMag(i, 0); 
    System.out.println("Memory reset!");
    setRAMBank(192);
    this.asiclocked = true;
    this.asicRamActive = false;
    this.upper = false;
    this.lower = true;
    this.upperROM = 0;
    this.plusROM = 0;
    enableAsicRam(this.asicRamActive, this.lowRomLoc, this.lowRomPage);
    try {
      this.cpc.psg.resetRegisters();
    } catch (Exception exception) {}
    remap();
  }
  
  public void killSprites() {
    System.out.println("Destroying spritememory");
    for (int i = 0; i < 16; i++)
      destroySprite(i); 
  }
  
  public void setRAMType(int value) {
    this.ramTYPE = value;
    getMem(0, 65536);
    for (int i = 1; i < 9; i++) {
      if ((this.ramTYPE & 0x1) != 0) {
        getMem(i, 65536);
      } else {
        freeMem(i, 65536);
      } 
      this.ramTYPE >>= 1;
    } 
    getMem(26, 16384);
    getMem(59, 16384);
  }
  
  public int getRAMType() {
    return this.ramtype;
  }
  
  public void setLowerROM(byte[] data) {
    setROM(9, data);
  }
  
  public void setMultiROM(byte[] data) {
    setROM(59, data);
  }
  
  public void setUpperROM(int rom, byte[] data) {
    setROM(10 + (rom & 0xF), data);
  }
  
  public void setPlusROM(int rom, byte[] data) {
    this.lowerROMInserted = setROM(27 + rom, data);
  }
  
  protected boolean setROM(int base, byte[] data) {
    if (data == null || data.length == 0) {
      freeMem(base, 16384);
      return false;
    } 
    base = getMem(base, 16384);
    System.arraycopy(data, 0, this.mem, base, Math.min(16384, data.length));
    return true;
  }
  
  public void setLowerEnabled(boolean value) {
    if (this.lower != value) {
      this.lower = value;
      remap();
    } 
  }
  
  public void setUpperEnabled(boolean value) {
    if (this.upper != value) {
      this.upper = value;
      remap();
    } 
  }
  
  public boolean getUpperEnabled() {
    return this.upper;
  }
  
  public void writePort(int port, int value) {
    setUpperROM(value);
  }
  
  public void setUpperROM(int value) {
    this.useplus = false;
    value &= 0xFF;
    if (this.isSecondaryRom) {
      value &= 0xF;
      if (this.upperROM != value) {
        this.upperROM = value;
        remap();
      } 
      return;
    } 
    if (value > 127) {
      this.useplus = true;
      value &= 0x1F;
      if (this.DEBUG_UPPER)
        System.err.println("plusmap:" + Util.hex((byte)value)); 
      this.plusROM = value;
    } else if (this.plus) {
      this.useplus = true;
      value &= 0xF;
      if (this.DEBUG_UPPER)
        System.err.println("normalmap:" + Util.hex((byte)value)); 
      if (value == 7) {
        value = 3;
      } else {
        value = 1;
      } 
      this.plusROM = value;
    } else {
      this.useplus = false;
      this.upperROM = value;
    } 
    remap();
  }
  
  public int getUpperROM() {
    return this.upperROM;
  }
  
  public int getPlusROM() {
    return this.plusROM;
  }
  
  public void setRAMBank(int value) {
    value &= 0x3F;
    if (this.bankRAM != value) {
      this.bankRAM = value;
      remapRAM();
    } 
  }
  
  public int getRAMBank() {
    return this.bankRAM | 0xC0;
  }
  
  public void remapRAM() {
    int mask = 0;
    boolean enable128k = false;
    boolean enable256k = false;
    boolean silicondiskenabled = false;
    if (this.ramtype == 1 || this.ramtype == 241)
      enable128k = true; 
    if (this.ramtype == 15)
      enable256k = true; 
    if (this.ramtype == 241 || this.ramtype == 240)
      silicondiskenabled = true; 
    if (enable128k)
      mask |= 0x7; 
    if (enable256k)
      mask |= 0x1F; 
    if (silicondiskenabled)
      mask |= 0x3F; 
    if (mask != 0)
      this.bankRAM &= mask; 
    int bankBase = ((this.bankRAM & 0x38) >> 3) + 0 + 1;
    bankBase = this.baseAddr[bankBase];
    if (bankBase == -1) {
      bankBase = this.baseAddr[0];
      this.bankRAM = 0;
    } 
    int base = ((this.bankRAM & 0x7) == 2) ? bankBase : this.baseAddr[0];
    for (int i = 0; i < 8; i++)
      this.baseRAM[i] = base + i * 8192; 
    if ((this.bankRAM & 0x5) == 1) {
      this.baseRAM[6] = bankBase + 49152;
      this.baseRAM[7] = bankBase + 49152 + 8192;
      if ((this.bankRAM & 0x2) == 2) {
        this.baseRAM[2] = base + 49152;
        this.baseRAM[3] = base + 49152 + 8192;
      } 
    } else if ((this.bankRAM & 0x4) == 4) {
      this.baseRAM[2] = bankBase + (this.bankRAM & 0x3) * 16384;
      this.baseRAM[3] = bankBase + (this.bankRAM & 0x3) * 16384 + 8192;
    } 
    if (this.asicRamActive && this.bankRAM == 0) {
      this.baseRAM[2] = this.baseAddr[26];
      this.baseRAM[3] = this.baseAddr[26] + 8192;
    } 
    remap();
  }
  
  public int readByte(int address) {
    try {
      return this.mem[this.readMap[address >> 13] + (address & 0x1FFF)] & 0xFF;
    } catch (Exception e) {
      return 0;
    } 
  }
  
  public byte readLowByte(int address) {
    return this.mem[this.baseAddr[0] + address];
  }
  
  public boolean getASICActive() {
    return (this.baseRAM[2] == this.baseAddr[26] && this.baseRAM[3] == this.baseAddr[26] + 8192);
  }
  
  public int writeByte(int address, int value) {
    value &= 0xFF;
    if (this.asicRamActive && address > 16383 && address < 32768) {
      if (address > 25599 && address < 25666 && (address & 0x1) != 0)
        value &= 0xF; 
      if (address > 16383 && address < 20480) {
        int d = (address - 16384) / 256;
        this.spriteram[address - 16384] = value & 0xF;
      } 
      writeASIC(address, value);
      this.cpc.getAsic().ASIC_WriteRam(address, value);
      return value & 0xFF;
    } 
    this.mem[this.writeMap[address >> 13] + (address & 0x1FFF)] = (byte)value;
    return value & 0xFF;
  }
  
  public int writeByte(int address, int value, int forcedbank, boolean forced) {
    if (address > 16383 && address < 32768) {
      int g = getRAMBank();
      setRAMBank(forcedbank);
      try {
        this.mem[this.writeMap[address >> 13] + (address & 0x1FFF)] = (byte)value;
      } catch (Exception exception) {}
      int b = value & 0xFF;
      setRAMBank(g);
      return b;
    } 
    return writeByte(address, value);
  }
  
  public void poke(int address, int value) {
    this.mem[address] = (byte)value;
  }
  
  public void remap() {
    mapRAM();
    mapROMs();
  }
  
  public int[] ReadMap() {
    return this.readMap;
  }
  
  protected void mapRAM() {
    for (int i = 0; i < this.baseRAM.length; i++) {
      this.readMap[i] = this.baseRAM[i];
      this.writeMap[i] = this.baseRAM[i];
    } 
    if (this.asicRamActive) {
      this.readMap[2] = this.baseAddr[26];
      this.writeMap[2] = this.baseAddr[26];
      this.readMap[3] = this.baseAddr[26] + 8192;
      this.writeMap[3] = this.baseAddr[26] + 8192;
    } 
  }
  
  public void enableAsicRam(boolean asicRamActive, int lowRomLoc, int lowRomPage) {
    this.asicRamActive = asicRamActive;
    this.lowRomLoc = lowRomLoc;
    this.lowRomPage = lowRomPage;
    remapRAM();
    remap();
  }
  
  public void setSecondaryRomMapping(boolean rom) {
    this.isSecondaryRom = rom;
  }
  
  protected void mapROMs() {
    if (this.isSecondaryRom) {
      int i;
      if (this.lower && (i = this.baseAddr[9]) != -1) {
        this.readMap[0] = i;
        this.readMap[1] = i + 8192;
      } 
      if (this.upper) {
        i = this.baseAddr[10 + this.upperROM];
        if (i == -1)
          i = this.baseAddr[10]; 
        if (i != -1) {
          this.readMap[6] = i;
          this.readMap[7] = i + 8192;
        } 
      } 
      return;
    } 
    int addr;
    if (!this.plus && this.lower && (addr = this.baseAddr[9]) != -1) {
      this.readMap[0] = addr;
      this.readMap[1] = addr + 8192;
    } 
    if (this.plus && this.lower) {
      if (this.DEBUG_LOWER)
        System.err.println("plusROM lower = " + this.plusROM); 
      addr = this.baseAddr[27 + this.lowRomPage];
      if (addr == -1)
        addr = this.baseAddr[27]; 
      if (addr != -1) {
        this.readMap[this.lowRomLoc] = addr;
        this.readMap[this.lowRomLoc + 1] = addr + 8192;
      } 
    } 
    if (this.upper && !this.useplus) {
      addr = this.baseAddr[10 + this.upperROM];
      if (addr == -1)
        addr = this.baseAddr[10]; 
      if (addr != -1) {
        this.readMap[6] = addr;
        this.readMap[7] = addr + 8192;
      } 
    } 
    if (this.upper && this.useplus) {
      addr = this.baseAddr[27 + this.plusROM];
      if (addr == -1)
        addr = this.baseAddr[27]; 
      if (addr != -1) {
        this.readMap[6] = addr;
        this.readMap[7] = addr + 8192;
      } 
    } 
  }
  
  public int readPort(int port) {
    this.cal = Calendar.getInstance();
    int result = 255;
    if (port == 65278)
      result = 160; 
    return result;
  }
  
  public int readByte(int address, Object config) {
    return readByte(address);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\system\cpc\CPCMemory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */