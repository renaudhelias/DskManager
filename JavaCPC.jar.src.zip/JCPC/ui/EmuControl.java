package JCPC.ui;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JToggleButton;

public class EmuControl extends JPanel {
  public JButton controller;
  
  public JToggleButton filter;
  
  public JButton fullscreen;
  
  public JCheckBox fullsize;
  
  public JCheckBox lightgun;
  
  public JButton reset;
  
  public JButton syscart;
  
  public EmuControl() {
    initComponents();
  }
  
  private void initComponents() {
    this.fullsize = new JCheckBox();
    this.lightgun = new JCheckBox();
    this.controller = new JButton();
    this.filter = new JToggleButton();
    this.fullscreen = new JButton();
    this.syscart = new JButton();
    this.reset = new JButton();
    setForeground(new Color(255, 255, 255));
    FlowLayout flowLayout1 = new FlowLayout(0, 2, 5);
    flowLayout1.setAlignOnBaseline(true);
    setLayout(flowLayout1);
    this.fullsize.setFont(new Font("Dialog", 0, 11));
    this.fullsize.setText("Fullsize");
    this.fullsize.setFocusPainted(false);
    this.fullsize.setFocusable(false);
    add(this.fullsize);
    this.lightgun.setFont(new Font("Dialog", 0, 11));
    this.lightgun.setText("Lightgun");
    this.lightgun.setFocusPainted(false);
    this.lightgun.setFocusable(false);
    add(this.lightgun);
    this.controller.setFont(new Font("Dialog", 0, 11));
    this.controller.setText("Setup Controler (F10)");
    this.controller.setFocusPainted(false);
    this.controller.setFocusable(false);
    add(this.controller);
    this.filter.setFont(new Font("Dialog", 0, 11));
    this.filter.setText("Filter (F7)");
    this.filter.setFocusPainted(false);
    this.filter.setFocusable(false);
    add(this.filter);
    this.fullscreen.setFont(new Font("Dialog", 0, 11));
    this.fullscreen.setText("Fullscreen (ALT + Enter)");
    this.fullscreen.setFocusPainted(false);
    this.fullscreen.setFocusable(false);
    add(this.fullscreen);
    this.syscart.setFont(new Font("Dialog", 0, 11));
    this.syscart.setText("System Cart.");
    this.syscart.setFocusPainted(false);
    this.syscart.setFocusable(false);
    add(this.syscart);
    this.reset.setFont(new Font("Dialog", 0, 11));
    this.reset.setText("Reset (F12)");
    this.reset.setFocusPainted(false);
    this.reset.setFocusable(false);
    add(this.reset);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCP\\ui\EmuControl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */