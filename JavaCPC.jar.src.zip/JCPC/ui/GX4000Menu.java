package JCPC.ui;

import JCPC.system.cpc.GateArray;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.KeyStroke;

public class GX4000Menu extends JPanel {
  public JMenuBar Menu;
  
  private ButtonGroup buttonGroup1;
  
  public JCheckBoxMenuItem jCheckBoxMenuItem1;
  
  public JCheckBoxMenuItem jCheckBoxMenuItem2;
  
  public JCheckBoxMenuItem jCheckBoxMenuItem3;
  
  public JCheckBoxMenuItem jCheckBoxMenuItem4;
  
  private JCheckBoxMenuItem jCheckBoxMenuItem5;
  
  private JCheckBoxMenuItem jCheckBoxMenuItem6;
  
  private JMenu jMenu1;
  
  private JMenu jMenu2;
  
  private JMenu jMenu3;
  
  private JMenu jMenu4;
  
  public JMenuItem jMenuItem1;
  
  public JMenuItem jMenuItem2;
  
  public JMenuItem jMenuItem3;
  
  public JMenuItem jMenuItem4;
  
  public JMenuItem jMenuItem5;
  
  private JMenuItem jMenuItem6;
  
  public JMenuItem jMenuItem7;
  
  public JMenuItem jMenuItem8;
  
  private JPopupMenu.Separator jSeparator1;
  
  private JPopupMenu.Separator jSeparator2;
  
  private JPopupMenu.Separator jSeparator3;
  
  private JPopupMenu.Separator jSeparator4;
  
  private JPopupMenu.Separator jSeparator5;
  
  public static JRadioButtonMenuItem keyb1;
  
  public static JRadioButtonMenuItem keyb2;
  
  public GX4000Menu() {
    initComponents();
  }
  
  private void initComponents() {
    this.Menu = new JMenuBar();
    this.jMenu1 = new JMenu();
    this.jMenuItem1 = new JMenuItem();
    this.jMenuItem2 = new JMenuItem();
    this.jSeparator1 = new JPopupMenu.Separator();
    this.jMenuItem7 = new JMenuItem();
    this.jSeparator2 = new JPopupMenu.Separator();
    this.jMenuItem4 = new JMenuItem();
    this.jMenu4 = new JMenu();
    keyb2 = new JRadioButtonMenuItem();
    keyb1 = new JRadioButtonMenuItem();
    this.jMenu2 = new JMenu();
    this.jMenuItem3 = new JMenuItem();
    this.jMenuItem5 = new JMenuItem();
    this.jSeparator4 = new JPopupMenu.Separator();
    this.jCheckBoxMenuItem4 = new JCheckBoxMenuItem();
    this.jSeparator5 = new JPopupMenu.Separator();
    this.jCheckBoxMenuItem1 = new JCheckBoxMenuItem();
    this.jCheckBoxMenuItem2 = new JCheckBoxMenuItem();
    this.jCheckBoxMenuItem3 = new JCheckBoxMenuItem();
    this.jCheckBoxMenuItem5 = new JCheckBoxMenuItem();
    this.jCheckBoxMenuItem6 = new JCheckBoxMenuItem();
    this.jMenu3 = new JMenu();
    this.jMenuItem6 = new JMenuItem();
    this.jSeparator3 = new JPopupMenu.Separator();
    this.jMenuItem8 = new JMenuItem();
    this.buttonGroup1 = new ButtonGroup();
    this.jMenu1.setText("File");
    this.jMenuItem1.setText("Load DSK/SNA");
    this.jMenu1.add(this.jMenuItem1);
    this.jMenuItem2.setText("Load CPR (Cartridge)");
    this.jMenu1.add(this.jMenuItem2);
    this.jMenu1.add(this.jSeparator1);
    this.jMenuItem7.setText("Reset");
    this.jMenu1.add(this.jMenuItem7);
    this.jMenu1.add(this.jSeparator2);
    this.jMenuItem4.setAccelerator(KeyStroke.getKeyStroke(115, 8));
    this.jMenuItem4.setText("Quit");
    this.jMenuItem4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GX4000Menu.this.jMenuItem4ActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem4);
    this.Menu.add(this.jMenu1);
    this.jMenu4.setText("Emulation");
    this.buttonGroup1.add(keyb2);
    keyb2.setSelected(true);
    keyb2.setText("GX4000 (64k)");
    keyb2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GX4000Menu.this.keyb2ActionPerformed(evt);
          }
        });
    this.jMenu4.add(keyb2);
    this.buttonGroup1.add(keyb1);
    keyb1.setText("CPC Plus (576k)");
    keyb1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GX4000Menu.this.keyb1ActionPerformed(evt);
          }
        });
    this.jMenu4.add(keyb1);
    this.Menu.add(this.jMenu4);
    this.jMenu2.setText("Misc");
    this.jMenuItem3.setText("Configure Controller");
    this.jMenu2.add(this.jMenuItem3);
    this.jMenuItem5.setText("Configure CSD Emulation");
    this.jMenu2.add(this.jMenuItem5);
    this.jMenu2.add(this.jSeparator4);
    this.jCheckBoxMenuItem4.setText("Record GIF frames");
    this.jMenu2.add(this.jCheckBoxMenuItem4);
    this.jMenu2.add(this.jSeparator5);
    this.jCheckBoxMenuItem1.setText("Show FPS");
    this.jMenu2.add(this.jCheckBoxMenuItem1);
    this.jCheckBoxMenuItem2.setSelected(true);
    this.jCheckBoxMenuItem2.setText("Fullsize");
    this.jMenu2.add(this.jCheckBoxMenuItem2);
    this.jCheckBoxMenuItem3.setText("Monitor Surface");
    this.jMenu2.add(this.jCheckBoxMenuItem3);
    this.jCheckBoxMenuItem5.setSelected(true);
    this.jCheckBoxMenuItem5.setText("Enable Hardwaresprites");
    this.jCheckBoxMenuItem5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GX4000Menu.this.jCheckBoxMenuItem5ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jCheckBoxMenuItem5);
    this.jCheckBoxMenuItem6.setSelected(true);
    this.jCheckBoxMenuItem6.setText("Simple Spriterenderer");
    this.jCheckBoxMenuItem6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GX4000Menu.this.jCheckBoxMenuItem6ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jCheckBoxMenuItem6);
    this.Menu.add(this.jMenu2);
    this.jMenu3.setText("Help");
    this.jMenuItem6.setText("About");
    this.jMenuItem6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            GX4000Menu.this.jMenuItem6ActionPerformed(evt);
          }
        });
    this.jMenu3.add(this.jMenuItem6);
    this.jMenu3.add(this.jSeparator3);
    this.jMenuItem8.setText("Open Debugger");
    this.jMenu3.add(this.jMenuItem8);
    this.Menu.add(this.jMenu3);
    GroupLayout layout = new GroupLayout(this);
    setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 400, 32767));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGap(0, 300, 32767));
  }
  
  private void jMenuItem4ActionPerformed(ActionEvent evt) {
    System.exit(0);
  }
  
  private void jMenuItem6ActionPerformed(ActionEvent evt) {
    URL ic = getClass().getResource("_carts/logo.png");
    Icon icon = new ImageIcon(ic);
    JOptionPane.showMessageDialog(this, "JavaGX4000 - © 2012-2016\r\nMarkus Hohmann\r\nwebmaster@cpc-live.com", "About", 1, icon);
  }
  
  private void jCheckBoxMenuItem5ActionPerformed(ActionEvent evt) {
    (GateArray.cpc.getGateArray()).nosprites = !this.jCheckBoxMenuItem5.isSelected();
  }
  
  private void jCheckBoxMenuItem6ActionPerformed(ActionEvent evt) {
    (GateArray.cpc.getGateArray()).simplesprites = this.jCheckBoxMenuItem6.isSelected();
  }
  
  private void keyb1ActionPerformed(ActionEvent evt) {
    if (keyb1.isSelected()) {
      GateArray.cpc.setKeyMapping(0);
      (GateArray.cpc.getDisplay()).menumode = false;
    } 
  }
  
  private void keyb2ActionPerformed(ActionEvent evt) {
    if (keyb2.isSelected())
      GateArray.cpc.setKeyMapping(1); 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCP\\ui\GX4000Menu.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */