package JCPC.ui;

import java.awt.AWTEvent;
import java.awt.Component;
import java.util.Vector;

public class Timer extends Component implements Runnable {
  protected Vector events = new Vector(1);
  
  public static Timer timer = new Timer();
  
  protected Thread timerThread = null;
  
  protected Vector counters = new Vector(1);
  
  public Timer() {
    enableEvents(1L);
  }
  
  public synchronized void post(UserEvent event) {
    this.events.addElement(event);
    setVisible(!isVisible());
  }
  
  protected static void addCounter(Counter counter) {
    synchronized (timer) {
      timer.counters.addElement(counter);
      timer.checkThread();
    } 
  }
  
  protected static void removeCounter(Counter counter) {
    synchronized (timer) {
      timer.counters.removeElement(counter);
    } 
  }
  
  protected void checkThread() {
    if (this.timerThread == null) {
      this.timerThread = new Thread(this);
      this.timerThread.start();
    } 
  }
  
  public void processEvent(AWTEvent e) {
    UserEvent event = null;
    synchronized (this) {
      if (this.events.size() > 0) {
        event = this.events.firstElement();
        this.events.removeElementAt(0);
      } 
    } 
    if (event != null) {
      Counter counter = (Counter)event.getData();
      counter.listener.timerTick(counter);
    } 
  }
  
  public void run() {
    int count;
    do {
      synchronized (this) {
        count = this.counters.size();
        if (count == 0) {
          this.timerThread = null;
        } else {
          long time = System.currentTimeMillis();
          for (int i = 0; i < count; i++)
            ((Counter)this.counters.elementAt(i)).tick(this, time); 
        } 
        try {
          wait(10L);
        } catch (Exception exception) {}
      } 
    } while (count != 0);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCP\\ui\Timer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */