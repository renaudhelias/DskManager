package JCPC.ui;

import java.awt.event.KeyEvent;

public class KeyTranslator {
  public KeyEvent translate(KeyEvent e, String localkeys) {
    if (localkeys.equals("DE_DE")) {
      if (e.getKeyChar() == 'ü' || e.getKeyChar() == 'Ü') {
        e.setKeyCode(91);
        return e;
      } 
      if (e.getKeyChar() == 'ä' || e.getKeyChar() == 'Ä') {
        e.setKeyCode(222);
        return e;
      } 
      if (e.getKeyChar() == 'ö' || e.getKeyChar() == 'Ö') {
        e.setKeyCode(59);
        return e;
      } 
      if (e.getKeyChar() == 'ß' || e.getKeyChar() == '?') {
        e.setKeyCode(45);
        return e;
      } 
      if (e.getKeyCode() == 45) {
        e.setKeyCode(47);
        return e;
      } 
      if (e.getKeyCode() == 129) {
        e.setKeyCode(61);
        return e;
      } 
      if (e.getKeyCode() == 153) {
        e.setKeyCode(65406);
        return e;
      } 
      if (e.getKeyCode() == 130) {
        e.setKeyCode(9);
        return e;
      } 
      if (e.getKeyCode() == 520) {
        e.setKeyCode(92);
        return e;
      } 
      if (e.getKeyCode() == 521) {
        e.setKeyCode(93);
        return e;
      } 
      if (e.getKeyCode() == 90) {
        e.setKeyCode(89);
        return e;
      } 
      if (e.getKeyCode() == 89) {
        e.setKeyCode(90);
        return e;
      } 
    } 
    if (localkeys.equals("ES_ES")) {
      if (e.getKeyChar() == 'º' || e.getKeyChar() == '²') {
        e.setKeyCode(9);
        return e;
      } 
      if (e.getKeyChar() == 'ç' || e.getKeyChar() == 'Ç') {
        e.setKeyCode(92);
        return e;
      } 
      if (e.getKeyChar() == 'Ñ' || e.getKeyChar() == 'ñ') {
        e.setKeyCode(59);
        return e;
      } 
      if (e.getKeyCode() == 222) {
        e.setKeyCode(45);
        return e;
      } 
      if (e.getKeyCode() == 45) {
        e.setKeyCode(47);
        return e;
      } 
      if (e.getKeyCode() == 129) {
        e.setKeyCode(222);
        return e;
      } 
      if (e.getKeyCode() == 521) {
        e.setKeyCode(93);
        return e;
      } 
      if (e.getKeyCode() == 518) {
        e.setKeyCode(61);
        return e;
      } 
      if (e.getKeyCode() == 153) {
        e.setKeyCode(65406);
        return e;
      } 
      if (e.getKeyCode() == 128) {
        e.setKeyCode(91);
        return e;
      } 
    } 
    if (localkeys.equals("FR_FR")) {
      if (e.getKeyCode() == 515) {
        e.setKeyCode(93);
        return e;
      } 
      if (e.getKeyCode() == 130) {
        e.setKeyCode(91);
        return e;
      } 
      if (e.getKeyCode() == 57) {
        e.setKeyCode(57);
        return e;
      } 
      if (e.getKeyCode() == 522) {
        e.setKeyCode(45);
        return e;
      } 
      if (e.getKeyCode() == 81) {
        e.setKeyCode(65);
        return e;
      } 
      if (e.getKeyCode() == 65) {
        e.setKeyCode(81);
        return e;
      } 
      if (e.getKeyCode() == 90) {
        e.setKeyCode(87);
        return e;
      } 
      if (e.getKeyCode() == 87) {
        e.setKeyCode(90);
        return e;
      } 
      if (e.getKeyChar() == '²' || (e.getKeyCode() == 0 && e.getKeyChar() == Character.MAX_VALUE)) {
        e.setKeyCode(92);
        return e;
      } 
      if (e.getKeyChar() == '%' || e.getKeyChar() == 'ù') {
        e.setKeyCode(222);
        return e;
      } 
      if (e.getKeyCode() == 151) {
        e.setKeyCode(65406);
        return e;
      } 
      if (e.getKeyCode() == 77) {
        e.setKeyCode(59);
        return e;
      } 
      if (e.getKeyCode() == 44) {
        e.setKeyCode(77);
        return e;
      } 
      if (e.getKeyCode() == 59) {
        e.setKeyCode(44);
        return e;
      } 
      if (e.getKeyCode() == 517) {
        e.setKeyCode(47);
        return e;
      } 
      if (e.getKeyCode() == 513) {
        e.setKeyCode(46);
        return e;
      } 
    } 
    return e;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCP\\ui\KeyTranslator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */