package JCPC.ui;

import JCPC.core.cpu.Z80;
import JCPC.core.device.crtc.Basic6845;
import JCPC.system.cpc.CPC;
import JCPC.system.cpc.GateArray;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.WritableRaster;
import java.io.File;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Display extends JDesktopPane {
  public int showdrives = 0;
  
  public int lowlines = 280;
  
  public int highlines = this.lowlines * 2;
  
  protected static String[] cartridges = new String[] { 
      "_barbarian2.png", "_batman.png", "_burninrubber.png", "_copter271.png", "_crazycars2.png", "_dicktracy.png", "_epyxworldofsports.png", "_fireandforget2.png", "_klax.png", "_mystical.png", 
      "_navyseals.png", "_noexit.png", "_operationthunderbolt.png", "_pang.png", "_panzakickboxing.png", "_plotting.png", "_protennistour.png", "_robocop2.png", "_skeetshoot.png", "_superpinballmagic.png", 
      "_switchblade.png", "_tenniscup2.png", "_theenforcer.png", "_tintinonthemoon.png", "_wildstreets.png" };
  
  public static final Image[] Cart = new Image[cartridges.length];
  
  public static String[] carts = new String[] { 
      "Barbarian II", "Batman", "Burnin' Rubber", "Copter 271", "Crazy Cars II", "Dick Tracy", "Epyx World Of Sports", "Fire And Forget II", "Klax", "Mystical", 
      "Navy Seals", "No Exit", "Operation Thunderbolt", "Pang", "Panza Kickboxing", "Plotting", "Pro Tennis Tour", "Robocop II", "Skeet Shoot", "Super Pinball Magic", 
      "Switchblade", "Tennis Cup II", "The Enforcer", "Tintin On The Moon", "Wildstreets", "CPC Plus System" };
  
  public int[] ppixels = new int[768 * this.lowlines];
  
  public boolean fullscreen = false;
  
  public static boolean showdisks = false;
  
  public static boolean drawmonitor = false;
  
  boolean DEBUG_FPS = false;
  
  boolean DEBUG_MIPS = false;
  
  boolean DEBUG_SCREEN = false;
  
  public boolean DEBUG_SPRITES = false;
  
  public static String vscroll = "0";
  
  long mLastFPSTime;
  
  int mNextFPS;
  
  public int mCurrFPS;
  
  public void doTouchFPS() {
    long time = System.currentTimeMillis();
    this.mNextFPS++;
    if (time - this.mLastFPSTime >= 1000L) {
      this.mCurrFPS = this.mNextFPS;
      this.mNextFPS = 0;
      this.mLastFPSTime = time;
    } 
  }
  
  public static boolean scanlines = true;
  
  public static final Color LED_ON = new Color(32, 255, 32);
  
  public static final Color LED_OFF = new Color(32, 96, 32, 192);
  
  public static final Color LED_BORDER = new Color(96, 64, 64, 160);
  
  public static final Color fLED_ON = new Color(255, 96, 32);
  
  public static final Color fLED_OFF = new Color(96, 32, 32, 192);
  
  public static final Color fLED_BORDER = new Color(96, 64, 64, 160);
  
  public static final Color SCAN = new Color(20, 20, 20, 144);
  
  public static final Color SCANL = new Color(20, 20, 20, 48);
  
  public int storesna;
  
  public int restoresna;
  
  public int crtc;
  
  final URL disc = getClass().getResource("3disc.gif");
  
  final Image Disc = getToolkit().getImage(this.disc);
  
  final URL iel = getClass().getResource("logo.png");
  
  final Image logo = getToolkit().getImage(this.iel);
  
  final URL imf = getClass().getResource("glossywindow.png");
  
  final Image masks = getToolkit().getImage(this.imf);
  
  final URL mimf = getClass().getResource("monitor.png");
  
  final URL dist = getClass().getResource("MonitorPieceBezel.png");
  
  final Image Dist = getToolkit().getImage(this.dist);
  
  final URL gx = getClass().getResource("gxlogo.png");
  
  final Image gxl = getToolkit().getImage(this.gx);
  
  final URL driva = getClass().getResource("resources/driveA.png");
  
  final Image drivea = getToolkit().getImage(this.driva);
  
  final URL drivb = getClass().getResource("resources/driveB.png");
  
  final Image driveb = getToolkit().getImage(this.drivb);
  
  public boolean large;
  
  public static boolean ledOn;
  
  protected int divider = 1;
  
  public static final int CENTER = 0;
  
  public static final Dimension SCALE_1 = new Dimension(1, 1);
  
  public static final Dimension SCALE_2 = new Dimension(2, 2);
  
  public static final Dimension SCALE_1x2 = new Dimension(1, 2);
  
  protected String snapl = "Snapshot loaded... Press F5 to reload";
  
  protected String snaps = "Snapshot stored... Press F5 to load";
  
  protected String crtctype = "CRTC type ";
  
  protected String crtctype2 = "... Press F8 to change";
  
  protected BufferedImage image;
  
  protected WritableRaster raster;
  
  protected WritableRaster praster;
  
  protected WritableRaster leftraster;
  
  protected WritableRaster rightraster;
  
  protected int[] pixels;
  
  protected int imageWidth;
  
  protected int imageHeight;
  
  protected int scaleWidth;
  
  protected int scaleHeight;
  
  protected Rectangle imageRect = new Rectangle();
  
  protected Rectangle sourceRect = null;
  
  protected int imagePos = 0;
  
  protected boolean sameSize;
  
  protected boolean painted = true;
  
  BufferedImage moniter;
  
  URL[] cart = new URL[cartridges.length];
  
  int pos = 0;
  
  double div;
  
  int off;
  
  int splitrgb;
  
  int[] rgb;
  
  boolean frame;
  
  AnimatedGifEncoder enc;
  
  public boolean isgifrecording;
  
  BufferedImage gimage;
  
  int gifdelay;
  
  Thread invoker;
  
  public boolean turbo;
  
  BufferedImage output;
  
  int width;
  
  public BufferedImage leftside;
  
  public BufferedImage rightside;
  
  public int[] leftpixels;
  
  public int[] rightpixels;
  
  public JPanel left;
  
  public JPanel right;
  
  public boolean drawborder;
  
  protected boolean borderinit;
  
  int fpstimer;
  
  int errorhit;
  
  int errortimer;
  
  int lx;
  
  int ly;
  
  int blurtimer;
  
  BufferedImage darker;
  
  boolean giffing;
  
  int logotimer;
  
  int logopos;
  
  public boolean penonscreen;
  
  int a;
  
  int b;
  
  int c;
  
  JFrame spriteframe;
  
  BufferedImage sprites;
  
  JLabel spritelabel;
  
  JFrame spriteframe2;
  
  BufferedImage sprites2;
  
  JLabel spritelabel2;
  
  BufferedImage trans;
  
  Font fontlarge;
  
  Font fontsmall;
  
  Graphics g2;
  
  BufferedImage sprites3;
  
  final URL cursorl;
  
  final Image lightPen;
  
  Font font2large;
  
  Font font2small;
  
  public int xdist;
  
  public int ydist;
  
  public boolean oldSkin;
  
  public boolean oldSize;
  
  int transp;
  
  int transpdir;
  
  int redd;
  
  int greenn;
  
  int bluee;
  
  int rdir;
  
  int gdir;
  
  int bdir;
  
  int shift;
  
  int shiftdir;
  
  public int[] getPixel(int x, int y) {
    return this.raster.getPixel(x, y, this.pixels);
  }
  
  public int putRGB(int red, int green, int blue) {
    return red << 16 | green << 8 | blue;
  }
  
  protected void getRGB(int value, int[] rgb) {
    rgb[0] = value >> 16 & 0xFF;
    rgb[1] = value >> 8 & 0xFF;
    rgb[2] = value & 0xFF;
  }
  
  public Display() {
    this.div = 1.25D;
    this.rgb = new int[] { 0, 0, 0 };
    this.isgifrecording = false;
    this.gifdelay = 0;
    this.drawborder = false;
    this.borderinit = false;
    this.fpstimer = 0;
    this.errorhit = 0;
    this.errortimer = 0;
    this.giffing = false;
    this.logotimer = 0;
    this.logopos = 0;
    this.a = 0;
    this.b = 0;
    this.c = 0;
    this.fontlarge = new Font("", 1, 11);
    this.fontsmall = new Font("", 1, 8);
    this.cursorl = getClass().getResource("Pen-icon.png");
    this.lightPen = getToolkit().getImage(this.cursorl);
    this.font2large = new Font("", 1, 16);
    this.font2small = new Font("", 1, 10);
    this.xdist = 0;
    this.ydist = 0;
    this.transp = 32;
    this.transpdir = 2;
    this.redd = 0;
    this.greenn = 0;
    this.bluee = 0;
    this.rdir = 2;
    this.gdir = 3;
    this.bdir = 4;
    this.shift = 64;
    this.shiftdir = 2;
    this.menupos = -600;
    this.shootme = false;
    this.impos = 0;
    this.lpos = 550;
    this.lw = 0;
    this.info = "";
    this.spx = new int[16];
    this.spy = new int[16];
    this.spw = new int[16];
    this.sph = new int[16];
    this.started = false;
    try {
      EventQueue.invokeLater(new Runnable() {
            public void run() {
              for (int i = 0; i < Display.cartridges.length; i++) {
                Display.this.cart[i] = getClass().getResource("_carts/" + Display.cartridges[i]);
                Display.Cart[i] = Display.this.getToolkit().getImage(Display.this.cart[i]);
              } 
            }
          });
      BufferedImage moni = ImageIO.read(this.mimf);
      this.moniter = new BufferedImage(moni.getWidth(), moni.getHeight(), 2);
      this.moniter.createGraphics().drawImage(moni, 0, 0, (ImageObserver)null);
      for (int x = 0; x < this.moniter.getWidth(); x++) {
        for (int y = 0; y < this.moniter.getHeight(); y++) {
          Color grab = new Color(this.moniter.getRGB(x, y));
          if (grab.getBlue() == 0 && grab.getGreen() == 0 && grab.getRed() == 0)
            this.moniter.setRGB(x, y, 0); 
        } 
      } 
    } catch (Exception exception) {}
    enableEvents(4L);
    setFocusTraversalKeysEnabled(false);
    setRequestFocusEnabled(true);
  }
  
  public void startRec() {
    if (this.isgifrecording)
      return; 
    this.isgifrecording = true;
  }
  
  public void addFrame() {
    if (!this.isgifrecording)
      return; 
    this.invoker = new Thread() {
        public void run() {
          Display.this.enc = new AnimatedGifEncoder();
          Display.this.enc.start("output.gif");
          Display.this.enc.setRepeat(0);
          Display.this.enc.setTransparent(null);
          while (Display.this.isgifrecording) {
            if (Display.this.gimage == null)
              Display.this.gimage = new BufferedImage(384, 280, 1); 
            Display.this.gimage.createGraphics().drawImage(Display.this.image, 0, 0, 384, 280, null);
            Display.this.enc.addFrame(Display.this.gimage);
            try {
              Thread.sleep(25L);
            } catch (Exception exception) {}
          } 
        }
      };
    this.invoker.start();
  }
  
  public void stopRec() {
    if (!this.isgifrecording)
      return; 
    this.isgifrecording = false;
    this.giffing = false;
    while (this.invoker.isAlive()) {
      try {
        Thread.sleep(1L);
      } catch (Exception exception) {}
    } 
    this.enc.finish();
  }
  
  protected void CRTFilter() {
    try {
      Thread.yield();
    } catch (Exception exception) {}
    this.splitrgb = 0;
    this.off = 0;
    this.frame = !this.frame;
    for (int y = 0; y < this.lowlines; y++) {
      for (int x = 0; x < 768; x++) {
        int r, g, b;
        if (y % 2 == (this.frame ? 1 : 0)) {
          this.splitrgb = (this.splitrgb == 0) ? 1 : 0;
        } else {
          this.splitrgb = (this.splitrgb == 2) ? 3 : 2;
        } 
        getRGB(this.pixels[this.off], this.rgb);
        switch (this.splitrgb) {
          case 0:
            this.pixels[this.off] = putRGB(this.rgb[0], (int)(this.rgb[1] / this.div), (int)(this.rgb[2] / this.div));
            break;
          case 1:
            this.pixels[this.off] = putRGB((int)(this.rgb[0] / this.div), this.rgb[1], (int)(this.rgb[2] / this.div));
            break;
          case 2:
            this.pixels[this.off] = putRGB((int)(this.rgb[0] / this.div), (int)(this.rgb[1] / this.div), this.rgb[2]);
            break;
          case 3:
            r = (int)(this.rgb[0] * this.div);
            g = (int)(this.rgb[1] * this.div);
            b = (int)(this.rgb[2] * this.div);
            if (r > 255)
              r = 255; 
            if (g > 255)
              g = 255; 
            if (b > 255)
              b = 255; 
            this.pixels[this.off] = putRGB(r, g, b);
            break;
        } 
        this.off++;
      } 
    } 
    if (this.leftside != null && this.fullscreen) {
      this.splitrgb = 0;
      for (this.off = 0; this.off < this.leftpixels.length; this.off++)
        this.leftpixels[this.off] = 0; 
      for (this.off = 0; this.off < this.rightpixels.length; this.off++)
        this.rightpixels[this.off] = 0; 
    } 
  }
  
  public void setImageSize(Dimension size, Dimension scale) {
    this.imageWidth = size.width;
    this.imageHeight = size.height;
    this.image = new BufferedImage(this.imageWidth, this.imageHeight, 1);
    this.image.setAccelerationPriority(1.0F);
    this.raster = this.image.getRaster();
    this.pixels = new int[768 * this.lowlines];
    for (int i = 0; i < this.pixels.length; i++)
      this.pixels[i] = -16777216; 
    if (scale == null)
      scale = SCALE_1; 
    this.scaleWidth = this.imageWidth * scale.width;
    this.scaleHeight = this.imageHeight * scale.height;
    checkSize();
    Graphics g = getGraphics();
    if (g != null) {
      size = getSize();
      g.setColor(getBackground());
      g.fillRect(0, 0, size.width, size.height);
      paint(g);
      g.dispose();
    } 
  }
  
  public void setBounds(int x, int y, int width, int height) {
    super.setBounds(x, y, width, height);
    checkSize();
  }
  
  protected void checkSize() {
    Dimension size = getSize();
    Insets insets = getInsets();
    int clientWidth = size.width - insets.left - insets.right;
    int clientHeight = size.height - insets.top - insets.bottom;
    this.imageRect = new Rectangle(insets.left + (clientWidth - this.scaleWidth) / 2, insets.top + (clientHeight - this.scaleHeight) / 2, this.scaleWidth, this.scaleHeight);
  }
  
  public int[] getPixels() {
    return this.pixels;
  }
  
  public void updateLightpen(int x, int y) {
    this.lx = x;
    this.ly = y;
  }
  
  public void updateImage(boolean wait) {
    checkSize();
    doTouchFPS();
    if (this.mCurrFPS < 20 && !GateArray.cpc.doTurbo && !this.large) {
      this.fpstimer++;
      if (this.fpstimer > 30) {
        this.fpstimer = 0;
        this.errorhit++;
        if (this.errorhit < 10) {
          GateArray.cpc.reSync();
          System.out.println("Slow Performance: " + this.mCurrFPS + "fps - Adjusting");
        } 
      } 
    } else {
      this.errortimer++;
      if (this.errortimer > 150)
        this.errorhit = 0; 
      this.fpstimer = 0;
    } 
    int off = 0;
    int lastPix = 0;
    if (this.fullscreen && this.leftside != null && this.drawborder) {
      if (!this.borderinit) {
        this.leftraster = this.leftside.getRaster();
        this.rightraster = this.rightside.getRaster();
        this.borderinit = true;
      } 
      int pipos = 0;
      int prpos = 0;
      int pval = GateArray.cpc.getGateArray().getBorder();
      for (int i = 0; i < this.lowlines; i++) {
        int k;
        for (k = 0; k < this.leftside.getWidth(); k++)
          this.leftpixels[pipos++] = pval; 
        for (k = 0; k < this.rightside.getWidth(); k++)
          this.rightpixels[prpos++] = pval; 
      } 
    } 
    if (scanlines) {
      CRTFilter();
      for (int y = 0; y < this.imageHeight - 1; y++) {
        off = y * this.imageWidth;
        for (int x = 0; x < this.imageWidth; x++) {
          off++;
          try {
            lastPix = this.pixels[off] = (lastPix & 0xFEFEFE) + (this.pixels[off] & 0xFEFEFE) >> 1;
          } catch (Exception exception) {}
        } 
      } 
    } 
    if (this.fullscreen && this.leftside != null && this.drawborder) {
      Graphics l = this.left.getGraphics();
      Graphics r = this.right.getGraphics();
      this.leftraster.setDataElements(0, 0, this.leftside.getWidth(), this.leftside.getHeight(), this.leftpixels);
      this.rightraster.setDataElements(0, 0, this.rightside.getWidth(), this.rightside.getHeight(), this.rightpixels);
      Graphics2D l2 = (Graphics2D)l;
      l2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
      l = l2;
      Graphics2D r2 = (Graphics2D)r;
      r2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
      r = r2;
      l.drawImage(this.leftside, 0, 0, this.left.getWidth(), this.left.getHeight(), null);
      r.drawImage(this.rightside, 0, 0, this.right.getWidth(), this.right.getHeight(), null);
    } 
    if (this.imageRect.width != 0 && this.imageRect.height != 0 && isShowing()) {
      if (this.menupos > (this.large ? -600 : -300)) {
        if (this.blurtimer == 0) {
          this.raster.setDataElements(0, 0, this.imageWidth, this.imageHeight, this.pixels);
          if (this.darker == null) {
            this.darker = new BufferedImage(32, 32, 2);
            Color trans = new Color(0, 0, 0, 60);
            Graphics t = this.darker.createGraphics();
            t.setColor(trans);
            t.fillRect(0, 0, 32, 32);
          } 
          this.image.createGraphics().drawImage(this.darker, 0, 0, this.image.getWidth(), this.image.getHeight(), null);
        } 
        this.blurtimer++;
        if (this.blurtimer < 8) {
          repaint(0, 0, getWidth(), getHeight());
          return;
        } 
        this.blurtimer = 0;
        return;
      } 
      this.raster.setDataElements(0, 0, this.imageWidth, this.imageHeight, this.pixels);
      if (this.logopos < 300)
        if (!CPC.gx4000) {
          this.image.createGraphics().drawImage(this.logo, 0, this.logopos, this.image.getWidth(), this.image.getHeight(), this);
          this.logotimer++;
          if (this.logotimer > 150)
            this.logopos += 8; 
        }  
      repaint(0, 0, getWidth(), getHeight());
    } 
    if (wait || this.isgifrecording)
      waitPainted(); 
    if (this.isgifrecording && !this.giffing) {
      this.giffing = true;
      addFrame();
    } 
  }
  
  public void waitPainted() {
    while (!this.painted)
      Thread.yield(); 
  }
  
  public void showSprites() {
    int[] result = GateArray.cpc.getGateArray().getField();
    if (this.spriteframe == null) {
      this.sprites = new BufferedImage(640, 400, 1);
      this.spriteframe = new JFrame("Sprites");
      this.spritelabel = new JLabel();
      this.spritelabel.setIcon(new ImageIcon(this.sprites));
      this.spriteframe.setResizable(false);
      this.spriteframe.setLayout(new BorderLayout());
      this.spriteframe.add(this.spritelabel, "Center");
      this.spriteframe.pack();
      this.spriteframe.setVisible(true);
    } 
    Graphics g = this.sprites.getGraphics();
    g.setColor(new Color(20, 60, 128));
    g.fillRect(0, 0, 768, this.highlines);
    g.setFont(this.large ? this.fontlarge : this.fontsmall);
    String f = "";
    try {
      int xpos = 0;
      int i;
      for (i = 0; i < 8; i++) {
        g.setColor(Color.white);
        g.drawRect(4 + xpos, 19, 33, 33);
        g.drawImage(GateArray.cpc.memory.spriteImg[i], 5 + xpos, 20, 32, 32, this);
        f = GateArray.cpc.memory.getSpriteX(i) + "," + GateArray.cpc.memory.getSpriteY(i) + " - " + (GateArray.cpc.getGateArray()).xm[i] + "," + (GateArray.cpc.getGateArray()).ym[i];
        g.drawString(f, 4 + xpos, 94);
        xpos += 80;
      } 
      xpos = 0;
      for (i = 8; i < 16; i++) {
        g.setColor(Color.white);
        g.drawRect(4 + xpos, 219, 33, 33);
        g.drawImage(GateArray.cpc.memory.spriteImg[i], 5 + xpos, 220, 32, 32, this);
        f = GateArray.cpc.memory.getSpriteX(i) + "," + GateArray.cpc.memory.getSpriteY(i) + " - " + (GateArray.cpc.getGateArray()).xm[i] + "," + (GateArray.cpc.getGateArray()).ym[i];
        g.drawString(f, 4 + xpos, 294);
        xpos += 80;
      } 
      this.spritelabel.setIcon(new ImageIcon(this.sprites));
    } catch (Exception exception) {}
    drawSprites();
  }
  
  public void drawSprites() {
    if (this.spriteframe2 == null) {
      this.sprites2 = new BufferedImage(768, this.highlines, 1);
      this.sprites3 = new BufferedImage(768, this.lowlines, 2);
      this.praster = this.sprites3.getRaster();
      this.trans = new BufferedImage(16, 16, 1);
      Graphics d = this.trans.createGraphics();
      d.setColor(Color.white);
      d.fillRect(0, 0, 8, 8);
      d.fillRect(8, 8, 8, 8);
      d.setColor(Color.lightGray);
      d.fillRect(8, 0, 8, 8);
      d.fillRect(0, 8, 8, 8);
      this.spriteframe2 = new JFrame("Sprites");
      this.spritelabel2 = new JLabel();
      this.spritelabel2.setIcon(new ImageIcon(this.sprites2));
      this.spriteframe2.setResizable(false);
      this.spriteframe2.setLayout(new BorderLayout());
      this.spriteframe2.add(this.spritelabel2, "Center");
      this.spriteframe2.pack();
      this.spriteframe2.setVisible(true);
      this.g2 = this.sprites2.getGraphics();
    } 
    for (int x = 0; x < 800; x += 16) {
      for (int y = 0; y < 600; y += 16)
        this.g2.drawImage(this.trans, x, y, this); 
    } 
    try {
      this.praster.setDataElements(0, 0, this.imageWidth, this.imageHeight, this.ppixels);
      this.sprites2.getGraphics().drawImage(this.sprites3, 0, 0, 768, this.highlines, this);
      this.spritelabel2.getGraphics().drawImage(this.sprites2, 0, 0, 768, this.highlines, this);
    } catch (Exception exception) {}
  }
  
  public void setFullscreen(boolean full) {
    this.fullscreen = full;
  }
  
  protected void paintImage(Graphics g) {
    if (this.oldSize != this.large && this.menupos <= -300) {
      this.oldSize = this.large;
      this.menupos = this.large ? -600 : -300;
    } else if (this.oldSize != this.large && this.menupos >= -50) {
      this.oldSize = this.large;
      this.menupos = this.large ? -50 : (GX4000.hasSkin ? 0 : -25);
    } else if (this.oldSkin != GX4000.hasSkin && this.menupos <= -300) {
      this.oldSkin = GX4000.hasSkin;
      this.menupos = this.large ? -600 : -300;
    } else if (this.oldSkin != GX4000.hasSkin && this.menupos >= -50) {
      this.oldSkin = GX4000.hasSkin;
      this.menupos = this.large ? -50 : (GX4000.hasSkin ? 0 : -25);
    } 
    if (scanlines || !this.large || this.fullscreen) {
      Graphics2D g2 = (Graphics2D)g;
      g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
      g = g2;
    } 
    g.setFont(this.large ? this.font2large : this.font2small);
    if (this.fullscreen) {
      Graphics2D g2 = (Graphics2D)g;
      g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
      g = g2;
      if (scanlines)
        this.image.createGraphics().drawImage(this.Dist, 0, 0, 768, this.lowlines, this); 
      g.drawImage(this.image, 0, 0, getWidth(), getHeight(), this);
      if (this.penonscreen)
        g.drawImage(this.lightPen, this.lx + 8, this.ly + 8, 256, 256, null); 
      if (this.turbo) {
        g.setColor(LED_ON);
        g.fillRect(4 * this.divider, 3 * this.divider, 7 * this.divider, 3 * this.divider);
        g.setColor(LED_BORDER);
        g.drawString("x" + CPC.turbospeed, 4 * this.divider, 15 * this.divider);
        g.drawRect(3 * this.divider, 2 * this.divider, 8 * this.divider, 4 * this.divider);
        g.setColor(LED_ON);
        g.drawString("x" + CPC.turbospeed, 3 * this.divider, 14 * this.divider);
      } 
      if (showdisks && showtime > 1) {
        g.drawImage(this.Disc, 24 * this.divider, 3 * this.divider, (this.divider != 1) ? 26 : 13, (this.divider != 1) ? 32 : 16, null);
        g.drawImage(this.Disc, 40 * this.divider, 3 * this.divider, (this.divider != 1) ? 26 : 13, (this.divider != 1) ? 32 : 16, null);
        showtime--;
      } 
      return;
    } 
    if (drawmonitor) {
      g.drawImage(this.image, this.large ? 60 : 30, this.large ? 80 : 40, this.large ? 768 : 384, this.large ? this.highlines : this.lowlines, null);
    } else {
      g.drawImage(this.image, 0, 0, this.large ? 768 : 384, this.large ? this.highlines : this.lowlines, null);
    } 
    if (this.DEBUG_SCREEN) {
      int[] result = GateArray.cpc.getGateArray().getField();
      g.setColor(new Color(255, 255, 255, 96));
      g.fillRect(0, 0, this.large ? 768 : 384, this.large ? result[2] : (result[2] / 2));
      g.fillRect(0, 0, this.large ? result[0] : (result[0] / 2), this.large ? this.highlines : this.lowlines);
      g.fillRect(0, this.large ? result[3] : (result[3] / 2), this.large ? 768 : 384, this.large ? this.highlines : this.lowlines);
      g.fillRect(this.large ? result[1] : (result[1] / 2), 0, this.large ? result[1] : (result[1] / 2), this.large ? this.highlines : this.lowlines);
    } 
    if (this.DEBUG_SPRITES)
      showSprites(); 
    if (this.showdrives > 0) {
      this.showdrives--;
      if (GX4000.toDriveB) {
        g.drawImage(this.driveb, this.large ? 380 : 190, this.large ? 100 : 50, this.large ? 340 : 170, this.large ? 329 : 165, null);
      } else {
        g.drawImage(this.drivea, this.large ? 20 : 10, this.large ? 100 : 50, this.large ? 340 : 170, this.large ? 329 : 165, null);
      } 
    } 
    if (scanlines && drawmonitor) {
      g.setColor(this.large ? SCAN : SCANL);
      for (int i = 0; i < this.imageRect.height; i += 2)
        g.drawLine(this.large ? 60 : 30, (this.large ? 80 : 40) + i, this.large ? 828 : 414, (this.large ? 80 : 40) + i); 
    } 
    if (drawmonitor)
      g.drawImage(this.Dist, this.large ? 60 : 30, this.large ? 80 : 40, this.large ? 768 : 384, this.large ? this.highlines : this.lowlines, this); 
    if (scanlines && !drawmonitor)
      g.drawImage(this.Dist, 0, 0, this.large ? 768 : 384, this.large ? this.highlines : this.lowlines, this); 
    if (this.storesna > 0) {
      g.setColor(LED_ON);
      this.restoresna = 0;
      this.crtc = 0;
      g.drawString(this.snaps, this.large ? 40 : 20, this.large ? 20 : 10);
      this.storesna--;
    } 
    if (this.restoresna > 0) {
      this.crtc = 0;
      this.storesna = 0;
      g.setColor(Color.GREEN);
      g.drawString(this.snapl, this.large ? 40 : 20, this.large ? 20 : 10);
      this.restoresna--;
    } 
    if (this.crtc > 0) {
      this.storesna = 0;
      this.restoresna = 0;
      g.setColor(Color.yellow);
      g.drawString(this.crtctype + Basic6845.CRTC + this.crtctype2, this.large ? 40 : 20, this.large ? 20 : 10);
      this.crtc--;
    } 
    if (GateArray.cpc.saveallowed && GateArray.cpc.storing() != 0) {
      g.setColor(Color.red);
      g.drawRect(0, 0, this.large ? 767 : 383, this.large ? 543 : 271);
      g.drawRect(1, 1, this.large ? 765 : 381, this.large ? 541 : 269);
    } 
    if (this.shootme) {
      File fil = new File("shots");
      if (!fil.exists())
        fil.mkdir(); 
      try {
        ImageIO.write(this.image, "PNG", new File("shots/" + this.impos++ + ".png"));
      } catch (Exception exception) {}
    } 
    if (this.menumode || this.menupos > (this.large ? -600 : -300)) {
      if (this.large) {
        int pos = 100 + this.menupos;
        this.shift += this.shiftdir;
        if (this.shift > 240)
          this.shiftdir = -2; 
        if (this.shift < 16)
          this.shiftdir = 2; 
        this.redd = this.shift;
        this.greenn = this.shift;
        this.bluee = this.shift;
        this.rdir = 1;
        this.gdir = 2;
        this.bdir = 3;
        g.drawImage(this.gxl, 60 + pos / 2, pos, 88, 428, this);
        int i;
        for (i = 0; i < carts.length - 11; i++) {
          for (int b = 0; b < 32; b += 2) {
            g.setColor(new Color(this.redd, this.greenn, this.bluee, this.transp));
            this.redd += this.rdir;
            this.greenn += this.gdir;
            this.bluee += this.bdir;
            if (this.redd > 220)
              this.rdir = -1; 
            if (this.redd < 40)
              this.rdir = 1; 
            if (this.greenn > 220)
              this.gdir = -2; 
            if (this.greenn < 40)
              this.gdir = 2; 
            if (this.bluee > 220)
              this.bdir = -3; 
            if (this.bluee < 40)
              this.bdir = 3; 
            g.fillRect(190, pos + b, 230, 2);
          } 
          g.drawImage(Cart[i], 200, pos, this);
          g.setColor(new Color(255, 255, 255, 150));
          g.drawRect(190, pos, 230, 32);
          g.drawString(carts[i], 238, pos + 20);
          g.drawString(carts[i], 239, pos + 20);
          g.drawString(carts[i], 240, pos + 20);
          pos += 32;
        } 
        pos = 100 + this.menupos;
        for (i = carts.length - 11; i < carts.length - 1; i++) {
          for (int b = 0; b < 32; b += 2) {
            g.setColor(new Color(this.redd, this.greenn, this.bluee, this.transp));
            this.redd += this.rdir;
            this.greenn += this.gdir;
            this.bluee += this.bdir;
            if (this.redd > 220)
              this.rdir = -1; 
            if (this.redd < 40)
              this.rdir = 1; 
            if (this.greenn > 220)
              this.gdir = -2; 
            if (this.greenn < 40)
              this.gdir = 2; 
            if (this.bluee > 220)
              this.bdir = -3; 
            if (this.bluee < 40)
              this.bdir = 3; 
            g.fillRect(490, pos + b, 230, 2);
          } 
          g.drawImage(Cart[i], 500, pos, this);
          g.setColor(new Color(255, 255, 255, 150));
          g.drawRect(490, pos, 230, 32);
          g.drawString(carts[i], 538, pos + 20);
          g.drawString(carts[i], 539, pos + 20);
          g.drawString(carts[i], 540, pos + 20);
          pos += 32;
        } 
        this.transp += this.transpdir;
        if (this.transp < 128)
          this.transpdir = 2; 
        if (this.transp > 224)
          this.transpdir = -2; 
      } else {
        int pos = 50 + this.menupos;
        this.xdist = GX4000.hasSkin ? 0 : -15;
        this.ydist = GX4000.hasSkin ? 0 : -25;
        g.drawImage(this.gxl, 50 + this.xdist, pos + 30, this);
        int d = 20;
        int i;
        for (i = 0; i < carts.length - 11; i++) {
          g.setColor(new Color(255 - d, 255 - d, 55, 255));
          g.drawRect(95 + this.xdist, pos, 135, 16);
          g.setColor(new Color(d, d / 2, 200, 128));
          g.fillRect(95 + this.xdist, pos, 136, 16);
          g.drawImage(Cart[i], 100 + this.xdist, pos, 16, 16, this);
          g.setColor(Color.white);
          g.drawString(carts[i], 119 + this.xdist, pos + 10);
          g.drawString(carts[i], 120 + this.xdist, pos + 10);
          pos += 16;
          d += 12;
        } 
        pos = 50 + this.menupos;
        d = 20;
        for (i = carts.length - 11; i < carts.length - 1; i++) {
          g.setColor(new Color(255 - d, 255 - d, 55, 255));
          g.drawRect(245 + this.xdist, pos, 135, 16);
          g.setColor(new Color(d, d / 2, 200, 128));
          g.fillRect(245 + this.xdist, pos, 136, 16);
          g.drawImage(Cart[i], 250 + this.xdist, pos, 16, 16, this);
          g.setColor(Color.white);
          g.drawString(carts[i], 269 + this.xdist, pos + 10);
          g.drawString(carts[i], 268 + this.xdist, pos + 10);
          pos += 16;
          d += 12;
        } 
      } 
      if (this.menumode) {
        if (this.menupos < (this.large ? -50 : (GX4000.hasSkin ? 0 : -25)))
          this.menupos += this.large ? 8 : 4; 
      } else {
        this.menupos -= this.large ? 8 : 4;
      } 
    } 
    if (this.penonscreen)
      g.drawImage(this.lightPen, this.lx + (this.large ? 8 : 4), this.ly + (this.large ? 8 : 4), this.large ? 128 : 64, this.large ? 128 : 64, null); 
    if (drawmonitor)
      g.drawImage(this.moniter, 0, 0, this.large ? 880 : 440, this.large ? 730 : 365, this); 
    if (this.DEBUG_FPS) {
      g.setColor((this.mCurrFPS < 40) ? Color.red : LED_ON);
      g.drawString("FPS: " + this.mCurrFPS, 4, getHeight() - (this.large ? 5 : 10));
    } 
    if (this.DEBUG_MIPS) {
      g.setColor(LED_ON);
      g.drawString("MIPS:" + Z80.getMIPS(), this.large ? (getWidth() - 90) : (getWidth() - 60), getHeight() - (this.large ? 5 : 10));
    } 
    if (this.DEBUG_SPRITES);
    if (!this.large) {
      if (ledOn) {
        g.setColor(fLED_ON);
      } else {
        g.setColor(fLED_OFF);
      } 
      g.fillRect(40, 340, 8, 4);
      g.setColor(fLED_BORDER);
      g.drawRect(39, 339, 9, 5);
    } else if (ledOn) {
      g.drawImage(this.Disc, 360 * this.divider, 3 * this.divider, this);
    } 
    if (this.turbo) {
      g.setColor(LED_ON);
      g.fillRect(4 * this.divider, 3 * this.divider, 7 * this.divider, 3 * this.divider);
      g.setColor(LED_BORDER);
      g.drawString("x" + CPC.turbospeed, 4 * this.divider, 15 * this.divider);
      g.drawRect(3 * this.divider, 2 * this.divider, 8 * this.divider, 4 * this.divider);
      g.setColor(LED_ON);
      g.drawString("x" + CPC.turbospeed, 3 * this.divider, 14 * this.divider);
    } 
    if (showdisks && showtime > 1) {
      g.drawImage(this.Disc, 24 * this.divider, 3 * this.divider, (this.divider != 1) ? 26 : 13, (this.divider != 1) ? 32 : 16, null);
      g.drawImage(this.Disc, 40 * this.divider, 3 * this.divider, (this.divider != 1) ? 26 : 13, (this.divider != 1) ? 32 : 16, null);
      showtime--;
    } 
  }
  
  public static int showtime = 0;
  
  public int menupos;
  
  public boolean menumode;
  
  public boolean shootme;
  
  int impos;
  
  int lpos;
  
  int lw;
  
  String info;
  
  int[] spx;
  
  int[] spy;
  
  int[] spw;
  
  int[] sph;
  
  boolean oldfull;
  
  int timer;
  
  private boolean started;
  
  public void repaint() {}
  
  public void setspri(int index, int x, int y, int w, int h) {
    this.spx[index] = x;
    this.spy[index] = y * 2;
    this.spw[index] = w;
    this.sph[index] = h * 2;
  }
  
  public void paintComponent(Graphics g) {
    this.painted = false;
    if (this.image != null) {
      this.started = true;
      paintImage(g);
    } 
    this.painted = true;
  }
  
  public Dimension getPreferredSize() {
    if (drawmonitor) {
      if (this.large)
        return new Dimension(880, 730); 
      return new Dimension(440, 365);
    } 
    if (this.large)
      return new Dimension(768, this.highlines); 
    return new Dimension(384, this.lowlines);
  }
  
  public Dimension getSize() {
    if (drawmonitor) {
      if (this.large)
        return new Dimension(880, 730); 
      return new Dimension(440, 365);
    } 
    if (this.large)
      return new Dimension(768, this.highlines); 
    return new Dimension(384, this.lowlines);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCP\\ui\Display.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */