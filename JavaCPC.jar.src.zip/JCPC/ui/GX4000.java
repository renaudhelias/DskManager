package JCPC.ui;

import JCPC.core.Util;
import JCPC.core.device.Computer;
import JCPC.core.device.crtc.Basic6845;
import JCPC.system.cpc.CPC;
import JCPC.system.cpc.GateArray;
import JCPC.system.cpc.Samples;
import com.nilo.plaf.nimrod.NimRODLookAndFeel;
import com.nilo.plaf.nimrod.NimRODTheme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FileDialog;
import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.LookAndFeel;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.plaf.metal.MetalTheme;

public class GX4000 extends JApplet implements ItemListener, ActionListener, KeyListener, FocusListener, Runnable, MouseListener, MouseMotionListener {
  GX4000Menu menu;
  
  EmuControl control;
  
  private ArrayList<DropTarget> dropTargetList;
  
  public void showDebugger() {
    try {
      System.out.println("showDebugger");
      if (debug == null) {
        debug = (Debugger)Util.secureConstructor(Debugger.class, new Class[0], new Object[0]);
        debug.setBounds(0, 0, 820, 600);
        debug.setComputer(this.computer);
      } 
      System.out.println("Showing Debugger");
      debug.setVisible(true);
      debug.toFront();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public static Debugger debug = null;
  
  public static boolean hasSkin;
  
  public void actionPerformed(ActionEvent e) {
    try {
      if (e.getSource() == this.control.controller)
        setupController(); 
      if (GateArray.cpc != null) {
        if (e.getSource() == this.control.syscart)
          if (!CPC.gx4000) {
            loadPlus();
            this.display.requestFocus();
          }  
        if (e.getSource() == this.control.syscart)
          if (CPC.gx4000) {
            loadGX();
            this.display.requestFocus();
          }  
      } 
      if (e.getSource() == this.control.reset) {
        GateArray.cpc.softReset();
        this.display.requestFocus();
      } 
      if (e.getSource() == this.control.fullscreen) {
        toggleFullscreen();
        this.display.requestFocus();
      } 
    } catch (Exception exception) {}
    if (this.menu != null) {
      if (e.getSource() == this.menu.jMenuItem1)
        load(); 
      if (e.getSource() == this.menu.jMenuItem2)
        this.computer.openCPR(); 
      if (e.getSource() == this.menu.jMenuItem3)
        this.controller.setVisible(true); 
      if (e.getSource() == this.menu.jMenuItem5)
        GateArray.cpc.checkCSD(); 
      if (e.getSource() == this.menu.jMenuItem7)
        GateArray.cpc.softReset(); 
      if (e.getSource() == this.menu.jMenuItem8)
        showDebugger(); 
    } 
  }
  
  boolean gifrec = false;
  
  public void itemStateChanged(ItemEvent e) {
    try {
      if (e.getSource() == this.control.filter) {
        Display.scanlines = this.control.filter.isSelected();
        this.display.requestFocus();
      } 
      if (e.getSource() == this.control.lightgun) {
        this.controller.trojan.setSelected(this.control.lightgun.isSelected());
        setLightgun(this.controller.trojan.isSelected());
      } 
    } catch (Exception exception) {}
    if (e.getSource() == this.control.fullsize) {
      if (this.menu != null) {
        this.menu.jCheckBoxMenuItem2.setSelected(this.control.fullsize.isSelected());
        if (this.menu.jCheckBoxMenuItem2.isSelected())
          this.menu.jCheckBoxMenuItem3.setSelected(false); 
      } 
      setFullSize(this.control.fullsize.isSelected());
      System.out.println("Changing display to " + (this.large ? "large size" : "small size"));
      try {
        Thread.sleep(100L);
      } catch (Exception exception) {}
      this.display.setPreferredSize(this.display.getPreferredSize());
      this.display.setSize(this.display.getPreferredSize());
      try {
        Thread.sleep(100L);
      } catch (Exception exception) {}
      if (frame != null) {
        frame.pack();
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation((d.width - (frame.getSize()).width) / 2, (d.height - (frame.getSize()).height) / 2);
      } 
      if (this.emu != null)
        this.emu.pack(); 
    } 
    if (this.menu != null) {
      hasSkin = this.menu.jCheckBoxMenuItem3.getState();
      if (this.menu.jCheckBoxMenuItem1 == e.getSource())
        this.display.DEBUG_FPS = this.menu.jCheckBoxMenuItem1.getState(); 
      if (this.menu.jCheckBoxMenuItem4 == e.getSource())
        if (this.menu.jCheckBoxMenuItem4.isSelected()) {
          if (!this.gifrec) {
            this.display.startRec();
            this.gifrec = true;
          } 
        } else if (this.gifrec) {
          this.display.stopRec();
          this.gifrec = false;
        }  
      if (this.menu.jCheckBoxMenuItem2 == e.getSource()) {
        this.control.fullsize.setSelected(this.menu.jCheckBoxMenuItem2.isSelected());
        setFullSize(this.menu.jCheckBoxMenuItem2.isSelected());
        if (this.menu.jCheckBoxMenuItem2.isSelected())
          this.menu.jCheckBoxMenuItem3.setSelected(false); 
        System.out.println("Changing display to " + (this.large ? "large size" : "small size"));
        try {
          Thread.sleep(100L);
        } catch (Exception exception) {}
        this.display.setPreferredSize(this.display.getPreferredSize());
        this.display.setSize(this.display.getPreferredSize());
        try {
          Thread.sleep(100L);
        } catch (Exception exception) {}
        if (frame != null) {
          frame.pack();
          Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
          frame.setLocation((d.width - (frame.getSize()).width) / 2, (d.height - (frame.getSize()).height) / 2);
        } 
        if (this.emu != null)
          this.emu.pack(); 
      } 
      if (this.menu.jCheckBoxMenuItem3 == e.getSource()) {
        this.keepmonitor = this.menu.jCheckBoxMenuItem3.getState();
        if (this.keepmonitor)
          this.menu.jCheckBoxMenuItem2.setSelected(false); 
        setFullSize(this.menu.jCheckBoxMenuItem2.getState());
        System.out.println("Changing display to " + (this.large ? "large size" : "small size"));
        try {
          Thread.sleep(100L);
        } catch (Exception exception) {}
        this.display.setPreferredSize(this.display.getPreferredSize());
        this.display.setSize(this.display.getPreferredSize());
        try {
          Thread.sleep(100L);
        } catch (Exception exception) {}
        if (frame != null) {
          frame.pack();
          Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
          frame.setLocation((d.width - (frame.getSize()).width) / 2, (d.height - (frame.getSize()).height) / 2);
        } 
        if (this.emu != null)
          this.emu.pack(); 
      } 
    } 
    if (e.getSource() == this.controller.trojan) {
      this.control.lightgun.setSelected(this.controller.trojan.isSelected());
      setLightgun(this.controller.trojan.isSelected());
    } 
    if (e.getSource() == this.controller.cart)
      GateArray.cpc.loadCart(this.controller.cart.getSelectedIndex()); 
  }
  
  boolean menupossible = false;
  
  boolean penonscreen = false;
  
  public void mouseMoved(MouseEvent e) {
    int x = e.getX();
    int y = e.getY();
    if (y < 50)
      if (Display.showdisks)
        Display.showtime = 50;  
    this.display.updateLightpen(x, y);
    if (this.lightpen) {
      if (this.display.fullscreen) {
        double xx = 768.0D / this.display.getWidth();
        double yy = 544.0D / this.display.getHeight();
        x = (int)(x * xx);
        y = (int)(y * yy);
      } 
      GateArray.cpc.getCRTC().setLightpen(x, y, this.display.large, this.display.fullscreen, this.penonscreen);
    } 
    if (this.large) {
      if (this.display.menumode && e.getX() > this.basex && e.getX() < this.basexmax && e.getY() > 50 && e.getY() < 530) {
        this.display.setCursor(new Cursor(12));
      } else if (this.display.menumode && e.getX() > this.basex + 300 && e.getX() < this.basexmax + 300 && e.getY() > 50 && e.getY() < 400) {
        this.display.setCursor(new Cursor(12));
      } else {
        this.menupossible = false;
        if (!this.lightpen) {
          this.display.setCursor(new Cursor(0));
        } else {
          this.display.setCursor(this.penonscreen ? this.pen : this.gun);
        } 
      } 
    } else if (e.getX() > 360 && e.getX() < 390 && e.getY() > 353 && e.getY() < 363) {
      this.display.setCursor(new Cursor(12));
      this.menupossible = true;
    } else if (this.display.menumode && e.getX() > 100 + this.display.xdist && e.getX() < 220 + this.display.xdist && e.getY() > 50 + this.display.ydist && e.getY() < 290 + this.display.ydist) {
      this.display.setCursor(new Cursor(12));
    } else if (this.display.menumode && e.getX() > 250 + this.display.xdist && e.getX() < 370 + this.display.xdist && e.getY() > 50 + this.display.ydist && e.getY() < 214 + this.display.ydist) {
      this.display.setCursor(new Cursor(12));
    } else {
      this.menupossible = false;
      if (!this.lightpen) {
        this.display.setCursor(new Cursor(0));
      } else {
        this.display.setCursor(this.penonscreen ? this.pen : this.gun);
      } 
    } 
  }
  
  public void mouseDragged(MouseEvent e) {
    int x = e.getX();
    int y = e.getY();
    this.display.updateLightpen(x, y);
    if (this.lightpen) {
      if (this.display.fullscreen) {
        double xx = 768.0D / this.display.getWidth();
        double yy = 544.0D / this.display.getHeight();
        x = (int)(x * xx);
        y = (int)(y * yy);
      } 
      GateArray.cpc.getCRTC().setLightpen(x, y, this.display.large, this.display.fullscreen, true);
    } 
  }
  
  protected static boolean developer = false;
  
  protected boolean URL = false;
  
  String CRTC = "3";
  
  boolean alt = false;
  
  int multiload = 0;
  
  String cartridge = "none";
  
  String load = "none";
  
  String loadb = "none";
  
  String sna = "none";
  
  protected Computer computer = null;
  
  Locale loc;
  
  String localkeys = "";
  
  public static boolean isStandalone = false;
  
  public Display display = new Display();
  
  protected boolean started = false;
  
  protected boolean large = false;
  
  JInternalFrame emu;
  
  static boolean toDriveB;
  
  String disk1;
  
  String disk2;
  
  JPanel show;
  
  protected int loadit;
  
  ActionListener update;
  
  Timer fireUpdate;
  
  int fram;
  
  private KeyTranslator translator;
  
  JFrame fullframe;
  
  BufferedImage testim;
  
  Controller controller;
  
  boolean ctrl;
  
  FileDialog loader;
  
  boolean lightpen;
  
  final URL cursorim;
  
  final Image lightGun;
  
  final URL cursorim2;
  
  final Image lightPen;
  
  Cursor gun;
  
  Cursor pen;
  
  int basex;
  
  int basexmax;
  
  boolean keepmonitor;
  
  static JFrame frame;
  
  public String getParameter(String key, String def) {
    try {
      return isStandalone ? System.getProperty(key, def) : ((getParameter(key) != null) ? getParameter(key) : def);
    } catch (Exception e) {
      return def;
    } 
  }
  
  public void init() {
    this.localkeys = getLocale().toString().toUpperCase();
    this.display.requestFocus();
    if (isStandalone) {
      this.dropTargetList = new ArrayList<>();
      DropListener myListener = new DropListener();
      registerDropListener(this.dropTargetList, this.display, myListener);
    } 
  }
  
  public void stopMotor() {
    this.computer.stop();
  }
  
  public void startMotor() {
    this.computer.start();
  }
  
  public Computer getComputer() {
    return this.computer;
  }
  
  public JInternalFrame getEmu(GX4000 emul) {
    if (this.emu == null) {
      this.emu = new JInternalFrame("JavaGX4000 - Amstrad CPC+ Emulator - Desktop") {
          public void doDefaultCloseAction() {
            System.out.println("Window closing!");
            GX4000.this.computer.reset();
            GX4000.this.computer.stop();
            super.doDefaultCloseAction();
          }
        };
      this.emu.setDefaultCloseOperation(1);
      initMenu();
      setJMenuBar(getMenu());
      this.emu.setLayout(new BorderLayout());
      this.emu.add(this, "Center");
      this.menu.jMenuItem4.setVisible(false);
      this.emu.pack();
      this.emu.setResizable(false);
      this.emu.setIconifiable(true);
      this.emu.setClosable(true);
    } 
    return this.emu;
  }
  
  public JMenuBar getMenu() {
    this.menu.Menu.setFocusable(false);
    return this.menu.Menu;
  }
  
  public void init(String locale) {
    this.localkeys = locale;
    this.display.requestFocus();
    this.dropTargetList = new ArrayList<>();
    DropListener myListener = new DropListener();
    registerDropListener(this.dropTargetList, this.display, myListener);
  }
  
  private class DropListener extends DropTargetAdapter {
    private DropListener() {}
    
    public void dragExit(DropTargetEvent dtde) {
      GX4000.this.display.showdrives = 0;
    }
    
    public void dragOver(DropTargetDragEvent dtde) {
      int x = (dtde.getLocation()).x;
      int y = (dtde.getLocation()).y;
      if (x > 370 / (GX4000.this.display.large ? 1 : 2)) {
        GX4000.toDriveB = true;
      } else {
        GX4000.toDriveB = false;
      } 
      try {
        Transferable t = dtde.getTransferable();
        if (t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
          Object userObject = t.getTransferData(DataFlavor.javaFileListFlavor);
          if (userObject instanceof List) {
            String fileName = ((List<E>)userObject).get(0).toString();
            if (fileName.toLowerCase().endsWith(".dsk")) {
              GX4000.this.display.showdrives = 20;
            } else {
              GX4000.this.display.showdrives = 0;
            } 
          } 
        } 
      } catch (Exception ex) {
        System.out.println("[MainForm::DropListener]" + ex);
      } 
    }
    
    public void drop(DropTargetDropEvent dtde) {
      try {
        Transferable t = dtde.getTransferable();
        if (t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
          dtde.acceptDrop(3);
          Object userObject = t.getTransferData(DataFlavor.javaFileListFlavor);
          if (userObject instanceof List) {
            String filename = ((List<E>)userObject).get(0).toString();
            if (filename.toLowerCase().endsWith(".dsk")) {
              int d = GX4000.this.computer.getCurrentDrive();
              GX4000.this.computer.setCurrentDrive(GX4000.toDriveB ? 1 : 0);
              GX4000.this.loadFile(1, filename, false);
              GX4000.this.computer.setCurrentDrive(d);
            } else {
              GX4000.this.loadFile(1, filename, false);
            } 
          } 
          dtde.dropComplete(true);
        } 
      } catch (UnsupportedFlavorException unsupportedFlavorException) {
      
      } catch (IOException iOException) {}
    }
  }
  
  private static void registerDropListener(ArrayList<DropTarget> list, Container basePanel, DropListener myListener) {
    list.add(new DropTarget(basePanel, myListener));
    Component[] components = basePanel.getComponents();
    for (int i = 0; i < components.length; i++) {
      Component component = components[i];
      if (component instanceof Container) {
        registerDropListener(list, (Container)component, myListener);
      } else {
        list.add(new DropTarget(component, myListener));
      } 
    } 
  }
  
  public void init(Locale loc) {
    this.localkeys = loc.toString().toUpperCase();
    this.display.requestFocus();
  }
  
  public GX4000() {
    this.disk1 = "";
    this.disk2 = "";
    this.loadit = 0;
    this.update = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          GX4000.this.update();
        }
      };
    this.fireUpdate = new Timer(50, this.update);
    this.fram = 0;
    this.translator = new KeyTranslator();
    this.testim = new BufferedImage(768, 544, 1);
    this.lightpen = false;
    this.cursorim = getClass().getResource("attachment.gif");
    this.lightGun = getToolkit().getImage(this.cursorim);
    this.cursorim2 = getClass().getResource("lightpen.png");
    this.lightPen = getToolkit().getImage(this.cursorim2);
    this.gun = Toolkit.getDefaultToolkit().createCustomCursor(this.lightGun, new Point(1, 1), "gunCursor");
    this.pen = Toolkit.getDefaultToolkit().createCustomCursor(this.lightPen, new Point(1, 1), "penCursor");
    this.basex = 200;
    this.basexmax = 410;
    enableEvents(8L);
  }
  
  public void startEngine(final GX4000 applet) {
    try {
      this.show = new JPanel();
      this.show.setBackground(new Color(39, 39, 39));
      this.show.setLayout(new BorderLayout());
      this.control = new EmuControl();
      this.controller = new Controller();
      this.fram = 0;
      this.disk2 = "";
      setLayout(new BorderLayout());
      CPC.cartindex = Integer.parseInt(getParameter("GAME", "25"));
      if (CPC.cartindex > 25 || CPC.cartindex < 0)
        CPC.cartindex = 2; 
      this.large = Util.getBoolean(getParameter("LARGE", "true"));
      Display.scanlines = Util.getBoolean(getParameter("FILTER", "false"));
      Display.drawmonitor = Util.getBoolean(getParameter("GUI", "false"));
      this.keepmonitor = Display.drawmonitor;
      this.controller.trojan.addItemListener(this);
      this.controller.cart.setModel(new DefaultComboBoxModel<>(Display.carts));
      this.controller.cart.setSelectedIndex(CPC.cartindex);
      this.controller.cart.addItemListener(this);
      String url = getParameter("URL", "false");
      url = url.toUpperCase();
      if (url.equals("TRUE"))
        this.URL = true; 
      String csd = getParameter("CSD", "false");
      csd = csd.toUpperCase();
      CPC.CSD = false;
      if (csd.equals("TRUE"))
        CPC.CSD = true; 
      String type = getParameter("AUTOTYPE", (String)null);
      String boot = getParameter("BOOT", (String)null);
      this.CRTC = "3";
      this.CRTC = getParameter("CRTC", this.CRTC);
      if (this.CRTC.startsWith("1"))
        this.CRTC = "1"; 
      if (this.CRTC.startsWith("3"))
        this.CRTC = "3"; 
      if (this.CRTC.startsWith("0"))
        this.CRTC = "0"; 
      Basic6845.CRTC = Integer.parseInt(this.CRTC);
      this.cartridge = getParameter("CPR", "internal");
      if (CPC.CSD)
        this.cartridge = "none"; 
      if (this.cartridge.equals("internal")) {
        this.cartridge = "none";
        CPC.internal = true;
      } 
      setComputer("CPCPLUS", true);
      this.load = getParameter("SNA", "none");
      this.sna = this.load;
      this.load = getParameter("DISK", this.load);
      if (this.load.startsWith("$"))
        this.load = "none"; 
      this.loadb = getParameter("DISKB", this.loadb);
      if (this.loadb.startsWith("$"))
        this.loadb = "none"; 
      this.disk2 = getParameter("DISK2", "");
      if (this.disk2.startsWith("$"))
        this.disk2 = ""; 
      Display.showdisks = false;
      if (this.disk2.length() > 1) {
        this.disk1 = this.load;
        Display.showdisks = true;
        Display.showtime = 150;
      } 
      this.display.large = this.large;
      if (this.large) {
        this.display.setSize(768, this.display.highlines);
        this.display.divider = 2;
      } else {
        this.display.setSize(384, this.display.lowlines);
      } 
      this.show.add(this.display, "Center");
      this.display.setBackground(Color.black);
      this.display.addKeyListener(this);
      this.display.addMouseListener(this);
      this.display.addMouseMotionListener(this);
      this.display.addFocusListener(this);
      this.started = true;
      if (type != null)
        this.computer.prepareAutotype(type); 
      if (boot != null)
        if (boot.contains("/")) {
          boot = boot.replace("/", "\"");
          this.computer.prepareAutotype(boot);
        } else if (boot.equals("tape")) {
          this.computer.prepareAutotype("|TAPE:RUN\"!\"");
        } else if (boot.startsWith("|")) {
          this.computer.prepareAutotype(boot);
        } else {
          this.computer.prepareAutotype("RUN\"" + boot + "\"");
        }  
      setLightgun(Util.getBoolean(getParameter("LIGHTGUN", "false")));
    } catch (Exception e) {
      e.printStackTrace();
    } 
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            if (!GX4000.this.cartridge.equals("none"))
              GX4000.this.loadFile(2, GX4000.this.cartridge, true); 
            if (!GX4000.this.load.equals("none") && GX4000.this.sna.equals("none"))
              GX4000.this.loadFile(2, GX4000.this.load, true); 
            if (GX4000.this.load.equals("none") && !GX4000.this.sna.equals("none"))
              GX4000.this.loadit = 1; 
            if (!GX4000.this.load.equals("none") && !GX4000.this.sna.equals("none"))
              GX4000.this.multiload = 1; 
            if (!GX4000.this.loadb.equals("none")) {
              GX4000.this.computer.setCurrentDrive(1);
              GX4000.this.loadFile(2, GX4000.this.loadb, true);
            } 
            GX4000.this.computer.setCurrentDrive(0);
            if (GX4000.frame != null) {
              GX4000.frame.pack();
              Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
              GX4000.frame.setLocation((d.width - (GX4000.frame.getSize()).width) / 2, (d.height - (GX4000.frame.getSize()).height) / 2);
            } 
            if (GX4000.this.emu != null)
              GX4000.this.emu.pack(); 
            GX4000.this.fireUpdate.start();
            GX4000.this.display.DEBUG_SPRITES = Util.getBoolean(GX4000.this.getParameter("SPRITES", GX4000.this.display.DEBUG_SPRITES ? "true" : "false"));
            GX4000.this.display.DEBUG_SCREEN = Util.getBoolean(GX4000.this.getParameter("SCREEN", GX4000.this.display.DEBUG_SCREEN ? "true" : "false"));
            GX4000.this.control.fullsize.setSelected(GX4000.this.large);
            GX4000.this.control.fullsize.addItemListener(applet);
            GX4000.this.control.lightgun.addItemListener(applet);
            GX4000.this.control.controller.addActionListener(applet);
            GX4000.this.control.fullscreen.addActionListener(applet);
            GX4000.this.control.syscart.addActionListener(applet);
            GX4000.this.control.reset.addActionListener(applet);
            GX4000.this.control.filter.addItemListener(applet);
            if (!GX4000.asApplet && GX4000.frame != null) {
              GX4000.this.initMenu();
              GX4000.this.setJMenuBar(GX4000.this.getMenu());
            } 
            GX4000.this.add(GX4000.this.control, "North");
            GX4000.this.add(GX4000.this.show, "Center");
            GX4000.this.display.requestFocus();
          }
        });
  }
  
  public void start() {
    if (asApplet)
      setStyle(); 
    CPC.gx4000 = isStandalone;
    startEngine(this);
    this.display.requestFocus();
  }
  
  public void startEmbedded() {
    CPC.gx4000 = true;
    startEngine(this);
    this.display.requestFocus();
  }
  
  public boolean isStarted() {
    return this.started;
  }
  
  public void waitStart() {
    try {
      while (!this.started)
        Thread.sleep(10L); 
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void run() {}
  
  public void stop() {
    GateArray.cpc.reset();
    GateArray.cpc.getPSG().resetRegisters();
    this.computer.stop();
  }
  
  public void update() {
    if (this.fram < 1) {
      this.fram++;
      this.computer.reset();
      this.computer.reSync();
      if (frame != null)
        frame.pack(); 
    } 
    if (this.loadit > 0) {
      this.loadit++;
      if (this.loadit > 5) {
        this.loadit = 0;
        loadFile(1, this.sna, true);
      } 
    } 
    if (this.multiload >= 1) {
      this.multiload++;
      if (this.multiload == 6)
        loadFile(1, this.sna, true); 
      if (this.multiload == 8) {
        loadFile(1, this.load, true);
        this.multiload = 0;
      } 
    } 
  }
  
  public void keyTyped(KeyEvent e) {}
  
  public void setupController() {
    this.controller.setVisible(true);
  }
  
  public void repaint() {}
  
  public void loadPlus() {
    GateArray.cpc.loadSystem();
  }
  
  public void loadGX() {
    GateArray.cpc.loadGX();
  }
  
  public void toggleFullscreen() {
    this.alt = false;
    if (this.fullframe == null) {
      this.fullframe = new JFrame();
      this.fullframe.setUndecorated(true);
      this.fullframe.setLayout(new BorderLayout());
      GraphicsConfiguration conf = getGraphicsConfiguration();
      int monitors = (conf.getDevice().getConfigurations()).length;
      int device = 0;
      int h = (conf.getDevice().getConfigurations()[device].getBounds()).height;
      int w = (conf.getDevice().getConfigurations()[device].getBounds()).width;
      Dimension d = new Dimension(w, h);
      this.fullframe.setPreferredSize(d);
      this.fullframe.setSize(d);
      Image testit = this.testim.getScaledInstance(d.width, -1, 2);
      this.display.left = new JPanel();
      this.display.right = new JPanel();
      this.display.left.setBackground(Color.black);
      this.display.right.setBackground(Color.black);
      Dimension dd = new Dimension(0, d.height - testit.getHeight(null) >> 1);
      this.display.left.setPreferredSize(dd);
      this.display.right.setPreferredSize(dd);
      if (testit.getHeight(null) > getHeight()) {
        testit = this.testim.getScaledInstance(-1, d.height, 2);
        dd = new Dimension(d.width - testit.getWidth(null) >> 1, (Toolkit.getDefaultToolkit().getScreenSize()).height);
        this.display.left.setPreferredSize(dd);
        this.display.right.setPreferredSize(dd);
        this.display.leftside = new BufferedImage(20, 280, 1);
        this.display.rightside = new BufferedImage(20, 280, 1);
        this.display.leftpixels = new int[5600];
        this.display.rightpixels = new int[5600];
        this.fullframe.add(this.display.left, "West");
        this.fullframe.add(this.display.right, "East");
        this.display.drawborder = true;
      } else {
        this.display.drawborder = false;
        this.fullframe.add(this.display.left, "North");
        this.fullframe.add(this.display.right, "South");
      } 
    } 
    this.display.fullscreen = !this.display.fullscreen;
    if (this.display.fullscreen) {
      if (frame != null)
        frame.setVisible(false); 
      setVisible(false);
      this.show.remove(this.display);
      this.fullframe.add(this.display, "Center");
      this.fullframe.setVisible(true);
    } else {
      this.fullframe.remove(this.display);
      this.show.add(this.display, "Center");
      this.show.repaint();
      this.fullframe.setVisible(false);
      setVisible(true);
      if (frame != null) {
        frame.setVisible(true);
        frame.pack();
      } 
    } 
    this.display.requestFocus();
  }
  
  public void toggleFilter() {
    Display.scanlines = !Display.scanlines;
  }
  
  public void keyPressed(KeyEvent e) {
    if (e.getKeyCode() == 123 && this.alt) {
      showDebugger();
      return;
    } 
    if (e.getKeyCode() == 145) {
      setLightgun(!this.lightpen);
      this.controller.trojan.setSelected(this.lightpen);
    } 
    if (e.getKeyCode() == 18)
      this.alt = true; 
    if (e.getKeyCode() == 17)
      this.ctrl = true; 
    if (this.alt && e.getKeyCode() == 10 && !this.display.menumode)
      toggleFullscreen(); 
    if (e.getKeyCode() == 121) {
      e.consume();
      return;
    } 
    for (int i = 0; i < 6; i++) {
      if (e.getKeyCode() == this.controller.keyevents[i])
        switch (i) {
          case 0:
            e.setKeyCode(101);
            break;
          case 1:
            e.setKeyCode(96);
            break;
          case 2:
            e.setKeyCode(104);
            break;
          case 3:
            e.setKeyCode(98);
            break;
          case 4:
            e.setKeyCode(100);
            break;
          case 5:
            e.setKeyCode(102);
            break;
        }  
    } 
    e = this.translator.translate(e, this.localkeys);
    if (e.getKeyCode() == 123)
      if (this.ctrl) {
        resetComputer();
      } else {
        GateArray.cpc.softReset();
      }  
    this.computer.processKeyEvent(e);
    e.consume();
  }
  
  public void keyReleased(KeyEvent e) {
    if (e.getKeyCode() == 32)
      if (CPC.gx4000)
        this.display.menumode = !this.display.menumode;  
    if (e.getKeyCode() == 18)
      this.alt = false; 
    if (e.getKeyCode() == 17)
      this.ctrl = false; 
    if (e.getKeyCode() == 121) {
      this.controller.setVisible(true);
      e.consume();
      return;
    } 
    for (int i = 0; i < 6; i++) {
      if (e.getKeyCode() == this.controller.keyevents[i])
        switch (i) {
          case 0:
            e.setKeyCode(101);
            break;
          case 1:
            e.setKeyCode(96);
            break;
          case 2:
            e.setKeyCode(104);
            break;
          case 3:
            e.setKeyCode(98);
            break;
          case 4:
            e.setKeyCode(100);
            break;
          case 5:
            e.setKeyCode(102);
            break;
        }  
    } 
    if (e.getKeyCode() == 114)
      GateArray.cpc.saveallowed = !GateArray.cpc.saveallowed; 
    if (e.getKeyCode() == 112) {
      JOptionPane.showMessageDialog(new JFrame(), "JavaGX4000 by Markus Hohmann\r\nContact: webmaster@cpc-live.com\r\n\r\nF1 - This info\r\nF2 - Load medium*\r\nF3 - Enable/disable DSK storing (Off by default)\r\nF6 - Load cartridge image (CPR)\r\nF7 - Toggle Scanlines (When large)\r\nF8 - Toggle CRTC type (0/1)\r\nF9 - Toggle Turbo\r\nF10 - Setup controller and lightgun / Select internal CPR\r\nF11 - Autotype console\r\nF12 - Reset CPC\r\n\r\nAlt+F12 - Debugger\r\nAlt+Enter - Toggle fullscreen\r\nPrint Screen - Poke interface\r\nScroll Lock - Toggle lightgun\r\nPause - Amstrad Cartridge Software Demonstrator (CSD) emulation panel\r\n\r\nJoystick is mapped to:\r\n<Insert>/<NP 5> - Fire 0\r\n<Page up>/<NP 0> - Fire 1\r\n<Home>/<NP 8> - Up\r\n<Page down>/<NP 6> - Right\r\n<End>/<NP 2> - Down\r\n<Delete>/<NP 4> - Left\r\n\r\n*Supported media:\r\nDSK, SNA, CDT, CSW, BIN, CPR\r\n");
      return;
    } 
    if (e.getKeyCode() == 118) {
      Display.scanlines = !Display.scanlines;
      this.control.filter.setSelected(Display.scanlines);
    } 
    e = this.translator.translate(e, this.localkeys);
    if (e.getKeyCode() == 113)
      load(); 
    this.computer.processKeyEvent(e);
    e.consume();
  }
  
  protected void load() {
    if (this.loader == null)
      this.loader = new FileDialog(frame, "Load file", 0); 
    this.loader.setVisible(true);
    String filename = this.loader.getFile();
    if (filename != null) {
      filename = this.loader.getDirectory() + this.loader.getFile();
      loadFile(1, filename, false);
    } 
  }
  
  public void mouseClicked(MouseEvent e) {
    if (this.lightpen)
      return; 
    this.display.requestFocus();
    if (e.getClickCount() == 2 && frame != null && !this.display.fullscreen)
      if (!CPC.gx4000) {
        Thread b = new Thread() {
            public void run() {
              if (GX4000.this.menu != null) {
                GX4000.this.menu.jCheckBoxMenuItem2.setSelected(!GX4000.this.large);
                return;
              } 
              GX4000.this.setFullSize(!GX4000.this.large);
              System.out.println("Changing display to " + (GX4000.this.large ? "large size" : "small size"));
              try {
                Thread.sleep(100L);
              } catch (Exception exception) {}
              GX4000.this.display.setPreferredSize(GX4000.this.display.getPreferredSize());
              GX4000.this.display.setSize(GX4000.this.display.getPreferredSize());
              try {
                Thread.sleep(100L);
              } catch (Exception exception) {}
              if (GX4000.frame != null) {
                GX4000.frame.pack();
                Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
                GX4000.frame.setLocation((d.width - (GX4000.frame.getSize()).width) / 2, (d.height - (GX4000.frame.getSize()).height) / 2);
              } 
              if (GX4000.this.emu != null)
                GX4000.this.emu.pack(); 
            }
          };
        b.start();
      }  
  }
  
  public void mousePressed(MouseEvent e) {
    if (this.lightpen && !this.display.menumode) {
      if (e.getButton() != 1) {
        this.penonscreen = !this.penonscreen;
        this.display.penonscreen = this.penonscreen;
        this.display.setCursor(this.penonscreen ? this.pen : this.gun);
        return;
      } 
      int x = e.getX();
      int y = e.getY();
      if (this.display.fullscreen) {
        double xx = 768.0D / this.display.getWidth();
        double yy = 544.0D / this.display.getHeight();
        x = (int)(x * xx);
        y = (int)(y * yy);
      } 
      GateArray.cpc.getCRTC().setLightpen(x, y, this.display.large, this.display.fullscreen, true);
      this.computer.keyPressed(this.penonscreen ? 10 : (CPC.gx4000 ? 17 : 155));
    } 
  }
  
  public void setLightgun(boolean enable) {
    this.lightpen = enable;
    (GateArray.cpc.getCRTC()).lightgun = this.lightpen;
    if (this.lightpen) {
      this.display.setCursor(this.penonscreen ? this.pen : this.gun);
    } else {
      this.display.setCursor(new Cursor(0));
    } 
  }
  
  public void mouseReleased(MouseEvent e) {
    int x = e.getX();
    int y = e.getY();
    if (y < 50)
      Display.showtime = 50; 
    if (Display.showtime > 0) {
      int d = this.display.divider;
      if (d == 2) {
        d = 1;
      } else {
        d = 2;
      } 
      if (x > 46 / d && x < 76 / d && 
        y > 6 / d && y < 38 / d) {
        System.out.println("Loading disk 1");
        loadFile(2, this.disk1, true);
        Samples.INSERT.play();
      } 
      if (x > 80 / d && x < 106 / d && 
        y > 6 / d && y < 38 / d) {
        System.out.println("Loading disk 2");
        loadFile(2, this.disk2, true);
        Samples.INSERT.play();
      } 
    } 
    if (this.menupossible)
      this.display.menumode = !this.display.menumode; 
    if (!this.display.menumode && this.lightpen) {
      this.computer.keyReleased(this.penonscreen ? 10 : (CPC.gx4000 ? 17 : 155));
      GateArray.cpc.getCRTC().releaseGun();
      return;
    } 
    if (this.display.menumode && this.display.large) {
      y -= this.large ? 50 : 100;
      if (x > this.basex && x < this.basexmax && 
        y < 480 && y > 0) {
        int index = y / 32;
        if (index < 0 || index > Display.carts.length - 1)
          return; 
        int hasIndex = this.controller.cart.getSelectedIndex();
        this.controller.cart.setSelectedIndex(index);
        if (hasIndex == index)
          GateArray.cpc.loadCart(index); 
        this.display.menumode = false;
      } 
      if (x > this.basex + 300 && x < this.basexmax + 300 && 
        y < 320 && y > 0) {
        int index = 15 + y / 32;
        if (index < 0 || index > Display.carts.length - 1)
          return; 
        int hasIndex = this.controller.cart.getSelectedIndex();
        this.controller.cart.setSelectedIndex(index);
        if (hasIndex == index)
          GateArray.cpc.loadCart(index); 
        this.display.menumode = false;
      } 
    } 
    if (this.display.menumode && !this.display.large) {
      y -= 50 + this.display.ydist;
      x -= this.display.xdist;
      if (x > 100 && x < 220 && 
        y < 240 && y > 0) {
        int index = y / 16;
        if (index < 0 || index > Display.carts.length - 1)
          return; 
        int hasIndex = this.controller.cart.getSelectedIndex();
        this.controller.cart.setSelectedIndex(index);
        if (hasIndex == index)
          GateArray.cpc.loadCart(index); 
        this.display.menumode = false;
      } 
      if (x > 250 && x < 370 && 
        y < 210 && y > 0) {
        int index = 15 + y / 16;
        if (index < 0 || index > Display.carts.length - 1)
          return; 
        int hasIndex = this.controller.cart.getSelectedIndex();
        this.controller.cart.setSelectedIndex(index);
        if (hasIndex == index)
          GateArray.cpc.loadCart(index); 
        this.display.menumode = false;
      } 
    } 
    if (this.display.mCurrFPS < 24)
      this.computer.reSync(); 
  }
  
  public void mouseEntered(MouseEvent e) {}
  
  public void mouseExited(MouseEvent e) {}
  
  public void loadFile(String name) {
    loadFile(0, name, true);
  }
  
  public void loadFile(int type, String name, boolean usePath) {
    if (this.URL)
      usePath = false; 
    try {
      this.computer.stop();
      this.computer.loadFile(type, (usePath ? this.computer.getFilePath() : "") + name);
    } catch (Exception exception) {}
    this.computer.start();
    this.display.requestFocus();
  }
  
  public void resetComputer() {
    GateArray.cpc.cprslot = 0;
    this.computer.reset();
  }
  
  public void loadGame(int slot) {
    GateArray.cpc.loadCart(slot);
  }
  
  public void setComputer(String name) {
    try {
      setComputer(name, true);
    } catch (Exception e) {
      e.printStackTrace();
      System.exit(0);
    } 
  }
  
  public void setComputer(String name, boolean start) throws Exception {
    if (this.computer == null || !name.equalsIgnoreCase(this.computer.getName())) {
      this.computer = Computer.createComputer(this, name);
      setFullSize(this.large);
      this.computer.initialise();
      if (start)
        this.computer.start(); 
    } 
  }
  
  void showHideButtons(boolean show) {
    this.control.controller.setVisible(this.large);
    this.control.filter.setVisible(this.large);
    this.control.fullscreen.setVisible(this.large);
  }
  
  public void setFullSize(boolean value) {
    this.large = value;
    showHideButtons(this.large);
    Display.drawmonitor = value ? false : this.keepmonitor;
    this.computer.stop();
    this.display.divider = this.large ? 2 : 1;
    this.display.large = this.large;
    this.computer.setLarge(this.large);
    this.display.setImageSize(this.computer.getDisplaySize(this.large), this.computer.getDisplayScale(this.large));
    this.computer.setDisplay(this.display);
    this.computer.start();
    this.show.repaint();
    this.display.requestFocus();
  }
  
  public void focusLost(FocusEvent e) {
    this.computer.displayLostFocus();
    if (this.display.mCurrFPS < 45)
      this.computer.reSync(); 
  }
  
  public void focusGained(FocusEvent e) {
    if (this.display.mCurrFPS < 45)
      this.computer.reSync(); 
  }
  
  public void initMenu() {
    this.menu = new GX4000Menu();
    this.menu.setVisible(true);
    this.menu.jMenuItem1.addActionListener(this);
    this.menu.jMenuItem2.addActionListener(this);
    this.menu.jMenuItem3.addActionListener(this);
    this.menu.jMenuItem5.addActionListener(this);
    this.menu.jMenuItem7.addActionListener(this);
    this.menu.jMenuItem8.addActionListener(this);
    this.menu.jCheckBoxMenuItem1.addItemListener(this);
    this.menu.jCheckBoxMenuItem2.addItemListener(this);
    this.menu.jCheckBoxMenuItem3.addItemListener(this);
    this.menu.jCheckBoxMenuItem4.addItemListener(this);
  }
  
  public static void setStyle() {
    try {
      NimRODTheme nt = new NimRODTheme();
      Color flow1 = new Color(4915205);
      Color flow3 = new Color(15397362);
      Color black = new Color(0);
      Color white = new Color(16777215);
      Color sec1 = new Color(10747936);
      Color sec2 = new Color(9647933);
      Color sec3 = new Color(16184554);
      Color select = new Color(10747936);
      nt.setPrimary(white);
      nt.setSecondary(white);
      nt.setPrimary1(flow1);
      nt.setPrimary3(flow3);
      nt.setPrimary2(select);
      nt.setSecondary1(sec1);
      nt.setSecondary2(sec2);
      nt.setSecondary3(sec3);
      nt.setBlack(black);
      nt.setWhite(white);
      nt.setMenuOpacity(195);
      nt.setFrameOpacity(120);
      NimRODLookAndFeel NimRODLF = new NimRODLookAndFeel();
      NimRODLookAndFeel.setCurrentTheme((MetalTheme)nt);
      UIManager.setLookAndFeel((LookAndFeel)NimRODLF);
    } catch (Exception exception) {}
  }
  
  public static boolean asApplet = true;
  
  public static void main(String[] args) {
    asApplet = false;
    setStyle();
    CPC.gx4000 = true;
    developer = true;
    GX4000 applet = new GX4000();
    isStandalone = true;
    frame = new JFrame() {
        protected void processWindowEvent(WindowEvent e) {
          super.processWindowEvent(e);
          if (e.getID() == 201)
            System.exit(0); 
        }
        
        public synchronized void setTitle(String title) {
          super.setTitle(title);
          enableEvents(64L);
        }
      };
    frame.setTitle("JavaGX4000");
    frame.getContentPane().add(applet, "Center");
    applet.initMenu();
    applet.init();
    applet.start();
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
            GX4000.frame.setLocation((d.width - 800) / 2, (d.height - 600) / 2);
            GX4000.frame.setVisible(true);
            GX4000.frame.setResizable(false);
            GX4000.frame.pack();
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCP\\ui\GX4000.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */