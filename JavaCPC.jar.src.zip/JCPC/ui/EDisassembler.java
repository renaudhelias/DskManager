package JCPC.ui;

import JCPC.core.device.Computer;
import JCPC.util.diss.Disassembler;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import javax.swing.JComponent;
import javax.swing.JScrollBar;
import javax.swing.border.BevelBorder;

public class EDisassembler extends JComponent implements AdjustmentListener, TimerListener {
  protected static final Color selBackground = new Color(14737632);
  
  protected static final Color selForeground = null;
  
  protected static final Color pcBackground = new Color(127);
  
  protected static final Color pcForeground = Color.white;
  
  protected JScrollBar scrollBar = new JScrollBar(1);
  
  protected int address = 0;
  
  protected int maxAddress = 65535;
  
  protected int pc = 0;
  
  protected Computer computer;
  
  protected int lineHeight = 0;
  
  protected int[] addresses = new int[0];
  
  protected int selAnchor = 0;
  
  protected int selStart = 0;
  
  protected int selEnd = 0;
  
  protected int timerY = 0;
  
  protected Counter counter = null;
  
  protected boolean inSet = false;
  
  public EDisassembler() {
    enableEvents(48L);
    setBackground(Color.white);
    setForeground(Color.black);
    setBorder(new BevelBorder(1));
    setFont(new Font("Courier", 0, 12));
    setLayout(new BorderLayout());
    this.scrollBar.addAdjustmentListener(this);
    this.scrollBar.setBlockIncrement(16);
    add(this.scrollBar, "East");
    setFocusable(true);
  }
  
  public void setComputer(Computer value) {
    this.computer = value;
    this.scrollBar.setMinimum(0);
    this.scrollBar.setMaximum(65552);
    this.scrollBar.setVisibleAmount(16);
    this.maxAddress = this.computer.getMemory().getAddressSize() - 1;
    repaint();
  }
  
  public Dimension getPreferredSize() {
    return new Dimension(200, 200);
  }
  
  protected void paintComponent(Graphics g) {
    Insets insets = getInsets();
    Rectangle rect = new Rectangle(insets.left + 1, insets.top + 1, getWidth() - this.scrollBar.getWidth() - insets.left - insets.right - 2, getHeight() - insets.top - insets.bottom - 2);
    g.setColor(Color.black);
    g.drawRect(rect.x - 1, rect.y - 1, rect.width + 1, rect.height + 1);
    g.setColor(getBackground());
    g.fillRect(rect.x, rect.y, rect.width, rect.height);
    g.setFont(getFont());
    FontMetrics fm = g.getFontMetrics();
    if (this.computer != null) {
      Disassembler diss = this.computer.getDisassembler();
      if (diss != null) {
        int a = fm.getAscent();
        int[] addr = { this.address };
        int h = this.lineHeight = fm.getHeight();
        this.addresses = new int[(rect.height + h - 1) / h];
        int n = 0;
        int y;
        for (y = rect.y; y < rect.y + rect.height; y += fm.getHeight()) {
          this.addresses[n++] = addr[0];
          if (addr[0] == this.pc) {
            g.setColor(pcBackground);
            g.fillRect(0, y, rect.width, fm.getHeight());
            g.setColor((pcForeground == null) ? getForeground() : pcForeground);
          } else if (addr[0] >= this.selStart && addr[0] <= this.selEnd) {
            g.setColor(selBackground);
            g.fillRect(0, y, rect.width, fm.getHeight());
            g.setColor((selForeground == null) ? getForeground() : selForeground);
          } else {
            g.setColor(getForeground());
          } 
          String line = diss.disassemble(this.computer.getMemory(), addr, true, 30);
          g.drawString(line, rect.x, y + a);
        } 
        this.scrollBar.setVisibleAmount(rect.height / h);
      } 
    } 
  }
  
  public void setPC(int value) {
    setAddress(this.pc = value, true);
  }
  
  public void setAddress(int value, boolean scroll) {
    this.address = Math.min(65535, value);
    repaint();
    if (scroll) {
      this.inSet = true;
      this.scrollBar.setValue(this.address);
      this.inSet = false;
    } 
  }
  
  public void setAddress(int value) {
    setAddress(value, true);
  }
  
  public int getAddress(int y) {
    Insets insets = getInsets();
    y = (y - insets.top + 1) / this.lineHeight;
    return (y < 0 || y >= this.addresses.length) ? -1 : this.addresses[y];
  }
  
  public void adjustmentValueChanged(AdjustmentEvent e) {
    if (!this.inSet) {
      int i;
      switch (e.getValue() - this.address) {
        case 1:
          nextAddress();
          break;
        case -1:
          prevAddress();
          break;
        case 16:
          for (i = Math.max(1, this.addresses.length - 1); i > 0; i--)
            nextAddress(); 
          break;
        case -16:
          for (i = Math.max(1, this.addresses.length - 1); i > 0; i--)
            prevAddress(); 
          break;
        default:
          setAddress(this.scrollBar.getValue());
          break;
      } 
      this.scrollBar.setValue(this.address);
    } 
  }
  
  protected void nextAddress() {
    Disassembler diss = this.computer.getDisassembler();
    diss.disassemble(this.computer.getMemory(), this.addresses, false, 0);
    setAddress(this.addresses[0], false);
  }
  
  protected void prevAddress() {
    int end = this.addresses[0];
    int addr = end - 6 & 0xFFFF;
    Disassembler diss = this.computer.getDisassembler();
    while (true) {
      int result = addr;
      this.addresses[0] = addr;
      diss.disassemble(this.computer.getMemory(), this.addresses, false, 0);
      addr = this.addresses[0];
      if (addr != end)
        addr = result + 1 & 0xFFFF; 
      if (addr == end) {
        setAddress(this.addresses[0] = result, false);
        return;
      } 
    } 
  }
  
  protected void setSelection(int addr, boolean range) {
    if (!range) {
      this.selAnchor = this.selStart = this.selEnd = addr;
    } else if (addr < this.selAnchor) {
      this.selStart = addr;
      this.selEnd = this.selAnchor;
    } else {
      this.selStart = this.selAnchor;
      this.selEnd = addr;
    } 
  }
  
  protected void startTimer(int y) {
    if (this.counter == null)
      this.counter = new Counter(this, 50L, null); 
    this.timerY = y;
  }
  
  protected void stopTimer() {
    if (this.counter != null) {
      this.counter.stop();
      this.counter = null;
    } 
  }
  
  public void timerTick(Counter counter) {
    if (this.counter == counter) {
      if (this.timerY < 0) {
        prevAddress();
        setSelection(this.address, true);
      } else {
        nextAddress();
        setSelection(this.addresses[this.addresses.length - 1], true);
      } 
      this.scrollBar.setValue(this.address);
      repaint();
    } 
  }
  
  protected void processMouseEvent(MouseEvent e) {
    if (e.getButton() == 1)
      if (e.getID() == 501) {
        setSelection(getAddress(e.getY()), ((e.getModifiers() & 0x1) != 0));
        repaint();
      } else if (e.getID() == 502) {
        stopTimer();
      }  
    super.processMouseEvent(e);
  }
  
  protected void processMouseMotionEvent(MouseEvent e) {
    if (e.getID() == 506 && (e.getModifiers() & 0x10) != 0) {
      Dimension size = getSize();
      int y = e.getY();
      if (y >= size.height) {
        setSelection(this.addresses[this.addresses.length - 1], true);
        startTimer(y);
      } else if (y < 0) {
        setSelection(this.addresses[0], true);
        startTimer(y);
      } else {
        setSelection(getAddress(e.getY()), true);
        stopTimer();
      } 
      repaint();
    } 
    super.processMouseMotionEvent(e);
  }
  
  protected void processKeyEvent(KeyEvent e) {
    if (e.getID() == 401) {
      boolean shift = ((e.getModifiers() & 0x1) != 0);
      switch (e.getKeyCode()) {
        case 36:
          setSelection(0, shift);
          break;
        case 35:
          setSelection(this.maxAddress - 1, shift);
          break;
        case 38:
          setSelection(this.address - 1, shift);
          break;
        case 40:
          setSelection(this.address + 1, shift);
          break;
        case 34:
          setSelection(this.address + 10, shift);
          break;
        case 33:
          setSelection(this.address - 10, shift);
          break;
      } 
    } 
    super.processKeyEvent(e);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCP\\ui\EDisassembler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */