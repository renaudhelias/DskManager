package JCPC.ui;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Autotype extends JFrame {
  private JScrollPane jScrollPane1;
  
  public JButton send;
  
  public static JTextArea text;
  
  public Autotype() {
    initComponents();
  }
  
  private void initComponents() {
    this.jScrollPane1 = new JScrollPane();
    text = new JTextArea();
    this.send = new JButton();
    setTitle("AutoType");
    text.setColumns(20);
    text.setRows(5);
    this.jScrollPane1.setViewportView(text);
    getContentPane().add(this.jScrollPane1, "Center");
    this.send.setText("Send!");
    getContentPane().add(this.send, "South");
    pack();
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCP\\ui\Autotype.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */