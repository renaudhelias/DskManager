package JCPC.ui;

public interface TimerListener {
  void timerTick(Counter paramCounter);
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCP\\ui\TimerListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */