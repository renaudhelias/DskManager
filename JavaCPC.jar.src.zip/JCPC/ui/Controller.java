package JCPC.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class Controller extends JFrame implements KeyListener {
  public int[] keyevents;
  
  char[] keychars;
  
  String[] keylocs;
  
  int keyindex;
  
  boolean changekey;
  
  String[] loc;
  
  final URL img;
  
  BufferedImage panel;
  
  public JComboBox cart;
  
  private JLabel jLabel1;
  
  private JLabel jLabel2;
  
  private JPanel jPanel1;
  
  public JCheckBox trojan;
  
  public void keyPressed(KeyEvent e) {}
  
  public void keyReleased(KeyEvent e) {
    if (e.getKeyCode() >= 112 && e.getKeyCode() <= 61451)
      return; 
    if (e.getKeyCode() == 17)
      return; 
    if (e.getKeyCode() == 16)
      return; 
    if (e.getKeyCode() == 20)
      return; 
    if (e.getKeyCode() == 18)
      return; 
    if (e.getKeyCode() == 65406)
      return; 
    this.keyevents[this.keyindex] = e.getKeyCode();
    this.keychars[this.keyindex] = e.getKeyChar();
    this.keylocs[this.keyindex] = (e.getKeyLocation() == 4) ? "NP_" : "KB_";
    removeKeyListener(this);
    this.changekey = false;
    updateController();
  }
  
  public void keyTyped(KeyEvent e) {}
  
  public Controller() {
    this.keyevents = new int[] { 101, 96, 104, 98, 100, 102 };
    this.keychars = new char[] { '5', '0', '8', '2', '4', '5' };
    this.keylocs = new String[] { "NP_", "NP_", "NP_", "NP_", "NP_", "NP_" };
    this.changekey = false;
    this.loc = new String[] { "Fire 1", "Fire 2", "Up", "Down", "Left", "Right" };
    this.img = getClass().getResource("/JCPC/ui/controller.png");
    initComponents();
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    setLocation((d.width - (getSize()).width) / 2, (d.height - (getSize()).height) / 2);
    updateController();
  }
  
  public void setButton(int index) {
    this.keyindex = index;
    this.changekey = true;
    updateController();
    addKeyListener(this);
  }
  
  public char getButton(int index) {
    char result = this.keychars[index];
    return result;
  }
  
  public void updateController() {
    try {
      this.panel = ImageIO.read(this.img);
      Graphics c = this.panel.createGraphics();
      c.setColor(Color.green);
      if (this.changekey) {
        c.drawString("Press desired key:", 120, 30);
        c.drawString("Press desired key:", 121, 30);
        c.drawString(this.loc[this.keyindex], 120, 50);
        c.drawString(this.loc[this.keyindex], 121, 50);
        requestFocus();
      } 
      c.setColor(Color.blue);
      c.drawString("" + this.keylocs[0] + ((this.keychars[0] == ' ') ? "spc" : (String)Character.valueOf(this.keychars[0])), 243, 90);
      c.drawString("" + this.keylocs[0] + ((this.keychars[0] == ' ') ? "spc" : (String)Character.valueOf(this.keychars[0])), 244, 90);
      c.drawString("" + this.keylocs[1] + ((this.keychars[1] == ' ') ? "spc" : (String)Character.valueOf(this.keychars[1])), 296, 90);
      c.drawString("" + this.keylocs[1] + ((this.keychars[1] == ' ') ? "spc" : (String)Character.valueOf(this.keychars[1])), 297, 90);
      c.drawString("" + this.keylocs[2] + ((this.keychars[2] == ' ') ? "spc" : (String)Character.valueOf(this.keychars[2])), 50, 50);
      c.drawString("" + this.keylocs[2] + ((this.keychars[2] == ' ') ? "spc" : (String)Character.valueOf(this.keychars[2])), 51, 50);
      c.drawString("" + this.keylocs[3] + ((this.keychars[3] == ' ') ? "spc" : (String)Character.valueOf(this.keychars[3])), 50, 154);
      c.drawString("" + this.keylocs[3] + ((this.keychars[3] == ' ') ? "spc" : (String)Character.valueOf(this.keychars[3])), 51, 154);
      c.drawString("" + this.keylocs[4] + ((this.keychars[4] == ' ') ? "spc" : (String)Character.valueOf(this.keychars[4])), 1, 100);
      c.drawString("" + this.keylocs[4] + ((this.keychars[4] == ' ') ? "spc" : (String)Character.valueOf(this.keychars[4])), 2, 100);
      c.drawString("" + this.keylocs[5] + ((this.keychars[5] == ' ') ? "spc" : (String)Character.valueOf(this.keychars[5])), 110, 100);
      c.drawString("" + this.keylocs[5] + ((this.keychars[5] == ' ') ? "spc" : (String)Character.valueOf(this.keychars[5])), 111, 100);
      this.jLabel1.setIcon(new ImageIcon(this.panel));
    } catch (Exception exception) {}
  }
  
  private void initComponents() {
    this.jLabel1 = new JLabel();
    this.jPanel1 = new JPanel();
    this.trojan = new JCheckBox();
    this.cart = new JComboBox();
    this.jLabel2 = new JLabel();
    setTitle("Gamepad Options");
    setResizable(false);
    this.jLabel1.setIcon(new ImageIcon(getClass().getResource("/JCPC/ui/controller.png")));
    this.jLabel1.setFocusable(false);
    this.jLabel1.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent evt) {
            Controller.this.jLabel1MouseReleased(evt);
          }
        });
    this.jLabel1.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Controller.this.jLabel1MouseMoved(evt);
          }
        });
    getContentPane().add(this.jLabel1, "Center");
    this.jPanel1.setLayout(new BorderLayout());
    this.trojan.setText("Enable Trojan Lightgun");
    this.trojan.setFocusPainted(false);
    this.trojan.setFocusable(false);
    this.jPanel1.add(this.trojan, "West");
    this.cart.setModel(new DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
    this.jPanel1.add(this.cart, "East");
    this.jLabel2.setHorizontalAlignment(4);
    this.jLabel2.setText("Select Cartridge  ");
    this.jPanel1.add(this.jLabel2, "Center");
    getContentPane().add(this.jPanel1, "Last");
    pack();
  }
  
  private void jLabel1MouseReleased(MouseEvent evt) {
    int x = evt.getX();
    int y = evt.getY();
    if (y > 100 && y < 132) {
      if (x > 244 && x < 276) {
        System.out.println("button 1");
        setButton(0);
      } 
      if (x > 290 && x < 328) {
        System.out.println("button 2");
        setButton(1);
      } 
    } 
    if (x > 50 && x < 75) {
      if (y > 56 && y < 84) {
        System.out.println("button up");
        setButton(2);
      } 
      if (y > 110 && y < 132) {
        System.out.println("button down");
        setButton(3);
      } 
    } 
    if (y > 84 && y < 110) {
      if (x < 50 && x > 28) {
        System.out.println("button left");
        setButton(4);
      } 
      if (x > 75 && x < 100) {
        System.out.println("button right");
        setButton(5);
      } 
    } 
  }
  
  private void jLabel1MouseMoved(MouseEvent evt) {
    int x = evt.getX();
    int y = evt.getY();
    this.jLabel1.setCursor(new Cursor(0));
    if (y > 100 && y < 132)
      if (x > 244 && x < 276) {
        this.jLabel1.setCursor(new Cursor(12));
      } else if (x > 290 && x < 328) {
        this.jLabel1.setCursor(new Cursor(12));
      }  
    if (x > 50 && x < 75) {
      if (y > 56 && y < 84)
        this.jLabel1.setCursor(new Cursor(12)); 
      if (y > 110 && y < 132)
        this.jLabel1.setCursor(new Cursor(12)); 
    } 
    if (y > 84 && y < 110) {
      if (x < 50 && x > 28)
        this.jLabel1.setCursor(new Cursor(12)); 
      if (x > 75 && x < 100)
        this.jLabel1.setCursor(new Cursor(12)); 
    } 
  }
  
  public static void main(String[] args) {
    try {
      for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
          UIManager.setLookAndFeel(info.getClassName());
          break;
        } 
      } 
    } catch (ClassNotFoundException ex) {
      Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (InstantiationException ex) {
      Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (IllegalAccessException ex) {
      Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (UnsupportedLookAndFeelException ex) {
      Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new Controller()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCP\\ui\Controller.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */