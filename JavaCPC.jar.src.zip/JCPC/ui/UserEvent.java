package JCPC.ui;

import java.awt.AWTEvent;

public class UserEvent extends AWTEvent {
  public static final int FIRST_ID = 4000;
  
  protected Object data;
  
  public UserEvent(Object source, int id, Object data) {
    super(source, id);
    this.data = data;
  }
  
  public Object getData() {
    return this.data;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCP\\ui\UserEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */