package JCPC.core.device.floppy;

import JCPC.core.Util;
import JCPC.core.device.Device;
import JCPC.system.cpc.Samples;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class UPD765A extends Device {
  public static boolean error = false;
  
  public static boolean fastdisk = false;
  
  public boolean showSys = false;
  
  protected int counter;
  
  boolean parados = false;
  
  int[] enduser = null;
  
  boolean systemdisk = false;
  
  private static final boolean DEBUG = false;
  
  private static final boolean DEBUGINFO = false;
  
  private static final boolean DEBUG_SENSE = false;
  
  private static final boolean DEBUG_GAP = false;
  
  private static final boolean DEBUG_BUFFER = false;
  
  private static final boolean DEBUG_DATA = false;
  
  private static final boolean DEBUG_READ_ID = false;
  
  protected boolean readtrack = false;
  
  private static final int[] SECTOR_SIZES = new int[] { 128, 256, 512, 1024, 2048, 4096, 6144 };
  
  protected static int[] sectSizes = new int[90];
  
  public static int getSectorSize(int commandSize) {
    int ret = SECTOR_SIZES[Math.min(commandSize, 6)];
    sectSizes[params[1]] = ret;
    return ret;
  }
  
  public static int getCommandSize(int realSize) {
    for (int i = 0; i < SECTOR_SIZES.length; i++) {
      if (SECTOR_SIZES[i] == realSize)
        return i; 
    } 
    return 2;
  }
  
  public int[] formatid = new int[] { 0, 0, 0, 0 };
  
  protected int actualDrive = 0;
  
  protected static int READ_TIME_FM;
  
  protected static int READ_TIME_MFM;
  
  protected static int POLL_TIME;
  
  protected static final int POLL = 0;
  
  protected static final int SEEK = 1;
  
  protected static final int READ_ID = 2;
  
  protected static final int MATCH_SECTOR = 3;
  
  protected static final int READ = 4;
  
  protected static final int WRITE = 5;
  
  protected static final int FORMAT = 6;
  
  protected static final int SCAN = 8;
  
  protected static final int[] CMD_PARAMS = new int[] { 
      0, 0, 8, 2, 1, 8, 8, 1, 0, 8, 
      1, 0, 8, 5, 0, 2, 0, 8, 0, 0, 
      0, 0, 0, 0, 0, 8, 0, 0, 0, 8, 
      0, 0 };
  
  protected static final int[] CMD_PARAMS_SEEK = new int[] { 
      0, 0, 0, 2, 1, 0, 0, 1, 0, 0, 
      0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0 };
  
  protected static final int D0_BUSY = 1;
  
  protected static final int D1_BUSY = 2;
  
  protected static final int D2_BUSY = 4;
  
  protected static final int D3_BUSY = 8;
  
  protected static final int COMMAND_BUSY = 16;
  
  protected static final int EXEC_MODE = 32;
  
  protected static final int DATA_IN_OUT = 64;
  
  protected static final int REQ_MASTER = 128;
  
  protected static final int SEEK_MASK = 15;
  
  protected static final int ST0_NORMAL = 0;
  
  protected static final int ST0_ABNORMAL = 64;
  
  protected static final int ST0_INVALID = 128;
  
  protected static final int ST0_READY_CHANGE = 192;
  
  protected static final int ST0_NOT_READY = 8;
  
  protected static final int ST0_HEAD_ADDR = 4;
  
  protected static final int ST0_EQUIP_CHECK = 16;
  
  protected static final int ST0_SEEK_END = 32;
  
  protected static final int ST1_MISSING_ADDR = 1;
  
  protected static final int ST1_NOT_WRITABLE = 2;
  
  protected static final int ST1_NO_DATA = 4;
  
  protected static final int ST1_OVERRUN = 16;
  
  protected static final int ST1_DATA_ERROR = 32;
  
  protected static final int ST1_END_CYL = 128;
  
  protected static final int ST2_MISSING_ADDR = 1;
  
  protected static final int ST2_BAD_CYLINDER = 2;
  
  protected static final int ST2_SCAN_NOT_SAT = 4;
  
  protected static final int ST2_SCAN_EQU_HIT = 8;
  
  protected static final int ST2_WRONG_CYL = 16;
  
  protected static final int ST2_DATA_ERROR = 32;
  
  protected static final int ST2_CONTROL_MARK = 64;
  
  protected static final int ST3_HEAD_ADDR = 4;
  
  protected static final int ST3_TWO_SIDE = 8;
  
  protected static final int ST3_TRACK_0 = 16;
  
  protected static final int ST3_READY = 32;
  
  protected static final int ST3_WRITE_PROT = 64;
  
  protected static final int ST3_FAULT = 128;
  
  protected int command;
  
  protected int action;
  
  protected static int[] params = new int[8];
  
  protected int pcount = 0;
  
  protected int pindex = 0;
  
  protected int[] result = new int[7];
  
  protected int rindex = 0;
  
  protected int rcount = 0;
  
  protected Drive activeDrive;
  
  protected int c;
  
  protected int h;
  
  protected int r;
  
  protected int n;
  
  protected int offset;
  
  protected int size;
  
  protected byte[] buffer;
  
  protected int count;
  
  protected int next;
  
  protected int status;
  
  protected int st1;
  
  protected int st2;
  
  protected int st3;
  
  protected byte data;
  
  protected int sectorcount;
  
  protected int cycleRate;
  
  protected int countPoll;
  
  protected int countStep;
  
  protected int countFM;
  
  protected int countMFM;
  
  protected Drive[] drives = new Drive[4];
  
  protected int[] pcn = new int[4];
  
  protected int[] ncn = new int[4];
  
  protected int[] dir = new int[4];
  
  protected int[] max = new int[4];
  
  protected int[] st0 = new int[4];
  
  protected boolean[] ready = new boolean[4];
  
  protected Device interruptDevice;
  
  protected int interruptMask;
  
  private boolean driveChanged;
  
  public static int nooftracks;
  
  public static String statusinfo;
  
  int oldstat;
  
  boolean DEBUGPORT;
  
  public UPD765A(int clocksPerCycle) {
    super("NEC uPD765AC-2 Floppy Controller");
    this.DEBUGPORT = false;
    this.seeker = 0;
    this.overrun = false;
    this.LOW_OR_EQUAL = 0;
    this.HIGH_OR_EQUAL = 1;
    this.EQUAL = 2;
    this.SCAN_COMMAND = 0;
    this.offset2 = 0;
    this.sectorsize = 1;
    this.stop = false;
    this.stat = 0;
    this.saveTimer = 0;
    this.cy = 0;
    switch (clocksPerCycle) {
      case 1:
      case 2:
      case 4:
      case 8:
        this.cycleRate = clocksPerCycle;
        break;
      default:
        this.cycleRate = 4;
        break;
    } 
    READ_TIME_FM = 32;
    READ_TIME_MFM = 16;
    POLL_TIME = 1024;
    this.countPoll = POLL_TIME * this.cycleRate;
    this.countFM = READ_TIME_FM * this.cycleRate;
    this.countMFM = READ_TIME_MFM * this.cycleRate;
    reset();
  }
  
  public void getNoOfTracks() {
    try {
      int drive = getDrive();
      nooftracks = this.drives[drive].getTracks();
    } catch (Exception e) {
      nooftracks = 40;
    } 
  }
  
  public void setInterruptDevice(Device device, int mask) {
    this.interruptDevice = device;
    this.interruptMask = mask;
  }
  
  public void setDrive(int index, Drive drive) {
    this.drives[index] = drive;
    this.driveChanged = true;
  }
  
  public Drive getDrive(int index) {
    return this.drives[index];
  }
  
  public void setStatusInfo() {
    if (this.status != this.oldstat) {
      this.oldstat = this.status;
      statusinfo = "???";
      if ((this.status & 0x40) != 0) {
        statusinfo = "FDC to CPU";
      } else {
        statusinfo = "CPU to FDC";
      } 
      if ((this.status & 0x80) != 0)
        statusinfo = "FDC ready for data"; 
      if ((this.status & 0x20) != 0)
        statusinfo = "Command execution"; 
      if ((this.status & 0x10) != 0)
        statusinfo = "FDC is busy"; 
      if ((this.status & 0x8) != 0)
        statusinfo = "DF3 is seeking"; 
      if ((this.status & 0x4) != 0)
        statusinfo = "DF2 is seeking"; 
      if ((this.status & 0x2) != 0)
        statusinfo = "DF1 is seeking"; 
      if ((this.status & 0x1) != 0)
        statusinfo = "DF0 is seeking"; 
    } 
  }
  
  public final int readPort(int port) {
    if ((port & 0x1) == 0)
      return this.status; 
    if ((this.status & 0xA0) == 128 && this.rcount > 0) {
      this.data = (byte)this.result[this.rindex++];
      if (--this.rcount == 0)
        this.status &= 0xFFFFFFAF; 
    } else if (this.action == 4 && (this.status & 0x80) != 0) {
      this.status &= 0xFFFFFF7F;
    } 
    this.overrun = false;
    return this.data;
  }
  
  public static String commands = "";
  
  public int seeker;
  
  int[] oldid;
  
  protected boolean overrun;
  
  protected final int LOW_OR_EQUAL = 0;
  
  protected final int HIGH_OR_EQUAL = 1;
  
  protected final int EQUAL = 2;
  
  protected int SCAN_COMMAND;
  
  protected byte[] Dfdd;
  
  protected byte[] Dcpu;
  
  int offset2;
  
  int sectorsize;
  
  boolean stop;
  
  int[] lastid;
  
  int stat;
  
  public int saveTimer;
  
  int cy;
  
  boolean slow;
  
  public final void writePort(int port, int value) {
    if (port < 64000 || port > 64511) {
      if (this.DEBUGPORT)
        System.err.println("Possibly bad port write on port " + Util.hex((short)port) + " with data:" + Util.hex((byte)value)); 
      return;
    } 
    if ((port & 0x1) != 0) {
      this.data = (byte)value;
      this.overrun = false;
      if ((this.status & 0xC0) == 128) {
        if ((this.status & 0x20) != 0)
          this.status &= 0xFFFFFF7F; 
        if ((this.status & 0x10) == 0) {
          this.command = value;
          value &= 0x1F;
          this.status |= 0x10;
          this.pindex = 0;
          if ((this.pcount = CMD_PARAMS[value]) == 0) {
            this.status |= 0x40;
            this.result[this.rindex = 0] = 128;
            this.rcount = 1;
            if (value == 8)
              for (int drive = 0; drive < 4; drive++) {
                if (this.st0[drive] != 128) {
                  this.result[0] = this.st0[drive];
                  this.st0[drive] = 128;
                  this.result[1] = this.pcn[drive];
                  this.status &= 1 << drive ^ 0xFFFFFFFF;
                  this.rcount = 2;
                  return;
                } 
              }  
          } 
        } 
        params[this.pindex++] = value;
        if (--this.pcount == 0) {
          if (this.command == 102)
            this.command = 102; 
          String msg = "FDC Command " + Util.hex((byte)this.command) + ": " + Util.hex((byte)params[1]) + "/" + Util.hex((byte)params[2]) + "/" + Util.hex((byte)params[3]) + "/" + Util.hex((byte)params[4]) + " ";
          switch (this.command & 0x1F) {
            case 2:
              commands = "Read Track";
              readTrack();
            case 3:
              commands = "Specify";
              specify();
            case 4:
              commands = "Sense Drive";
              senseDrive();
            case 5:
              commands = "Write Sector";
              writeSector();
            case 6:
              commands = "Read Sector";
              readSector();
            case 7:
              commands = "Re-Calibrate";
              seek(0, 77);
            case 8:
              return;
            case 9:
              commands = "Write Del.";
              writeSector();
            case 10:
              commands = "Read ID";
              readID();
            case 12:
              commands = "Read Del.";
              readSector();
            case 13:
              commands = "Format Track";
              this.sectorcount = 0;
              formatTrack();
            case 15:
              commands = "Seek Track";
              seek(params[1], -1);
            case 17:
              commands = "Scan Equal";
              scan(2);
            case 25:
              commands = "Scan L.o.E.";
              scan(0);
            case 29:
              commands = "Scan H.o.E.";
              scan(1);
          } 
          throw new RuntimeException("Invalid command: " + Util.hex((byte)this.command));
        } 
      } 
    } 
  }
  
  public final void reset() {
    Samples.SEEK.stop();
    Samples.SEEKBACK.stop();
    this.pindex = this.pcount = this.count = 0;
    this.status = 128;
    this.countStep = 128000 / this.cycleRate;
    this.action = 0;
    this.next = this.countPoll;
    this.stop = false;
    this.command = 0;
  }
  
  public final void resetb() {
    this.pindex = this.pcount = this.count = 0;
    this.status = 128;
    this.action = 0;
  }
  
  public final void initialise() {
    this.pindex = this.pcount = this.count = 0;
    this.action = 0;
  }
  
  public final void specify() {
    this.countStep = (16 - (params[0] >> 4)) * 8000 / this.cycleRate;
    this.status &= 0xFFFFFFAF;
  }
  
  public final void senseDrive() {
    int select = params[0] & 0x7;
    int drv = select & 0x3;
    this.activeDrive = this.drives[drv];
    if (this.activeDrive != null) {
      if (this.ready[drv])
        select |= 0x20; 
      if (this.activeDrive.getCylinder() == 0)
        select |= 0x10; 
      if (this.activeDrive.getSides() == 2)
        select |= 0x8; 
      if (this.activeDrive.isWriteProtected())
        select |= 0x40; 
    } 
    this.driveChanged = false;
    this.result[this.rindex = 0] = select;
    this.rcount = 1;
    this.status |= 0x40;
  }
  
  public int getDrive() {
    this.actualDrive = params[0] & 0x3;
    return this.actualDrive;
  }
  
  public int getCylinder() {
    System.out.println("FDC is on Cylinder " + this.result[3]);
    return this.result[3];
  }
  
  public final void seek(int cyl, int steps) {
    Samples.MOTOR.turn2();
    this.seeker = 1;
    getDrive();
    this.max[this.actualDrive] = steps;
    this.ncn[this.actualDrive] = cyl;
    this.status &= 0xFFFFFFEF;
    if (this.pcn[this.actualDrive] == cyl) {
      seekEnd(this.actualDrive, 0);
    } else {
      this.status |= 1 << this.actualDrive;
      if (this.pcn[this.actualDrive] < cyl) {
        this.dir[this.actualDrive] = 1;
        Samples.TRACK.play();
      } else if (this.pcn[this.actualDrive] > cyl) {
        Samples.TRACKBACK.play();
        this.dir[this.actualDrive] = -1;
      } 
      if (this.action != 1) {
        this.action = 1;
        this.next = this.count + this.countStep;
      } 
    } 
  }
  
  public final void seekStep() {
    for (int drive = 0; drive < 4; drive++) {
      if (this.pcn[drive] != this.ncn[drive]) {
        int step = this.dir[drive];
        this.pcn[drive] = this.pcn[drive] + step;
        if (this.drives[drive] != null && this.drives[drive].step(step))
          this.pcn[drive] = 0; 
        if (this.pcn[drive] == this.ncn[drive]) {
          seekEnd(drive, 0);
        } else {
          this.max[drive] = this.max[drive] - 1;
          if (this.max[drive] - 1 == 0) {
            this.ncn[drive] = this.pcn[drive];
            seekEnd(drive, 80);
          } else {
            this.next = this.count + this.countStep;
            if (this.pcn[drive] <= 9) {
              String track = "0";
            } else {
              String track = "";
            } 
            getNoOfTracks();
            if (this.activeDrive != null)
              this.activeDrive.setActive(false); 
            if (step > 0) {
              Samples.SEEK.loop2();
            } else {
              Samples.SEEKBACK.loop2();
            } 
          } 
        } 
      } 
    } 
  }
  
  protected final void seekEnd(int drive, int status) {
    this.st0[drive] = status | 0x20 | drive;
    this.dir[drive] = 0;
    Samples.SEEK.stop();
    Samples.SEEKBACK.stop();
    if ((this.dir[0] | this.dir[1] | this.dir[2] | this.dir[3]) == 0) {
      this.action = 0;
      this.next = this.count + this.countPoll;
      if (this.activeDrive != null)
        this.activeDrive.setActive(true); 
    } 
  }
  
  public final void poll() {
    int drive = getDrive();
    boolean rdy = true;
    if (rdy != this.ready[drive]) {
      this.ready[drive] = rdy;
      this.st0[drive] = 0xC0 | (rdy ? Character.MIN_VALUE : '\b') | drive;
    } 
  }
  
  public final boolean setupResult() {
    int select = params[0] & 0x7;
    this.driveChanged = false;
    this.activeDrive = this.drives[select & 0x3];
    this.result[this.rindex = 0] = select | 0x40;
    this.result[1] = 5;
    this.rcount = 2;
    if (this.activeDrive != null && this.activeDrive.isReady()) {
      this.activeDrive.setHead(select >> 2);
      this.activeDrive.setActive(true);
      return true;
    } 
    this.result[0] = this.result[0] | 0x8;
    this.status |= 0x40;
    return false;
  }
  
  public final void readID() {
    if (setupResult()) {
      this.action = 2;
      this.status ^= 0xC0;
      if (!fastdisk) {
        this.next = this.count + 77100 / this.cycleRate;
      } else {
        this.next = this.count + 1200 / this.cycleRate;
      } 
    } 
  }
  
  public final void getNextID() {
    int[] id = this.activeDrive.getNextSectorID();
    this.oldid = id;
    if (id != null) {
      this.result[0] = this.result[0] & 0xFFFFFFBF;
      this.result[2] = 0;
      this.result[1] = 0;
      this.result[3] = id[0];
      this.result[4] = id[1];
      this.result[5] = id[2];
      this.result[6] = id[3];
      this.next = this.count + this.countPoll;
    } else {
      this.result[0] = 64;
      this.result[1] = 1;
      this.result[3] = 0;
      this.result[4] = 0;
      this.result[5] = 1;
      this.result[6] = 2;
      this.next = this.count + this.countPoll;
    } 
    this.rcount = 7;
    this.status |= 0x80;
    this.action = 0;
  }
  
  protected final void readSectorByte() {
    if (this.offset == this.buffer.length || this.overrun) {
      endBuffer(4);
    } else {
      this.overrun = true;
      this.data = this.buffer[this.offset++];
      this.next = this.count + this.countMFM;
      this.status |= 0x80;
    } 
  }
  
  protected final void readSector() {
    if (setupResult())
      getNextSector(4); 
  }
  
  protected final void readTrack() {
    if (setupResult()) {
      this.readtrack = true;
      this.activeDrive.resetSector();
      getNextSector(4);
    } 
  }
  
  protected final void formatTrack() {
    if (setupResult()) {
      if (this.activeDrive == null)
        senseDrive(); 
      this.activeDrive.removeAllSectorsFromTrack();
      this.activeDrive.resetSector();
      getNextFormatID();
    } 
  }
  
  protected void addSector() {}
  
  protected final void getNextFormatID() {
    this.action = 6;
    this.offset = 0;
    this.status = this.status & 0xFFFFFFBF | 0x80 | 0x20;
    if (fastdisk) {
      this.next = this.count + 1200 / this.cycleRate;
    } else {
      this.next = this.count + 100000 / this.cycleRate;
    } 
    this.data = -1;
  }
  
  protected void scan(int scancommand) {
    if (setupResult())
      try {
        this.SCAN_COMMAND = scancommand;
        this.action = 8;
        this.Dfdd = this.activeDrive.getSector(params[1], params[2], params[3], params[4]);
        this.Dcpu = new byte[this.Dfdd.length];
        if (!fastdisk) {
          this.next = this.count + 77100 / this.cycleRate;
        } else {
          this.next = this.count + 1200 / this.cycleRate;
        } 
        this.offset2 = 0;
        this.status = this.status & 0xFFFFFFBF | 0x80 | 0x20;
        this.data = -1;
      } catch (Exception exception) {} 
  }
  
  protected final void writeScanByte() {
    // Byte code:
    //   0: aload_0
    //   1: getfield data : B
    //   4: iconst_m1
    //   5: if_icmpne -> 8
    //   8: aload_0
    //   9: getfield Dcpu : [B
    //   12: ifnull -> 35
    //   15: aload_0
    //   16: getfield Dcpu : [B
    //   19: aload_0
    //   20: dup
    //   21: getfield offset2 : I
    //   24: dup_x1
    //   25: iconst_1
    //   26: iadd
    //   27: putfield offset2 : I
    //   30: aload_0
    //   31: getfield data : B
    //   34: bastore
    //   35: aload_0
    //   36: iconst_m1
    //   37: putfield data : B
    //   40: aload_0
    //   41: getfield Dcpu : [B
    //   44: ifnull -> 70
    //   47: aload_0
    //   48: getfield offset2 : I
    //   51: aload_0
    //   52: getfield Dcpu : [B
    //   55: arraylength
    //   56: if_icmpne -> 70
    //   59: aload_0
    //   60: aload_0
    //   61: getfield SCAN_COMMAND : I
    //   64: invokevirtual endScanBuffer : (I)V
    //   67: goto -> 95
    //   70: aload_0
    //   71: aload_0
    //   72: getfield count : I
    //   75: aload_0
    //   76: getfield countMFM : I
    //   79: iadd
    //   80: putfield next : I
    //   83: aload_0
    //   84: dup
    //   85: getfield status : I
    //   88: sipush #128
    //   91: ior
    //   92: putfield status : I
    //   95: return
    // Line number table:
    //   Java source line number -> byte code offset
    //   #813	-> 0
    //   #814	-> 8
    //   #815	-> 15
    //   #817	-> 35
    //   #818	-> 40
    //   #819	-> 59
    //   #821	-> 70
    //   #822	-> 83
    //   #824	-> 95
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	96	0	this	LJCPC/core/device/floppy/UPD765A;
  }
  
  protected final void endScanBuffer(int direction) {
    int i, scanstatus = 4;
    switch (direction) {
      case 1:
        for (i = 0; i < this.Dfdd.length; i++) {
          if (this.Dfdd[i] == this.Dcpu[i])
            scanstatus |= 0x8; 
          if (this.Dfdd[i] >= this.Dcpu[i])
            scanstatus &= 0xFFFFFFFB; 
        } 
        break;
      case 0:
        for (i = 0; i < this.Dfdd.length; i++) {
          if (this.Dfdd[i] == this.Dcpu[i]) {
            scanstatus |= 0x8;
            break;
          } 
          if (this.Dfdd[i] <= this.Dcpu[i])
            scanstatus &= 0xFFFFFFFB; 
        } 
        break;
      case 2:
        for (i = 0; i < this.Dfdd.length; i++) {
          if (this.Dfdd[i] == this.Dcpu[i]) {
            scanstatus |= 0x8;
            scanstatus &= 0xFFFFFFFB;
          } 
        } 
        break;
    } 
    if (params[3] == params[5] || (scanstatus & 0x4) == 0) {
      this.status &= 0xFFFFFFDF;
      this.status |= 0xC0;
      this.result[0] = this.result[0] & 0xFFFFFFBF;
      this.result[1] = 0;
      this.result[2] = scanstatus;
      this.result[3] = params[1];
      this.result[4] = params[2];
      this.result[5] = 1;
      this.result[6] = params[4];
      this.rcount = 7;
      this.action = 0;
      this.next = this.count + this.countPoll;
      this.activeDrive.setActive(false);
    } else {
      params[3] = params[3] + 1 & 0xFF;
      getNextSector(4);
    } 
  }
  
  protected final void endFormatID() {
    int drive = getDrive();
    this.activeDrive.addSectorToTrack(this.formatid[0], this.formatid[1], this.formatid[2], this.formatid[3], params[4]);
    this.sectorcount = this.sectorcount + 1 & 0xFF;
    if (this.sectorcount == params[2]) {
      this.status &= 0xFFFFFFDF;
      this.status |= 0xC0;
      this.result[0] = this.result[0] & 0xFFFFFFBF;
      this.result[2] = 0;
      this.result[1] = 0;
      this.result[3] = params[1];
      this.result[4] = params[2];
      this.result[5] = 1;
      this.result[6] = params[4];
      this.rcount = 7;
      this.action = 0;
      this.next = this.count + this.countPoll;
      this.activeDrive.setActive(false);
    } else {
      getNextFormatID();
    } 
    if (this.activeDrive.getCylinder() <= 9) {
      String track = "0";
    } else {
      String track = "";
    } 
    getNoOfTracks();
    try {
      int[] arrayOfInt = this.activeDrive.getNextSectorID();
    } catch (Exception exception) {}
  }
  
  protected final void getNextSector(int direction) {
    this.buffer = this.activeDrive.getSector(params[1], params[2], params[3], params[4]);
    if (this.readtrack) {
      this.buffer = null;
      this.readtrack = false;
    } 
    if (direction == 4)
      if ((this.command & 0x1F) == 6) {
        if ((this.command & 0x20) != 0)
          if (isDeletedData()) {
            endBuffer(direction);
            return;
          }  
      } else if ((this.command & 0x1F) == 12) {
        if ((this.command & 0x20) != 0)
          if (!isDeletedData()) {
            endBuffer(direction);
            return;
          }  
      }  
    if (direction == 5)
      if ((this.command & 0x1F) == 5) {
        this.activeDrive.setST2ForSector(params[1], params[2], params[3], params[4], 0);
      } else if ((this.command & 0x1F) == 9) {
        this.activeDrive.setST2ForSector(params[1], params[2], params[3], params[4], 64);
      }  
    if (this.buffer != null) {
      if (params[1] <= 9) {
        String track = "0";
      } else {
        String track = "";
      } 
      int drive = getDrive();
      getNoOfTracks();
      this.offset = 0;
      this.action = direction;
      if (direction == 4) {
        this.status = this.status & 0xFFFFFF7F | 0x40 | 0x20;
      } else {
        this.status = this.status & 0xFFFFFFBF | 0x80 | 0x20;
      } 
      this.next = this.count + getGAP2() + this.countPoll;
      this.data = -1;
    } else {
      endBuffer(direction);
    } 
  }
  
  public int getGAP2() {
    int total = 146 + getSectorSize() * this.activeDrive.getSectorCount();
    int gap = (6250 - total) / this.activeDrive.getSectorCount();
    int timer = (62 + gap) * 32;
    return timer / 3;
  }
  
  public int getSectorSize() {
    try {
      this.sectorsize = this.buffer.length;
    } catch (Exception exception) {}
    return this.sectorsize;
  }
  
  public int getTiming() {
    if (fastdisk)
      return this.countPoll; 
    int numbytes = 0;
    int i;
    for (i = 0; i < this.activeDrive.getSectorCount(); i++) {
      try {
        int[] sectorID = this.activeDrive.getNextSectorID();
        if (sectorID[2] == params[3])
          break; 
      } catch (Exception e) {
        break;
      } 
    } 
    for (i = 0; i < this.activeDrive.getSectorCount(); i++) {
      numbytes += getGAP() + 2 + 60;
      try {
        int[] sectorID = this.activeDrive.getNextSectorID();
        if (sectorID[2] == (params[3] + 1 & 0xFF))
          break; 
        numbytes += SECTOR_SIZES[Math.min(sectorID[3], 6)];
      } catch (Exception e) {
        break;
      } 
    } 
    int numCycles = numbytes * this.countMFM / 3;
    return numCycles;
  }
  
  public int getGAP() {
    try {
      int secs = this.activeDrive.getSectorCount();
      int GAPLength = (6100 - getSectorSize() * secs) / secs;
      GAPLength &= 0x7F;
      if (GAPLength < 1)
        GAPLength = 1; 
      if (GAPLength > 90)
        GAPLength = 90; 
      return GAPLength;
    } catch (Exception e) {
      return this.countPoll;
    } 
  }
  
  protected boolean isDeletedData() {
    return ((this.activeDrive.getST2ForSector(params[1], params[2], params[3], params[4]) & 0x40) != 0);
  }
  
  protected final void endBuffer(int direction) {
    int[] id;
    try {
      id = this.activeDrive.getReadID();
      this.lastid = id;
    } catch (Exception e) {
      id = this.lastid;
    } 
    if (this.buffer == null)
      try {
        this.status &= 0xFFFFFFDF;
        this.status |= 0xC0;
        this.result[0] = this.result[0] | 0x40;
        this.result[1] = 4;
        this.result[2] = 0;
        params[1] = id[0];
        this.result[3] = id[0];
        params[2] = id[1];
        this.result[4] = id[1];
        this.result[5] = id[2];
        params[4] = id[3];
        this.result[6] = id[3];
        this.rcount = 7;
        this.action = 0;
        this.next = this.count + getTiming();
        this.activeDrive.setActive(false);
        return;
      } catch (Exception exception) {} 
    this.stop = false;
    if (direction == 4)
      if ((this.command & 0x1F) == 6) {
        if (isDeletedData())
          this.stop = true; 
      } else if ((this.command & 0x1F) == 12) {
        if (!isDeletedData())
          this.stop = true; 
      }  
    if ((this.activeDrive.getST2ForSector(params[1], params[2], params[3], params[4]) & 0x20) != 0)
      this.stop = true; 
    if ((this.activeDrive.getST1ForSector(params[1], params[2], params[3], params[4]) & 0x20) != 0)
      this.stop = true; 
    if (params[3] == params[5] || this.stop || this.overrun) {
      this.status &= 0xFFFFFFDF;
      this.status |= 0xC0;
      if (this.stop) {
        this.result[0] = this.result[0] & 0xFFFFFFBF;
        this.result[2] = 0;
        this.result[1] = 0;
      } else {
        this.result[0] = this.result[0] & 0x40;
        this.result[1] = 128;
        this.result[2] = 0;
      } 
      this.result[1] = this.result[1] | this.activeDrive.getST1ForSector(params[1], params[2], params[3], params[4]) & 0x20;
      this.result[2] = this.result[2] | this.activeDrive.getST2ForSector(params[1], params[2], params[3], params[4]) & 0x20;
      if (this.overrun) {
        System.out.println("FDC overrun");
        this.result[1] = this.result[1] | 0x10;
      } 
      if (direction == 4)
        if ((this.command & 0x1F) == 6) {
          if ((this.command & 0x20) == 0)
            if (isDeletedData())
              this.result[2] = this.result[2] | 0x40;  
        } else if ((this.command & 0x1F) == 12) {
          if ((this.command & 0x20) == 0)
            if (!isDeletedData())
              this.result[2] = this.result[2] | 0x40;  
        }  
      try {
        params[1] = id[0];
        this.result[3] = id[0];
        params[2] = id[1];
        this.result[4] = id[1];
        this.result[5] = id[2];
        params[4] = id[3];
        this.result[6] = id[3];
      } catch (Exception exception) {}
      this.rcount = 7;
      this.action = 0;
      this.next = this.count + getTiming();
      this.activeDrive.setActive(false);
    } else {
      params[3] = params[3] + 1 & 0xFF;
      getNextSector(direction);
    } 
  }
  
  protected final void writeSector() {
    if (setupResult())
      getNextSector(5); 
  }
  
  protected final void writeDeletedData() {
    if (setupResult())
      getNextSector(5); 
  }
  
  protected final void writeSectorByte() {
    if (this.data == -1)
      this.overrun = true; 
    this.saveTimer = 1;
    this.buffer[this.offset++] = this.data;
    this.data = -1;
    if (this.offset == this.buffer.length) {
      endBuffer(5);
      saveCheck();
    } else {
      this.next = this.count + this.countMFM;
      this.status |= 0x80;
    } 
  }
  
  protected final void writeFormatByte() {
    this.formatid[this.offset++] = this.data & 0xFF;
    this.data = -1;
    if (this.offset == 4) {
      endFormatID();
      saveCheck();
    } else {
      this.next = this.count + this.countMFM;
      this.status |= 0x80;
    } 
  }
  
  public final void saveCheck() {}
  
  public final void cycle() {
    if (this.seeker != 0) {
      this.seeker++;
      if (this.seeker > 4000000) {
        this.seeker = 0;
        Samples.MOTOR.stop();
      } 
    } 
    if (this.saveTimer != 0) {
      this.saveTimer++;
      if (this.saveTimer > 1000000) {
        this.activeDrive.saveImage();
        this.saveTimer = 0;
      } 
    } 
    if (++this.count == this.next) {
      setStatusInfo();
      switch (this.action) {
        case 1:
          seekStep();
          break;
        case 0:
          poll();
          break;
        case 2:
          getNextID();
          break;
        case 4:
          readSectorByte();
          break;
        case 8:
          writeScanByte();
          break;
        case 5:
          writeSectorByte();
          break;
        case 6:
          writeFormatByte();
          break;
      } 
    } 
  }
  
  public void setForcedHead(int head, int drive) {
    if (this.drives[drive] != null) {
      this.drives[drive].setForcedHead(head);
      this.driveChanged = true;
    } 
  }
  
  public int getForcedHead(int drive) {
    if (this.drives[drive] != null)
      return this.drives[drive].getForcedHead(); 
    return 0;
  }
  
  public String[] getInfo(int drive) {
    try {
      this.drives[drive].setCylinder(0);
      poll();
      int cylinder = this.drives[drive].getCylinder();
      int[] disktype = null;
      byte[] info1 = null;
      byte[] info2 = null;
      byte[] info3 = null;
      byte[] info4 = null;
      byte[] info5 = null;
      byte[] info6 = null;
      byte[] info7 = null;
      byte[] info8 = null;
      byte[] info = null;
      int dumpsize = 64;
      int length = 0;
      int position = 0;
      this.parados = false;
      if (this.drives[drive] != null) {
        disktype = this.drives[drive].getNextSectorID();
        if (disktype != null) {
          if (disktype[2] > 64 && disktype[2] <= 73) {
            this.systemdisk = true;
            this.drives[drive].setCylinder(2);
            info1 = this.drives[drive].getSector(2, 0, 65, 2);
            info2 = this.drives[drive].getSector(2, 0, 66, 2);
            info3 = this.drives[drive].getSector(2, 0, 67, 2);
            info4 = this.drives[drive].getSector(2, 0, 68, 2);
            info5 = this.drives[drive].getSector(2, 0, 69, 2);
            info6 = this.drives[drive].getSector(2, 0, 70, 2);
            info7 = this.drives[drive].getSector(2, 0, 71, 2);
            info8 = this.drives[drive].getSector(2, 0, 72, 2);
          } else if (disktype[2] > 192 && disktype[2] <= 201) {
            this.systemdisk = false;
            this.drives[drive].setCylinder(0);
            info1 = this.drives[drive].getSector(0, 0, 193, 2);
            info2 = this.drives[drive].getSector(0, 0, 194, 2);
            info3 = this.drives[drive].getSector(0, 0, 195, 2);
            info4 = this.drives[drive].getSector(0, 0, 196, 2);
            info5 = this.drives[drive].getSector(0, 0, 197, 2);
            info6 = this.drives[drive].getSector(0, 0, 198, 2);
            info7 = this.drives[drive].getSector(0, 0, 199, 2);
            info8 = this.drives[drive].getSector(0, 0, 200, 2);
          } else if (disktype[2] > 144 && disktype[2] <= 159) {
            this.systemdisk = false;
            this.drives[drive].setCylinder(0);
            info1 = this.drives[drive].getSector(0, 0, 145, 2);
            info2 = this.drives[drive].getSector(0, 0, 146, 2);
            info3 = this.drives[drive].getSector(0, 0, 147, 2);
            info4 = this.drives[drive].getSector(0, 0, 148, 2);
            info5 = this.drives[drive].getSector(0, 0, 149, 2);
            info6 = this.drives[drive].getSector(0, 0, 150, 2);
            info7 = this.drives[drive].getSector(0, 0, 151, 2);
            info8 = this.drives[drive].getSector(0, 0, 152, 2);
            this.parados = true;
          } else if (disktype[2] > 16 && disktype[2] <= 31) {
            this.systemdisk = false;
            this.drives[drive].setCylinder(0);
            info1 = this.drives[drive].getSector(0, 0, 17, 2);
            info2 = this.drives[drive].getSector(0, 0, 18, 2);
            info3 = this.drives[drive].getSector(0, 0, 19, 2);
            info4 = this.drives[drive].getSector(0, 0, 20, 2);
            info5 = this.drives[drive].getSector(0, 0, 21, 2);
            info6 = this.drives[drive].getSector(0, 0, 22, 2);
            info7 = this.drives[drive].getSector(0, 0, 23, 2);
            info8 = this.drives[drive].getSector(0, 0, 24, 2);
            this.parados = true;
          } else {
            this.systemdisk = false;
            System.err.println("Unknown disk format: " + Util.hex(disktype[2]));
            this.drives[drive].setCylinder(0);
            info1 = this.drives[drive].getSector(0, 0, 193, 2);
            info2 = this.drives[drive].getSector(0, 0, 194, 2);
            info3 = this.drives[drive].getSector(0, 0, 195, 2);
            info4 = this.drives[drive].getSector(0, 0, 196, 2);
            info5 = this.drives[drive].getSector(0, 0, 197, 2);
            info6 = this.drives[drive].getSector(0, 0, 198, 2);
            info7 = this.drives[drive].getSector(0, 0, 199, 2);
            info8 = this.drives[drive].getSector(0, 0, 200, 2);
          } 
          this.drives[drive].setCylinder(cylinder);
          if (info1 != null && info2 != null && info3 != null && info4 != null) {
            length += info1.length;
            length += info2.length;
            length += info3.length;
            length += info4.length;
            if (info5 != null)
              length += info5.length; 
            if (info6 != null)
              length += info6.length; 
            if (info7 != null)
              length += info7.length; 
            if (info8 != null)
              length += info8.length; 
            info = new byte[length];
            int i;
            for (i = 0; i < info1.length; i++) {
              info[position] = info1[i];
              position++;
            } 
            for (i = 0; i < info2.length; i++) {
              info[position] = info2[i];
              position++;
            } 
            for (i = 0; i < info3.length; i++) {
              info[position] = info3[i];
              position++;
            } 
            for (i = 0; i < info4.length; i++) {
              info[position] = info4[i];
              position++;
            } 
            if (info5 != null) {
              dumpsize += 16;
              for (i = 0; i < info5.length; i++) {
                info[position] = info5[i];
                position++;
              } 
            } 
            if (info6 != null) {
              dumpsize += 16;
              for (i = 0; i < info6.length; i++) {
                info[position] = info6[i];
                position++;
              } 
            } 
            if (info7 != null) {
              dumpsize += 16;
              for (i = 0; i < info7.length; i++) {
                info[position] = info7[i];
                position++;
              } 
            } 
            if (info8 != null) {
              dumpsize += 16;
              for (i = 0; i < info8.length; i++) {
                info[position] = info8[i];
                position++;
              } 
            } 
            return showDir(info, drive, dumpsize);
          } 
        } 
      } 
    } catch (Exception exception) {}
    return null;
  }
  
  public String[] showDir(byte[] info, int drive, int size) {
    poll();
    String[] entry = new String[size];
    String[] output = null;
    String[] endentries = null;
    int[] user = new int[size];
    int[] checkuser = null;
    int position = 0;
    int[] check = new int[size];
    int recount = 0;
    int arrayLength = 0;
    boolean sys = false;
    boolean readonly = false;
    boolean corrupt = false;
    this.enduser = null;
    int counte;
    for (counte = 0; counte < size; counte++) {
      if (!this.parados) {
        check[counte] = info[position + 12];
      } else {
        check[counte] = 0;
      } 
      if (check[counte] == 0)
        arrayLength++; 
      entry[counte] = "";
      user[counte] = info[position++];
      int k;
      for (k = 1; k < 9; k++) {
        int chk = info[position] & Byte.MAX_VALUE;
        if (chk < 32 || chk > 127)
          corrupt = true; 
        entry[counte] = entry[counte] + (char)(info[position] & Byte.MAX_VALUE);
        position++;
      } 
      entry[counte] = entry[counte] + ".";
      for (k = 0; k < 3; k++) {
        entry[counte] = entry[counte] + (char)(info[position] & Byte.MAX_VALUE);
        if (k == 1 && info[position] < 0)
          sys = true; 
        if (k == 0 && info[position] < 0)
          readonly = true; 
        position++;
      } 
      if (readonly) {
        entry[counte] = entry[counte] + "<";
        readonly = false;
      } 
      if (sys) {
        if (this.showSys) {
          entry[counte] = entry[counte] + ">";
        } else {
          entry[counte] = null;
        } 
        sys = false;
      } 
      if (corrupt) {
        entry[counte] = null;
        corrupt = false;
      } 
      position += 20;
    } 
    output = new String[arrayLength];
    checkuser = new int[arrayLength];
    for (counte = 0; counte < size; counte++) {
      if (entry[counte] != null && check[counte] == 0 && user[counte] >= 0 && user[counte] <= 65301) {
        output[recount] = entry[counte];
        checkuser[recount] = user[counte];
        recount++;
      } 
    } 
    int i;
    for (i = 0; i < output.length; i++) {
      if (output[i] == null)
        arrayLength--; 
    } 
    endentries = new String[arrayLength];
    for (i = 0; i < arrayLength; i++) {
      endentries[i] = output[i] + "|" + checkuser[i];
      System.out.println(endentries[i]);
    } 
    Set<String> strings = new HashSet<>();
    strings.addAll(Arrays.asList(endentries));
    endentries = strings.<String>toArray(new String[0]);
    Arrays.sort((Object[])endentries);
    this.enduser = new int[endentries.length];
    for (int j = 0; j < endentries.length; j++) {
      String us = endentries[j];
      while (us.contains("|"))
        us = us.substring(1); 
      this.enduser[j] = Integer.parseInt(us);
      while (endentries[j].contains("|"))
        endentries[j] = endentries[j].substring(0, endentries[j].length() - 1); 
    } 
    poll();
    return endentries;
  }
  
  public boolean getSystem() {
    return this.systemdisk;
  }
  
  public int[] getUser() {
    return this.enduser;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\floppy\UPD765A.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */