package JCPC.core.device.floppy;

import java.io.File;

public abstract class DiscImage {
  protected String name;
  
  public abstract void saveImage();
  
  public DiscImage(String name) {
    this.name = name;
  }
  
  public String getName() {
    return this.name;
  }
  
  public abstract int getNoOfTracks();
  
  public abstract void removeAllSectorsFromTrack(int paramInt1, int paramInt2);
  
  public abstract void addSectorToTrack(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public abstract int getST1ForSector(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public abstract int getST2ForSector(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public abstract void setST1ForSector(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public abstract void setST2ForSector(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public abstract byte[] readSector(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public abstract int getSectorCount(int paramInt1, int paramInt2);
  
  public abstract int[] getSectorID(int paramInt1, int paramInt2, int paramInt3);
  
  public abstract void writeSector(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, byte[] paramArrayOfbyte);
  
  public abstract void saveImage(File paramFile);
  
  public abstract byte[] getImage();
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\floppy\DiscImage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */