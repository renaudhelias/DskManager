package JCPC.core.device;

import JCPC.core.Util;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class MappingCalculator extends JFrame {
  private JTextField from;
  
  private JButton jButton2;
  
  private JLabel jLabel1;
  
  private JLabel jLabel2;
  
  private JLabel jLabel3;
  
  private JLabel jLabel4;
  
  private JLabel jLabel5;
  
  private JLabel jLabel6;
  
  private JTextField mask;
  
  private JTextField test;
  
  private JTextField to;
  
  public MappingCalculator() {
    initComponents();
  }
  
  protected void test() {
    try {
      for (int i = 0; i < 100; i++)
        System.out.println(); 
      int pmask = Util.hexValue(this.mask.getText());
      int ptest = Util.hexValue(this.test.getText());
      int fromport = Util.hexValue(this.from.getText());
      int toport = Util.hexValue(this.to.getText());
      int port = 0;
      boolean match = true;
      int j;
      for (j = 0; j < fromport; j++) {
        if ((port & pmask) == ptest) {
          match = false;
          System.out.println("error: match:" + Util.hex((short)port));
          break;
        } 
      } 
      for (j = fromport; j <= toport; j++) {
        port = j;
        if ((port & pmask) != ptest) {
          match = false;
          System.out.println("error: match:" + Util.hex((short)port));
          break;
        } 
      } 
      for (j = toport + 1; j <= 65535; j++) {
        port = j;
        if ((port & pmask) == ptest) {
          System.out.println("error: match:" + Util.hex((short)port));
          break;
        } 
      } 
      if (match)
        System.out.println("Success!" + Util.hex((short)port)); 
      this.jLabel6.setText(match ? "Success!" : "Failed!");
    } catch (Exception exception) {}
  }
  
  private void initComponents() {
    this.jLabel1 = new JLabel();
    this.from = new JTextField();
    this.jLabel2 = new JLabel();
    this.to = new JTextField();
    this.jLabel3 = new JLabel();
    this.mask = new JTextField();
    this.jLabel4 = new JLabel();
    this.test = new JTextField();
    this.jButton2 = new JButton();
    this.jLabel5 = new JLabel();
    this.jLabel6 = new JLabel();
    setDefaultCloseOperation(3);
    setTitle("Port tester");
    setAlwaysOnTop(true);
    setResizable(false);
    this.jLabel1.setText("Wanted Port-Range:");
    this.from.setText("7F00");
    this.jLabel2.setText("-");
    this.to.setText("7FFF");
    this.jLabel3.setText("Mask:");
    this.mask.setText("FF00");
    this.jLabel4.setText("Test:");
    this.test.setText("7F00");
    this.jButton2.setText("Test");
    this.jButton2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            MappingCalculator.this.jButton2ActionPerformed(evt);
          }
        });
    this.jLabel5.setText("Status:");
    this.jLabel6.setText("Not tested");
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
              .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(this.jLabel1)
                .addGroup(layout.createSequentialGroup()
                  .addComponent(this.jLabel3)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.mask, -2, -1, -2)
                  .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(this.jLabel4)))
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(this.test, -2, -1, -2)
                .addComponent(this.from, -2, -1, -2))
              .addGap(16, 16, 16)
              .addComponent(this.jLabel2)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(this.to, -2, -1, -2)
                .addComponent(this.jButton2)))
            .addGroup(layout.createSequentialGroup()
              .addComponent(this.jLabel5)
              .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
              .addComponent(this.jLabel6)))
          .addContainerGap(-1, 32767)));
    layout.setVerticalGroup(layout
        .createParallelGroup(GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
          .addContainerGap()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jLabel1)
            .addComponent(this.from, -2, -1, -2)
            .addComponent(this.jLabel2)
            .addComponent(this.to, -2, -1, -2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jLabel3)
            .addComponent(this.mask, -2, -1, -2)
            .addComponent(this.jLabel4)
            .addComponent(this.test, -2, -1, -2)
            .addComponent(this.jButton2))
          .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(this.jLabel5)
            .addComponent(this.jLabel6))
          .addContainerGap(18, 32767)));
    pack();
  }
  
  private void jButton2ActionPerformed(ActionEvent evt) {
    test();
  }
  
  public static void main(String[] args) {
    try {
      for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
          UIManager.setLookAndFeel(info.getClassName());
          break;
        } 
      } 
    } catch (ClassNotFoundException ex) {
      Logger.getLogger(MappingCalculator.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (InstantiationException ex) {
      Logger.getLogger(MappingCalculator.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (IllegalAccessException ex) {
      Logger.getLogger(MappingCalculator.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (UnsupportedLookAndFeelException ex) {
      Logger.getLogger(MappingCalculator.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new MappingCalculator()).setVisible(true);
          }
        });
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\MappingCalculator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */