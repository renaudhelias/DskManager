package JCPC.core.device.memory;

import JCPC.core.device.Device;

public abstract class Memory extends Device {
  public static final int KB = 1024;
  
  public static final int MB = 1048576;
  
  protected int size;
  
  public Memory(String type, int size) {
    super(type);
    this.size = size;
  }
  
  public int getAddressSize() {
    return this.size;
  }
  
  public int readByte(int address, Object config) {
    return readByte(address);
  }
  
  public void writeByte(int address, int value, Object config) {
    writeByte(address, value);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\memory\Memory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */