package JCPC.core.device.tape;

public abstract class CDT2WAVBaseOutput {
  private static final int LOAMP = 38;
  
  private static final int HIAMP = 218;
  
  protected boolean med = false;
  
  private double z80_freq = 3500000.0D;
  
  private byte[] buf = null;
  
  private int bufPos = 0;
  
  private double frequency = 44100.0D;
  
  private double cycle = 0.0D;
  
  private int amp = 38;
  
  public CDT2WAVBaseOutput(int freq) {
    this.buf = null;
    this.bufPos = 0;
    this.frequency = freq;
    this.cycle = this.frequency / this.z80_freq;
    init();
  }
  
  public void dispose() {
    this.buf = null;
  }
  
  protected abstract void init();
  
  protected abstract void write(int paramInt);
  
  protected abstract void stop();
  
  protected double getFrequency() {
    return this.frequency;
  }
  
  protected void outputSeek(int pos) {
    this.bufPos = pos;
  }
  
  protected int outputTell() {
    return this.bufPos;
  }
  
  protected final void outputByte(byte b) {
    if (this.buf != null)
      this.buf[this.bufPos] = b; 
    this.bufPos++;
  }
  
  protected final void outputByte(byte b, int count) {
    if (this.buf != null) {
      int p = this.bufPos;
      for (int i = 0; i < count; i++)
        this.buf[p++] = b; 
    } 
    this.bufPos += count;
  }
  
  public void setOutputBuffer(byte[] buf) {
    this.buf = buf;
    this.bufPos = 0;
  }
  
  public int samples(int tstates) {
    return (int)(0.5D + this.cycle * tstates);
  }
  
  public void setAmp(boolean high) {
    this.amp = high ? 218 : 38;
  }
  
  public void setAmpLow() {
    this.amp = 38;
  }
  
  public void toggleAmp() {
    if (isLowAmp()) {
      this.amp = 218;
    } else {
      this.amp = 38;
    } 
  }
  
  protected boolean isLowAmp() {
    return (this.amp == 38);
  }
  
  public void play(int numsamples) {
    write(numsamples);
  }
  
  public void pause(int ms) {
    int p = (int)(ms * this.frequency / 1000.0D);
    play(p);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\tape\CDT2WAVBaseOutput.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */