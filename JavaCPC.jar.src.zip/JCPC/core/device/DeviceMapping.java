package JCPC.core.device;

public class DeviceMapping {
  protected Device device;
  
  protected int mask;
  
  protected int test;
  
  protected String name;
  
  public DeviceMapping(Device device, int mask, int test) {
    this.device = device;
    this.name = device.name;
    this.mask = mask;
    this.test = test;
  }
  
  public int readPort(int port) {
    return ((port & this.mask) == this.test) ? this.device.readPort(port) : -1;
  }
  
  public void writePort(int port, int value) {
    if ((port & this.mask) == this.test)
      this.device.writePort(port, value); 
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\DeviceMapping.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */