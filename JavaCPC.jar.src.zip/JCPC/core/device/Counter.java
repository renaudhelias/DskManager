package JCPC.core.device;

public class Counter extends Device {
  protected int mask;
  
  protected int increment;
  
  protected int count;
  
  protected int value;
  
  public Counter(int bits, boolean down) {
    super("Counter (" + bits + " bit " + (down ? "down)" : "up)"));
    this.mask = 0;
    for (int i = 0; i < bits; i++)
      this.mask = this.mask << 1 | 0x1; 
    this.increment = down ? -1 : 1;
  }
  
  public int getCount() {
    return this.count;
  }
  
  public void setCount(int value) {
    this.count = value;
  }
  
  public int getValue() {
    return this.value;
  }
  
  public void setValue(int value) {
    this.value = value;
  }
  
  public void cycle() {
    this.value = this.value + this.increment & this.mask;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\Counter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */