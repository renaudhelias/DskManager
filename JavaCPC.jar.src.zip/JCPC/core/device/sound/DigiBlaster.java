package JCPC.core.device.sound;

public class DigiBlaster extends DigiDevice {
  public DigiBlaster() {
    super("Digiblaster");
  }
  
  public void writePort(int port, int value) {
    if (port == 61311 || port < 61184 || (port > 61343 && port < 61424))
      return; 
    AY_3_8910.digicount = 1;
    AY_3_8910.digiblast = true;
    AY_3_8910.blasterA = value;
    AY_3_8910.blasterB = AY_3_8910.blasterA;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\sound\DigiBlaster.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */