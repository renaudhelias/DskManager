package JCPC.core.device.sound;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;

public class JavaSound extends SunAudio {
  public static int SAMPLE_RATE = 22050;
  
  public static int[] rates = new int[] { 6000, 8000, 11025, 22050, 32000, 44100 };
  
  public static boolean muted = false;
  
  protected static AudioFormat STEREO_FORMAT;
  
  protected SourceDataLine line;
  
  protected byte[] data;
  
  protected int offset = 0;
  
  protected int channels;
  
  protected long startCount;
  
  public JavaSound(int samples, boolean stereo) {
    super(samples, stereo);
    System.out.println("Samples:" + samples);
  }
  
  public int getSampleRate() {
    return SAMPLE_RATE;
  }
  
  protected void init() {
    this.format = 2;
    this.channels = 2;
    this.data = new byte[this.samples * this.channels];
    for (int i = 0; i < this.data.length; i++)
      this.data[i] = Byte.MIN_VALUE; 
    boolean match = false;
    int j = rates.length - 1;
    boolean a = false, b = true;
    while (!match) {
      try {
        SAMPLE_RATE = rates[j--];
        STEREO_FORMAT = new AudioFormat(SAMPLE_RATE, 8, 2, a, b);
        AudioFormat audioformat = STEREO_FORMAT;
        this.line = (SourceDataLine)AudioSystem.getLine(new DataLine.Info(SourceDataLine.class, audioformat, SAMPLE_RATE * this.channels));
        this.line.open();
        match = true;
      } catch (Exception e) {
        if (j < 0) {
          if (!a) {
            a = true;
          } else if (!b) {
            b = true;
          } else {
            System.err.println("Critical Error!!!\r\nUnable to define sound!");
            break;
          } 
          j = rates.length - 1;
        } 
      } 
    } 
    System.out.println("Samplerate is: " + SAMPLE_RATE + " - A is: " + a + " - B is: " + b);
  }
  
  public void resync() {
    this.line.flush();
    for (int i = 0; i < this.data.length; i++)
      this.data[i] = Byte.MIN_VALUE; 
    this.startCount = this.line.getLongFramePosition();
    int sample = SAMPLE_RATE / 10 * this.channels;
    while (sample > 0) {
      int len = Math.min(this.data.length, sample);
      this.line.write(this.data, 0, len);
      sample -= len;
    } 
    System.out.println("resync: start=" + this.startCount);
  }
  
  public long getCount() {
    return this.line.getLongFramePosition() - this.startCount - 100L;
  }
  
  public long getDeviation() {
    return (SAMPLE_RATE / 10);
  }
  
  public void play() {
    resync();
    this.line.start();
  }
  
  public void stop() {
    this.line.stop();
  }
  
  public void dispose() {
    this.line.close();
  }
  
  public void writeStereo(int a, int b) {
    a ^= 0x80;
    b ^= 0x80;
    switch (this.format) {
      case 0:
        this.data[this.offset] = SoundUtil.ulawToUPCM8((byte)a);
        this.data[this.offset + 1] = SoundUtil.ulawToUPCM8((byte)b);
        break;
      case 2:
        this.data[this.offset] = (byte)a;
        this.data[this.offset + 1] = (byte)b;
        break;
    } 
    if (muted) {
      this.data[this.offset] = 0;
      this.data[this.offset + 1] = 0;
    } 
    if ((this.offset += 2) == this.data.length) {
      this.line.write(this.data, 0, this.data.length);
      this.offset = 0;
    } 
    this.updates++;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\sound\JavaSound.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */