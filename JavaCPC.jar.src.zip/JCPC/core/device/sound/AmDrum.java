package JCPC.core.device.sound;

public class AmDrum extends DigiDevice {
  int drum = 255;
  
  public AmDrum() {
    super("Cheetah AmDrum");
  }
  
  public int readPort(int port) {
    if (!AY_3_8910.digiblast)
      return 255; 
    return this.drum;
  }
  
  public void writePort(int port, int value) {
    AY_3_8910.digicount = 1;
    AY_3_8910.digiblast = true;
    this.drum = value;
    AY_3_8910.blasterA = value ^ 0x80;
    AY_3_8910.blasterB = AY_3_8910.blasterA;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\sound\AmDrum.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */