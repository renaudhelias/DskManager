package JCPC.core.device.sound;

import JCPC.core.device.Device;

public class DigiDevice extends Device {
  public DigiDevice(String name) {
    super(name);
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\sound\DigiDevice.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */