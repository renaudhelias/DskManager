package JCPC.core.device.sound;

import JCPC.core.device.Device;

public class SoundDevice extends Device {
  protected SoundPlayer player;
  
  public SoundDevice(String name) {
    super(name);
  }
  
  public SoundPlayer getSoundPlayer() {
    return this.player;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\sound\SoundDevice.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */