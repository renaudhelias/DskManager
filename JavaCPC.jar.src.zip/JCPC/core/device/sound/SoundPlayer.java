package JCPC.core.device.sound;

import JCPC.core.device.ComputerTimer;

public abstract class SoundPlayer implements ComputerTimer {
  protected int format = 0;
  
  public int getClockAdder(int test, int cyclesPerSecond) {
    return (int)(test * getSampleRate() / cyclesPerSecond);
  }
  
  public abstract int getSampleRate();
  
  public abstract void writeStereo(int paramInt1, int paramInt2);
  
  public abstract void play();
  
  public abstract void stop();
  
  public abstract void resync();
  
  public abstract void dispose();
  
  public void setFormat(int value) {
    this.format = value;
  }
  
  public int getFormat() {
    return this.format;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\sound\SoundPlayer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */