package JCPC.core.device.crtc;

public interface CRTCListener {
  void hSyncStart();
  
  void hSyncEnd();
  
  void cycle();
  
  void vDispStart();
  
  void hDispStart();
  
  void vSyncStart();
  
  void vSyncEnd();
  
  void hDispEnd();
  
  void cursor();
  
  void modeCheck();
  
  int[] getField();
  
  int PEEK(int paramInt);
  
  void POKE(int paramInt1, int paramInt2);
  
  int getScreenMode();
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\crtc\CRTCListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */