package JCPC.core.device.crtc;

import JCPC.core.device.Device;

public abstract class CRTC extends Device {
  protected CRTCListener listener;
  
  public CRTC(String type) {
    super(type);
  }
  
  public void setCRTCListener(CRTCListener listener) {
    this.listener = listener;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\crtc\CRTC.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */