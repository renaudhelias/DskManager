package JCPC.core.device;

public class Register {
  protected String name;
  
  protected int bits;
  
  protected String format;
  
  protected int column;
  
  public Register(String name, int bits, String format, int column) {
    this.name = name;
    this.bits = bits;
    this.format = format;
    this.column = column;
  }
  
  public Register(String name) {
    this(name, 8, null, 0);
  }
  
  public Register(String name, int bits) {
    this(name, bits, null, 0);
  }
  
  public Register(String name, int bits, String format) {
    this(name, bits, format, 0);
  }
  
  public Register(String name, int bits, int column) {
    this(name, bits, null, column);
  }
  
  public String getName() {
    return this.name;
  }
  
  public int getBits() {
    return this.bits;
  }
  
  public String getFormat() {
    return this.format;
  }
  
  public int getColumn() {
    return this.column;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\device\Register.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */