package JCPC.core.cpu;

import JCPC.core.Util;
import JCPC.core.device.Device;
import JCPC.core.device.DeviceMapping;

public abstract class Processor extends Device {
  public int actualAddress;
  
  protected Device memory;
  
  protected DeviceMapping[] inputDevice = new DeviceMapping[0];
  
  protected DeviceMapping[] outputDevice = new DeviceMapping[0];
  
  protected Device cycleDevice = null;
  
  protected Device interruptDevice = null;
  
  protected int interruptPending = 0;
  
  protected long cycles = 0L;
  
  protected long cyclesPerSecond;
  
  protected boolean stopped = false;
  
  public Processor(String type, long cyclesPerSecond) {
    super(type);
    this.cyclesPerSecond = cyclesPerSecond;
  }
  
  public final void cycle(int count) {
    for (; count > 0; count--)
      cycle(); 
  }
  
  public void cycle() {
    this.cycles++;
    this.cycleDevice.cycle();
  }
  
  public void reset() {
    this.interruptPending = 0;
    this.cycles = 0L;
  }
  
  public long getCycles() {
    return this.cycles;
  }
  
  public abstract void step();
  
  public abstract void stepOver();
  
  public void run() {
    this.stopped = false;
    do {
      step();
    } while (!this.stopped);
  }
  
  public void runTo(int address) {
    this.stopped = false;
    do {
      step();
    } while (!this.stopped && getProgramCounter() != address);
  }
  
  public synchronized void stop() {
    this.stopped = true;
  }
  
  public final int readWord(int addr) {
    return readByte(addr) + (readByte(addr + 1 & 0xFFFF) << 8);
  }
  
  public final void writeWord(int addr, int value) {
    writeByte(addr, value & 0xFF);
    writeByte(addr + 1 & 0xFFFF, value >> 8 & 0xFF);
  }
  
  public int readByte(int address) {
    return this.memory.readByte(address);
  }
  
  public int writeByte(int address, int value) {
    return this.memory.writeByte(address, value);
  }
  
  public final int in(int port) {
    int result = 255;
    for (int i = 0; i < this.inputDevice.length; i++)
      result &= this.inputDevice[i].readPort(port); 
    return result;
  }
  
  public final void out(int port, int value) {
    for (int i = 0; i < this.outputDevice.length; i++)
      this.outputDevice[i].writePort(port, value); 
  }
  
  public final void setMemoryDevice(Device value) {
    this.memory = value;
  }
  
  public final Device getMemoryDevice() {
    return this.memory;
  }
  
  public final void addInputDeviceMapping(DeviceMapping value) {
    this.inputDevice = (DeviceMapping[])Util.arrayInsert((Object[])this.inputDevice, this.inputDevice.length, 1, value);
  }
  
  public final void removeInputDeviceMapping(DeviceMapping value) {
    this.inputDevice = (DeviceMapping[])Util.arrayDeleteElement((Object[])this.inputDevice, value);
  }
  
  public final void addOutputDeviceMapping(DeviceMapping value) {
    this.outputDevice = (DeviceMapping[])Util.arrayInsert((Object[])this.outputDevice, this.outputDevice.length, 1, value);
  }
  
  public final void removeOutputDeviceMapping(DeviceMapping value) {
    this.outputDevice = (DeviceMapping[])Util.arrayDeleteElement((Object[])this.outputDevice, value);
  }
  
  public final void setCycleDevice(Device value) {
    this.cycleDevice = value;
  }
  
  public final void setInterruptDevice(Device value) {
    this.interruptDevice = value;
  }
  
  public void setInterrupt(int mask) {
    this.interruptPending |= mask;
  }
  
  public void clearInterrupt(int mask) {
    this.interruptPending &= mask ^ 0xFFFFFFFF;
  }
  
  public abstract String getState();
  
  public abstract int getProgramCounter();
  
  public long getCyclesPerSecond() {
    return this.cyclesPerSecond;
  }
  
  public void setCyclesPerSecond(long value) {
    this.cyclesPerSecond = value;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCPC\core\cpu\Processor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */