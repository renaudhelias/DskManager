package JCPC.util.diss;

import JCPC.core.Util;
import JCPC.core.device.memory.Memory;

public abstract class Disassembler {
  protected Object config;
  
  protected int addrMask = 65535;
  
  protected int nextAddress(int[] address) {
    int result = address[0];
    address[0] = result + 1 & this.addrMask;
    return result;
  }
  
  public abstract String disassemble(Memory paramMemory, int[] paramArrayOfint);
  
  public String disassemble(Memory memory, int[] address, boolean showAddr, int dataPos) {
    int start = address[0];
    String result = (showAddr ? (Util.hex((short)start) + ": ") : "") + disassemble(memory, address);
    if (dataPos != 0) {
      while (result.length() < dataPos)
        result = result + " "; 
      int i;
      for (i = start; i != address[0]; i = i + 1 & 0xFFFF) {
        if (i != start)
          result = result + " "; 
        result = result + Util.hex((byte)memory.readByte(i, this.config));
      } 
    } 
    return result;
  }
  
  public void setMemoryConfiguration(Object value) {
    this.config = value;
  }
  
  public Object getMemoryConfiguration() {
    return this.config;
  }
}


/* Location:              C:\Users\Joe\Downloads\JavaCPC_Desktop_2.9.8f\JavaCPC.jar!\JCP\\util\diss\Disassembler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */